import assert from 'node:assert/strict';
import { fork } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { after, test } from 'node:test';
import type { PoolClient } from 'pg';
import { StateFixture } from './state-fixture.ts';
import type { AttemptInput, EffectInput, Head, Json } from './state-fixture.ts';

type Observation = { scenario: string; status: 'passed' | 'failed'; details: unknown };
const observations: Observation[] = [];
after(async () => {
  await writeFile(process.env['STATE_RESULTS_PATH'] ?? 'state-results.json', JSON.stringify({
    scope: 'native PostgreSQL host fixture, not production qualification',
    node: process.version, scenarios: observations,
    jointScenario: 'S09 belongs to real Worker plus database integration receipt',
  }, null, 2) + '\n');
});
function scenario(id: string, run: (db: StateFixture) => Promise<unknown>): void {
  test(id, { timeout: 35000 }, async () => {
    let db: StateFixture | undefined;
    try {
      db = await StateFixture.create();
      const detail = await run(db);
      observations.push({ scenario: id, status: 'passed', details: detail });
    } catch (error) {
      observations.push({ scenario: id, status: 'failed', details: String(error) });
      throw error;
    } finally { if (db) await db.destroy(); }
  });
}
function candidate(id: string, captured: Head, target = 'B1', digest = 'artifact-B'): AttemptInput {
  return { attemptId: id, expectedRevision: captured.revision,
    expectedGeneration: captured.generation, targetGeneration: target,
    cohortDigest: digest, baselineId: 'S0' };
}
function operation(id: string, captured: Head, value: Json = { count: 1 }): EffectInput {
  return { effectId: id, generation: captured.generation,
    effectEpoch: captured.effectEpoch, stateSchema: 'v1', value };
}
async function publish(db: StateFixture, id: string, target = 'B1', digest = 'artifact-B'): Promise<Head> {
  await db.admitAttempt(candidate(id, await db.readHead(), target, digest));
  const outcome = await db.publishAttempt(id);
  assert.equal(outcome.status, 'committed');
  assert.ok(outcome.result);
  return outcome.result;
}
async function until<T>(read: () => Promise<T>, accept: (value: T) => boolean, label: string): Promise<T> {
  const deadline = Date.now() + 8000;
  while (true) {
    const value = await read();
    if (accept(value)) return value;
    if (Date.now() >= deadline) throw new Error(`Timed out observing ${label}`);
    await delay(10); // Native observed condition, never timing alone, is the oracle.
  }
}
async function waitForBlock(observer: PoolClient, blockedPid: number): Promise<number[]> {
  return until(async () => {
    const row = (await observer.query<{ blockers: number[] }>(
      'SELECT pg_blocking_pids($1::int) AS blockers', [blockedPid],
    )).rows[0];
    assert.ok(row);
    return row.blockers;
  }, blockers => blockers.length > 0, 'native row-lock wait');
}
async function waitForWaiters(observer: PoolClient, schema: string, count: number): Promise<unknown> {
  return until(async () => (await observer.query<{
    pid: number; blockers: number[]; query: string;
  }>(`SELECT pid, pg_blocking_pids(pid) AS blockers, query FROM pg_stat_activity
    WHERE application_name=$1 AND wait_event_type='Lock'`, [schema])).rows,
  rows => rows.length >= count, `${count} independent DB waiters`);
}
async function backendPid(client: PoolClient): Promise<number> {
  const row = (await client.query<{ pid: number }>('SELECT pg_backend_pid() AS pid')).rows[0];
  assert.ok(row);
  return row.pid;
}
function child(mode: string, db: StateFixture, id: string): {
  process: ChildProcess;
  exited: Promise<{ code: number | null; signal: NodeJS.Signals | null }>;
  staged: Promise<number>;
} {
  const process = fork(new URL('./fault-child.ts', import.meta.url), [mode, db.schema, id], {
    execArgv: ['--unhandled-rejections=strict'], stdio: ['ignore', 'ignore', 'inherit', 'ipc'],
  });
  const exited = new Promise<{ code: number | null; signal: NodeJS.Signals | null }>((resolve, reject) => {
    process.once('error', reject);
    process.once('exit', (code, signal) => resolve({ code, signal }));
  });
  void exited.catch(() => {});
  const staged = new Promise<number>((resolve, reject) => {
    // An early failed child must unwind the test, not wait forever for IPC.
    const timeout = setTimeout(() => {
      process.kill('SIGKILL');
      reject(new Error('Fault child did not reach staged checkpoint'));
    }, 8000);
    const earlyExit = (): void => {
      clearTimeout(timeout);
      reject(new Error('Fault child exited before staged checkpoint'));
    };
    const failed = (error: Error): void => { clearTimeout(timeout); reject(error); };
    process.once('error', failed);
    process.once('exit', earlyExit);
    process.once('message', (message: unknown) => {
      clearTimeout(timeout);
      process.removeListener('exit', earlyExit);
      process.removeListener('error', failed);
      if (typeof message !== 'object' || message === null || !('kind' in message) ||
        message.kind !== 'staged' || !('backendPid' in message) ||
        typeof message.backendPid !== 'number') reject(new Error('Unexpected child message'));
      else resolve(message.backendPid);
    });
  });
  // Other fault modes intentionally never send a staged checkpoint.
  void staged.catch(() => {});
  return { process, exited, staged };
}
async function rollbackRelease(client: PoolClient): Promise<void> {
  try { await client.query('ROLLBACK'); } finally { client.release(); }
}

scenario('S01 competing publishers CAS once', async db => {
  const [barrier, observer] = await Promise.all([db.client(), db.client()]);
  let settle: Promise<unknown> = Promise.resolve();
  try {
    const captured = await db.readHead();
    await Promise.all([
      db.admitAttempt(candidate('left', captured, 'B1', 'artifact-B')),
      db.admitAttempt(candidate('right', captured, 'C1', 'artifact-C')),
    ]);
    await barrier.query('BEGIN');
    await barrier.query(`SELECT * FROM ${db.sql}.head FOR UPDATE`);
    const outcomes = Promise.all([db.publishAttempt('left'), db.publishAttempt('right')]);
    settle = outcomes.catch(() => {});
    const waiters = await waitForWaiters(observer, db.schema, 2);
    await barrier.query('COMMIT');
    const values = await outcomes;
    assert.deepEqual(values.map(v => v.status).sort(), ['committed', 'conflict']);
    const selected = await db.readHead();
    assert.equal(selected.revision, '1');
    assert.ok(values.every(v => v.result?.generation === selected.generation));
    assert.deepEqual(await db.observeAttempt('left'), values[0]);
    assert.deepEqual(await db.observeAttempt('right'), values[1]);
    const inventory = (await observer.query<{ version: string; version_num: string }>(
      "SELECT version() AS version, current_setting('server_version_num') AS version_num",
    )).rows[0];
    assert.ok(inventory);
    assert.equal(inventory.version_num, '180007');
    return { inventory, waiters, outcomes: values, selected };
  } finally { await rollbackRelease(barrier); await settle; observer.release(); }
});

scenario('S02 same attempt serializes and effects replay once', async db => {
  const captured = await db.readHead();
  const input = candidate('same-attempt', captured);
  const admissions = await Promise.all([db.admitAttempt(input), db.admitAttempt(input)]);
  assert.deepEqual(admissions[0], admissions[1]);
  const [barrier, observer] = await Promise.all([db.client(), db.client()]);
  let settle: Promise<unknown> = Promise.resolve();
  try {
    await barrier.query('BEGIN');
    await barrier.query(`SELECT * FROM ${db.sql}.head FOR UPDATE`);
    const work = Promise.all([db.publishAttempt(input.attemptId), db.publishAttempt(input.attemptId)]);
    settle = work.catch(() => {});
    const waiters = await waitForWaiters(observer, db.schema, 2);
    await barrier.query('COMMIT');
    const publications = await work;
    assert.deepEqual(publications[0], publications[1]);
    assert.equal(publications[0]?.status, 'committed');
    assert.equal((await db.readHead()).revision, '1');
    const effectInput = operation('idempotent-effect', await db.readHead());
    const effects = await Promise.all([db.guardedWrite(effectInput), db.guardedWrite(effectInput)]);
    assert.deepEqual(effects.map(e => e.kind).sort(), ['committed', 'replayed']);
    await publish(db, 'next', 'C1', 'artifact-C');
    const replay = await db.guardedWrite(effectInput);
    assert.equal(replay.kind, 'replayed');
    assert.equal((await db.guardedWrite({ ...effectInput, effectId: 'new-stale' })).kind, 'stale');
    await assert.rejects(db.guardedWrite({ ...effectInput, value: { count: 99 } }), /Effect input mismatch/);
    await assert.rejects(db.guardedWrite({ ...effectInput, generation: 'C1' }), /Effect input mismatch/);
    assert.deepEqual(await db.readEffect(effectInput.effectId), effectInput);
    return { waiters, publications, effects, historicalReplay: replay };
  } finally { await rollbackRelease(barrier); await settle; observer.release(); }
});

scenario('S03 attempt identity rejects changed inputs', async db => {
  const input = candidate('immutable', await db.readHead());
  const original = await db.admitAttempt(input);
  for (const changed of [
    { ...input, targetGeneration: 'C1' }, { ...input, baselineId: 'S1' },
    { ...input, expectedRevision: '1' }, { ...input, cohortDigest: 'artifact-other' },
  ]) await assert.rejects(db.admitAttempt(changed), /Attempt input mismatch/);
  assert.deepEqual(await db.observeAttempt(input.attemptId), original);
  return { original, mismatchesRejected: 4 };
});

scenario('S04 artifact ABA cannot reuse live identity revision or epoch', async db => {
  const a1 = await db.readHead();
  await db.admitAttempt(candidate('old-publication', a1, 'C1', 'artifact-C'));
  const b1 = await publish(db, 'to-B');
  const a2 = await publish(db, 'back-to-A', 'A2', 'artifact-A');
  assert.equal(a1.cohortDigest, a2.cohortDigest);
  assert.notEqual(a1.generation, a2.generation);
  assert.equal((await db.publishAttempt('old-publication')).status, 'conflict');
  await db.admitAttempt({ ...candidate('stale-revision-only', a2), expectedRevision: a1.revision });
  assert.equal((await db.publishAttempt('stale-revision-only')).status, 'conflict');
  const epochOnly = await db.guardedWrite({ ...operation('stale-epoch-only', a2), effectEpoch: a1.effectEpoch });
  const generationOnly = await db.guardedWrite({ ...operation('stale-generation-only', a2), generation: a1.generation });
  assert.equal(epochOnly.kind, 'stale');
  assert.equal(generationOnly.kind, 'stale');
  return { a1, b1, a2, labelOnlyNegativeControlWouldAccept: a1.cohortDigest === a2.cohortDigest,
    staleRevisionRejected: true, epochOnly, generationOnly };
});

scenario('S05 lost application reply reconciles same durable attempt', async db => {
  await db.admitAttempt(candidate('lost-reply', await db.readHead()));
  const controller = child('commit-no-reply', db, 'lost-reply');
  try {
    const exit = await controller.exited;
    assert.deepEqual(exit, { code: 73, signal: null });
    const restartedController = new StateFixture(db.schema);
    try {
      const selected = await restartedController.readHead();
      const durable = await restartedController.observeAttempt('lost-reply');
      assert.equal(durable?.status, 'committed');
      assert.deepEqual(durable?.result, selected);
      assert.deepEqual(await restartedController.publishAttempt('lost-reply'), durable);
      assert.equal((await restartedController.readHead()).revision, '1');
      return { exit, durable, selected, recovered: 'durable selection only; no live Worker readiness' };
    } finally { await restartedController.close(); }
  } finally { controller.process.kill('SIGKILL'); await controller.exited; }
});

scenario('S06 controller death before COMMIT rolls back native transaction', async db => {
  const original = await db.readHead();
  await db.admitAttempt(candidate('crash-before-commit', original));
  const observer = await db.client();
  const controller = child('stage-without-commit', db, 'crash-before-commit');
  try {
    const pid = await controller.staged;
    assert.deepEqual(await db.readHead(), original); // MVCC sees committed old row.
    controller.process.kill('SIGKILL');
    const exit = await controller.exited;
    assert.equal(exit.signal, 'SIGKILL');
    await until(async () => (await observer.query<{ count: string }>(
      'SELECT count(*)::text AS count FROM pg_stat_activity WHERE pid=$1', [pid],
    )).rows[0]?.count, count => count === '0', 'crashed backend disconnect');
    assert.deepEqual(await db.readHead(), original);
    assert.equal((await db.observeAttempt('crash-before-commit'))?.status, 'pending');
    const restarted = new StateFixture(db.schema);
    try {
      const outcome = await restarted.publishAttempt('crash-before-commit');
      assert.equal(outcome.status, 'committed');
      assert.equal((await db.readHead()).revision, '1');
      return { exit, backendPid: pid, original, recovered: outcome };
    } finally { await restarted.close(); }
  } finally { controller.process.kill('SIGKILL'); await controller.exited; observer.release(); }
});

scenario('S07 KEY SHARE negative control allows old effect after publication', async db => {
  const old = await db.readHead();
  const writer = await db.client();
  try {
    await writer.query('BEGIN');
    await writer.query(`SELECT * FROM ${db.sql}.head WHERE singleton FOR KEY SHARE`);
    const selected = await publish(db, 'publish-through-weak-lock');
    await writer.query(`INSERT INTO ${db.sql}.effects VALUES ($1,$2,$3::bigint,$4,$5::jsonb)`,
      ['unsafe-late', old.generation, old.effectEpoch, 'v1', '{"count":1}']);
    await writer.query('COMMIT');
    const late = await db.readEffect('unsafe-late');
    assert.equal(late?.generation, old.generation);
    assert.notEqual(late?.effectEpoch, selected.effectEpoch);
    return { selected, late, interpretation: 'negative control, not approved receiver behavior' };
  } finally { await rollbackRelease(writer); }
});

scenario('S08 SHARE fence orders old effect before new publication', async db => {
  const old = await db.readHead();
  await db.admitAttempt(candidate('wait-for-effect', old));
  const [writer, observer] = await Promise.all([db.client(), db.client()]);
  let settle: Promise<unknown> = Promise.resolve();
  try {
    await writer.query('BEGIN');
    await writer.query(`SELECT * FROM ${db.sql}.head WHERE singleton FOR SHARE`);
    const publishing = db.publishAttempt('wait-for-effect');
    settle = publishing.catch(() => {});
    const waiters = await waitForWaiters(observer, db.schema, 1);
    assert.deepEqual(await db.readHead(), old);
    await writer.query(`INSERT INTO ${db.sql}.effects VALUES ($1,$2,$3::bigint,$4,$5::jsonb)`,
      ['ordered-old', old.generation, old.effectEpoch, 'v1', '{"count":2}']);
    await writer.query('COMMIT');
    const published = await publishing;
    assert.equal(published.status, 'committed');
    assert.ok(await db.readEffect('ordered-old'));
    const stale = await db.guardedWrite(operation('late-new-effect', old));
    assert.equal(stale.kind, 'stale');
    assert.equal(await db.readEffect('late-new-effect'), null);
    return { waiters, published, stale, barrier: 'test-only held SQL transaction, no plugin callback' };
  } finally { await rollbackRelease(writer); await settle; observer.release(); }
});

function oldDecoder(value: unknown): { count: number } {
  if (typeof value !== 'object' || value === null || !('count' in value) ||
    typeof value.count !== 'number' || !Number.isSafeInteger(value.count)) throw new Error('v1 state incompatible');
  return { count: value.count };
}
function newDecoder(value: unknown): { count: number } {
  if (typeof value === 'object' && value !== null && 'countText' in value && typeof value.countText === 'string') {
    const count = Number(value.countText);
    if (!Number.isSafeInteger(count)) throw new Error('v2 state incompatible');
    return { count };
  }
  return oldDecoder(value);
}
scenario('S10 rollback requires actual current state compatibility', async db => {
  const client = await db.client();
  try {
    // Consumer-owned orchestration outside any DB transaction. This small toy
    // action is deliberately quiescent: concurrent writer admission is unproved.
    const requestRollback = async (attemptId: string): Promise<
      { kind: 'blocked'; reason: string } | { kind: 'published'; selected: Head }
    > => {
      const currentValue = (await client.query<{ value: unknown }>(
        `SELECT value FROM ${db.sql}.business_state WHERE state_key='document'`,
      )).rows[0]?.value;
      try { oldDecoder(currentValue); }
      catch (error) { return { kind: 'blocked', reason: String(error) }; }
      return { kind: 'published', selected: await publish(db, attemptId, 'A2', 'artifact-A') };
    };
    const newHead = await publish(db, 'new-writer');
    await client.query(`INSERT INTO ${db.sql}.business_state VALUES ('document', $1::jsonb)`, ['{"countText":"7"}']);
    const stored = (await client.query<{ value: unknown }>(`SELECT value FROM ${db.sql}.business_state WHERE state_key='document'`)).rows[0]?.value;
    assert.deepEqual(newDecoder(stored), { count: 7 });
    assert.throws(() => oldDecoder(stored), /v1 state incompatible/);
    const refused = await requestRollback('unsafe-rollback');
    assert.equal(refused.kind, 'blocked');
    assert.deepEqual(await db.readHead(), newHead);
    assert.equal(await db.observeAttempt('unsafe-rollback'), null);
    await client.query(`UPDATE ${db.sql}.business_state SET value=$1::jsonb WHERE state_key='document'`,
      ['{"count":8,"description":"expanded compatible field"}']);
    const expanded = (await client.query<{ value: unknown }>(`SELECT value FROM ${db.sql}.business_state WHERE state_key='document'`)).rows[0]?.value;
    assert.deepEqual(oldDecoder(expanded), { count: 8 });
    assert.deepEqual(newDecoder(expanded), { count: 8 });
    const rollback = await requestRollback('compatible-rollback');
    assert.equal(rollback.kind, 'published');
    assert.equal((await db.observeAttempt('compatible-rollback'))?.status, 'committed');
    return { stored, refused, expanded, rollback,
      limitation: 'toy consumer codecs and quiescent state; not atomic concurrent migration admission' };
  } finally { client.release(); }
});

scenario('S11 durable baseline cannot silently change after controller restart', async db => {
  const controller = child('admit-no-reply', db, 'baseline-attempt');
  const client = await db.client();
  try {
    assert.deepEqual(await controller.exited, { code: 74, signal: null });
    await client.query(`INSERT INTO ${db.sql}.snapshots VALUES ('S1', '{"count":99}')`);
    const restarted = new StateFixture(db.schema);
    try {
      const originalInput = candidate('baseline-attempt', await restarted.readHead());
      const resumed = await restarted.admitAttempt(originalInput);
      assert.equal(resumed.baselineId, 'S0');
      await assert.rejects(restarted.admitAttempt({ ...originalInput, baselineId: 'S1' }), /Attempt input mismatch/);
      const newAttempt = await restarted.admitAttempt({ ...originalInput, attemptId: 'new-baseline-attempt', baselineId: 'S1' });
      assert.equal(newAttempt.baselineId, 'S1');
      return { resumed, newAttempt };
    } finally { await restarted.close(); }
  } finally { controller.process.kill('SIGKILL'); await controller.exited; client.release(); }
});

scenario('S12 DO NOTHING CTE fallback can miss the committed winner', async db => {
  const [first, second, observer] = await Promise.all([db.client(), db.client(), db.client()]);
  let settle: Promise<unknown> = Promise.resolve();
  try {
    await first.query('BEGIN');
    await first.query(`INSERT INTO ${db.sql}.snapshot_gap VALUES ('same', 'winner')`);
    const secondPid = await backendPid(second);
    const statement = second.query<{ id: string; value: string }>(`WITH inserted AS (
      INSERT INTO ${db.sql}.snapshot_gap VALUES ('same','loser') ON CONFLICT DO NOTHING RETURNING *
      ) SELECT * FROM inserted UNION ALL SELECT * FROM ${db.sql}.snapshot_gap WHERE id='same' LIMIT 1`);
    settle = statement.catch(() => {});
    const blockers = await waitForBlock(observer, secondPid);
    await first.query('COMMIT');
    const missing = await statement;
    assert.equal(missing.rowCount, 0);
    const fresh = await second.query<{ id: string; value: string }>(`SELECT * FROM ${db.sql}.snapshot_gap WHERE id='same'`);
    assert.deepEqual(fresh.rows, [{ id: 'same', value: 'winner' }]);
    return { blockers, staleStatementRows: missing.rows, freshStatementRows: fresh.rows };
  } finally { await rollbackRelease(first); await settle; second.release(); observer.release(); }
});

scenario('S13 FK retention metadata excludes dangling canonical reference', async db => {
  const [deleter, holder, observer] = await Promise.all([db.client(), db.client(), db.client()]);
  let settle: Promise<unknown> = Promise.resolve();
  try {
    await observer.query(`INSERT INTO ${db.sql}.artifacts VALUES ('artifact-held'),('artifact-deleting')`);
    await holder.query('BEGIN');
    await holder.query(`INSERT INTO ${db.sql}.holds VALUES ('first-hold','artifact-held')`);
    const deletePid = await backendPid(deleter);
    const deletion = deleter.query(`DELETE FROM ${db.sql}.artifacts WHERE digest='artifact-held'`);
    // Attach rejection immediately so native waiting errors cannot be unhandled.
    const rejectedDeletion = assert.rejects(deletion, { code: '23503' });
    settle = rejectedDeletion.catch(() => {});
    const deleteBlockers = await waitForBlock(observer, deletePid);
    await holder.query('COMMIT');
    await rejectedDeletion;
    await deleter.query('BEGIN');
    await deleter.query(`DELETE FROM ${db.sql}.artifacts WHERE digest='artifact-deleting'`);
    const holderPid = await backendPid(holder);
    const insertion = holder.query(`INSERT INTO ${db.sql}.holds VALUES ('late-hold','artifact-deleting')`);
    const rejectedInsertion = assert.rejects(insertion, { code: '23503' });
    settle = rejectedInsertion.catch(() => {});
    const holdBlockers = await waitForBlock(observer, holderPid);
    await deleter.query('COMMIT');
    await rejectedInsertion;
    const dangling = await observer.query<{ count: string }>(`SELECT count(*)::text AS count FROM ${db.sql}.holds h
      LEFT JOIN ${db.sql}.artifacts a ON a.digest=h.digest WHERE a.digest IS NULL`);
    assert.equal(dangling.rows[0]?.count, '0');
    return { deleteBlockers, holdBlockers, danglingReferences: 0,
      limitation: 'metadata only; no physical blob deletion or runtime lease proof' };
  } finally { await rollbackRelease(holder); await rollbackRelease(deleter); await settle; observer.release(); }
});
