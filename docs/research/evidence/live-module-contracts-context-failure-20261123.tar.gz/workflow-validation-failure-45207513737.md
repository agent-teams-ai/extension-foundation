# Workflow validation failure before native execution

Run [45207513737](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45207513737) on `3b511d2a75829169c011baf3c114ec62c8c254b3` failed immediately with **zero jobs and zero native executions**. The input archive is unchanged.

The previous delivery correction placed `runner.temp` in job-level env. The official [context availability table](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#context-availability) does not permit runner there. A runtime step can use RUNNER_TEMP and export the resulting absolute paths through GITHUB_ENV before checkout/extraction.

The CI reviewer's earlier path-only approval missed this restriction and was erroneous for workflow validity. This failure remains part of the record. Exact UI validation annotation has not been retrieved; the cause above is explicitly a source-and-documentation diagnosis supported by the zero-job failure, not a fabricated quote from a job log. No job log/native observation can exist for a zero-job run.
