# Live plugin replacement: runtime mechanisms and boundaries

Research date: client 2026-11-14; primary snapshots are no later than 2026-11-13 UTC. Research lane: actual lifecycle, code/resource/state continuity, operational limits. This report is an intermediate for an existing repository, not an implementation proposal approved by the user.

**Product vision to retain:** all plugin categories should support addition, update and replacement while the application and agents remain running; agents may themselves initiate plugin changes. **Still undecided:** the mechanism and the policy for interrupting work during ordinary updates. Neither graceful draining nor stop/start is silently promoted to a requirement here.

**Decisive finding:** “every plugin live” is a meaningful product invariant if it means every logical plugin has a versioned activation/replacement path. It does not imply that arbitrary suspended JavaScript continues inside changed code. The practical systems studied preserve some boundary—an invocation, session, workflow history, resource handle, import wiring, or process—and replace code on the other side. The stronger the continuity claim, the more the plugin must participate in it.

## Findings that materially change the architecture choice

1. **Replacement of discovery is much cheaper than replacement of every active reference.** Updating a route changes future acquisition. It cannot alter closures, Java object references, Wasm resource handles, already-open RPC sessions or a model response produced against an older tool schema. A generation selected for one operation must stay coherent for the operation's chosen lifetime.
2. **Reliable cleanup has a boundary.** Cordis cleans tracked effects; OSGi cleans framework registrations; an executor can reclaim its own process/instance memory and descriptors. None thereby undoes completed remote writes. Registration rollback, runtime rollback and data rollback are distinct operations.
3. **New-first activation assumes overlap is possible.** A shared host listener with revision-specific handlers supports overlap; two plugins each binding the same exclusive port do not. A single SQLite writer, device, native singleton or account session may require handoff or stop/start. Retrying acquisition cannot solve conflicting custody.
4. **Compatibility is a product contract, not a property inferred from matching TypeScript interfaces.** A replacement can typecheck while interpreting state differently, changing tool semantics or performing irreversible side effects. Agents changing plugins makes immutable artifact identity and explicit promotion especially useful.
5. **A generic global supervisor is unnecessary.** Existing product routing/auth/state services can select revisions; GM can continue building immutable compositions; existing executors can own physical processes, files, sessions and cancellation. A small lifecycle adapter at each current executor boundary is enough to start exploring.

## Eight contrasting primary-source cases

### 1. Cordis and Koishi: tracked effects, dependency-sensitive teardown, and two different HMR generations

**What actually changes.** Koishi's documented runtime API can add/remove plugin forks; its file watcher HMR replaces plugin modules and recreates plugin instances. The lifecycle documentation explicitly requires external resources to supply disposers. Its development guide places HMR under development launch scripts, and its Loader API is explicitly experimental and CLI-specific. Therefore supported runtime plugin disabling and development source HMR should not be conflated. [R04–R07]

The current **cordiverse/cordis main snapshot** is materially more ambitious than those older Koishi mechanics. At commit `1378a9c1237b6b8c26166a7375947468454f2e95`, `packages/core/package.json` declares **`cordis` 4.0.0-rc.13**. This is a prerelease source snapshot; it is not the installed `@cordisjs/core`/Cordis dependency in another framework. Its `Hmr.reconcile(callback)` serializes transactions, rejects nested reconciliation, identifies affected module/component units, retries failed module jobs, and can follow changed package resolution. This is a callable reconciliation mechanism with optional watching, not only a development watcher. It relies on private Node loader access (`--expose-internals` or an addon). [R02]

**Where continuity ends.** Stage 1 imports and validates replacement components. Failed units have caches/resolutions restored. Stage 2 replaces registry components; stage 3 waits for fibers to settle. The implementation explicitly does **not** roll back a replacement whose activation fails: the new fiber remains `FAILED`, retaining config/parent for a future retry. Host modules, native addons, ambiguous import provenance and ambiguous exports can be skipped. Existing noncomponent references can keep the old value after cache eviction. Import-cache restoration also cannot reverse arbitrary top-level side effects; this last point is an inference from what the transaction restores. [R02]

**Cleanup precision.** `Fiber._unload()` waits for dependent scopes before provider effects are disposed. Independent disposers start in reverse registration order but run concurrently; errors are logged and other disposers proceed. An effect iterator sequences cleanup inside that effect. A failing or never-resolving disposer can still leak a real resource or prevent progress; the code does not turn arbitrary JS into reclaimable isolated work. Disposal tests cover idempotence and async initialization/aborted generators, not universal request drain. [R01, R03]

**Transferable mechanism:** bind all registrations and resources to a revision scope; invalidate dependents deliberately; report failed activation separately from import failure. **Do not copy blindly:** Node internal loader manipulation, a full dependency-reconciliation engine, or a promise of automatic state/side-effect rollback.

Pins: [Fiber lifecycle](https://github.com/cordiverse/cordis/blob/1378a9c1237b6b8c26166a7375947468454f2e95/packages/core/src/fiber.ts), [current Hmr.reconcile](https://github.com/cordiverse/cordis/blob/1378a9c1237b6b8c26166a7375947468454f2e95/packages/hmr/src/index.ts), [Koishi HMR](https://github.com/koishijs/koishi/blob/97d5c395750cec37b772e0b94dc63c427e3bb868/plugins/hmr/src/index.ts).

### 2. OSGi and Apache Felix: live bundles are not universally rewired callers

**What actually changes.** OSGi bundle update creates a new revision and stops/restarts an active bundle. Existing class-loading wires remain attached to the old revision. Refresh computes the transitive dependent closure, stops active members, resolves new wires and restarts them. This explicitly trades stable existing linkage against a larger refresh interruption. [R08–R09]

**Cleanup and stale references.** OSGi services are dynamic registrations with events; ServiceTracker/Declarative Services help consumers follow them. The specification says ordinary stale Java object references cannot be generically removed. After unregistering a service, behavior of a retained service object is undefined: it may still work or throw. A service registry's usage count is not by itself a transparent invocation lease that prevents resource closure. [R10]

**Implementation check.** Felix `updateBundle` stops the active bundle, revises it, marks it updated, and restarts it. `rollbackRevise` exists in a limited verification failure path; that is not a transaction over every activation effect. `stopBundle` invalidates the context, unregisters provided services, releases consumed services and removes listeners even when activator stop throws, then reports the exception. Ordinary plugin threads, sockets and other objects still require plugin cooperation. [R11]

**Transferable mechanism:** distinguish revision identity from current activation, retain old dependencies while clients require them, and define the refresh blast radius. **Avoid importing:** the whole OSGi resolver/classloader model into TS solely for hot replacement. A small product route with revision-scoped acquisition can express the needed boundary.

Pins: [OSGi Core 8 wiring](https://docs.osgi.org/specification/osgi.core/8.0.0/framework.wiring.html), [stale-reference contract, §5.7](https://docs.osgi.org/specification/osgi.core/8.0.0/framework.service.html), [Felix implementation](https://github.com/apache/felix-dev/blob/286739e356c69badf698f0f735b30607bec4f25e/framework/src/main/java/org/apache/felix/framework/Felix.java).

### 3. Erlang/OTP: genuine hot code changes still require safe points and explicit state conversion

**What actually changes.** Erlang allows current and old module code concurrently. A fully qualified call enters current code; local calls can remain on old code. Loading a third generation can purge the oldest and terminate processes still using it. `on_load` can validate before a new current module becomes callable; failure preserves the previous current module. This is actual runtime code switching, but not arbitrary replacement of an executing instruction or closure. [R12]

**State and work.** OTP synchronized replacement suspends relevant behavior processes, calls application-written `code_change`, and resumes them. `.appup`/`relup` scripts encode upgrade and downgrade steps. Other processes remain active; ordering and newly created processes can still cause timeouts and incompatibilities. Runtime/core upgrades may require reboot. Release installation failure can fall back by rebooting into the previous release. [R13]

**Implementation check.** OTP-29.1.2 `release_handler_1.erl` separates instructions around `point_of_no_return`, collects supervised processes for suspension, invokes `sys:change_code` only for the relevant suspended processes, propagates conversion errors, and explicitly purges lingering old-code processes when instructed. A generic “rollback keeps every task untouched” interpretation is false. [R14]

**Transferable mechanism:** explicit state schema plus a checkpoint/safe-point protocol can enable hot upgrade of long-running agents. The protocol has to be designed into the agent state machine. This is a substantially different project from switching tool implementations between invocations; Node does not acquire BEAM semantics by adding a disposer.

Pins: [OTP module switching](https://www.erlang.org/doc/system/code_loading.html), [release model](https://www.erlang.org/doc/system/release_handling.html), [OTP-29.1.2 implementation](https://github.com/erlang/otp/blob/d199a49a01a2079afb6f2c5c9ae047cd4555e68d/lib/sasl/src/release_handler_1.erl).

### 4. Extism and the Wasm Component Model: strong instance and capability boundaries, no automatic state upgrade

**What actually changes.** Extism constructs plugin instances from compiled modules; replacement is naturally instantiate-new, route future calls, then free-old. The inspected `Plugin::call` takes a mutable plugin and guards against reentrant calls. Concurrency is obtained through multiple instances. The C API explicitly creates/frees instances. A runtime reset rebuilds state from the same module set; it does not replace code. [R15–R16, R18]

**What stays pinned.** A call executes within its selected instance. Extism-managed exchange memory is cleared between calls, and borrowed output bytes are invalidated on the next call. This must not be misread as a guarantee that every guest-language global is reset. Host functions and optional WASI determine available capabilities; an instance pool does not isolate shared host data unless the host makes it so. [R15, R17–R18]

**Cleanup/failure.** Epoch interruption/timeouts and instance dropping provide useful bounds on guest execution and memory lifetime. They do not reverse remote writes made by host functions; interruption of a blocking host call needs separate host/runtime behavior. Do not claim that killing an instance invokes all application-level cleanup successfully. Failed construction can leave the old instance selected if publication is separate; that is an architecture option, not an Extism-provided deployment transaction. [R15–R16; last sentence is inference]

The Component Model adds typed linking and explicit resource ownership. `own` handles transfer ownership; `borrow` constrains lifetime across a call; resources live in per-component-instance handle tables with destructors. A saved resource handle is therefore not a portable state snapshot for a replacement component. The model gives useful interface/lifetime discipline, not a universal hot-upgrade protocol. [R19]

**Transferable mechanism:** use opaque resource IDs and host-mediated operations, serialize durable plugin state separately, and make execution units disposable. **Prerequisite for adoption:** the desired Node ecosystem and host APIs must fit the Wasm boundary; replacing arbitrary npm/native plugins with Wasm is a port, not a loader change.

Pins: [Extism Plugin implementation](https://github.com/extism/extism/blob/051b765bb6abe4fe95d5e4f489f03ad7b137edbc/runtime/src/plugin.rs), [C API](https://github.com/extism/extism/blob/051b765bb6abe4fe95d5e4f489f03ad7b137edbc/runtime/src/sdk.rs), [Component Model resources](https://github.com/WebAssembly/component-model/blob/dd1fefc0c618382359feca6f2c758a2b3ef21c36/design/mvp/Explainer.md).

### 5. Cloudflare Dynamic Workers and Facets: immutable code identity, and explicit restart of stateful instances

**Maturity:** published cloud-platform capability, introduced in open beta on 2026-03-24; current GA status was not verified. Documentation publication and a branch named `production` do not establish GA or an SLA. This is separate from the experimental self-modifying harness example.

**What actually changes.** `load(code)` creates a new worker each time. `get(id, callback)` caches by ID, and the official contract requires identical complete `WorkerCode` content for a reused ID. Changing code/config means a new ID, commonly a version or digest. Even requests through the same stub are not guaranteed to reach the same isolate. A cache key is not a stable heap or upgradeable singleton. [R20]

**Capabilities.** Explicit bindings can wrap storage and service operations with host-owned authorization. `globalOutbound: null` blocks network; omission inherits parent access. This is useful when an agent writes code dynamically: new code does not need to receive the product's raw state stores or credentials. [R20, R22]

**Stateful case.** Facets separate stable named SQLite state from the dynamically supplied class. `facets.get(name, callback)` reuses a running facet and does not invoke a new callback. The documented update is `abort(name, reason)` followed by `get` with the new class. Abort invalidates old stubs and preserves the database; delete also removes the database. This is a supported restart-with-state boundary, not a documented transparent continuation of old in-flight calls. Incompatible database schema still needs application migration. [R21; schema statement is inference]

**Failure/rollback.** Keep immutable old code IDs if rollback is wanted. A pointer can choose old code for future stateless calls, but it cannot undo writes or automatically restore a facet's old schema. The docs inspected establish no general atomic drain-and-replace guarantee for facets; do not invent it.

**Transferable mechanism:** immutable revision IDs, host-mediated capabilities and durable state outside disposable code. Cloudflare's example calls its parent Durable Object a “supervisor”; that is a provider-specific existing custody boundary, not evidence that this product needs a new universal supervisor service.

Pins: [Worker Loader API](https://github.com/cloudflare/cloudflare-docs/blob/f7388b9513672d30263e7e04eaaf087a3b06a0c1/src/content/docs/dynamic-workers/api-reference.mdx), [Facet update contract](https://github.com/cloudflare/cloudflare-docs/blob/f7388b9513672d30263e7e04eaaf087a3b06a0c1/src/content/docs/dynamic-workers/usage/durable-object-facets.mdx).

### 6. Envoy: overlap and drain with listening-socket handoff

**What actually changes.** A new process fully initializes, then gets copies of listening sockets and begins accepting. The old process drains existing connections. Those connections are not transferred to the new process and may be terminated at parent shutdown. Independent drain and shutdown deadlines matter. Listener socket options cannot change through this hot-restart path; lowering concurrency can drop connections in old accept queues. [R23]

**Implementation check and failure.** The pinned implementation has explicit listener duplication, drain and parent-termination operations and validates the shared-memory protocol layout. The official Python restarter example starts generations on SIGHUP, but on abnormal child exit it kills all child processes. This sample is not proof of automatically keeping an old healthy process after a new generation fails. [R24–R25]

**Transferable mechanism:** keep physical listener custody below the changing plugin, publish only after readiness, and retain old execution for bounded draining when policy permits. Existing executors can do this locally. It does not require a new global controller, nor does it preserve arbitrary language heap state.

Pins: [Envoy v1.40.2 contract](https://www.envoyproxy.io/docs/envoy/v1.40.2/intro/arch_overview/operations/hot_restart), [implementation](https://github.com/envoyproxy/envoy/blob/b2d89e0ae53916f28770771fbdd49c5c99c5c5a2/source/server/hot_restart_impl.cc), [official restarter example](https://github.com/envoyproxy/envoy/blob/b2d89e0ae53916f28770771fbdd49c5c99c5c5a2/restarter/hot-restarter.py).

### 7. systemd: separate descriptor custody from process lifetime

**What actually changes.** A service restart is stop followed by start. Socket activation can leave the listening socket owned by the existing manager while service code changes. Services must understand the inherited-descriptor protocol. The optional FD store can retain sockets and other descriptors; serialized state may live in a file or memfd. Preserving descriptors does not preserve an application heap, parser state, transaction semantics or arbitrary suspended work. [R26–R27]

**Implementation check.** In pinned v258, `service_add_fd_store` enforces store bounds and installs polling; `service_collect_fds` includes stored descriptors in the next process launch; FDSTORE messages explicitly add/remove entries. Preservation modes and HUP/error events determine release. The feature is concrete resource custody, not an application-state migration system. [R28]

**Transferable mechanism:** a plugin can be completely replaced while an existing executor retains exclusive physical resources. The plugin receives a scoped capability/reference; replacement changes who uses it, not who owns the OS endpoint. This is often simpler than resource-transfer logic inside every plugin. Platform scope matters: this is a Linux/systemd pattern, not a portable requirement to add systemd to a Node product.

Pins: [systemd v258 service manual](https://github.com/systemd/systemd/blob/781d9d0789379d1ea1f2ecefb804d41e9c8b6c38/man/systemd.service.xml), [concrete descriptor store](https://github.com/systemd/systemd/blob/781d9d0789379d1ea1f2ecefb804d41e9c8b6c38/src/core/service.c).

### 8. Temporal: keep execution on immutable code versions; change admission separately

**What actually changes.** Deployment name plus Build ID identifies worker code. Current/ramping selection directs new workflows and auto-upgrade workflows; pinned workflows keep their selected deployment version. Old workers remain while their pinned workflows drain. Auto-upgrade requires replay-safe code; pinning avoids needing every old execution to accept new logic. Continue-as-new and child inheritance rules can keep old versions alive longer than expected. [R29, R31]

**Rollback precision.** Reverting current/ramping selection stops new admissions to a bad version. Existing pinned workflows stay there until explicitly recovered. The official recovery runbook distinguishes replay-safe version overrides from history reset-and-move; corrupted critical state may need out-of-band compensation. Resetting closed executions repeatedly is not idempotent. “Instant rollback” in rollout descriptions is therefore a routing promise, not universal erasure of previous execution. [R30]

**Transferable mechanism:** choose a short stable execution boundary—tool call, model turn, task or session—and record the revision there. For long workflows, retain the old implementation or provide a checkpoint/replay migration protocol. Temporal is evidence for that pattern, not a recommendation to add a durable workflow engine solely for plugin reloading.

Pins: [versioning model](https://github.com/temporalio/documentation/blob/ce2b620285f5f2ff5dbcbc7b26209111cad274fb/docs/encyclopedia/workers/worker-versioning.mdx), [recovery contract](https://github.com/temporalio/documentation/blob/ce2b620285f5f2ff5dbcbc7b26209111cad274fb/docs/production-deployment/worker-deployments/recover-pinned-workflows.mdx).

## Minimal future-friendly shape for this Node/TS product

This is a candidate shape, conditional on the user choosing its semantics; it is not an approved architecture. It uses boundaries the product already owns.

| Responsibility | Existing owner | Minimal added contract |
|---|---|---|
| Bind executable artifact identity and requested permissions | Existing EF/product artifact and trust owner | Admit immutable code/import identity and bind supplied factories to it |
| Validate/build closed plugin composition from supplied factories | GM | Return the verified composition and typed construction capability; do not own artifact trust, loading or product generation identity |
| Decide whose plugin changes and who can invoke it | Product authorization | Authorize revision activation against current identity/policy |
| Select implementation for new work | Product routing | Logical plugin ID resolves to immutable revision plus capability/schema descriptor |
| Acquire/release live implementation | Existing executor or adapter | One operation/session acquires one selected revision and releases it at its declared boundary |
| Hold files/processes/listeners/sessions | Existing physical executor | Keep custody or explicitly hand it off according to the resource's own rules |
| Durable state and migration policy | Product/state owner | Schema/version contract; no opaque arbitrary-heap migration promise |

An immutable revision is more useful than a mutable module name. Its identity should cover code plus relevant composition/config, or refer to another immutable descriptor that does. Promotion should compare against the revision the agent intended to replace so concurrent agent changes do not silently overwrite each other. A product can serialize promotions per logical plugin without inventing a system-wide lifecycle manager.

A prepared candidate can be validated before activation. That only preserves the old implementation if validation does not take its exclusive resource or irreversibly mutate shared state. Preparation may consist of compilation/schema checks and construction of inert descriptors, with actual exclusive activation delayed until handoff. Readiness should be reported as readiness, not inferred from successful module import.

The runtime operation can conceptually be “prepare candidate, authorize/publish selected revision, retire old revision”; exact APIs can remain private to the existing services. There is no reason to standardize a giant universal plugin object now. Record outcomes such as candidate rejected, selected, draining, activation failed and cleanup failed where they are operationally meaningful. A stale retire/cleanup completion must never remove a newer revision's route.

**Agent-specific consistency:** a model may emit a tool call based on a schema/catalog retrieved earlier. The product must either pin that descriptor for a turn/session or explicitly reject/re-resolve a stale descriptor. Looking up “latest” only at execution time can execute a different contract than the model selected. Revision identity should remain visible in audit/events even if the UI shows only a logical plugin name. Pinning code does not pin authorization: the product can still check current grants or revoke admission according to its existing policy. Selecting and retaining a generation must form one acquisition step before asynchronous work, so promotion cannot retire a just-selected resource in between.

**Direct Node limitations:** deleting `require.cache` affects future requires and does not support reloading native addons. ESM has a separate cache; query-string identities produce distinct modules, not a specified complete disposal protocol. Process/worker/isolated executor replacement is a cleaner reclamation boundary than indefinite URL-cache busting. Node worker threads have separate engine limits but still share process-level failure risks and are not by themselves a hostile-tenant security sandbox. [R32–R34]

## Interruption policy is a separate product decision

| Conditional policy | What remains live | What may pause or fail | Conditions |
|---|---|---|---|
| Targeted stop/start | App and unrelated agents/plugins | Calls needing this plugin while it switches; possibly its active work | Simplest for exclusive resources; define queue/retry/error behavior |
| New calls switch; old calls finish | App and selected old operations | Never-ending calls prevent retirement unless policy bounds them | Overlap allowed; invocation-scoped resource retention; capacity for both |
| Existing tasks/sessions pin old revision | Entire selected sessions/tasks | Old versions may persist for hours/days | Explicit retention, revocation and compatibility policy |
| Checkpoint and resume on new code | Durable semantic task state | A checkpoint pause and incompatible migrations | Serializable state machine, migrators, replay/idempotency contracts |
| Cancel/retry on replacement | App and agents as orchestration entities | Current plugin operation is interrupted/retried | Cancellation and external-effect semantics must make retry acceptable |

These policies can coexist by plugin/resource category while every category has a supported live lifecycle. “All plugins live” need not force all resources into the same overlap mechanism. Conversely, claiming “the agents keep running” is weaker than claiming “every operation continues without interruption”; the product should state which one it promises.

## Conditional effort bands and qualitative ratings

Estimates below are **conditional mechanism-only TypeScript LOC budgets**, not delivery estimates or quotes for this repository. They were formed before the sibling lane established the current reusable kernel/native-lease inventory. They cannot be presented as the cost of the recommended current-Host path. They exclude plugin bodies, UI/marketplace/package installer, general authorization system, distributed consensus, data-specific migrations and third-party runtime code. Existing GM, state/auth/routing and executor services are prerequisites. Bands are deliberately disjoint hypothetical alternatives; do not sum them. P denotes newly implemented mechanism code; I denotes one-product integration; T denotes meaningful tests. Only hypothetical P is estimated in this table. I, T and changed-existing LOC are unestimated here. Rating scales: complexity 10 is hardest; reliability 10 is a qualitative judgment about the explicitly named guarantee under its prerequisites; confidence 10 is strongest evidence/estimate confidence. These are not measured availability scores.

| Alternative, if prerequisites hold | Hypothetical P LOC; I/T unestimated | Complexity /10 | Reliability /10 | Confidence /10 | Named guarantee and prerequisites |
|---|---:|---:|---:|---:|---|
| A. Existing executor already exposes immutable versions, lifetime and disposal; add selection mechanism only | 120–280 | 2 | 8 | 6 | Coherent revision selection for new calls; calls already cross a typed dispatch boundary; no new resource lifecycle or migrations |
| B. Trusted in-process factories; a missing targeted stop/start mechanism | 400–800 | 4 | 7 | 6 | Targeted replacement with accounted cleanup; scope-owned effects, bounded cooperative teardown, no hostile/native code; brief plugin unavailability accepted |
| C. Hypothetical adapter lacking promotion/retirement and borrower accounting | 1,000–1,900 | 6 | 8 | 4 | Old resource retained through its invocation and coherent new admission; overlap allowed, shared state compatible. This budget is withdrawn for the current native GM/Host path because kernel/scoped accounting already exists |
| D. One missing process/RPC or sandbox executor adapter plus routing/readiness/retirement mechanism | 2,400–4,200 | 7 | 9 | 5 | Reclamation/fault containment of disposable execution unit; existing infrastructure/transport, serializable API, external state; no generalized multi-runtime orchestrator |
| E. Missing generic durable checkpoint/migration mechanism | 5,000–9,000 | 9 | 6 | 3 | Semantic task resume at declared checkpoint; existing durable state machine/replay substrate; excludes each data migration and product integration |

**Reuse correction:** the existing 135-line lifecycle-kernel core and native Scope/RcRef ownership/borrower primitives count as **zero new LOC**. No duplicate phase table or borrower counter is proposed. A literal subtraction of 135 from a speculative broad band would create false precision. For the actual already-native route, replace C with the sibling Effect lane’s narrower current-Host P/I estimate (180–450 new combined production/integration LOC, tests separately 550–1,000); do not add that estimate to this table. Changed code and full product/provider cost remain unaudited.

A vs B is not a universal claim that stop/start costs more than routing. It reflects whether lifetime support already exists. D's higher reliability applies to fault/resource isolation for disposable workers; RPC retries and external effects still need product semantics. E is less reliable until actual task/state invariants are proven. A generic in-process module graph rewriter plus arbitrary live state conversion cannot responsibly be assigned a small finite band from this research; it is outside these bounded alternatives.

## Modest discriminating spikes, with independent oracles

Do not run a bespoke toy “hot swap” and then cite its self-authored tests as proof. Each useful spike should falsify one real boundary using the actual runtime/executor/resource. None was executed in this research lane.

1. **Native scope/lease semantics (coordinated with Effect research lane).** Hold a real FileHandle through a Deferred barrier while replacing native ScopedRef; confirm the handle is usable before and EBADF after closure. Fail candidate acquisition after opening a real handle; independently verify candidate closed and old still usable. Defect old finalization after close; inspect Cause and actual current object/resource state. Invalidate native RcRef while an existing borrow is live; acquire a new borrow afterward and verify old stays usable until its scope closes. These four cases distinguish native immediate replacement from scoped retention. They do not prove routing/publication or migration.
2. **The product's actual most important executor boundary.** With a long bounded invocation on revision A, prepare B, promote once and start a second invocation. Independently identify code revision and underlying real resource in both results; assert A's resource closes only at the policy-selected boundary. A failed B readiness check must leave A selected. Include one stale retire callback after a later promotion. Stop if the existing executor already gives this contract unambiguously.
3. **One exclusive resource the product truly needs.** Use its actual listener/device/SQLite owner, not an artificially exclusive counter. Determine whether the existing executor can retain custody while handlers change. If it cannot, document the measured pause or required handoff, rather than forcing overlap into a generic API.
4. **Actual descriptor/schema skew.** Capture the real agent tool descriptor at revision A, promote an incompatible B, then submit an A-shaped call. The independent oracle is that A executes, or the product rejects the stale descriptor explicitly; successful accidental dispatch to B is failure. This decides turn/session pinning and is likely more valuable than another module-cache benchmark.
5. **Only if durable migration is chosen:** run one representative real task across an incompatible state schema change and crash at the persistence/promotion boundary. Verify committed external effects independently. A fake counter migration cannot validate an agent workflow's replay semantics.

Suggested order is 1 (already being evaluated in the sibling lane), 4, then 2/3 against the executor actually selected. Defer 5 until the product chooses durable migration continuity. A package ecosystem feasibility spike may precede D if Wasm/isolate constraints would exclude required Node/native APIs.

## Uncertainty and claims deliberately not made

- Main-branch source pins are inspection evidence, not support or stability commitments. Cordis prerelease source is separated from Koishi runtime docs and any separately installed older Cordis dependency.
- No third-party plugins or untrusted code were executed; no deployment or external write occurred. There are no empirical throughput, pause or leak measurements in this lane.
- Cloudflare docs establish ID/cache/facet abort contracts; they do not establish uninterrupted migration of current facet requests. Extism docs and source establish instance/call ownership; they do not establish rollback of host side effects.
- OSGi/Felix, Erlang and Envoy are architectural precedents, not dependencies this product must adopt. Their guarantees do not automatically transfer to a Node implementation.
- LOC bands depend strongly on existing executor/lifetime support; they should be recalibrated against the actual repository after choosing the desired continuity boundary.
- Promotion rollback is not state rollback. The old code can be available but unable to read a newly migrated database or safely repeat an external operation.

## Краткие выводы по-русски

- Видение «все плагины добавляются и заменяются на живой системе, в том числе по инициативе агентов» технически осмысленно. Оно требует стандартного жизненного цикла ревизий, но не означает перенос произвольного приостановленного JavaScript в новый код.
- Механизм и допустимость прерывания обычной работы пока не выбраны. Stop/start отдельного плагина, дренирование вызовов и закрепление версии на задачу — разные допустимые политики, а не обязательная последовательность усложнения.
- Минимальная граница: GM строит неизменяемую композицию; продукт выбирает и авторизует ревизию; существующий исполнитель держит процессы, файлы, сокеты и сессии. Новый глобальный supervisor для этого не нужен.
- Самая важная развилка — ресурс допускает одновременное существование старой и новой версии или требует эксклюзивного владения. Для эксклюзивного ресурса нужны передача владения, сохранение ресурса у исполнителя или локальная пауза.
- Актуальный Cordis HMR существенно интереснее обычного file watcher, но новая активация после ошибки не откатывается автоматически: fiber остаётся FAILED. Это prerelease source-main, не гарантия установленной зависимости.
- Cloudflare требует нового immutable ID при смене кода/конфига; для stateful facet официальный путь — abort и повторный get с сохранением SQLite. Temporal закрепляет старую версию за workflow. Envoy оставляет старые соединения в старом процессе до завершения или принудительного закрытия.
- В первую очередь стоит проверить настоящие scope/lease-примитивы, рассогласование схемы инструмента у агента и реальную границу выбранного исполнителя. Искусственный «hot swap» с тестами на собственную обёртку этих вопросов не решает.

## Evidence files

`primary-source-ledger.json` contains 34 primary-source records with URLs, exact repository commits, inspected symbols/line regions, paraphrased claims and source-file SHA-256 hashes. The research used full source only transiently; external source copies were removed. Round1 corrections distinguish Cloudflare published capability from unverified GA, keep artifact identity outside GM, name rating guarantees, and withdraw the broad C band for the current native integration after reuse discovery. Source IDs in this report map directly to that ledger.
