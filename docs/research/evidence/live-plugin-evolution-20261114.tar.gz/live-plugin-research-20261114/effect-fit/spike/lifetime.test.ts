import assert from "node:assert/strict";
import { mkdtemp, open, rm, writeFile, type FileHandle } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { Cause, Deferred, Effect, Exit, Fiber, RcRef, Scope, ScopedRef } from "effect";

async function fixture() {
  const directory = await mkdtemp(join(tmpdir(), "effect-live-lifetime-"));
  const filename = join(directory, "resource.txt");
  await writeFile(filename, "alive");
  const events: string[] = [];
  const handles = new Map<string, FileHandle>();
  const acquire = (name: string, afterClose: Effect.Effect<void> = Effect.void) =>
    Effect.acquireRelease(
      Effect.promise(async () => {
        const file = await open(filename, "r");
        handles.set(name, file);
        events.push(`acquire:${name}`);
        return file;
      }),
      file => Effect.gen(function* () {
        yield* Effect.promise(async () => { await file.close(); events.push(`close:${name}`); });
        yield* afterClose;
      }),
    );
  return {
    events, handles, acquire,
    cleanup: () => rm(directory, { recursive: true, force: true }),
    report: (name: string) => console.log(JSON.stringify({ scenario: name, events })),
  };
}

async function alive(file: FileHandle) {
  const bytes = Buffer.alloc(5);
  const result = await file.read(bytes, 0, bytes.length, 0);
  assert.equal(result.bytesRead, 5);
  assert.equal(bytes.toString(), "alive");
}
const closed = async (file: FileHandle) => { await assert.rejects(file.stat(), { code: "EBADF" }); };
const once = (events: string[], item: string) => assert.equal(events.filter(event => event === item).length, 1);

test("ScopedRef replacement closes a resource retained by an active borrowing call", { timeout: 10000 }, async () => {
  const f = await fixture();
  try {
    await Effect.runPromise(Effect.scoped(Effect.gen(function* () {
      const closing = yield* Deferred.make<void>();
      const allowClose = yield* Deferred.make<void>();
      const holdFinalizer = Deferred.succeed(closing, undefined).pipe(Effect.andThen(Deferred.await(allowClose)));
      const ref = yield* ScopedRef.fromAcquire(f.acquire("old", holdFinalizer));
      const borrowed = yield* Deferred.make<void>();
      const proceed = yield* Deferred.make<void>();
      const borrower = yield* Effect.gen(function* () {
        const file = yield* ScopedRef.get(ref);
        yield* Effect.promise(() => alive(file));
        f.events.push("borrower:old-alive");
        yield* Deferred.succeed(borrowed, undefined);
        yield* Deferred.await(proceed);
        yield* Effect.promise(() => closed(file));
        f.events.push("borrower:old-EBADF");
      }).pipe(Effect.forkScoped);
      yield* Deferred.await(borrowed);
      const changing = yield* ScopedRef.set(ref, f.acquire("new")).pipe(Effect.forkScoped);
      yield* Deferred.await(closing);
      const duringClose = yield* ScopedRef.get(ref);
      assert.equal(duringClose, f.handles.get("old"));
      yield* Effect.promise(() => closed(duringClose));
      f.events.push("reader:during-set-old-EBADF");
      yield* Deferred.succeed(allowClose, undefined);
      yield* Fiber.join(changing);
      f.events.push("set:complete");
      const current = yield* ScopedRef.get(ref);
      assert.equal(current, f.handles.get("new"));
      yield* Effect.promise(() => alive(current));
      yield* Deferred.succeed(proceed, undefined);
      yield* Fiber.join(borrower);
    })));
    assert.deepEqual(f.events, ["acquire:old", "borrower:old-alive", "acquire:new", "close:old", "reader:during-set-old-EBADF", "set:complete", "borrower:old-EBADF", "close:new"]);
    f.report("scoped-ref-retained-borrower");
  } finally { await f.cleanup(); }
});

test("ScopedRef typed candidate acquisition failure preserves old resource and releases partial candidate", { timeout: 10000 }, async () => {
  const f = await fixture();
  const failure = { _tag: "CandidateAcquireFailure" } as const;
  try {
    await Effect.runPromise(Effect.scoped(Effect.gen(function* () {
      const ref = yield* ScopedRef.fromAcquire(f.acquire("old"));
      const old = yield* ScopedRef.get(ref);
      const exit = yield* Effect.exit(ScopedRef.set(ref, f.acquire("partial").pipe(Effect.andThen(Effect.fail(failure)))));
      assert.ok(Exit.isFailure(exit));
      assert.deepEqual(exit.cause.reasons.filter(Cause.isFailReason).map(reason => reason.error), [failure]);
      assert.equal(Exit.hasDies(exit), false);
      assert.equal(Exit.hasInterrupts(exit), false);
      assert.equal(yield* ScopedRef.get(ref), old);
      yield* Effect.promise(() => alive(old));
      assert.equal(f.events.includes("close:old"), false);
      const partial = f.handles.get("partial");
      assert.ok(partial);
      yield* Effect.promise(() => closed(partial));
      f.events.push("failure:old-preserved");
    })));
    assert.deepEqual(f.events, ["acquire:old", "acquire:partial", "close:partial", "failure:old-preserved", "close:old"]);
    f.report("scoped-ref-acquisition-failure");
  } finally { await f.cleanup(); }
});

test("ScopedRef finalizer defect retains exact defect but leaves current pointing at the closed old value", { timeout: 10000 }, async () => {
  const f = await fixture();
  const defect = new Error("old-finalizer-defect-after-physical-close");
  try {
    await Effect.runPromise(Effect.scoped(Effect.gen(function* () {
      const ref = yield* ScopedRef.fromAcquire(f.acquire("old", Effect.die(defect)));
      const old = yield* ScopedRef.get(ref);
      const exit = yield* Effect.exit(ScopedRef.set(ref, f.acquire("candidate")));
      assert.ok(Exit.isFailure(exit));
      assert.deepEqual(exit.cause.reasons.filter(Cause.isDieReason).map(reason => reason.defect), [defect]);
      assert.equal(Exit.hasFails(exit), false);
      assert.equal(Exit.hasInterrupts(exit), false);
      assert.equal(yield* ScopedRef.get(ref), old);
      yield* Effect.promise(() => closed(old));
      const candidate = f.handles.get("candidate");
      assert.ok(candidate);
      yield* Effect.promise(() => closed(candidate));
      f.events.push("defect:old-current-closed-and-candidate-closed");
      console.log(JSON.stringify({ scenario: "scoped-ref-finalizer-defect-cause", reasons: exit.cause.reasons.map(reason => ({ tag: reason._tag, message: Cause.isDieReason(reason) && reason.defect instanceof Error ? reason.defect.message : undefined })) }));
    })));
    once(f.events, "close:old");
    once(f.events, "close:candidate");
    f.report("scoped-ref-finalizer-defect");
  } finally { await f.cleanup(); }
});

test("RcRef invalidation preserves an active scoped borrower while the next borrower gets a fresh resource", { timeout: 10000 }, async () => {
  const f = await fixture();
  let generation = 0;
  try {
    await Effect.runPromise(Effect.scoped(Effect.gen(function* () {
      const ref = yield* RcRef.make({ acquire: Effect.suspend(() => f.acquire(`generation-${++generation}`)) });
      const scopeA = yield* Scope.make();
      const scopeB = yield* Scope.make();
      yield* Effect.addFinalizer(() => Scope.close(scopeB, Exit.void));
      yield* Effect.addFinalizer(() => Scope.close(scopeA, Exit.void));
      const old = yield* RcRef.get(ref).pipe(Scope.provide(scopeA));
      yield* Effect.promise(() => alive(old));
      f.events.push("borrowA:old-alive");
      yield* RcRef.invalidate(ref);
      f.events.push("invalidate:complete");
      const current = yield* RcRef.get(ref).pipe(Scope.provide(scopeB));
      assert.notEqual(current, old);
      assert.equal(generation, 2);
      yield* Effect.promise(async () => { await alive(old); await alive(current); });
      assert.equal(f.events.some(event => event.startsWith("close:")), false);
      f.events.push("both:alive");
      yield* Scope.close(scopeA, Exit.void);
      yield* Effect.promise(async () => { await closed(old); await alive(current); });
      f.events.push("borrowA:closed-borrowB:alive");
      yield* Scope.close(scopeB, Exit.void);
      yield* Effect.promise(() => closed(current));
    })));
    assert.deepEqual(f.events, ["acquire:generation-1", "borrowA:old-alive", "invalidate:complete", "acquire:generation-2", "both:alive", "close:generation-1", "borrowA:closed-borrowB:alive", "close:generation-2"]);
    once(f.events, "close:generation-1");
    once(f.events, "close:generation-2");
    f.report("rc-ref-scoped-lease-invalidation");
  } finally { await f.cleanup(); }
});
