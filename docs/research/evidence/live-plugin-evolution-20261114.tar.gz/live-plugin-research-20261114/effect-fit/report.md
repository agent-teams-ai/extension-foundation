# Native Effect fit for live plugin replacement

Research date requested by owner: 2026-11-14. Retrieval used exact GitHub commits, not a moving checkout. This is a bounded architecture study and four-scenario resource experiment, not a production adoption, a registry release check, or a new plugin runtime implementation.

## Research conclusion

`@get-modular/effect` is useful for constructing and owning each plugin generation with real Effect Layers, typed construction failures, native cancellation and scoped finalization. It does not mutate a running dependency graph, redirect previously injected objects, choose a generation for a new invocation, or decide when existing agents must stop. The useful design is a closed composition per generation and an existing product Host that selects a generation at an explicit operation/session boundary.

Effect can materially reduce the amount of correct resource and concurrency machinery that such a Host must implement. In particular, Effect 4.1.4 has real scoped borrowing through `RcRef`; there is no need to invent a second native resource reference counter. Get Modular already has a separate synchronous lifecycle-kernel candidate for generation/call/custody facts; there is no need to recreate its state machine either. Both mechanisms remain subordinate to the same existing Host: native scopes own physical resource finalization, while the kernel records invocation authority and retained obligations. Neither becomes a second global lifecycle owner.

The important counterexample is `ScopedRef`. It is not, by itself, a graceful live plugin handover. On the qualified installed Effect 4.1.4, a replacement closes the previous resource before publishing the replacement. A concurrent reader can obtain the old already-closed resource while the setter is still finalizing it. A retained old capability is not a lease. Four real FileHandle tests confirm both this limitation and the narrower useful guarantee of `RcRef`.

All plugin categories can be designed for future live changes without promising that all categories have identical switching semantics. Short calls, agent turns, long streams, background subscriptions, exclusive resources and stateful providers require explicit boundaries. The first implementation can prove one bounded category while the architecture standard applies to every category. This does not require restricting the eventual ecosystem to that first category. Retention through completion is conditional on selecting a continuity policy; the owner has not ruled out cancellation, a local pause, stop/start or checkpoint migration during ordinary updates.

## Exact subjects and availability

| Subject | Exact identity | What is established |
| --- | --- | --- |
| Fresh Get Modular main | `6c91ff1c3c8ce7088db215af9705f7ee3a9db103` | GitHub branch resolved to this commit. Its parent is PR 240's squash commit. Selected source files are retained and their Git blobs verified. |
| PR 240 | reviewed head `4b187b0d831347d640b79dbd670b120bd2144460`; merge `28500bb686d1b91428bd5d7a9e1d26ce3d4ac839`; merged `2026-11-13T13:09:10Z` | Merged correction for combined inventory bounds and simplification/qualification of native lowering. It is not a plugin hot-swap PR. |
| `@get-modular/effect` | source manifest `0.0.0`; exact catalog peer `effect: 4.1.4` | Current README calls it an implementation candidate, explicitly not an npm release. Target coordinated release is Core/Assembly 0.8.0 and Effect adapter 0.1.0. |
| Released Assembly compatibility | README identifies Assembly 0.7.1 as lacking the new preparation bridge | Do not mix the candidate with that released archive. Matched local archives are the documented candidate path. This lane did not independently query the live npm registry. |
| `@get-modular/lifecycle-kernel` | source manifest `0.1.0`, `private: true` | An implemented synchronous candidate; no release/product adoption claim follows. |
| Upstream Effect source | tag `effect@4.1.4` → `289a53f7b1fc40049219c6e69022db2fb859c356` | Exact primary source inspected. |
| Executed Effect package | installed package manifest `4.1.4`; exact resolved directory and source/dist hashes in `spike/evidence-manifest.json` | Four scenarios executed against this compiled package. Git source and installed source are separate identities. |
| Compiler/runtime | TypeScript 7.0.2; Node v24.22.1; `@types/node` 24.19.1 | Strict test typecheck passed before executing the final fixture. No TypeScript 5.9 compiler/API was initialized. |

PR 240's production review reports 27 native/admission tests and 23 scenarios repeated through installed archives, portable NodeNext/Bundler public types, and ordinary Assembly without Effect. Its repeated-diamond and malformed-product cases are meaningful resource evidence. Those are the repository's recorded qualification results; this research did not rerun the Get Modular suite or replace exact-head CI evidence. They establish native constructor behavior within those tests, not npm publication, application adoption, concurrent production load or live plugin replacement.

Primary anchors: [current adapter README](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/packages/effect/README.md), [accepted ADR-0043](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/docs/decisions/0043-plan-optional-native-effect-composition.md), [production review](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/research/effect-integration-2026-11/production-review-2026-11-13.md), [PR 240](https://github.com/agent-teams-ai/get-modular/pull/240).

## What the actual adapter does

The preparation factory delegates to Assembly's existing neutral preparation, then returns a frozen prepared object whose `layer` function closes over the verified wiring. It is one composition authority. It does not introduce a second compiler, DI resolver or runtime.

In `lower.ts`, every selected step gets a private native service key and one native Layer. Provider nodes are resolved once from previously selected steps; `Layer.provide` closes each node over its chosen providers. Root instances are collected into a frozen record. Each call to `.layer()` creates new mapper-owned Layer identities. Reusing one returned Layer deliberately reuses native memoization inside its build domain.

Calling `.layer()` again therefore creates another construction graph, not an update of the existing graph. Calling `prepare()` with a changed inventory creates a new verified selection. “Generation” is the Host's interpretation of that new build; the adapter itself does not mint operational generation IDs or control a live route.

The distinction matters when module B captured a method, object or Effect from module A. Constructing A2 does not rewrite B1's closure. There are two honest options at an intentionally replaceable boundary: rebuild the affected closed composition, or inject a stable subject-specific facade that selects and retains a generation at each operation boundary. Existing CMS explicitly recommends such a facade and rejects a generic Proxy. This is a product-owned dispatch boundary where replacement requires it, not a new mandatory wrapper around every plugin API. A whole application need not be rebuilt when its replaceable instance boundary is smaller.

The same caution applies to private Layers captured by factories and borrowed inputs. Fresh mapper Layer identities do not clone arbitrary mutable objects, reopen every private Layer or change cache configuration. Borrowed values preserve their external owner. A new native Scope does not isolate a shared MemoMap by itself.

Anchors: [factory.ts:12–25](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/packages/effect/src/features/construction/factory.ts#L12-L25), [lower.ts:54–91](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/packages/effect/src/features/construction/lower.ts#L54-L91), [CMS dynamic instances](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/docs/architecture/common-assembly.md#dynamic-instances).

## Version-specific native primitives

| Primitive in Effect 4.1.4 | Useful guarantee | What it does not guarantee |
| --- | --- | --- |
| `Layer`, `Layer.buildWithMemoMap`, `Layer.fresh` | Native construction, dependency provision, identity-based sharing, selected scope ownership | Rebinding an already captured service, global service identity, routing or business readiness |
| `MemoMap` | Counts observing build scopes and closes a memoized entry when its last observer releases; same Layer object can be shared | Every user of an escaped service is an observer; isolation merely because scopes differ; compatibility of changed configuration |
| `Scope`, `Effect.acquireRelease` | Acquisition/finalizer handoff and scope-bound cleanup; acquisition is normally uninterruptible to avoid losing late resources | Hard shutdown deadline, safe interruption of arbitrary foreign IO, cleanup-debt retry or revocation of JS references |
| `ScopedRef` | Serializes replacement setters; acquires a candidate before releasing previous resource; acquisition failure can preserve old value | Borrower leases, drain, atomic readiness/publication with uninterrupted readers, rollback after arbitrary old cleanup failure |
| `RcRef` | A `get` adds a reference to the current caller Scope; `invalidate` sends subsequent gets to fresh acquisition while existing scoped borrowers retain the old resource | Candidate readiness before routing, multi-capability atomic publication, generation authorization, safe calls through escaped references or indefinite lifetime after owner shutdown |
| `LayerMap` / `RcMap` | Keyed scoped resource families, native borrowing, invalidation and optional idle retention | The key includes configuration/version automatically; owning-scope close joins arbitrary foreign clients. `LayerMap` is explicitly unstable. |
| `ManagedRuntime` | Runs work at an existing application boundary; disposal tracks managed work and closes its scope | One runtime per plugin is required; unrelated runners using captured services are tracked; repeat disposal callers receive the initiating caller's cleanup failure |
| `Reloadable` | No public module/export found in the pinned Effect 4.1.4 distribution or its `index.ts` | Do not apply Effect v3 Reloadable examples as though that module were available here. |

`ScopedRef.get` is simply an effectful read of its backing current value. The exact source `set` sequence is: acquire in new generation Scope; close old Scope; close candidate on old-close failure; only then write the new backing tuple. Setter serialization is not reader leasing. The observed finalizer-defect outcome is version-specific behavior, not a promise that future Effect versions must retain a closed old pointer.

`RcRef.get` increments references and registers the release with the caller Scope inside an uninterruptible handoff. `invalidate` marks the acquired state invalidated and removes it as the current cached state; existing positive reference counts delay its close. The acquire effect itself is fixed at `RcRef.make`, so obtaining a genuinely different plugin requires an explicit generation/configuration choice in the owning design. Calling `invalidate` on one generic mutable lookup is not a ready-before-publish transaction: the next caller may discover the replacement's startup failure. A prepared and retained candidate, followed by explicit Host promotion, is a different protocol.

`RcRef` also has an owner finalizer. Its owning scope must outlive the borrowers whose continued use is promised. Refcounting is not permission to close the owner early. Likewise, a finite idle TTL schedules release in another fiber; the caller releasing its last reference may not await that cleanup. These distinctions matter for a public “fully released” result and cleanup failure reporting.

Anchors: [ScopedRef.ts:116–205](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/ScopedRef.ts#L116-L205), [RcRef contract](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/RcRef.ts), [RcRef implementation:198–262](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/internal/rcRef.ts#L198-L262), [MemoMap:245–276](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/Layer.ts#L245-L276), [LayerMap:184–209](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/LayerMap.ts#L184-L209), [ManagedRuntime disposal](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/ManagedRuntime.ts#L403-L427).

## Decision-changing experiment

The 166-line TypeScript fixture was planned before execution and independently critiqued by the parallel runtime research lane. It uses real Node FileHandles, independent lifecycle event arrays, and Deferred barriers. There are no sleep-based race assumptions and no hand-written generation manager. An open file is verified by reading known bytes at a fixed offset; physical close is independently verified with `EBADF`. Source assertions and real lifecycle events are distinct oracles.

| Case | Observed result | Consequence |
| --- | --- | --- |
| Old borrowing call remains active during `ScopedRef.set` | Old handle was readable before replacement; after its physical close, concurrent `get` during held finalization returned that old handle with `EBADF`; retained call also saw `EBADF` after set completed | Bare `ScopedRef` is insufficient for graceful replacement with overlapping resource-using calls. |
| Candidate acquires a file, then returns a typed failure | Candidate partial file closed; old file remained current and usable; old finalizer had not run | Acquisition failure can leave old service healthy; this is a positive control, not a blanket rollback claim. |
| Old finalizer physically closes file, then defects | Exact sentinel preserved as one `Die`; no typed Fail or Interrupt; candidate file closed; current reference still pointed at old closed file | Preserve failure class and observed state; never infer a healthy rollback from “set failed.” |
| `RcRef.invalidate` with an active old scoped borrower | Next borrower got a distinct live handle; both remained usable; old closed only when old borrowing scope closed; each generation closed exactly once | Native scoped resource pinning is reusable. Publication and operational authorization remain separate. |

Final strict typecheck exit: 0. Runtime: 4 tests, 4 passed, 0 failed/cancelled/skipped. Commands, source/config hashes, resolved versions, package/dist hashes and raw logs are retained in `spike/evidence-manifest.json`, `spike/typecheck.log`, `spike/runtime.tap.log` and `spike/runtime.stderr.log`.

This proves the selected primitive behaviors, not a production route switch, a whole-GM generation implementation, stream migration, authorization, application adoption, hard cancellation or throughput. No user credentials, production resources or remote mutation were involved.

The pinned Git source and npm-installed source were hashed separately. `RcRef.ts`, `internal/rcRef.ts`, `LayerMap.ts`, `ManagedRuntime.ts` and `index.ts` were byte-identical. Some other files had generated overload JSDoc additions; the complete `ScopedRef` difference is retained as `spike/installed-scoped-ref-source.diff` and changes no executable statements. No byte-identical source tree or archive claim is made. A TypeScript compiler-API inspection attempt found that this installed native TypeScript 7 package has no `lib/typescript.js`; no older compiler was substituted, and that optional inspection was not a test gate.

## Existing lifecycle owner and what must remain separate

The current CMS already describes the required coarse shape: build a new instance; activate it, switch the Host route and quiesce the old instance in one synchronous step; drain according to Host policy; retire and close; release retained custody only after the real close completes. That is an existing contract to integrate with, not a missing universal generation framework.

The implemented lifecycle kernel already provides `stage`, `activate`, `quiesce`, `resume`, `retire`, `beginCall`, `retainCustody`, `checkCall`, `release`, `finishRetirement` and snapshots. Its core implementation is 135 lines. New calls require active phase. Existing call authority survives quiesce but is revoked by retire. Custody is retention, not authority. `finishRetirement` requires zero held calls and custody, but proves only the kernel's bookkeeping. The Host must separately prove physical cleanup.

Resource retention and invocation authority are related but different facts. A native resource lease can keep a FileHandle alive; a kernel call token decides whether a supported Host-mediated effect is still admitted. That token is not the product's security grant; reauthorization may still be required. Correct integration must not maintain a second editable phase/count table mirroring the kernel, or let the kernel and native Scope both independently dispose the same resource. Couple acquisition/release through the actual executor hooks at the boundary and have one Host supervise the result. Do not add parallel registries/counters where the existing owner already represents the same fact.

The first accepted kernel contract explicitly excludes retained consumers starting new calls after their owner has retired. A retained stream/callback that will issue new calls cannot silently treat custody as an invocation grant. Either those calls belong to a still-admitted operation whose owner remains quiescing, the callback goes through the current facade and is admitted to the new generation, or a successor contract is needed. This is a real unresolved semantic choice, not a TypeScript trick.

Anchors: [current kernel API](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/packages/lifecycle-kernel/src/features/lifecycle/types.ts), [kernel implementation](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/packages/lifecycle-kernel/src/features/lifecycle/kernel.ts), [ADR-0029](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md), [CMS candidate boundary](https://github.com/agent-teams-ai/get-modular/blob/6c91ff1c3c8ce7088db215af9705f7ee3a9db103/docs/architecture/common-assembly.md#optional-dynamic-host-lifecycle-candidate).

## Missing contracts for live changes

These are contracts to complete at existing owners. They are not a proposal for another DI container or lifecycle manager.

| Contract | Required decision and rejection evidence |
| --- | --- |
| Version and artifact identity | Immutable executable identity, selected manifest/factory identity, compatible capabilities and permissions must match. GM validation is not executable trust; typed `E/R` is not a runtime proof for downloaded agent-authored code. |
| Operation/session pin | Specify whether a tool call, entire agent turn, transaction, session or stream holds one generation. Under a continuity policy, new selections after promotion use new graph and already admitted work keeps its selected graph until its agreed end. Under an interruption policy, retain the resource through actual cancellation/settlement; do not dispose merely because interruption was requested. |
| Atomic admission and promotion | Route selection, admission and lifetime retention must complete coherently before any asynchronous yield in one execution agent. Either old is admitted and retained before quiesce, or new is selected. Prefer one composition pin per operation to independently selecting unrelated plugin generations midway through the operation. Async candidate acquisition/readiness must not create a routing gap. Multi-process publication requires its own existing distributed authority. |
| Failed startup | Candidate has retained ownership before acquisition. Failed/interrupting candidate cleanup is observed, old route remains available, and uncertain external side effects are not called rollback. Exclusive resources can require a pause or handoff instead of overlap. |
| Old work and callbacks | Recheck authority after await and immediately before supported effects; distinguish continuing admitted work from a new call by an escaped callback. A callback, object, closure or JS reference is not revoked by changing a route. |
| Streams and background work | Hold the owning generation through stream consumption and its finalization, not merely stream-object creation. Every detached worker/subscription has an explicit owner, cancellation path, completion observation and failure policy. |
| Retire versus drain | User has not selected interruption policy. Define bounded drain, force-interrupt, deferred activation or a plugin-specific combination. A timeout must say whether it ends a wait, requests cancellation, or proves actual settlement. |
| Cleanup failures | Preserve exact Cause/first close result where promised; retain custody until physically resolved. Native Scope is not retryable GM Resources cleanup debt. Do not erase a failed old close by declaring new publication successful. |
| Stateful upgrades | State compatibility, external writes, schema migration, idempotency and rollback/roll-forward ownership are explicit. Resource replacement alone does not migrate private heap state. |
| Agent-authored self-update | Editing/testing code yields a candidate request for the existing authority. The active invocation must not wait for its own generation's drain; return a durable request/receipt and let the stable owner finish promotion/retirement separately. |

A non-cooperative arbitrary JS plugin can retain raw IO capabilities, ignore cancellation or perform synchronous work that blocks the event loop. Neither Effect nor the kernel can enforce revocation of such behavior in-process. If isolation or hard preemption is part of the product guarantee, the responsible process/worker/sandbox boundary must enforce it. That is separate from adopting Effect for cooperative native resource ownership.

## Assembly and native Effect compared on the same scope

Both routes can support immutable instances, stable narrow facades and Host-controlled promotion. Ordinary Assembly plus the existing Resources/kernel contracts is a viable baseline; live replacement does not force a native Effect migration.

| Concern | Existing Promise Assembly + Resources | Native Effect route |
| --- | --- | --- |
| Provider selection | Same neutral GM preparation/bindings | Same neutral GM preparation/bindings |
| Per-generation construction | A separate `run` with separate inputs/scope | A distinct native Layer build with appropriate identity/scope |
| Native resource semantics | Resources close reports and retained cleanup debt/retry contract | Native acquisition, Scope and Cause semantics; no automatic Resources debt/retry |
| Concurrent work and cancellation | Existing Host/Promise/AbortSignal adapters explicitly coordinate and join work | Connected fibers, scoped finalization and native error/context propagation reduce adapter work |
| Borrowed generation/resource lifetime | Existing custody/operation wrapper must retain resource owner | Existing kernel remains authority bookkeeping; native scoped borrowing can supply physical resource pinning |
| Rebinding retained JS values | Explicit facade or rebuild affected instance | Same requirement |
| Trust, readiness, admission, recovery, migration | Existing product owners | Same owners; none moves into Effect |

The native route is most attractive where implementations already return Effect/Stream and the actual resource-using operations can stay inside the same native execution chain. Wrapping Promise Assembly in `tryPromise` does not gain native construction semantics. Introducing one ManagedRuntime per module would fragment ownership and caller context; ADR-0043 rejects that approach.

## Conditional implementation cost and scores

These are preliminary engineering judgments for **incremental local generation/use-boundary integration**, not complete plugin delivery, rollout, package release or current Agent Runtime provider work. Assumptions: one JavaScript execution agent, trusted cooperative implementations, existing CMS/kernel semantics accepted in the target scope, a narrow stable capability facade, one agreed operation/stream lifetime policy, and version-compatible or externally owned state. No complete product baseline was audited in this lane.

Existing GM preparation/lowering, native Scope/fiber/refcount primitives and lifecycle-kernel implementation are reused. They are not counted as new code. A new DI container, general async lifecycle framework and duplicated phase/lease bookkeeping have **zero planned LOC**. If a design requires them, reconsider its ownership before estimating more code.

| Bounded integration route | New mechanism code P | One consumer integration I | New tests/fixtures T | Confidence in estimate /10 | Achievable reliability within this bounded scope /10 | Implementation burden /10 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Existing Promise Host + Assembly/Resources + lifecycle kernel | 150–300 | 100–250 | 600–1,100 | 5 | 8 | 6 |
| Already-native Host + `@get-modular/effect` + existing kernel, native scope/lease reuse | 100–250 | 80–200 | 550–1,000 | 5 | 8 | 5 |
| Introduce native Effect for one currently Promise-only slice | Native row plus 50–200 | Native row plus 100–300 | Native row plus 200–600 | 4 | 8 after equal qualification | 7 |

P and I are non-overlapping rough bands, not measured line counts. P covers the missing generation/use-boundary glue at its existing owner, without a new container or general lifecycle framework; I covers one consuming capability's wiring, readiness inputs and facade/native operation mapping. T covers the cross-boundary scenarios, not a test suite per line of P. Combined P+I ranges are 250–550 and 180–450 for the first two alternatives. The third row is an additional migration cost only when native Effect is absent. If the actual executor already implements one of these mechanisms, subtract that work; its incremental P may be zero.

The code ranges cover one facade/use boundary, candidate ownership/readiness integration, synchronous promotion wiring, scoped call/custody release, and retained failure observation using existing primitives. They exclude executable artifact loading, authorizer/grants, durable admission/recovery storage, plugin state migrations, distributed rollout, all plugin categories, UI, platform isolation, publication, installed dependency qualification and operating/release work. Those exclusions are prerequisites or separate deliveries, not “free” capabilities supplied by Effect. The ranges must be revised after the owning Host is inspected; they are not additive estimates for a whole product.

The two reliability scores are intentionally equal for the same promised behavior: Effect does not make the missing publication/authority/state contracts disappear. Its likely advantage is less custom concurrency/resource code in an already-native system. The actual constructor fit has high source confidence; a global “Effect 9/10 for hot swap” rating would obscure the unimplemented contracts. The dated production review's 9/10 assessment concerned concurrent resourceful TypeScript workloads generally, not turnkey plugin replacement.

## Recommended next decision

Candidate principle for the next decision: a generation's composition is immutable and new work selects a current generation at an explicit boundary. If continuity is selected, an admitted operation/session retains its selected generation until completion; if interruption is selected, resources remain retained through actual settlement and cleanup. Keep that policy deliberately open until plugin categories and the first real consumer establish it. Treat agent-authored code as candidate artifacts admitted by the existing authority, and separate the self-update request from waiting for old-generation retirement.

For a bounded next implementation, integrate the existing CMS/kernel mechanism at one real replaceable capability with real concurrent calls and a real stream or callback lifetime. Choose Promise or native Effect according to that slice's current execution model. In a native slice, evaluate native scopes/RcRef or a keyed LayerMap only where the contract requires sharing; do not start by putting the entire graph in a bare ScopedRef. Verify candidate failure, a retained old call, a post-await old callback, finalizer failure, and a self-update request that cannot deadlock on its own drain. A successful slice qualifies that category and owner, not every future plugin automatically.

## Reproducibility and source ledger

`source-ledger.json` contains exact repository/commit/path/Git-blob/URL and content hashes for every retained source. Get Modular source is under its retained Apache-2.0 `LICENSE`; Effect source is under its retained MIT `LICENSE`. These are selected read-only upstream snapshots, not modified production sources.

The local probe lives in `spike/lifetime.test.ts`, with `package.json` and strict `tsconfig.json`. Its `node_modules` links use the previously installed exact packages only; they are not a self-contained dependency archive. Reproduction elsewhere must install the recorded package versions and qualify the resulting bytes, then run the recorded compiler and Node commands. The fixture and raw evidence remain usable without trusting a narrated outcome.
