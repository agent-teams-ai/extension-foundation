# Live plugin evolution research, 2026-11-14

This packet supports the governed Extension Foundation research and OD-003
vision record. It is not a runtime implementation, accepted architecture or
release. Client date is November 14; primary retrieval began November 13 UTC.

## Reading order

1. `brief.md` records the user direction and unresolved interruption policy.
2. `root-analysis.md` covers portable packaging, the Cloudflare self-modifying
   example, model context and UI boundaries.
3. `agent-trends/agent-ecosystem-report.en.md` covers nine agent ecosystems.
4. `runtime-patterns/report.md` covers eight runtime precedent groups.
5. `effect-fit/report.md` covers the current Get Modular integration and native
   Effect resource experiment; its `spike` directory holds exact source/config,
   hashes, strict typecheck and raw runtime results.
6. `critiques` preserves two review rounds, independent probe inspection and
   the root's dispositions. Lane source ledgers provide exact provenance.

## Scope of execution

Only the four real FileHandle scenarios in `effect-fit/spike/lifetime.test.ts`
were newly executed. They passed with strict TypeScript 7.0.2 and installed
Effect 4.1.4 on Node 24.22.1. Other upstream tests and examples were inspected,
not run. No paid provider, production deployment or third-party plugin ran.
The fixture is a frozen research input, not a newly published package or
production host. Reproduction requires the recorded dependency versions;
`node_modules` and machine-local links are intentionally excluded.

Selected read-only Get Modular and Effect source bytes retain their Apache-2.0
and MIT licenses. Frozen upstream names, including a Get Modular `.mjs` test,
are preserved as source evidence and were not edited or executed. New authored
JavaScript-runtime research code is the strictly checked `.ts` fixture.

## Validation and limits

`validation` retains documentation context, initial spelling rejection,
corrected quality output and exact embedded-compiler resolution. General local
Foundation/check/check:fast/check:changed entrypoints were not run: installed
Engineering Foundation 1.7.2 statically imports API Extractor 7.58.12, whose
compiler resolves to TypeScript 5.9.3. The organization standard prohibits
initializing that older compiler for current work. No dependency or gate was
weakened. The separate Docs Protocol route remains available. Final complete
Docs results and original hosted CI runs are recorded in the PR; hosted success
does not resolve the separately owned compiler/tooling adoption gap.

The external archive manifest covers every regular member and the compressed
archive itself. No absolute or traversing member path, symlink, dependency tree
or temporary fetch script belongs in the packet. Historical evidence archives
are unchanged. Reviews critique source/claims; agreement does not select a
runtime, approve interruption policy or establish product-scale reliability.
