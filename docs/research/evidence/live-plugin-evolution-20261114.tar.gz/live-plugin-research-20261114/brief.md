# Live plugin vision and research brief

Client date: 2026-11-14, Europe/Kiev. Initial source retrieval: 2026-11-13 UTC.

## User direction

The user explicitly prioritizes adding, updating, replacing and initializing
plugins while the application and agents continue running. Agents should also
be able to author or request changes to plugins. This is an important product
vision to record now, across plugin categories, ideally implementable from the
first useful slices when the cost is reasonable. Research mechanisms deeply
before selecting one. Avoid architecture that makes later adoption require an
unnecessary broad rewrite.

The user leaves whether an ordinary update may interrupt current work OPEN
("на подумать"). Do not select cancellation, maintenance grace, forced close,
session migration or a no-interruption promise on their behalf.

Chat responses must be concise, emphasize only useful findings, critical
limitations and questions, and may use a few emphasis emojis. The complete
research, sources, criticism, exact experiments and estimates belong in the
existing Extension Foundation research repository.

## Existing authority and scope

- EF PR55 remains open draft, head 7fd1e3392c732b64053edb11cfd32a7711dfdec8.
- Prior research and accepted ADRs remain historical evidence. The new user
  direction is a product vision; concrete runtime/host/SPI choices are proposals.
- A static immutable composition inside a generation need not prevent live
  switching between generations. Explicitly reconcile this with the previous
  controlled-restart baseline without silently rewriting accepted ADRs.
- GM owns neutral graph preparation/composition. EF owns neutral artifacts,
  trust/distribution/conformance. Products own capabilities, authorization,
  active selection, routing, state and update policy. Existing execution owners
  retain physical custody. Shared mechanism should be one reusable library
  where justified; no duplicate resolver, supervisor or state authority.
- Freshly inspect GM PR240 and current main Effect integration. Source/library
  acceptance, registry publication, app adoption, hot replacement and fleet
  qualification are distinct. Native Effect4 APIs must be checked, not inferred
  from Effect3 examples.
- TS >=7.0.2, new JavaScript-runtime maintained code is .ts. No TS5.9 initialization.
- This delivery is research/vision documentation and a small discriminating
  native-library experiment if justified. No production implementation,
  dependency migration, release, merge or untrusted/live-provider execution.

## Parallel research lanes

1. Agent trends: MCP current protocol, CLI tools/skills/mods, reload and
   self-modification; exact update boundary and maturity.
2. Runtime patterns: Cordis, OSGi, Erlang, Wasm and Dynamic Workers,
   generation/state/resource/dependency lifetime, mature counterexamples.
3. Effect fit: current GM/Effect4 source, native resource primitives,
   narrow real-library probe with independent plan and result criticism.
4. Root: portable packaging, Cloudflare self-modifying harness and skills,
   browser/UI reload, trust/control separation, synthesis and authority.

## Required retained evidence

For each case preserve retrieval date, official source/release/commit, files and
symbols, observed mechanism, maturity, counterevidence, unexecuted boundaries
and applicability. Classify a specification, inspected source, local execution,
upstream test and inference separately. No popularity-based ranking or invented
trend adoption statistics. Do not equate dynamic discovery with live migration.

Plan and result review must challenge lifetime, exception/cleanup, state and
authorization claims. Use two bounded cross-review rounds. Only execute a spike
whose result changes a real design choice; preserve failed predictions.

Estimate production mechanism, one product integration, and tests separately;
state prerequisites, exclusions, new vs changed code, uncertainty and overlap.
Scores out of ten are engineering judgments about a named guarantee, not uptime.

## Deliverables

- Maintained vision and explicit open interruption question in OD003.
- Governed synthesis with breadth matrix, trend confidence, architecture options,
  current Effect fit, critical unknowns and staged acceptance plan.
- Detailed research/criticism/source ledgers and real probe evidence in a
  hashed archive, linked from the maintained research reference.
- Docs Protocol validation and published PR55 commit, original hosted CI
  completion observed without unnecessary reruns.
