# Root research: portable packages, editable agents and UI boundaries

Client observation date: 2026-11-14. Primary source retrieval started
2026-11-13 UTC. This is research, not adoption of an external runtime.

## 1. Portable packages are converging; live lifecycle remains a host contract

Agent Plugins 1.0.0 is a published package specification, announced on
2026-08-06. At source `465e04661ccddfcccff95d0b99a4cf59d80c5478`, its README
still identifies 1.0.0 as published and 1.1.0 as a working draft. The stable
package covers Skills and MCP configurations. The draft adds command hooks
at named agent-loop boundaries. Neither status is evidence that arbitrary
loaded implementation, active session or persistent state can be migrated.
[ROOT-AP-README, ROOT-AP-STABLE, ROOT-AP-DRAFT, ROOT-AP-LAUNCH]

The stable spec has deterministic local schema selection and confines packaged
paths. It explicitly does not turn those path rules into a subprocess sandbox.
Its version field is metadata used for freshness, not our immutable artifact
identity or a complete compatibility proof. The draft hook contract preserves
applicable client/organization restrictions even when a hook returns allow.
Namespaced client extensions remain outside the portable contract.

**Inference:** retain interoperability at the artifact/component edge and keep
live activation in the consuming owner. EF should not redefine a portable skill
format merely to implement replacement, nor let a portable manifest overwrite
effective authorization. Track draft hooks as a convergence signal, not an
adopted stable dependency. A package format can evolve faster than the guarantee
that running code is replaceable.

## 2. Cloudflare has a direct, explicitly experimental self-modifying example

Inspected `cloudflare/agents` at
`9b73399c7cee9550c19146b7f76a735a10700ada`, especially
`examples/next/harnesses/self-modifying/src`.

The documentation labels this harness experimental and example-local; it uses
internal SDK APIs. It also states that the example has no authentication.
Running it requires remote Workers AI and Worker Loader access; this research
did not run it or contact a model. [ROOT-CF-DOC]

The mechanism is much closer to the user's vision than a generic plugin list:

- `SelfModifyingHarness.#activateUnlocked` snapshots source, compiles/checks it,
  and only then calls the store's activation operation. Source editing alone
  does not change the active build. Activation keys make replayed activation
  identifiable. The source lock serializes source-related operations.
- The turn creation path binds `revisionId` from a retained turn/task or the
  selected active revision. Later execution uses that pinned revision rather
  than rereading current editable code. [ROOT-CF-HARNESS]
- `compileHarness` bundles source with a generated entry module and checks a
  parsed manifest in a fresh Dynamic Worker. This is bundling plus runtime
  shape/contract validation; this inspected path does not establish a strict
  semantic TypeScript compiler run. Both validation and turn execution disable
  direct global outbound networking and set explicit worker resource limits.
  A fresh worker is loaded for each turn; heap globals are not its durable
  checkpoint. [ROOT-CF-RUNTIME]
- `SelfModifyingHarnessStore.activate` stores content-addressed build material,
  appends a monotonic revision and changes the active revision in its own
  synchronous storage transaction. Restoring prior source appends a forward
  revision rather than reusing old authority identity. [ROOT-CF-STORE]
- `HostBridge.callTool` binds journal records to turn/call/input identity, reuses
  a recorded completed result and rejects mismatched inputs. The actual System
  tool switch stays outside editable code. It exposes source write/delete and
  explicit activate/restore tools. Candidate custom-tool registration rejects
  shadowing System tool names. [ROOT-CF-BRIDGE, ROOT-CF-RUNTIME]

Upstream tests contain cases for invalid source preserving the active revision,
custom-tool creation/activation, System tool shadow rejection, queued turns and
self-edit/restore. Those test sources were inspected, not executed here.
[ROOT-CF-TESTS]

**Boundary:** an interrupted effect whose result has not been journaled can run
again, and custom code can replay during recovery. This example does not prove
exactly-once arbitrary effects, automatic state migration or production access
control. Its real value is the separation of editable execution from a stable
revision/state/control owner. [ROOT-CF-DOC]

**Transfer candidate:** allow an agent to write a candidate and request its
activation through a narrow owner command. A running old generation must not
await its own retirement; return a request/activation receipt and let later work
observe the selected revision. Source writing, executable admission, routing
publication and retirement are distinct outcomes. Do not import Cloudflare's
storage or internal APIs into our existing owners simply to copy this example.

## 3. Dynamic skills also change model context, not just files

The current Cloudflare Skills documentation is explicitly experimental and
names Agents SDK0.32.0 / Think0.23.0. It lists sources before each turn. A changed
catalog reaches the model as a reminder while the existing system-prompt cache
is retained; compaction or clearing history later rebuilds the prompt catalog.
[ROOT-CF-SKILLS]

This supports a useful design inference: a live plugin update has two consumers,
the executing host and the agent's view of available capability schemas. A
tool name alone cannot bind an already-issued model call to the intended
implementation. The product should retain the presented catalog/schema and
execution revision at its chosen call/turn boundary, then recheck current
authorization when accepting the effect. Do not silently reinterpret an old
call using a new schema or give a withdrawn grant continued authority merely
because code is pinned. This is a proposal, not a claim about an existing MCP
version field or already implemented Agent Teams admission.

## 4. Browser modules: dynamic loading exists; UI lifetime remains separate

Module Federation's current official runtime supports dynamic registration and
loading. `registerRemotes(..., { force: true })` replaces registration/cache
entries and explicitly warns of risk. At source
`d4a31960d20a717626af43be59aab0881c7b6cc0`,
`packages/runtime-core/src/remote/index.ts` removes the prior registration,
clears relevant snapshots/loading/module caches and handles shared-instance
references before registering the replacement. Removal errors are logged.
[ROOT-MF-API, ROOT-MF-SOURCE]

Inspection of that function does not find product component unmounting,
application subscription disposal, saved-form migration or rewiring of ordinary
objects already returned to consumers. These responsibilities are outside that
remote-cache operation. Do not claim that forced remote registration preserves
all React state, is a transaction over side effects, or creates a hostile-plugin
sandbox. No Module Federation execution was added in this task.

**Transfer candidate:** UI contributions need an explicit owner boundary for
mount/unmount, callbacks and persisted user state. Keep that boundary compatible
with a future isolated renderer or fresh component generation. It can share
artifact/revision vocabulary with backend plugins without sharing one loader or
requiring every backend plugin to implement UI methods. Module Federation is a
case study, not a selected frontend dependency.

## 5. Node module cache is not a generation owner

Current Node26.13.1 ESM documentation says URL query/fragment differences produce
separate loads and ESM has a cache separate from `require.cache`. This describes
module identity, not cleanup of retained objects. [ROOT-NODE-ESM]

**Inference:** appending a new query to an entry module cannot establish a closed
dependency/import graph, reclaim all escaped resources or update captured
consumers. Preserve an immutable executable closure and a chosen lifetime
boundary. A worker/process/realm can provide a reset boundary when justified;
ordinary module evaluation and a resource scope should not be described as an
OS security boundary. Previous EF experiments already cover import-closure and
worker-cleanup counterexamples, so no duplicate cache experiment was run.

## 6. Cross-cutting architectural proposals

1. **Immutable artifact, replaceable generation.** Keep plugin identity,
   artifact/import digest, candidate attempt, selected head and execution
   incarnation distinct. Group inseparable dependencies into a replacement
   cohort; one marketplace entry need not equal one process.
2. **Capture one generation per declared unit of work.** Call, model step,
   turn, session and durable workflow are different boundaries. Choose and
   document one per capability. Retained ordinary objects either belong inside
   the cohort or use a consumer-owned facade; no global service locator.
3. **One resource owner.** Acquisition, callbacks, streams, timers and cleanup
   belong to the generation scope or existing executor. Native Effect can help
   with local lifetime; it does not grant product authority or physical absence.
4. **Explicit state compatibility.** External canonical state keeps its owner.
   Optional plugin-private state needs version/restore semantics. A previous
   code revision cannot undo a database write or external action.
5. **Same admission for human- and agent-authored candidates.** Agent code does
   not edit its own effective grants, canonical registry or lifecycle owner.
   Preauthorized policy can permit automatic updates; this does not require a
   human confirmation for each safe update. Elevated effects remain explicit.
6. **Bound churn and retained work.** The eventual profile must account for
   candidate preparation and failed cleanup as retained resources. Test repeated
   updates, generations held by sessions, memory, queue pressure and fairness.
   A single successful replacement is not fleet-scale evidence.

These are candidate design constraints for review. The user has confirmed the
vision, not all six mechanisms or an ordinary-update interruption policy.

## Research result and limits

The strongest forward direction is versioned live evolution at explicit
capability boundaries, with fresh validated code and coherent generation
identity for each admitted operation. Retaining existing work until completion
is one candidate continuity policy; ordinary-update interruption remains open.
Same-process code mutation and suspended-stack migration
are optional specialized techniques, not required to satisfy the user's main
goal that the application stays live. The user's ambition applies to all plugin
categories; coverage can be qualified incrementally with visible exceptions.

Source inspection and a current standard show concrete directional movement;
they do not measure ecosystem adoption or prove an inevitable universal trend.
No source here selects Cloudflare, Module Federation, a new language, another
store or a new supervisor for Agent Teams.
