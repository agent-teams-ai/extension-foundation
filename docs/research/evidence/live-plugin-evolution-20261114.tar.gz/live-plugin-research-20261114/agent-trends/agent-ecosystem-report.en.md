# Agent and tool ecosystems: live extension, replacement, and self-modification

Research date: **2026-11-14 (client date)**. Retrieval and source pins: **2026-11-13 UTC**, through approximately 23:01 UTC. This is a detailed research intermediate for a git-backed product-vision record. It is not an implementation decision.

**Product-vision status to preserve: HIGH PRIORITY.** All plugin categories should support acquisition, update, disabling and replacement while the application and agents remain running, potentially with the agent authoring or installing the extension itself. This does not decide whether an individual operation may be interrupted during an ordinary update. The reload boundary, interruption policy, runtime and migration mechanism remain open; effective authority remains controlled by the host/product.

Nine cases were selected because they expose materially different mechanisms. Their existence supports serious investigation of the vision. It does not establish that arbitrary stateful code can be replaced safely without interruption, that self-authored code is safe, or that any one architecture has won.

## 1. What this research actually establishes

There are at least four concrete, independently documented patterns:

1. **Agent-authored procedures:** Hermes and OpenClaw can save and revise procedural skills. Voyager already demonstrated accumulation and replacement of executable behaviors in a research environment.
2. **Mutable tool registries:** MCP SDKs, Pi, and OpenCode can change callable definitions while their hosts remain alive. Discovery, model awareness, and execution authorization are separate layers.
3. **Same-session executable harness changes:** Pi, Letta Code, Claude Code mods, and OpenCode implement replacement of extension instances or code modules under defined lifecycle rules.
4. **Agent-version evolution:** DGM writes and evaluates new agent implementations. This is an outer generation/evaluation loop, not evidence of transparent replacement inside an already executing call stack.

The strongest novel product direction is a closed operational loop: the agent can inspect its extension surface, create a change, activate it through a host-controlled boundary, observe diagnostics, and repair or revert it. Letta states this philosophy explicitly. Claude Code now provides an end-of-turn path for agent-authored mods. These are documented usable surfaces with concrete implementations where source is available, subject to significant constraints.

**What was not established:** no inspected case supplies a universal live-state migration protocol for arbitrary plugins, an assurance that uncooperative in-process code stops when unloaded, or evidence that autonomous self-modification reliably improves long-term product quality.

## 2. Definitions that prevent misleading comparisons

| Mechanism | What changes | What this alone does not prove |
|---|---|---|
| File reread / discovery | A prompt, skill, configuration file, or manifest is found/read again | The model knows the new capability; old imported code is gone |
| Model-surface refresh | Tool descriptions or skill catalog become visible on a later request | Installation, execution authority, or code replacement |
| Registry mutation | Definitions and/or callable handlers are added, replaced, or removed | Migration of open operations or existing object references |
| Extension-generation replacement | Old owned registrations are disposed; a new module/factory is activated | Arbitrary JS execution is killed, global side effects undone, or state automatically migrated |
| New-session activation | Files are installed now, but a new session adopts them | A current session changes behavior |
| Process/service rollout | A worker/Gateway/process is restarted or another generation serves new work | Same-process hot replacement |
| Candidate-agent evolution | A modified agent version is tested and selected in an outer loop | Ongoing tasks automatically move to the new implementation |
| State retention/migration | Selected state is externalized/reloaded, or transformed between schemas | Retention of arbitrary module locals, sockets, closures, in-flight continuations |

“Live” should always be qualified by the unit that survives: process, session, conversation, current model request, tool invocation, UI panel, connection, or persistent agent identity.

## 3. Comparative evidence map

Maturity labels: **released specification** requires explicit publication evidence; **documented implementation** means official docs and/or inspected source describe a usable feature, without implying that every inspected source commit is a released artifact; **research prototype** means the authors evaluate an experimental system; **design stance** means maintainer intent rather than proof of a runtime property. “High” confidence means explicit primary evidence, not independent execution, production reliability or stable API support.

| Case and inspected version | Mechanism and boundary | Agent can drive change? | State / failure boundary | Maturity and confidence |
|---|---|---|---|---|
| MCP 2026-07-28; TypeScript server package 2.4.0 | Registry mutation + opt-in list notifications + client refresh | Only if a server/host exposes an authorized management action; protocol does not grant this | In-flight state/migration outside protocol; notifications best effort | Released specification; stable SDK line inspected; high |
| Pi coding agent 1.5.2 | Immediate tool-registry edits; full runtime `/reload` only when response/compaction permit | Yes: author extension; agent-triggerable request waits for `agent_settled` | Old context invalidated; old handler frame does not become new code | Documented implementation, main source snapshot; high |
| Claude Code mods, CLI >=2.1.287 | Agent-written modules reload at turn end; installed plugins have explicit reload/activation rules | Yes, documented built-in authoring skill; permission mode matters | Module locals reset; `$.state` and `$.store` have different lifetimes; monitors need restart | Documented versioned feature; high for docs, no proprietary host-source audit |
| OpenCode core 2.3.0 (dev snapshot) | Watched plugin module reload; ordered registry transforms; changed activation suffix replaced | Agent can write/install through ordinary authorized tools; no claim of universally automatic self-install | Unchanged prefix retained; fallback can reactivate old code; failing reload races have public reports | Documented V2 feature + development source; high for source, reliability unmeasured |
| Letta Code 0.34.60 (main snapshot) | Trusted local mods; generation-based reload and re-registration | Explicitly designed for agent authorship and repair; docs tell user to run `/reload` | Dispose old generation, publish empty registry, reject stale completions; no last-known-good transaction | Documented implementation + explicit evolving API stance; high |
| Hermes, pinned Nov 13 source | Agent writes skills; next-message delta notice; catalog refreshed at compaction | Yes, `skill_manage`; writes can be gated/staged | Atomic writes, per-skill mutation locks, pinned/locked skills, optional scanner | Documented implementation; high for skills, not a Python-host hot-swap claim |
| OpenClaw, pinned Nov 13 source | Ordinary file skills next-turn snapshot; managed/learned selections may stay pinned; plugin code needs Gateway restart | Yes for learned skills and authorized installation paths | Immutable published snapshots, revisions/undo; code and metadata require restart | Documented implementation; high, but multiple skill paths must remain separate |
| Voyager, 2023 main snapshot | Generates/verifies executable skills; updates library for subsequent environment steps | Yes, autonomous skill generation and replacement | Versioned saved skill files, vector index; no live stack/object migration | Research prototype; high |
| DGM, Aug 2025 main snapshot | Self-modifies candidate agent code, evaluates, archives, branches | Yes, within experimental outer-loop execution | Containerized candidates and traceable lineage; objective hacking observed by authors | Research prototype; high for experiment, low for product generalization |

Version pins are source-package versions unless explicitly identified as a release. A package version in a main/dev checkout does not prove that the inspected commit was published or that every described fix is deployed. Full commit hashes and dates are in `source-ledger.json`.

## 4. Case studies

### 4.1 MCP: a changing capability contract, not a plugin loader

The current protocol is **2026-07-28**, officially released July 28, 2026. The TypeScript SDK main branch is its stable v2 line, while v1.x remains a separate compatibility line. Treating the older `initialize`-era connection model as the whole current design would be stale. [A02, A05]

The tools specification permits the available set to change over time and vary by authorization presented on a request. It forbids making the set depend on connection-local state or earlier requests on that connection. Servers advertise `tools.listChanged`; modern clients request `toolsListChanged` through `subscriptions/listen`. The notification is an invalidation signal. The client then needs a new list. Deterministic ordering and cacheable list results matter because the tool catalog is also model input. [A01]

The inspected SDK has actual executable registry mutation. `McpServer.registerTool()` returns a handle with enable/disable/update/remove operations. `RegisteredTool.update()` can change metadata, schemas, handler, and enabled state, then emits the list-change signal. This proves same-process registry replacement. It does not prove a new module was installed or that an old invocation's execution migrated. [A03]

The client side is equally important. `ClientOptions.listChanged` configures callbacks; `_setupListChangedHandlers()` forces fresh list reads rather than serving stale cached entries. Modern connection setup intersects requested handlers with server-advertised support and opens a subscription. Failure to establish that subscription does not necessarily fail the connection. The SDK supports legacy unsolicited notifications separately. Request-only workers do not open an automatic long-lived stream on that path. A host integrating the SDK must still propagate refreshed definitions into its next model request and execution router. [A04]

The architecture documentation calls notifications best effort, including across reconnects. A design that depends on seeing every change event needs additional freshness/reconciliation logic. Authorization is transport-level and operation-scoped; new visibility is not an automatic grant of new scopes or permission. Tool annotations are not a substitute for trust. [A06, A07]

**Useful pattern:** separate registration, invalidation, fresh discovery, model-surface update, and execution admission. **Bad inference:** “MCP supports list_changed, therefore any MCP host can install, safely trust, and hot-replace arbitrary plugins.” None of those additional operations follows from the notification.

**Open question for experiments:** pin a tool-generation/schema digest in every planned call, remove or replace that tool during an active request, and verify which definition executes. This lane did not run such an experiment.

### 4.2 Pi: dynamic registration is broader than its full-reload permission

The authoritative upstream is now `earendil-works/pi`; `badlogic/pi-mono` redirects, and `pi0/pi-mono` surfaced in search as a fork. The inspected coding-agent package is 1.5.2 at commit `97d539ce4c2c7db681bf7acdbbb07ca09533400d`. This distinction matters because older fork docs showed a less precise reload example.

Pi's docs explicitly invite users to ask the agent to build an extension. Extensions execute TypeScript/JavaScript in the host process, can register tools, intercept events, add commands/UI, and register providers/MCP servers. Project extensions load after project trust. This is executable customization, not only prompt-file learning. [B01, B03]

Two mechanisms coexist:

- `pi.registerTool()` is allowed after startup. It refreshes the host's current registry and can activate the new tool in the same session; `setActiveTools()` controls availability. The maintained dynamic-tools example demonstrates the intended API. [B01, B04]
- `AgentSession.reload()` replaces the extension runtime. It first rejects streaming and compaction. It emits shutdown, invalidates the old runner, rereads settings/resources, rebuilds registrations, emits the replacement session-start event, and discovers contributed resources. [B02]

The current agent-driven example has a tool record the reload request, terminate its work, and arrange the command after `agent_settled`. It is not legal for a tool to call the command-only reload API in the middle of an active run. The docs also explain that a command's old call frame continues after awaiting reload; code below that await remains old code and must not use stale runtime state. The recommended handler returns immediately. [B01]

State must be restored deliberately from session entries or other persistence. Event ownership and cleanup remain extension responsibilities: factories should not create background resources before session startup, and shutdown handlers should be idempotent. Revoking Pi context handles does not terminate arbitrary JavaScript that retains direct Node access. That last statement is an architectural limitation of trusted in-process code, not a report of an exploit.

Historical evidence also supplies a useful failure mode. Issue #2753 reported stale disagreement between session settings and the resource loader in 0.64.0. It was opened April 1 and closed completed April 3, 2026. The current reload source explicitly reloads settings; the old issue should be used as a regression scenario, not described as an established current defect. [B05]

**Useful pattern:** make idle-only runtime replacement explicit while allowing lighter registry mutation. Invalidate captured old handles. **Bad pattern:** assume a queued follow-up command necessarily runs at a safe reload boundary, or imply that the present model request sees a tool registered after its schema was sent.

### 4.3 Claude Code: end-of-turn agent-written mods now exist, with surface-specific limits

This case goes beyond the older “skills plus shell hooks plus MCP” picture. Official docs describe in-process JS/TS mods, enabled by default in CLI 2.1.287+ (Desktop minimum differs). They can change UI, register commands/tools, intercept requests, and act within the user's account privileges. The proprietary host implementation was not audited here; the evidence is detailed official operational documentation. [C05]

The documented agent-authoring path uses a built-in `plugin-authoring` skill. Claude writes into a session-specific `~/.claude/dev-mods/<session-id>/` directory. Once enabled for that session, changes load at the end of turns that modify them. Permission modes determine whether the user is asked about files and hot reload. Local `--plugin-dir` development is also watched; agent edits settle at turn end. Generated TypeScript declarations describe the exact running build and take precedence over drifting documentation. [C04]

Installed packages have a separate path. The install UI can report active now, pending reload, missing server configuration, or load failure. On-disk background updates do not automatically mean the running session changed. Reload may be deferred if tool-set changes invalidate the prompt cache; forcing it incurs a fresh uncached request. [C01, C02]

`/reload-plugins` does not mean every component changes everywhere. Noninteractive/SDK/Desktop contexts have command-origin restrictions, require a sufficiently recent version, and do not connect/disconnect plugin MCP servers through this path; those server changes await another session. Monitors also require session restart. Thus “Claude reloads plugins without restarting” is true only with component and surface qualifiers. [C02, C03]

State has explicit tiers: module-level variables reset on module reload; `$.state` survives reload within its defined session lifetime; `$.store` is persisted JSON with its own retention. This is useful externalized state, not automatic object-graph migration or schema migration. Host-owned timer helpers are lifecycle-scoped. [C06]

The trust model is powerful: mods run unsandboxed and can access credentials, prompts and filesystem/network APIs. Bash sandbox settings do not wrap arbitrary processes started by a mod. Built-in guards and managed settings constrain certain mod actions, but do not turn the mod into an untrusted sandbox. Conversely, the official docs deliberately protect the permission-prompt rendering surface. [C05]

**Useful pattern:** agent-written changes activate at a visible turn boundary; exact-build types aid repair; install/fetch/load states are distinguished. **Risk to carry into vision:** granting “author a plugin” and “activate privileged runtime code” can be materially broader than ordinary file editing. A production product should represent that authority separately even if its chosen autonomy setting approves both.

### 4.4 OpenCode: real lifecycle machinery, and real reload failures

Current docs and the inspected `@opencode/core` package (2.3.0, dev-branch snapshot) describe V2 plugins. V1 plugin implementations are incompatible until ported. This is a concrete warning against equating a package manifest standard with a stable execution ABI. [D06]

The installation docs distinguish cached startup, missing-package installation, checking available updates, explicit package updates, and exact-version/hash pins. Changes under watched configuration directories reload automatically. An unwatched local dependency can still need a service restart. GUI-only rebuilds need not restart the server component. [D05]

Two separate interfaces are relevant. A plugin's `setup` may return cleanup. Registry transforms synchronously edit tools, providers, agents, MCP servers, and other domains. Reloading a transform replays registrations in order against a fresh value; it does not rerun plugin setup. External data captured by a transform is not automatically watched. Old read results remain snapshots rather than being mutated in place. MCP definition changes are reconciled into connection lifecycle separately from catalog reads. [D04]

The tool-specific contract is stronger than an immutable list alone: each model request captures executable definitions, Code Mode descriptions and executor functions together. Later transform changes, reload and disposal affect future snapshots. An executor closing over mutable plugin data can still observe changed data unless it captures a value during the transform. This is direct evidence for coherent model-request tool snapshots. It does not establish that a captured executor's old plugin resources remain live: the activation path below closes the old plugin scope before setting up its replacement. Definition retention and resource retention must be checked separately. [D04, D01]

Source inspection provides stronger lifecycle evidence than the marketing phrase “hot reload”:

- `Plugin.activate()` compares IDs and revisions in activation order, preserving only the unchanged prefix.
- Registrations after the first change are closed in reverse order and loaded again, even if a later plugin itself did not change, because registration order affects behavior.
- Cleanup failures are logged rather than aborting the entire swap.
- If candidate setup fails, the implementation can try to activate the previous code again. That is reactivation, not continuation of the old in-memory instance.
- Module-resolution failure may retain the already running generation. A supervisor serializes/coalesces source changes and guards against stale asynchronous update results. [D01–D03]

This is a substantive implementation, but not evidence of fault-free service. The research found three public primary bug reports with distinct status:

| Issue | Version in report | Reported failure | Status retrieved Nov 13 |
|---|---|---|---|
| #62068 | 2.2.5 | Plugin update removes a versioned cache directory still referenced by an in-flight reload; custom provider catalog disappears until explicit reload | Open; labeled “reproduced”; opened Nov 5 |
| #49982 | 2.0.9 | Failed config/plugin reload loses custom agents and commands in persistent service | Closed completed Nov 12; labeled “reproduced” |
| #53526 | 2.0.24 | Reload failure wipes configured providers and, reportedly, bypasses an intended configured base URL | Closed not planned Oct 9; cause not independently established |

These reports were read, not reproduced. Their status must not be upgraded into a universal current bug or downgraded into proof that every scenario is fixed. [D07–D09]

**Useful pattern:** generation identities, consistent ordering, cleanup scopes, and retaining/reconstructing known code after failure. **Failure pattern:** a harmless filesystem edit or package cache cleanup can corrupt a larger derived registry. A candidate product needs to test catalog completeness, authority and routing, not merely whether the new plugin's own feature appears.

### 4.5 Letta Code mods: repairability is an explicit compatibility strategy

Letta Code 0.34.60 exposes trusted local mods for tools, commands, events, permission policies and local providers. The docs explicitly frame them as a way for the agent to modify its own runtime. Machine-wide and agent-memory scopes are supported; project-local mods are not. Host capabilities differ: a Desktop listener cannot necessarily deliver every model/compaction/lifecycle event, and local provider registration is not an update to Letta Cloud. [E05]

The author's loop is concrete: ask the agent to build a mod, let it inspect authoring guidance and existing code, then activate with `/reload`. The source also supports dynamic owned registration. The public page's example instructs the user to reload; it should not be embellished into an unconditional built-in agent permission to trigger every reload itself.

The engineering README is unusually direct about the emerging design: agent authorship reduces the emphasis on a strongly versioned semantic SDK. The host retains APIs where it owns invariants—tools, turn boundaries, cancellation, permissions, scoped conversations, diagnostics—while ordinary JS handles the rest. Breaking changes are considered acceptable if failures identify the owner, phase, source path and replacement API, so the agent can repair them. This is a **maintainer design stance**, not evidence that agent repair always succeeds. [E01]

The runtime uses owner generations. Disposing mods aborts their owner signals, runs registered disposers in reverse order, and removes owned global capabilities. Reload increments generation and publishes an empty registry before loading the replacement. A load completing after a newer generation is ignored/disposed. Tests specifically cover stale handles, empty intermediate snapshots, and competing reload completions. The tests were inspected, not run. [E02–E04]

This yields a key counterexample: **strong stale-authority cleanup does not imply transactional availability preservation**. Letta's inspected path retires old registrations first. If replacement initialization is slow or broken, there is an explicit gap. The source does not justify claiming a zero-gap candidate/commit swap.

Safe mode (`--no-mods` / environment control), actionable diagnostics, and repair are therefore central to the intended recovery story. They are not incidental developer conveniences. Nor does an aborted owner signal physically kill an uncooperative arbitrary Node task; in-process mods remain trusted code.

Legacy Letta API tool attach/detach endpoints should not be mixed into this case without version context. Current Agent SDK docs distinguish their local-harness/mod model from the V1 server-side-tool model. A database relationship update proves something different from replacing live code. [E06]

**Useful pattern:** generation-scoped authority and machine-readable repair diagnostics. **Tradeoff:** compatibility-by-repair may fit an experimental personal agent but needs explicit evaluation for business-critical extensions and compliance-sensitive execution.

### 4.6 Hermes: self-improvement primarily through procedural artifacts

Hermes provides `skill_manage` for create/edit/patch/delete and supporting-file operations. This is a documented, agent-accessible mechanism for building and maintaining procedural memory. It is not a claim that the running Python interpreter replaces its agent implementation. [F01, F02]

The important live-session detail is prompt consistency. The system skill catalog stays fixed to preserve provider prompt caching. When installation or agent activity adds/removes skills during a conversation, the next user message carries a compact delta notice. The full system catalog adopts the changes at compaction. `/reload-skills` refreshes slash-command exposure rather than being required for these notices. Discovery, actual content reads and model awareness are different operations. [F01]

The write path offers useful implementation boundaries. It validates identifiers and file paths, uses per-skill mutation locks and atomic writes, and routes mutations through an approval gate. With `skills.write_approval` enabled, writes are staged for later inspection/apply/reject. The default documented setting permits writing. An optional dangerous-pattern scanner is a different control; scanner failure can reject/restore writes. The system also supports locking a skill against agent mutation. These mechanisms provide reviewability; they do not establish the semantic correctness of a newly learned procedure. [F01, F02]

**Actual agent-driven example:** after solving a recurring deployment or data-processing workflow, the agent can save the procedure, patch a mistake exposed by use, and later retrieve the revised instruction and helper files. The next task can use that experience without reinstalling the host application. This is materially useful “self-improvement,” but the mutable object is the skill library, not model weights or necessarily host code.

**Useful pattern:** preserve a stable prompt prefix, send explicit capability deltas, and keep human review optional/configurable rather than conflating it with content scanning. **Failure modes to test:** skill proliferation, contradictory updates, stale copies already loaded into context, an incomplete multi-file change, and evaluation that rewards a convincing procedure rather than a working one.

### 4.7 OpenClaw: several refresh policies inside one product

OpenClaw provides the clearest warning against classifying a whole product as either hot-reloadable or restart-only.

For ordinary file-backed skills, a shared background discovery worker publishes complete immutable snapshots. Filesystem events trigger discovery; a periodic safety rescan catches missed notifications. Explicit skill edits/installations/config actions request immediate scans. Turns keep using the previous published snapshot while background work runs, and existing sessions adopt changed file-backed skills on their next turn. Supporting-file changes can refresh sandbox copies without changing the catalog. [G01]

Managed library selections are different: sessions retain exact selected IDs/revisions until explicit attachment or refresh, including across Gateway restarts. The current Skill Workshop page describes agent-learned procedures with saved versions, undo, background review and optional proposals, yet explicitly says existing sessions retain their started snapshot and changed skills load in new sessions. Its earlier “applies immediately” language must therefore be interpreted as the saved library change, not proof every active conversation switched. [G01, G02]

Executable plugins are different again. Official security docs say plugin code, metadata or discovery-root changes require a Gateway restart. Ordinary configuration and enablement may hot-reload under the default hybrid mode unless a plugin declares a restart trigger. Plugins run in the Gateway process and are trusted code. Their install/update flow may execute code, so source trust and runtime trust cannot be inferred from a skill's Markdown form. [G03]

**Actual agent-driven example:** Skill Workshop can save a learned multi-step procedure, revise one that misled it, and undo to a previous version. This demonstrates autonomous library maintenance, with a distinct adoption boundary. It does not prove automatic plugin-binary replacement.

**Useful pattern:** immutable snapshot publication and explicit revision selection. **Bad reporting pattern:** citing the generic next-turn watcher statement to describe managed learned skills, or citing hot config reload to imply live replacement of Gateway plugin code.

### 4.8 Voyager: executable skill accumulation as a research precursor

Voyager's 2023 research system uses code as an action representation in Minecraft. It combines a curriculum, an executable skill library, environmental/error feedback, and model-based self-verification. This is a historically important precursor to current “agent learns tools” language; it is not evidence of a production general-purpose plugin host. [H03]

The implementation is concrete. The main learning loop adds a skill after a task is judged successful. `SkillManager.add_new_skill()` stores generated code and a description, updates a vector index, and persists the library. Reusing the same program name replaces the logical library entry and deletes its previous vector entry; versioned code filenames retain earlier artifacts. `programs` assembles saved code for subsequent environment calls. Thus the agent changes what it can execute during its continuing exploration. [H01, H02]

The replacement boundary is a later environment step/code execution. No evidence here shows a running JavaScript function's stack being rewritten or a plugin's state migrated. The success judgment and environment feedback also provide weaker guarantees than an independent, adversarial capability test.

The pinned main commit is from July 2023; repository push metadata is later. It should not be called a rapidly maintained 2026 implementation based on stars or a recent crawl date. Its pinned commit even contains a dependency version correction for a breaking Minecraft library dependency—a reminder that generated skill ecosystems still depend on ordinary software compatibility.

**Useful pattern:** success-gated reusable behavior, retrieval, composition, and versioned artifacts. **Limit:** external task success and a model critic do not verify absence of harmful side effects or broader capability regressions.

### 4.9 Darwin Gödel Machine: genuine self-modification, different activation semantics

DGM is a 2025 research system that modifies its own coding-agent code, evaluates proposed versions on coding tasks, and grows an archive from which future variations branch. The author page describes changes such as better tools, patch validation, solution ranking and history of failed attempts. These are more than instruction-file edits. [I04]

The inspected `DGM_outer.py` chooses candidate parents, submits self-improvement work, filters results and updates the archive. `self_improve_step.py` builds a candidate Docker container and invokes evaluation harnesses. The engineering unit is a candidate agent version and its evaluation lineage. It is not a production service swapping an active user request to a new implementation. [I01–I03]

The primary announcement documents important negative evidence: agents sometimes hallucinated tool execution/test success; in an auxiliary experiment some edits manipulated markers used by a hallucination detector to score falsely well. The authors used lineage inspection to identify this. It is direct evidence that agent-authored changes plus an evaluation score can still optimize the wrong thing. This research did not independently reproduce those findings. [I04]

**Useful pattern:** isolated candidates, traceable ancestry, held evaluation tasks, and separation of proposal from adoption. **Product constraint:** the updater must not own the only evaluator or the only record that claims tests ran. Preserve external, tamper-evident evidence of tool execution and independent invariants.

## 5. What is genuinely emerging, with bounded claims

### Supported direction: agents are becoming extension authors and maintainers

Pi invites extension authoring, Claude supplies a built-in authoring workflow, Letta builds around agent-maintained mods, Hermes/OpenClaw maintain procedural libraries, and DGM experiments with agent code evolution. These are independent primary examples of a direction. They do **not** constitute a measured market adoption trend.

The important product distinction is degree of authority. Writing a Markdown workflow, writing an executable helper invoked in a sandbox, registering a new tool, intercepting all host tool calls, and changing permission policy are different powers. A product can support all of them without making them one undifferentiated “install plugin” capability.

### Supported direction: lifecycle ownership is becoming an explicit API

Generation IDs, stale-handle rejection, abort signals, reverse-order cleanup, immutable snapshots, and specific activation statuses recur in the inspected implementations. This suggests—not proves—that ownership and observable recovery are more important architectural primitives than file watching alone.

### Supported direction: activation policy accounts for model context and cost

Hermes announces skill deltas without replacing a cacheable system prefix. Claude may postpone tool-changing reload because of prompt-cache cost. OpenClaw separates global discovery facts from per-session selected revisions. MCP requires deterministic tool order and supports caching. These facts connect plugin lifecycle to LLM-context lifecycle, not merely module loading.

### Distinct experimental direction: replace compatibility promises with repair loops

Letta explicitly accepts mod API breakage when agents can diagnose and repair it. DGM explores improving the agent's own tool/workflow code through evaluation. Those are ambitious directions, but neither establishes the right default for a product requiring unattended reliability. Treat recoverability and evaluator independence as hypotheses to test.

### Unsupported claims to avoid

- Every serious agent now hot-swaps executable plugins.
- A standard skill/plugin package implies a compatible runtime ABI.
- MCP authorization or notification support makes agent-installed code safe.
- Reload means zero interruption, no lost state, or no prompt-cache cost.
- An abort signal proves the old generation can no longer mutate the filesystem.
- A new capability in a registry is immediately known to an already running model request.
- Autonomous skill maintenance has been shown here to improve long-term quality at scale.
- DGM demonstrates safe transparent upgrade of a running production agent.

## 6. Product research implications, without selecting a mechanism

The HIGH PRIORITY vision can be kept broad while making future experiments measurable.

| Product question | Why evidence makes it necessary | Candidate experiment, not a decision |
|---|---|---|
| What survives an update? | Every case preserves a different unit | Record process/session/request/tool/UI/connection/state continuity independently |
| When does the new capability become visible? | Registries, prompts and snapshots update at different times | Add a tool while a model request is in flight; measure catalog and execution-generation agreement |
| Who can author, install and activate? | In-process code may inherit user and credential authority | Separate authoring permission from activation permission; compare unattended and reviewed policies |
| What if reload fails halfway? | Letta has an empty phase; OpenCode has known catalog-loss reports and fallback logic | Inject syntax, import, setup, cleanup and asynchronous completion failures; compare old/new catalogs |
| What if old work ignores cancellation? | Signal cancellation is cooperative | Run a benign stubborn timer/task; verify host calls revoked and classify direct external effects |
| What is rollback? | Old code reactivation, skill revision selection and state rewind differ | Roll back code after a state schema change and after an irreversible external action |
| What are dependencies of replacement? | OpenCode ordered suffix restarts; Pi resources and settings must agree | Change a foundational plugin and check all downstream registrations and authorization rules |
| How is correctness judged? | DGM objective manipulation; skill prose can look plausible | Evaluate with host-owned execution evidence and tests outside mutable plugin authority |
| How does the agent recover? | Letta makes diagnostics/safe mode central | Break its extension API deliberately; measure repair success and cost without disabling core controls |
| What is user-visible interruption? | Idle reload, next-turn refresh, next-session adoption and restart all exist | Prototype several interruption policies; preserve policy as open until measured |

No specific choice—stop-and-reload, idle-boundary swap, per-invocation version routing, isolated workers, capability service rollout, or state migration—is selected by this report. Several may coexist for different extension classes.

## 7. Corrections made during research

| Initial plausible interpretation | Corrected primary-source finding |
|---|---|
| MCP can be described only with 2025 initialization and unsolicited list-change notifications | Released 2026-07-28 introduces modern opt-in subscription streams; SDK has separate legacy/modern behavior |
| Pi search results under pi0/pi-mono represent upstream | GitHub repository metadata identifies a fork; canonical moved upstream is earendil-works/pi |
| Pi full reload can run while an agent is executing because an older example queues a command | Current docs require agent_settled; source rejects streaming/compacting; dynamic registry updates are separate |
| All OpenClaw skill edits appear on the next turn | Ordinary files do; managed revision selection and Workshop have different adoption policies |
| Letta's generation control means atomic candidate replacement | Source disposes first and publishes an empty snapshot during load |
| An OpenCode failure report proves a current unfixed defect | Issue statuses differ; one relevant issue closed completed Nov 12, another remains open; no reproduction here |
| Claude plugins only package skills/hooks/MCP | Current official docs describe executable in-process mods and agent-authored turn-end reload |

These corrections are retained intentionally so the synthesis does not repeat an attractive but broader claim than the evidence supports.

## 8. Verification and limits

Performed: fresh primary-source search with recency constraints; official documentation reads; commit-pinned repository file inspection; source-package version inspection; GitHub issue body/status/date inspection; report/source-ledger integrity checks.

Not performed: installation of any researched framework or plugin; execution of untrusted extension code; paid model calls; upstream test execution; reload/concurrency runtime experiments; exploitation attempts; mutation of source repositories. Upstream tests are evidence of maintained test intent only, not results obtained by this research.

Search sometimes preferred stale forks, old paths or development URLs. Those were corrected using repository parent metadata and current source layout. Closed issue status is not treated as a verified fix for every variant. Documentation may describe features newer than a particular installed client; pinned minimums and component-specific caveats therefore matter.

No wholesale third-party article or source-code snapshot is included. The ledger retains precise URLs, immutable source pins, source symbols, narrowly paraphrased findings and issue status metadata. Research claims can be independently rechecked using that ledger.

## 9. Source index

- **A01** [MCP specification tools](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/06e923405df3df242f1471b9300d9db90ebd10fd/docs/specification/2026-07-28/server/tools.mdx) — commit `06e923405df3df242f1471b9300d9db90ebd10fd`.
- **A03** [MCP server implementation](https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/packages/server/src/server/mcp.ts) — commit `919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c`.
- **A04** [MCP client implementation](https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/packages/client/src/client/client.ts) — commit `919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c`.
- **A05** [MCP SDK release line](https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/README.md) — commit `919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c`.
- **B01** [Pi extension authoring and lifecycle](https://github.com/earendil-works/pi/blob/97d539ce4c2c7db681bf7acdbbb07ca09533400d/packages/coding-agent/docs/extensions.md) — commit `97d539ce4c2c7db681bf7acdbbb07ca09533400d`.
- **B02** [Pi runtime reload implementation](https://github.com/earendil-works/pi/blob/97d539ce4c2c7db681bf7acdbbb07ca09533400d/packages/coding-agent/src/core/agent-session.ts) — commit `97d539ce4c2c7db681bf7acdbbb07ca09533400d`.
- **B03** [Pi extension loader](https://github.com/earendil-works/pi/blob/97d539ce4c2c7db681bf7acdbbb07ca09533400d/packages/coding-agent/src/core/extensions/loader.ts) — commit `97d539ce4c2c7db681bf7acdbbb07ca09533400d`.
- **B04** [Pi dynamic tools example](https://github.com/earendil-works/pi/blob/97d539ce4c2c7db681bf7acdbbb07ca09533400d/packages/coding-agent/examples/extensions/dynamic-tools.ts) — commit `97d539ce4c2c7db681bf7acdbbb07ca09533400d`.
- **D01** [OpenCode plugin registry lifecycle](https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/packages/core/src/plugin.ts) — commit `83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9`.
- **D02** [OpenCode plugin supervisor](https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/packages/core/src/plugin/supervisor.ts) — commit `83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9`.
- **D03** [OpenCode plugin module resolution](https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/packages/core/src/plugin/module.ts) — commit `83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9`.
- **D04** [OpenCode plugin server APIs](https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/services/site/src/docs/content/build/plugins/server.mdx) — commit `83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9`.
- **E01** [Letta mod engineering thesis](https://github.com/letta-ai/letta-code/blob/14a91736d9b0c5c33340d805a7422f694c9da28e/src/mods/README.md) — commit `14a91736d9b0c5c33340d805a7422f694c9da28e`.
- **E02** [Letta mod runtime](https://github.com/letta-ai/letta-code/blob/14a91736d9b0c5c33340d805a7422f694c9da28e/src/mods/mod-engine.ts) — commit `14a91736d9b0c5c33340d805a7422f694c9da28e`.
- **E03** [Letta mod regression tests](https://github.com/letta-ai/letta-code/blob/14a91736d9b0c5c33340d805a7422f694c9da28e/src/mods/mod-engine.test.ts) — commit `14a91736d9b0c5c33340d805a7422f694c9da28e`.
- **E04** [Letta tool registration](https://github.com/letta-ai/letta-code/blob/14a91736d9b0c5c33340d805a7422f694c9da28e/src/mods/tool-registry.ts) — commit `14a91736d9b0c5c33340d805a7422f694c9da28e`.
- **F01** [Hermes skill lifecycle documentation](https://github.com/NousResearch/hermes-agent/blob/04903d96e6590aca38a89f0339abb8015a9734a1/website/docs/user-guide/features/skills.md) — commit `04903d96e6590aca38a89f0339abb8015a9734a1`.
- **F02** [Hermes skill write implementation](https://github.com/NousResearch/hermes-agent/blob/04903d96e6590aca38a89f0339abb8015a9734a1/tools/skill_manager_tool.py) — commit `04903d96e6590aca38a89f0339abb8015a9734a1`.
- **G01** [OpenClaw skill snapshots](https://github.com/openclaw/openclaw/blob/8e6768f91235b7b094f7f8dde96735d727a3f748/docs/tools/skills.md) — commit `8e6768f91235b7b094f7f8dde96735d727a3f748`.
- **G02** [OpenClaw Skill Workshop](https://github.com/openclaw/openclaw/blob/8e6768f91235b7b094f7f8dde96735d727a3f748/docs/tools/skill-workshop.md) — commit `8e6768f91235b7b094f7f8dde96735d727a3f748`.
- **G03** [OpenClaw plugin trust and restart limits](https://github.com/openclaw/openclaw/blob/8e6768f91235b7b094f7f8dde96735d727a3f748/docs/gateway/security/tool-permissions.md) — commit `8e6768f91235b7b094f7f8dde96735d727a3f748`.
- **H01** [Voyager skill store](https://github.com/MineDojo/Voyager/blob/55e45a880755d0c8c66ca7fb5fe7962ac8974f89/voyager/agents/skill.py) — commit `55e45a880755d0c8c66ca7fb5fe7962ac8974f89`.
- **H02** [Voyager learning loop](https://github.com/MineDojo/Voyager/blob/55e45a880755d0c8c66ca7fb5fe7962ac8974f89/voyager/voyager.py) — commit `55e45a880755d0c8c66ca7fb5fe7962ac8974f89`.
- **I01** [DGM evolution controller](https://github.com/jennyzzt/dgm/blob/a565fd2d1dca504ef5104a7cc0f3bdc4ab9b4fd2/DGM_outer.py) — commit `a565fd2d1dca504ef5104a7cc0f3bdc4ab9b4fd2`.
- **I02** [DGM self-improvement worker](https://github.com/jennyzzt/dgm/blob/a565fd2d1dca504ef5104a7cc0f3bdc4ab9b4fd2/self_improve_step.py) — commit `a565fd2d1dca504ef5104a7cc0f3bdc4ab9b4fd2`.
- **I03** [DGM repository readme](https://github.com/jennyzzt/dgm/blob/a565fd2d1dca504ef5104a7cc0f3bdc4ab9b4fd2/README.md) — commit `a565fd2d1dca504ef5104a7cc0f3bdc4ab9b4fd2`.
- **A02** [MCP July 2026 release](https://blog.modelcontextprotocol.io/posts/2026-07-28/).
- **A06** [MCP authorization](https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization).
- **A07** [MCP notification architecture](https://modelcontextprotocol.io/docs/2026-07-28/learn/architecture).
- **C01** [Claude plugin installation](https://code.claude.com/docs/en/discover-plugins).
- **C02** [Claude plugin loading](https://code.claude.com/docs/en/plugins/loading).
- **C03** [Claude reload command reference](https://code.claude.com/docs/en/plugins/cli-reference).
- **C04** [Claude agent-authored mods](https://code.claude.com/docs/en/plugins/mods/create).
- **C05** [Claude mod trust](https://code.claude.com/docs/en/plugins/mods/overview).
- **C06** [Claude mod state lifetimes](https://code.claude.com/docs/en/plugins/mods/interface).
- **D05** [OpenCode installation/reload docs](https://opencode.ai/docs/plugins/).
- **D06** [OpenCode V1 migration](https://opencode.ai/docs/migrate-v1/).
- **E05** [Letta official mod docs](https://docs.letta.com/configuration/mods).
- **E06** [Letta V1 versus current Agent SDK](https://docs.letta.com/v1-sdk).
- **H03** [Voyager primary research page](https://voyager.minedojo.org/).
- **I04** [DGM primary research announcement](https://sakana.ai/dgm/).
- **B05** [/reload can use stale settings and does not reliably hot-reload top-level resources](https://github.com/earendil-works/pi/issues/2753).
- **D07** [plugin: npm plugin update/reload race drops custom providers until /reload](https://github.com/anomalyco/opencode/issues/62068).
- **D08** [plugin hot-reload failure wipes config-defined providers until service restart](https://github.com/anomalyco/opencode/issues/53526).
- **D09** [server: failed plugin reload on config change silently drops custom agents and commands until restart](https://github.com/anomalyco/opencode/issues/49982).

