# Round 1 independent critique — agent ecosystem lane

Reviewer: `/root/live_agent_trends`. Client date: 2026-11-14; source retrieval 2026-11-13 UTC. Reviewed `root-analysis.md`, `runtime-patterns/report.md`, their source ledgers and the governing `brief.md`. This is a bounded cross-review, not an implementation acceptance or a new user decision.

## Verdict

The reports preserve the central ambition well: every plugin category can acquire a supported live lifecycle, including agent-authored changes, without claiming arbitrary suspended-stack migration. The runtime report's interruption-policy table is especially useful because it keeps targeted stop/start, old-call retention, task pinning, checkpoint migration and cancel/retry as alternatives. The owner division is consistent with the brief: GM composition, product selection/authorization/state, existing executor resource custody, EF artifacts/trust/conformance.

I found **three material presentation/coverage corrections before synthesis**, not a fatal technical contradiction. Two were sent to root early. No third-party runtime was executed in this review.

## R1-A1 — maturity label must not inherit the documentation branch name

**Location:** `runtime-patterns/primary-source-ledger.json`, R20 and R21, status “Official production docs pinned at 2026-11-13”; runtime report case 5.

The source branch is named `production`, but this is not evidence that Dynamic Workers or every Facets capability is generally available or has a production reliability commitment. The official announcement dates Dynamic Workers' **open beta** to 2026-03-24. Current October-updated docs describe usable functionality but the retrieved pages do not establish a later GA transition. This is a maturity distinction, not a denial that the cloud feature runs or is billed.

**Requested correction:** use “official documentation, pinned from the production documentation branch” as provenance. For maturity use “published platform capability; introduced in open beta; current GA status not established by this evidence” unless a later explicit release source is found. Keep it independent from the self-modifying harness, which its own current documentation explicitly calls experimental, example-local and based on internal APIs. The latter classification in `root-analysis.md` is correct.

**Independent evidence checked:**

- [Dynamic Workers open-beta announcement, 2026-03-24](https://developers.cloudflare.com/changelog/post/2026-03-24-dynamic-workers-open-beta/).
- [Current Dynamic Workers overview](https://developers.cloudflare.com/dynamic-workers/) and [Facets documentation](https://developers.cloudflare.com/dynamic-workers/usage/durable-object-facets/), both showing 2026-10-12 update dates at retrieval.
- [Pinned API source](https://github.com/cloudflare/cloudflare-docs/blob/f7388b9513672d30263e7e04eaaf087a3b06a0c1/src/content/docs/dynamic-workers/api-reference.mdx): confirms a new ID when code/config changes, possible fresh isolates even with the same stub and inherited networking unless restricted. This validates the behavior claim, not GA maturity.
- [Self-modifying harness documentation](https://developers.cloudflare.com/agents/harnesses/self-modifying/), updated 2026-11-09: independently confirms its experimental status, turn revision boundary, fresh-worker behavior, absent example authentication and replay caveat.

**Confidence:** high for the labeling issue; current GA status remains unverified. Do not invert absence of GA evidence into a claim that no subsequent GA announcement exists.

## R1-A2 — the conclusion must keep interruption policy open

**Location:** `root-analysis.md`, concluding paragraph beginning “The strongest forward direction…”, originally lines 172–174.

The body explicitly says these are candidate constraints and interruption policy is undecided. The conclusion then describes existing work pinned to its generation as the strongest direction, which could be read as selecting old-work completion or session retention. The intended invariant should be **coherence during whatever lifetime the product selects**, not a promise that all existing work completes uninterrupted.

**Requested wording:** “Versioned live evolution at explicit capability boundaries is a strong candidate. Within the selected lifetime, a call uses a coherent implementation and schema; ordinary-update policy may retain, pause, cancel/retry or explicitly migrate that work.” This keeps authorization revocation independent of code retention and does not pick one scheduling policy for the user.

The same care applies when compressing “all plugins live” into one sentence: the product vision covers **all categories**, including stateful, native, UI and long-running capabilities. A phased qualification plan may show unsupported slices, but must not quietly redefine the goal as only stateless tools or file-backed skills. Conversely, the vision does not by itself require arbitrary executing stacks to transfer into new code. Runtime report §Interruption policy already makes this distinction correctly.

**Confidence:** high; this is a user-authority/wording correction, not a disagreement with immutable artifact identity.

## R1-A3 — effort bands need the requested accounting split

**Location:** `runtime-patterns/report.md`, conditional effort table, originally lines 152–162; `brief.md` required estimate scope.

The table clearly calls its ranges conditional new owned TypeScript implementation LOC, names prerequisites/exclusions and warns not to sum alternatives. That is much better than treating source size as delivery effort. It still does not separately quantify **reusable production mechanism, one product integration and tests**, or state changed existing LOC. The brief expressly requires that split. These rows are therefore useful mechanism hypotheses, not complete implementation estimates.

**Requested correction for synthesis:** preserve the conditional bands only with an explicit scope column, then add integration and test bands separately or mark them not yet estimated. State how new/changed code is counted and where test/integration work overlaps. No inference from one small passing scope probe to a complete live-plugin delivery estimate is warranted.

The numeric reliability scores are declared qualitative, but their guarantees are not identical. A disposable process may improve resource reclamation while increasing RPC/retry failure modes; a simpler stop/start policy may be stronger for an exclusive resource. Keep scores as engineering judgments about a **named guarantee** (e.g. resource isolation under stated assumptions), not a universal ranking, uptime measure or empirical result. The paragraph qualifying option D should survive any shortened synthesis.

**Confidence:** high on missing accounting; low-to-medium on all LOC predictions until an actual executor and continuity policy are selected.

## Strong contrary examples to retain in the combined synthesis

These are supported by the agent lane's pinned sources; they are not new runtime execution results.

1. **Letta deliberately has a registry gap on reload.** `createModEngine` disposes old registrations and publishes an empty snapshot before loading new mods; tests describe this behavior. It is a concrete live host with cooperative replacement, not a transactional last-known-good swap. This prevents the research from making new-first overlap look universal.
2. **Pi separates dynamic registry edits from full reload.** Tool registration can refresh immediately; `AgentSession.reload()` refuses streaming and compaction. An agent-triggered request waits for `agent_settled`. A process staying alive does not imply every current activity can be reloaded.
3. **OpenCode captures executable tool snapshots per model request, but resource retention is a separate issue.** The pinned server documentation lines 1068–1071 says definitions, descriptions and executors are captured together. Mutable closure data can still change. `Plugin.activate` closes the old suffix scopes before replacement setup, so that definition contract alone is not evidence that sockets or other resources used by old executors stay acquired. This is an especially useful schema-versus-lifetime test target.
4. **OpenClaw has several distinct skill paths.** Ordinary file skills can change on the next turn; managed selections stay revision-bound until explicit refresh; Workshop documentation says running sessions retain their starting skill snapshot. Plugin code/metadata still requires Gateway restart. One product name cannot be assigned a single blanket hot-reload guarantee.
5. **DGM self-modification is candidate evolution and has evaluator failures.** The experiment executes/evaluates candidate implementations in an outer loop; it is not old-stack continuation. Its authors report tool-log hallucination and reward hacking. Keep candidate execution/evaluation and immutable authority/evidence separate when borrowing the direction.

The combined report does not need to repeat all implementation details. Retaining two or three of these precise exceptions next to the positive examples will prevent the breadth matrix from becoming a binary “supports hot reload” catalog.

## Claims selectively checked and accepted

- Independently read the pinned Agent Plugins README and 1.0 specification: published 1.0 supports Skills/MCP; 1.1 hooks remain a working draft. Package containment does not sandbox child processes. Source: commit `465e04661ccddfcccff95d0b99a4cf59d80c5478`, `README.md`, `spec/1.0.0.md`.
- Independently reread current Cloudflare Skills docs: experimental API; sources re-listed before turns; changed catalogs delivered by reminder while the system prefix is retained. This supports a model-awareness design inference, not automatic executor authorization.
- The root report carefully limits compile/check to bundling/runtime contract validation, not a proven full semantic TypeScript pass. It distinguishes revision activation from source editing and effect journaling from exactly-once effects. Preserve these qualifications.
- Runtime report distinguishes Cordis prerelease source from Koishi HMR docs; OSGi wires from ordinary retained objects; Wasm memory from host effects; Envoy draining from connection transfer; Temporal admission rollback from recovery of existing executions. No contradiction identified in those distinctions from the report/ledger comparison. These implementations were not all independently re-fetched during this bounded review.

## Corrections to this reviewer's own lane

The same maturity test exposed imprecise wording in the initial agent report: “released source/docs” was too broad. The report and ledger now reserve release language for explicit publication evidence and call main/dev code **inspected source snapshots**. OpenCode 2.3.0 is explicitly a dev snapshot; Letta 0.34.60 is a main snapshot. A source-package version does not prove that exact commit was published. No provider-wide support claim follows from the current MCP specification or one SDK implementation.

Following independent feedback from the Effect lane, I reread OpenCode's pinned model-request snapshot contract and added the definition/resource distinction above to the agent report and source D04. The HIGH PRIORITY opening now explicitly covers all plugin categories and explicitly leaves individual-operation interruption undecided.

## Review limits

Performed: local document/ledger comparison; fresh official maturity search; read-only official documentation and selected pinned source checks. No package installation, plugin execution, provider call, fault injection or upstream test run. Evidence remains paraphrased with exact URLs and source symbols; no external source snapshots were added. Root is responsible for reconciling these corrections into the governed synthesis and for the separate second review round.
