# Final research dispositions

Owner: root synthesis. Research observation: client 2026-11-14.
Scope: non-normative evidence and recorded product vision; no implementation,
release, merge or ordinary-update interruption decision.

## Round 1

| Finding | Disposition |
| --- | --- |
| Documentation branch named production and main/dev package versions do not prove publication/GA | Corrected lane ledgers, English/Russian reports and synthesis. Cloudflare platform introduction is open beta; later GA status unverified. Experimental harness remains distinct. |
| Unconditional old-generation completion language could decide interruption | Corrected root and Effect conclusions. Coherent code/schema selection is the candidate invariant; lifetime/interruption is explicitly open in OD-003. |
| Runtime owner table could assign artifact identity to GM | Corrected runtime and synthesis: GM composes supplied factories; EF/product owners bind admitted executable identity. |
| Cost bands mixed mechanism, integration, tests and missing existing primitives | Runtime report explicitly retains hypothetical P-only budgets with I/T/changed code unestimated. It withdraws broad overlap C for current native path. Effect report and synthesis split narrow P/I/T with prerequisites and exclusions; reuse counts zero. |
| Reliability scores compared different guarantees | Runtime report names each guarantee; native/Promise comparison rates the same bounded operation/resource contract. Scores remain engineering judgments, not uptime. |
| Positive OpenCode schema/executor snapshot contract was omitted | Added concrete source-backed paragraph and direct pinned server-contract reference. Resource retention is not inferred from retained executors. |

## Round 2

All three specialist lanes reported no remaining blocking vision/semantic
finding. Root incorporated the remaining precision changes rather than
launching a third review or rerunning unchanged experiments.

| Finding | Disposition |
| --- | --- |
| Persistent-session category said retained old authority | Replaced with retained resource lifetime and current call authority. Added first-kernel restriction: retained custody does not grant new calls after owner retirement. |
| Git source and installed package comparison could sound tree-wide | Narrowed to separate identities and hashes; retained full ScopedRef diff changes documentation, while executed distribution bytes are independently hashed. |
| Combined P+I costs obscured account split | Added inline non-overlapping P/I/T table and conditional migration increment. Existing changed LOC remains unaudited; no whole-product quote. |
| MCP paragraph mixed invalidation with model refresh | Protocol/SDK invalidation and consuming-host model-surface responsibility are distinct. Added pinned client source. |
| Several nearby citations did not support exact implementation/status claims | Added Claude loading/trust, Pi runtime guard, Hermes write source, OpenCode closed issue and Dynamic Workers beta announcement. |
| Directional language suggested measured growth | Reworded to multiple current systems supporting agent-authored extension. No adoption-rate or winner claim. |
| Live ambition could be narrowed to easiest first slice | All categories remain explicit. Incremental qualification is coverage planning, not a redefinition of the vision. Targeted plugin restart can preserve application life; whole-application restart alone does not satisfy the target. |

## Experiment review

The Effect lane planned a small discriminating real-resource experiment. The
runtime lane reviewed its plan before execution and required independent file
read/EBADF and cause oracles, Deferred ordering and explicit scope finalization.
The final fixture has four scenarios only. The typed startup-failure control,
old-finalizer defect, closed-value reader and scoped-borrowing positive control
are retained together. Native TypeScript 7.0.2 and Node tests passed.

The runtime reviewer subsequently inspected all 166 fixture lines, the raw TAP
and package/distribution/fixture hashes without rerunning the tests. Its JSON
review records matches and scope. This independently corroborates the retained
result identity, not an independent experiment replication. Root also read the
complete fixture and manifest. No claim of full route publication, migration,
authorization, exclusive handoff, forced preemption or fleet load was added.

## Remaining open work

Ordinary-update interruption policy remains the user's explicit TODO. A concrete
consumer/runtime and its first supported category remain to be selected before
implementation. Accepted ADRs and library publication/adoption are not changed
by research. Embedded TypeScript 5.9.3 in EF's general tooling remains a separate
documented gate conflict; no workaround, dependency downgrade or hidden rerun
was used to label it compliant.
