# Round 2 bounded synthesis review — agent ecosystem lane

Reviewer: `/root/live_agent_trends`. Client date 2026-11-14. Reviewed the maintained `docs/research/live-plugin-evolution-vision-and-evidence-2026-11-14.md`, OD-003's new vision/TODO section, and the updated agent-lane EN/RU reports and 46-source ledger. This round reused already retrieved pinned evidence; no additional broad research or runtime tests were performed. Root files were not edited by this reviewer.

## Verdict

**No blocker remains in the user-vision or interruption-policy framing.** The synthesis and OD-003 retain a high-priority direction covering all plugin categories and agent-authored changes. They explicitly avoid deciding whether an ordinary update interrupts current work. The existing controlled-restart baseline is preserved as a delivery baseline, with successor decisions required for conflicting accepted mechanisms. The category matrix does not silently narrow the ambition to stateless tools.

The updated maturity language is substantially correct. OpenCode is labeled a dev source snapshot, package publication is not inferred, MCP publication is distinguished from client implementation, and the experimental Cloudflare harness is separate from the underlying platform. The beta/GA uncertainty identified in round 1 is now visible.

Two material **documentation precision changes** remain recommended before publication: include the directly relevant executable tool-snapshot evidence, and attach supporting citations to the exact claims. Neither requires another experiment or architecture decision.

## R2-A1 — make the model-schema/executor precedent concrete

**Location:** current agent ecosystem table and the paragraphs that follow, originally synthesis lines 99–124. The architecture section already states the right proposed invariant, but the concrete current example remains implicit.

**Recommended insertion:**

> OpenCode's inspected V2 documentation gives a concrete model-request boundary: tool definitions, descriptions and executors are captured together, and later transforms, reload and disposal affect future snapshots. An executor can still observe mutable data captured by its closure. This binds a presented definition to an executable function, but it does not prove that the function's old sockets or other resources remain acquired: the activation path closes old plugin scopes before replacement setup. Definition retention and resource retention require separate evidence.

Sources:

- [Pinned OpenCode server contract, lines 1068–1071](https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/services/site/src/docs/content/build/plugins/server.mdx#L1068), ledger D04.
- [Pinned activation implementation](https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/packages/core/src/plugin.ts), ledger D01, `Plugin.activate`.

This is not a new continuity guarantee for this product. It is primary evidence for the proposed schema/execution check, and simultaneously a counterexample to equating stable executor references with live resource retention. The Effect lane independently identified this passage; I reread it against the same pinned file and added it to our report/ledger.

**Disposition:** root notified; ready-to-use wording supplied. Recommended for the final synthesis, no further test required.

## R2-A2 — make citations support the nearby implementation/status claims

All reference-style links in the synthesis resolve to defined reference keys. The following are semantic citation gaps, not broken-link syntax:

| Claim in synthesis | Current limitation | Precise source to attach |
| --- | --- | --- |
| SDK modern/legacy subscription behavior and fresh reads | Paragraph cites the protocol, while the table cites server source; neither alone establishes the inspected client implementation | [MCP client at pinned SDK commit](https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/packages/client/src/client/client.ts), A04: `ClientOptions.listChanged`, `_setupListChangedHandlers`, modern subscription setup |
| Claude components may need a new session | Current create/state links do not directly establish all component-loading limits | [Official plugin loading rules](https://code.claude.com/docs/en/plugins/loading), C02; retain the distinction between mods and installed plugin components |
| OpenCode #49982 closed completed November 12 | Nearby O2 points only to #62068 | [Issue #49982](https://github.com/anomalyco/opencode/issues/49982), D09; preserve “not reproduced locally” |
| Dynamic Workers introduced in open beta | API/facet documentation describes behavior but is not the release-status announcement | [Official March 24 open-beta announcement](https://developers.cloudflare.com/changelog/post/2026-03-24-dynamic-workers-open-beta/), already checked in round 1 |
| Pi full reload rejects streaming/compaction | Extension docs establish the settled example; the explicit guard is in runtime source | [AgentSession source](https://github.com/earendil-works/pi/blob/97d539ce4c2c7db681bf7acdbbb07ca09533400d/packages/coding-agent/src/core/agent-session.ts), B02, `reload` |
| Hermes atomic skill writes | The cited skills docs establish delta notices and the optional gate; write atomicity is source evidence | [Skill manager implementation](https://github.com/NousResearch/hermes-agent/blob/04903d96e6590aca38a89f0339abb8015a9734a1/tools/skill_manager_tool.py), F02 |

For MCP, separate two layers in the wording: the protocol invalidates the list; **the host integration must refresh the model-visible catalog for its own consistency guarantee**. The SDK/protocol do not automatically ensure a model request adopts a changed definition or confer installation authority. Notifications are opt-in and best effort in the reviewed modern path; this is not a claim that every MCP client/server supports it.

**Disposition:** root notified of the material citations. Sources are already retained; no new broad retrieval is needed. Adding direct references avoids making the evidence archive the only way to recover support for specific maintained-document claims.

## Nonblocking precision suggestions

1. “Agents increasingly author their own extension surface” is plausible directional interpretation, but the evidence is a selected cross-project case set, not a measured growth series. “Several current systems explicitly support agent-authored extensions” is more exact and consistent with the no-adoption-statistics caveat.
2. The positive same-process CLI examples should retain their trust limit in at least one synthesis sentence. Claude documents mods as trusted code with the user's process privileges; Bash sandboxing does not generally sandbox arbitrary mod code. Letta also describes trusted local mods. Scope cleanup, abort signals and permission interfaces are not isolation of arbitrary OS effects. Sources are C05, [Claude mod overview](https://code.claude.com/docs/en/plugins/mods/overview), and E05, [Letta mods](https://docs.letta.com/configuration/mods). The candidate product authority rules are stronger requirements, not guarantees inherited from these projects.
3. Keep the current concise caution that source/main package versions do not prove publication. A central caveat plus explicit “source”/“dev” table labels is sufficient; no need to repeat it in every sentence.

## Round 1 dispositions confirmed

- **R1-A1 maturity:** addressed in synthesis. Cloudflare platform row says introduced in open beta and current GA status unestablished; experimental harness remains separately labeled. Add the release citation above.
- **R1-A2 pinning:** addressed. Synthesis says settle old work according to explicit policy, and later defines coherence without mandatory uninterrupted lifetime. OD-003 explicitly defers wait/pause/cancel/migrate choices.
- **R1-A3 estimates:** substantially addressed in maintained synthesis. It separates runtime alternatives from the small Effect/Promise integration estimate, states production/integration versus test LOC, excludes large delivery surfaces, and calls changed existing LOC unestimated until a consumer is selected. The archived lane breakdown remains required for the reusable-mechanism versus one-product split. This review does not validate the numerical predictions.
- **Own-lane maturity:** EN report and JSON ledger corrected. During round 2 the RU page was also tightened: all plugin categories explicit, operation interruption open, source snapshots labeled, Pi reload rejection separated from the example's waiting behavior. This removes residual translation shorthand that could overstate the mechanism.

## Validation and limits

Performed: bounded document comparison, source-ledger mapping, reread of already retrieved OpenCode/MCP/Pi/Hermes primary source passages, and a mechanical check that synthesis reference keys are all defined. No runtime/package/provider execution and no new performance or reliability evidence. The four-case Effect experiment is a separate lane's retained result, not a test rerun or independently repeated by this reviewer. With R2-A1/A2 disposition recorded, no further agent-ecosystem review round is requested.
