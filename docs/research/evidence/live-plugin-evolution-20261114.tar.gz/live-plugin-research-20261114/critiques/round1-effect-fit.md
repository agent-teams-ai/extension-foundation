# Round 1 independent review — Effect/GM fit lane

Reviewed: `root-analysis.md`; `runtime-patterns/report.md`; `agent-trends/agent-ecosystem-report.en.md`, with direct re-reading of pinned OpenCode sources below. Review concerns ownership, true lifetime guarantees, conditional estimates and preservation of the user's open interruption policy. No production changes or additional experiment were performed.

## Overall result

The three reports support a coherent research conclusion: immutable executable/composition revisions, an explicit selected unit of work, and existing product/executor owners are a strong candidate direction. None supports arbitrary in-place state/stack migration or universal zero-interruption replacement. Their broad vision should remain a high-priority product direction rather than an implementation decision.

No blocking factual error was found in root's principal Cloudflare/portable-package interpretation or in the OpenCode suffix/fallback description. Two ownership/estimate corrections and one stronger OpenCode counterexample should be resolved before synthesis.

## Findings to address

### R1 — Keep artifact identity/loader outside GM (medium)

The runtime report's responsibility table gives GM “Resolve/build immutable plugin composition” and says it should return a “composition/artifact descriptor.” GM owns inert selection, validation and construction from supplied factories. Its accepted source explicitly excludes artifact trust, executable discovery and product generation identity. The word “artifact” can accidentally make GM the authority for code/import closure.

Suggested correction: GM returns the verified composition/typed construction capability; the existing product artifact owner binds that composition and factory identity to an immutable admitted executable descriptor. Do not add artifact loading, trust or promotion to `@get-modular/effect`.

Evidence: current Get Modular ADR-0043 and CMS “Optional dynamic Host lifecycle candidate”; exact pin `6c91ff1c3c8ce7088db215af9705f7ee3a9db103`. The lowering code creates private Layer identities and closed providers, not artifact IDs or a live dispatch map.

### R2 — Reconcile estimate scope with existing kernel/native mechanisms (medium)

The runtime report estimates 1,000–1,900 owned implementation LOC for overlapping in-process generations, whereas the Effect report estimates a smaller incremental local use-boundary integration after reusing existing CMS/kernel/native resources. These are different scopes. Neither range should become an apparent product-wide forecast, nor should they be added.

The current implemented lifecycle-kernel already owns stage/active/quiesce/retire, distinct call/custody tokens, check/release, and retained-work refusal; its core is 135 source lines. Effect supplies scoped resource acquisition and borrower counting. Subtract these mechanisms before estimating new code. Runtime estimates should split new mechanism P, one consumer integration I and tests/fixtures T as the organization standard requests, or explicitly state that those parts were not estimated separately. Existing executor support can reduce incremental mechanism code to zero.

The broad runtime scenarios D/E include substantially different process/protocol/durable-state concerns, so their higher numbers do not contradict the narrow native integration estimate. Final synthesis should present conditional scope-specific bands, not one “full live-plugin implementation costs N LOC.” No lane audited all current product executor/provider paths, and that work is changing elsewhere.

### R3 — Preserve a positive OpenCode consistency guarantee, without inventing a resource lease (medium)

Directly re-read OpenCode `83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9`:

- `packages/core/src/plugin.ts`, blob `d6b11356ed18bcf8dc6afa6606c0dc72d1fffd52`: lines 122–176 compute unchanged prefix, close changed suffix in reverse order, log cleanup failures, then attempt replacement and reactivation fallback. This supports the report's description. It does not establish per-invocation drain.
- `packages/core/src/plugin/supervisor.ts`, blob `c5f320e4c80073b1772b93ea3e1ff2ea41606ec9`: failed module resolution retains the prior running generation; one consumer serializes/coalesces activation; generation checks reject stale asynchronous update-check results. This supports the report and limits the meaning of “rollback.”
- `services/site/src/docs/content/build/plugins/server.mdx`, blob `aaca94624ec0e491b89ab5d7c64afaa370badb73`: lines 1035–1036 distinguish transform replay from plugin setup. Lines 1068–1071 explicitly state a stable executable tool snapshot per model request: later transforms/reload/disposal do not rewrite captured definitions or executors, but captured mutable plugin data can still change.

The last guarantee is stronger than merely “old reads are snapshots” and is useful counterevidence against portraying all current systems as oblivious to model-schema/executor consistency. Include it. Equally, do not turn it into a claim that all resources reachable from that executor remain alive: `Plugin.activate` closes old activation Scope before new setup, and docs about retained executors are not an ownership proof for their captured FileHandles/connections.

No source in this review establishes a full old-generation resource lease for those captured executors. Do not label this a defect without the missing executor/Host lifetime investigation; state the evidence boundary. This is directly analogous to the new Effect primitive experiment, where retaining the object alone did not retain the resource.

Primary URLs:

- https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/packages/core/src/plugin.ts#L122-L176
- https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/packages/core/src/plugin/supervisor.ts#L54-L86
- https://github.com/anomalyco/opencode/blob/83960f8a56b2f2b8ad0b751f23baaf9d0eb65ad9/services/site/src/docs/content/build/plugins/server.mdx#L1035-L1071

## Root synthesis strengths and refinements

Root correctly separates source editing, activation, operational selection, authorization and retirement; keeps the self-modifying Cloudflare example experimental; distinguishes its runtime shape checking from strict TypeScript checking; and warns against self-update waiting for its own drain. The immutable turn revision and current-grant distinction are especially useful.

Two refinements for final prose:

1. “One generation per declared unit of work” means one coherent composition pin, not independently resolving “latest” for each dependency halfway through a turn. Selection, admission and resource retention must be one acquisition step before yielding. This gives a one-JS-agent linearization point only; it is not distributed atomicity.
2. Keep preservation through completion conditional. Under a chosen interruption policy, the same ownership requirement is to retain resources until the actual operation settles after cancellation. Do not accidentally promise every existing agent operation completes uninterrupted. Existing work may pause/retry/fail according to a future explicit category policy while the application and agents remain running.

## Updates made to this lane after critique

The Effect report now uses “Research conclusion,” marks continuous pinning conditional, separates P/I/T bands, distinguishes security grants from kernel call authority, and makes the facade a product-owned boundary where needed. It explicitly reuses actual executor hooks and forbids duplicate editable phase/count state.

The four-case fixture was not expanded beyond its approved scope. Its first case includes a deterministic reader during old finalization. Strict TS7.0.2 and runtime logs already passed; no redundant suite was rerun. The peer runtime lane reviewed the plan and separately inspected the resulting evidence.
