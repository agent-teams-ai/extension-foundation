# Round 1 independent critique — runtime patterns

Reviewer: runtime-patterns lane. Scope: `agent-trends/agent-ecosystem-report.en.md`, `root-analysis.md`, and independent inspection of `effect-fit/spike/lifetime.test.ts`, raw results/configuration/diff and evidence manifest. No experiment was rerun. No root-owned file was edited.

## Result

The two reports preserve the owner's broad, high-priority live-plugin vision and keep the ordinary-update interruption policy open. Their principal distinctions are sound: discovery, refreshed model schemas, registry mutation, executable-generation replacement, stable durable state and migration of running work are separate claims. No blocking factual/ownership problem remains in the versions inspected. The following qualifications must survive synthesis.

## Agent ecosystem critique

1. **Current source versus released behavior is sufficiently explicit.** OpenCode 2.3.0 is labeled dev-source; Pi/Letta package versions are source snapshots; Claude mods are official operational documentation without a proprietary host-source audit; Voyager and DGM are research prototypes. The maturity legend correctly says package.json version alone is not release evidence. MCP is separately described as a released specification. Preserve these labels when compressing the comparison.
2. **Positive executable-snapshot evidence matters.** OpenCode's per-model-request snapshot includes definitions and executors, which is stronger than a catalog refresh. Its setup lifecycle still closes old plugin scope before replacement, so this is not proof that all resources captured by an old executor remain alive. The revised report explicitly preserves both observations. Do not label this an established resource bug without inspecting the actual consuming executor/lifetime path.
3. **Fallback is reactivation, not old-instance continuity.** The OpenCode report distinguishes module-resolution failure retaining an existing generation from failed setup reconstructing old code after scope closure. Letta instead exposes an empty registry interval and stale-completion rejection. Those are materially different failure contracts; a synthesized “all support rollback” statement would be wrong.
4. **Same-session does not mean current-call replacement.** Pi's registry mutation can occur after startup, while full reload rejects streaming/compaction and the agent-driven example waits for `agent_settled`. Claude's turn-end adoption and surface-specific monitor/MCP restrictions are appropriately separate. The original call frame can continue with old code after a reload; invalidated context is not physical termination of arbitrary Node execution.
5. **Skills deserve their own legitimate category.** Hermes/OpenClaw procedural updates satisfy meaningful live instruction evolution but not host binary replacement. OpenClaw ordinary next-turn snapshots, managed selected revisions and Workshop new-session adoption remain distinct. The report avoids shrinking the user's all-plugin goal to the easiest skill case.
6. **Model awareness and authority are separate.** MCP notification/discovery requires client propagation into a future model request; no protocol event automatically installs code or grants scopes. Exact schema-generation pinning is an experiment proposal, not an adopted MCP field. Agent authorship must not silently authorize privileged activation.
7. **Rollback of external state remains outside all of these generic mechanisms.** Restored source/skill revision or reactivated old code may be incompatible with a database already changed by the candidate. Existing work may require cancellation/retry/compensation under a later selected policy. The report states this limitation and should retain it.

Public issue status is handled carefully: read reports are not local reproductions; closed-completed/not-planned does not prove all variants fixed; current-open does not prove every latest source build fails. The report's negative claims remain bounded.

## Root analysis critique

- Agent Plugins 1.0.0 published versus 1.1.0 draft is distinct from executable lifecycle; manifest permission requests are not effective authority. Good.
- The Cloudflare self-modifying harness is explicitly experimental/example-local and unauthenticated. Fresh worker validation is runtime manifest/shape checking after bundling, not a demonstrated strict TypeScript semantic check. Immutable turn revision selection, activation receipt and host-side journal are concrete mechanisms, but journal gaps mean interrupted effects can repeat. The report does not infer exactly-once effects.
- Module Federation forced registration/cache clearing does not own component unmount, retained callbacks or application state migration. Node ESM cache identity does not own resource lifetime. Both boundaries are correctly stated.
- The proposed replacement cohort must capture coherent dependencies for the selected unit, not independently resolve latest capabilities midway through an operation. Root's later synthesis strengthens this appropriately.
- Selection/retention must form one acquisition step under the existing owner. This is a local concurrency requirement; it is not proof of distributed atomicity. Product authorization can still revoke current grants even when code is pinned.
- Self-update must not await retirement of the generation containing the updater call. A receipt plus a stable existing owner avoids self-drain deadlock. This is an operational insight, not a reason to invent a global supervisor.

## Independent Effect result review

Read the entire 166-line fixture, `tsconfig.json`, raw TAP log, empty stderr/typecheck logs, retained ScopedRef source diff, and manifest. Hash-only verification checked seven retained fixture/config/log/diff files including byte sizes, eight installed compiled Effect modules, and three installed package manifests. **18/18 checked entries matched.** Exact verification output is `runtime-probe-hash-review.json`. This confirms custody of the read evidence; it is not a new execution. Compiler execution exit zero is recorded by the retained manifest and its strict configuration; an empty log alone would not establish it.

| Case | Independent oracle inspected | Supported conclusion |
| --- | --- | --- |
| ScopedRef old borrower and reader during set | Real file reads establish initial liveness; Deferred barriers hold old finalizer after actual close; `stat` rejects with EBADF; reference identity checked before/after publication | Bare ScopedRef replacement is not a borrower lease, and an overlapping read can return the old already-closed handle in this version/path |
| Typed candidate acquisition failure | Candidate FileHandle acquired before typed Fail; exact typed reason asserted with no Die/Interrupt; candidate EBADF, old identity/readability and absence of old close checked | This acquisition-failure path preserves old usable resource and cleans partial candidate |
| Old finalizer closes then defects | Physical close precedes exact sentinel Die; old-current identity and EBADF checked; candidate EBADF checked; old/candidate close events exactly once | Failed replacement does not guarantee a healthy rollback; exact defect remains observable |
| RcRef invalidate with scoped borrow | Invalidate completes before fresh acquisition; handles distinct; both read successfully; scopeA closure produces old EBADF while B still reads; final closures exactly once | Existing scoped borrow retains old resource through invalidation while later borrow gets fresh resource |

Raw TAP reports four tests, four pass, zero failed/cancelled/skipped. Tests use no scheduling sleeps; timeouts merely bound hangs. The fixture does not implement a fake plugin manager. Matching runtime output plus assertions supports all four reported observations without extrapolating them to arbitrary concurrency schedules.

Limits: no router/publication transaction, readiness-before-publish, incompatible state migration, security grant, hard preemption, physical process absence, worker fleet behavior or all-plugin qualification was tested. RcRef invalidation is not a ready-before-publish swap, and its owning scope must outlive retained borrowers. Installed package bytes and Git source are correctly distinguished; the decisive ScopedRef diff contains overload JSDoc additions. No universal package-tree byte identity is asserted.

## Corrections accepted in the runtime lane

- R20/R21 and the report now call Cloudflare a published platform capability, introduced in open beta on March 24; current GA status is unverified. The official announcement was independently opened. A documentation branch named production is provenance, not maturity/SLA evidence.
- Artifact binding/trust/import identity belongs to EF/product artifact ownership. GM validates/builds closed composition from supplied factories and exposes typed construction, not artifact authority.
- LOC figures are explicitly hypothetical P mechanism-only budgets; I, T and changed-existing LOC remain unestimated in that table. Ratings name the guarantee being judged. Existing 135-line kernel and native Scope/RcRef primitives count as zero new code. The broad C budget is withdrawn for the actual existing-native path and is not added to the narrower Effect lane P/I/T estimate. Literal arithmetic subtraction from a speculative broad band would give false precision.
