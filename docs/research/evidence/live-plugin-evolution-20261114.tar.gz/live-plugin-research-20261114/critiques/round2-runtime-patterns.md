# Round 2 bounded final synthesis review — runtime patterns

Reviewed final synthesis `extension-foundation/docs/research/live-plugin-evolution-vision-and-evidence-2026-11-14.md` and the owner-prioritized vision/TODO section of OD-003. Reviewed the four-case Effect evidence once by reading and hashes only, as recorded in `round1-runtime-patterns.md` and `runtime-probe-hash-review.json`. No test rerun, root-file edit, external mutation or new implementation.

## Verdict

**No blocking resource/state/ownership finding.** The synthesis faithfully records the broad vision without selecting ordinary-update interruption semantics. It distinguishes current implementation evidence from production qualification, keeps artifact identity outside GM, reuses existing owners, and bounds the native Effect experiment and cost estimates.

## Required boundaries checked

| Check | Result |
| --- | --- |
| All plugin categories remain the vision | Pass. Category matrix includes pure contributions, tools, UI, sessions/streams, jobs/listeners, exclusive/native resources and durable workflows; incremental qualification does not redefine the target |
| No implicit ordinary-update interruption choice | Pass. Scope and OD-003 explicitly defer finish/pause/cancel/checkpoint policy; targeted plugin restart is conditional; emergency revocation/deadlines retain existing authority |
| Immutable composition versus live product selection | Pass. GM builds closed compositions; EF/product owns code/import identity/trust; product selects admitted revision; no mutable GM graph or public universal SPI is selected |
| Single resource owner | Pass. Existing Host/executor owns physical cleanup; kernel facts and native resource leases are distinct and not duplicated; no new universal supervisor is proposed |
| Definition consistency versus resource retention | Pass. Captured schema/executor/cohort and current grant checks are explicit; retained objects do not automatically retain external resources |
| State/rollback semantics | Pass. Cordis import and activation failures differ; OSGi stale refs, Erlang purge, Cloudflare abort-with-SQLite, Envoy old connections and Temporal pinned recovery all remain bounded |
| Cloudflare maturity | Pass. Underlying published platform/open-beta provenance is separate from experimental harness; current GA status unverified |
| Four-case native experiment | Pass. All four table observations are supported by inspected fixture and raw TAP. No wrapper test is sold as full lifecycle proof. RcRef readiness/owner-lifetime caveats are retained |
| Cost/exclusions | Pass for research framing. Current-Host narrow integration differs from broad mechanism scenarios; tests, excluded loading/distribution/migration/platform work and unaudited changed LOC remain explicit |

## Nonblocking wording/refinement

An earlier inspected category row used “retained old authority” for persistent sessions/streams. Prefer “retained generation; current authorization” or “retained call/custody rights under current authorization” so a reader does not infer frozen security grants. Surrounding prose already explicitly says code selection does not freeze grants; this is a local wording refinement, not an architecture defect.

OpenCode's positive per-model-request executable snapshot should remain visible alongside the old-scope teardown limitation. It is useful evidence that schema/execution consistency is already implemented in a concrete system, while no general resource lease follows. Root reports this addition is included in the finishing synthesis.

The selection-and-retention acquisition statement is valid under one existing local owner. Do not later reuse it as a distributed publication guarantee without that owner's protocol. The current exclusions already keep distributed rollout/admission outside the local estimate.

## Evidence review disposition

Seven retained evidence files (including fixture, strict TS config, raw logs and decisive source diff), eight installed compiled Effect modules and three package manifests matched their recorded SHA-256 values, with retained byte sizes also matching: **18/18**. Fixture is exactly 166 lines. Raw TAP has four passes and zero failed/cancelled/skipped tests. This review did not rerun the experiment or verify every possible package-tree file; it establishes the exact checked assets and supports the bounded observations.

No finding justifies expanding the probe. Next experiments should exercise the real consumer's model-schema/executor binding, actual resource lifetime and one required exclusive resource, as synthesis proposes. Migration/replay experiments should wait for the stronger continuity policy to be selected.

## Own lane readiness

`runtime-patterns/report.md` and `primary-source-ledger.json` now incorporate the round1 Cloudflare maturity, EF/GM ownership and mechanism-versus-delivery corrections. The broad C budget is explicitly inapplicable to the already-native current Host, existing kernel/Scope/RcRef mechanisms count as zero new code, and unestimated integration/tests/changed LOC are identified. Ready for the archive freeze with these corrected bytes.
