# Round 2 synthesis review — Effect/GM fit lane

Reviewed read-only: `extension-foundation/docs/research/live-plugin-evolution-vision-and-evidence-2026-11-14.md` and OD-003's owner-prioritized live plugin vision/open interruption section. No runtime rerun, root-file edit, dependency change or production mutation.

## Disposition

The synthesis is substantively sound. The four-case Effect result is accurately reported and bounded. Exact source versus installed package identity, candidate versus npm publication, one existing Host, kernel reuse and open ordinary-update interruption are all preserved. OD-003 records the high-priority all-category direction without adopting a runtime, silently modifying an accepted ADR or selecting cancellation/drain policy.

No blocker was found. One medium clarification and two small precision improvements should be applied before freezing the final evidence archive.

## 1. Make retained execution distinct from new call authority (medium)

The category table's “Persistent provider sessions and streams” row currently says “retained old authority.” This could be read as preserving old grants or allowing new plugin calls simply because resources are retained. Earlier prose correctly says current authorization can revoke an effect, but the actual kernel contract adds a sharper limit: custody does not grant invocation, and its first accepted contract does not authorize retained consumers to start new calls after owner retirement.

Suggested cell: “Reconnect/resume behavior; retained resource lifetime; current call authority; compatibility.”

Suggested sentence near the kernel discussion:

> The first kernel contract does not let retained consumers start new calls after their owner retires. A long-lived callback or stream must distinguish continuing already-admitted work from a fresh call admitted through the current boundary; custody alone is not invocation authority.

This preserves the broad vision while making the missing contract visible. It is source-backed by current CMS “Optional dynamic Host lifecycle candidate” and ADR-0029, not a speculative safety rule or a new owner approval step.

## 2. Keep source-byte comparison as narrow as actually established (low)

The current statement “Several source files differ by generated overload documentation” is directionally correct, but the strongest retained full diff is specifically `ScopedRef`. The manifest records separate hashes for all inspected Git/installed source files; five were identical and four differed. The decisive ScopedRef difference is only added overload JSDoc. Layer/Scope/RcMap differences were inspected as generated overload documentation/formatting, not validated as an identical source tree or archive.

Safest replacement:

> Git-pinned sources and installed package bytes are recorded separately. Some hashes differ; the retained ScopedRef diff adds overload documentation without changing its implementation. Executed compiled-file hashes are retained; no byte-identical package-tree claim is made.

The fixture executed installed `effect` 4.1.4 compiled JS. The upstream tag `effect@4.1.4` independently resolves to `289a53f7b1fc40049219c6e69022db2fb859c356`. The synthesis correctly does not present them as one byte-identical artifact.

## 3. Optional compact P/I/T table (low; improves reviewability)

Combined ranges are mathematically correct and currently point to the archived breakdown. A compact inline table would make scope easier to compare without opening the archive:

| Bounded local integration | New mechanism P | One consumer integration I | Tests/fixtures T |
| --- | ---: | ---: | ---: |
| Existing Promise Host + Assembly/Resources + kernel | 150–300 LOC | 100–250 LOC | 600–1,100 LOC |
| Already-native Host + Effect adapter + kernel | 100–250 LOC | 80–200 LOC | 550–1,000 LOC |

State that P and I are non-overlapping rough bands, not measured counts or separate new frameworks; existing primitives are excluded; actual existing executor support can make incremental P zero. Both rows assume one execution agent, a narrow replacement boundary and compatible/external state. Estimate confidence is 5/10, bounded achievable reliability 8/10 for both, burden 6/10 versus 5/10. These are judgments for that same limited scope, not measured availability or a product-wide Effect score. A new Effect migration is additional and conditional.

The synthesis already names the material exclusions and says changed existing LOC cannot be estimated before selecting a real consumer. Preserve that language.

## Positive verification

- The fixture remains 166 lines and the recorded run is 4/4, with no skips or cancellations. Test 1 has an independent held finalizer so its during-set closed-handle read is deterministic. Test 2 is a positive typed-startup-failure control; test 3 preserves exact `Die` without relabelling it a typed failure; test 4 proves resource borrowing only. No whole application guarantee is inferred.
- The `.layer()` explanation correctly describes fresh mapper Layer identities rather than live rewiring, and acknowledges private Layers/borrowed identity.
- `Reloadable` absence is qualified to inspected Effect 4.1.4. `LayerMap` instability and RcRef readiness/owner-scope limitations remain visible.
- Kernel bookkeeping and native physical resource retention remain different facts under one existing Host. No duplicate DI, generation supervisor or independent disposer is proposed.
- The central invariant is coherent schema/implementation selection. Completion without interruption is not promised. Selection+retention before a yield, stale cleanup isolation and self-update not awaiting its own drain are correctly conditional architecture proposals.
- OD-003 explicitly allows targeted plugin restart as a possible live boundary while rejecting whole-application restart as sufficient by itself, and keeps ordinary interruption deferred. This matches the owner's stated priority without silently selecting an implementation.

## Evidence integrity

`effect-fit/deliverable-hashes.json` covers the lane report, Russian conclusions, exact source ledger and spike manifest only. It deliberately does not claim to cover subsequently written cross-review files. `source-ledger.json` contains 34 retained upstream files with exact Git blob verification; Apache-2.0/MIT license texts are included. The source and runtime evidence were not changed in this review. Final member hashing belongs to the root's archive manifest after all review dispositions are incorporated.
