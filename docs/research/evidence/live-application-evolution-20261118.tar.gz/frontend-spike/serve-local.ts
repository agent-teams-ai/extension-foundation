import { writeFile } from "node:fs/promises";
import { startFixtureServer } from "./fixture-server.ts";

const { server, base } = await startFixtureServer();
const state = { base, binding: "127.0.0.1", pid: process.pid, startedAt: new Date().toISOString() };
await writeFile(new URL("./evidence/local-server.json", import.meta.url), JSON.stringify(state, null, 2) + "\n");
console.log(JSON.stringify(state));
function stop(): void { server.close(() => process.exit(0)); }
process.once("SIGINT", stop);
process.once("SIGTERM", stop);
