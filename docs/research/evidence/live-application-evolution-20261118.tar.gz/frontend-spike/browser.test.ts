import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, writeFile, mkdir, rm } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import test from "node:test";
import { chromium, type Browser, type Page } from "playwright";
import { startFixtureServer } from "./fixture-server.ts";

const directory = dirname(fileURLToPath(import.meta.url));
const attempt = process.env.FRONTEND_ATTEMPT ?? "1";
assert.match(attempt, /^[a-z0-9-]+$/);
const execute = promisify(execFile);
const digest = (source: string): string => createHash("sha256").update(source, "utf8").digest("hex");
type Artifact = Readonly<{ id: string; version: string; target: string; contract: string; digest: string; source: string }>;
type Observation = Readonly<{ name: string; expected: unknown; actual: unknown }>;
const observations: Observation[] = [];
function observe(name: string, actual: unknown, expected: unknown): void {
  observations.push({ name, expected, actual });
  assert.deepStrictEqual(actual, expected, name);
}
async function artifact(name: string, version: string, target = "browser"): Promise<Artifact> {
  const source = await readFile(join(directory, "generated/plugins", name + ".js"), "utf8");
  assert.doesNotMatch(source, /\bimport\s*(?:\(|["'{*])|\bfrom\s*["']/,
    "The fixture admits only known self-contained generated modules with zero runtime imports");
  return { id: "quote-pricing", version, target, contract: "quote-v1", digest: digest(source), source };
}
async function ready(page: Page): Promise<void> {
  await page.waitForFunction(() => document.body.dataset.ready === "true");
  assert.notEqual(await page.locator("#operation").getAttribute("data-outcome"), "error");
}
async function act(page: Page, id: string, outcome = "success"): Promise<string> {
  const previous = await page.evaluate(() => Number(document.body.dataset.completed ?? "0"));
  await page.locator("#" + id).click();
  await page.waitForFunction((count) => Number(document.body.dataset.completed ?? "0") > count, previous);
  assert.equal(await page.locator("#operation").getAttribute("data-outcome"), outcome, id);
  return await page.locator("#operation").innerText();
}
async function rawProfile(page: Page): Promise<string> {
  return await page.evaluate(async () => await new Promise<string>((resolve, reject) => {
    const request = indexedDB.open("live-evolution-quote-fixture", 1);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction("state", "readonly");
      const get = tx.objectStore("state").get("profile");
      let value: unknown;
      get.onsuccess = () => { value = get.result; };
      tx.oncomplete = () => { db.close(); resolve(JSON.stringify(value)); };
      tx.onabort = () => { db.close(); reject(tx.error); };
    };
  }));
}
async function token(page: Page): Promise<string> { return await page.locator("#document-token").innerText(); }
async function calculate(page: Page, expected: string): Promise<void> {
  await act(page, "calculate");
  observe("visible quote", await page.locator("#result").innerText(), expected);
}

test("real browser live logic, persistence, transfer and bounded management", { timeout: 90_000 }, async () => {
  await mkdir(join(directory, "artifacts"), { recursive: true });
  await mkdir(join(directory, "evidence"), { recursive: true });
  const v1 = await artifact("v1", "1.0.0");
  const rejected = await artifact("rejected", "rejected");
  const wrongTarget = { ...rejected, target: "node" };
  const tampered = { ...rejected, digest: v1.digest };
  await rm(join(directory, "artifacts/v2.json"), { force: true });
  async function publish(name: string, value: Artifact): Promise<void> {
    const bytes = JSON.stringify(value);
    await writeFile(join(directory, "artifacts", name + ".json"), bytes);
  }
  await publish("v1", v1);
  await publish("wrong-target", wrongTarget);
  await publish("tampered", tampered);
  const { server, base } = await startFixtureServer();
  let browser: Browser | undefined;
  const errors: string[] = [];
  const metadata = { attempt, browser: "not launched", node: process.version,
    executable: process.env.FRONTEND_CHROMIUM ?? chromium.executablePath(), startedAt: new Date().toISOString() };
  try {
    const executablePath = process.env.FRONTEND_CHROMIUM;
    browser = await chromium.launch({ headless: true, timeout: 15000,
      ...(executablePath ? { executablePath } : {}) });
    metadata.browser = browser.version();
    const context = await browser.newContext({ viewport: { width: 1200, height: 980 } });
    const page = await context.newPage();
    page.setDefaultTimeout(7000);
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto(base); await ready(page);
    const originalToken = await token(page);
    observe("v2 is not available to the initial document", (await page.request.get(base + "/artifacts/v2.json")).status(), 404);
    observe("fresh consumer has no installed plugin", await page.locator("#installed").innerText(), "none");
    await act(page, "install-v1");
    await page.locator("#amount").fill("100"); await page.locator("#coupon").check();
    const draft = "Customer note: keep the negotiated quote after logic replacement.";
    await page.locator("#draft").fill(draft); await act(page, "save-draft");
    await calculate(page, "120.00");
    await act(page, "hold-call");
    observe("old call is admitted and held", await page.locator("#held").innerText(), "waiting: 1.0.0");

    // v2 is compiled and published only after the running document computes v1.
    const compiler = join(directory, "../node_modules/typescript/bin/tsc");
    let compilerLog = "$ " + process.execPath + " " + compiler + " -p tsconfig.v2.json\n";
    try {
      const result = await execute(process.execPath, [compiler, "-p", "tsconfig.v2.json"], { cwd: directory, timeout: 15000 });
      compilerLog += result.stdout + result.stderr + "exit_code=0\n";
    } catch (error) {
      compilerLog += String(error) + "\n";
      throw error;
    } finally { await writeFile(join(directory, "evidence", "late-compile-attempt-" + attempt + ".log"), compilerLog); }
    const v2 = await artifact("v2", "2.0.0");
    await publish("v2", v2);
    observe("v2 becomes available after local build", (await page.request.get(base + "/artifacts/v2.json")).status(), 200);
    await act(page, "install-v2");
    await page.locator("#amount").fill("200");
    await calculate(page, "212.50");
    await act(page, "toggle-shipping"); await calculate(page, "205.50");
    await act(page, "release-call");
    observe("captured old implementation, input and shipping complete coherently while current input differs", await page.locator("#held-result").innerText(), "120.00");
    await act(page, "toggle-shipping");
    await page.locator("#amount").fill("100"); await act(page, "save-draft");
    await calculate(page, "102.50");
    observe("live replacement does not reload document", await token(page), originalToken);
    observe("live replacement preserves app draft", await page.locator("#draft").inputValue(), draft);
    await page.screenshot({ path: join(directory, "evidence", "live-v2-attempt-" + attempt + ".png"), fullPage: true });

    await page.reload(); await ready(page);
    assert.notEqual(await token(page), originalToken, "reload creates a new document instance");
    observe("reload restores active version", await page.locator("#active").innerText(), "2.0.0");
    observe("reload restores app draft", await page.locator("#draft").inputValue(), draft);
    await calculate(page, "102.50");
    await page.screenshot({ path: join(directory, "evidence", "restored-v2-attempt-" + attempt + ".png"), fullPage: true });
    await page.locator("summary").click(); await act(page, "export");
    const exported = await page.locator("#artifact").inputValue();
    observe("UI exports exact installed artifact", exported, JSON.stringify(v2));
    const freshContext = await browser.newContext();
    try {
      const fresh = await freshContext.newPage();
      fresh.setDefaultTimeout(7000); fresh.on("pageerror", (error) => errors.push(error.message));
      await fresh.goto(base); await ready(fresh);
      observe("new context has isolated plugin storage", await fresh.locator("#installed").innerText(), "none");
      observe("new context has isolated draft", await fresh.locator("#draft").inputValue(), "");
      await fresh.locator("summary").click(); await fresh.locator("#artifact").fill(exported); await act(fresh, "import");
      await calculate(fresh, "102.50");
      observe("fresh compatible consumer executes transferred v2", await fresh.locator("#result-version").innerText(), "2.0.0");
    } finally { await freshContext.close(); }

    await act(page, "toggle-shipping"); await calculate(page, "95.50");
    await page.reload(); await ready(page);
    observe("eligible built-in selection persists", await page.locator("#shipping").innerText(), "off");
    await calculate(page, "95.50");
    for (const action of ["disable-control", "remove-control"]) {
      const before = await rawProfile(page);
      assert.match(await act(page, action, "error"), /Protected control capability/);
      observe(action + " leaves persisted profile unchanged", await rawProfile(page), before);
    }
    await act(page, "toggle-shipping"); await calculate(page, "102.50");
    for (const [action, reason] of [["wrong-target", "Wrong execution target"], ["tampered", "Artifact digest mismatch"]]) {
      assert.ok(action !== undefined && reason !== undefined);
      const before = await rawProfile(page);
      assert.ok((await act(page, action, "error")).includes(reason));
      observe(action + " leaves persisted profile unchanged", await rawProfile(page), before);
      observe(action + " preserves healthy active binding", await page.locator("#active").innerText(), "2.0.0");
      observe(action + " does not execute rejected module sentinel", await page.evaluate(() => {
        const value: unknown = Reflect.get(globalThis, "rejectedImportCount");
        return typeof value === "number" ? value : 0;
      }), 0);
    }
    await calculate(page, "102.50");
    await act(page, "negative-control");
    const control: unknown = JSON.parse(await page.locator("#control-result").innerText());
    observe("plain JS mutable reference mixes revisions; captured functions remain coherent", control, { mixed: 110, captured: 11, wholeNew: 115 });
    await act(page, "disable"); await page.reload(); await ready(page);
    observe("disabled feature is unavailable after restart", await page.locator("#active").innerText(), "unavailable");
    observe("disable retains installed artifact", await page.locator("#installed").innerText(), "2.0.0");
    assert.match(await act(page, "calculate", "error"), /Quote plugin unavailable/);
    observe("disable preserves draft", await page.locator("#draft").inputValue(), draft);
    await act(page, "enable"); await calculate(page, "102.50");
    await act(page, "remove"); await page.reload(); await ready(page);
    observe("removed artifact does not resurrect", await page.locator("#installed").innerText(), "none");
    observe("removal preserves app-owned draft", await page.locator("#draft").inputValue(), draft);
    const removed = await rawProfile(page);
    assert.match(await act(page, "enable", "error"), /No installed artifact/);
    observe("re-enable cannot invent removed installation", await rawProfile(page), removed);
    observe("no uncaught page runtime errors", errors, []);
    await writeFile(join(directory, "evidence", "artifact-inventory.json"), JSON.stringify({
      v1: { digest: v1.digest, bytes: Buffer.byteLength(v1.source) },
      v2: { digest: v2.digest, bytes: Buffer.byteLength(v2.source), availability: "built after visible v1 result" },
      rejected: { digest: rejected.digest, bytes: Buffer.byteLength(rejected.source) }
    }, null, 2) + "\n");
    await writeFile(join(directory, "evidence", "results-attempt-" + attempt + ".json"), JSON.stringify({
      ...metadata, status: "passed", observations, errors,
      documentTokens: { initial: originalToken, final: await token(page) }
    }, null, 2) + "\n");
    await context.close();
  } catch (error) {
    await writeFile(join(directory, "evidence", "results-attempt-" + attempt + ".json"), JSON.stringify({
      ...metadata, status: "failed", observations, errors, failure: error instanceof Error ? error.stack : String(error)
    }, null, 2) + "\n");
    throw error;
  } finally {
    await browser?.close();
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
});
