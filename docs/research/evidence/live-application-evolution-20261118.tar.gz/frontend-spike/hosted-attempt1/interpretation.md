# First hosted attempt: runtime passed, evidence upload failed

Run: https://github.com/agent-teams-ai/extension-foundation/actions/runs/44203816704
Job:134464490823. Input commit:10a9d29cf845e78b9d8a8c0149ffaba72d9c107d.

The retained native-test log reports1 test passed,0 failed,0 cancelled and0
skipped. Case duration was6181.05824ms; suite duration6492.049683ms. Strict
TypeScript checks and the browser experiment step succeeded with the pinned
Playwright browser (Chromium151.0.7922.34).

The workflow then failed in actions/upload-artifact because its path contained
a literal `..` segment, which that action rejects. The official artifact list
is empty. Detailed JSON observations and screenshots from this run therefore
were not recovered and are not presented as retained evidence. The whole job
was failed; only the runtime step is observed to have passed.

The parent corrected the canonical output path in the workflow, preserving the
same frozen source archive and runtime assertions, and executed the ordinary
hosted workflow again. This addressed path syntax, not permission restrictions.
The complete successful second run and its downloaded artifact are retained
separately in `../hosted-final/`. No output from that second execution is
retroactively attributed to this first execution.

Primary evidence: `workflow-job.log` and `job-and-artifacts.json` in this folder.
