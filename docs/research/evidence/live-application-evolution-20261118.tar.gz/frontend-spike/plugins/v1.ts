export const contract = "quote-v1";
export const version = "1.0.0";
export function quote(input: Readonly<{ amount: number; coupon: boolean }>): number {
  const discounted = input.coupon ? input.amount * 0.9 : input.amount;
  return Math.round((discounted * 1.2 + 5) * 100) / 100;
}

