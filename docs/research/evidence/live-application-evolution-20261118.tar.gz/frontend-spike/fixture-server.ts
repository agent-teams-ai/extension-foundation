import { readFile } from "node:fs/promises";
import { createServer, type Server } from "node:http";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const directory = dirname(fileURLToPath(import.meta.url));
const files = new Map([
  ["/", "index.html"], ["/generated/app.js", "generated/app.js"],
  ...["v1", "v2", "wrong-target", "tampered"].map((name) =>
    ["/artifacts/" + name + ".json", "artifacts/" + name + ".json"] as const)
]);
export async function startFixtureServer(): Promise<{ server: Server; base: string }> {
  const server = createServer((request, response) => {
    void (async () => {
      const path = request.url ?? "/";
      if (path === "/favicon.ico") { response.writeHead(204); response.end(); return; }
      const file = files.get(path);
      if (!file) { response.writeHead(404); response.end("Not available"); return; }
      let contents: Buffer;
      try { contents = await readFile(join(directory, file)); }
      catch (error) {
        if (error instanceof Error && "code" in error && error.code === "ENOENT") {
          response.writeHead(404); response.end("Not available"); return;
        }
        throw error;
      }
      response.writeHead(200, { "content-type": file.endsWith("html") ? "text/html" :
        file.endsWith("json") ? "application/json" : "text/javascript", "cache-control": "no-store" });
      response.end(contents);
    })().catch(() => { response.writeHead(500); response.end("Fixture read failed"); });
  });
  await new Promise<void>((resolve, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", resolve); });
  const address = server.address();
  if (address === null || typeof address === "string") throw new Error("Expected loopback TCP address");
  return { server, base: "http://127.0.0.1:" + address.port };
}
