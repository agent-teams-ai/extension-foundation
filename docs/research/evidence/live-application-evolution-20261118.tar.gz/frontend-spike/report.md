# Real-browser live logic experiment

Date: 2026-11-18, Europe/Kiev. Disposable consumer research only.

**The bounded browser experiment passed and its evidence was recovered.** The
[final official run](https://github.com/agent-teams-ai/extension-foundation/actions/runs/44205511602)
completed successfully:1/1 native test,0 failed,0 skipped,0 cancelled,
41 matching recorded observations and0 uncaught page errors. Native case
duration was3027.511302ms; suite duration3471.347778ms. These durations describe
one small test execution, not a throughput or latency benchmark.

The result demonstrates replacing substantive calculation logic in a running
document, coherent captured old work, IndexedDB reconstruction after page reload,
exact compatible-artifact transfer and bounded feature management. It does not
prove complete browser-process restart, independent SPI conformance or an
in-application LLM authoring loop. The unsuccessful local attempts and the first
hosted test pass with failed artifact upload remain separately preserved.

## Implemented boundary

One ordinary quote application owns a serialized command queue, its application
draft and one IndexedDB profile. A selected plugin is a pure calculation
closure. Generated artifacts contain one self-contained ESM source snapshot,
a display version, target, consumer-specific contract and exact SHA-256.
The application checks target/contract/digest before importing a Blob of those
same source bytes, then validates exports before committing the desired profile
and publishing its prepared binding. A digest is identity, not authorization.

An admitted delayed calculation captures its binding, primitive input and
shipping setting. There is no reference-counting or resource owner: the plugin
is pure. A consumer-owned built-in shipping calculation remains ordinary
built-in code. Protected-control command rejection is a narrow fixture guard,
not authentication, sandboxing or a general permissions implementation.

The fixture deliberately stores the artifact and desired state together in one
IndexedDB profile. Installation, activation, disabling and deletion are distinct
commands. Disabling retains the artifact; removal deletes the installation,
while the application-owned draft remains. Restoration revalidates the stored
bytes and rebuilds the executable binding in a new document. A successful IDB
transaction and runtime publication are separate steps; this browser fixture
does not inject a crash between them. The complementary backend experiment
owns that exact crash barrier.

## Observed results

- UI v1 quote is120.00 at amount100 with coupon and built-in shipping.
- The v2 endpoint returned404 when the page started, then200 after its build.
  Only after a visible v1 result did the harness invoke the pinned compiler for
  v2, publish the generated artifact, and activate it in the existing document.
  The candidate TypeScript source was written before the experiment; its
  executable bytes were built and published at this live boundary. This is
  local build→artifact→live activation, not in-app LLM authoring.
- A held v1 call returns120.00 while current input200 and shipping off produce
  v2 output205.50. Current and captured operations therefore have independently
  discriminating implementation, input and built-in-selection oracles.
- Restoring input100 and shipping on gives102.50. The document token remained
  unchanged through replacement, then changed on page reload while artifact,
  draft and result were restored from IndexedDB. This is document reconstruction
  inside the same browser process/context; it is not a complete browser-process
  restart or a power-loss experiment.
- UI export transfers the exact installed artifact into a fresh isolated
  Chromium context. This is a new installation of the same compatible consumer,
  not independent SPI conformance.
- Disable followed by page reload made calculation unavailable while retaining
  the installed artifact. Re-enabling restored102.50. Remove followed by page
  reload retained the app draft, left no artifact, and rejected re-enable.
- Turning off built-in shipping changed102.50 to95.50 and persisted through
  page reload. Attempts to disable/remove the protected control surface failed
  and left the independently read IndexedDB profile unchanged.
- Wrong-target and tampered-digest candidates contain a top-level sentinel;
  both rejections preserved the healthy profile/binding and left the sentinel0.
- A plain JavaScript negative control yields mixed110, captured11 and whole-new115.
  This is not a Lively or Pharo defect reproduction.

The numeric expectations are independent fixed assertions, not values computed
by calling the candidate implementation from the test. The held operation
completed while current input and shipping selection differed, making its
coherence assertion discriminate implementation, input and built-in selection.
DOM completion/readiness oracles and real transaction completion are used;
there are no fixed sleeps as correctness oracles.

Exact outputs are in `hosted-final/evidence/results-attempt-hosted.json`.
The two actual Chromium screenshots are
`hosted-final/evidence/live-v2-attempt-hosted.png` and
`hosted-final/evidence/restored-v2-attempt-hosted.png`. The live image shows v2
output102.50 beside completed captured-v1 output120.00. The restored image
shows a different document instance, restored v2 output102.50 and its saved
application draft. The pending-call display resets with the document, as expected.
An initially ambiguous image preview was checked against the original PNGs:
the two draft-text regions contain exactly equal RGB bytes, and independent
installed OCR reads the full note in both. The bounded read-only verification
is retained in `../live-logic-industry/frontend-visual-verification.json`
(SHA-256 `9094f039fb90ec9f1bbd3f0c12c518f597f91a6e0253df862a72680170dc1ae0`).
No image, browser input or runtime result was changed to obtain that check.

## Execution history and retained failures

Exact hosted environment: Node24.22.1, pnpm11.25.0, TypeScript7.0.2,
Playwright1.62.1 and its bundled Chromium151.0.7922.34; @types/node24.13.3.
Local diagnostics used system Chromium156.0.8078.79 on Debian13.
Strict browser compilation, separate Node harness checking and v2 noEmit
checking passed. v2's executable bytes are intentionally not built at startup.
The configs enable strict, noUncheckedIndexedAccess, exactOptionalPropertyTypes
and unused-code checks; source does not use blanket any or unsafe type assertions.

Attempt1 used an outer subprocess wrapper that buffered logs. It did not exit
after browser setup; it was interrupted with exit130. The exact initial harness
and a truthful missing-output note are retained. No runtime result is inferred.
Attempt2 fixed launcher failure cleanup and streamed the raw native-test output
directly into a retained file. Chromium aborts before a page exists:
`process_singleton_posix.cc:297 ... socket() failed: Operation not permitted (1)`.
The Node test reports1 failed and0 passed; JSON records zero successful
observations. This is an execution-environment failure, not proof of any plugin
algorithm, persistence property or browser-platform defect. No restriction
bypass was attempted. The parent also checked the official connected-browser
route (no originating extension context) and cloud CUA route. Cloud CUA
initialized, but one ordinary navigation to the strictly loopback fixture
returned ERR_CONNECTION_REFUSED. The fixture server was stopped; no external
exposure or tunnel was introduced.

The official hosted route then executed the same frozen fixture on the existing
Draft PR55. The harness defaults to Playwright's exact installed bundled browser;
only explicit FRONTEND_CHROMIUM selects a diagnostic executable. There are no
custom browser flags.

The [first hosted run](https://github.com/agent-teams-ai/extension-foundation/actions/runs/44203816704)
passed1/1 native test with no failures, skips or cancellations (suite6492.049683ms),
but artifact upload rejected a path containing a literal `..` segment. That job
failed overall and returned no downloadable artifacts. Its detailed JSON and
screenshots were not recovered; only its raw logs and API metadata are retained
in `hosted-attempt1/`, with `interpretation.md` describing this exact distinction.

The parent corrected only the canonical path in the workflow and used the
ordinary hosted execution again. The frozen archive and runtime assertions did
not change. Final job134470295465 on run44205511602 succeeded, including upload.
Official artifact14383646439 was downloaded as255662 bytes and independently
hashed. The recovered14-file input receipt binds the source, manifest, lockfile,
input archive, commit and run identity. Rechecking its frontend input file hashes
against the local frozen files found no mismatches. The recovered41 observations
all equal their expected values; the error list is empty. This closes the runtime
and evidence-custody gap without reinterpreting the earlier failures as passes.

## Exact evidence identities

Final input commit:`4f77b5f61b1053e9493091043c14a3caa447b7cf`.
The final source is the same frozen input archive that the initial hosted run used.

| Evidence | SHA-256 |
| --- | --- |
| Frozen input archive | `ee51b6c1cddd63f33b4a56a505140b46876fb8e2414b62920345705b38138ac4` |
| Eleven-file source hash manifest | `c0e144f7700e6d57cbea87c2e39362c12ccf1227810ea73f8fadc3a6bf119ad3` |
| Frozen browser.test.ts | `b44b477ae4a3e374f10b262b2e830f2ac6fc9422877275ba3fddc9a50087f631` |
| Downloaded official artifact ZIP | `5411de8b302497d496fc9dcb841675cacd1037588c90ee951d154df7a8a8320f` |
| Recovered input receipt | `ad0f96c4944717b0202846bdc6778b0ccbf492239384f6ae91c368fcdabd3a8e` |
| Recorded results JSON | `367508d10f92cabf1da5323879f967185ab59fdce72c2d4db73af0cda02ec7d8` |
| Live v2 screenshot | `a7db9914457488fe16118e9e0f477ea23b79314d9fd81a3038a76fe62c891120` |
| Restored v2 screenshot | `d21b45c6f0ffdf34542df448bd60d5a031ba8e0310d07d616a9c9904e04ed5f1` |

Generated executable source identities: v1(233 bytes)
`21d22a103ab6b3d6a0a479e1e2189b3c75ced0117b078551e95b3649ed74b0a1`;
v2(249 bytes)`4e926890e2eb43470096267de95cd84b3d2384a88b5e498e7591be803f8664fb`;
rejected sentinel module(276 bytes)
`578f29def528a4b1bd070ae0e289baae10ef40d014b3b25fa9808dd76c70930b`.
These identify exact executable bytes, not authority to execute them.

`hosted-final/` retains the original ZIP, download receipt, native logs,
workflow logs, official job/artifact metadata, compiler outputs, generated
modules, full artifacts and screenshots. Empty successful compiler log files
are interpreted together with the successful workflow step and shell exit
handling; an empty file alone is not a successful typecheck receipt.

## Hosted reproduction

The parent workspace owns the exact dependency manifest and frozen lockfile.
Install the official browser using `pnpm exec playwright install --with-deps chromium`.
From the `frontend-spike` directory run:

```sh
node ../node_modules/typescript/bin/tsc -p tsconfig.browser.json
node ../node_modules/typescript/bin/tsc -p tsconfig.node.json
node ../node_modules/typescript/bin/tsc -p tsconfig.v2.json --noEmit
FRONTEND_ATTEMPT=hosted node --test browser.test.ts
```

Do not set FRONTEND_CHROMIUM on that normal hosted route. The v2 noEmit check
validates source without publishing executable bytes before the running-page
observation. The harness subsequently performs its real emitted compile at the
named live boundary. Always retain native-test stdout and `evidence/`,
`artifacts/` and `generated/` even on failure. The successful outputs are
`results-attempt-hosted.json`, `late-compile-attempt-hosted.log`,
`artifact-inventory.json`, `live-v2-attempt-hosted.png` and
`restored-v2-attempt-hosted.png`, all under `evidence/`.

## Transfer inference and limits

`evidence/` retains compiler logs, both runtime attempt records, the initial
harness snapshot, available-artifact inventory and exact current source hashes.
Current handwritten source: app251LOC, plugin modules20LOC, harness207LOC,
shared fixture server36LOC, standalone local launcher10LOC, HTML27LOC, configs58LOC.
Generated output and dependencies are excluded from those counts.

This evidence supports keeping application state outside executable instances,
binding each admitted operation to one coherent implementation/input selection,
and distinguishing installed, desired and observed runtime state. It also
supports compatible artifact transfer with exact source identity and explicit
target/contract validation. These are mechanisms demonstrated in this ordinary
consumer; they do not publish a public API or create a new universal lifecycle
authority. The underlying pure calculation has no scoped external resources,
so adding a second resource manager would not improve this experiment.

No claim is made about untrusted code containment, arbitrary running-stack
migration, physical ESM unload/GC, distributed publication, authorization,
multi-tab contention, resourceful plugin lifecycle, complete browser-process
restart, in-app LLM authoring, power-loss durability or cross-implementation
portability. The fresh context imports into the same consumer implementation;
it is not the independent implementation needed to qualify a reusable SPI.
An experiment's retained-old-call profile
does not adopt the still-open ordinary-update interruption policy.
