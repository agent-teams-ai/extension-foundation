export const contract = "quote-v1";
export const version = "2.0.0";
export function quote(input) {
    const discount = input.coupon ? Math.min(15, input.amount * 0.2) : 0;
    return Math.round(((input.amount - discount) * 1.1 + 2) * 100) / 100;
}
