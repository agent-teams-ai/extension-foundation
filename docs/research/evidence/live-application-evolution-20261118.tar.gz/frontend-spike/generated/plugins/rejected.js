const previous = Reflect.get(globalThis, "rejectedImportCount");
Reflect.set(globalThis, "rejectedImportCount", (typeof previous === "number" ? previous : 0) + 1);
export const contract = "quote-v1";
export const version = "rejected";
export function quote() { return -999; }
