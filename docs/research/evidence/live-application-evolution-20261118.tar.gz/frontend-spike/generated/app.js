function record(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function parseArtifact(value) {
    if (!record(value) || typeof value.id !== "string" || typeof value.version !== "string" ||
        typeof value.target !== "string" || typeof value.contract !== "string" ||
        typeof value.digest !== "string" || !/^[a-f0-9]{64}$/.test(value.digest) ||
        typeof value.source !== "string" || value.source.length > 100_000)
        throw new Error("Invalid artifact");
    return Object.freeze({ id: value.id, version: value.version, target: value.target,
        contract: value.contract, digest: value.digest, source: value.source });
}
function parseProfile(value) {
    if (!record(value) || typeof value.enabled !== "boolean" || typeof value.shipping !== "boolean" ||
        !record(value.draft) || typeof value.draft.amount !== "string" ||
        typeof value.draft.coupon !== "boolean" || typeof value.draft.note !== "string")
        throw new Error("Invalid persisted profile");
    const artifact = value.artifact === null ? null : parseArtifact(value.artifact);
    if (value.enabled && artifact === null)
        throw new Error("Enabled profile has no artifact");
    return { artifact, enabled: value.enabled, shipping: value.shipping,
        draft: { amount: value.draft.amount, coupon: value.draft.coupon, note: value.draft.note } };
}
function el(id) {
    const node = document.getElementById(id);
    if (!(node instanceof HTMLElement))
        throw new Error("Missing element: " + id);
    return node;
}
function input(id) {
    const node = el(id);
    if (!(node instanceof HTMLInputElement))
        throw new Error("Expected input: " + id);
    return node;
}
function area(id) {
    const node = el(id);
    if (!(node instanceof HTMLTextAreaElement))
        throw new Error("Expected text area: " + id);
    return node;
}
const defaults = { artifact: null, enabled: false, shipping: true,
    draft: { amount: "100", coupon: true, note: "" } };
let profile = defaults;
let active = null;
let commands = Promise.resolve();
let completed = 0;
const events = [];
const documentToken = crypto.randomUUID();
el("document-token").textContent = documentToken;
document.body.dataset.documentToken = documentToken;
function openDb() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open("live-evolution-quote-fixture", 1);
        request.onupgradeneeded = () => request.result.createObjectStore("state");
        request.onerror = () => reject(request.error ?? new Error("Database open failed"));
        request.onsuccess = () => resolve(request.result);
    });
}
async function readProfile() {
    const db = await openDb();
    try {
        return await new Promise((resolve, reject) => {
            const tx = db.transaction("state", "readonly");
            const request = tx.objectStore("state").get("profile");
            let value;
            request.onsuccess = () => { value = request.result; };
            tx.oncomplete = () => {
                try {
                    resolve(value === undefined ? defaults : parseProfile(value));
                }
                catch (error) {
                    reject(error);
                }
            };
            tx.onabort = () => reject(tx.error ?? new Error("Read aborted"));
        });
    }
    finally {
        db.close();
    }
}
async function persist(next) {
    const db = await openDb();
    try {
        await new Promise((resolve, reject) => {
            const tx = db.transaction("state", "readwrite");
            tx.objectStore("state").put(next, "profile");
            tx.oncomplete = () => resolve();
            tx.onabort = () => reject(tx.error ?? new Error("Write aborted"));
        });
    }
    finally {
        db.close();
    }
}
async function prepare(artifact) {
    if (artifact.target !== "browser")
        throw new Error("Wrong execution target");
    if (artifact.id !== "quote-pricing" || artifact.contract !== "quote-v1")
        throw new Error("Wrong quote contract");
    const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(artifact.source));
    const actual = Array.from(new Uint8Array(hash), (n) => n.toString(16).padStart(2, "0")).join("");
    if (actual !== artifact.digest)
        throw new Error("Artifact digest mismatch");
    const url = URL.createObjectURL(new Blob([artifact.source], { type: "text/javascript" }));
    try {
        const exports = await import(url);
        if (!record(exports) || exports.contract !== "quote-v1" || exports.version !== artifact.version ||
            typeof exports.quote !== "function")
            throw new Error("Invalid quote exports");
        const calculate = exports.quote;
        return Object.freeze({ version: artifact.version, quote: (value) => {
                const result = Reflect.apply(calculate, undefined, [value]);
                if (typeof result !== "number" || !Number.isFinite(result))
                    throw new Error("Invalid quote result");
                return result;
            } });
    }
    finally {
        URL.revokeObjectURL(url);
    }
}
function render() {
    el("active").textContent = active?.version ?? "unavailable";
    el("installed").textContent = profile.artifact?.version ?? "none";
    el("shipping").textContent = profile.shipping ? "on" : "off";
    el("enabled").textContent = profile.enabled ? "enabled" : "disabled";
    el("history").textContent = events.slice(-8).join("\n");
}
function restoreDraft() {
    input("amount").value = profile.draft.amount;
    input("coupon").checked = profile.draft.coupon;
    area("draft").value = profile.draft.note;
}
function enqueue(name, action) {
    commands = commands.then(async () => {
        document.body.dataset.busy = "true";
        try {
            await action();
            el("operation").textContent = name + ": complete";
            el("operation").dataset.outcome = "success";
            events.push(name + " completed");
        }
        catch (error) {
            const reason = error instanceof Error ? error.message : "Unknown failure";
            el("operation").textContent = name + ": " + reason;
            el("operation").dataset.outcome = "error";
            events.push(name + " rejected: " + reason);
        }
        finally {
            completed += 1;
            render();
            document.body.dataset.completed = String(completed);
            document.body.dataset.busy = "false";
        }
    });
}
function button(id, name, action) {
    el(id).addEventListener("click", () => enqueue(name, action));
}
async function install(artifact) {
    const prepared = await prepare(artifact);
    const next = { ...profile, artifact, enabled: true };
    await persist(next);
    profile = next;
    active = prepared;
}
async function installFixture(name) {
    const response = await fetch("/artifacts/" + name + ".json");
    if (!response.ok)
        throw new Error("Fixture download failed");
    const value = await response.json();
    await install(parseArtifact(value));
}
function capture() {
    if (!active)
        throw new Error("Quote plugin unavailable");
    const amount = Number(input("amount").value);
    if (!Number.isFinite(amount) || amount < 0)
        throw new Error("Invalid amount");
    return { binding: active, value: Object.freeze({ amount, coupon: input("coupon").checked }),
        shipping: profile.shipping ? 7 : 0 };
}
function total(call) {
    return (Math.round((call.binding.quote(call.value) + call.shipping) * 100) / 100).toFixed(2);
}
let releaseHeld;
let held;
button("install-v1", "Install v1", () => installFixture("v1"));
button("install-v2", "Replace v2", () => installFixture("v2"));
button("save-draft", "Save draft", async () => {
    const next = { ...profile, draft: { amount: input("amount").value,
            coupon: input("coupon").checked, note: area("draft").value } };
    await persist(next);
    profile = next;
});
button("calculate", "Calculate", async () => {
    const call = capture();
    el("result").textContent = total(call);
    el("result-version").textContent = call.binding.version;
});
button("hold-call", "Capture old call", async () => {
    if (releaseHeld)
        throw new Error("A call is already held");
    const call = capture();
    const gate = new Promise((resolve) => { releaseHeld = resolve; });
    el("held").textContent = "waiting: " + call.binding.version;
    held = gate.then(() => {
        el("held").textContent = "completed: " + call.binding.version;
        el("held-result").textContent = total(call);
    });
});
button("release-call", "Release captured call", async () => {
    if (!releaseHeld || !held)
        throw new Error("No held call");
    releaseHeld();
    await held;
    releaseHeld = undefined;
    held = undefined;
});
button("disable", "Disable", async () => {
    const next = { ...profile, enabled: false };
    await persist(next);
    profile = next;
    active = null;
});
button("enable", "Enable", async () => {
    if (!profile.artifact)
        throw new Error("No installed artifact");
    const prepared = await prepare(profile.artifact);
    const next = { ...profile, enabled: true };
    await persist(next);
    profile = next;
    active = prepared;
});
button("remove", "Remove", async () => {
    const next = { ...profile, artifact: null, enabled: false };
    await persist(next);
    profile = next;
    active = null;
});
button("toggle-shipping", "Toggle built-in shipping", async () => {
    const next = { ...profile, shipping: !profile.shipping };
    await persist(next);
    profile = next;
});
async function rejectControl() { throw new Error("Protected control capability"); }
button("disable-control", "Disable control", rejectControl);
button("remove-control", "Remove control", rejectControl);
button("export", "Export artifact", async () => {
    if (!profile.artifact)
        throw new Error("No installed artifact");
    area("artifact").value = JSON.stringify(profile.artifact);
});
button("import", "Import artifact", async () => {
    const value = JSON.parse(area("artifact").value);
    await install(parseArtifact(value));
});
button("wrong-target", "Wrong target", () => installFixture("wrong-target"));
button("tampered", "Tampered digest", () => installFixture("tampered"));
button("negative-control", "Mutation control", async () => {
    const mutable = { first: (n) => n * 2, second: (n) => n + 1 };
    const first = mutable.first, second = mutable.second;
    let release = () => { throw new Error("Gate not initialized"); };
    const gate = new Promise((resolve) => { release = resolve; });
    const mixed = (async () => { const n = mutable.first(5); await gate; return mutable.second(n); })();
    const captured = (async () => { const n = first(5); await gate; return second(n); })();
    mutable.first = (n) => n * 3;
    mutable.second = (n) => n + 100;
    release();
    const [mixedResult, capturedResult] = await Promise.all([mixed, captured]);
    el("control-result").textContent = JSON.stringify({ mixed: mixedResult, captured: capturedResult,
        wholeNew: mutable.second(mutable.first(5)) });
});
try {
    profile = await readProfile();
    restoreDraft();
    if (profile.enabled && profile.artifact)
        active = await prepare(profile.artifact);
    events.push("Document restored");
    el("operation").textContent = "Ready";
}
catch (error) {
    el("operation").textContent = error instanceof Error ? error.message : "Startup failed";
    el("operation").dataset.outcome = "error";
}
render();
document.body.dataset.completed = "0";
document.body.dataset.ready = "true";
export {};
