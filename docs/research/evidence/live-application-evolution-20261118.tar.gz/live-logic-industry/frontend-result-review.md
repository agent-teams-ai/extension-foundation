# Independent review: disposable real-browser live-logic spike

Date: 2026-11-18. Reviewer: `live_logic_industry`.

## Final verdict

**PASS for the bounded trusted browser fixture. No material finding remains
open.** Official hosted run `44205511602`, job `134470295465`, completed
successfully and retained the exact executable artifacts, result JSON and
screenshots. One native test passed, with 41 matching recorded observations,
zero page errors and no failed, cancelled or skipped tests. Total native-test
duration was 3,471.347778 ms; this is an execution record, not a performance
qualification.

The reviewer inspected source, the retained raw ZIP/API metadata/logs, exact
input/output hashes, all observations and original screenshot files. No browser
test was rerun and no implementation or input file was changed by the reviewer.
The following historical sections retain the initial oracle correction and
unsuccessful local/setup attempts; final evidence and limits follow them.

## Initial source review

Read `frontend-plan.md` and the complete `app.ts`, `browser.test.ts`, HTML,
plugin sources and three TypeScript configurations. All spike paths below are
relative to `/workspace/scratch/58e9c088d2ee/live-evolution-20261118/frontend-spike`.

| Initial input | SHA-256 |
| --- | --- |
| `app.ts` | `205f0a5316ccd6d75df29a806ba225e3e1e895aea156d103052c7b7e12bb0dd8` |
| `browser.test.ts` | `14a2b3d90e2537b3d794213c602ecf58165f050f954029a24b60b8567326b71e` |
| `index.html` | `3163936b9f2898ce3141a17d74cd3d5bd10a228689545a233558b51422c090be` |
| `plugins/v1.ts` | `e23a7e61a44d23842db15e5010fe3720c04b53fa3c95d523ad40d25bad4db81c` |
| `plugins/v2.ts` | `dcb86fa80579e425f5f0d4fbf95a9bd59aa31f847116b9cabcb76cc8a22e7dd0` |
| `plugins/rejected.ts` | `e391b9cf4b4262299be2d5c7ab1559da50c2436efb9b0b7ddf4dd53fed5e93f9` |
| `tsconfig.browser.json` | `0a8b9fed4d7764eeff595cd7a48bff0ea58b28d221af06f2bbbc1ff367fbde18` |
| `tsconfig.node.json` | `ff88a5dcf87b660d44c0af412954ca79b21f1b2f6a984004772d18f7ec14793a` |
| `tsconfig.v2.json` | `06afd9fa38735339ead5e782dbed78903cbbb04bb7770981c5d43bdaabd46320` |

### Finding F1: held-call input/built-in oracle was non-discriminating

The implementation captures a frozen amount/coupon input and the built-in
shipping selection when admitting the held call. However, the first harness
revision restores amount 100 before releasing the call and leaves shipping
unchanged throughout the hold. A faulty implementation which reread those
values at completion could therefore produce the same expected 120.00.

The bounded correction is to release the held v1 call while current amount is
200 and shipping is off, require the current v2 calculation to produce 205.50
and the retained call to remain 120.00, then restore amount 100/shipping on for
the existing screenshot/reload flow. This checks both independent inputs
without adding a framework or broader test matrix.

Sent to the browser owner and root. The browser owner applied it. The amended
`browser.test.ts` has SHA-256
`5e3787ec455226ae8f90486ce710037eb32766a171a1e5164e54e33916408cc3`.
The source-level finding is closed: the harness now requires 205.50 while the
retained operation must still return 120.00, before restoring either control.
The later frozen hosted harness preserves that correction. Final hosted results
observed both values and close F1 at the runtime level as well.

### Source conclusions

- Actual v2 source is separately compiled and published after visible v1 use;
  its artifact route must return 404 beforehand. The initial server used an
  in-memory publication map; the later shared helper below reads only allowlisted
  fixture files, with stale v2 artifact removal before harness startup.
- A nonpersisted document token supports the no-reload oracle; deliberate reload
  is separately required to produce a different token.
- Artifact fields are parsed from unknown input and frozen; target/contract and
  SHA-256 checks precede import of a Blob made from the same source snapshot.
  The top-level sentinel is suitable for the two specific rejected fixtures.
- The captured binding closes over the exported calculation function; the
  known plugin functions have no imports or mutable external helpers.
- Profile mutation waits for IndexedDB transaction completion before replacing
  in-memory profile and active binding. One consumer command queue owns those
  mutations. This does not introduce another catalog or lifecycle owner.
- Disable retains the artifact; remove drops installation/enabled facts while
  retaining application draft. Restore consults persisted selection. Pure
  function retirement makes no physical ESM-unload claim.
- The eligible built-in is a built-in numeric contribution with a persisted
  selection; it is not mislabeled as a distributed artifact. Protected-control
  commands explicitly reject and leave persisted state unchanged.
- Transfer uses a fresh browser storage context running the same consumer.
  It cannot establish independent-implementation conformance or a public SPI.
- The native-JS mutation control distinguishes mixed 110, captured 11 and whole
  new 115 under its precise functions. It says nothing about a defect in Lively,
  Pharo or another runtime and does not prove generic state migration.

The self-contained/import-free restriction is verified for known generated
fixtures by the harness and direct source inspection; the browser import UI is
not a malicious-code analyzer or a security sandbox. The meaningful bounded
claim is trusted pure-logic replacement within this single consumer.

## Local execution evidence reviewed

The following exact files were read after the browser owner diagnosed its local
launch failure. All implementation hashes above remain unchanged except the
amended harness identified under F1. The amended launcher is now inside the
`try`/`finally`, records launch failures, bounds launch/late compilation and
closes the server even when Chromium never starts.

| Evidence | SHA-256 |
| --- | --- |
| `evidence/browser-attempt-2.log` | `9b92cdb4dcf0e37e4ff9880a1caa2d37bfe189e041d6adc90c5e566f89cf423b` |
| `evidence/results-attempt-2.json` | `1aaafdea0c991c0c487f3424b3c2fae6bc5c966a0739d9cc15dbd045cd2df1a1` |
| `report.md` at this review | `1982d9b0ff251d9c6254b1bbd380bc34afaf276f727e30e80369e1810127b704` |

Attempt 2 reports **0 passed, 1 failed**, with JSON `status: failed`, browser
`not launched` and an empty observations array. Chromium terminated at
`process_singleton_posix.cc` when `socket()` returned EPERM, before any page
existed. This is evidence of the local environment's launch failure, not a
passing browser behavior test and not an upstream runtime defect. The spike
report states that limitation accurately. The initial interrupted invocation
is retained by the owner and has not been counted as a successful run.

At that checkpoint the parent examined an official alternate execution route.
No unsafe restriction bypass or duplicate browser run was attempted by this
reviewer. These local launch failures remain failures; the later successful
hosted result does not relabel them as passed runs.

## Alternate-route support source review

While the parent checked official cloud-browser reachability, the browser owner
extracted the existing allowlisted HTTP server into one shared helper and a
small standalone loopback launcher. These changes do not themselves establish
browser execution. The helper binds only `127.0.0.1` and serves the known HTML,
app source and four named artifact files; missing files return 404. The amended
harness removes its own stale v2 artifact before starting, preserving the
initial-unavailable oracle with file-based serving.

| Additional reviewed input | SHA-256 |
| --- | --- |
| `browser.test.ts` after helper extraction | `4a7e7d8d2d244d22736568a07201953989054754ced7370caceb95b0e5dea74f` |
| `fixture-server.ts` | `fac9e6032bf7b34fb98a205b0c332e215f1e3cb4655be4db9118a521b7ecb3c0` |
| `serve-local.ts` | `57ed172ac3c24d9f8e75390030fa02eebae488b7e64e8c69b198990a3abcff5a` |
| `tsconfig.node.json` including helpers | `159fcd058ce624ee8053e83bb160fd3b7816ae4dfb78e93b6d3210c68f9b5eee` |

The implementation and plugin hashes remain unchanged. No additional material
issue found. Any alternate UI run must be recorded against the actual served
source and observations; the original local Playwright assertions cannot be
marked passed merely because another browser opens the page.

## Frozen hosted input review

The parent selected a bounded job on the existing draft PR after local launch
failed and official cloud-browser navigation could not reach the loopback
server. The browser owner amended only executable selection/metadata for that
route: default `chromium.launch` now uses the browser supplied by pinned
Playwright; an explicitly set `FRONTEND_CHROMIUM` remains a local diagnostic
override. There are no custom browser flags in this final source.

Final `browser.test.ts` SHA-256:
`b44b477ae4a3e374f10b262b2e830f2ac6fc9422877275ba3fddc9a50087f631`.
The frozen 11-file manifest `evidence/source-hashes-hosted-input.json` SHA-256:
`c0e144f7700e6d57cbea87c2e39362c12ccf1227810ea73f8fadc3a6bf119ad3`.
The reviewer compared every manifest digest and byte count to the actual files;
all 11 matched. No fixture/dependency program was executed by that read-only
identity check.

The complete final harness diff against the retained initial snapshot was read.
F1's discriminating input/shipping assertion, late-build/publication sequence,
document token, persistence/removal/transfer/rejection assertions, launch
failure recording and cleanup remain intact. No assertion was weakened for
hosted execution. That source/setup review alone established no runtime result;
the completed hosted evidence below supplies the final behavioral qualification.

## Final hosted identity and artifact custody

The final successful run executed commit
`4f77b5f61b1053e9493091043c14a3caa447b7cf` on the existing draft branch. Both
the complete job log and retained GitHub API artifact metadata bind that exact
head. Artifact ID `14383646439` belongs to run `44205511602`, attempt 1.
The downloaded ZIP has exactly 255,662 bytes and SHA-256
`5411de8b302497d496fc9dcb841675cacd1037588c90ee951d154df7a8a8320f`,
matching both GitHub's reported artifact digest and the local download receipt.

The reviewer independently checked all 20 unique regular file entries. Every
ZIP member matched its extracted bytes and recorded size/hash, and every path
was a safe relative path. The execution receipt's entire 14-file list equals
the frozen outer input manifest; it records archive SHA-256
`ee51b6c1cddd63f33b4a56a505140b46876fb8e2414b62920345705b38138ac4`,
the same exact source/package/lock archive reviewed before execution. Run ID,
commit and source inventory match across the receipt, API metadata and logs.

Files below are relative to `frontend-spike/hosted-final/`:

| Retained evidence | SHA-256 |
| --- | --- |
| `original-workflow-artifact.zip` | `5411de8b302497d496fc9dcb841675cacd1037588c90ee951d154df7a8a8320f` |
| `download-receipt.json` | `f6b40d4ff852d0530191b16ed05d4ddfd61c5bd178fb5ff20c567488f50841cb` |
| `job-and-artifacts.json` | `32436f9f2105917a0665fdb33db667f748c289fd578706c04d6c73ad2a4e67d1` |
| `evidence/hosted-input-receipt.json` | `ad0f96c4944717b0202846bdc6778b0ccbf492239384f6ae91c368fcdabd3a8e` |
| `evidence/results-attempt-hosted.json` | `367508d10f92cabf1da5323879f967185ab59fdce72c2d4db73af0cda02ec7d8` |
| `evidence/hosted-runtime.log` | `aeed381bcf6ac74d9e040ab72e5008032307a6b8682bef8c1976cbbbe13b5caa` |
| `evidence/late-compile-attempt-hosted.log` | `ee675f4a9b7b1519debd7c60d31917126c6dfad878fd93f3fe5be425b1a14781` |
| `evidence/artifact-inventory.json` | `4d2508911ff7456790f79874ffbc2285728217dc3aa6a39df572bc296ff10dd4` |
| `evidence/live-v2-attempt-hosted.png` | `a7db9914457488fe16118e9e0f477ea23b79314d9fd81a3038a76fe62c891120` |
| `evidence/restored-v2-attempt-hosted.png` | `d21b45c6f0ffdf34542df448bd60d5a031ba8e0310d07d616a9c9904e04ed5f1` |

Actual recorded environment: Node 24.22.1, pnpm 11.25.0, TypeScript 7.0.2,
Playwright 1.62.1 and Chromium 151.0.7922.34 from Playwright's normal installed
browser path. All three strict compiler commands and the native browser command
completed in the successful job step; upload also succeeded. Empty compiler
output is supported by the job's success/failure propagation, not used as proof
on its own.

The earlier hosted job's native test passed but upload failed on a dot-component
path. That failure remains retained separately in `hosted-attempt1/` and
`hosted-workflow-review.md`. Only workflow path normalization changed between
the two hosted jobs; frozen source and assertions did not change. The successful
repeat recovered the missing artifact evidence and requires no further rerun.

## Executable artifacts and observed behavior

The v1/v2 artifact JSON contains exactly the source bytes in the corresponding
retained generated modules. Their claimed hashes independently recompute to
`21d22a103ab6b3d6a0a479e1e2189b3c75ced0117b078551e95b3649ed74b0a1`
and `4e926890e2eb43470096267de95cd84b3d2384a88b5e498e7591be803f8664fb`.
The generated modules were read: each is a self-contained pure calculation with
no runtime imports. The retained generated app, v1 and rejected module also match
the already compiled pre-host local files byte for byte; no new compilation was
run for that comparison.

The wrong-target artifact uses the known sentinel source with a valid digest
but target `node`. The tampered artifact contains those same sentinel bytes but
intentionally claims a different digest. Both artifact contents match their
declared negative-control purpose; neither case relies on an inert placeholder
that could never show evaluation.

| Qualified observation | Concrete final evidence |
| --- | --- |
| Meaningful code added after application start | v2 artifact route initially returns 404; v1 UI computes 120.00; late compiler log records exit 0; route then returns 200 and v2 computes 212.50/205.50 for amount 200 with shipping on/off. |
| Old semantic binding and inputs remain coherent | With current v2 amount 200 and shipping off producing 205.50, held v1 still produces 120.00 using its admitted amount and shipping selection. |
| Live replacement does not reload | Original document token `bafe1d75-c36b-45ca-ad39-bdc66f77479a` is unchanged through activation; application draft value remains equal. |
| Real reload reconstructs desired functionality | Explicit reload must change the token, restores active 2.0.0 and draft, and calculates 102.50. This also appears in the original restored screenshot. |
| Exact artifact transfer | UI export equals the retained v2 artifact; a fresh context begins with no plugin/empty draft and executes imported 2.0.0 with result 102.50. This is the same compatible consumer, not independent SPI conformance. |
| Built-in selection and protected boundary | Shipping off yields 95.50 and survives reload; disable/remove commands for the control capability reject without changing persisted profile. This is a fixture guard, not authentication. |
| Pre-import rejection preserves healthy state | Wrong-target and tampered candidates leave persisted profile and active 2.0.0 intact; rejected-import sentinel stays 0; normal calculation still returns 102.50. |
| Disable differs from remove/data deletion | Disable survives reload with installed artifact retained and calculation unavailable; re-enable works. Removal survives reload with no installation, draft retained and re-enable rejected. |
| Native-JS mutation control | Recorded values are mixed 110, captured 11 and whole-new 115. These demonstrate this control's lookup boundary, not a Lively/Pharo defect. |

All 41 recorded actual/expected values match. The passing native test also
contains the reviewed direct assertions, including changed reload token and
the expected command failures. No passing observation is inferred from only
an event label or a source comment.

## Original screenshot verification

Both original 1200×980 PNGs were inspected. The live screenshot shows active
2.0.0, current result 102.50, completed retained 1.0.0 result 120.00, the draft
and original document token. The restored screenshot shows active/stored 2.0.0,
result 102.50, a changed document token and reset transient held-call UI.

A tool-preview reading briefly made the restored textarea appear blank. That
impression was not treated as a runtime defect: the reviewer read the original
PNG pixels and ran the already installed OCR tool without editing an image or
rerunning the browser. OCR reads the full draft sentence in both originals.
The text-containing interior rectangle `[94, 378, 580, 431]` is exactly equal in
both PNGs: 77,274 RGB bytes, zero differing bytes, region SHA-256
`3ae9b4aad4835d57915cb28341436547d627d1df41c839f73b46c0db03d2586b`.
Thus the original restored image contains the same painted draft text. The
read-only analysis is retained in `frontend-visual-verification.json`, SHA-256
`9094f039fb90ec9f1bbd3f0c12c518f597f91a6e0253df862a72680170dc1ae0`.

These images are snapshots at the reviewed live/restored checkpoints; the later
management/rejection outcomes are established by source and recorded assertions,
not claimed as visible in those earlier images.

## Qualification limit

This demonstrates trusted pure-logic replacement in one concrete browser
consumer, persistence across page reload, compatible same-consumer transfer and
the named management/rejection behaviors. It does not qualify hostile-code
containment, arbitrary import/dependency admission, resourceful plugin cleanup,
physical ESM unload, browser/backend coordinated rollout, multi-tab contention,
user data/schema migration, independent implementation conformance or an agent
authoring platform. No runtime LLM authored the replacement. The ordinary-update
interruption decision remains OPEN; the experiment's retained-call profile does
not settle that policy.
