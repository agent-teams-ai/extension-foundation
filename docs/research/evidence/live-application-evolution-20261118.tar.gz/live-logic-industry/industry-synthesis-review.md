# Bounded audit of the four-industry synthesis

Date: 2026-11-18. Reviewer: `live_logic_industry`.

## Scope and result

Reviewed the root report's four new industry mechanisms and their architectural
inference against the two retained research reports/ledgers. This is not a new
industry search or runtime test. **The four substantive summaries are supported.
One ambiguous Directus reload phrase should specify browser page reload.**

Root report reviewed:
`docs/research/live-application-evolution-vision-and-executed-spikes-2026-11-18.md`,
SHA-256 `0cce4db7b13633ab907164278a6605a659c88f9e2a97de20ddf19e753efa2671`.
Its execution checkpoint still explicitly says hosted browser results are
pending; this audit does not turn that checkpoint into a runtime pass.

Evidence ledgers reviewed:

| Ledger | SHA-256 |
| --- | --- |
| `live-logic-industry/source-ledger.json` | `9ddf57efdd05cd9b24e3158a5da64b9de745ed81f3ac431a89a31cf08bebd7c3` |
| `persistent-industry/source-ledger.json` at audit start | `076c213c989406d5857e3f672f9a8dfe9c6a469708a4aefe8f1c1dc4f3931738` |

The first ledger derives from this reviewer's original exact-source inspection.
The second was read with its accompanying report; this synthesis audit did not
independently re-execute or re-fetch all Directus/NocoBase implementation files.

## Claim mapping

| Root claim | Evidence and limit | Assessment |
| --- | --- | --- |
| Directus durable settings, serialized unregister/load and separate browser handling | Persistent-industry D1/D2/D4/D5: exact release code separates settings transaction, asynchronous reload request, queue coalescing, package storage and browser reload notice. | Supported. No healthy-old lease, arbitrary callback settlement or global atomic activation is inferred. |
| NocoBase installed/enabled/version reconstruction and started-application restart path | Persistent-industry N1–N4: current manager paths, persisted collection/repository and `tryReloadOrRestart` distinguish application restart from direct dispatch replacement. | Supported. The root does not claim that every path restarts the Node process or preserves current work. |
| Lively mutable module bindings/class updates and source-save/live-apply distinction | Exact pinned `module.js`, `change.js`, class runtime and serialization sources support live authoring; `changeSource` starts writing/evaluation through `Promise.all` without a common rollback in that inspected function. | Supported and narrowly scoped. The report does not promote the developer server into a production plugin sandbox or claim an executed upstream failure. |
| Pharo structural migration and retained resource limits | Pinned class installer copies slots/forwards identity; its shrinking-layout path invalidates affected retained block code. Pinned Socket source says sockets do not survive snapshots. | Supported. The root preserves the narrow path qualification and does not claim all callbacks fail or that image persistence preserves external handles. |

The root labels immutable admitted generations plus consumer-owned selection
and recovery as **Inference**. It is a design recommendation informed by source
mechanisms and the separate backend experiment, not a universal industry
adoption claim. A separately qualified in-place editing profile remains possible;
ordinary-update interruption stays OPEN. The four implementations are described
as studies, without a new permissive-license or dependency-adoption claim.

## Directus reload wording clarification

The phrase "an already-open editor retains its schema until reload" needs one
specific noun: **until browser page reload**. The persistent-industry owner
rechecked the same official
[rich-text guide](https://directus.com/docs/guides/extensions/app-extensions/richtext)
and confirmed that the old schema/version survives a server extension reload;
saving and reloading the browser page applies the new version. The guide's
separate field-configuration rule applies when the item is opened again.

The ambiguity came from compressing two different reload boundaries, not an
architectural disagreement or a newly discovered upstream defect. The owner is
clarifying its lane prose/ledger and the root was sent the corresponding
one-phrase correction. No additional experiment or research scope is needed.
