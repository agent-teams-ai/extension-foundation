# Independent review: bounded hosted browser qualification

Date: 2026-11-18. Reviewer: `live_logic_industry`.

## Verdict

**Revised workflow is ready to run.** The first hosted job passed its compiler
and browser-test step, then failed to upload evidence because the artifact
action rejects dot path components. The initial source review missed that
action-specific restriction. The minimal canonical-path correction below has
been reviewed; the frozen input and runtime assertions are unchanged.

This source/setup verdict is not a successful workflow/evidence-delivery claim.
The next hosted job must complete and retain its actual observations before the
final browser result review.

The reviewer changed no repository file, installed no dependency, launched no
browser and triggered no workflow. Read-only parsing and archive/hash checks
were performed in the existing environment.

## Exact inputs

Repository: `/workspace/scratch/58e9c088d2ee/extension-foundation`.

| Reviewed file | SHA-256 |
| --- | --- |
| `.github/workflows/live-application-browser-spike.yml` initial reviewed version | `06e7b0f48931395024ef7fad5009a895be001f97f8605dc1cb9ee03875b380de` |
| Same workflow after canonical-path correction | `2c5658f5aa56ff661da24cb471cacc2a239dc4d0f92e9d07536d81d82b9351af` |
| `docs/research/evidence/live-application-browser-input-20261118.tar.gz` | `ee51b6c1cddd63f33b4a56a505140b46876fb8e2414b62920345705b38138ac4` |
| `docs/research/evidence/live-application-browser-input-20261118.manifest.json` | `3c2adb86368e4fa549ed3869fbf7ff94c61c638dc7aebce5bfdf620a3f2a6b6a` |
| Archived final `frontend-spike/browser.test.ts` | `b44b477ae4a3e374f10b262b2e830f2ac6fc9422877275ba3fddc9a50087f631` |
| Archived 11-source inventory | `c0e144f7700e6d57cbea87c2e39362c12ccf1227810ea73f8fadc3a6bf119ad3` |
| Archived `package.json` | `d27ce859713298d3253ffba69018f00573308d77fd6f3c2f84a546c6dede5ec7` |
| Archived `pnpm-lock.yaml` | `9b16d2a88ad6548d63959050788357edc66bfdbdc6abbcec66a673557cf0832e` |

The archive is 14,532 bytes with exactly 14 regular members: 11 authored source/
HTML/configuration files, their source inventory, and the existing disposable
package/lock pair. Every member's name, size and SHA-256 matched the outer
manifest. The inner source inventory matches the previously reviewed final
source. No generated v2 artifact or prior successful result is included as a
substitute for execution.

## Checks and reasoning

### Parsing and trigger scope

YAML was parsed with the existing Python YAML package's BaseLoader, preserving
the `on` key as text rather than YAML 1.1's boolean interpretation. All three
Bash run blocks passed `bash -n`; the embedded extraction program parsed as a
Python AST. These are syntax checks, not an assertion that GitHub has already
accepted or executed the job.

The one job runs only on pushes to the existing draft branch and changes to the
workflow or its two frozen input files. It does not add a broad pull-request
trigger or change existing CI gates. A documentation/results-only follow-up can
reuse evidence for this unchanged input rather than rerunning the same probe.
The review inspected the repository's existing CI and found no working-tree
change to its workflow, package or lock/workspace files.

### Archive custody and run binding

Checkout explicitly selects `github.sha` and does not persist credentials.
The extraction step checks archive size/digest, unique manifest entries, exact
member membership/count, regular-file type, safe relative paths and each
member's byte length/digest. It writes captured bytes itself rather than using
unrestricted tar extraction. The fresh destination is a sibling of the checkout;
an existing destination causes creation to fail rather than overwrite it.

The retained input receipt binds the manifest's archive digest and file list to
the actual `GITHUB_SHA`, run ID and run attempt. The reviewer independently
verified the exact archive digest above. The manifest is not an external trust
authority: its credibility comes from the reviewed bytes at the exact checked
out commit. The result review must use that same binding, including when later
documentation is delivered on a newer commit.

### Package-manager and browser setup

The sibling location avoids inheriting Extension Foundation's root pnpm
workspace. The archived package pins pnpm 11.25.0, TypeScript 7.0.2 and
Playwright 1.62.1; the exact lock includes their integrity records and resolved
peers. Existing disposable GM/Effect dependencies remain unchanged. No alternate
dependency release or root workspace reconfiguration is introduced.

The exact pinned pnpm action was independently read through GitHub's file API:

- [Action declaration](https://github.com/pnpm/action-setup/blob/008330803749db0355799c700092d9a85fd074e9/action.yml), blob `d2f1196c0dc16f67cd1e428e570503b286d2157b`, documents `package_json_file` relative to `GITHUB_WORKSPACE`.
- [Installer implementation](https://github.com/pnpm/action-setup/blob/008330803749db0355799c700092d9a85fd074e9/src/install-pnpm/run.ts), blob `3c1cceabd74772b92f7e0f73f6db708f2ea1c3ab`, joins that workspace with the supplied path and checks the declared version for disagreement.

Consequently `../live-application-browser-spike/package.json` points to the
already extracted sibling package and agrees with the explicit action version.
It does not accidentally compare fixture pnpm 11.25.0 against repository pnpm
11.18.0. The action itself runs on Node 24 and handles its bootstrap; the next
step selects Node 24.22.1 for the fixture.

Installation uses frozen lock, ignored package lifecycle scripts, strict engines
and strict peer dependencies. Chromium is installed through the pinned
Playwright CLI's official browser command. The reviewed harness defaults to
that installed browser, with no custom browser flags; the workflow does not set
the optional local diagnostic executable override.

### Failure propagation and evidence

The extraction and test steps use GitHub's explicit Bash shell. GitHub documents
that this shell enables early exit and pipeline failure propagation; the test
script also explicitly sets pipefail. A failing compiler or native test cannot
be turned into success by `tee`. There is no `continue-on-error`, swallowed exit
or conditional success substitution. See the official
[workflow shell semantics](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#jobsjob_idstepsshell).

Compiler output, native runtime output, input receipt, environment versions,
late compilation record, result JSON, artifact bytes, generated code and actual
screenshots are retained by an always-run artifact upload. Uploading after a
failure preserves diagnosis; it does not change the prior job failure. A job
timeout or setup failure is not browser success. The fixed timeout bounds this
research job without pretending to qualify long-running product lifecycle.

The job requests repository contents read permission, references no repository
secret and has no repository-write/publish step. Pinned action SHAs match the
existing CI's action choices. Installing dependencies and browser prerequisites
mutates only the disposable hosted runner; "read-only" here describes repository
authority, not an assertion of zero runner filesystem writes.

## Assertion integrity and remaining observation

The archived harness is the reviewed strengthened source: actual v2 construction
and publication happen after a visible v1 result; retained v1 completes while
current input and built-in shipping differ; the document token separates live
replacement from reload; persistence, transfer, disable/remove, data retention,
protected control, rejection sentinel and native-JS control assertions remain.
Nothing was weakened to fit hosted execution.

No additional source correction is requested after the minimal workflow fix
below. A final pass requires the actual hosted result on these bound inputs and
the corresponding observations/logs.
That result will qualify only the named trusted browser fixture, not production
security, independent implementation conformance or a new universal platform.

## First hosted attempt and minimal correction

The first completed job was `134464490823` in run `44203816704`, on published
head `10a9d29cf845e78b9d8a8c0149ffaba72d9c107d`. Read retained files under
`frontend-spike/hosted-attempt1/`:

| Evidence | SHA-256 |
| --- | --- |
| `workflow-job.log` | `c784e936a11608b327c60a7d6a169b45598e9970537323ff896e30344e59d64e` |
| `job-and-artifacts.json` | `547f175c60aea84ccc0df05845c9b498081d92ba6e36c8f52259278fb351b0d4` |

The compiler and browser-test step completed successfully. Native output reports
one test passed, zero failed/skipped and duration 6,492.049683 ms. The job as a
whole failed in the upload step, and its artifact list is empty. The failed
pattern was the otherwise filesystem-valid absolute path containing the
checkout's `../live-application-browser-spike` sibling traversal. The upload
action's pattern validator rejects `.`/`..` components. This was a workflow
formatting defect, not a failing plugin calculation or browser assertion.

The initial review checked the sibling filesystem path and pnpm's resolution
correctly, but did not catch the upload action's different pattern restriction.
That initial readiness verdict cannot be used as evidence that upload worked.

The exact minimal diff now:

- Gives the verified extraction step ID `inputs`.
- Calls `Path(...).resolve()` once for the already intended sibling directory.
- Writes the canonical directory through `GITHUB_OUTPUT` after successful
  extraction/receipt creation.
- Uses `steps.inputs.outputs.directory` for both run working directories and
  the three upload paths.

Independent parsing passed again. The example resolves to
`/home/runner/work/extension-foundation/live-application-browser-spike`, without
dot components. AST inspection confirms that the output entry and JSON receipt
use real newline characters. The step-output expression is consumed only by
later steps. The archive SHA remains
`ee51b6c1cddd63f33b4a56a505140b46876fb8e2414b62920345705b38138ac4`;
there is no dependency, assertion, compiler or runtime-source change.

The exact pinned upload action's
[README](https://github.com/actions/upload-artifact/blob/cf430e030ddbb5b0abf93d22962f4752f3646cd9/README.md),
blob `b708eb322c6cbc798af63dc0314eb9f7fb112d95`, explicitly supports absolute
paths. Canonical absolute paths therefore address the observed defect through
the action's normal supported interface.

A repeated real job is warranted to obtain the missing JSON/screenshot/artifact
evidence. The first job's successful test step remains recorded honestly, while
overall workflow success and complete artifact custody remain pending.
