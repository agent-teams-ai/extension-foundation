# Independent review: native Effect backend live-logic spike

Date: 2026-11-18. Reviewer: `live_logic_industry`.

## Verdict

**Pass for the bounded trusted single-consumer experiment. No material finding
remains open.** The corrected fixture's runtime attempt 3 exited 0 with five
tests passed and zero failed, skipped or cancelled. Its source and raw result
establish the specific semantic-generation, native resource-lifetime and
process-recovery observations below; they do not qualify a production Host or
settle the owner's interruption policy.

The reviewer read source and retained output; no tests were run and no backend
files were changed by the reviewer.

## Exact reviewed inputs

Paths are relative to
`/workspace/scratch/58e9c088d2ee/live-evolution-20261118/backend-spike`.

| Input | SHA-256 |
| --- | --- |
| `backend.ts` | `a23e4ab861f4a80121fc018e697c93993926c0c1f4bfb90c9b82d918f7a05e2b` |
| `backend.test.ts` initial reviewed harness | `c6516a6f821e31b0c3a3920bb88fd2241831dffe4fc084e6a475875ee3d21849` |
| `backend.test.ts` corrected final harness | `1d83a4b89323765ad5c31eb4a469b9f3e195102aa836584da07342c8dacc8700` |
| `child.ts` | `da6c61a3526a0b5b8099eb0b722732c188da27573a60cf96eeb27ebad37c7038` |
| `contracts.ts` | `f215f662e1e044d8f376a5d40c070dd5cda2ec193f0b352d1db9f660dc76cb9e` |
| `plugin-src/v1.ts` | `6e142ce38fc2206971abfdd3ac02197e6b3a6886ae33dd5e0d6f712fb6a3ee36` |
| `plugin-src/v2.ts` | `8a83ae28608dfb76d7945c2997ed7db8969b9413788053876c684456c0680c29` |
| `plugin-src/rejected.ts` | `a00904fda1f8c68a25a48b561395d10e64adff951561cb08aedca820ef8dbb2e` |
| `plugin-src/tampered.ts` | `80cac9be2e55cef1ab73a78d54a02b4fa7dd8f5928e69ac4928112486dee92b0` |
| `tsconfig.json` | `4d4612d44d1a8104f65471ad7f0f09f331eb21eb2c440f6f66cba7e083baf040` |
| `tsconfig.plugins.json` | `9df1de755a7fb82d35acc601772a7042e9cc53e7ac1c995c5b3f5edd71e9b34a` |

Read the complete sources/configs, the reviewed backend plan, the initial
failure explanation, full `runtime-attempt2.log`, the corrected harness changes
and full `runtime-attempt3.log`. The backend owner confirmed the original attempt
3 command exited 0 and the implementation/child source hashes were unchanged.

| Retained raw evidence | SHA-256 |
| --- | --- |
| `runtime-attempt2.log` | `fbcb6644e18ad322d371baec64f5dc1a12af4696c016477858491596afc6c57d` |
| `runtime-attempt3.log` | `5ee6299cf7de42d702327fcc40c702c041ce21bc9e306342de93fe6a0f52264f` |
| `typecheck-attempt3.log` (empty successful compiler output) | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

An empty compiler log alone is not proof of success. The owner separately
reported the original strict TypeScript check's successful exit. The runtime
log includes all five successful scenarios and final native-test counters;
the original command's exit was separately confirmed rather than inferred from
absence of output. The reviewer did not rerun any command.

## Finding B1: algorithm identity should remain different at old-call completion

In the initial reviewed harness, one v1 request is held while selection changes
v1 → v2 → a fresh v1 incarnation. It completes only after the new v1 activation.
The expected old total 140 could also be produced by a faulty implementation
which reread the newest active algorithm at completion. The source correctly
retains its capability, but this numeric oracle does not independently falsify
that late-reread error.

The bounded correction is to complete one held v1 request while v2 is still
active, requiring old 140 versus current 120. The same-artifact incarnation
case should use a separate call/phase while preserving its real-resource
assertions. This refines the existing two discriminators; it is not a new
scenario matrix.

**Closed in final harness and attempt 3.** The owner now admits two old v1
calls. The first completes with total 140 while v2 remains active; an independent
new request still returns 120 and the owner snapshot still selects v2. The
second old call remains borrowed across reactivation of the same v1 artifact
with a fresh incarnation, then completes and permits physical resource close.
The final log records both distinct outcomes and the original/new incarnations.
The new harness also compares child-reported ready/checkpoint/error PIDs to the
parent's actual `fork().pid` before accepting those messages.

## Other implementation and observed results

### Ownership and resource lifetime

The ordinary consumer owns one desired profile and active selection. Native
`Semaphore` protects admission and selection. Preparation happens outside that
gate; each requested revision is fenced at publication. No duplicate graph,
resource registry or borrower counter was introduced into the implementation.
Test-only handle/closure maps are observers, not lifecycle owners.

`RcMap` owns keyed resources; its entry Scope builds the Get Modular Layer.
Candidate readiness and actual HTTP calls borrow through separate native scopes.
Each activation gets a new frozen generation object and UUID incarnation,
independently of content-derived implementation identity. The same-artifact
case observes a distinct incarnation, kept-open old handle and eventual map
membership reduction.

The file oracle includes more than an event label: requests and assertions read
actual bytes from a `FileHandle`; finalization assertions require `stat()` to
reject with EBADF. The response-writing promise is inside the request scope, so
the borrow remains owned through this finite response completion. This is not a
long-lived streaming-response guarantee.

### Failure and stale preparation

The rejected candidate throws only after its real file has been acquired. The
attempt 2 test requires physical close, unchanged persisted selection, an old
algorithm response of 140 and one remaining native map entry. A separate held
preparation is overtaken by requested revision 3; the late result is stale,
closes its own file and cannot overwrite revision 3. The current handle remains
usable. These are supported by the inspected assertions and successful output.

### Restart, commit barrier and artifact identity

Desired-state persistence uses a single-writer atomic file replacement fixture.
It is explicitly not the product PostgreSQL catalog, distributed CAS or
power-loss durability. Actual child processes serve HTTP; the parent observes
process exits and distinct PIDs. The attempt 2 recovery sequence reported
PIDs 24, 36, 48 and 60, with a fresh incarnation after ordinary restart.

The child acknowledges the post-commit/pre-publication IPC checkpoint, then
waits indefinitely there. The parent independently reads the desired profile
and status showing desired v2 while active v1, observes SIGKILL and child stream
closure, then starts a new process. Recovery serves v2 total 120 at revision 2.
The killed process never claims v2 activation. No Effect-finalizer result is
inferred from SIGKILL or OS resource closure.

Disable persists an unavailable desired state; the fourth process returns 503
and artifact bytes remain installed. This backend case proves disable/restart;
frontend work owns the separate remove/data-retention behavior. It does not
establish a built-in artifact conversion or a public installation catalog.

Artifact manifests and hashes are validated before import; import evaluates the
same captured bytes through a data URL, not a second read of the verified path.
The known generated modules have zero runtime imports. The altered-artifact
fresh boot fails with the expected digest error, never reports ready, and its
fully drained stdout contains no top-level sentinel. This is an identity and
recovery oracle for trusted known modules, not a general admission or sandbox.

### Initial failure and boundaries

The first runtime fixture used raw UUID segments where Get Modular's identifier
grammar requires a lowercase leading character. The retained explanation
identifies that source error and the correction to `h-<sha256>` implementation
identity, keeping incarnation separate. The compiler passing did not imply
runtime declaration validity; no upstream grammar or expected total was changed
to make the test pass.

This probe cannot qualify hostile-code containment, arbitrary state migration,
multi-process routing/transactions, plugin code unloading, arbitrary cleanup
liveness or the owner's still-open ordinary-update interruption policy. Local
resource files are disposable fixture data; the demonstrated native cleanup is
physical descriptor closure, not a promise of generalized external-effect undo.
