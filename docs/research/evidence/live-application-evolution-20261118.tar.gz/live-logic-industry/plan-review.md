# Independent plan review: live logic and semantic continuity

Reviewed on 2026-11-18, Europe/Kiev, before experiment execution.
Reviewer: live-logic-industry. Read-only plan review; no source edits or runtime tests.

## Inputs

| Plan | SHA-256 |
| --- | --- |
| Root plan.md | `8df80949d25564df855398b57fbaacc57808aa9ecb0778a9e04afb4786709299` |
| backend-spike/plan.md | `79822b180d19d9c940728ba6e4eaa7a10205f327321b5e442bfcbcb18664aa14` |

## Verdict

**Proceed after the bounded identity/oracle clarifications below.** The plans
choose useful observations rather than a synthetic universal framework.
Native resource ownership, concrete consumer contracts, scoped failure evidence
and the open interruption policy are preserved. Nothing here requires a new
product decision or publication approval.

## Material clarifications

### R1. Bind the executable bytes that actually run

A SHA-256 of an entry file does not bind transitive imports. Reading and hashing
a file followed by an independent import from a mutable path can also execute
different bytes after a concurrent replacement.

For this bounded fixture, the simplest valid boundary is a self-contained
generated quote module and execution of its verified byte snapshot. Otherwise
bind and validate its complete declared executable closure. An already admitted
built-in host dependency is a different authority; it should not accidentally be
represented as part of the plugin bytes. Record whether concurrent malicious
writers are excluded rather than claiming their safety.

The necessary observation is that the byte sequence executed is the sequence
identified in the receipt. A bad-digest test before a later independent read
proves a narrower condition. Do not build a general loader merely to handle this
fixture.

### R2. Prove live browser replacement independently from persisted restoration

Preserved draft state and a changed result could pass even if the page silently
reloaded and restored the draft. Give each fresh document a non-persisted
in-memory instance token and assert it is unchanged through activation and
in-flight replacement, then changed by the deliberate reload. Assert the DOM
calculation and user input as planned.

The native-JavaScript negative control should expose a mixed *calculation* or
two incompatible revisions within one paused operation, and its positive
counterpart should produce the full independently expected v1 result. Keep
object lookup and an already retained function distinct. This control does not
execute or reproduce Lively, Pharo or their VM semantics.

### R3. Make the crash boundary and its claims exact

The child must acknowledge the completed desired-state commit and then wait on
a deterministic barrier before publication. The parent stops that exact child,
observes its exit and starts a process with a distinct PID. Avoid a sleep-based
guess about whether commit or activation occurred.

Keep desired revision and the previous process's observed active revision
separate. Forced process exit releases OS-owned resources but is not evidence
that Effect finalizers ran gracefully. A committed target whose later recovery
fails must produce the declared failure state, not a retrospective claim that
the target had already activated before the crash.

### R4. State RcMap key and reactivation semantics

A retained key may still denote the same entry/resource when a feature is
disabled and enabled again. Specify whether the key denotes artifact identity
with intentional reuse or a fresh activation incarnation. Do not imply a fresh
instance simply from selecting the same digest again. Native keyed borrowing
can implement either declared profile; no second reference counter is needed.

Also keep the semaphore boundary narrow: acquisition of a ready borrowed entry
must not run the substantive request under the owner's admission lock. The plan
already puts preparation outside this lock; the code review should verify the
actual scope.

### R5. Bound the portability claim

Import into a new browser storage context is good evidence of transferring an
artifact to a fresh installation of the same compatible consumer. It does not
establish an independently authored implementation of a public SPI or reuse in
an arbitrary project. The backend and browser may use different concrete quote
contracts, as the plan correctly allows.

State those bounds in the result. There is no reason to add another framework
or a third consumer solely to broaden a research claim.

## Scope and evidence notes

- The two fixtures cover important parts of the expanded vision, not all
  built-in feature management, permissions, migration and sharing policies.
  Built-in control should either have a tiny explicit eligible-feature case or
  be labelled a recorded architectural target rather than an executed result.
- A client/server compatibility rejection before the first observable effect is
  an effective discriminator. It must not be presented as a sandbox test.
- Preserve every actual failure with its inspected cause. An intentionally
  adverse native-JavaScript control passing its expected mixed-behavior oracle
  is not a failed upstream product test.
- Ordinary-update interruption stays OPEN. Testing a non-interrupting retention
  profile does not adopt it as the universal product default.
- No additional unrelated test matrix is requested. These corrections can be
  implemented within the planned scenarios and reviewed through their retained
  source, logs, actual I/O and browser observations.

