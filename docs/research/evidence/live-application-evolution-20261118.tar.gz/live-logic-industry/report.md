# Live object and live logic systems: Lively.next and Pharo

Observation: **2026-11-18, Europe/Kiev**. Research lane: live-logic-industry.
This is read-only primary-source research. No upstream program, dependency
installation, runtime experiment or benchmark was executed. Upstream test files
were inspected, not run. No production runtime, public SPI, permission rule or
ordinary-update interruption policy is selected.

## Result for the architecture discussion

Both systems substantiate the owner's vision: a person can change meaningful
behavior in an already running object system and keep useful state. They also
show why live editing, a reusable plugin artifact, a reproducible restart and
safe continuation of existing work need different contracts.

The strongest transfer is a continuous authoring-to-application workflow with
explicit identities and outcomes. We should retain the existing authority for
composition, admission, resources and state. An in-place editing engine is an
alternative execution profile; it must not silently stand in for an immutable
generation guarantee.

## Exact observation identities

| System | Inspected identity | Technology and availability | License observation |
| --- | --- | --- | --- |
| Lively.next | Main commit `694053603639947be013f3e6d803979a87af988b` | JavaScript, instrumented module loader, live class runtime, object graph serialization. The current README calls it beta and provides nightly builds; this is a source snapshot, not a qualified stable package release. | Root MIT license [L0]. |
| Pharo | Release `v14.0.0`, commit `1ad0bf20f22fd3a720ec809b2b84096c3c6d1129` | Smalltalk image, reflective class/method system and its VM-dependent primitives. Released 2026-10-26. No VM/image was installed for this research. | Root license says MIT with Apache-licensed parts and contains additional asset notices [P0]. |

The GitHub latest-release endpoint for Lively.next returned 404. That is not a
claim that no release artifacts exist: the inspected README explicitly links
nightly artifacts. Pharo's later Pharo14 branch head was observed separately but
was not substituted for the release pin in implementation claims.

## Lively.next: a direct realization of live authoring

### L1. Live bindings and object behavior are deliberately mutable

**Source.** The module API exposes the evaluated module environment, including
a recorder of top-level definitions. Instrumentation and dependency setters let
changed definitions reach importers. The class runtime searches a class holder
for an existing constructor, reuses it when suitable, changes its superclass
and installs new descriptors on the existing constructor/prototype. Methods
removed from the new definition are deleted. Class-related subscriptions
propagate later superclass binding changes. [L1] [L2]

The upstream class/module tests explicitly create an instance, then modify its
superclass module and assert that the existing instance gains or loses a method
or managed property. These are inspected assertions, not our executed evidence.
[L3]

**Inference.** This is stronger interactive behavior than simply loading a fresh
ES module. It also has different consistency semantics: an object reference can
keep its identity while later method lookups obtain changed behavior. Capturing
the object alone therefore does not establish one semantic revision for an
entire asynchronous operation. A future comparison must observe a lookup before
and after an await, and separately observe an already captured function.

### L2. Client/server compatibility is checked before evaluated changes

**Source and documented contract.** Packages and modules can declare client,
server or shared environments. Module load and evaluated source change call an
environment assertion before executing the module. The upstream integration
test checks that a client-only module fails in a server environment without
running its top-level effect; it also checks changed declarations and linked
package resolution. [L1] [L4] [L5]

**Transfer.** Declare execution compatibility and reject a wrong-target
candidate before its first effect. Keep that check distinct from authorization,
trust or isolation: an environment label does not make code safe or grant
access. Our frontend/backend packaging can use a qualified equivalent without
copying the entire Lively loader.

### L3. Saving source and changing the live system are distinct outcomes

**Source.** `ModuleInterface.changeSource` defaults to both saving and
evaluating. It starts the resource write and live source-change operation
together with `Promise.all`. The ESM change implementation updates its module
record and dependency setters before executing the new body. Errors are
announced and rethrown; these inspected functions do not wrap the source write
and live mutation in a common rollback transaction. [L1] [L6]

**Inference, not a reproduced defect.** A write may succeed while evaluation
fails, or evaluation may affect runtime state while saving fails. That is a
meaningful interactive editor contract, but it cannot be relabelled an atomic
production activation. A saved candidate, the desired selected revision and the
currently serving revision must be observable separately. The existing owner
should define recovery from each partial outcome.

### L4. Module removal is not evidence of arbitrary resource release

**Source.** The inspected unload route removes the module and optionally its
dependents from the loader, clears its environment and top-level observer list,
removes cached translation data, and emits an unload notification. Reload uses
the dependent/importer closure in this implementation, then imports again.
[L1]

**Inference.** This particular route does not establish that a previously
retained callback, socket, timer or external operation has ended. It is not a
project-wide claim that Lively has no cleanup mechanisms. Our reuse assessment
must attach cleanup to the actual owning scope and required observation, not to
a registry deletion or notification name.

### L5. Persistent objects still need code and dependency availability

**Source.** The serializer traverses an object graph and supports selected or
excluded properties and custom serialization hooks. In the generic property
path, a function becomes undefined if no serialization plugin has handled it.
Class-aware serialization records metadata used to recreate class instances.
This is not arbitrary JavaScript closure or execution-stack serialization.
[L7] [L8] [L9]

The morph snapshot path can include local object packages and their dependency
information. The load path reconstructs package files and imports required
modules. If the same package URL is already loaded with an equal or greater
version, that path keeps the loaded version; the adjacent source explicitly
flags compatibility of old objects as something to ensure. Some module import
failures are logged within this helper. [L10]

**Transfer.** A shareable plugin needs its executable identity and required
dependency/state contract, not just a dump of a live object. Reusing whatever
higher version happens to be installed is weaker than reproducible activation
from admitted immutable identities. A consumer may deliberately offer that
weaker editing behavior, but the packaging profile must say so.

### L6. The authoring platform and deployed application are separate profiles

**Documented contract.** The pinned root README describes live programming and
direct manipulation, but says platform updates restart the server and require
the session to reload. It distinguishes serving built/frozen applications from
publicly exposing its development server, whose filesystem and shell powers
make that exposure discouraged. It also declares the project beta without
stable API guarantees. [L0]

**Inference.** Lively is unusually relevant to the user experience we want:
inspect, edit, apply and immediately observe meaningful application logic.
Its development environment is not an admission or isolation design for a
multi-user agent backend. Borrow the feedback loop and the explicit code/state
model; qualify deployment and trust independently.

## Pharo: VM-supported evolution with concrete limits

### P1. Method changes and structural instance migration are separate mechanisms

**Source.** Method installation places a compiled method into a behavior's
method dictionary. Structural class changes use a class builder/installer
pipeline. The installer creates replacement instances, initializes slots,
copies matching old slot values and forwards identity to the replacements;
class and class-variable identities are forwarded in an uninterruptible region
of the migration path. [P1] [P2]

**Inference.** A runtime capable of changing object identity and layout can
preserve much more than ordinary JavaScript imports. Slot copying nevertheless
does not invent a business migration between different meanings or invariants.
The operation needs runtime-specific semantics; reproducing the whole Pharo
object memory in a TypeScript plugin library would be a different product.

### P2. Some retained closures are intentionally invalidated

**Source.** On the instance-migration path where the instance layout shrinks,
`ShiftClassInstaller` finds retained full block closures whose receiver is an
old instance and replaces their compiled blocks with an error-producing block.
It then forwards instance identity. [P2]

This is positive safety counterevidence to an unlimited continuity claim, not
an alleged Pharo regression. Even this highly dynamic runtime explicitly
rejects a category of retained work that can no longer use the changed shape
safely.

**Transfer.** Define which old callbacks, streams and sessions survive each
update profile. A state migration or object-identity operation does not by
itself authorize them or make them compatible. The ordinary-update interruption
choice remains open; a test can compare named profiles without adopting a
product-wide default.

### P3. Saving an image is a lifecycle operation, not a socket checkpoint

**Source.** The snapshot operation stops the current session, invokes the VM
snapshot primitive, installs a new session on image startup and runs startup
again. A stop failure has an explicit attempt to restart the session. On a real
startup, the working session clears external objects before startup handlers.
[P3] [P4]

The network implementation explicitly requires network reinitialization after
startup, and the socket status primitive documents that sockets do not survive
image snapshots. [P5]

**Transfer.** Persist selected plugin identity and logical state, then reacquire
external capabilities under the existing resource owner after restart. An image
or snapshot is not proof that a TCP session, credential grant or external side
effect has survived. Test actual restart and reacquisition failure, including
the user's visible outcome.

### P4. Package loading coordinates definitions and notifications

**Source.** Monticello's loader sorts additions and reverses the removal order.
It loads class definitions, delays method-addition announcements until the
method batch has loaded, applies removals, then runs postload operations. The
class-loading path retries definitions when progress may resolve dependencies
and reports persistent errors. Package unload is represented as a patch to an
empty snapshot. [P6]

**Inference.** Delaying notifications prevents observers from reacting to a
half-published method batch, but this mechanism is not evidence of one atomic
transaction covering arbitrary application code and external effects. It is a
useful precedent for staging observations until the relevant invariant holds,
while retaining explicit partial-failure/recovery semantics.

## What these alternatives change in our decision

| Aspect | Live object mutation | Immutable generation plus explicit selection |
| --- | --- | --- |
| Existing object identity | Can be preserved while methods or shape change, using runtime support. | Existing work retains its selected generation and compatible owned state where that profile promises retention. |
| Long operation consistency | Must define whether later lookups observe edits; a retained object alone is insufficient. | Must acquire selection and retention together and keep the required cohort through the actual operation lifetime. |
| State change | Runtime layout migration can help, but business semantics remain consumer-owned. | State schema and compatibility remain explicit; keeping old code alive does not isolate a shared database. |
| Failed change | Interactive systems may retain partial edits or saved source; report exact outcomes. | Candidate acquisition and selection can be separated, but effectful preparation and persistence failures still need cleanup/reconciliation. |
| Restart and sharing | Images/snapshots need code packages and external-resource recovery. | Admitted artifact identity, desired profile and compatible state need persistence; startup creates fresh runtime resources. |
| Fit | Powerful live authoring, exploratory tools and a deliberately qualified trusted in-place profile. | A promising candidate profile for predictable multi-request services, subject to the owner's unresolved policy and real consumer evidence. |

This table is architectural reasoning from the observed mechanisms, not a
benchmark or a decision to adopt either implementation. No new shared Host,
graph compiler, refcount runtime, catalog writer or state owner is proposed.

## Bounded falsifiers that can change the architecture

These are proposed checks only; select the few relevant to the experiment.
An independent expected result must come from the chosen profile rather than
from the implementation under test.

| Question | Adversarial stimulus | Useful observation |
| --- | --- | --- |
| Can one operation silently mix revisions? | Pause an operation between two dependency/method lookups; apply a change before resuming. Also retain a function directly. | Exact per-operation semantics and the distinction between a retained object, retained function and retained generation. |
| What persists after a failed live edit? | Save or publish a candidate, fail evaluation/acquisition, then restart the backend. Reverse the failure order too. | Desired, installed and active facts remain distinguishable; restart follows the declared authority and never silently promotes a failed candidate. |
| Is a target restriction checked early enough? | Supply a client-only module to the backend with a detectable top-level effect. | Rejection happens before that effect. This proves target checking only, not hostile-code isolation. |
| Does sharing preserve executable meaning? | Import a snapshot/plugin into a consumer with a conflicting dependency version already present. | Exact admitted dependency/state compatibility or a declared rejection, rather than an unreported version substitution. |
| Does disable/remove mean callbacks have ended? | Retain a callback and a resource, disable the feature, then attempt use and inspect cleanup. | Invocation permission, resource custody and physical cleanup have their declared independent outcomes. |
| Does restart preserve external-resource validity? | Restore logical plugin state after a real process restart; make resource reacquisition fail. | No stale physical handle is treated as live, and startup reports a supported failure/recovery outcome. |
| Do observers see an incomplete composition? | Publish related capabilities while an observer triggers work on the first notification. | The selected consistency unit is prepared before observation/admission; partial installation is visible as such. |

The source evidence favours separating a mutable authoring workspace from
admitted executable generations and durable consumer intent. A continuous user
flow can make those steps feel immediate without hiding the actual boundaries.
This recommendation preserves the user's all-category vision while allowing
different update mechanisms where their contracts genuinely fit.

## Primary-source navigation

[L0]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/README.md
[L1]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.modules/src/module.js
[L2]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.classes/runtime.js
[L3]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.classes/tests/classes-in-modules-test.js
[L4]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.modules/README.md
[L5]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.modules/tests/native-system-live-test.mjs
[L6]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.modules/src/change.js
[L7]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.serializer2/README.md
[L8]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.serializer2/object-pool.js
[L9]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.serializer2/plugins.js
[L10]: https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/lively.morphic/serialization.js
[P0]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/LICENSE
[P1]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/src/Kernel-CodeModel/Behavior.class.st
[P2]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/src/Shift-ClassBuilder/ShiftClassInstaller.class.st
[P3]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/src/System-SessionManager/SnapshotOperation.class.st
[P4]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/src/System-SessionManager/WorkingSession.class.st
[P5]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/src/Network-Kernel/Socket.class.st
[P6]: https://github.com/pharo-project/pharo/blob/1ad0bf20f22fd3a720ec809b2b84096c3c6d1129/src/Monticello/MCPackageLoader.class.st

Additional contract navigation: [Pharo features](https://pharo.org/features.html),
[Pharo 14 release](https://www.pharo.org/news/2026-10-26-Pharo14Release.html),
[Lively root license](https://github.com/LivelyKernel/lively.next/blob/694053603639947be013f3e6d803979a87af988b/LICENSE).
The adjacent ledger records exact blobs, symbols, retrieval classes and limits.

