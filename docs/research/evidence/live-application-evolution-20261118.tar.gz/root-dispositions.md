# Root dispositions: live application evolution

Date:2026-11-18, Europe/Kiev. This record separates review corrections from
owner-approved architecture. Ordinary-update interruption remains OPEN.

## Plans and source facts

Both independent plan critiques are retained. Before execution, the common
plan required exact captured executable bytes, no runtime imports in generated
fixtures, an actual document-instance token, a parent-observed crash checkpoint,
unique activation incarnations, separate disable/remove/data oracles and a
pre-import rejected-code sentinel. The target/ABI checks are not isolation.

Root independently checked seven key upstream implementations through official
GitHub reads; exact blobs are in root-provenance.json. No inspected upstream
project was executed. Current documentation is distinguished from release-pinned
source. No upstream license suitability is inferred from this research.

## Backend result review

The initial fixture UUID segment did not satisfy GM identity grammar. The
fixture now uses its artifact digest for implementation identity and keeps
activation incarnation separate. Core's early rejection was correct, not an
upstream runtime defect. Original diagnostics remain.

The first passing old-call test could have missed a newest-binding reread because
it completed only after v1 reactivation. Independent review required two held
calls: one completes while v2 is active; another tests same-artifact reactivation
and resource retention. PID checks now tie selected IPC observations to actual
parent fork handles. Strict checking and the final affected five-case run passed.

The root prose was then narrowed: candidate readiness holds are native child
Scopes, whereas HTTP operation borrowing uses Effect.scoped; physical postclose
evidence is FileHandle.stat rejecting with EBADF. No runtime rerun was warranted
for these accurate wording corrections. Reviewer verified the exact updated hash.

## Browser oracle and official execution route

The held-call test now changes current input and eligible built-in selection
before releasing old work, so the oracle tests the captured operation, not only
a version label. The old result must remain120 while new input/shipping yields
205.50. Frozen source remains bound to its hosted input manifest.

Local browser execution did not qualify: Chromium aborted before page creation
with socket EPERM. The official connected Browser lacked an originating context;
the separate cloud browser could not reach the local loopback fixture. The owned
server was stopped. No flags, tunnel, access override or weakened assertion was
introduced. The normal GitHub runner installs pinned Playwright's official
browser and executes the same assertions with only contents-read repository
permission. The independently reviewed workflow is an input-bound research job;
existing required gates and root dependency pins are untouched.

The initial report correctly marked hosted results pending. Final claims require
the actual downloaded output, input receipt, source hashes and independent
result review. Source/setup review alone is never substituted for execution.

## Industry prose clarification

The Directus richtext guide distinguishes server extension reload from a
browser page reload. Both the specialist and root report now say an already-open
editor retains the previous schema through server reload; saving and reloading
the page applies the new version. Field configuration changes separately apply
on reopening the item. This narrows the existing citation rather than claiming
a new upstream experiment. Root re-opened the official source and checked both
sections. The profile classification is an explicit proposal, not an adopted SPI.

## First hosted result and retained-output correction

Official run44203816704 completed all strict compiler checks and the browser
test successfully:1/1 with no skipped/cancelled cases,6.492s total. The workflow
then failed in upload-artifact because its absolute path still contained a
`..` segment. No downloadable artifact was produced. Completed-job logs retain
that precise distinction; the failed workflow is not relabelled green and the
missing JSON/screenshots are not claimed inspected.

The correction only canonicalizes the existing owned sibling directory with
Path.resolve and supplies that absolute path through a step output. Official
upload-artifact documentation supports absolute paths. No runtime input,
assertion, dependency, security flag, scope or permission is changed. A normal
new workflow execution is warranted to retain the actual result packet. The
first input commit's other required CI checks completed successfully before
publishing this correction, so no running required check is cancelled.

## Corrected hosted result

Run44205511602 at4f77b5f61b1053e9493091043c14a3caa447b7cf completed successfully,
including artifact upload. The official download's255662bytes matched GitHub's
SHA2565411de8b302497d496fc9dcb841675cacd1037588c90ee951d154df7a8a8320f.
All20members and the input receipt are retained. One native end-to-end test
passed with41recorded comparisons and0uncaught page errors; these are not
41independent test cases. The input archive remained unchanged.

Initial visual reading of the restored screenshot seemed to show a blank draft.
The original PNG was checked directly: its draft-text rectangle is byte-for-byte
identical to the visible live-state rectangle, and independent OCR reads the
full note in both. This resolved a preview/misreading concern; no missing-paint
incident, code change or extra browser rerun is claimed. The read-only verification
is retained with the independent browser result review.
