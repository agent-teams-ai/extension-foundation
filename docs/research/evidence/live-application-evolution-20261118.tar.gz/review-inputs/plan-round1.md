# Live application evolution: bounded qualification plan

Date: 2026-11-18, Europe/Kiev. Status: experiment plan for independent review.
No experiment result, public contract or production implementation is claimed.

## Owner direction and purpose

Users should be able to ask an agent to change substantive application logic
while the frontend or backend remains running, see the result, preserve it
across restart, reuse/share the resulting plugin, disable/remove it and manage
eligible built-in functionality. This is a high-priority architectural vision,
not a universal promise to migrate arbitrary running stacks or replace trusted
invariants. The canonical expanded vision belongs in existing OD-003, prominently
linked from README, AGENTS and the documentation index.

The experiment can change the first implementation profile and whether existing
native mechanisms suffice. It does not select the unresolved ordinary-update
interruption policy, publish an SPI, add a new product Host, supersede accepted
ADRs or authorize a merge. The prior controlled-restart baseline stays qualified
only within its retained scope. Each experiment explicitly chooses a retention
profile to test; that is not a default policy for production.

## Two complementary execution boundaries

### Backend: native scoped resources and real requests

Use real loopback HTTP, independently asserted quote calculations, exact
published Get Modular native Effect composition when it fits, and Effect4.1.4
RcMap/child Scopes. One consumer owns desired revision, admission and selection;
native resources own borrowing/finalization. No duplicated graph, reference
counter, cleanup manager or authority is allowed.

Required discriminators: an admitted v1 request retains its real file resource
and old algorithm while a new request sees v2; failed partial acquisition closes
the actual handle while healthy selection survives; stale preparation cannot
replace a newer selected intention. Add real child-process restart after a
committed target, and a deliberately stopped process after commit/before runtime
publication. Distinguish persisted target, observed active instance and closed
resource. Disable/removal then restart must not resurrect a feature. Altered
artifact bytes must be rejected before their code is invoked.

The backend may use one ordinary disposable consumer profile file with atomic
replacement. This is a configuration fixture, not the EF PostgreSQL catalog,
OCI trust path, distributed CAS or power-loss durability. Keep the persistence
code minimal and explicit. Backend artifact reuse is tested only within its
compatible contract/target. The detailed backend plan owns lifecycle sequencing.

### Browser: live logic, state retention, persistence and transfer

Use actual Chromium and Playwright with TypeScript-generated application and
plugin JavaScript. A small quote application owns its draft/input state; plugin
versions change the substantive calculation. IndexedDB is the ordinary browser
consumer's persisted profile and local artifact store, not an EF catalog.

The discriminating sequence exercises: first import/activation; changed logic
without a page reload; an already captured old call retaining its algorithm;
application-owned draft preserved; page reload restoring selected plugin;
exported exact artifact imported into a fresh isolated browser consumer;
disable/re-enable and removal followed by reload; bad digest or wrong execution
target rejected before import. Explicit target checks are not permission or
sandbox qualification. Removing executable installation does not erase the
application's user data.

A small native-JavaScript negative control may mutate an object's method while
an asynchronous operation is paused, proving that in-place mutable references
can mix old and new behavior. The positive immutable operation capture must
retain one coherent implementation. This is not a reproduction of a Lively or
Pharo defect and does not implement either VM's live-update semantics.

### Shared experiment conventions, not a public SPI

Artifacts identify exact generated JavaScript bytes with SHA-256; a manifest
records a plugin id, display version, target and consumer-specific quote ABI.
Installation, preparation, durable desired/selected state, observed activation,
disable and deletion are distinct observations. Backend and browser have
different concrete execution contracts; only compatible artifacts are shared.
No root-package code loader, universal plugin interface or catalog is built.

## Independent oracles and failure evidence

Expected calculations are fixed independently of plugin code. Resource cleanup
is checked by actual I/O, not only event labels. New process identity proves
backend restart; a fresh browser storage context proves independent transfer.
The browser's actual DOM output and preserved draft prove visible behavior.
Record source/artifact hashes, compilation and execution commands, full outputs,
screenshots, precise rejected cases and their reasons. A retained failed control
or initial harness failure stays visible with its correction; do not relabel it
as a platform defect or successful runtime test.

## Engineering and bounded cost

All handwritten JavaScript-runtime code is `.ts`, strictly checked by exact
TypeScript7.0.2; Node type stripping alone is not proof. Use repository-adopted
compiler mechanisms and native Node test APIs, not a second checker framework.
Pin and retain the disposable project's actual package/lock metadata. Never
initialize installed TypeScript5.9.3 through the unrelated Foundation general
route; report the unchanged limitation and run the unaffected Docs gate.

New production code:0. Provisional disposable fixture/integration code:
backend300–500LOC and browser250–400LOC; independent tests/harness250–450LOC;
combined800–1,350LOC, excluding generated output, dependencies and documentation.
Actual line counts replace estimates after the experiments. Planning judgments:
confidence7/10, complexity6/10, achievable reliability8/10 only for the named
bounded observations after verification. These are not production availability
or a quote for a universal runtime, migrations, isolation or distribution system.

## Review and stopping rule

Obtain a concrete independent plan critique before execution. Correct actual
ownership/oracle defects. After execution, review exact source and retained
results independently, then fix material findings and rerun only affected checks.
Research lanes add Directus/NocoBase and Lively.next/Pharo source comparisons.
Stop adding experiments when these concrete architectural uncertainties are
resolved. The root integrates a readable report and canonical vision, preserves
historical evidence, publishes one coherent research continuation and waits for
the final-head required hosted checks. Existing PR55 remains Draft.
