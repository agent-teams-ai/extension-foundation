# Browser spike implementation brief

One trusted quote feature, a real Chromium document and IndexedDB. This is an
ordinary disposable consumer, not Agent Teams production, a public SPI, a
catalog, an authorization framework or a new generic plugin manager.

## Sources and runtime

Own files only in `frontend-spike/`; dependencies and lockfile belong to root at
the parent workspace. Exact TypeScript7.0.2, Playwright1.62.1 and system Chromium
are available. Use `.ts`, strict checking with noUncheckedIndexedAccess and
exactOptionalPropertyTypes; generated browser/plugin `.js` is compiler output.
One browser tsconfig emits DOM source, a separate noEmit Node config checks
the small server/Playwright harness. Use existing native compiler/test commands.

Artifacts contain one generated self-contained ESM module, zero runtime imports,
with exact SHA-256, id `quote-pricing`, a display version, target `browser` and
consumer-specific `quote-v1` contract. Validate unknown manifest/data, digest
and target before importing a Blob of the same verified source snapshot. Load
and validate the exports before selection. Artifact identity is not execution
permission. Trusted code only; no malicious-code containment claim.

Keep application draft state and eligible built-in settings outside plugin
instances. Use one consumer-owned command queue to serialize IndexedDB profile
edits and installation/activation commands while compute calls capture a stable
binding and immutable input before any test delay. Do not create a second
lifecycle owner or reference counter for a pure calculation capability.
Do not assert ESM/Blob garbage collection or physical unload.

Suggested independent calculations for amount100 with coupon enabled:
v1: amount*0.9*1.2+5 =113; v2: (amount-min(15,amount*0.2))*1.1+2 =95.5.
An eligible built-in shipping capability adds7 (120 versus102.5). Round money
explicitly. Tests state numeric expectations independently of implementation.

## Required observed sequence

1. Install/activate v1 and compute through actual UI; capture document token.
2. Set a meaningful draft note and coupon/input state; persist them with an
   explicit completion oracle rather than an arbitrary sleep.
3. Admit and hold one v1 calculation (actual algorithm plus input/built-in
   selection captured); activate v2; new UI calculation returns v2; release
   held call and assert v1. Document token is unchanged and draft preserved.
4. Reload the page; a new document token and same persisted version/result and
   draft demonstrate restart reconstruction independently of module cache.
5. Export exact v2 artifact and import it into a fresh browser storage context;
   calculate same compatible result. This is a fresh installation of the same
   consumer, not independent implementation conformance.
6. Disable then reload: calls unavailable, installed artifact remains. Re-enable:
   result works. Remove then reload: no resurrection, draft remains; re-enable
   cannot invent a removed artifact. No deletion of application-owned data.
7. Toggle built-in shipping and observe numeric change plus reload persistence.
   Reject a command attempting to disable/delete the protected control surface.
   Built-in code remains a built-in module, not a newly minted artifact.
8. Reject a wrong-target and a tampered-digest candidate before its generated
   top-level sentinel runs. Healthy binding/profile remain intact.
9. Plain native-JS negative control: pause an operation, mutate a method used
   after its await, observe mixed revision. Positive capture must hold the whole
   self-contained calculation closure, not a function reading mutable helpers.

## Evidence

Retain exact TS sources/configs, commands, generated-artifact digest inventory,
full compiler/runtime logs and JSON numeric/lifecycle observations. Capture a
useful screenshot from the actual document after live replacement and one from
the restarted/restored state; root visually inspects them. Keep failed first
runs visible and diagnose them rather than presenting them as upstream defects.
Use readiness/events and Playwright conditions; no fixed sleeps as correctness
oracles. Bound action deadlines. Close browser/server and temporary resources.
Keep total scope near250–400 fixture LOC plus150–250 harness LOC if practical;
expand only for a real missing oracle, not a reusable framework.
