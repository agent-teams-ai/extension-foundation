# Independent plan review: persistence and product lifecycle

Date: 2026-11-18, Europe/Kiev. Reviewer: persistent_plugin_industry.
Reviewed root plan.md and backend-spike/plan.md before runtime execution.
This review does not run either fixture or approve production policy.

Inspected root plan SHA-256:
`8df80949d25564df855398b57fbaacc57808aa9ecb0778a9e04afb4786709299`.
Inspected backend plan SHA-256:
`79822b180d19d9c940728ba6e4eaa7a10205f327321b5e442bfcbcb18664aa14`.

## Verdict

The plan asks useful architectural questions at real boundaries: HTTP and native
resource lifetime, process restart, browser state and independent transfer.
Its explicit ordinary-consumer profile, single authority, native borrowing,
zero production code and open interruption policy are appropriate. Proceed with
the following narrow clarifications; none calls for a new framework.

## Material clarifications

1. **Bind the executable closure actually tested.** SHA-256 of a generated
   entry file is sufficient for a self-contained quote module, or a bundle whose
   imports are only the explicitly supplied host contract. If a candidate
   imports another mutable local file, the claimed artifact identity is wider
   than the measured input. Make the fixture self-contained or bind that small
   closure. Do not add a package resolver to this experiment.

2. **Make the commit/publication cut observable.** Parent-controlled child IPC
   must reach a definite barrier after the profile replacement completes and
   before the active binding can change. Then terminate that child and observe
   exit before starting another. Retain the pre-change HTTP oracle and the
   barrier ordering; do not infer the cut from a log label after graceful
   shutdown. If termination is abrupt, the operating system's resource cleanup
   is not evidence that native Effect finalizers ran. The startup result may
   establish the chosen committed-target recovery policy, not universal crash
   consistency, filesystem fsync durability or pre-crash activation.

3. **Do not collapse disable, uninstall and data erasure.** The root browser
   sequence already provides the right opportunity: disable → reload →
   re-enable must preserve installation; remove → reload must remove the
   installation and block accidental resurrection. Preserve an independently
   asserted user-owned draft/data sentinel through both. Backend can test the
   disable/restart half without repeating the entire browser management matrix.
   Any physical artifact deletion is distinct from code already retained in
   the module cache and resources still borrowed by an admitted operation.

4. **Cover the owner's built-in-management distinction explicitly.** At present
   it is a documented boundary, not an executable discriminator. One ordinary
   eligible built-in capability can use the existing selection owner and be
   disabled/re-enabled. An attempt to disable/remove the invariant-owning
   management/admission capability must be rejected before changing persisted
   state. This is one narrow control case, not a separate privilege manager.
   Alternatively, keep this aspect honestly unexecuted and do not imply that
   plugin CRUD alone qualified arbitrary built-in management.

## Evidence that motivated these points

- Directus ExtensionsService persists settings before asynchronous reload;
  a coalesced manager.reload call can resolve before the pending reload.
  An API acknowledgement is therefore not enough for an activation oracle.
- NocoBase retains enabled/installed/version independently and its started
  application's enable/disable path calls restart. This is precisely why the
  experiment should prove its own narrower replacement boundary.
- NocoBase frontend URL hashes use metadata, not executable content. Their
  presence is not an immutable artifact guarantee.
- Directus rich-text removal preserves stored markup and can expose unsupported
  data read-only. Removing executable functionality and deleting user content
  are independent user outcomes.

These are source/documentation observations, not defects reproduced in either
upstream product.

## Keep the experiment bounded

Existing immutable capture plus native Scope/RcMap are enough to test the
chosen single-process retention profile. No need to test arbitrary stack
migration, distributed consensus, external effect undo, hostile code, streaming
or a full UI framework in this slice. The native-JavaScript mutation control
must remain a falsifier of that plain mutable pattern, not an attributed
failure of Lively or Pharo. The plan's separation of experiment evidence from
production readiness should remain in the final report.

