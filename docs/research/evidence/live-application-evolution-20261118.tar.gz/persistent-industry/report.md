# Persistent plugin products and live application change

Observation: **2026-11-18, Europe/Kiev** (retrieval at 2026-11-17 23:24 UTC).
Research lane: Directus and NocoBase. This is a bounded implementation study for
the owner's request to change substantial application logic while the application
is running, retain and share the resulting plugins, and control built-in
functionality. It is not an executed upstream benchmark, security audit or
dependency-adoption decision.

The repository's AGENTS.md, research reference and OD-003 were read. Existing
composition, product policy, trust, canonical storage and physical custody keep
their owners. **Ordinary-update interruption remains OPEN.** An experimental
update profile is not a newly accepted default.

## Decision-oriented findings

Both products demonstrate that persistent plugin management is practical.
Their mechanisms are particularly useful for package distribution, durable
enablement, application-specific contributions and recovery. Neither studied
release supplies an undifferentiated promise of replacing arbitrary running
logic while preserving every current operation and all frontend state.

| Question | Directus 12.6.1 | NocoBase 2.2.47 |
| --- | --- | --- |
| What persists? | Extension settings in `directus_extensions`; packages in the local or configured extension storage. | Plugin records in `applicationPlugins`; third-party package files in plugin storage. |
| How is code changed? | Serialized extension-wide unregister/load in the running server, with separate frontend reload handling. | Package import/update plus application restart/reload; the started application uses its restart path for enable/disable. |
| Is management acknowledgement activation proof? | Not generally: update settings starts reload asynchronously, and a coalesced reload request can resolve immediately. | Not generally: HTTP actions normally launch CLI work asynchronously; enable/disable optionally await CLI completion. |
| How are frontend extensions selected? | App-enabled extension IDs drive a persistent reload notice; the user reloads the browser. | Enabled records supply lane-specific client URLs; production URLs use cache-busting metadata. |
| Does disable imply deleting user data? | Settings and package deletion are distinct; rich-text content can remain while its extension is absent. | Disable retains the installed flag; remove deletes plugin records and conditionally removes package files. Plugin-owned data needs its own lifecycle. |
| Does this establish our desired live guarantee? | It establishes real runtime re-registration and useful product boundaries, not healthy-old generation retention. | It establishes persistent modular product management, not arbitrary instruction-level replacement or preserved active operations. |

Rows are derived from the exact source and documentation below, not runtime
execution. The distinctions are deliberate limits of this comparison, not claims
of defects in either upstream product.

## Directus: real reload with separated persistence and browser state

### Exact source identity and distribution

Latest stable release observed: [v12.6.1][d-release], published 2026-11-04,
commit `b17d2e94ac8dd118f6c3c28b5b04337e97fdd418`.
The release's root license is **Monospace Sustainable Core License,
MSCL-1.0-GPL**, with a future GPL grant. It must not be described from an old
BSL assumption or treated as a permissive library dependency. This research
does not assess license suitability. [Pinned license][d-license].

The official publishing guide describes npm packages carrying a built
`dist`, name/version and extension-type/host metadata, discovered by Directus's
registry. This is a concrete sharing mechanism with a recognizable authored
artifact and host contract. The inspected installer downloads by registry
version ID, extracts and validates the extension manifest in a temporary
directory, optionally uploads package files to configured storage, then moves
the local package into `.registry/<versionId>`. These are concrete package
installation steps; this trace does not prove an OCI-style content-addressed
identity or an atomic transaction spanning storage, database and every process.
[Publishing guide][d-publish]; [installation manager][d-install].

### Persisted settings, runtime readiness and recovery are different facts

The extensions service stores enabled state, source, folder and bundle
membership in `directus_extensions`. Installation creates settings before
calling the installation manager. Uninstall requires a registry-owned parent
extension, removes its settings, then uninstalls package files. Settings updates
run inside a database transaction; afterward, the service starts reload and
returns without awaiting it. Bundle-child enabled state has explicit
synchronization rules. [ExtensionsService][d-service].

At startup/load, the manager rediscovers local, module and registry packages and
obtains their stored settings. The settings helper retains matching existing
settings and creates defaults for previously unknown packages. It also reconciles
added and removed entries inside bundles. Its inspected code does not establish
a durable multi-phase install journal. A crash between settings and file changes
therefore remains an appropriate qualification scenario; it is not a reproduced
data-loss incident. [Settings reconciliation][d-settings].

**Transfer inference:** use the existing consuming authority's desired-profile
record and existing artifact owner. Report durable intent, installed bytes and
observed active revision separately. The owner should define restart
reconciliation explicitly; a newly discovered directory must not silently
acquire authority merely because it contains executable code. This inference
does not change Directus's intended administrator trust model.

### Reload is serialized, but does not preserve an old generation by construction

The manager owns a queue with concurrency one. Its normal reload task unregisters
API extensions and then loads extensions. Pending reload requests are coalesced:
when a task is already queued, a further `reload()` call returns a resolved
promise. Read APIs can instead wait on `isReloading()`. The manager publishes
reload messages with an origin ID and receivers ignore their own messages.
[ExtensionManager][d-manager].

Non-sandboxed endpoint cleanup removes the scoped Express router registration;
hook cleanup removes registered listeners and stops registered schedules.
Sandboxed extension cleanup also disposes its isolate. These concrete actions
must not be promoted into a universal proof that every already-started callback,
stream or external effect has settled. The inspected reload path has no
old/new generation lease contract of that strength.

With the default permissive load policy, extension registration failures can
be logged while loading continues. `EXTENSIONS_MUST_LOAD` chooses a stricter
server-exit policy. The source-backed conclusion is a distinction between
reload completion and each capability's useful readiness, not a claim that
Directus promises an atomic successful replacement.
[Manager error handling][d-manager]; [configuration][d-config].

### A live backend update need not mutate an already-open editor

The app's extension store compares enabled browser extension IDs after refresh.
When that set changes, it posts a persistent notice whose action calls
`window.location.reload()`. This is direct source evidence for the ordinary
browser update boundary. [App store][d-app].

The current rich-text guide supplies a more specific contract: an editor builds
its schema when opened; an existing editor keeps its prior extension schema
through a server extension reload. Saving changes and reloading the browser
page applies the new extension version. A field's extension-configuration
change separately takes effect when the item is opened again. Removing an
extension leaves stored markup until a later save;
unsupported content opens read-only with explicit editing choices. The guide
also says manual loading does not enforce the declared host range. These
statements are documented contracts, not new local experiments.
[Rich-text extension guide][d-richtext].

**Transfer inference:** separate code delivery from the feature's state
transition. A browser feature may support replacing a pure computation
immediately while retaining an editor's current schema until a selected
boundary. User-visible stale/ready state is useful. Compatibility declarations
should be enforced at the boundary that claims compatibility, not inferred
from marketplace presentation.

## NocoBase: a plugin-shaped product whose live limits remain explicit

### Exact source identity and licensing qualification

Latest release observed: [v2.2.47][n-release], published 2026-11-17, commit
`03efe7e0681aca73987e19b718997e8ce4ddb364`.
Its root package labels the project Apache-2.0; the release root LICENSE.txt
incorporates Apache-2.0 with additional agreement terms, while the inspected
older server files retain AGPL/commercial headers. All three observations are
preserved in the ledger. This research does not resolve their legal effect or
certify a dependency as permissively reusable. [Root package][n-package];
[root agreement][n-license]; [server source][n-manager].

### Durable plugin records reconstruct a product, not an arbitrary live stack

The `applicationPlugins` collection stores name, package name, version,
enabled, installed, builtIn and options. The repository's `getItems()` reads
enabled records, sorts them using package dependency information, and
`init()` adds them back to the manager. Preset initialization is a distinct
path. The presence of `builtIn` metadata by itself is not evidence of
enforced removability or security guarantees.
[Collection][n-collection]; [repository][n-repository]; [manager][n-manager].

Enablement invokes plugin preparation/loading and database synchronization,
runs first-install work when needed, persists enabled/installed/version
records, invokes the enabled callback, then asks the application to reload or
restart. Disablement invokes its callbacks, persists enabled=false, and takes
the same application transition. The modern disable path leaves installed
state intact; deprecated repository helpers have different behavior and must
not be mistaken for the active manager path. Guarded preparation and install
failure paths request recovery reload/restart before propagating their error;
this is not a claim that every direct manager call has identical recovery.
[Manager][n-manager].

In the application implementation, `tryReloadOrRestart()` uses restart when
already started. That method emits beforeStop, reloads the application and
starts it again. Reload reinitializes application services and replaces the
database instance. It is an application lifecycle transition, not only a
dispatch-pointer change for one plugin. Nothing in this inspection proves
preservation of arbitrary active work. [Application][n-application].

**Transfer inference:** persistent modularity and live replacement are
orthogonal capabilities. We can preserve the useful durable plugin intent and
lifecycle ownership without inheriting the entire application's restart
boundary for every future plugin category.

### Package import, upgrade, removal and acknowledgement are explicit operations

Official CLI documentation says to import a third-party archive or npm package
into plugin storage, restart the application, then enable a new plugin or
verify an upgraded one. Import does not itself enable the package.
[Third-party installation guide][n-thirdparty].

The pinned source resolves package storage and node_modules locations with
package-name and child-path checks. Its copy helper removes the existing
package directory, moves the extracted candidate into place and creates the
storage link. Update uses this path and invokes upgrade/restart handling.
This is useful concrete evidence for staged extraction and persistent files,
but not a content-addressed immutable multi-version store or a crash-atomic
swap. Those stronger properties would require their own qualification.
[Package utilities][n-utils]; [update path][n-manager].

The manager's remove path deletes matching plugin records and removes package
directories when the application lacks the `applications` collection. The
observed manager path does not itself establish a universal domain-data purge
or full execution settlement. The plugin base class exposes lifecycle hooks,
but merely declaring a hook does not prove every delete route invokes it.
[Remove implementation][n-manager]; [plugin base][n-plugin];
[CLI route][n-command].

HTTP management actions commonly return after launching CLI work.
Enable/disable can request `awaitResponse`, which awaits the CLI promise.
This improves acknowledgement precision; it still does not by itself certify
all browser clients or every cluster node is on the same new code.
[Resource actions][n-resource].

### Frontend code delivery uses an explicit lane and cache identity

Enabled records drive separate client and client-v2 lists. The server supplies
the selected lane's entry URL and, where needed, the other lane's URL rather
than requiring the client to guess it. Development-mode ESM URLs are explicit
and separate from production file URLs. [Resource actions][n-resource].

The production URL suffix is a truncated hash of file modification time,
application key, plugin/application versions and salt. It is a cache-busting
token, not a hash of the executable closure. It should not be adopted as
our immutable artifact identity or a proof of browser/backend compatibility.

**Transfer inference:** a plugin can package backend and frontend contributions
while exposing a declared compatible pair. The existing product authority
should publish the pair's selection. A cache URL alone is insufficient to bind
a pending user action to the server revision whose behavior it expects.

## Five mechanisms worth transferring

1. **Distinct persistent and live facts.** A package can be stored, enabled in
   desired configuration, currently selected and still retained for old work.
   Keep these facts with existing owners; do not introduce a second registry
   that competes with the authoritative desired profile or artifact catalog.
2. **An authored artifact before distribution.** Agent changes become a
   reproducible package with an explicit consumer contract, compatible host
   range and required capabilities. Local live execution is one projection of
   that artifact. Sharing should not include user secrets, live handles or
   application-specific authority.
3. **Operation-specific receipts.** Coalesced/queued, persisted, activated,
   ready, detached and physically settled are different observations. A UI or
   agent may wait for the particular fact its next operation requires.
4. **Lifecycle aligned with state ownership.** Disabling or removing code is
   separate from deleting user data. Unsupported stored content may need an
   explicit read-only or migration path. Cleanup must remain owned after the
   caller stops waiting.
5. **Explicit frontend/backend coherence.** Versioned contributions and
   application-owned state enable useful live updates without claiming every
   editor or current request can migrate. Existing permissions and invariants
   still apply to agent-authored and built-in modules.

These are semantic responsibilities and qualification criteria, not five new
services, interfaces or packages. Get Modular retains graph/composition
ownership; native resources or the qualified existing kernel retain their
already supplied lifetime work.

## Proposed falsifiers that could change an architecture choice

These are proposals for the parent's bounded spikes; none was executed by this
research lane.

| Scenario | What an independently observed result should distinguish |
| --- | --- |
| Persist update intent, then stop before runtime publication | Which revision is actually recoverable and what the next startup is allowed to select. |
| Finish artifact staging, then stop before intent commit | An unselected package remains inert; filesystem discovery is not authority. |
| Candidate initialization fails after acquiring a resource | Old selection, candidate cleanup and persisted intent have independently correct outcomes under the selected experimental profile. |
| Send overlapping updates while one is queued | A coalesced acknowledgement cannot be mistaken for that candidate's readiness. |
| Browser holds old action code while backend changes | An explicitly compatible contract succeeds, or incompatibility is rejected before business effects. |
| Disable/remove a feature that has durable data | New use is blocked as declared, data policy remains explicit, and restart does not silently re-enable the feature. |
| Share a package into an ordinary second consumer | Behavior follows the package and declared contract without the source application's credentials or domain types. |
| Restart after file replacement but before metadata transition | The actual supported recovery is recorded; no false atomicity or rollback guarantee is inferred. |

A useful first implementation need not solve every row. Select rows whose result
can decide its promised profile. Do not turn this into a new universal
qualification framework.

## Evidence boundary and retained counterevidence

No source package was installed or executed, no dependencies were modified, and
no repository file was changed by this lane. Only this report and its adjacent
source ledger are produced. Exact released source, current unversioned official
docs and architectural inference remain distinguishable.

Directus's real queue, registration cleanup, sandbox disposal and browser
reload notice are positive mechanisms; their narrower guarantees are not
defects. NocoBase's persistent record reconstruction, import workflow and
restart/recovery paths likewise demonstrate useful modularity. The result
supports a more explicit portable mechanism, not a claim of superiority over
either complete product.

The inspected Directus settings test file covers registry-option forwarding
and avoiding registry queries for local extensions. Those tests were read,
not run; they do not establish the live/crash scenarios above. Search results
from unpinned repository default branches were used only for navigation and
not as released-source evidence. Failed documentation URLs were excluded from
claims.

## Primary navigation

[d-release]: https://github.com/directus/directus/releases/tag/v12.6.1
[d-manager]: https://github.com/directus/directus/blob/b17d2e94ac8dd118f6c3c28b5b04337e97fdd418/api/src/extensions/manager.ts
[d-service]: https://github.com/directus/directus/blob/b17d2e94ac8dd118f6c3c28b5b04337e97fdd418/api/src/services/extensions.ts
[d-settings]: https://github.com/directus/directus/blob/b17d2e94ac8dd118f6c3c28b5b04337e97fdd418/api/src/extensions/lib/get-extensions-settings.ts
[d-install]: https://github.com/directus/directus/blob/b17d2e94ac8dd118f6c3c28b5b04337e97fdd418/api/src/extensions/lib/installation/manager.ts
[d-app]: https://github.com/directus/directus/blob/b17d2e94ac8dd118f6c3c28b5b04337e97fdd418/app/src/stores/extensions.ts
[d-license]: https://github.com/directus/directus/blob/b17d2e94ac8dd118f6c3c28b5b04337e97fdd418/license
[d-config]: https://directus.com/docs/configuration/extensions
[d-publish]: https://directus.com/docs/guides/extensions/marketplace/publishing
[d-richtext]: https://directus.com/docs/guides/extensions/app-extensions/richtext
[n-release]: https://github.com/nocobase/nocobase/releases/tag/v2.2.47
[n-manager]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/plugin-manager/plugin-manager.ts
[n-repository]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/plugin-manager/plugin-manager-repository.ts
[n-collection]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/plugin-manager/options/collection.ts
[n-application]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/application.ts
[n-utils]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/plugin-manager/utils.ts
[n-resource]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/plugin-manager/options/resource.ts
[n-plugin]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/plugin.ts
[n-command]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/packages/core/server/src/commands/pm.ts
[n-package]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/package.json
[n-license]: https://github.com/nocobase/nocobase/blob/03efe7e0681aca73987e19b718997e8ce4ddb364/LICENSE.txt
[n-thirdparty]: https://nocode.docs.nocobase.com/nocobase-cli/plugins/third-party

