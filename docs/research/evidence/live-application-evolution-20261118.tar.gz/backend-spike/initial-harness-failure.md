# Initial backend fixture failure

The initial strict TypeScript check and generated-artifact compilation exited0.
The initial full runtime attempt exited1: all five scenarios failed before the
intended observations were established. Two single-scenario diagnostic attempts
also exited1. Their complete original outputs are retained separately.

The fixture initially used the runtime activation UUID directly as the last
segment of Get Modular's `implementationId`. Core correctly requires each
portable identity segment to start with a lowercase letter. A UUID starting
with a digit therefore produced `assembly.prepare.core-rejected` with
`identity.invalid` diagnostics before factories executed. A UUID beginning with
a letter could pass that step, which explained the differing failure locations
between attempts.

The correction uses an implementation identity derived from immutable artifact
content, `fixture/rules/h-<sha256>`, while keeping the fresh activation
incarnation in the native RcMap key. This also preserves the semantic distinction
between executable implementation identity and one acquired runtime instance.
No upstream grammar, dependency, gate or expected quote result was changed.

The diagnostics were made visible in the preparation error and activation
assertions. This was a fixture construction error, not an Effect resource-lifetime
failure, Get Modular defect or evidence against a live-update mechanism. The
initial runs are not counted as passed experiments.
