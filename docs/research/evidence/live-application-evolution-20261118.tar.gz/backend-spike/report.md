# Backend live logic, native resources and process recovery

Date: **2026-11-18, Europe/Kiev**. This is a disposable executed experiment,
not a production plugin runtime, published SPI or accepted interruption policy.

## Result

**The corrected final run passed all five cases: 5 passed, 0 failed, 0 cancelled,
0 skipped, 4,040.160334ms.** Strict TypeScript 7.0.2 checking also passed. The
original compiler/runtime commands and their exit observations are retained in
`execution-receipt.json`; `runtime-attempt3.log` is the final runtime authority.

The bounded finding is useful: a real HTTP consumer can switch substantive
calculation logic with published Get Modular native Effect composition and
Effect's own scoped keyed resource mechanism. Already admitted operations retain
their implementation and real resource while new calls use a newly prepared
generation. No second graph compiler, handwritten reference counter, resource
disposer or production Host was introduced.

The single disposable consumer still needs explicit selection/admission,
readiness, stale-intent checks and persistence semantics. Native resource
primitives do not supply those application decisions automatically.

## Tested implementation and actual boundaries

- Node **24.22.1** on Linux; compiler **TypeScript 7.0.2**; Node declarations
  **24.13.3**.
- Installed public `@get-modular/core` and `@get-modular/assembly` **0.8.0**,
  `@get-modular/effect` **0.1.1**, and **Effect 4.1.4**. The parent's disposable
  workspace owns their exact package/lock metadata and registry provenance.
- One concrete quote capability is provided by a GM module; a separate endpoint
  module consumes its declared required slot. Public GM preparation and
  `prepared.layer` build immutable native compositions.
- Native `RcMap` owns keyed resource acquisition, borrower accounting and entry
  cleanup with zero TTL. A candidate readiness hold is a native child Scope;
  the HTTP operation has its own scoped borrow. The entry's native Scope owns
  the GM Layer and real file resource.
- One consumer semaphore protects selection together with obtaining the scoped
  borrow. Candidate preparation happens outside that critical section. A
  consumer request revision rejects a preparation made stale by a newer intent.
- Every activation receives a fresh incarnation. Its executable implementation
  identity is independently derived from the immutable code digest. Reusing
  identical artifact bytes does not reuse a retired activation's resources.
- TypeScript-generated artifacts have no runtime imports. The loader hashes a
  captured byte buffer and imports that exact snapshot through a data URL;
  import never rereads the verified path. This is a deliberately small concrete
  loader for trusted self-contained fixtures, not a general dependency resolver.
- The local profile is one ordinary consumer's configuration, replaced with an
  atomic rename by its sole writer. It is not EF's PostgreSQL catalog, OCI
  admission protocol, distributed CAS or a power-loss durability implementation.

The consumer owns substantive logic selection and plugin lifetime; it does not
mutate Get Modular's composition core. The observer's handle map and close event
counts are independent test oracles, not lifecycle decisions or another owner.

## Executed observations

| Case | Independent evidence | What this establishes |
| --- | --- | --- |
| Live replacement and same-artifact reactivation | An old real HTTP calculation returned 140 while new requests returned 120 and the active binding remained v2. A low-order v2 input independently returned 32. A second admitted old call retained its file while the same v1 artifact was activated with a new incarnation. Actual reads succeeded while borrowed, then `FileHandle.stat` rejected with `EBADF`; each observed physical close occurred once. | Coherent old/new algorithm selection and native resource retention in this trusted bounded JSON request profile; fresh runtime identity is distinct from content identity. |
| Candidate fails after acquisition | The rejected module's `initialize` failed after its real file opened. That file became physically closed; the persisted desired profile remained equal to the prior selected profile; the old HTTP endpoint still returned 140. | Partial startup failure did not publish the candidate or destroy the healthy selected instance in this path. |
| Older preparation completes late | A v2 preparation paused after actual acquisition. A later request selected a new v1 incarnation and committed revision 3. The released older candidate returned `stale`, its handle closed, and active/persisted selection remained the newer one. | Publication follows the owner's current intention, not asynchronous completion order. Stale cleanup did not remove the newer binding. |
| Real restart, commit checkpoint and disabled recovery | The first process served v1; a fresh PID restored v1 with a new incarnation. IPC then paused after committing v2 while an independently read status still showed active v1. The parent observed actual SIGKILL exit; another fresh PID restored v2/120 from the committed profile. Disable persisted revision 3, and another fresh process returned 503 without deleting installed artifact bytes. | Desired persisted target, observed activation and runtime lifetime are distinct facts. Ordinary process restart preserves committed configuration; disabled state does not resurrect. |
| Altered artifact on fresh boot | The parent replaced a retained artifact path with different compiled code containing a top-level sentinel. Fresh boot reported digest mismatch, exited 1, never became ready, and produced no sentinel output. The selected profile was preserved for diagnosis. | Exact-byte validation rejected this changed local executable before evaluation in a fresh process; ESM cache reuse did not hide the change. |

The restart case's final observed PIDs were **24, 36, 48, 60**. Ready, checkpoint
and boot-error PIDs used by the oracle were checked against the parent's actual
`fork().pid`; logged stopped messages were not separately PID-checked. Actual
exit/stdio closure was awaited. The SIGKILL branch explicitly records
`effectFinalizationClaimed:false`: operating-system termination is not evidence
that Effect finalizers ran.

## Useful implications

1. **Prefer existing native resource ownership before inventing a shared kernel.**
   RcMap/Scope already provide the keyed lifetime mechanism required by this
   slice, including retirement after the final old borrower. The remaining
   coordination belongs under the consuming owner's authority.
2. **Treat artifact identity, requested revision and activation incarnation as
   separate identities.** A content digest can recur across activations, and a
   pending request can become stale while a healthy active generation remains.
3. **Persist a named fact.** The checkpoint made it observable that a target was
   committed without having become the active implementation in that process.
   Recovery rebuilt the desired target. A receipt must not collapse those phases.
4. **Captured exact executable bytes matter.** Hashing a path and independently
   importing that path would leave a verification/evaluation race. This fixture's
   self-contained byte snapshot avoids that particular race.
5. **A live endpoint can change behavior without changing all existing work.**
   One immutable operation binding supplies a practical first profile for the
   owner's vision. Other plugin categories still need their own operation,
   state, permissions and resource contracts.

These are architectural inferences from the named cases, not automatic
production acceptance. Retaining admitted calls is the experiment's chosen
profile; the owner's ordinary-update interruption question stays OPEN.

## Initial failures and independent correction

The first runtime attempt failed because the fixture placed a raw UUID in a GM
implementation identity segment. Core correctly rejected digit-starting segments
before factories. Two focused diagnostic runs identified `identity.invalid`.
The fixture now uses `fixture/rules/h-<sha256>` for implementation identity and
keeps incarnation separate. No upstream dependency, grammar, gate or expected
calculation was weakened. `initial-harness-failure.md` and original logs retain
that unsuccessful work. Those failures are not counted as platform failures or
passed resource experiments.

The next run passed five cases. Independent review then found that the first
algorithm oracle completed old v1 only after reactivating v1. That could fail to
detect a hypothetical reread of the newest algorithm. The corrected final test
uses two held calls: the first completes while v2 remains active; the second
tests same-artifact reactivation and final resource release. The application
mechanism did not change. The PID oracle was also tied to the parent fork handle.
Strict checking and the selected five-case run then passed on the final inputs.

## Exact final identities

| Input/output | SHA-256 |
| --- | --- |
| `backend.ts` | `a23e4ab861f4a80121fc018e697c93993926c0c1f4bfb90c9b82d918f7a05e2b` |
| `backend.test.ts` | `1d83a4b89323765ad5c31eb4a469b9f3e195102aa836584da07342c8dacc8700` |
| `child.ts` | `da6c61a3526a0b5b8099eb0b722732c188da27573a60cf96eeb27ebad37c7038` |
| `runtime-attempt3.log` | `5ee6299cf7de42d702327fcc40c702c041ce21bc9e306342de93fe6a0f52264f` |

The receipt binds the remaining source, configurations, generated artifacts,
actual installed primitives, commands and earlier logs. No package dependency
tree or downloaded third-party implementation needs to be copied into this
research packet.

## Limits and actual cost

This proves the listed trusted single-consumer, Linux, loopback-HTTP cases. It
does not prove hostile-plugin isolation, permission admission, production
PostgreSQL/OCI behavior, multi-writer or multi-node publication, power-loss
durability, resource finalizer failure recovery, bounded overload, arbitrary
stack continuation, state migration or undo of external effects. The fixture
uses bounded JSON responses, not a general stream/session handoff contract.

Node can keep imported ESM namespaces/code in its cache. File closure and native
RcMap entry removal are not proof of physical code unload or bounded memory under
unlimited update churn. The data-URL technique assumes self-contained generated
artifacts; a future real loader must qualify its complete dependency closure.

The loopback control routes and error diagnostics are disposable test interfaces
without authentication. They are not a deployable management API. The ordinary
configuration fixture introduces no alternate EF catalog authority. No production
source, public package, accepted ADR or interruption policy changed.

Actual new handwritten TypeScript: **767 lines**: 422 lines of consumer/child/
contracts/artifact fixtures and 345 lines of independent tests/harness. Generated
output, dependency code, configs and prose are excluded. New production code: 0.
This is measured fixture size, not a production implementation estimate.

## Primary implementation references

- [Effect 4.1.4 RcMap source](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/RcMap.ts): scoped keyed acquisition, zero-TTL removal and actual entry close. Blob `c98b0e34322e3f9147365cece2d1b90dd8786e32`.
- [Effect 4.1.4 Scope source](https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/Scope.ts): child lifetime and detachment. Blob `8ff3748f8dd9747b2ef5a277f55402f8259e5fc4`.
- [Public GM native Effect guide](https://github.com/agent-teams-ai/get-modular/blob/33c032f829028967825428bc6b049ed6db1c56b2/packages/effect/README.md): native composition and resource-owner boundary.
- [GM Effect 0.1.1 package source](https://github.com/agent-teams-ai/get-modular/blob/33c032f829028967825428bc6b049ed6db1c56b2/packages/effect/package.json): source coordinates, separately verified against the installed public package metadata and parent registry records.
