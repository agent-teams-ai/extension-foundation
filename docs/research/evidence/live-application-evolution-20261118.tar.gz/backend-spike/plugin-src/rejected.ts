import type { QuoteInput } from "../contracts.ts";

export const version = "rejected";
export function initialize(): void {
  throw new Error("candidate-initialization-failure-after-acquisition");
}
export function calculate(input: QuoteInput): number {
  return input.unitPrice * input.quantity;
}
