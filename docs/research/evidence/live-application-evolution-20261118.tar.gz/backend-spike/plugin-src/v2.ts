import type { QuoteInput } from "../contracts.ts";

export const version = "v2";
export function initialize(): void {}
export function calculate(input: QuoteInput): number {
  const subtotal = input.unitPrice * input.quantity;
  const discounted = subtotal >= 100 ? Math.floor(subtotal * 0.9) : subtotal;
  return discounted + (input.expedited ? 24 : 12);
}
