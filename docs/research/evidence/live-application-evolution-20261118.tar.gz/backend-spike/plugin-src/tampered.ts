import type { QuoteInput } from "../contracts.ts";

console.log("TAMPER_BODY_EXECUTED");
export const version = "tampered";
export function initialize(): void {}
export function calculate(input: QuoteInput): number {
  return input.unitPrice * input.quantity + 999;
}
