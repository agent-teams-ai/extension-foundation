import type { QuoteInput } from "../contracts.ts";

export const version = "v1";
export function initialize(): void {}
export function calculate(input: QuoteInput): number {
  const subtotal = input.unitPrice * input.quantity;
  return subtotal + (input.expedited ? 35 : 20);
}
