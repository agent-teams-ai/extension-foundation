export interface QuoteInput {
  readonly unitPrice: number;
  readonly quantity: number;
  readonly expedited: boolean;
}

export interface Algorithm {
  readonly version: string;
  readonly initialize: () => void;
  readonly calculate: (input: QuoteInput) => number;
}

export interface ArtifactManifest {
  readonly id: "example/quote";
  readonly version: string;
  readonly target: "node-quote/v1";
  readonly sha256: string;
}

export type DesiredProfile =
  | { readonly revision: number; readonly enabled: true; readonly sha256: string }
  | { readonly revision: number; readonly enabled: false; readonly sha256: null };

export interface Generation {
  readonly incarnation: string;
  readonly revision: number;
  readonly manifest: ArtifactManifest;
  readonly algorithm: Algorithm;
}
