import { createHash, randomUUID } from "node:crypto";
import { mkdir, open, readFile, rename, rm, writeFile, type FileHandle } from "node:fs/promises";
import { createServer, type ServerResponse } from "node:http";
import { join } from "node:path";
import { declareModule, defineContract, type CapabilitiesOf } from "@get-modular/assembly";
import { required } from "@get-modular/core";
import { effectFor, implement } from "@get-modular/effect";
import { Context, Effect, Exit, Layer, RcMap, Scope, Semaphore } from "effect";
import type { Algorithm, ArtifactManifest, DesiredProfile, Generation, QuoteInput } from "./contracts.ts";

export const sha256 = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex");
const digestPattern = /^[a-f0-9]{64}$/;
const errorOf = (error: unknown): Error => error instanceof Error ? error : new Error(String(error));
const io = <A>(operation: () => Promise<A>): Effect.Effect<A, Error> =>
  Effect.tryPromise({ try: operation, catch: errorOf });

export interface Observations {
  readonly acquired?: (generation: Generation, handle: FileHandle) => void;
  readonly closed?: (generation: Generation, handle: FileHandle) => void;
  readonly event?: (name: string, detail: unknown) => void;
  readonly afterAcquire?: (generation: Generation) => Promise<void>;
  readonly requestBarrier?: (label: string, generation: Generation) => Promise<void>;
  readonly afterCommit?: (detail: unknown) => Promise<void>;
}

function manifestOf(value: unknown, digest: string): ArtifactManifest {
  if (typeof value !== "object" || value === null || !("id" in value) || value.id !== "example/quote" ||
      !("target" in value) || value.target !== "node-quote/v1" ||
      !("version" in value) || typeof value.version !== "string" ||
      !("sha256" in value) || value.sha256 !== digest || !digestPattern.test(digest)) {
    throw new Error("invalid artifact manifest or execution target");
  }
  return { id: value.id, target: value.target, version: value.version, sha256: digest };
}

function algorithmOf(namespace: unknown, manifest: ArtifactManifest): Algorithm {
  if (typeof namespace !== "object" || namespace === null ||
      !("version" in namespace) || namespace.version !== manifest.version ||
      !("initialize" in namespace) || typeof namespace.initialize !== "function" ||
      !("calculate" in namespace) || typeof namespace.calculate !== "function") {
    throw new Error("invalid concrete quote algorithm");
  }
  const initialize = namespace.initialize;
  const calculate = namespace.calculate;
  return Object.freeze({
    version: manifest.version,
    initialize: () => { initialize(); },
    calculate: (input: QuoteInput): number => {
      const value: unknown = calculate(input);
      if (typeof value !== "number" || !Number.isFinite(value)) throw new Error("invalid quote result");
      return value;
    },
  });
}

async function readArtifact(directory: string, digest: string): Promise<{ manifest: ArtifactManifest; algorithm: Algorithm }> {
  if (!digestPattern.test(digest)) throw new Error("invalid requested digest");
  const manifestValue: unknown = JSON.parse(await readFile(join(directory, "artifacts", `${digest}.json`), "utf8"));
  const manifest = manifestOf(manifestValue, digest);
  const bytes = await readFile(join(directory, "artifacts", `${digest}.js`));
  if (sha256(bytes) !== digest) throw new Error("artifact digest mismatch before import");
  // This exact verified byte snapshot is evaluated. Import never rereads the path.
  // Generated fixture artifacts have zero runtime imports; this is no general loader.
  const namespace: unknown = await import(`data:text/javascript;base64,${bytes.toString("base64")}`);
  return { manifest, algorithm: algorithmOf(namespace, manifest) };
}

export async function installFixture(directory: string, bytes: Uint8Array, version: string): Promise<string> {
  const digest = sha256(bytes);
  await mkdir(join(directory, "artifacts"), { recursive: true });
  const manifest: ArtifactManifest = { id: "example/quote", version, target: "node-quote/v1", sha256: digest };
  await writeFile(join(directory, "artifacts", `${digest}.js`), bytes);
  await writeFile(join(directory, "artifacts", `${digest}.json`), JSON.stringify(manifest));
  return digest;
}

function profileOf(value: unknown): DesiredProfile {
  if (typeof value !== "object" || value === null ||
      !("revision" in value) || typeof value.revision !== "number" || !Number.isSafeInteger(value.revision) || value.revision < 0 ||
      !("enabled" in value) || !("sha256" in value)) throw new Error("invalid desired profile");
  if (value.enabled === false && value.sha256 === null) return { revision: value.revision, enabled: false, sha256: null };
  if (value.enabled === true && typeof value.sha256 === "string" && digestPattern.test(value.sha256)) {
    return { revision: value.revision, enabled: true, sha256: value.sha256 };
  }
  throw new Error("invalid desired selection");
}

export async function readProfile(directory: string): Promise<DesiredProfile> {
  try {
    const value: unknown = JSON.parse(await readFile(join(directory, "profile.json"), "utf8"));
    return profileOf(value);
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      return { revision: 0, enabled: false, sha256: null };
    }
    throw error;
  }
}

async function persist(directory: string, profile: DesiredProfile): Promise<void> {
  const temporary = join(directory, `profile-${randomUUID()}.tmp`);
  try {
    await writeFile(temporary, JSON.stringify(profile), { flag: "wx" });
    await rename(temporary, join(directory, "profile.json"));
  } finally { await rm(temporary, { force: true }); }
}

interface QuoteCapability { readonly evaluate: (input: QuoteInput) => Effect.Effect<number, Error> }
const QuotePort = defineContract<QuoteCapability>()({ id: "fixture/quote", revision: 1 });
interface Ports extends CapabilitiesOf<typeof QuotePort> {}
class Roots extends Context.Service<Roots, { readonly endpoint: QuoteCapability }>()("fixture/QuoteRoots") {}
const owner = { authority: "fixture", path: ["backend"] };

function composition(directory: string, generation: Generation, observations: Observations) {
  const provider = implement<Ports>()(declareModule({
    moduleId: "fixture/rules", implementationId: `fixture/rules/h-${generation.manifest.sha256}`, owner,
    provides: [QuotePort.provide()], slots: [],
  }), () => Effect.gen(function* () {
    const filename = join(directory, "resources", `${generation.incarnation}.txt`);
    yield* io(() => writeFile(filename, "alive"));
    const file = yield* Effect.acquireRelease(io(() => open(filename, "r")), handle => Effect.promise(async () => {
      await handle.close();
      observations.closed?.(generation, handle);
      observations.event?.("resource-closed", { incarnation: generation.incarnation });
    }));
    observations.acquired?.(generation, file);
    observations.event?.("resource-acquired", { incarnation: generation.incarnation, version: generation.manifest.version });
    const afterAcquire = observations.afterAcquire;
    if (afterAcquire) yield* io(() => afterAcquire(generation));
    yield* Effect.try({ try: generation.algorithm.initialize, catch: errorOf });
    const capability: QuoteCapability = {
      evaluate: input => Effect.gen(function* () {
        yield* io(async () => {
          const bytes = Buffer.alloc(5);
          const { bytesRead } = await file.read(bytes, 0, bytes.length, 0);
          if (bytesRead !== 5 || bytes.toString() !== "alive") throw new Error("resource observation failed");
        });
        return yield* Effect.try({ try: () => generation.algorithm.calculate(input), catch: errorOf });
      }),
    };
    return { instance: capability, capabilities: { [QuotePort.id]: capability } };
  }));
  const endpoint = implement<Ports>()(declareModule({
    moduleId: "fixture/endpoint", implementationId: "fixture/endpoint/default", owner,
    provides: [], slots: [QuotePort.slot("quote", required())],
  }), ({ quote }) => Effect.succeed({ instance: quote, capabilities: {} }));
  return Effect.gen(function* () {
    const result = yield* io(() => effectFor<Ports>().prepare({
      profileId: "fixture/live-quote", modules: [provider, endpoint], roots: { endpoint },
    }));
    if (result.status !== "prepared") return yield* Effect.fail(new Error(`native composition rejected: ${JSON.stringify(result)}`));
    const context = yield* Layer.build(result.prepared.layer(Roots));
    return Context.get(context, Roots).endpoint;
  });
}

function sendJson(response: ServerResponse, status: number, body: unknown): Promise<void> {
  return new Promise((resolve, reject) => {
    const done = (error?: Error) => {
      response.off("error", failed);
      response.off("close", closed);
      error ? reject(error) : resolve();
    };
    const failed = (error: Error) => done(error);
    const closed = () => done(response.writableFinished ? undefined : new Error("response disconnected"));
    response.once("error", failed);
    response.once("close", closed);
    response.writeHead(status, { "content-type": "application/json", "cache-control": "no-store" });
    response.end(JSON.stringify(body), () => done());
  });
}

function inputOf(url: URL): QuoteInput {
  const unitPrice = Number(url.searchParams.get("unit") ?? "40");
  const quantity = Number(url.searchParams.get("quantity") ?? "3");
  if (!Number.isSafeInteger(unitPrice) || !Number.isSafeInteger(quantity) || unitPrice < 0 || quantity < 1) {
    throw new Error("invalid fixture quote input");
  }
  return { unitPrice, quantity, expedited: url.searchParams.get("expedited") === "1" };
}

export async function createBackend(directory: string, observations: Observations = {}) {
  await mkdir(join(directory, "resources"), { recursive: true });
  let desired = await readProfile(directory);
  const ownerScope = await Effect.runPromise(Scope.make());
  const gate = await Effect.runPromise(Semaphore.make(1));
  const resources = await Effect.runPromise(RcMap.make({
    lookup: (generation: Generation) => composition(directory, generation, observations), idleTimeToLive: 0,
  }).pipe(Scope.provide(ownerScope)));
  let requestedRevision = desired.revision;
  let active: { readonly generation: Generation; readonly hold: Scope.Closeable } | undefined;
  let closed = false;
  const locked = <A>(operation: () => Promise<A>): Promise<A> =>
    Effect.runPromise(Semaphore.withPermits(gate, 1)(io(operation)));
  const closeScope = (scope: Scope.Closeable) => Effect.runPromise(Scope.close(scope, Exit.void));
  const generationFor = async (digest: string, revision: number): Promise<Generation> => {
    const artifact = await readArtifact(directory, digest);
    return Object.freeze({ incarnation: randomUUID(), revision, ...artifact });
  };
  const prepare = async (generation: Generation): Promise<Scope.Closeable> => {
    const hold = await Effect.runPromise(Scope.fork(ownerScope));
    try {
      await Effect.runPromise(RcMap.get(resources, generation).pipe(Scope.provide(hold)));
      return hold;
    } catch (error) {
      try { await closeScope(hold); } catch (cleanup) { throw new AggregateError([error, cleanup], "candidate and cleanup failed"); }
      throw error;
    }
  };
  const releaseReadiness = async (scope: Scope.Closeable | undefined): Promise<"released" | "failed" | "absent"> => {
    if (!scope) return "absent";
    try { await closeScope(scope); return "released"; }
    catch (error) { observations.event?.("readiness-release-failed", String(error)); return "failed"; }
  };
  const activate = async (digest: string, pauseAfterCommit = false) => {
    const checkpoint = observations.afterCommit;
    if (pauseAfterCommit && !checkpoint) throw new Error("checkpoint observer unavailable");
    const revision = await locked(async () => {
      if (closed) throw new Error("consumer closed");
      return ++requestedRevision;
    });
    const generation = await generationFor(digest, revision);
    const hold = await prepare(generation);
    let published = false;
    try {
      const commit = await locked(async () => {
        if (closed || revision !== requestedRevision) return { status: "stale" } as const;
        const profile: DesiredProfile = { revision, enabled: true, sha256: digest };
        await persist(directory, profile);
        desired = profile;
        if (pauseAfterCommit && checkpoint) {
          await checkpoint({ desired, activeDigest: active?.generation.manifest.sha256 ?? null, pid: process.pid });
        }
        const previous = active;
        active = { generation, hold };
        published = true;
        observations.event?.("published", { revision, incarnation: generation.incarnation, digest });
        return { status: "published", previous } as const;
      });
      if (commit.status === "stale") {
        await closeScope(hold);
        return { status: "stale", revision, incarnation: generation.incarnation } as const;
      }
      const readiness = await releaseReadiness(commit.previous?.hold);
      return { status: "activated", revision, incarnation: generation.incarnation, readiness } as const;
    } catch (error) {
      if (!published) await closeScope(hold);
      throw error;
    }
  };
  const disable = async () => {
    const previous = await locked(async () => {
      if (closed) throw new Error("consumer closed");
      const profile: DesiredProfile = { revision: ++requestedRevision, enabled: false, sha256: null };
      await persist(directory, profile);
      desired = profile;
      const old = active;
      active = undefined;
      return old;
    });
    return { status: "disabled", readiness: await releaseReadiness(previous?.hold) } as const;
  };
  const snapshot = async () => ({
    desired, requestedRevision, pid: process.pid,
    active: active ? { incarnation: active.generation.incarnation, digest: active.generation.manifest.sha256, revision: active.generation.revision } : null,
    resources: Array.from(await Effect.runPromise(RcMap.keys(resources)), generation => ({
      incarnation: generation.incarnation, digest: generation.manifest.sha256, revision: generation.revision,
    })),
  });
  try {
    if (desired.enabled) {
      const generation = await generationFor(desired.sha256, desired.revision);
      active = { generation, hold: await prepare(generation) };
      observations.event?.("restored", { digest: desired.sha256, incarnation: generation.incarnation, pid: process.pid });
    }
  } catch (error) { await closeScope(ownerScope); throw error; }

  const server = createServer((request, response) => {
    const run = async () => {
      const url = new URL(request.url ?? "/", "http://127.0.0.1");
      if (url.pathname === "/quote") {
        const input = inputOf(url);
        await Effect.runPromise(Effect.scoped(Effect.gen(function* () {
          const binding = yield* Semaphore.withPermits(gate, 1)(Effect.gen(function* () {
            const selected = active;
            if (!selected || closed) return yield* Effect.fail(new Error("feature disabled"));
            const capability = yield* RcMap.get(resources, selected.generation);
            return { generation: selected.generation, capability };
          }));
          const before = yield* binding.capability.evaluate(input);
          const barrier = observations.requestBarrier;
          const label = url.searchParams.get("hold");
          if (barrier && label) yield* io(() => barrier(label, binding.generation));
          const total = yield* binding.capability.evaluate(input);
          yield* io(() => sendJson(response, 200, {
            version: binding.generation.manifest.version, digest: binding.generation.manifest.sha256,
            incarnation: binding.generation.incarnation, revision: binding.generation.revision,
            before, total, pid: process.pid,
          }));
        })));
      } else if (url.pathname === "/_fixture/activate" && request.method === "POST") {
        await sendJson(response, 200, await activate(url.searchParams.get("digest") ?? "", url.searchParams.get("pause") === "1"));
      } else if (url.pathname === "/_fixture/disable" && request.method === "POST") {
        await sendJson(response, 200, await disable());
      } else if (url.pathname === "/_fixture/status") {
        await sendJson(response, 200, await snapshot());
      } else { await sendJson(response, 404, { error: "fixture route absent" }); }
    };
    void run().catch(async error => {
      observations.event?.("request-error", String(error));
      if (!response.headersSent) await sendJson(response, 503, { error: String(error) });
    }).catch(error => observations.event?.("response-write-failed", String(error)));
  });
  try {
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", () => { server.off("error", reject); resolve(); });
    });
  } catch (error) { await closeScope(ownerScope); throw error; }
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("expected loopback TCP address");
  return {
    url: `http://127.0.0.1:${address.port}`, activate, disable, snapshot,
    close: async () => {
      await locked(async () => { closed = true; });
      await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
      await closeScope(ownerScope);
    },
  };
}
