# Backend live replacement spike plan

Date: 2026-11-18, Europe/Kiev. Status: reviewed disposable experiment plan;
root authorized the selected scenarios after independent plan criticism.
No executed result is claimed by this plan.

## Reviewed corrections and selected scope

- Execute all three lifecycle discriminators plus normal subprocess restart,
  interruption after committed intent/before in-memory publication, disable then
  restart, and altered-artifact rejection before code evaluation. Browser work
  separately owns artifact transfer, re-enable/remove and draft retention.
- Generated executable artifacts are self-contained modules with zero runtime
  imports. Hash exact bytes, then import that same captured byte snapshot through
  a data URL. Do not verify a path and then let import reread potentially changed
  bytes from that path.
- Every activation has a fresh incarnation in addition to the content digest.
  Retaining an old call and selecting the same artifact again must not silently
  reuse the retired activation's resources.
- A parent-controlled IPC checkpoint observes committed intent while in-memory
  publication is paused. The parent stops the child, observes its actual exit,
  and verifies a distinct new PID on restart. SIGKILL/OS file closure does not
  count as an Effect finalizer observation.
- A tampered artifact has an observable top-level sentinel; rejecting the
  altered bytes must happen before that sentinel can execute.
- One ordinary local profile, one writer, no database/catalog or power-loss
  claim. The specified profile retains admitted calls; production policy stays
  OPEN. No stream or mutable-state migration guarantee is inferred.

## Decision the experiment can change

Can a native Effect application reuse existing keyed scoped resources to replace
substantive request logic while retaining already admitted work, without another
reference counter, graph compiler, resource owner or production plugin Host?
Can a small consumer retain its selected immutable artifact across a real process
restart, while preserving the distinction between durable intent and observed
runtime activation?

The retained November14 four-case experiment already establishes specific
ScopedRef/RcRef behavior. Repeating those four cases adds little information.
This proposal crosses the real HTTP, selected-implementation and process-restart
boundaries. It is one explicitly named experimental retention profile, not the
owner's unresolved ordinary-update interruption policy.

## Existing ownership and primitives

- The concrete consuming application's single owner selects the active revision,
  admits requests and persists its desired selection. It is not a new library
  authority or production Host.
- Effect 4.1.4 `RcMap` owns keyed acquisition, borrower accounting and cleanup.
  Native child `Scope`s own candidate readiness holds and request leases.
  No handwritten borrower count or resource-disposal registry is added.
- Preparation runs outside the existing owner's admission semaphore. Selection
  and acquisition of a native borrowing scope occur under that same semaphore;
  the substantive request runs after releasing it.
- If the matched public Get Modular packages are available, immutable native
  composition supplies the selected concrete capability through its public
  entrypoints. Otherwise a previously admitted factory suffices for this
  bounded experiment; no duplicate graph implementation is justified.
- A native `Layer.build` under the RcMap entry's actual Scope can preserve
  resource lifetime. Returning a capability from a completed `Effect.provide`
  scope would be an invalid experiment and is explicitly rejected.

Inspected retained Effect 4.1.4 source: `RcMap.get` registers a scoped release;
`release` with zero TTL removes the current entry and returns `closeEntry`;
`Scope.fork` creates a child which detaches on its own close. This supports a
testable candidate, not a blanket cleanup guarantee. The prior RcRef finite-TTL
qualification must not be generalized to a different primitive.

## Concrete operation and independent observations

Use a disposable HTTP order-quote endpoint. Two separately compiled immutable
plugin modules implement different calculation algorithms, such as a fixed fee
versus a threshold discount plus a changed fee. The expected totals are written
independently in tests. This is substantive logic, not an injected version label
or stylesheet change.

Each prepared generation owns a real `FileHandle` for its declared fixture
resource. A held HTTP request reads the handle before and after replacement.
The oracle independently checks readability before release and `EBADF` after
physical close. Observed close events supplement actual I/O checks; an event
named closed alone is insufficient evidence.

Candidate readiness holds and call scopes are separate native borrows. Releasing
the old readiness hold after publication must not end an admitted old call.
Native keyed membership can be inspected after final borrower release to detect
retired-entry retention without implementing a second reference counter.

## Proposed scenarios

| Scenario | Independent observation | Architectural consequence |
| --- | --- | --- |
| Hold a v1 HTTP call, activate ready v2, issue another call | New call returns v2 calculation; held call completes v1 calculation using its still-open handle; old handle closes after that call | Tests selected-generation and resource lifetime at the actual request boundary |
| Candidate acquires a real file and then fails | Partial handle is physically closed; old endpoint and persisted selection remain usable | Tests failure before publication without destroying healthy service |
| An older preparation is deliberately held while a newer requested revision wins | Late candidate receives a stale result, never overwrites the newer selection, and releases only its resources | Tests owner revision fencing rather than relying on preparation completion order |
| Persist successful target, stop backend, launch a fresh Node process | New process serves the same immutable algorithm and revision | Tests persisted user selection independently from one process's ESM cache |
| Stop after desired-state commit but before runtime publication | Recovery reconstructs the committed desired target and does not claim the pre-crash runtime had activated it | Distinguishes durable intent from activation evidence |
| Disable/remove selected contribution, then restart | New calls are unavailable under the declared fixture policy and restart does not resurrect it | Separates stored installation, desired activation and live selection |
| Alter or remove retained artifact bytes before a fresh restart | Validation rejects the desired target before invoking its code | Tests fail-closed recovery for this fixture, not artifact trust admission |

The first three scenarios are the minimum high-information lifecycle slice.
Persistence scenarios should share root's chosen portable artifact/profile
fixture when one exists, rather than creating a second incompatible store.
The parent may select a smaller non-duplicated subset across its backend and
frontend experiments.

## Persistence and artifact boundary

A filesystem profile is acceptable only as an explicitly ordinary disposable
consumer's configuration fixture. It is not the EF canonical PostgreSQL catalog,
OCI admission protocol or a substitute authority. Artifact content hashes in
this experiment identify exact local bytes; they do not confer execution
permission, supply-chain trust or hostile-code isolation.

Persisted selected intent and in-memory active binding have one owner and
distinct observations. Atomic file replacement can test process-restart
semantics; it does not prove distributed CAS, concurrent writers, power-loss
durability or database migration. No product data is deleted by plugin removal.
Physical artifact deletion must not be asserted while admitted work still owns
resources derived from that artifact.

The existing OD-003 constraint remains: a built-in module is not a plugin
artifact. Activation control for built-in capabilities can use the same owner
without silently converting trusted invariants into removable third-party code.

## Scope limits

- One trusted consumer process, loopback HTTP and disposable files.
- No production source, new public SPI, release, feature adoption or merge.
- No arbitrary stack migration, user database migration, external effect undo,
  multi-process routing, untrusted-code sandbox or global atomic switch.
- Node may retain imported ESM code. Closing its resources is not a claim that
  module code or escaped closures were physically unloaded.
- No long-lived stream guarantee unless the fixture holds the native borrow
  until response consumption/finalization, not merely until a function returns.
- Normal update interruption remains OPEN. This named retention experiment
  does not select cancellation, indefinite waiting or a timeout policy.

## Dependencies and qualification

Root supplies a disposable dependency workspace. Requested exact versions:
Effect 4.1.4; TypeScript at least7.0.2, pinned to the approved actual compiler;
matching Node ambient types. If root chooses the GM integration, use the matched
published Core/Assembly/Effect package versions verified from their actual
metadata, not private lifecycle deep imports.

New source and tests use `.ts` with effective strict checking, unchecked indexed
access and exact optional property checks. Preserve the package/lock identity,
compiler resolution, raw typecheck output, runtime TAP, source hashes and concrete
event/I/O outcomes. No TypeScript5.9 implementation is initialized.

Provisional incremental effort, excluding reused native/GM code and dependency
installation: minimum lifecycle fixture150–250 implementation LOC plus200–300
test/HTTP-fixture LOC; adding non-duplicated process-restart/profile scenarios
adds150–250 fixture LOC. This is disposable evidence, not a production estimate.
Confidence7/10; complexity5/10; achievable reliability for the stated single-process
resource invariant8/10 after decisive checks. These are planning judgments,
not measured production availability or a public compatibility commitment.

## Review and stop conditions

Obtain a bounded independent plan review before execution. Address concrete
ownership, lifecycle or oracle issues; do not grow a framework to satisfy a
synthetic fixture. After execution, review code and results against exact source
hashes and retain failed runs when they change the conclusion. Stop expanding
tests when the selected architectural uncertainty is resolved.
