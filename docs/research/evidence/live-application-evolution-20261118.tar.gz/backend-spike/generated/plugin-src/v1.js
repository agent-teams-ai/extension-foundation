export const version = "v1";
export function initialize() { }
export function calculate(input) {
    const subtotal = input.unitPrice * input.quantity;
    return subtotal + (input.expedited ? 35 : 20);
}
