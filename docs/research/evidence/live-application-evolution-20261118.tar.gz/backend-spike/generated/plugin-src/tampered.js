console.log("TAMPER_BODY_EXECUTED");
export const version = "tampered";
export function initialize() { }
export function calculate(input) {
    return input.unitPrice * input.quantity + 999;
}
