export const version = "rejected";
export function initialize() {
    throw new Error("candidate-initialization-failure-after-acquisition");
}
export function calculate(input) {
    return input.unitPrice * input.quantity;
}
