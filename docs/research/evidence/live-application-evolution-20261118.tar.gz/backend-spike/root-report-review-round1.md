# Independent root report review: backend evidence and ownership

Date: 2026-11-18, Europe/Kiev. Reviewer: `backend_live_spike`.
Review type: read-only source/evidence comparison; no tests, package installs,
repository mutations or runtime evidence edits.

## Exact input

Root report:
`docs/research/live-application-evolution-vision-and-executed-spikes-2026-11-18.md`

SHA-256:
`1fecbbe777b09ff546af4c721daf6c8327a0e3876c68c1585d7d1f269b6d89b0`

Compared with the final backend source and retained run:

- `backend.ts`: `a23e4ab861f4a80121fc018e697c93993926c0c1f4bfb90c9b82d918f7a05e2b`.
- `backend.test.ts`: `1d83a4b89323765ad5c31eb4a469b9f3e195102aa836584da07342c8dacc8700`.
- `runtime-attempt3.log`: `5ee6299cf7de42d702327fcc40c702c041ce21bc9e306342de93fe6a0f52264f`.
- Backend report: `f94a77435b1df58b9b578d999014472f210dc628e6dc31aa6e1082eff59ea6bd`.

## Verdict

The root report accurately preserves the measured backend outcome, its limited
scope, existing ownership and the open policy decisions. **Two narrow evidence
wording corrections are required before treating this text as final.** Neither
requires changing source or repeating a test. No broader architecture objection
or additional experiment is justified by this review.

## R-B1: distinguish readiness child scopes from operation scopes

Current sentence in the executed-backend description:

> child Scopes own readiness holds and per-operation borrows.

The readiness hold uses `Scope.fork(ownerScope)`. Each HTTP operation instead
uses `Effect.scoped`; its scoped borrowing is not constructed by that same
`Scope.fork(ownerScope)` call. The distinction matters because it would be wrong
to infer that closing a parent scope automatically drains all admitted operations
while preserving their resource use. The fixture explicitly stops serving and
waits for server closure before closing the resource owner.

Suggested bounded replacement:

> Native child Scopes own candidate readiness holds; each HTTP operation uses
> `Effect.scoped` for its borrow. The RcMap entry Scope owns the actual resource.

This states the observed mechanism without changing the proposed architecture.

## R-B2: name the actual post-close I/O oracle

The same-artifact row currently says:

> Final reads failed with `EBADF`.

The fixture performs actual reads while the handle must remain alive, then
checks physical closure through `FileHandle.stat()` rejecting with `EBADF`.
It does not issue a post-close `read()` in that assertion.

Suggested replacement:

> After final release, `FileHandle.stat()` rejected with `EBADF`; each observed
> physical close occurred once.

The existing evidence is strong enough. Narrow the wording to that evidence;
do not add a redundant test just to preserve the previous phrase.

## Confirmed strengths and bounds

- The five-case count is correct despite the table's presentation: live
  replacement plus same-artifact incarnation share one test; the last row
  combines recovery and altered-artifact tests; the total remains five.
- Old total140 is now observed while v2 remains active and an independent new
  call returns120. The separate second retained old call supports the
  same-artifact incarnation and physical file-lifetime assertion. The weak
  intermediate oracle is not promoted to final evidence.
- Typed code size arithmetic is correct: backend767 plus browser524 equals1291.
  The backend's measured767 includes422 fixture/integration and345 tests/harness.
  This is explicitly research size, with production code0. Browser524 is accepted
  as the parent-provided inventory for this bounded review, not independently
  recounted here.
- Published GM0.8.0/native adapter0.1.1 and Effect4.1.4 match the executed
  backend; TypeScript7.0.2 and Node24.22.1 are correctly stated. Runtime4.040s is
  explicitly not presented as a performance benchmark.
- Desired target, observed activation and cleanup are not collapsed. The parent
  IPC checkpoint, actual SIGKILL and fresh process recovery are accurately
  described; no Effect-finalizer result is inferred from OS process termination.
- The artifact loader evaluates its captured verified bytes; the report limits
  this to self-contained modules and does not claim ESM code unload, hostile
  isolation or complete dependency-closure qualification.
- One consumer owns selection, requested revision and persisted configuration;
  native mechanisms own keyed resource accounting and cleanup. No second graph,
  public SPI, private-kernel deep import, catalog or generalized runtime is
  introduced by the recommendation.
- External consumers are not required to adopt Effect. The native path is
  explicitly appropriate for the accepted new application; optional library
  work can still result in a recipe with no new residual mechanism.
- Built-in contribution management does not turn protected invariants into
  removable external artifacts. User data remains a distinct responsibility.
- Ordinary-update interruption stays OPEN. Experimental retention is not
  declared an accepted default, and the proposed architecture remains a
  recommendation rather than an adopted production runtime.
- Browser runtime is repeatedly marked pending. The enumerated browser
  assertions are targets, and neither typecheck, review nor an input archive is
  described as successful browser execution. The final delivery must replace
  that checkpoint only with the actual observed hosted result.

## Review boundary

This review checks backend measurements/oracles, authority, portability and
the report's claim boundaries. It does not re-audit all four upstream research
implementations, browser source behavior, workflow security or the future final
archive. Those remain with their independent source and execution reviews.

## Correction disposition

Reviewed the corrected root report at SHA-256
`0cce4db7b13633ab907164278a6605a659c88f9e2a97de20ddf19e753efa2671`.

- **R-B1 resolved:** the text now distinguishes native child Scopes for candidate
  readiness holds from each operation's `Effect.scoped` borrow, and states that
  the entry Scope owns its resource. This matches the source mechanism.
- **R-B2 resolved:** the same-artifact row now names the observed
  `FileHandle.stat()` rejection with `EBADF` and once-only physical close.

Both corrections are wording-only and require no runtime rerun. No material
issue remains within this review's backend/reuse/authority scope. This is a
bounded PASS for the input-publication checkpoint; the browser hosted result
remains pending and is not promoted by this disposition.

Parent reported first input-publication tree
`d099f363434add2b705f1d1047ed0109c5eb9c08`; this reviewer independently verified
the report content hash above, not the entire tree or its CI outcome.
