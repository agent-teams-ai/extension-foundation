import { createBackend } from "./backend.ts";

const directory = process.argv[2];
if (!directory) throw new Error("fixture directory required");

try {
  const backend = await createBackend(directory, {
    event: (name, detail) => console.log(JSON.stringify({ name, detail })),
    afterCommit: async detail => {
      await new Promise<void>((resolve, reject) => {
        if (!process.send) return reject(new Error("parent IPC required for crash checkpoint"));
        process.send({ event: "commit-before-publication", detail }, error => error ? reject(error) : resolve());
      });
      await new Promise<void>(() => {});
    },
  });
  process.on("message", (message: unknown) => {
    if (message !== "stop") return;
    void backend.close().then(() => {
      if (process.send) process.send({ event: "stopped", pid: process.pid }, () => process.disconnect());
    }).catch(error => { console.error(error); process.exitCode = 1; process.disconnect(); });
  });
  if (!process.send) throw new Error("parent IPC required");
  process.send({ event: "ready", url: backend.url, pid: process.pid });
} catch (error) {
  console.error(String(error));
  if (process.send) process.send({ event: "boot-error", message: String(error), pid: process.pid }, () => process.disconnect());
  process.exitCode = 1;
}
