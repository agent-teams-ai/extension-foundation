import assert from "node:assert/strict";
import { fork } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile, type FileHandle } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { createBackend, installFixture, readProfile, type Observations } from "./backend.ts";
import type { Generation } from "./contracts.ts";

const record = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);
function object(value: unknown): Record<string, unknown> {
  if (!record(value)) throw new Error("expected JSON object");
  return value;
}
function string(value: unknown): string {
  if (typeof value !== "string") throw new Error("expected string");
  return value;
}
async function within<T>(promise: Promise<T>, label: string, milliseconds = 10000): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([promise, new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`timeout: ${label}`)), milliseconds);
    })]);
  } finally { if (timer) clearTimeout(timer); }
}
async function request(url: string, post = false) {
  const response = await fetch(url, { method: post ? "POST" : "GET", signal: AbortSignal.timeout(15000) });
  const value: unknown = await response.json();
  return { status: response.status, body: object(value) };
}
const settled = <A>(promise: Promise<A>) => promise.then(
  value => ({ ok: true, value }) as const,
  error => ({ ok: false, error: error instanceof Error ? error.message : String(error) }) as const,
);
async function fixture() {
  const directory = await mkdtemp(join(tmpdir(), "backend-live-evolution-"));
  const fixtures = new Map<string, string>();
  for (const version of ["v1", "v2", "rejected"]) {
    const bytes = await readFile(new URL(`./generated/plugin-src/${version}.js`, import.meta.url));
    assert.doesNotMatch(bytes.toString(), /\bimport\s*(?:\(|[\s{*])/u, "generated fixture has zero runtime imports");
    fixtures.set(version, await installFixture(directory, bytes, version));
  }
  const digest = (version: string) => {
    const found = fixtures.get(version);
    assert.ok(found);
    return found;
  };
  return { directory, digest, cleanup: () => rm(directory, { recursive: true, force: true }) };
}
async function alive(file: FileHandle) {
  const bytes = Buffer.alloc(5);
  assert.equal((await file.read(bytes, 0, bytes.length, 0)).bytesRead, 5);
  assert.equal(bytes.toString(), "alive");
}
async function physicallyClosed(file: FileHandle) {
  await assert.rejects(file.stat(), { code: "EBADF" });
}
function observer() {
  const handles = new Map<string, { generation: Generation; file: FileHandle }>();
  const closures = new Map<string, number>();
  const waiting = new Map<string, () => void>();
  const events: Array<{ name: string; detail: unknown }> = [];
  const observations: Observations = {
    acquired: (generation, file) => handles.set(generation.incarnation, { generation, file }),
    closed: generation => {
      closures.set(generation.incarnation, (closures.get(generation.incarnation) ?? 0) + 1);
      waiting.get(generation.incarnation)?.();
    },
    event: (name, detail) => events.push({ name, detail }),
  };
  const handle = (incarnation: string) => {
    const found = handles.get(incarnation);
    assert.ok(found);
    return found.file;
  };
  const waitClosed = async (incarnation: string) => {
    if (!closures.has(incarnation)) {
      await within(new Promise<void>(resolve => waiting.set(incarnation, resolve)), `physical close ${incarnation}`);
    }
    assert.equal(closures.get(incarnation), 1);
    await physicallyClosed(handle(incarnation));
  };
  return { handles, closures, events, observations, handle, waitClosed };
}

test("real HTTP old call stays coherent while new code and fresh same-artifact incarnations activate", { timeout: 20000 }, async () => {
  const f = await fixture();
  const seen = observer();
  const outcomes: unknown[] = [];
  const admitted = Promise.withResolvers<Generation>();
  const resume = Promise.withResolvers<void>();
  const retainedAdmitted = Promise.withResolvers<Generation>();
  const retainedResume = Promise.withResolvers<void>();
  const backend = await createBackend(f.directory, {
    ...seen.observations,
    requestBarrier: async (label, generation) => {
      if (label === "old") { admitted.resolve(generation); await resume.promise; }
      if (label === "retained") { retainedAdmitted.resolve(generation); await retainedResume.promise; }
    },
  });
  try {
    const firstActivation = await request(`${backend.url}/_fixture/activate?digest=${f.digest("v1")}`, true);
    assert.equal(firstActivation.body.status, "activated", JSON.stringify(firstActivation.body));
    const oldCall = settled(request(`${backend.url}/quote?hold=old`));
    const old = await within(admitted.promise, "old HTTP call admitted");
    const retainedCall = settled(request(`${backend.url}/quote?hold=retained`));
    const retained = await within(retainedAdmitted.promise, "second old HTTP call admitted");
    assert.equal(retained.incarnation, old.incarnation);
    await alive(seen.handle(old.incarnation));
    const secondActivation = await request(`${backend.url}/_fixture/activate?digest=${f.digest("v2")}`, true);
    assert.equal(secondActivation.body.status, "activated", JSON.stringify(secondActivation.body));
    const fresh = await request(`${backend.url}/quote`);
    assert.equal(fresh.status, 200);
    assert.equal(fresh.body.before, 120);
    assert.equal(fresh.body.total, 120);
    assert.equal(fresh.body.version, "v2");
    const v2 = string(fresh.body.incarnation);
    assert.equal((await request(`${backend.url}/quote?unit=20&quantity=1`)).body.total, 32);
    assert.equal((await backend.snapshot()).resources.length, 2);
    await alive(seen.handle(old.incarnation));
    assert.equal(seen.closures.has(old.incarnation), false);

    // Complete this old call while the different v2 algorithm remains active.
    resume.resolve();
    const completedUnderV2 = await within(oldCall, "old response while v2 active");
    assert.ok(completedUnderV2.ok);
    assert.equal(completedUnderV2.value.body.before, 140);
    assert.equal(completedUnderV2.value.body.total, 140);
    assert.equal(completedUnderV2.value.body.incarnation, old.incarnation);
    assert.equal((await request(`${backend.url}/quote`)).body.total, 120);
    assert.equal((await backend.snapshot()).active?.digest, f.digest("v2"));
    await alive(seen.handle(old.incarnation));
    outcomes.push({ currentV2: fresh.body, oldCompletedWhileV2: completedUnderV2.value.body });

    // A different retained call proves fresh activation of the same artifact.
    await request(`${backend.url}/_fixture/activate?digest=${f.digest("v1")}`, true);
    const again = await request(`${backend.url}/quote`);
    assert.equal(again.body.total, 140);
    assert.equal(again.body.digest, old.manifest.sha256);
    assert.notEqual(again.body.incarnation, old.incarnation);
    await seen.waitClosed(v2);
    await alive(seen.handle(old.incarnation));
    retainedResume.resolve();
    const completed = await within(retainedCall, "retained old response complete");
    assert.ok(completed.ok);
    assert.equal(completed.value.body.before, 140);
    assert.equal(completed.value.body.total, 140);
    assert.equal(completed.value.body.incarnation, old.incarnation);
    await seen.waitClosed(old.incarnation);
    assert.equal((await backend.snapshot()).resources.length, 1);
    await alive(seen.handle(string(again.body.incarnation)));
    outcomes.push({ reactivated: again.body, retainedOriginal: completed.value.body });
  } finally { resume.resolve(); retainedResume.resolve(); await backend.close(); await f.cleanup(); }
  for (const incarnation of seen.handles.keys()) await seen.waitClosed(incarnation);
  console.log(JSON.stringify({ scenario: "http-generation-retention-and-incarnation", outcomes, events: seen.events }));
});

test("failed real candidate closes partial file and preserves active and persisted selection", { timeout: 20000 }, async () => {
  const f = await fixture();
  const seen = observer();
  const backend = await createBackend(f.directory, seen.observations);
  try {
    await request(`${backend.url}/_fixture/activate?digest=${f.digest("v1")}`, true);
    const before = await readProfile(f.directory);
    const failed = await request(`${backend.url}/_fixture/activate?digest=${f.digest("rejected")}`, true);
    assert.equal(failed.status, 503);
    assert.match(string(failed.body.error), /candidate-initialization-failure-after-acquisition/);
    const partial = [...seen.handles.values()].find(item => item.generation.manifest.version === "rejected");
    assert.ok(partial);
    await seen.waitClosed(partial.generation.incarnation);
    assert.deepEqual(await readProfile(f.directory), before);
    const current = await request(`${backend.url}/quote`);
    assert.equal(current.body.total, 140);
    await alive(seen.handle(string(current.body.incarnation)));
    assert.equal((await backend.snapshot()).resources.length, 1);
  } finally { await backend.close(); await f.cleanup(); }
  for (const incarnation of seen.handles.keys()) await seen.waitClosed(incarnation);
  console.log(JSON.stringify({ scenario: "partial-candidate-failure", events: seen.events }));
});

test("late preparation cannot overwrite a newer user intention or retain its file", { timeout: 20000 }, async () => {
  const f = await fixture();
  const seen = observer();
  const acquired = Promise.withResolvers<Generation>();
  const resume = Promise.withResolvers<void>();
  const backend = await createBackend(f.directory, {
    ...seen.observations,
    afterAcquire: async generation => {
      if (generation.manifest.version === "v2") { acquired.resolve(generation); await resume.promise; }
    },
  });
  try {
    await request(`${backend.url}/_fixture/activate?digest=${f.digest("v1")}`, true);
    const slow = settled(request(`${backend.url}/_fixture/activate?digest=${f.digest("v2")}`, true));
    const candidate = await within(acquired.promise, "candidate actual resource acquired");
    await alive(seen.handle(candidate.incarnation));
    const newest = await request(`${backend.url}/_fixture/activate?digest=${f.digest("v1")}`, true);
    assert.equal(newest.body.status, "activated");
    const newestIncarnation = string(newest.body.incarnation);
    resume.resolve();
    const result = await within(slow, "stale candidate response");
    assert.ok(result.ok);
    assert.equal(result.value.body.status, "stale");
    await seen.waitClosed(candidate.incarnation);
    const quote = await request(`${backend.url}/quote`);
    assert.equal(quote.body.incarnation, newestIncarnation);
    assert.equal(quote.body.total, 140);
    assert.deepEqual(await readProfile(f.directory), { revision: 3, enabled: true, sha256: f.digest("v1") });
    assert.equal((await backend.snapshot()).resources.length, 1);
  } finally { resume.resolve(); await backend.close(); await f.cleanup(); }
  for (const incarnation of seen.handles.keys()) await seen.waitClosed(incarnation);
  console.log(JSON.stringify({ scenario: "stale-preparation-fencing", events: seen.events }));
});

function startChild(directory: string) {
  const child = fork(new URL("./child.ts", import.meta.url), [directory], { execArgv: [], stdio: ["ignore", "pipe", "pipe", "ipc"] });
  const messages: Array<Record<string, unknown>> = [];
  const listeners = new Set<(message: Record<string, unknown>) => void>();
  let stdout = "";
  let stderr = "";
  child.stdout?.on("data", chunk => { stdout += String(chunk); });
  child.stderr?.on("data", chunk => { stderr += String(chunk); });
  child.on("message", (value: unknown) => {
    const message = object(value);
    messages.push(message);
    for (const listener of listeners) listener(message);
  });
  const exit = new Promise<{ code: number | null; signal: NodeJS.Signals | null }>(resolve => {
    child.once("exit", (code, signal) => resolve({ code, signal }));
  });
  const closed = new Promise<void>(resolve => child.once("close", () => resolve()));
  const event = async (name: string) => {
    const validate = (message: Record<string, unknown>) => {
      if (name === "commit-before-publication") assert.equal(object(message.detail).pid, child.pid);
      else assert.equal(message.pid, child.pid);
      return message;
    };
    const existing = messages.find(message => message.event === name);
    if (existing) return validate(existing);
    const waiting = Promise.withResolvers<Record<string, unknown>>();
    const listener = (message: Record<string, unknown>) => { if (message.event === name) waiting.resolve(message); };
    listeners.add(listener);
    try { return validate(await within(waiting.promise, `child ${name}`)); }
    finally { listeners.delete(listener); }
  };
  const waitExit = async () => {
    const result = await within(exit, "actual child exit");
    await within(closed, "child stdout/stderr closure");
    return result;
  };
  return {
    child, event, waitExit,
    logs: () => ({ stdout, stderr, messages }),
    stop: async () => { child.send("stop"); return waitExit(); },
    kill: async () => { assert.equal(child.kill("SIGKILL"), true); return waitExit(); },
    cleanup: async () => {
      if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
      await waitExit();
    },
  };
}

test("real process restart restores committed selection and disabled state; crash checkpoint is not activation", { timeout: 40000 }, async () => {
  const f = await fixture();
  const children: ReturnType<typeof startChild>[] = [];
  const observations: unknown[] = [];
  try {
    const first = startChild(f.directory); children.push(first);
    const ready1 = await first.event("ready");
    const url1 = string(ready1.url);
    await request(`${url1}/_fixture/activate?digest=${f.digest("v1")}`, true);
    const original = await request(`${url1}/quote`);
    assert.equal(original.body.total, 140);
    assert.deepEqual(await first.stop(), { code: 0, signal: null });

    const second = startChild(f.directory); children.push(second);
    const ready2 = await second.event("ready");
    assert.notEqual(ready2.pid, ready1.pid);
    const url2 = string(ready2.url);
    const restored = await request(`${url2}/quote`);
    assert.equal(restored.body.total, 140);
    assert.equal(restored.body.digest, original.body.digest);
    assert.notEqual(restored.body.incarnation, original.body.incarnation);
    const pending = settled(request(`${url2}/_fixture/activate?digest=${f.digest("v2")}&pause=1`, true));
    const checkpoint = await second.event("commit-before-publication");
    const detail = object(checkpoint.detail);
    assert.equal(detail.activeDigest, f.digest("v1"));
    assert.deepEqual(await readProfile(f.directory), { revision: 2, enabled: true, sha256: f.digest("v2") });
    const during = await request(`${url2}/_fixture/status`);
    assert.equal(object(during.body.active).digest, f.digest("v1"));
    assert.equal(object(during.body.desired).sha256, f.digest("v2"));
    assert.deepEqual(await second.kill(), { code: null, signal: "SIGKILL" });
    assert.equal((await within(pending, "killed update caller")).ok, false);
    observations.push({ checkpoint, killed: true, effectFinalizationClaimed: false });

    const third = startChild(f.directory); children.push(third);
    const ready3 = await third.event("ready");
    assert.notEqual(ready3.pid, ready2.pid);
    const url3 = string(ready3.url);
    const recovered = await request(`${url3}/quote`);
    assert.equal(recovered.body.total, 120);
    assert.equal(recovered.body.digest, f.digest("v2"));
    assert.equal(recovered.body.revision, 2);
    assert.equal((await request(`${url3}/_fixture/disable`, true)).body.status, "disabled");
    assert.equal((await request(`${url3}/quote`)).status, 503);
    assert.deepEqual(await third.stop(), { code: 0, signal: null });

    const fourth = startChild(f.directory); children.push(fourth);
    const ready4 = await fourth.event("ready");
    assert.notEqual(ready4.pid, ready3.pid);
    assert.equal((await request(`${string(ready4.url)}/quote`)).status, 503);
    assert.deepEqual(await readProfile(f.directory), { revision: 3, enabled: false, sha256: null });
    assert.ok((await readFile(join(f.directory, "artifacts", `${f.digest("v2")}.js`))).length > 0, "disable retains installation bytes");
    assert.deepEqual(await fourth.stop(), { code: 0, signal: null });
    observations.push({ pids: [ready1.pid, ready2.pid, ready3.pid, ready4.pid], original: original.body, restored: restored.body, recovered: recovered.body, disabledAfterRestart: true });
  } finally {
    await Promise.all(children.map(child => child.cleanup()));
    console.log(JSON.stringify({ scenario: "process-recovery-and-disable", observations, children: children.map(child => child.logs()) }));
    await f.cleanup();
  }
});

test("altered retained artifact is rejected on fresh boot before top-level code executes", { timeout: 25000 }, async () => {
  const f = await fixture();
  const children: ReturnType<typeof startChild>[] = [];
  try {
    const first = startChild(f.directory); children.push(first);
    const ready = await first.event("ready");
    await request(`${string(ready.url)}/_fixture/activate?digest=${f.digest("v1")}`, true);
    assert.equal((await request(`${string(ready.url)}/quote`)).body.total, 140);
    assert.deepEqual(await first.stop(), { code: 0, signal: null });
    const malicious = await readFile(new URL("./generated/plugin-src/tampered.js", import.meta.url));
    assert.match(malicious.toString(), /TAMPER_BODY_EXECUTED/);
    await writeFile(join(f.directory, "artifacts", `${f.digest("v1")}.js`), malicious);
    const rejected = startChild(f.directory); children.push(rejected);
    const failure = await rejected.event("boot-error");
    assert.match(string(failure.message), /artifact digest mismatch before import/);
    assert.deepEqual(await rejected.waitExit(), { code: 1, signal: null });
    assert.doesNotMatch(rejected.logs().stdout, /TAMPER_BODY_EXECUTED/);
    assert.equal(rejected.logs().messages.some(message => message.event === "ready"), false);
    assert.deepEqual(await readProfile(f.directory), { revision: 1, enabled: true, sha256: f.digest("v1") });
    console.log(JSON.stringify({ scenario: "altered-artifact-rejected-before-import", failure, rejectedLogs: rejected.logs() }));
  } finally { await Promise.all(children.map(child => child.cleanup())); await f.cleanup(); }
});
