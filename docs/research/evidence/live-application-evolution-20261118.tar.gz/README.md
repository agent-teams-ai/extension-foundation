# Live application evolution: retained research and execution

Observation date:2026-11-18, Europe/Kiev. Owner: Extension Foundation research;
canonical vision and unresolved product choices remain in OD-003. This packet
contains authored research, strict disposable TypeScript fixtures, original
failures, final observed results and independent reviews. It is not production
runtime adoption, a public SPI, package publication or an interruption decision.

## Navigation

- `plan.md`, `frontend-plan.md`, `backend-spike/plan.md`: bounded plans and
  independent critique dispositions. The original common plan remains in
  `review-inputs/plan-round1.md`.
- `persistent-industry/`: Directus12.6.1 and NocoBase2.2.47 source-ledger study.
- `live-logic-industry/`: Lively.next and Pharo14 source-ledger study; independent
  vision, plan, backend, browser and hosted-workflow reviews.
- `backend-spike/`: real HTTP, native GM/Effect resource lifetime and actual
  process recovery. `runtime-attempt3.log` is the corrected final5/5 authority.
  Initial errors and intermediate successful but weaker-oracle output remain.
- `frontend-spike/`: trusted browser logic/state/artifact fixture, local launch
  failures, frozen strict sources and the separately received hosted evidence.
- `root-provenance.json`, `root-dispositions.md`, `validation/`: source/policy
  identities, reviewed report wording and delivery checks.

## Reproduction boundary

Use the retained exact package/lock outside the repository's pnpm workspace.
Install with `pnpm install --frozen-lockfile --ignore-scripts --engine-strict
--strict-peer-dependencies`. TypeScript is exactly7.0.2; Node24.22.1 was used.
Consult each fixture's execution receipt/report for actual commands and cwd.
For the browser, use pinned Playwright1.62.1's official browser installation.
The repository's dedicated bounded workflow checks the independently frozen
14-file input archive before running; the hosted receipt binds that digest to
its checkout, run and attempt. No copied dependency tree is part of this packet.

The fixtures intentionally use self-contained generated executable modules,
ordinary local consumer persistence and trusted code. They do not qualify EF's
PostgreSQL/OCI admission, hostile isolation, arbitrary state migration, remote
effects, distributed rollout, unlimited code churn or all stream/session forms.
No upstream research project's tests were run. Third-party inspection copies
are excluded; exact revisions/blobs and primary links are retained instead.

Historical Nov14/Nov17 evidence archives were reverified without changes. The
new result is an additional bounded observation, not a rewrite of prior evidence.
