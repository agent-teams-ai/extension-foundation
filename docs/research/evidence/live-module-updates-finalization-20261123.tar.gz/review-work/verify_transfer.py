#!/usr/bin/env python3
"""One-off, read-only research-transfer review. Not a production test or gate."""
import argparse
import copy
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key}")
        result[key] = value
    return result


def parse_json(content):
    return json.loads(content, object_pairs_hook=unique_object)


def digest(content):
    return hashlib.sha256(content).hexdigest()


def safe_path(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute(), f"absolute/empty member: {name!r}")
    require(".." not in path.parts and "\\" not in name and "\0" not in name,
            f"unsafe member: {name!r}")
    require(not re.match(r"^[A-Za-z]:", name), f"drive path: {name!r}")
    require(path.as_posix() == name.rstrip("/"), f"noncanonical path: {name!r}")
    return path


def archive_metadata(manifest):
    value = manifest.get("archive")
    return value if isinstance(value, dict) else manifest


def verify_archive(archive, manifest, destination=None):
    data = archive.read_bytes()
    metadata = archive_metadata(manifest)
    require(len(data) == metadata["bytes"], "archive byte count mismatch")
    require(digest(data) == metadata["sha256"], "archive SHA-256 mismatch")
    entries = manifest.get("members", manifest.get("files"))
    require(isinstance(entries, list) and entries, "manifest has no explicit members")
    expected = {entry["path"]: entry for entry in entries}
    require(len(expected) == len(entries), "duplicate manifest member")
    for name in expected:
        safe_path(name)
    with tarfile.open(archive) as handle:
        members = handle.getmembers()
        require(len({member.name for member in members}) == len(members),
                "duplicate archive member")
        for member in members:
            safe_path(member.name)
            require(member.isfile() or member.isdir(), f"special/link member: {member.name}")
        regular = [member for member in members if member.isfile()]
        require({member.name for member in regular} == set(expected), "member set mismatch")
        for member in regular:
            content = handle.extractfile(member).read()
            record = expected[member.name]
            require(len(content) == record["bytes"], f"member size: {member.name}")
            require(digest(content) == record["sha256"], f"member hash: {member.name}")
        if destination is not None:
            handle.extractall(destination, filter="data")
    for key in ("memberCount", "fileCount"):
        if key in manifest:
            require(manifest[key] == len(expected), f"{key} mismatch")
    if destination is not None:
        actual = {str(path.relative_to(destination)): path for path in destination.rglob("*")
                  if path.is_file()}
        require(set(actual) == set(expected), "extracted file set mismatch")
        for name, path in actual.items():
            require(not path.is_symlink(), f"extracted symlink: {name}")
            content = path.read_bytes()
            require(len(content) == expected[name]["bytes"] and
                    digest(content) == expected[name]["sha256"], f"round-trip bytes: {name}")
    return expected


def git(repo, *args):
    result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True)
    require(result.returncode == 0,
            f"Git lookup failed: {' '.join(args)}: {result.stderr.decode(errors='replace')}")
    return result.stdout


def walk_values(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk_values(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_values(child)
    elif isinstance(value, str):
        yield value


def visible_markdown(text, strip_inline_code=True):
    output, fence = [], None
    for line in text.splitlines():
        match = re.match(r"^\s{0,3}(`{3,}|~{3,})", line)
        if match:
            marker = match.group(1)
            if fence is None:
                fence = marker
            elif marker[0] == fence[0] and len(marker) >= len(fence):
                fence = None
            output.append("")
        elif fence is None:
            output.append(re.sub(r"(`+).*?\1", "", line) if strip_inline_code else line)
        else:
            output.append("")
    return "\n".join(output)


def markdown_targets(text):
    text = visible_markdown(text)
    inline = re.findall(r"!?\[[^\]\n]*\]\(\s*(<[^>]+>|[^\s)]+)(?:\s+[^\n]*?)?\)", text)
    references = re.findall(r"^\s{0,3}\[[^\]]+\]:\s*(<[^>]+>|\S+)", text, re.M)
    return [target[1:-1] if target.startswith("<") else target
            for target in inline + references]


def heading_ids(content):
    result, counts = set(), {}
    text = content.decode("utf-8")
    result.update(re.findall(r'<a\s+[^>]*(?:id|name)=["\']([^"\']+)', text, re.I))
    for match in re.finditer(r"^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$", visible_markdown(text, False), re.M):
        title = re.sub(r"\[([^]]+)\]\([^)]+\)", r"\1", match.group(1)).lower()
        title = re.sub(r"(`+)(.*?)\1", r"\2", title)
        title = re.sub(r"<[^>]*>", "", title)
        slug = re.sub(r"[^\w\- ]", "", title, flags=re.UNICODE).replace(" ", "-")
        count = counts.get(slug, 0)
        result.add(slug + (f"-{count}" if count else ""))
        counts[slug] = count + 1
    return result


def verify_fragment(content, fragment, filename):
    if not fragment:
        return
    fragment = unquote(fragment)
    if re.fullmatch(r"L\d+(?:-L\d+)?", fragment):
        require(max(map(int, re.findall(r"\d+", fragment))) <= len(content.splitlines()),
                f"line fragment beyond file: {filename}#{fragment}")
    elif filename.lower().endswith(".md"):
        require(fragment in heading_ids(content), f"missing Markdown fragment: {filename}#{fragment}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--repository", default="agent-teams-ai/extension-foundation")
    parser.add_argument("--baseline", default="cc07959309f65ab2401f838c982911743075fe1e")
    parser.add_argument("--freeze", type=Path)
    parser.add_argument("--allow-changed", action="append", default=[])
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    manifest = parse_json(args.manifest.read_text())
    freeze = parse_json(args.freeze.read_text()) if args.freeze else None
    if freeze:
        require(freeze["sourceCommit"] == args.baseline, "freeze baseline differs")
        for label, path in (("archive", args.archive), ("manifest", args.manifest)):
            content = path.read_bytes()
            require(len(content) == freeze[label]["bytes"] and
                    digest(content) == freeze[label]["sha256"], f"frozen {label} drift")
        for record in freeze["governedDocuments"]:
            content = (args.repo / record["path"]).read_bytes()
            require(len(content) == record["bytes"] and digest(content) == record["sha256"],
                    f"frozen governed document drift: {record['path']}")
    checked_git, external, local_links, packet_records = {}, set(), [], []

    def remote_target(target):
        url = urlsplit(target)
        parts = unquote(url.path).strip("/").split("/")
        if url.netloc == "github.com" and len(parts) >= 5 and parts[2] in ("blob", "tree"):
            repository, revision, name = "/".join(parts[:2]), parts[3], "/".join(parts[4:])
        elif url.netloc == "raw.githubusercontent.com" and len(parts) >= 4:
            repository, revision, name = "/".join(parts[:2]), parts[2], "/".join(parts[3:])
        else:
            external.add(target)
            return
        if repository != args.repository:
            external.add(target)
            return
        require(re.fullmatch(r"[0-9a-f]{40}", revision) is not None,
                f"mutable/noncanonical source ref: {target}")
        safe_path(name)
        coordinate = f"{revision}:{name}"
        if coordinate not in checked_git:
            kind = git(args.repo, "cat-file", "-t", coordinate).decode().strip()
            checked_git[coordinate] = {"type": kind}
            if kind == "blob":
                content = git(args.repo, "show", coordinate)
                checked_git[coordinate].update(bytes=len(content), sha256=digest(content))
        if url.fragment and checked_git[coordinate]["type"] == "blob":
            verify_fragment(git(args.repo, "show", coordinate), url.fragment, name)

    with tempfile.TemporaryDirectory(prefix="live-module-transfer-review-") as temporary:
        temp = Path(temporary)
        extracted = temp / "extracted"
        extracted.mkdir()
        expected = verify_archive(args.archive, manifest, extracted)
        tree = digest("".join(name + "\0" + expected[name]["sha256"] + "\n"
                              for name in sorted(expected)).encode())
        if "treeSha256" in manifest:
            require(tree == manifest["treeSha256"], "manifest tree hash mismatch")
        if freeze:
            require(tree == freeze["projectTreeSha256"], "freeze tree hash mismatch")
        if "uncompressedFileBytes" in manifest:
            require(sum(record["bytes"] for record in expected.values()) ==
                    manifest["uncompressedFileBytes"], "uncompressed file byte count mismatch")
        require(not any(path.is_symlink() for path in args.project.rglob("*")),
                "project contains a symlink")
        project_files = {str(path.relative_to(args.project)): path
                         for path in args.project.rglob("*") if path.is_file()}
        require(set(project_files) == set(expected), "frozen project/archive file set mismatch")
        for name, path in project_files.items():
            require(not path.is_symlink(), f"project symlink: {name}")
            require(digest(path.read_bytes()) == expected[name]["sha256"], f"project drift: {name}")
            parts = PurePosixPath(name).parts
            require(not {"node_modules", ".git", "__pycache__"}.intersection(parts),
                    f"nonportable dependency/cache: {name}")
            require(not name.startswith(".github/workflows/"), f"active transferred workflow: {name}")

        for path in sorted(extracted.rglob("*.md")):
            for target in markdown_targets(path.read_text()):
                url = urlsplit(target)
                if url.scheme or url.netloc:
                    require(url.scheme not in ("file", "sandbox"), f"nonportable link: {target}")
                    remote_target(target)
                    continue
                name = unquote(url.path)
                require(not name.startswith("/"), f"absolute local link: {target}")
                resolved = (path.parent / name).resolve() if name else path.resolve()
                require(resolved.is_relative_to(extracted.resolve()), f"escaping link: {target}")
                require(resolved.exists(), f"missing relative link in {path.relative_to(extracted)}: {target}")
                if resolved.is_file():
                    verify_fragment(resolved.read_bytes(), url.fragment, str(resolved))
                local_links.append({"source": str(path.relative_to(extracted)), "target": target})

        for path in sorted(extracted.rglob("*.json")):
            for item in walk_values(parse_json(path.read_text())):
                if isinstance(item, str) and item.startswith(("https://github.com/", "https://raw.githubusercontent.com/")):
                    remote_target(item)
                if not isinstance(item, dict) or "archivePath" not in item:
                    continue
                require(item["sourceRepository"] == args.repository, "unmapped evidence repository")
                revision, name = item["sourceCommit"], item["archivePath"]
                require(re.fullmatch(r"[0-9a-f]{40}", revision) is not None, "unfixed evidence revision")
                content = git(args.repo, "show", f"{revision}:{name}")
                require(len(content) == item["bytes"] and digest(content) == item["sha256"],
                        f"evidence packet bytes differ: {name}")
                source_manifest = parse_json(git(args.repo, "show", f"{revision}:{item['manifestPath']}"))
                metadata = archive_metadata(source_manifest)
                require(metadata["sha256"] == item["sha256"] and metadata["bytes"] == item["bytes"],
                        f"evidence archive/manifest mismatch: {name}")
                packet_records.append({"path": name, "revision": revision,
                                       "bytes": len(content), "sha256": digest(content)})

        # Negative control: valid TAR with one modified member, original manifest.
        tampered = temp / "tampered.tar.gz"
        modified = None
        with tarfile.open(args.archive) as source, tarfile.open(tampered, "w:gz") as target:
            for member in source.getmembers():
                member = copy.copy(member)
                if member.isfile():
                    content = source.extractfile(member).read()
                    if modified is None and content:
                        content = bytes([content[0] ^ 1]) + content[1:]
                        modified = member.name
                    target.addfile(member, io.BytesIO(content))
                else:
                    target.addfile(member)
        rejected = []
        for label, check_manifest in (("original manifest", manifest),
                                      ("outer hash recomputed, member hashes unchanged", copy.deepcopy(manifest))):
            if check_manifest is not manifest:
                metadata = archive_metadata(check_manifest)
                metadata["bytes"] = tampered.stat().st_size
                metadata["sha256"] = digest(tampered.read_bytes())
            try:
                verify_archive(tampered, check_manifest)
            except ValueError as error:
                rejected.append({"control": label, "reason": str(error)})
            else:
                raise ValueError(f"tampered archive accepted: {label}")

    require(modified is not None, "negative control has no nonempty member")
    changed = set(git(args.repo, "diff", "--name-only", "-z", args.baseline).decode().strip("\0").split("\0"))
    changed.update(git(args.repo, "ls-files", "--others", "--exclude-standard", "-z").decode().strip("\0").split("\0"))
    changed.discard("")
    changed.discard("node_modules")
    require(changed <= set(args.allow_changed), f"out-of-scope changed paths: {sorted(changed-set(args.allow_changed))}")
    historical = git(args.repo, "ls-tree", "-r", "--name-only", "-z", args.baseline,
                     "--", "docs/research/evidence").decode().strip("\0").split("\0")
    for name in historical:
        if name:
            require((args.repo/name).read_bytes() == git(args.repo, "show", f"{args.baseline}:{name}"),
                    f"historical evidence rewritten: {name}")
    report = {"verdict": "PASS artifact integrity and portability only; semantic review separate",
              "archive": str(args.archive), "archiveSha256": digest(args.archive.read_bytes()),
              "members": len(expected), "bytes": args.archive.stat().st_size,
              "projectTreeSha256": tree,
              "roundTrip": "exact", "tamperControls": rejected, "tamperedMember": modified,
              "relativeLinks": local_links, "verifiedGitObjects": checked_git,
              "referencedPacketRecords": packet_records,
              "externalLinksNotValidated": sorted(external),
              "baseline": args.baseline, "changedPaths": sorted(changed),
              "historicalEvidenceFilesUnchanged": len([name for name in historical if name]),
              "newNativeCoverage": 0}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n")
    print(json.dumps({key: report[key] for key in ("verdict", "members", "bytes", "roundTrip",
                                                  "historicalEvidenceFilesUnchanged", "newNativeCoverage")}, indent=2))


if __name__ == "__main__":
    main()
