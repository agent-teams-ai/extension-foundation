# Native state recovery result and final research review

Date: 2026-10-26 UTC. This is a completed, bounded research result, not a
production plugin runtime, full-product recovery qualification or package release.

## Start here

- `reports/state-recovery-native-result.md`: source owner's review of the actual
  run, provenance, exact restore semantics, cost and limitations.
- `reports/critic-native-result-independent.md`: independent source/result
  criticism after execution. Reviewer agreement is not another execution.
- `reports/critic-final-adoption-round2.md`: independent ownership, reuse,
  Temporal, language and next-integration judgment. Its native section was
  written before the two raw native reviews and explicitly says so.
- `run/artifact/sr1/results.json`, `source-expected.json` and
  `target-readback.json`: actual structured runtime observations.
- `run/artifact/sr1/feature.dump`, `globals.sql` and `archive-toc.log`: actual
  tiny synthetic logical restore inputs and listing. Physical DB data is absent.
- `run/root-artifact-review.json`: root's separate retained-byte review and a
  corrected distinction between copied source-catalog JSON and the executed
  target SQL equality assertion.
- `run/job.log`, `run/run.json`, `run/jobs.json`, `run/artifacts.json` and
  `run/executed-workflow.yml`: exact execution identity and workflow.

## Execution identity

Repository: agent-teams-ai/extension-foundation, draft PR55.
Executed commit: `b3c51fc0485cc8c396638a212716bb9497d57652`.
Run: https://github.com/agent-teams-ai/extension-foundation/actions/runs/40407349905
Job: `121868432835`. Attempt: 1. Actual outer exit: 0.

GitHub artifact `12689974898` has 52 regular files. The exact downloaded ZIP is
`run/artifact.zip`, 146,615 bytes, SHA256
`c005c978e670f44d6ac030ad611278c390be89bd0587796d0c4fabad757b3f2d`.
Root matched every extracted byte to this ZIP; the native critic separately
checked the upload digest and source/input binding. The upload's 14-day retention
does not limit this committed copy.

Actual executed workflow SHA256:
`e8b79fc8799b9cb87ee400ced96f00a1042a8c011b3ae99e3bb901190450b6cc`.
The first workflow at `ba5dbdd` failed before scheduling any jobs. Its source
placed runner-context variables in job environment, where that context is
unavailable. Only the two variables' placement moved to the consuming step
environments. The failed run receipt and independent correction review are
retained. No native guard, assertion, source, input, permission or budget changed.

The temporary branch-only native workflow is removed from the final PR tree
after its research purpose is complete; executed bytes and history remain.
No existing required workflow or identity policy is changed.

At the exact executed commit, the retained `run/repository-checks.json` records
successful repository check, Node 26 check, Windows/macOS architecture,
product-source, CodeQL and actual trusted DocsProtocol routes. The existing
author-alias identity check still fails. These are that commit's observed gates;
later documentation publication must be assessed at its own commit.

## Exact inputs and reproduction

The separate published input archive is
`docs/research/evidence/native-state-recovery-20261026-inputs.tar.gz`,
1,099,983 bytes, SHA256
`9ee27beb087e17d946724b98fb4dbd01370350910757dfa6faed4b3da7e90740`.
It retains the source, public package manifest/lock, strict configs, final
source manifest, bootstrap, PGDG key/signed index and initial plan reviews.
Its original `review/workflow.yml` is the initial pre-scheduling-failed snapshot;
use this result archive's separately bound `run/executed-workflow.yml` for the
actual successful environment layout. Do not silently rewrite that input archive.

From each extracted archive root, run `sha256sum -c SHA256SUMS` to verify its
regular payloads. Reproduction uses the exact executed workflow and input
archive on an isolated Ubuntu 24.04 x64 environment with an unprivileged user,
Node 26.11.1, pnpm 11.18.0, at least the retained 1 GiB available-space guard
and official HTTPS dependency access. The workflow supplies bounded staging,
frozen installation, strict TypeScript 7.0.2 checks, native execution and
always-retained evidence. Keep all output and cluster paths task-owned and new.
On GitHub Actions, bootstrap writes the declared native paths into GITHUB_ENV
for the next step. A manual replay must transport those same environment values
explicitly; running only `run-ci.sh` without them is not the recorded workflow.

Do not execute SR2 from this input snapshot. Its exact Drizzle RC4 dependency
declaration gate is red; changing compiler flags, vendor files or package pins
would define different inputs and requires the owning compatibility review.

## Observed result and interpretation

SR1 is one actual end-to-end flow with four named passed checkpoints. The
optional older-major helper comparison is recorded as unavailable, not passed.
Three original facts and three outbox identities survive the restore exactly.
Two original-identity retries add no event, and one new manifest yields the
final four facts/four events. Source and target have different system identifiers
and data directories; the source postmaster stops before target startup.

An initial restore without source roles fails and the executed SQL assertions
find no partial feature schema/tables. Restoring captured global roles and the
same whole-application-database archive succeeds without target migrations or
grant/policy repairs. Target catalog equality is an actual awaited SQL assertion;
`target-readback.originalCatalog` is a copy of the original source catalog,
not an additional raw target snapshot. Direct target runtime SQL separately
retains identity, effective privileges, own/foreign visibility, four RLS-specific
write rejections and a distinct DDL permission rejection.

Native server is the exact embedded-postgres 18.4 research payload. Logical
helpers and libpq are separate PGDG 18.4 packages selected from a verified
signed index; their path resolution and hashes are retained. The native npm
and Debian binary payloads are not embedded in this result archive. Recorded
versions and provenance do not approve a production distribution or imply the
launcher ships backup tools.

Both postmasters exited 0, actual status checks returned stopped, native absence
was asserted and both registered roots were removed. No native command hit its
deadline. An outer timeout would have been failure with cleanup unproved, not a
passing watchdog. Hosted job containment remains only a final fallback.

This result concerns one synthetic application database using the preserved
real feature on the named Linux/native profile. It does not establish full
Temporal/product backup, cross-database consistency, production secret/role
restoration, power-loss behavior, arbitrary descendants, cross-OS delivery,
migration rollback, hostile plugins or a thousand active plugin instances.

## Adoption disposition

Continue static composition and controlled restart within existing owners.
Keep product admission ordered in its existing receiver, original construction
authority through readiness/cleanup debt, and physical retirement in its existing
custodian. Complete hashes and a fresh process need real fixed artifact custody.
Optional Temporal scheduling adapts the same qualified product operation.
Preserve the existing Rust keeper/init direction for a named OS custody need;
this campaign supports no speculative Rust lifecycle rewrite or new supervisor.

The next decision-changing work is one real product extension family and its
actual receiver/artifact/custody join. Reuse the existing verify-then-replace
falsifier against that real custody mechanism; repeating the disposable matrix
cannot qualify it. The final critic retains separate confidence, reliability,
complexity and production/integration/test LOC estimates with explicit scope.
