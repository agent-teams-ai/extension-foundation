--
-- PostgreSQL database cluster dump
--

\restrict AsoxTeAWyCgkEt8INDysPwm8Bb5uvXfuyVW5T6Ka8PxmuhMQrYkMCUHJDH6Sgaj

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE "TEST_source_owner";
ALTER ROLE "TEST_source_owner" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;
CREATE ROLE test_runtime;
ALTER ROLE test_runtime WITH NOSUPERUSER NOINHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;

--
-- User Configurations
--








\unrestrict AsoxTeAWyCgkEt8INDysPwm8Bb5uvXfuyVW5T6Ka8PxmuhMQrYkMCUHJDH6Sgaj

--
-- PostgreSQL database cluster dump complete
--

