# Native workflow context correction — independent review

Date: 2026-10-26 UTC. **Read-only source/documentation review; no repository edit,
workflow dispatch, native execution or archive replacement by this reviewer.**

## Verdict

**GO for the minimal corrected workflow.** Both `NATIVE_ROOT` and `EVIDENCE` must
move out of `jobs.sr1.env` because both values use `runner.temp`. Root's actual
corrected file moves the exact two unchanged bindings into **each** consuming
step's `env`: native staging and the strict SR1/native-run step. The upload step
already refers to `runner.temp` in `with.path`, which is permitted there.

I compared the actual corrected repository workflow against the frozen original
plan using both a textual diff and a parsed structural comparison. Removing the
old job `env`, then removing and comparing the two identical step `env` mappings,
leaves equal workflow structures. No other semantic YAML change was found.

## Failure record and limits of diagnosis

Root reports actual run **40406776214**, source head **ba5dbdd**, failed before
scheduling, with `jobs[].length === 0` and its name rendered as the workflow path.
Those fields are root-retained platform evidence, not an independently repeated
API query by this reviewer. No native job, restore scenario, typecheck or database
cleanup result can be inferred from that unscheduled run.

The invalid context placement is independently established from source and the
official GitHub availability table. It explains a concrete semantic defect
consistent with rejection before scheduling. This review does **not** claim an
unavailable GitHub parser annotation was retrieved or that the sparse run fields
alone uniquely identify that defect.

The original prepublication syntax/structural review missed this expression
context rule. Parsing valid YAML and checking permission/trigger shapes did not
qualify it as a schedulable GitHub workflow. Preserve that failure and correction
instead of rewriting the initial review as though it had caught the issue.

## Official context-availability check

Retrieved 2026-10-26 from the primary
[GitHub contexts reference](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#context-availability).
Its availability table explicitly limits each workflow key's contexts.

| Actual expression location | Context/function used | Official availability | Review disposition |
| --- | --- | --- | --- |
| Original `jobs.sr1.env` | `runner.temp` in both path values | Job `env` permits github/needs/strategy/matrix/vars/secrets/inputs; **runner is absent** | Invalid original placement; both occurrences require correction |
| Corrected staging `steps.env` | `runner.temp` for both paths | Step `env` includes runner | Allowed |
| Corrected native-run `steps.env` | `runner.temp` for both paths | Step `env` includes runner | Allowed |
| `jobs.sr1.if` | `github.repository` | Job `if` includes github | Allowed |
| Staging `steps.run` | `job.status` | Step `run` includes job | Allowed |
| Upload `steps.with.name` | `github.sha`, `github.run_attempt` | Step `with` includes github | Allowed |
| Upload `steps.with.path` | `runner.temp` in include/exclude paths | Step `with` includes runner | Allowed |
| Staging/upload `steps.if` | `always()` | Step `if` permits that status function | Allowed |

The other workflow values are literals or ordinary runner-shell variables.
`$RUNNER_TEMP`, `$NATIVE_ROOT`, `$EVIDENCE` and `$GITHUB_ENV` are consumed inside
running steps/scripts, rather than interpolated as job-level runner contexts.
No additional unsupported context expression remained in the reviewed file.

## Environment and evidence continuity

Staging receives the same two absolute paths and exports them to its bootstrap
child through ordinary step environment inheritance. The bootstrap writes its
`STATE_RECOVERY_*` and `LD_LIBRARY_PATH` values to `GITHUB_ENV` for subsequent
steps. Native execution receives those exported values plus its own identical
two path bindings. Its step `env` does not replace unrelated exported variables.
Upload uses an explicit permitted runner-path expression and does not depend on
the removed job `env`.

The correction changes no branch/path trigger, repository condition, action
pin, native source/provenance binding, fixture/lock, permission, secret policy,
unprivileged UID check, disk guard, timeout, SQL/native bound or upload retention.
It adds no installation, fallback, library-check bypass or new runtime path.
SR2 remains blocked and absent from native execution.

Exact identity anchors:

| Subject | SHA256 |
| --- | --- |
| Frozen original `plans/native-state-recovery-workflow.yml` and initial repository YAML | `6d7bb78f6d771917c9b302d2a6374b2e9e3caa3a943d5c945a193e7c627c21b8` |
| Actual corrected `.github/workflows/native-state-recovery-research.yml` | `e8b79fc8799b9cb87ee400ced96f00a1042a8c011b3ae99e3bb901190450b6cc` |
| Existing native input archive, rehashed after this correction | `9ee27beb087e17d946724b98fb4dbd01370350910757dfa6faed4b3da7e90740` |

A new input bundle is unnecessary because neither bootstrap nor fixture inputs
changed. The original workflow/review snapshot inside the archive remains an
immutable historical input. Eventual hosted evidence must bind **the actual
corrected workflow bytes/commit** separately and state that the archived input
review contains the initial workflow snapshot. Do not overwrite or delete the
original archive, failed workflow or unscheduled-run evidence.

## What the next hosted result can establish

The first next check is whether GitHub accepts the corrected workflow and
creates the expected job. A scheduled job is only workflow-semantic progress;
it does not establish native acquisition, strict typechecking, restore success,
physical retirement or artifact retention. Those remain the actual subsequent
step/results/cleanup observations. A timeout or failed upload remains a failed
or unqualified outcome under the previously reviewed rules.

No native rerun or input/policy change is requested by this review. Root may
publish the minimal external-workflow correction and retain its actual result.
