# Final adoption critic, round 2

Review date: 2026-10-26 UTC. **Read-only synthesis review, not independent
reexecution.** No repository, experiment source, dependency, gate or accepted
ADR was changed. This report is the only file written by this critic. Sandbox
startup intermittently failed with ENOSPC during document reads; those failures
are environmental observations, not test results. All conclusions below derive
from the inspected retained reports and current synthesis.

## Verdict: proceed with the existing direction; keep qualification holds explicit

**GO** for the accepted static-composition plus controlled-restart baseline and
for a narrow first product integration using existing owners. The new evidence
justifies receiver-local acceptance sealing, retention of the original
construction/resource attempt, separate semantic/effect/physical observations,
inert selected loading and a complete fixed artifact closure. It does not
justify a new universal Host, lifecycle FSM, supervisor, RPC framework, migration
engine, mandatory workflow wrapper or language rewrite.

**HOLD** any claim of production plugin admission/restart qualification, complete
artifact custody, hostile isolation, arbitrary-descendant containment, a
thousand active plugin instances, long-run retention bounds, power-loss
durability or a qualified public SPI. These are distinct missing guarantees,
not reasons to restart the architecture research.

**Native SR1 status advanced during this review.** Root reports an actual
successful run on corrected commit `b3c51fc`, run `40407349905`, job
`121868432835`. Raw artifact `12689974898` is 146,615 bytes with SHA256
`c005c978e670f44d6ac030ad611278c390be89bd0587796d0c4fabad757b3f2d`
and is being acquired for independent review. This critic has not inspected its
raw native results and therefore records that result as root-reported, not
independently verified here or product-qualified. The earlier pre-scheduling
workflow failure remains history. SR2 remains red/unexecuted behind the exact
Drizzle declaration gate. Keep both statuses separate from the locally executed
restart/loading observations.

I found no material false-positive claim in the current
`docs/research/plugin-boundary-and-failure-experiments.md` narrative. It carries
the important independent-critic corrections and distinguishes evidence from
future adoption. Reviewer agreement is not an additional execution result.

## Evidence reviewed and what it actually supports

The common `context.md` was read first. I then read `reports/restart.md`,
`reports/plugin-boundaries.md`, both independent cross-track result critiques,
`reports/state-recovery.md`, the actual awaited-initializer `REPORT.md` and its
independent critic, and the root-owned boundary/failure synthesis. I also
inspected the existing static-restart validation, reuse/ownership, Temporal,
language-boundary, customization/scale and ecosystem-scale research. This
review does not imply a fresh checksum audit, strict build or code-level audit
of every retained source file.

| Finding | Why the evidence changes a decision | Scope retained |
| --- | --- | --- |
| Seven positive restart cases and three deliberate red witnesses | The new absence/reservation oracle detects the original hole, while the receiver-local correction rejects after actual queued seal completion. A new global manager is unnecessary for this measured problem. | Copied receiver/custodian fixture; process-restart persistence; no product PostgreSQL transaction qualification. |
| Earlier acceptance is ordered ahead of the seal | Stop-request wall clock alone cannot define a retroactive rejection guarantee. An accepted cohort needs its declared recovery disposition. | One receiver's serialized ordering, both retained recovery profiles. |
| Readiness rejection with one failed cleanup debt | Real handles remain open, then the same retained attempt retries and closes them. Discarding construction authority or adding a candidate lifecycle owner is unnecessary. | The new row retains the first report; discarded-report authority belongs to historical L07. Initialization itself did acquire resources. |
| Real late effect/result and a live disconnected child | Cancellation is a canonical semantic choice, not undo of an already synced file effect. Result/disconnect cannot release occupied execution capacity. | Exact known processes; planned force retirement; no arbitrary tree or custodian-death qualification. |
| Six selected-loading observations | Inert metadata and actual public GM compilation can precede selected executable evaluation; installed code need not all execute. | Literal TEST loaders and selected tiny graph; not arbitrary package admission or proof of manifest truthfulness. |
| Four artifact groups | Entry-only hashing and root-only query reload fail coherence. Complete two-file verification also fails custody when the same path can change before import. | Real counterexamples; unchanged coherent directories are a conditional positive, not enforcement. |
| Five placement trials | Worker/process placement preserves host response under the measured pure-JS loop and provides a distinct retirement boundary. | Trusted Linux code; shared process fate remains for Workers; no security sandbox result. |
| Separate actual awaited-initializer row | A retained startup really awaits initialization, stays responsive while pending and reaches readiness after actual release/return. The reachable positive prevents broken readiness from passing a no-ready-only check. | A synthetic gate and real async/IPC/file/exit observations; no cancellation, resource cleanup or hard-watchdog guarantee. |

The original async row must continue to be described as a pending Promise plus
withheld readiness, not as an actual awaited initializer. The current synthesis
does this. Likewise, a Promise-race observation deadline does not cancel the
underlying continuation. The finite registries match the expected creates, but
the registrar's silent omission on unavailable mapping prevents a generic
fail-closed custody claim. These limitations are already disclosed; none
requires another campaign matrix.

## Ownership recommendation is justified

GM remains the owner of declarations, selection, graph compilation/construction
and its existing resource semantics. EF remains the neutral owner of extension,
artifact/trust/protocol requirements, conformance and package admission.
Products own concrete extension points, literal selection/loading policy,
effective grants, real admission, canonical state, operation/recovery and
lifecycle decisions. The existing execution owner retains physical custody.

This is consistent with the observed faults. The acceptance failure is repaired
where acceptance is serialized; its fix does not belong in graph compilation.
The byte race belongs to artifact/loading custody; neither GM type compatibility
nor a new supervisor closes it. Readiness/cleanup debt belongs to the retained
attempt/resource owner. Semantic cancellation and external-effect reconciliation
belong to the product operation, while exact exit and capacity release remain
with custody.

Do not interpret these boundaries as requiring each product to copy common
mechanics. A demonstrated reusable residual can have one neutral library owner
from its first real delivery. The current evidence merely fails to identify a
new residual large enough to require another framework or repository after
subtracting GM, fitting execution/RPC libraries and existing product operations.
Library-first does not require speculative publication; product authority does
not prohibit reusable sequencing. Preserve EF public-SPI and product production
adoption gates, including the stronger independent integration requirements,
separately from an ordinary library-source admission.

The existing optional GM lifecycle candidate remains private. These results do
not make it public, require it for static restart, authorize deep imports or
justify moving/rewriting its state machine.

## Plugin model, cohort, sandbox and scale are different decisions

| Dimension | What the current evidence says | What it does not say |
| --- | --- | --- |
| Plugin model | Small consumer/plugin-owned extension points, explicit provider selection and immutable profiles can support deep customization without product forks. Static binding and restart are useful capabilities. | Every internal method is a public hook, every future customization fits today's contracts, or every plugin requires live replacement. |
| Execution cohort | A selected capability graph can share one fitting execution owner when its trust, failure and lifetime contract permits. Ordinary module calls remain ordinary calls. | One Worker/process/workflow per descriptor, or one universal shared realm for unrelated authority/failure profiles. |
| Security sandbox | Host grants and selected runtime authority must be enforced at their real boundaries. | Worker separation, a child PID, a hash/signature, TypeScript types or a Rust host makes arbitrary user code safe. |
| Static graph growth | The current descriptor-union recipe passed N100/500/1000, eight stages each under unchanged caps. | A new compiler fix, thousand-plugin active capacity, tenant multiplication, hostile execution, editor latency or runtime retention qualification. |
| Active plugin scale | Installed, selected, constructed and executing counts must be reported separately; tenant/cohort/replica/generation multipliers matter. | Finite one-shot cycles or descriptor counts bound aggregate RSS, queues, process count or cleanup debt. |

Deep customization therefore does not require a generic global interception API
or container access. It requires owner-supported contribution/provider seams and
compatibility examples. The first implementation should prove its actual author
task; it should not implement every hypothetical extension category.

One historical navigation caveat remains: the dated
`customization-without-forks-and-scale.md` scale section still mentions a
separate TypeScript 7.0.2 compiler blocker. Do not read that sentence as a
current blocker of the now-qualified descriptor-union recipe. The newer
static-restart validation explicitly supersedes such a reading and correctly
says the recipe already had upstream October 23 evidence. Preserve the old
history; the current decision summary must keep that chronology explicit. I
have not inferred that all possible type-level API shapes or editor workloads
are qualified.

## Optional Temporal, Rust and extraction

Optional Temporal scheduling is supported as an adapter above the same
product-owned operation. Existing retained native evidence includes receiver
COMMIT/ACK-loss and stale-epoch behavior, and ordinary calls succeeded with
Workers/service unavailable. It does not turn Temporal into the plugin runtime
or acceptance authority. In particular, the stale Activity still performed one
finite preflight construction before its SQL fence rejected the mutation; a
canonical fence does not guard arbitrary plugin effects occurring earlier.
Retain construction as inert/repeatable or move effect authority to its actual
receiver. Do not label the finite preflight result a long-lived Host cutover.

This optional rollout choice does not reopen Orchestrator's application
workflow choice. Native PostgreSQL local/hosted and Fully Local V1 are already
accepted on main; owner-accepted ADR-0116 selects full native Temporal in
unmerged PR90. Acceptance and merge status are separate. Research package
versions are evidence identities, not approved production distribution pins.

Keeping TypeScript policy/composition/SDK work and avoiding a Rust FSM rewrite
is justified. None of the measured faults is a handwritten-memory-management
failure. The prior approved direction for separate Rust keeper/init physical
custody work must remain preserved: this campaign neither delivers nor revokes
it. Reuse/audit that existing work for a named OS-custody requirement. Do not
claim an available released keeper, fund a second supervisor or infer a sandbox
from implementation language. Wasm remains a separate capability-constrained
plugin profile if a concrete product need selects it, not compatibility for
arbitrary Node plugins.

## Drizzle strict readiness: exact scope and next disposition

The exact `drizzle-orm@1.0.0-rc.4` public dependency closure fails the selected
TS7.0.2 strict declaration profile with 47 vendor diagnostics after the fixture's
eight constructor mistakes were corrected. Owned source has zero final
diagnostics. The count supports **package/profile readiness failure**, not a
runtime migration failure, PostgreSQL fault, data loss, universal failure of
every Drizzle release/profile, or proof that the source-inferred migration race
occurs. No SR2 runtime was emitted/executed around the gate.

Keep the required gate red. Do not resolve it by weakening compiler flags,
patching vendor declarations, running emitted fragments or silently selecting
another dependency. The owning ADR already permits compatible-GA readiness
review; the inspected stable/newer-RC metadata is a candidate input to that
review, not selection. Stable 0.45.4 and RC4 have different migration
formats/journal semantics, so a strict pass alone would not establish migration
history compatibility. The smallest next readiness action is an owning exact
package/profile decision followed by its strict gate; only then resume the
already prepared real-library SR2 question if it still changes integration.

SR1 is independent; the now root-reported successful isolated native run should
receive its already planned raw-evidence review. On verified success, state the
exact engine/helper provenance and restore boundary;
separate PGDG helpers do not prove the embedded launcher payload includes them.
This critic claims no independent native-pass verification.

## Smallest next implementation and qualification seam

Select one actual product extension family, one trusted extension author task
and the existing canonical receiver/artifact/execution owners. Give it an
immutable profile and downtime-permitted restart. Inspect those actual seams
before estimating a broader platform. Wire a selected artifact into existing
GM composition and readiness, seal acceptance in its real authoritative order,
retain accepted work/attempt/cleanup debt, and let existing custody determine
actual retirement. No new Host abstraction is necessary to make that slice
concrete.

The most valuable missing falsifier is **at the production artifact custody
join**: reuse the PB verify-then-replace witness against the actual claimed
fixed-artifact mechanism. After its receipt, attempt a controlled change to the
selected entry/helper before evaluation; the claimed profile must either prevent
the change or refuse execution without evaluating the substituted bytes. A
fresh PID or matching pre-load hash alone must fail this oracle. This does not
require building a signature loader or hostile-code sandbox; the chosen trust
profile determines which writers the real owner must exclude. It is an actual
integration gate, not a reason for another disposable PB matrix.

At the same slice, apply the already established command-specific absence and
no-acquisition assertions after actual seal completion and retain the real
attempt through readiness/cleanup failure. Do not repeat all resolved fixtures.
If the real custodian cannot prove retirement, preserve occupied capacity/debt
and refuse the incompatible successor according to that product's availability
contract. A new abstract framework cannot supply the missing native fact.

## Bounded alternatives and effort judgments

Scores are engineering judgments, not measured uptime. Reliability is
achievable within the named scope **after its stated qualification**; higher
complexity is more burden. LOC columns are disjoint handwritten additions,
approximately x2 uncertain, and exclude reused engines/GM/custody, provider
business logic, domain schema changes, signing/installers and full OS delivery.
Rows overlap or are incremental; do not sum them into a platform estimate.

| Option and scope | Confidence /10 | Reliability /10 | Complexity /10 | New production/shared mechanism LOC | New product integration LOC | New test/qualification LOC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| First direct controlled-restart slice on existing operation/store/custody | 8 | 9 after real joins qualify | 4 | 0 assumed | 150–500 | 600–1,400 |
| Fixed artifact + fresh process seam within that slice | 9 | 9 conditional on actual custody | 3 | 0–50 if an existing adapter lacks one narrow seam | 80–180 | 200–500 provisional; included within a matching slice scope |
| Optional Temporal adapter above that qualified operation | 8 | 9 within its receiver/custody contract | 5 | 80–220 adapter mechanics | 70–230 incremental | 500–1,100 incremental |
| Neutral residual driver package before a demonstrated shared need | 4 | 7 after qualification | 6 | 100–300 speculative | 100–250 per consumer | 500–1,000 |
| Add universal Host/second supervisor for the measured fixture faults | 3 | 6 for a still-bounded promise | 8 | 800–2,000 speculative | 200–600 | 1,500–3,500 |
| Thin TS connection to an already qualified native custody service, only if real OS need selects it | 8 conditional on availability/fit | 8 within the qualified OS profile | 6 | 300–700 mapping/protocol code | 200–450 integration/release | 800–1,800 |

The native-adapter row does not estimate or authorize developing the keeper;
its required available/qualified service is not claimed. A pure Rust lifecycle
FSM rewrite has confidence 3/10, achievable scoped reliability 7/10 and
complexity 7/10 in the prior language review; its bounded comparison was
600–1,100 Rust plus 250–500 TS production, 350–800 integration/release and
1,500–3,000 test lines, with the same approximate x2 uncertainty. No measured
benefit justifies that increment now. Universal hostile plugins, arbitrary
private-state migration and thousand-active-plugin production capacity have no
honest bounded incremental estimate without a selected workload/contract.

## Final disposition

Integrate the current evidence and proceed to the smallest real product seam.
Complete independent review of the newly reported native restore artifact, keep
Drizzle SR2 blocked until owning readiness is resolved, and retain public and
production guarantees behind
their existing gates. There is no concrete unresolved fixture-level falsifier
that warrants repeating the resolved restart/loading/async cases or creating a
new architecture. The remaining decision-changing work is real artifact custody
and receiver/custodian integration under the first product's explicit trust,
availability and accepted-work contract.
