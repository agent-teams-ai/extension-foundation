# Independent critique of the executed native SR1 restore

Review date:2026-10-26. Reviewed EF commit:`b3c51fc0485cc8c396638a212716bb9497d57652`. [CI run40407349905, job121868432835](https://github.com/agent-teams-ai/extension-foundation/actions/runs/40407349905/job/121868432835). This review used retained source, the original CI artifact ZIP, extracted evidence and the job log. It did not rerun SR1, start a cluster, install/download a dependency or change frozen experiment/source files.

## Disposition

**Accept the observed result as one successful bounded logical backup/restore of the unchanged historical Agent Context feature using this exact native18.4 server plus external18.4 helper/libpq pairing.** No result-invalidating oracle failure, unexpected state contamination or false normal-cleanup claim was found. The selected restore uncertainty is resolved sufficiently to stop this experiment; no repeat or wider matrix is requested.

The successful result is not a production/deployment qualification. It does not qualify whole-product recovery, Temporal/NATS/blob consistency, PITR, arbitrary business rollback, power-loss/corruption behavior, offline/signed installation, hostile plugin isolation or generic process custody. The artifact itself retains `releaseQualification:false` and `supplyChainQualification:false`.

**SR2 remains blocked and unexecuted.** Installing exact Drizzle RC4 as part of the frozen research dependency set does not qualify its declarations or execute its migrator. The existing47-vendor-diagnostic strict readiness blocker remains separate from the SR1 success.

## Evidence identity and source binding

The original ZIP is `validation/native-ci-b3c51fc/artifact.zip`:146,615 bytes, SHA256 `c005c978e670f44d6ac030ad611278c390be89bd0587796d0c4fabad757b3f2d`. This matches the upload digest and size in the retained `job.log`. All52 extracted files match their original ZIP bytes. The job log records checkout of the exact reviewed commit and successful upload of artifact12689974898.

The CI input-integrity log reports the frozen input tar passed its checked-in checksum. Independent read-only inspection found the same1,099,983-byte tar and SHA256 `9ee27beb087e17d946724b98fb4dbd01370350910757dfa6faed4b3da7e90740`. All22 source/lock/config entries in `planning/final-sr1-source-manifest.json` match the tar contents. Bootstrap SHA256 is the pre-run reviewed `7913af0fc912388a39d52a4f10d5d1950981c60dc197a1835ca114a91c0d1d51`. The12 feature files in the tar also match their frozen historical sources byte-for-byte and the retained reuse manifest; the feature boundary remains Orchestrator historical commit`aaabc1e7cd2e2482668530e4412e61c2bca1f515`.

This is source binding through the checked input tar and observed CI command path, not an independent rebuild of PostgreSQL/npm packages or a claim that the current product main was executed.

The earlier`ba5dbdddc70bb457e154175dfe8a1a4f689f8c9c` attempt was a workflow validation failure before any job was scheduled. It produced no native result. The successful commit moves `runner.temp` usage from job-level environment to the two relevant step environments. The experiment input tar is unchanged; the other changed files retain the failure/correction record and research status. There is no evidence of a source/oracle change to obtain this native pass.

## What the retained execution actually establishes

| Boundary | Observed evidence | Assessment |
| --- | --- | --- |
| Strict SR1 source gate | Frozen install records Node26.11.1, pnpm11.18.0, TS7.0.2, pg/@types/pg8.23.1 and @types/node26.6.5. The reviewed shell requires both SR1-only noEmit and build gates before the driver. Both logs are empty, and the shell/driver finish with outer exit0. | Strict SR1 passed without changing its compiler requirements. No combined/SR2 success is inferred. |
| Actual native supplier/version | Native version logs show postgres/initdb/pg_ctl18.4 and PGDG pg_dump/pg_restore/pg_dumpall/psql18.4. Seven driver-recorded executable hashes agree with bootstrap's file-hash manifest. Both running servers independently report PostgreSQL18.4. | This exact native/helper assembly was exercised, rather than an existence-only tool inventory. |
| Fresh distinct cluster after source shutdown | Source PID2592 logs shutdown complete at21:48:16.136UTC and its child-exit event is code0. Target PID2630 starts at21:48:16.895UTC. Source/target system identifiers are`7701096672759187995` and`7701096677183146558`, with separate private roots/sockets and exact checked data directories. | The successful readback cannot be explained by accidentally reading the still-running source or reusing its physical cluster. |
| Retained complete declared archive | `feature.dump` is an8,521-byte `PGDMP` custom archive. TOC identifies the declared database, two feature tables, table data, primary keys, ACLs, enabled RLS and two policies. Source and helper version metadata is18.4. | The selected two-table feature was dumped with no table/data/owner/ACL exclusion. No unmodeled extension/tablespace/product coverage follows. |
| Mandatory failed restore | The first target restore exits1 because `TEST_source_owner` is missing, after the log records `CREATE SCHEMA`. The driver then queries feature namespace/tables and requires absence before proceeding. | This is a real negative control with rollback of the early schema creation. It does not test failures occurring after table data or arbitrary later restore stages. |
| No target repair/state contamination | The target applies retained globals, drops/recreates only its task-owned database, then restores the same archive. Target logs place schema/table/ACL/policy creation in the restore transaction and record COMMIT before validation. The reviewed source invokes no target feature migration, supplemental GRANT or policy repair. | The GRANT/policy statements visible in target logs are expected archive content, not post-restore repairs. The failed-control database is explicitly replaced before positive restore. |
| Actual runtime authority | Both enforcement records show `test_runtime` as session/current user, NOSUPERUSER/NOBYPASSRLS/NOINHERIT, no memberships, and true effective INSERT/UPDATE privileges on both tables. | Privileged owner/bootstrap readback is distinct from runtime enforcement. Source globals legitimately restore the privileged fixture owner; runtime probes do not use it. |
| Direct RLS and WITH CHECK | Runtime SQL sets tenantB and SELECTs both tables without an application tenant predicate, requiring B visibility/A absence. Source and target logs each contain four actual row-security-policy errors for the foreign INSERT/UPDATE probes, with ROLLBACK. Results retain42501 plus RLS-specific messages. DDL produces the separate schema permission denial. | The pre-run ACL-versus-RLS false-pass issue is closed by actual execution, not just by source changes. The adapter-supplied tenant setting remains trusted context, not protection from a caller choosing arbitrary SQL/session tenant identity. |
| Exact state and continuing feature use | Retained source JSON has3 facts/3 outbox rows. Final target JSON has the identical original rows plus exactly one new B manifest and `TEST_event_b_after_restore`. All timestamps retain`1969-12-31 23:59:59.999999`, public facts retain`createdAt:'-1'` and the large string-valued instruction reference, and fingerprints/outbox identities are preserved. | The unchanged feature can read, retry and commit a new manifest/outbox transaction after restore. This is not evidence about dispatching outbox events or arbitrary external effects. |
| Duplicate retries | The driver retries the original immutable seed twice using a deliberately different next-event ID and requires the entire snapshot to remain unchanged before the new seed. Target native logs show the duplicate `INSERT ... ON CONFLICT DO NOTHING` transactions and only the later new seed's outbox INSERT. | Idempotence concerns actual canonical rows/outbox identities in this feature, not just application return values. |

The archive hash independently recomputed from the retained bytes is`8600950a3846de71844af39ab2d397467c8702f378f4fd89ccd6adb94d6793f9`; globals hash is`ec0ff9679342aab783245fb725743d46c2ee3f2a76654f60d0646e58e56f7bcf`. Both equal the driver's recorded pre-restore hashes. Archive bytes contain the three original event identities and contain neither the new after-restore event nor the deliberately forbidden duplicate event. This is supporting evidence that the retained restore input is the pre-restore state.

The older-major PG17 helper control is explicitly **unavailable**, because none was provided. It is not counted as a passed rejection. The mandatory missing-role control did run successfully as an expected failure. The result contains four passed scenario groups and this one unavailable optional control.

## Cleanup and deadline semantics

This run followed normal cleanup. Both postmasters have observed child exit code0, `pg_ctl` stop code0, native shutdown-complete log entries and status3 records. The source has a second status3 observation during final cleanup. The checked source requires exact postmaster PID absence before it marks a cluster stopped. Both registered roots have `removed:true`; the reviewed implementation sets that only after successful awaited recursive removal of the exact owned root following the stop proof.

The outer shell exit is0. All19 retained native events have no termination signal/deadline flag, and results contain no watchdog/deadline/cleanup-error field. Target shutdown completes at21:48:20.737UTC before artifact upload begins. Consequently this result does not depend on emergency group kill or runner teardown to claim normal cleanup.

This is finite evidence for the two known postmasters and two task roots in this run. The reviewer did not inspect a still-live runner filesystem after removal, and there is no independent OS-wide descendant/cgroup/FD/RSS inventory. Initialization-failure cleanup debt, watchdog behavior and external timeout124/137 classification were inspected in source but were not exercised by this successful run. Keep those distinct from the normal cleanup actually observed; no generic complete-custody claim follows.

## Remaining evidence/reporting limits

### 1. The target catalog is asserted at runtime but is not separately retained as raw JSON

`sr1.ts` actually executes `assert.deepEqual(await catalog(restoredOwner), originalCatalog)` before runtime and feature validation. The target log independently records its catalog queries. However, `target-readback.json.originalCatalog` is the **source** catalog copied into the final JSON, not the returned target query result. Comparing that field with `source-expected.json.originalCatalog` proves only equality between two retained copies of the source snapshot.

This does not invalidate the executed catalog assertion because the frozen source, successful control flow and actual target queries are bound to this run. It does require accurate reporting: say **the target catalog equality assertion passed**; do not say two independently retained raw catalog snapshots were compared after the run. The root was notified and accepted this distinction. Do not alter the frozen source or rerun merely to improve raw evidence presentation.

### 2. Native binary provenance is retained; the downloaded binary package payloads are not in this result artifact

The artifact includes the good PGDG signature log, signed InRelease, exact selected package fields, matching signed/selected tuples, downloaded package hashes/control metadata, embedded-server registry/SRI identity, actual executable/library hashes and loader resolution. PGDG package version is exactly`18.4-1.pgdg24.04+1`. The loader records the extracted PGDG libpq for the clients and initdb; the server also uses its declared bundled libraries and runner system libraries.

The result ZIP does not contain the downloaded server tarball, either `.deb` or the resolved native executable/library bytes. Those package hashes are observed CI records, not binary payloads that this reviewer could rehash from this ZIP. Host system shared-library byte identities are also not fully preserved by the package file-hash manifest. Preserve the original input/provenance bundle and supplier identities with the result, and call this **provenance-bound execution**, not a self-contained offline binary reproduction or audited supply-chain qualification. No extra download is requested for this review.

### 3. Existing prepared-state text must remain historical rather than current status

The input metadata legitimately says `nativeExecutionStatus:'not-run'`, and the frozen planning material was written before CI. Do not rewrite those immutable inputs to say they anticipated a pass. The current owning report/synthesis should instead append/link this actual run and its result, while retaining the earlier workflow failure and the separate SR2 strict blocker. Root owns that publication.

## Decision consequence and stop rule

The earlier missing backup/restore evidence for this exact native assembly can now be replaced with a narrower positive statement: **one real historical feature's logical archive plus fixture globals restored successfully into a distinct18.4 cluster after normal source shutdown; exact state, catalog equality, low-privilege RLS enforcement, duplicate-seed idempotence, new outbox transaction and normal owned cleanup passed.** The external helper/libpq family is therefore supported as a candidate for the missing logical-recovery capability in this research profile.

Product backup admission, multi-store consistency, credentials, deployment packaging, restore-point policy and schema/domain compatibility still belong to their existing owners. No accepted ADR, product dependency pin or production package is changed by this result. SR2's strict readiness failure is not repaired by this success.

Engineering judgments within this scope: confidence in the observed limited pass9/10; reliability of the narrow conclusion8/10; experiment complexity3/10. These are evidence judgments, not availability percentages or deployment ratings. New production/product-integration/source code required by this critique:0LOC. Only accurate result documentation/retention is requested; no additional experiment, rerun or implementation is justified by the reviewed evidence.
