# Native PostgreSQL logical restore: source-owner audit of SR1 result

Observation/review date:2026-10-26. **PASS for the selected Linux x64, single-database logical-backup/restore boundary.** A real archive from the unchanged Agent Context feature was restored into a distinct clean native PostgreSQL18.4 cluster after the source had stopped. The retained data, native logs, helper outcomes and reviewed source support this narrower result; a green Actions job alone is not the oracle. **SR2 remains blocked and unexecuted.** No source, published input, earlier report or dependency was changed during this review, and no test/native command was rerun.

I prepared the SR1 source. This is a separate audit of the retained execution artifacts by that source's owner, not a second source-independent reviewer. The independent implementation/result critique is `critic-native-result-independent.md`. The checksum and data comparisons described below were performed independently of the harness's result summary, within this source-owner audit.

## Execution and evidence identity

| Item | Exact identity |
| --- | --- |
| Executed EF commit |`b3c51fc0485cc8c396638a212716bb9497d57652` |
| Actual CI |[Run40407349905](https://github.com/agent-teams-ai/extension-foundation/actions/runs/40407349905), job121868432835, attempt1; recorded run interval2026-10-26T21:47:58Z–21:48:22Z |
| Input archive |`native-state-recovery-20261026-inputs.tar.gz`, SHA256 `9ee27beb087e17d946724b98fb4dbd01370350910757dfa6faed4b3da7e90740` |
| Downloaded output ZIP |146,615 bytes; SHA256 `c005c978e670f44d6ac030ad611278c390be89bd0587796d0c4fabad757b3f2d` |
| Retained output |52 files,571,766 expanded bytes under `validation/native-ci-b3c51fc/artifact/`; raw job log is its sibling `job.log` |
| Frozen driver |`sr1.ts`: SHA256 `6662ffcd07cd69661e34f296e117238a8d59578ba07219c0a01173c141354729` |
| Frozen SQL oracle |`sr1-oracles.ts`: SHA256 `553a8a76e73f77d392b7d1a19ca371b7bec3f788c798b18f1ae9c39889ff5986` |
| Frozen native fixture |`native-fixture.ts`: SHA256 `2795e6dae5bdf97953347f8e7132dc67c228dbc297346779b2610512b1987b0f` |

I rehashed the retained ZIP, logical archive and globals; checked all22 entries in the input archive's final SR1 manifest; and compared those frozen inputs with the reviewed source. I independently compared literal source/target facts, parsed stored fingerprint values, event identities, actual RLS diagnostics, native process/helper results and signed-package tuple binding. This is an artifact/source review, not a second native execution or an independently rebuilt binary distribution.

Primary retained records are `sr1/results.json`, `sr1/source-expected.json`, `sr1/target-readback.json`, both raw server logs, the actual `sr1/feature.dump` and `sr1/globals.sql`, helper logs, native provenance/hash/library records and the raw job log. The repository's published input checksum, retained `input-integrity.log` and checkout/job records bind the executed input archive to the stated commit.

## Exact executed profile and suppliers

The job used Ubuntu24.04.5 on the `ubuntu-24.04` runner image, Linux x64, nonroot Unix UID1001. Its initial disk observation showed91,099,852,800 bytes available. The driver retained the unchanged1GiB available-space guard before initdb. Actual runtime/tool records are Node26.11.1, pnpm11.18.0, TypeScript7.0.2, pg/@types/pg8.23.1 and @types/node26.6.5. The latter differs from other tracks'24.19.1; no byte-identical shared-toolchain claim follows.

Frozen ignore-scripts installation completed with20 packages. SR1-only strict typecheck/build completed with no diagnostics, under strict/exactOptionalPropertyTypes, skipLibCheck:false and noEmitOnError:true. Installation of Drizzle as an unused research dependency does **not** mean that its separately failing declarations passed this SR1 compilation route.

The server supplier was the exact `@embedded-postgres/linux-x64@18.4.0-beta.17` native payload. The actual postmaster SHA256 is `de0a4a7646c51f032e0088ae6fe9d0833fa280b78d4455681574a32937b32838`, matching the earlier measured18.4 engine identity. CI verified its pinned npm sha512 SRI; its downloaded tar SHA256 was `795d587bb466423385db256dc81e61f2ee40c9e10efde21e881f3e997dd1bdb2`. The actual payload's14 declared library aliases were retained and reconstructed only in an owned overlay; package hooks were not executed or vendor bytes edited.

The **separate helper supplier** was PGDG Ubuntu noble/amd64 `postgresql-client-18` and `libpq5`, both `18.4-1.pgdg24.04+1`:

| Asset | Bytes | SHA256 |
| --- | ---: | --- |
| `libpq5_18.4-1.pgdg24.04+1_amd64.deb` |256,172|`632e63bd7e66c3a5a1b539f77dbc76a823f63b9d99fb2ac67bb334c84e4b8a17` |
| `postgresql-client-18_18.4-1.pgdg24.04+1_amd64.deb` |2,095,260|`ff3fb9af478e4bdada47168681d9987917fd3170b043c612d6d01f0c923469c2` |

The native CI `gpgv` log records a good PostgreSQL Debian Repository signature using key `B97B0AFCAA1A47F044F244A07FCC7D46ACCC4CF8`. I independently checked that the retained InRelease equals the frozen input, that its SHA256/size entry binds the904,666-byte Packages.bz2, and that both selected Package/Version/Architecture/Filename/Size/SHA256 tuples equal the records parsed from that index. This goes beyond trusting an unbound selected JSON file. This review did not rerun GPG or verify npm's provenance attestation independently.

All seven actual executable hashes agree between the driver's binary identities and the1,062-entry native file-hash record. Per-executable `ldd` records show no missing library. All five reported libpq resolutions use the selected PGDG library directory. Actual server/query and helper versions are18.4. These facts qualify the measured pairing; **they do not establish that embedded-postgres ships backup helpers or select a production wrapper/helper release matrix**.

## Actual boundary results

### 1. Source facts and enforced runtime scope

The unchanged feature source is the preserved Orchestrator Agent Context boundary at `aaabc1e7cd2e2482668530e4412e61c2bca1f515`, not a newly claimed fresh-main product deployment. Three distinct manifests and their three stable `SandboxManifestCreated` outbox identities were seeded for two synthetic tenants. An additional same-identity source seed produced no fourth row/event.

All three source rows have `createdAt:'-1'`, exact SQL instant `1969-12-31 23:59:59.999999`, and the literal reference `instructions:exact-9007199254740993`. The stored “fingerprint” in this feature is a canonical JSON-array value, not a cryptographic digest; I parsed and compared its components independently. The long numeric-looking reference is text. This run is not a general arbitrary numeric/money codec qualification.

Both source and restored runtime observations identify `session_user=current_user=test_runtime`, NOSUPERUSER, NOBYPASSRLS, NOINHERIT and no role memberships. Four **individual** effective privilege checks confirm INSERT and UPDATE authority on both policy-covered tables. Predicate-free direct SQL sees tenant B's own rows and hides tenant A. Each side then produces four actual RLS-specific foreign INSERT/tenant-changing UPDATE errors across manifests/outbox, followed by rollback and unchanged readback. Ordinary missing privileges therefore cannot masquerade as successful WITH CHECK enforcement. The separate DDL attempt returns schema permission denial.

Raw server logs corroborate **eight RLS-specific errors in total**, four per cluster, and **two separate schema-DDL permission errors**. These are intentional rejecting controls. Trusted transaction-local `app.tenant_id` remains the adapter's scope assumption; the result does not secure arbitrary SQL code that can choose its own tenant setting.

### 2. A retained real archive, then source shutdown

`feature.dump` is8,521 bytes, SHA256 `8600950a3846de71844af39ab2d397467c8702f378f4fd89ccd6adb94d6793f9`. Its actual bytes have the PGDMP custom-archive header; retained TOC identifies format CUSTOM, dump version1.16-0, compression none, PostgreSQL18.4 producer/server and18 TOC entries. The listed objects include both tables and table-data entries, primary keys, ownership/ACLs, both row-security entries and both policies.

I also inspected the uncompressed payload bytes: each of the three original event IDs occurs once, all three negative-microsecond values are present, and the later post-restore event is absent. This was read-only byte inspection; I did not invoke pg_restore again. The682-byte globals file has SHA256 `ec0ff9679342aab783245fb725743d46c2ee3f2a76654f60d0646e58e56f7bcf` and contains the two explicit fixture roles without role passwords.

Source postmaster PID2592 reports a completed fast shutdown at21:48:16.136 UTC and exits0. Only afterward does target PID2630 start at21:48:16.895 UTC. That ordering, different private socket/data paths and different system identifiers rule out accidentally reading the still-live source as the restored target in this scenario:

| Identity | Source | Target |
| --- | --- | --- |
| System identifier |`7701096672759187995`|`7701096677183146558` |
| Private root suffix |`sr1-source-RU9nVm`|`sr1-target-T0UeCp` |
| Actual postmaster PID |2592|2630 |
| fsync / full_page_writes / synchronous_commit |on / on / on|on / on / on |

This is an observed ordering, not a recovery-time benchmark. Source shutdown was graceful; this run did not inject a crash or power loss.

### 3. The mandatory incomplete-restore control rejected

Before globals were applied, real pg_restore attempted the retained archive with owner restoration and a single transaction. It exited1 because `TEST_source_owner` did not exist, specifically at ALTER SCHEMA ownership. The target log shows CREATE SCHEMA was reached before that error, so the control did more than fail before any work began.

An independent bootstrap connection then queried schema/table absence, and the reviewed assertions accepted empty results before globals or clean database recreation. The raw log does not show an explicit SQL ROLLBACK for this failed pg_restore connection; do not claim that statement was observed. The terminating failed restore connection, subsequent absence checks and frozen all-or-nothing oracle support the scoped negative result. It is **not** a corrupt-archive, disk-failure or arbitrary interruption test.

The optional PG17 version-mismatch control is **unavailable**, because no PG17 helper was supplied. It is not counted as passed, skipped into a success percentage or needed to substitute for the executed missing-role control.

### 4. Exact restored state, usable authority and one new transaction

After applying the retained globals and recreating only the clean target database, the identical custom archive restored successfully in one transaction. Actual server logs show its tables, ownership, policies, RLS flags and grants being restored within pg_restore, then COMMIT. There was no separate target feature.migrate(), GRANT or policy-repair step.

The frozen code queried and asserted target catalog equality before running the direct runtime enforcement checks and public feature reads. One evidence-format limit must remain explicit: **`target-readback.json.originalCatalog` is the retained source/expected catalog, not a separately exported target catalog response.** Target equality is supported by the reviewed successful assertion, actual target catalog queries/restoration logs and behavior; do not present that copied field as a second raw target snapshot.

I independently matched all three original manifest rows—including exact facts, stored fingerprints and timestamps—to their corresponding rows in the final target readback. The three original event identities are retained. Two target retries of the original immutable seed append no `TEST_duplicate_must_not_append` event and create no second manifest.

One new tenant-B manifest then commits through the same public feature. Final actual readback contains **four manifests and four corresponding outbox rows**, including exactly one `TEST_event_b_after_restore`. The target native log shows that new manifest/outbox INSERT and COMMIT; there is one successful post-restore application outbox INSERT execution. This proves continued usability of this feature transaction after restore, not delivery of the outbox or an arbitrary external business effect.

## Bounded counts and cleanup evidence

The driver's result contains **four named passed groups plus one explicitly unavailable optional group**. These are scenario groups, not a count of every assertion and not a pass percentage.

| Observed item | Count/result |
| --- | --- |
| Real source/target clusters |2, with distinct roots/system IDs |
| Backup artifacts |1 custom database archive +1 globals file |
| Facts/outbox |3+3 at snapshot;4+4 after the one new target transaction |
| Direct RLS rejections |8 total, separate from2 DDL denials |
| Actual native command-close events |17:13 exit0,3 status-probe exit3,1 expected restore exit1 |
| Actual postmaster exits |2, both code0/signal null |
| Command deadlines/watchdog |Every recorded native command deadline false; no watchdog-use/deadline-failure flag |
| Registered roots |2, both removed:true and no retained debt |
| Source/target server logs |439/405 lines; no FATAL or PANIC; one completed shutdown per cluster |

Both fast stops completed, and pg_ctl returned status3 twice for the source and once for the target. The reviewed source also asserts ESRCH for each exact postmaster PID before removal; root removal flags can become true only after stop proof and successful owned-path rm. The CI result therefore supports normal cleanup **in this fixture**. ESRCH and rm are enforced source assertions rather than independently exported post-run process/filesystem scans; this artifact review cannot observe that former runner's current process namespace. No Supervisor-death, arbitrary descendant, PID-reuse, reference/RSS stabilization or generic custody guarantee follows.

An ordinary PostgreSQL logical-replication launcher background worker reports exit1 during each fast shutdown. That is logged during the shutdown sequence while both postmasters exit0 and complete shutdown; it is not a hidden failed scenario or an injected crash. No unexpected native failure, timeout, value mismatch or cleanup debt appears in the retained run. The outer runner records exit0; the240-second outer termination path was not exercised.

## Actual code cost

Counts below are physical lines including comments/blank lines from the **executed input archive**, excluding generated JS, generated locks, vendor/dependency code and evidence data. The scopes are disjoint; the shared fixture is not counted again under SR2.

| Hand-maintained research scope | Files / lines | Execution status |
| --- | ---: | --- |
| New SR1 driver + SQL oracles |2 TS files /275 lines|Strict-checked and executed in this run |
| New native fixture shared by the proposed tracks |1 TS file /144 lines|SR1 path strict-checked/executed |
| Prepared SR2 driver |1 TS file /212 lines|Retained, blocked and unexecuted |
| Unchanged real feature |12 TS files /209 lines|Reused byte-for-byte; strict-checked and executed through SR1 |
| Portable shell entry |22 lines|Executed |
| Native acquisition shell / workflow |62 shell /74 YAML lines|Executed research setup; not production runtime |
| **New production / product integration** |**0 /0 lines**|No production implementation or admission |

SR1 therefore adds419 TypeScript fixture lines, plus the stated setup/configuration, above209 unchanged feature lines. These are actual disposable research costs, not the estimated cost of a signed multi-platform installer, production restore operation or schema/authority lifecycle.

## Decision and remaining limits

The previous “backup/restore unavailable because the payload lacks helpers” result now has a concrete positive qualification: **the measured native18.4 server plus independently identified matching PGDG18.4 helpers can reconstruct this declared feature database and fixture roles, preserving exact state/outbox/ACL/RLS and continuing ordinary transactions.** Mature PostgreSQL tooling answered the selected uncertainty; no generic backup engine or plugin state framework was needed.

Keep the boundaries separate. This was one Linux x64 run over small, quiescent synthetic data and two fresh private clusters, using test-only trust authentication and explicit privileged bootstrap/migration roles. It does not qualify production credentials/ACLs, wrapper global hooks, signed/offline installation, Windows/macOS, native updates, PITR, corrupted/torn storage, disk exhaustion, backup under active writes, multi-context/Temporal/NATS/blob recovery points, schema downgrade, arbitrary effects, accepted-work handoff or a long-lived Host restart. Configuration `fsync=on` and a logical restore are not power-loss evidence.

SR2's exact-RC4 strict declaration blocker remains red; this SR1-only CI route did not import/qualify its public API declarations or execute its migration scenarios. No alternate Drizzle package was adopted. The accepted static-restart and native PostgreSQL/Temporal decisions remain unchanged. The selected SR1 uncertainty is resolved at the stated boundary; no optional rerun or expanded failure matrix was performed by this reviewer.
