import type {DriverFactory as Current} from "ar-spi";
import type {DriverFactory as External} from "external-spi";
declare const delivered: External;
export const accepted: Current = delivered;
