import type {DriverFactory} from "ar-spi";
declare const current: DriverFactory;
export const accepted: DriverFactory = current;
