import type {DriverFactory as Current} from "ar-spi";
import type {DriverFactory as External} from "external-spi";
declare const current: Current;
export const accepted: External = current;
