# Exact source-contract compatibility evidence

Executed2026-11-06 after Astra plan review and root authorization. This directory is source evidence, **not packed packages, installed provider artifacts, full factory compilation or runtime/Host E2E**.

## Observed outcomes

| Consumer | Exit | Actual compiler result |
| --- | ---: | --- |
| `control.ts`: AR→AR | 0 | Resolution/setup control passes |
| `external-to-ar.ts` | 1 | One TS2322 rooted in external `compaction` event absent from AR event union |
| `ar-to-external.ts` | 1 | One TS2322 rooted in external question-denial reply absent from AR input union |

The11 fixture TS lines contain no cast, suppression, copied SPI or runtime implementation. Source barrels are unchanged. There were exactly three compiler invocations, no dependency installation, no generated production declaration/package and no runtime call. Stop followed the decisive result.

**Product authority limit:** external source is `old-provider-implementations` draft/open PR1, head7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9, which explicitly targets the legacy Desktop extraction and excludes future Runtime/Orchestrator work. It is not established as ADR0091's intended provider delivery. The comparison is exploratory reuse evidence and demonstrates no supported-release failure, intended ADR0091 blocker or instruction to modify/integrate/merge either source. The separately fetched PR body is retained in `external-pr1-observed.json`.

## Provenance

- `source-manifest.json` retains exact git commits/blob IDs/SHA256 for six AR contract-closure files, three external contract-closure files and two factory/facade provenance files. It also records the inspected TS wrapper/package and the resolved native `@typescript/typescript-linux-x64`7.0.2 package/binary SHA256. No compiler version command was run; both exact package manifests identify7.0.2, the wrapper source launches that native compiler, and compiler `listFiles` records its standard-library path. The binary was hashed by read-only inspection.
- `source-snapshots/` contains those11 exact original source files under repository-relative paths; `snapshot-manifest.json` verifies their hashes. The two factory/facade files establish its explicit returned external DriverFactory type; their SDK implementation dependency closure was neither compiled nor executed.
- `results.json` retains Node24.22.1, exact command argument arrays, exit codes, output hashes and compiler-listed file closures. Every compiler call used the same strict, noEmit/skipLibCheck:false/NodeNext/ES2024 settings plus exact optional properties and unchecked-index checking. `types:[]` prevents ambient owner/SDK types.
- Separate stdout/stderr logs are untouched; stdout includes full diagnostics and `listFiles` inventories. stderr is empty in all three outcomes.

## Reproduction constraints

The original configs preserve the absolute research checkout paths used in the actual calls. Reproducing in those paths needs exact AR `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`, exact legacy PR1 `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`, Node24.22.1 and a separately installed/verified TypeScript7.0.2 compiler/native package. Do not silently initialize an older compiler. No source dependency requires an SDK or additional package.

To reproduce elsewhere from this evidence, copy the three configs to a new disposable TEST directory, preserve all compiler settings, change only `paths.ar-spi` and `paths.external-spi` to the corresponding exact source-snapshot barrels, and include the unchanged three consumer files. Record the changed resolution paths and new compiler/platform identity as a new observation, not a replay of these original logs. The AR barrel is `source-snapshots/agent-runtime/packages/contexts/agent-execution/src/interactive-contracts.ts`; the external barrel is `source-snapshots/old-provider-implementations/packages/provider-session-contracts/src/index.ts`. Verify every snapshot hash before use. A new OS/toolchain observation is separate evidence.

The original command shape is `node <verified-typescript>/bin/tsc --project tsconfig.<consumer>.json --pretty false`, with cwd this directory and stdout/stderr captured separately. Repeated source compilation is unnecessary unless a relevant input changes or an independent reviewer identifies a setup defect. No fourth compiler invocation was performed in this investigation.

Independent Astra result review verified all11 source hashes and pins, the setup pass and both semantic TS2322 mismatches. No missing-module/type-dependency error was mistaken for a compatibility result. No package/Host/runtime fallback followed.
