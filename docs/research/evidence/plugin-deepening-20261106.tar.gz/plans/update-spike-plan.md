# Ordinary update policy: reviewed-spike proposal

Date: 2026-11-06 UTC. Status: **proposal; no implementation or execution authorized yet**. Scope: research only. Owner has not selected 2A/2B. This plan neither edits production code nor changes ADR-0009.

## First decide whether an experiment adds evidence

The statement “keep permanent admission closed while unresolved work may last forever” has an immediate liveness consequence: fresh work may remain unavailable forever. No harness is needed to rediscover it. Conversely, waiting for quiescence with admission open can starve an update under continuous arrivals. Neither consequence demonstrates a bug in the current implementation because OD-003 has not specified what “defer” does and no product ordinary-update operation was identified.

**Recommended immediate work:** inspect the existing product owner, classify which current seals are permanent shutdown capabilities, and repair the decision brief's ambiguous policy promise. Reuse RST-01 (queued acceptance vs permanent sealing), RST-02 (candidate cleanup debt) and RST-03 (late result vs actual physical exit), rather than rerunning them. Do not build a generic update manager or an invented product replacement simulation merely to make 2A look green.

## Hypotheses and decision changed

H1. A product-owned reversible *pre-disposal* admission pause, separate from its irreversible shutdown seal, can bound each ordinary-update interruption while preserving accepted work. At deadline it can abandon this attempt, revalidate unchanged healthy authority and resume admission without declaring unresolved operations terminal. This can improve the ordinary update recommendation; it cannot guarantee eventual update completion.

H2. The existing exposed `sealAdmission`/`dispose` lifecycle is a permanent stop boundary and cannot safely be reused as the reversible pause merely by resetting a flag. Source inspection, not a new runtime demo, should settle this unless there is an actual uncertain owner seam.

H3. Reopening only checks fresh admission. It must not replay an unresolved operation, refund its reservation, transfer exclusive custody, or resurrect authority invalidated by cutoff/revocation/disposal. Existing per-operation reconciliation remains authoritative.

Decision the experiment could change: whether a narrow reversible pre-disposal gate at the *actual admission owner* is feasible within the earlier residual integration estimate. A standalone new toy gate does not answer that question. If actual admission/closure/authority readback ports are absent, stop and report that prerequisite; do not manufacture them for a proof.

## Conditional minimal experiment, only after root and independent plan review

One disposable strict TypeScript fixture derived from the existing archived RST-01 receiver and existing real effect-child boundary; preserve original sources and failures. The inherited permanent seal must stay permanent. Add only a narrowly owned attempt pause if the actual owner can expose it without touching its irreversible stop. Do not copy the whole earlier suite.

### Scenario U1: abandonment before disposal

1. Start the real receiver worker; submit operation A before the pause. Hold its existing real effect-child acknowledgement/exit gate so A remains accepted and unresolved. Capture operation-specific canonical receipt, reservation and child identity.
2. Arrange one operation B already queued ahead of the pause and record actual acceptance-order events. Enqueue the pause through the same serialization boundary as real new acceptance. Await actual pause completion, not wall-clock request time.
3. Submit fresh operation C after observed pause completion. Independent parent must see rejection, zero C reservation/launch observations, and absence from a fresh canonical readback. A/B retain their accepted truth.
4. Let the bounded attempt expire without invoking cutoff, cancellation, shutdown or authority transfer. Abandon the attempt, check that authority/head remain unchanged and old service is healthy, then resume only this temporary pause. Submit fresh D: it must execute successfully through the same receiver/process path while A remains unresolved and unchanged. A duplicate submit remains readback, not a second effect.
5. Release/retire only the exact owned effect children, join exit and stdio close, stop the worker with its permanent seal, and read back canonical bytes in a fresh worker. Resource ownership has not been reassigned due to attempt expiry.

### Scenario U2: irreversible boundary refuses reopen

Reuse the same disposable receiver. Begin permanent stop/cutoff using its existing owner; hold physical exit. Attempt the same temporary-pause abandonment/resume action after the permanent boundary. Fresh E must still be rejected, operation-specific reservation/launch counts must remain zero, and fresh readback must show no E. Cancellation/timeout is never accepted as exit evidence. Reuse existing RST-03 for the stronger late-result/unknown-effect claim; do not reimplement it.

## Actual I/O and independent oracle

Use an actual worker/child IPC boundary and synced canonical files from the existing fixture, an actual held effect child, and parent-owned PID/exit/close/absence observations. Independent parent checks the exact accepted IDs, canonical bytes and acquisition/launch events. Assertions cannot rely solely on the gate's boolean/status JSON or final total capacity. Fresh worker readback establishes durable truth only for this file fixture; it is not AR production-storage qualification.

## Negative controls

Run each negative control once; retain its failed desired assertion separately.

- U1-N: leave the reversible pause closed on defer; D acceptance oracle must fail. This qualifies that the availability observation is live.
- U2-N: intentionally permit resume to bypass the permanent seal in a separate mutated fixture; E rejection/absence oracle must fail. No production source is changed.

The existing original unsealed RST-01 counterexample already qualifies the admission rejection oracle; do not rerun it merely for volume. A negative control cannot be silently converted to an expected-failure green aggregate.

## Limits, budget and stop criteria

- No providers, credentials, network contacts, containers, Temporal deployment, production stores or package publication. No new dependencies. Frozen existing Node and TS >=7.0.2; strict own-source compile, no stale output after compile failure.
- Inspection/preparation budget 30 minutes; source delta cap 200 handwritten fixture TS LOC before asking root to reconsider. At most 2 substantive scenario groups + 2 controls, one initial execution and one correction replay only if a concrete fixture defect appears. Whole runtime cap 120 seconds, per child/action cap 10 seconds. Record actual runtime/version/hash/commands/outputs and first failures.
- Stop before coding if implementing the gate requires a new generic manager, fresh custody/store, production redesign, or unsupported public/private imports. Report the actual missing contract instead.
- Cleanup on every path uses exact recorded owned handles/PIDs and task temporary roots; graceful join first, bounded SIGTERM then SIGKILL only for these fixture children, collect exit/close and native absence. Keep cleanup debt explicit if absence is unproven; never kill by name or broad process match. Retain source/logs/canonical observations; remove disposable resource roots only after observation.
- This does not qualify continuous-arrival fairness, crash-safe production attempt recovery, real provider closure, hostile isolation, or bounded wall-clock update success. An infinite-wait theorem is not proved by a finite timeout run.

## Internal review checkpoint

Send this plan to root and `deep_plan_critic`; wait for reviewed go-ahead. Current recommendation is to execute **no new spike** unless actual owner-source inspection reveals uncertainty that this small experiment resolves. The narrower policy recommendation may already be justified by primary-source evidence and the retained RST campaign.

## Review disposition after current-owner inspection

**2026-11-06: independent critic and root agree: no new spike.** Current AR source has no ordinary-update pause/resume or atomic quiescence-and-stop port at the inspected owners. The Host-disposal flag, provider owner seal, and interactive close are permanent shutdown boundaries. Introducing a reversible gate only in the earlier receiver would test a newly invented toy policy, not the actual product seam, and cannot preserve the earlier low integration estimate.

The conditional U1/U2 proposal above is retained as a plan history and is **not authorized to implement**. No code was written, dependencies installed, processes launched, or runtime tests executed for this workstream. Earlier RST evidence is reused as previously scoped, not rerun or promoted to AR qualification.

The simpler candidate is to defer while the service remains active and commit irreversible stop only if the same real admission owner can atomically establish a genuinely quiescent cohort. Quiescence must include durable accepted/pending work, retained live sessions, interactions and cleanup debt; a zero API-call count or idle interactive turn is insufficient. Continuous arrivals and indefinitely open sessions can starve updates under this policy. That is an explicit tradeoff, not a reason to silently cancel work.

ADR-0091 further limits the original scenario: interactive close durably seals and rejects queued undispatched inputs, never reopens a session, and restores conversation only through an explicitly bound checkpoint/new generation. Historical contained-turn queued acceptance B is not proof that interactive B must execute during close. Before any later spike, the owner must identify the actual profile and declare the disposition of idle open sessions and queued inputs.

Reopen experiment planning only after there is a concrete product-owned admission/quiescence seam and a specific unresolved implementation risk. Then retain this plan's independent operation/physical-resource oracles and controls, but adapt the scenarios to the selected profile rather than extending a parallel Host framework.

Independent report review additionally requires any future temporary pause to preserve reply, targeted control, observation and reconciliation paths needed for accepted work to settle; it must not copy an interactive shutdown gate that blocks all scheduled calls. Include a provider-waiting-for-reply witness only if this becomes an actual selected implementation risk.
