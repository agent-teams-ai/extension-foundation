# Seam spike plan — source finding first, optional cross-artifact falsifier

Date: 2026-11-06. Owner: seam research. Status: **Reviewed source-contract addendum executed after root goahead; full packed/Host proposal not executed. No dependencies installed or production source changed.**

## Decision this can change

The prior contained-provider-first 1A recommendation should already be withdrawn on source authority: AR ADR-0091 accepts an additive interactive provider SPI and freezes contained-turn. A spike cannot re-vote that accepted choice or establish that an invented adapter behavior is useful. The only potentially useful residual question is whether the currently accessible external provider artifact can consume that exact SPI and unchanged public Host, or requires an explicit product-owned compatibility correction. A failure must not trigger a new contracts package automatically: ADR-0091 allows extraction only when actual packaging proves the private AR package cannot supply the type dependency, while AR already contains an isolated erased-SPI packed test.

## Source evidence and reuse inventory

Pinned AR: `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`.

- `packages/contexts/agent-execution/tests/package/interactive-contracts-packed-consumer.test.ts` already manually tars/extracts current dist plus manifest outside checkout, strictly compiles a curated SPI consumer, checks empty runtime exports and rejects `ClaudeConfig`. It does not perform package-manager installation/dependency resolution. Repeating it is not a new experiment.
- `packages/apps/embedded-runtime/tests/features/interactive-session-runtime/host.test.ts` exercises actual Host graph, independent wiring oracle, failed cleanup retention, held open/restore races, scoped process lock and restore. It imports internal dist paths and uses its owner fake; it does not join an external provider artifact through package exports.
- `experiments/interactive-provider-contract/test/packed-consumer.test.ts` separately packs the draft Claude experiment and resolves the SDK/CLI. Its contract subpath is draft-contracts; it does not exercise the current production Host.
- Current interactive owner tests already cover late interrupt/callback authority. Do not repeat unchanged C races in this spike.
- External `old-provider-implementations` PR1 head `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9` has its own packed provider consumer, but that consumer targets its separate `@agent-teams/provider-session-contracts`, not AR's contract. It adds EventPayload `compaction`, Input attachments and question-denial replies. Source already identifies a real compatibility gap. PR2 head `076f11c71532e8ebb7530a9272f4de3731232661` is an unmerged OpenCode correction, not current base authority.

**Recommended stop now:** retain the source mismatch, exact open-PR status and package provenance as evidence; do not build a harness simply to get the expected compiler error. Proceed only if cross-review identifies a remaining decision-sensitive uncertainty that the source cannot settle.

## Optional falsifier, if root explicitly authorizes it after cross-review

### Hypotheses

H1: With independently packed exact AR contracts and exact external PR1 provider artifacts, a consumer can assign `createClaudeDriverFactory(...)` to AR `DriverFactory` without casts, suppression, deep imports, source links, or a copied SPI. The independent expected result is rejection if the expanded external Event union can reach AR; a pass would falsify the suspected mismatch and remove one packaging concern.

H2 (only after H1 passes): That same external provider factory can be supplied to unchanged `createInteractiveSessionHost` using only the admitted package exports and a deterministic SDK transport double; one admitted input is handed off once, observed result is attributed through the real owner, and explicit unknown provider cleanup prevents a clean Host disposal until the genuine fixture custody owner supplies closure. This reduces cross-artifact integration uncertainty only. It is not production durability, real authentication, hostile isolation, useful independent variation or release qualification.

### Real boundary and independent oracle

The boundary is installed archives outside every source checkout: current AR erased contract, current AR `@agent-teams/embedded-runtime/composition`, external provider public `./claude`. Artifact identities, package versions, lockfile and compiler resolution are captured. The consumer imports no experiment and no internal/relative source path. Use public option types or `Parameters<typeof createInteractiveSessionHost>[0]` to type the fixture owner inputs; provider code imports only the admitted SPI/its own selected implementation surface. Keep fixture store/authority/custody outside the provider.

The type oracle is current AR's `DriverFactory` declaration, not generated from external provider mappings. Runtime expected observations are separately written: exactly one handoff; SDK consumption means provider acceptance unknown; output cannot make business completion; `cleanup: unknown` plus insufficient independent custody evidence leaves Host disposal rejecting/ownership retained. Never treat a provider cleanup receipt as physical custody proof.

### Negative controls

1. A minimal current-contract fixture factory must compile against the installed AR erased SPI. This distinguishes missing type dependency/exports from real external incompatibility. Its behavior is test instrumentation, not an independently useful plugin.
2. Deliberately access a private package subpath and require `ERR_PACKAGE_PATH_NOT_EXPORTED` (or TypeScript's package-export rejection). If the public package's existing rejecting test already proves the exact unchanged bytes, reuse it instead of executing again.
3. For H2 only, provider completion with unknown cleanup and false custody closure must not produce clean disposal. A counterpart with separately observed fixture cleanup may close. Do not use process absence or a timeout as that observation.

### Scope, budget and stop criteria

Hard cap: one external TEST consumer; at most 350 handwritten TS LOC; TS >=7.0.2 strict only; no production edits, new production API, provider invocation, credential/account lookup, external network effect, new provider selection, compatibility shim or duplicate graph/lifecycle. Reuse existing compiled archives and dependency cache when possible. Budget 30 minutes investigation/build execution and 90 seconds runtime per scenario, <=2 runtime scenarios. No further testing after decisive H1 rejection. Do not execute old TS compiler/parser versions while inspecting package prerequisites.

Stop immediately if artifacts cannot be built under permitted exact toolchain, current external source lineage/authority is unclear, H1 rejects for semantic mismatch, dependencies need unapproved nontrivial migration, or H2 requires importing private factory internals. Record the exact blocker; do not repair it in this research. A failed type assignment is not evidence of the need for a universal host/runtime.

### Resources and cleanup

Only a new canonical mode-0700 TEST directory; no user project, credential source, real SDK process or live provider. H2 deterministic SDK transport uses no network and creates no provider child. Existing real descriptor-lock owner may create a TEST lock; dispose before removing its directory. Preserve redacted artifacts, commands, stdout/stderr and exact hashes; delete disposable installs/processes only after owned closure. Unknown cleanup remains visible rather than deleting its evidence.

### Reporting

Report source-inspected vs newly executed facts separately; retain failure as a useful result. Passing this falsifier cannot promote ADR0091's prospective real-provider/deployment gates. It can only identify a compatibility correction or eliminate one cross-artifact uncertainty.

## Smaller source-contract probe proposed after root review request

Root asked whether a <15-minute source-only falsifier avoids full package/SDK build. It does. No compiled external provider artifact was found in the local workspace; the fresh clone has no `dist`. Its manifest pins TS7.0.2, but installing/building SDK packages is unnecessary for this narrower question.

Use the existing independently installed TS7.0.2 compiler in the EF authoring checkout, inspected as bytes before invocation. A new TEST consumer tsconfig maps two explicit *research-only resolution aliases* to the unchanged AR `src/interactive-contracts.ts` and unchanged external `packages/provider-session-contracts/src/index.ts`. Both have finite dependency-free type closures. No SPI is copied, rewritten or synthesized, and aliases are not product package exports.

AR closure: `src/interactive-contracts.ts`; `features/interactive-agent-session/index.ts`; `contracts/interactive-session.ts`; `contracts/interactive-provider-driver.ts`; `application/ports/outbound/interactive-provider-driver.ts`; `domain/session.ts`. External closure: `src/index.ts`; `features/provider-session-contracts/index.ts`; `contracts/session.ts`. Capture exact git revision, blob SHA and SHA-256 for every file and compiler entry/package before the probe. The actual public `src/claude.ts` facade exports `createClaudeDriverFactory`; its unchanged implementation `adapters/claude-sdk/factory.ts` explicitly returns the same external `DriverFactory`. Retain those sources as provenance; do not claim their full SDK closure was compiled.

Hypothesis: the factory's declared external contract is assignable to current AR's contract. Positive control: AR→AR assignment. Main falsifier: external→AR. Secondary diagnostic: AR→external, to distinguish output-covariance from input/reply contravariance. Write three separate <=8-line `.ts` consumers; run strict `noEmit`, `skipLibCheck:false`, `types:[]`, NodeNext/ES2024 compiler projects with identical settings and no suppressions. Expect main rejection identifying `compaction` output; do not prescribe the compiler's conclusion in the fixture. No runtime code/provider/SDK is imported or invoked, no dependency installed, no Host run, no pack claim.

Independent oracle: actual unchanged current AR type contract, with AR→AR proving the setup. A source-level mismatch is an incompatibility between these exact snapshots, not proof either unmerged/private artifact violates its intended future release contract. A 404 on the originally named provider repository is only the authenticated access observation, not proof that no repository exists.

Stop after the three compiler outcomes and <=15 minutes. No automatic build, compatibility shim, new contracts owner, feature amendment or runtime test follows rejection. If current AR positive control fails or compiler version is below7.0.2, stop with unsupported setup. This is a compiler check of real source declarations, explicitly weaker than exact packed-package consumption. Source-only evidence may be enough to recommend reconciling version/contract provenance before a package/Host spike.

### Executed disposition and independent scope correction

Astra plan review approved this smaller addendum; root then authorized exactly the three source compiler calls. Results: AR→AR exit0, legacy external→AR exit1 (`compaction` event mismatch), AR→legacy external exit1 (question-denial reply mismatch). Full diagnostics and source/compiler hashes are retained under `seam-probe/`. No package/SDK/Host/runtime fallback was attempted.11 TS fixture lines,0 production/integration LOC,0 dependency installations.

Independent update researcher then checked the actual external PR1 body: this is a legacy Desktop-owned extraction, explicitly excluding future Runtime/Orchestrator. That scope was independently fetched and preserved. It is not established as ADR0091's actual delivery target. The diagnostic is therefore an exploratory reuse comparison between exact snapshots, not an intended release defect, an ADR0091 blocker, or justification to patch either contract or integrate/merge the legacy PR. The full original H1/H2 proposal above remains historical plan reasoning, not authority for further execution.
