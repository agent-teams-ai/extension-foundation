# Deepening plugin choices — common owner context, 2026-11-06

## Current owner request
Think much deeper about the pending forks; use source-backed industry experience, good/bad patterns, experiments if they can change the choice, and independent critics on the strongest models at xhigh. Produce the best justified recommendation for a reliable, powerful, extensible plugin system. User has NOT selected 1A/B/C or2A/B. Research/criticism/spikes must remain evidence, not adoption.
Previous explicit instructions remain: many researchers/critics in waves, critique experiment plans before implementation, realistic minimal falsifiers, no speculative platform and no pointless tests; preserve all findings, source dates/versions/limits/counterevidence; commit and push research checkpoints to continuing EF draft PR55. No merge authorized. Do not implement an unresolved production architecture. Scores for options: reliability/confidence/complexity /10 and separate new/changed production/integration/test LOC with actual prerequisites and uncertainty.

## Owner vision
Hundreds/thousands of modules and user plugins, deep customization without forking, reliable maintainable extensibility, independent responsibilities, convenient authorship. Clean Architecture, SOLID, DRY, actual DDD, pluggable/modular, no overengineering. Mature reuse before inventing mechanics. TS primary; native/Rust only a named demonstrated benefit with all deployment costs. Preserve existing native/process custody. Static composition and controlled restart confirmed; optional Temporal adapter to SAME owned operation when qualified and justified. No hidden universal manager, service locator, duplicate graph/lifecycle authority. No feature flags by default. New maintained JS-runtime code/tests/tooling .ts with TS7.0.2+ strict typechecking; never initialize old TS5.9.x. Explicitly distinguish source inspection, proposed experiments, actual execution, and product/release qualification.

## Current source authority freshly verified at 2026-11-06 20:32 UTC
EF PR55 open DRAFT head99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d, branch docs/plugin-research-hot-reload-20261021, main/base29ae5b0269d9d83f071344e3e18761ded04ff53d.
GM main5fb83478dd7b95216be92c4d3077eddf2774eef8.
Orchestrator maina34587b313e656eeb43d755b4a4f08c40dff2116.
Agent Runtime mainf990acc26e1b8071ae22d0b87a2ddd3672be8e2e.
Common quality standard blob9d4fc54d99249077bf6887be35a59ace1d5547bd (unchanged), full local snapshot at prior task quality-standard.md below.
Previous head99 full local Docs8/8 and hostedDocs8/8 passed, generalCI42268706990 nowsuccess. No test/runtime source was changed in that decision-preparation commit.

## Already fixed, not new votes
GM neutral declarations/bindings/graph/immutableplan/construction. GMResources accepted cooperativecleanup mechanism; executionowner retains actualresource/physicalcustody. GMADR0030 supersedes oldownership/K1/two-scopegates; don'trevive. GMlifecyclekernelADR0029 privatecandidate localbookkeeping only, not released asyncHost.
EF neutral artifact/trust/distribution/protocol/conformance; product-specific payloads/SPIs and operational authority remain products. EFADR0011 conditional admittedHostfloor excludesordinarylibraries/staticDI/GMconstruction, cannot invent installations for ordinarymodules.
EFADR0014 authoring/generationguardrails, ADR0015 independentGM. Productreadiness/grants/desiredprofile/state/recovery and executioncustodykeepowners. Ordinarypluginscan'treplaceauthorization,invariants,canonicalstate,fencing,enforcement.
Orchestrator ADR0114 nativePostgreSQLallprofiles; ADR0115 FullyLocalV1 bundledembedded-postgreslauncher/exactbundlequalification; ADR0116 nativefullTemporal+PostgreSQLacceptedonmergedmain, no enginefallback, releasegatesremain; ADR0117 currentGMadoption.
Catalog topology alreadyresolvedinEF: explicit authorityroute, PostgreSQLcanonicalperwritablesource,digest-pinnedOCI; nocatalogmerge/fallback. Exactkey/freshness/offlineoperatingparametersaredependentopenchoices.
Staticcontrolledrestart mayhavedowntime; noautomaticoverlap/statefulhotswap/publicSPIapproval. Temporalapplicationenginechoice!=optionalpluginrolloutscheduler.

## Pending brief being challenged
Read full EF OD003 newdatedownerbrief before judging.
1A preferred conditionally: curated trusted variation of existing ARproviderfamily; real useful behavior+realconsumer, independentbehavior-bearingadapter, noforkapplication/kernel/custody. P900–1800/I450–900/T1400–2800,R8/C6/X5.
1B namednewprovider; P2000–5000/I900–1800/T3000–6000,R7/C5/X7; includes1Aseam; vendor/missinginfrastructureoutside.
1C protectedoperationalHostDiscovery; P700–1500/I500–1100/T1200–2500,R8/C6/X5. Privilegedbootstrapinfra, notordinarycommunityplugin.
2A preferred ordinaryupdatepolicy: closeadmissioninaffectedscope, letboundedacceptedturnsfinishnaturally, deferifunknown; thenexistingdisposal. SharedP0/I150–350/T500–1100,R8/C7/X4.
2B grace thenexistingauthorizedcancellation/cutoff, waitrealclosure/reconciliationbefore restart. P0/I250–550/T800–1600,R8/C6/X5.
Estimates customizeexistingbase, NOT totalproductionrelease;2overlaps1integration+earlierrestartallowance. No fakeadditiveplatformquote.
Potential problem to investigate independently: seal-and-wait+defer might leave oldservice permanently unavailable; cancellationreceipt!=physicalclosure; failedreadiness/candidatecleanup/stalework/lateeffects/privatelibraryexport constraints. Don't designcounterexamplejusttofitrootintuition. A betterordinaryupdatepolicycan be proposedbutnotadopted. Freshnormalarrivalvsqueuedacceptedworkandracebarriersmatter; no unsafe reopen after cutoff/revocation/disposal.

## AR concrete facts (do not overstate)
ContainedTurnKernelProviderPort.execute exists. Private composition exactcodex|claude, ownfactories/sevencolsdeps, notuserSPI. Product-controlledtrustedadaptercontract stillneeded. Currentregistry Docker/LinuxCodex row qualification='implementation' only: NOlivekernelroute/providerturn/container/network/credential/origin, missingproductionids/resolver/evidencebroker-sessionowners. Claude outrightrefused claude-broker-seam-absent, notcuredbyregistryrow. FeatureREADME cancellation/outputparitygaps remain.
ARADR0009 actualHostdisposal already sealsadmission, requestsdurablecutoffforeveryinscopenonterminalop, containment, observationsdrain,custody/receipt-governedrelease. Waitpolicycanprecededisposal; cannotredefineactualshutdownaswaitonly. ADR0010 unknown ->reconcile_required notsuccess/retry.
Ordinaryuser-sessionCodexprofile is separatelyowned; don'tassumecontainedprofile iswholeARdefault/readiness. Inspectcurrentauthorityifrecommendationneedsit.
No realprovider/account/secret/APIcalls withoutneededexplicit scope; disposable testprojects only.

## Evidence bounds
ExistingpackedpublicconsumerE2E:10scenarios×4OS/Nodeprofiles,433fixtureTSLOC,0production/integration; realpublicHostDiscoverySourceport throughprivateproductpackage, independentfixtureadapter/helper andGM0.5. Nooperationalconnector/Host, artifactcustody, hostileisolation, actualrestart, UIorproductionfleetproof.
Previousstatic/boundarycampaign includes failedreceiverseal and separatelycorrectedqueuedseal, nativePostgreslogicalrestore, realTemporalworker/servicecrash/receiptfencing, supportedN1000graphrecipe andindustryscoped1024receivers. Reuseexactevidence, don'trepeatunchangedtests orclaimthousandsactiveplugins.
Latestindustryresearch14cases,152sourceIDrecords+3movingdocs,6critiques/4critics: GoogleADK,PydanticAI,MicrosoftAgentFramework,Mastra,ElizaOS,LettaCode;Pluggy,PF4J,Fastify/Avvio,Hapi,Nest,Drupal;OTelCollector/APISIX. Source/upstreamtestinspectiononly; reportsfrozen. EarlierNGINX/Envoy/VSCode/etcstudyexists; lookforunresolvedcontractratherthanrepeatbroadsurvey.

## Paths and workflow
LatestcleanEFcheckout: /workspace/scratch/f863b9d38368/plugin-decision-brief-2026-11-06/authoring (head99; frozenNode24.22.1/pnpm11.25, strictTS7.0.2 installed).
Full previousbrief/reports/quality: /workspace/scratch/f863b9d38368/plugin-decision-brief-2026-11-06/{brief.md,quality-standard.md,reports/}.
Long researchreports: /workspace/scratch/f863b9d38368/plugin-modularity-research-2026-11-05/reports/
GM/Orchestratorclones: /workspace/scratch/f863b9d38368/plugin-industry-2026-11-05/repos/{get-modular,agent-teams-orchestrator}; usepins/freshfetch;ARnotyetlocal.
Packedexperiment: /workspace/scratch/f863b9d38368/plugin-e2e-2026-11-05/experiment.
DoNOTeditoriginalEFclone or oldpublication tool-ownedtemp/failedtransaction. Root aloneownsgovernedEFdocs/publishing. ReadrepoAGENTS+DocsProtocol+qualitybeforegovernedchanges.
ghabsent; GitHubconnector authorizedrouteavailable. Tools viaALL_TOOLS. Primarysources only for technicalclaims; exactpinsdates+movingdocstatus. Searchwebforcurrent/nichefacts.
New taskroot: /workspace/scratch/f863b9d38368/plugin-decision-deepening-2026-11-06.
Writeyourfilesonlyinyourassignedsubdirorownreport. No productionedits, commits,pushes,releases, or newdepswithoutrootcoordination.
For neededspikes: FIRST writeplanwithhypothesis/decisionitcanchange,real boundary,independentoracle,negativecontrol,scope/reuse,stopcriteria,resourcecleanup,executionbudget. Askrootforinternalplanreview,notuserpermission. Waitforroot'sreviewedgoaheadbeforeexecutingorbuildingcomplexharness. Thisdoesnotmeanaskuseragain.
Smallfalsifiersarenotautomaticallybacklog. Ifsourceevidencealreadysettlesquestion,noextraexperiment. Do not overengineertransaction/Hostframeworktodemoaproperty.

## Deliverables
Sourcebackedfindings, alternatives, counterevidence, concretecritiqueofearlierrecommendation, smallestusefulspikeplan. Afterreview executeonlyauthorized bounded disposable experiment, retainexactsource/input/runtime/output/failures+limits.
No claim 'best in world' withoutcomparables; optimizeownergoalswithdemonstrableguarantees. Scoresconditional, separateconfidenceincontractvsestimate, honestunknownwholecost. Furthermaterialownerchoicesremainproposed.
