# Independent architecture and experiment critique

Date: 2026-11-06 UTC. Scope: read-only authority/source review and experiment-plan criticism. No production implementation, accepted-decision edit, package publication, commit or push was performed by this critic. New maintained JavaScript-runtime source/tests: zero.

## Verdict after the second authority pass

**Withdraw the earlier preference for a new contained-turn provider variation. Align the evidence work with the already accepted interactive Claude/session extraction in AR ADR-0091. Do not manufacture a fourth owner option.** The prior owner packet and all three previous reviews omitted a material accepted decision that was already present at the exact AR commit they cited, `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`. This is a research correction, not a newly changed upstream decision. [AR91]

ADR-0091 explicitly says the owner-directed A–F plan selects persistent Claude sessions, a runtime-owned consumer SPI, an ordinary external implementation library, Orchestrator-owned product tools and later desktop integration. It explicitly freezes contained-turn and forbids widening the ordinary Codex contract to achieve that path. Current modular research repeats that the conditional harness shortlist must not reopen or replace the accepted interactive path. The previous 1A could remain a hypothetical future independently justified capability, but it is a poor current recommendation and must not become authorized implementation by inertia. [AR91, ARMOD]

The ordinary-update recommendation also needs repair. **The recorded 2A is underspecified for service availability and inapplicable without refinement to persistent interactive sessions.** It preserves no-premature-retirement safety, but permanent sealing plus indefinite unresolved work can leave the old service unable to accept fresh work indefinitely. An ordinary update should not accidentally create that promise. This is a direct consequence of the policy, not an experimentally discovered implementation bug. Actual disposal and close remain irreversible and retain the existing operation/custody obligations. [OD3, AR9, AR91]

**Experiment disposition:** approve source-only update-policy correction and reuse retained RST evidence; do not execute a new update simulation by default. A small isolated packed-consumer spike at the actual interactive public contract can be useful because ADR-0091 explicitly makes that packaging boundary decision-relevant. Its exact plan must pass review below before execution.

## 1. What the prior packet got right, and where its inference failed

The three prior reports were careful about source inspection versus execution, current contained-route qualification, private versus public contracts, GM/EF/product ownership, shutdown truth, nonadditive LOC and public-SPI gates. Those distinctions should be retained. In particular, they did not claim that external packaging alone supplies user value, that Claude was already a usable contained provider, or that an expired deadline proves physical cleanup.

Their shared error was **selection bias in the source inventory**. They studied the old contained provider port and exact Codex/Claude composition deeply but did not reconcile that candidate against the already accepted successor product journey. Therefore their conditional recommendation had strong local boundary reasoning but an incomplete architecture premise. Agreement among three critics did not cure a shared omission.

The earlier 1A/1B/1C table mixes three unlike scopes: variation within an old contained path, a new unspecified vendor, and privileged discovery infrastructure. These are not substitutes for the owner-selected persistent Claude/session work. The current accepted journey already has the useful behavior and authoring direction that the previous packet asked the owner to name. The remaining research question is whether its actual boundary, packaging and failure semantics can support that journey as promised.

Two additional controls belong in any future product comparison:

- If a desired variation is expressible by current immutable configuration or ordinary product composition, extracting another plugin contract can be unnecessary. No-fork customization is the outcome; independent packaging is one possible delivery mechanism.
- If the desired variation is independent distribution, permissions or an external author compatibility promise, static trusted source substitution is only partial delivery. A curated type contract cannot be marketed as an untrusted plugin ecosystem.

Neither control reopens ADR-0091. They prevent future generic recommendations from using an impressive seam as a surrogate for a requested outcome.

## 2. Correct owner and repository implications of ADR-0091

The accepted owner is Agent Execution for runtime session/generation semantics, admission, durable observations, interactions, control and recovery. Orchestrator keeps product work, tools, approvals and retry/completion meaning. Embedded Runtime selects the concrete factory at composition. The implementation package imports the runtime contract subpath **as types only**; Agent Execution does not import the implementation. [AR91]

The exact existing source supports this narrow arrangement:

- `@agent-teams/agent-execution/interactive-contracts` is an admitted curated subpath. `src/interactive-contracts.ts` contains erased type exports for `DriverFactory`, `Session`, `OpenConfig`, events and receipts.
- `DriverFactory.open` returns a session driver and capability list. The session's operations distinguish handoff, observation, targeted interruption, readiness, checkpoint and close. Handoff explicitly records client consumption with unknown provider acceptance; interruption returns a request with unconfirmed terminal status.
- The driver close receipt separates logical closure from `cleanup: confirmed | unknown`. The owning session dependencies have a distinct custody port for output drain, resources stopped and exact-generation owner closure. A third-party driver cannot acquire that custody authority merely by returning `confirmed`.
- The package remains `private: true` at version `0.0.0`. Publicly named exports are not publication, independent installation or release qualification. Current readiness still says the interactive contract has no qualified implementation/Host/real-credential/deployment tuple. Current source presence and that qualification state must both be reported. [ARCONTRACT, ARPORTS, ARPKG, ARREADY]

ADR-0091 already names the planned `agent-teams-ai/provider-implementations` repository, package `@agent-teams/provider-implementations`, and concrete `./claude` factory. A missing or differently named repository is a delivery/status issue; it does not create a new architectural owner vote, authorize a new neutral Host repository, or prove the contracts must move to EF/GM.

The same ADR explicitly provides a contingency: **only if isolated packaging proves that the private runtime package cannot supply the type dependency**, extract the runtime-owned contract into a separately packed contracts package. That is a narrowly permitted delivery adjustment under the same semantic owner. Do not preempt this test by creating a new contracts package, republishing private internals, bundling copied declaration sources under an invented manifest, or choosing another provider.

Repository location, package distribution and runtime authority are distinct. No new shared mechanism has been demonstrated by this inventory. The accepted GM mechanisms and existing process/native custody remain in place. A shared test kit can be considered for an actual shared contract; a second manager, registry, lifecycle authority or scheduler is unsupported.

## 3. Update policy: safety and availability are different promises

The old 2A offers sealing, natural completion and indefinite deferral without specifying whether fresh requests can return to the old implementation. Four policies expose the real tradeoffs:

| Policy | Preserved promise | Limitation or missing prerequisite |
| --- | --- | --- |
| Defer while the existing generation keeps serving; commit stop only at an owner-proved quiescent boundary | An unready ordinary update does not create an indefinite outage | Update may starve under continuous use. Observation of zero active calls followed by a separate stop is a race. |
| Permanently seal, wait for natural closure | No new accepted cohort can extend that drain | One unresolved operation/session/debt can keep fresh work unavailable indefinitely. This is an explicit maintenance mode, not a harmless deferred update. |
| Bounded reversible pause before disposal, then abandon and resume if still authorized | Each attempted drain can have a bounded admission interruption | Requires a real reversible gate at the actual admission owner, distinct from permanent close. No such API may be invented or assumed from `dispose`. Eventual update completion remains unbounded. |
| Grace, then existing authorized cutoff/close | Bounded initiation of interruption under owner policy | Neither control acknowledgement nor process termination guarantees operation/effect/closure truth. Successful update time can remain unbounded. |

The first policy is the simplest availability-preserving candidate when the actual owner can atomically check quiescence and commit stop. It does not require a reversible lifecycle. It must include accepted durable queue entries, unresolved handoffs, open sessions and cleanup debt in its exact definition of quiescence. A call counter alone is insufficient. This recommendation is reasoning about a proposed product policy; source inspection has not established that the necessary atomic operation already exists.

The third policy is not automatically better. A new reversible gate has costs and races. Reopening is permitted only before permanent cutoff, close, disposal, revocation or authority transfer, under unchanged generation/head and fresh valid authority, with the same owners and reservations still held. It admits only new work; it never replays an unknown operation, refunds occupied capacity, clears reconciliation debt or restores a cancelled operation's callback authority. A stale deadline callback cannot reopen a newer attempt. If any condition is unknown, retain typed unavailability/reconciliation.

Current source makes the distinction concrete. The old `AgentRuntimeHostDisposalLifecycle` has `assertActive`, `dispose`, `isDisposed`, call tracking and cancellation operations, but no temporary pause or reopen. `dispose` sets `#disposed = true` before abort and cancellation; a rejected bounded wait does not reset it. The interactive Host similarly sets `closing = true`, joins pending attempts, then cleans up owned sessions; a rejected cleanup clears its retry Promise, not its closing state. These are permanent lifecycle boundaries and cannot serve as ordinary reversible deferral by resetting a field. [ARDISPOSE, ARHOST]

ADR-0009 remains authoritative for the contained Host: disposal requests durable cutoffs and follows containment, drain and custody/receipt truth. ADR-0091 adds the corresponding interactive semantics: close durably seals, rejects queued undispatched inputs, invalidates interactions, joins close calls and retains cleanup debt. **The queued-work oracle is profile-specific.** Historical contained-request RST expectations cannot be copied into an interactive test that should reject queued undispatched inputs on close. [AR9, AR91]

Persistent sessions also change the meaning of “bounded turn.” A naturally finished turn can leave a live session, pending conversation context and provider resources. Closing an idle session or reconstructing one later is not transparent continuation. Restore is explicit, bound to exact engine/codec/config/workspace/account/checkpoint identity, produces a new generation and restores no callback authority or filesystem/effect truth. Do not promise automatic update-resume using existing checkpoint APIs without a product promise and applicable evidence. [AR91]

Finally, “affected scope” must mean the actual process/dependency/resource closure that will restart. A static adapter inside one owning Host may require that Host's dependent capabilities to stop. Restricting the word “scope” to one plugin ID does not create isolated restart capability. No new overlap requirement follows; downtime is already allowed.

## 4. Narrow industry cross-check and its limits

NGINX's documented configuration reload validates/applies the candidate before replacing workers, and keeps the prior configuration if this preparation fails. Its old workers stop taking new connections and finish existing clients after replacement workers start. The useful lesson is to preserve the old serving path before an irreversible transition and to distinguish admission from drain. Its overlap/socket/worker design is not proof that arbitrary plugin sessions or effects can be handed over, and overlap is not selected here. [NGINX]

Envoy 1.40.2 documents that graceful draining may discourage requests while continuing to accept connections for a period; immediate listener stop and process shutdown are separate actions. Support also depends on the protocol/filter. This is counterevidence to a universal interpretation of “graceful drain.” No Envoy run was performed and its connection semantics do not establish AR operation closure. [ENVOY]

Both references are documentation inspected on 2026-11-06. The NGINX page is moving documentation; the Envoy page is versioned documentation, not an immutable source commit. They reinforce the conceptual separation already evident in AR authority, rather than justify importing a new runtime or deployment matrix.

## 5. Plan review: update spike

Reviewed `plans/update-spike-plan.md`, initially titled “Ordinary update policy: reviewed-spike proposal.”

**Disposition: approve its default of no new execution.** H1/H2/H3 identify genuine policy questions, and its real worker/effect-child, canonical readback and adversarial controls would be preferable to an in-memory boolean demo. However, an inherited RST receiver is not the actual AR interactive admission owner. Adding a new gate there would prove a constructed gate, not validate the small residual AR implementation estimate. Source evidence already proves permanent close cannot be used as reversible pause, while the indefinite liveness consequence requires no measurement.

Conditional U1/U2 should run only if a newly identified actual owner API uncertainty can change the decision. Before then they remain deferred proposals, not a backlog or authorization to build. Specific corrections communicated to the author:

1. Preserve the one-way real seal; never create reopen by resetting disposal state.
2. Distinguish queued accepted requests in the historical RST fixture from ADR-0091 queued interactive inputs, whose close disposition is rejection.
3. Include durable pending acceptance/handoff/session/debt, not just executing work, in the relevant quiescence claim.
4. Prefer inspecting an atomic defer-before-seal option before creating a reversible pause.
5. Retain first failures and controls separately; no clock-based assertion can prove an infinite liveness claim.

The plan's 200-new-TS-line cap, no-dependency rule, one runtime profile, two scenario groups and exact owned-child cleanup are reasonable upper bounds if that missing trigger is later demonstrated. They are not a reason to run it now.

## 6. Required test quality for the interactive packing spike

The smallest useful hypothesis is: **the existing curated contract and real product consumer can be consumed outside the repository from authentic package artifacts without a sibling checkout, private imports or a runtime dependency cycle**. Failure may trigger ADR-0091's already allowed contracts-package adjustment, reveal an actual release prerequisite, or narrow claims about independent provider authorship.

Minimum review requirements for the forthcoming plan:

- Use the exact existing contract export and unchanged real interactive factory/Host boundary. A copied shape plus a homemade consumer is not evidence.
- Build an external adapter independently against installed types. Keep its runtime code independent of AR/GM/internal types and vendor SDK objects. Prove the consumer path resolves installed artifacts rather than workspace paths or a hidden symlink.
- Keep the isolated artifact and command census exact. If ordinary package installation is impossible without private prerequisites, record that concrete failure before considering a permitted narrower experiment. Do not silently synthesize a successful production package from selected files.
- Establish at least one meaningful behavior with an independent observable owner result. Packaging alone is valid packing evidence; it is not end-user value. A fake provider's marker echoed by a fake consumer proves almost nothing.
- One negative control should invalidate the particular claimed boundary: omit the curated export/type dependency for the packaging hypothesis, or return misleading cleanup/handoff observations for the owner-semantics hypothesis. The independent oracle must fail in the expected place.
- Synthetic provider close success must not supply the independent custody fact under test. Keep custody held/unknown and check actual owner retention/readback before release, or restrict the claim to packaging only.
- Reject runtime execution if strict TS 7.0.2+ fails; no old embedded compiler, stale output, `any`/double-cast escape or `skipLibCheck` workaround may be used to claim full strict compatibility.
- Reuse existing synthetic store/owner fixtures where possible; no credentials, live providers, new DB/service deployment or broad OS/version matrix. One relevant profile is sufficient for this boundary falsifier.

The approved synthetic exercise cannot prove the useful Claude implementation exists, public compatibility is stable, arbitrary third-party code is contained, migration works or a deployment is ready. It can nevertheless change an actual delivery decision because ADR-0091 explicitly depends on this packaging boundary.

## 7. Estimates, scores and publication wording

The prior 1A/1B estimates must not be transferred to the interactive path. Persistent sessions, durable queues, independent replies, exact targeted interruption, output cursors, restore and per-session cleanup are materially different semantics. Existing implemented source must be inventoried before estimating residual work; neither the total existing LOC nor the old contained adapter byte count is new implementation cost. Missing provider delivery, current package distribution, real credential/custody and actual integration remain separate prerequisites.

Confidence should be split into confidence in the accepted direction and confidence in residual delivery sizing. This review has high confidence that ADR-0091 selects the direction, and low confidence in a total delivery estimate before the external artifact and missing-owner inventory. The earlier numerical reliability rating was scoped to a correctness promise; it should not be reused as an availability score for 2A or as a score for persistent sessions.

The current research can refine or correct EF's open brief and preserve these findings. It cannot change AR accepted decisions, complete A–F production implementation, authorize publication, merge research, or convert synthetic evidence into product qualification. Remaining owner questions should name an actual unresolved promise—such as acceptable ordinary-update disruption for persistent sessions—after checking whether the existing A–F plan already resolves it. Repository materialization and proof obligations are not automatically owner architecture choices.

## Primary sources and provenance

- [OD3] EF OD-003, local `authoring` at `99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d`: <https://github.com/agent-teams-ai/extension-foundation/blob/99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md>.
- [AR91] Full accepted ADR-0091, independently read at verified checkout `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md>.
- [AR9] Accepted ADR-0009, freshly fetched through the GitHub connector at the same pin: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0009-contained-turn-private-access-and-host-shutdown-boundary.md>.
- [ARMOD] Current modular research, including explicit reconciliation with ADR-0091: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/agent-runtime-modular-research.md>.
- [ARREADY] Current qualification state: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/readiness.md>.
- [ARCONTRACT] Actual interactive driver contract: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/interactive-agent-session/application/ports/outbound/interactive-provider-driver.ts>.
- [ARPORTS] Distinct store, driver, authorization and custody dependencies: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/interactive-agent-session/application/ports/outbound/interactive-session-ports.ts>.
- [ARPKG] Actual private package manifest and curated exports: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/package.json>.
- [ARDISPOSE] Existing irreversible contained/ordinary Host disposal: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/agent-runtime-host-disposal.ts>.
- [ARHOST] Existing interactive Host admission and disposal: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/features/interactive-session-runtime/application/use-cases/create-session-host.ts>.
- [NGINX] Official moving documentation, inspected 2026-11-06: <https://nginx.org/en/docs/control.html>.
- [ENVOY] Official versioned 1.40.2 documentation, inspected 2026-11-06: <https://www.envoyproxy.io/docs/envoy/v1.40.2/intro/arch_overview/operations/draining>.

Previous reviewed reports: `plugin-decision-brief-2026-11-06/reports/{authority-audit,product-options,mechanism-critique,review-dispositions}.md`. They are retained historical evidence and were not edited. This report supersedes their current recommendation only where explicitly explained above; it does not erase valid findings or their source/experiment limitations.

## Subsequent plan and result reviews

### Interactive seam plan: initial review and narrowed approval

Reviewed `plans/seam-spike-plan.md` and its later source-contract addendum, then independently inspected the exact AR erased SPI, current AR erased-SPI packed test, external contract and Claude factory annotation. External checkout is exact `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`, the inspected PR1 head of `agent-teams-ai/old-provider-implementations`, not a merged/published delivery. Its `provenance/source-extraction.json` names donor AR `4e37051ed390da84842eb27535c8e9b07a0364b7` and two copied source packages. Its README explicitly keeps consumers responsible for configuration, transports, custody, durable intents/checkpoints, tools and credentials; it does not claim upstream engine authority or live qualification.

The initially proposed packed H1 followed by real Host H2 is **not approved for execution in this review**. The current AR repository already contains an isolated erased-SPI packed test, so repeating that unchanged test adds little. Building the full external SDK/product closure only to expose a visible contract divergence would exceed the useful scope. Full cross-artifact Host behavior remains useful later after compatible exact artifacts exist, but is not needed to identify the current blocker.

**Approved smaller diagnostic:** a strict TypeScript 7.0.2 `noEmit` assignability probe using the exact unmodified source export closures: current AR public source barrel and the external provider-session-contracts public source barrel. The external public Claude factory explicitly declares the latter `DriverFactory` as its return type; retain its facade/signature provenance, but do not claim to compile its SDK implementation. Three tiny consumers are sufficient: AR-to-AR setup control, external-to-AR primary falsifier and AR-to-external directional diagnostic. Budget is 15 minutes, no dependency upgrade, source/interface rewriting, generated shim, SDK/runtime execution, new production API or full matrix. Stop after the decisive diagnostics.

This probe is worthwhile for a narrow reason. Optional additional input fields do not by themselves demonstrate failure of structural substitution, while a new observable event member can invalidate the returned driver contract. The compiler can identify which concrete promises fail in each direction. The AR-to-AR control proves the selected source/standard-library/compiler setup resolves; it is not independent semantic evidence. The reverse direction is not evidence that the old driver supplies all advertised new capabilities.

This is **source-contract compatibility evidence only**. It does not establish public npm installation, exact packed declarations, complete factory implementation correctness, a runtime Host journey, or a need for a contracts-package extraction. A rejected candidate pair does not prove a defect in an already supported release. These source branches must first be reconciled with the owning plan and exact intended delivery. Neither package relocation nor a cast/shim can repair semantic disagreement by itself.

Primary additional sources:

- External factory return annotation: <https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-implementations/src/features/provider-session-implementation/adapters/claude-sdk/factory.ts>.
- External contract: <https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-session-contracts/src/features/provider-session-contracts/contracts/session.ts>.
- Extraction source record: <https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/provenance/source-extraction.json>.
- Existing AR erased-SPI package test, inspected but not rerun: <https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/tests/package/interactive-contracts-packed-consumer.test.ts>.

The root-authorized result review follows below; the approval above preceded execution.

### External repository status and ownership recheck

Independently fetched <https://github.com/agent-teams-ai/old-provider-implementations/pull/1> through the GitHub connector after the local source inspection. At this review it is open, draft and unmerged, exact head `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`, base branch `bootstrap` at `97785f6096dd25c43c80394dbd58f416798069f2`.

Its current body adds a material limitation: this extraction serves the legacy Desktop migration, where Desktop keeps teams, durable inputs, process custody and product state. It explicitly excludes future Orchestrator/runtime work and says the future Agent Runtime rewrite does not own that extraction. Therefore it is **not established as the intended current ADR-0091 delivery artifact merely because its package name and source lineage resemble the planned extraction**. Do not recommend merging this PR to complete ADR-0091, transfer its broader contract wholesale, or label candidate-pair incompatibility a production regression. Reconcile exact lineage, acceptance and target consumer before changing either contract. The source-contract probe remains an honest bounded diagnostic between these exact candidates.

### Independent review of the update research report

Read the complete `reports/update-research.md` and independently checked the new current-Codex-owner observation. Its `disposed` flag gates attempt preparation, delegated `createProcess` and owner preparation; `sealAdmission` sets that flag and seals custody. Thus an accepted operation that has not yet passed delegated setup cannot be assumed to run naturally after this seal. This is an additional applicability problem for earlier 2A, beyond the service-availability ambiguity. It is not a claim that current shutdown is defective.

**Disposition: pass**, with one small clarification requested from its author: a future temporary *new-operation* pause must preserve the existing reply, control, observation and reconciliation paths needed for accepted work to settle. Reusing the broad interactive `closing` gate would both start irreversible shutdown and potentially block progress the proposed wait relies on. The report appropriately keeps quiescence-and-stop/pause capability absent, whole-delivery LOC unknown, session continuity separate, source inspection distinct from execution and no-new-spike disposition explicit.

### Independent source-contract result review

Inspected the three consumer files, complete diagnostics, compiler configuration, compiler wrapper and `seam-probe/source-manifest.json`. Independently recomputed all 11 listed source/signature hashes and compared each file byte-for-byte with `git show` at its recorded source commit: **11/11 match both the manifest and exact Git source**. The six AR files and three external-contract files are the compiler source closure; the remaining two files establish the public Claude facade and explicit factory return annotation. They are not a full implementation compile.

| Probe | Observed result | Exact interpretation |
| --- | --- | --- |
| AR contract to itself | Exit 0, no diagnostics | The selected AR source closure and compiler setup resolve. This is a setup control only. |
| External declared driver contract to current AR contract | Exit 1, one TS2322 diagnostic | The returned driver's `observe` can yield `compaction`, which is absent from AR's event union. The factory types are not directly substitutable in this direction. |
| Current AR driver contract to external contract | Exit 1, one TS2322 diagnostic | The external contract allows a question-denial reply without `answers`; the AR `respondToInteraction` parameter cannot accept that form. The contracts are not directly substitutable in the reverse direction either. |

The configuration uses TypeScript 7.0.2, strict checking, `skipLibCheck: false`, `exactOptionalPropertyTypes: true`, `noUncheckedIndexedAccess: true`, no emit and no ambient package types. Its paths deliberately resolve the two **source** barrels; that is why this experiment makes no installed-package claim. The loaded library listing points to the TS7.0.2 native package. I inspected the retained `tsc.js` wrapper: it invokes the selected native executable and contains no older compiler implementation. The agent was asked to retain exact command/exit/version observations and the actual native compiler identity for provenance, without rerunning scenarios.

Both failures are semantic assignability diagnostics, not missing dependencies, invalid imports, compiler setup errors or runtime/provider failures. `any` appearing in TypeScript's standard `IteratorResult` diagnostic is not an escape added by the consumers. The consumers themselves contain only imports, declared source-typed values and direct assignments; there are no casts, suppressions, copied interfaces, fixtures claiming product behavior or production edits.

**Result verdict: pass as bounded evidence of source-contract divergence for this exact pair; stop testing.** H2/runtime/packed execution is unnecessary after the decisive primary rejection. This does not block the accepted ADR-0091 direction, show the curated AR export is defective, prove actual package installation fails, or justify merging the legacy provider branch, moving a contract to EF/GM, introducing a new shared Host, widening event unions or dropping new events. A real integration must first identify its intended consumer, supported artifact versions and ownership of semantic adaptation.

### Independent review of the process-plugin cross-check

Read `reports/process-plugin-crosscheck.md` and `sources/process-plugin-pins.json`. Independently fetched the exact release `client.go` and `server.go`; their returned Git blob hashes match `4db80ff60eef249048d7c0291976fd51da319fa1` and `0f4b8e5634511ba9d03f535b675d521499089fe1`. Reviewed `Kill`, its conditional two-second graceful phase, background-context runner kill, deferred client-goroutine join, environment inheritance and the reattach exclusions. Also independently fetched the current release API and both official Vault documentation pages. This is source review, not execution.

**Disposition: pass.** The report correctly distinguishes a transport/interface implementation from permission, process custody and effect truth. Its scale inference follows from registration versus activation and multiplexing, without claiming tenant isolation or measured thousand-plugin capacity. It does not turn go-plugin's shutdown timer into a total deadline, treat the magic cookie as authentication, transfer Vault's automatic reload behavior into AR, or recommend Go/process adoption. Release-fix history is explicitly historical rather than evidence of present bugs. The source pins distinguish the observed release from moving main and moving documentation.

### Sizing follow-up disposition

The update investigator proposed separately itemized, low-confidence local-mechanics bands for a future bounded-turn profile after root requested numerical comparison. These may be retained as **hypothetical conditional planning bands**, with estimate confidence 3/10 and unknown whole-delivery cost, if the prerequisites include a real complete accepted-work/debt inventory, authority-consistent admission and quiescence, existing operation journal/custody and existing restart/recovery owner. Implementing missing durable semantics is not included by assertion. Such bands are not source-validated measurements, a current ADR-0091 residual quote or a reason to implement an update controller now; place them below the primary policy/authority conclusion.

### Final governed-draft review

Read the actual new `authoring/docs/research/plugin-choice-deepening-2026-11-06.md`, the complete corrected OD-003 owner brief and subsequent open-choice sections, and the maintained research-reference delta plus its historical authority corrections. This was a read-only publication review against the evidence already inspected above; no experiment, compilation, runtime execution or governed edit was performed by this critic.

**Substantive disposition: pass for research-only publication.** The draft withdraws the mistaken contained-first recommendation without reopening accepted ADR-0091, explains that the omission existed at the same source pin, and separates the admitted provider slice from future no-fork capabilities and public EF publication. It distinguishes the legacy Desktop extraction from the intended delivery and expressly refuses to turn the two semantic compiler failures into a supported-release defect or an ADR-0091 blocker. The lower Shared Host Mechanics paragraph now limits its owner discussion to additional capabilities or mechanisms beyond the accepted provider slice.

The experiment account is accurate: three strict TypeScript 7.0.2 compiler invocations; eleven new TypeScript consumer lines; six AR plus three external contract files in the compiled source closure; eleven retained unchanged source/signature files checked against Git; two semantic TS2322 failures after a passing setup control. It claims no packed integration, Host/provider runtime, new update experiment, SDK validation, credentials, package release or deployment qualification. Earlier receiver results remain reused historical evidence with their original bounded scope.

The ordinary-update comparison preserves the accepted irreversible disposal/close/custody boundaries, separates update starvation from service unavailability, and retains replies/control/observation/reconciliation for any future reversible fresh-admission gate. It does not infer session continuity from idle turns or checkpoint APIs. The recommendation to defer before sealing is explicitly conditional on a real atomic owner capability rather than a production implementation already present.

The numerical update bands are conspicuously hypothetical local bounded-turn mechanics with unestablished prerequisites, missing prerequisite work excluded and unestimated, sizing confidence 3/10, overlapping alternatives and no delivery ceiling. Actual persistent-session P/I/T remains unknown, and reliability is unrated without a named promise. These restrictions prevent the supplemental arithmetic from becoming an estimate for the accepted interactive delivery. The old P0 wait/defer allowance is expressly retired. Research and reviewer agreement are not treated as owner adoption.

Two narrow editorial fixes were returned to root before archive freeze: (1) make the separate P0/I100–250/T200–500 future allowance explicitly distinguish owning-product composition wiring in I from consumer/conformance fixture work in T, because calling the whole allowance a fixture conflicts with the stated I definition; (2) render grouped source keys as separate defined Markdown references so the cited sources are clickable. Neither requires another scenario, a revised architecture choice or additional scope. Subject to those clarifications, this critic requests no further changes or experiments. Archive construction, DocsProtocol checks, commit/push and publication remain root's separate work and are not qualified by this review.

**Final closure:** reread the corrected allowance: I now names future owning-product startup/composition wiring, and T names the independent packed consumer/conformance fixture. Confirmed no combined undefined source-key references remain in the synthesis. Both requested clarifications are resolved. **Final review PASS; report ready for archive freeze.** No further change or experiment is requested.
