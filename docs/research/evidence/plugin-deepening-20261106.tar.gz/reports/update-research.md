# Ordinary plugin update policy: preserve work without indefinite accidental outage

Research cut: **2026-11-06 UTC**. Status: **research and proposed decision repair; no option adopted**. Source inspection and prior-experiment reuse only. No new runtime experiment, production change, public SPI, package, scheduler or lifecycle manager was implemented.

## Recommendation and the material change from the previous brief

Do not carry forward the current “seal new work, wait, and defer if unresolved” wording as a complete ordinary-update policy. **Defer must say whether the service remains active, temporarily pauses, or has irreversibly entered shutdown.** Keeping admission permanently closed while an accepted operation or live session may remain unresolved can leave that service unavailable indefinitely. That is a direct consequence of the proposed policy, not a newly observed production bug. Reopening the existing shutdown seal is not an available repair.

The smallest promising ordinary policy is **prepare what is safe while the old service stays active; defer before irreversible sealing while the selected profile is not safely replaceable; commit controlled shutdown only at an owner-proven quiescent boundary.** For bounded independent turns, the owner can consider an atomic quiescence-and-stop operation at actual admission. This can preserve ordinary service and accepted work, but updates may starve under continuous arrivals. For persistent interactive sessions, an idle turn is insufficient: the owner must decide whether a live session may close and what explicit checkpoint/restore continuity it promises. Do not automatically close such sessions merely to make an update finish.

A separately owned temporary **new-operation admission pause** is a second candidate when the product wants a deliberate drain window. It may abort the update attempt and resume the unchanged healthy service before irreversible action; it never abandons accepted work or improves unknown outcomes. Current inspected product ports do not supply that reversible operation. It adds admission, failure and recovery obligations and should not be smuggled into the earlier `P0 / I150–350` residual quote.

Keep 2B as an explicit owner-selected maintenance policy: after the chosen grace, request the existing authorized cutoff/cancellation and use the existing custody/receipt rules. It can improve pressure toward an update, but cannot promise an unconditional restart deadline when physical or external closure remains unknown. Emergency revocation, failure containment and already accepted owner deadlines remain independent of ordinary update preference. [A1, A2]

## 1. Current authority and the exact existing boundaries

AR main was inspected at `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`. EF OD-003 was read in full at current PR55 source head `99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d`. The confirmed baseline remains static composition plus controlled restart; downtime is permitted, and neither overlapping generations nor transparent session migration is approved. [A1, F1]

### Actual shutdown is already irreversible at several layers

| Inspected owner | What the source actually provides | Consequence for ordinary update policy |
| --- | --- | --- |
| `HostDisposalOrchestrator` | `dispose()` sets `#disposed = true` before abort and cancellation. Failure may clear the shared wait attempt for retry, but never clears `#disposed`. The 1,000 ms timeout bounds a caller's wait; it proves neither settlement nor termination. | Rejected disposal is cleanup debt or incomplete shutdown, not an invitation to reopen the same Host. There is no exposed reversible pause or quiescence-and-stop operation. [A3] |
| Host-custodied composition | Synchronously calls `containedTurn.sealAdmission()` before awaiting Host disposal; retains provider owner until shutdown permits disposal. | This is shutdown ordering, not an ordinary drain window. [A4] |
| Codex current-kernel owner | `sealAdmission` sets its `disposed` variable and seals custody. Delegated preparation, one-use process creation and attempt preparation check that variable. The exposed object has no resume operation. Claude/Docker owners follow the same permanent-seal shape. | The seal also fences delegated creators. It cannot be assumed to reject only fresh user submissions while every accepted-but-not-yet-prepared operation proceeds naturally. That is an applicability limit of the proposal, not a demonstrated new source defect. [A5] |
| Interactive Host | `closing = true` rejects new scheduled calls, then joins pending attempts and invokes existing cleanup for retained sessions. A failed cleanup resets the disposal Promise but leaves `closing` true. | A second disposal attempt retries cleanup; it does not reopen the Host. A count of API calls does not enumerate all session obligations. [A6] |
| Accepted interactive-session contract | Close durably seals admission, rejects queued undispatched inputs, invalidates interactions, drains observations, and never reopens. Restore is explicit, bound to the exact engine/codec/config/account/workspace/checkpoint and creates a new generation. | “Let all accepted queued work run naturally” is not the existing interactive close policy. Checkpoint restore restores conversation, not filesystem or effect truth; no automatic session migration follows. [A7] |

The inspected source has **no ordinary-update pause/resume/readback port** at these owners. A negative source search is bounded to these lifecycle/composition and interactive feature paths, not proof about every repository capability. More fundamentally, the explicit surfaces and implementations above are one-way shutdown APIs. An ordinary update controller cannot bypass them by resetting private state, deep importing private helpers or inventing a second Host authority.

The existing upstream current-owner shutdown test was inspected, not executed here. It checks repeated seals and refusal before synthetic dependency effects. That is useful evidence of intended permanent sealing, not live provider, container, cancellation or availability qualification. [A8]

### Preserve separate facts

| Fact | What it establishes | What it does not establish |
| --- | --- | --- |
| Candidate artifact/graph validated | A selected inert artifact/plan passes its applicable checks | Provider startup, service readiness, publish authority, resource compatibility |
| Candidate prepared/ready | Named candidate checks finished with the allowed dependencies/effects | Permission to route ordinary work or reuse exclusive old custody |
| Temporary admission paused | New operation identities in the named scope cannot be accepted while this reversible attempt owns its pause | Cancellation of accepted work; physical closure; global ingress convergence |
| Accepted cohort fixed | Admissions ordered before the barrier retain their actual accepted disposition | That every item was dispatched, is terminal, has no external effect, or belongs to the same profile |
| Durable cutoff/cancellation accepted | The operation owner accepted and persisted the command/fence at the right revision | Provider containment, effect resolution, output drain or terminal truth |
| Disposal requested / wait rejected | Shutdown began / this wait did not complete | Safe reopening, resource release, successful restart or known effect outcome |
| Physical closure observed | The qualified process/stream/container owner supplied the required closure evidence | External request rollback or resolution of a lost remote acknowledgement |
| Exact operation reconciled | The operation owner has the evidence its contract requires | Permission to replay a different identity or infer business-effect equivalence |

ADR-0009 and ADR-0010 explicitly prohibit using caller abort, timeout, disconnect, process exit or Host disposal as manufactured cancellation, containment, effect-resolution or terminal receipts. Unknown acceptance/effect remains nonterminal `reconcile_required`; it is not failure, success, `known_not_accepted` or retry permission. [A1, A2]

## 2. Primary industry experience: what changes the recommendation

These are documented contracts and exact source inspections, not newly executed deployment experiments or claims that a proxy, BEAM VM and agent session share one lifecycle. Exact file blobs and retrieval scope are retained in `sources/update-industry-pins.json`.

### NGINX 1.28.0: prepare before old admission changes; bounded retirement trades away completion

NGINX's official control guide describes validating and opening the new configuration's logs/listeners before starting replacement workers and asking old workers to close listening sockets while serving existing clients. Configuration-application failure retains the old configuration. In the inspected release source, `ngx_init_cycle` failure returns to the old cycle before the replacement-worker/shutdown sequence. The later worker start uses a short delay, so this is not evidence that every arbitrary module or business dependency achieved full readiness before cutover. [N1, N2]

NGINX also has a distinct optional shutdown timer. The inspected timer handler marks existing ordinary connections closed/error and runs their read handlers. Its timeout therefore sacrifices remaining connections; it does not prove remote effects completed or rolled back. [N3]

**Applicable lesson:** candidate checks and irreversible old retirement have different failure domains. Move safe validation earlier; keep any promise about late readiness appropriately narrow. **Not copied:** NGINX worker overlap, socket inheritance and restartable old master are not established AR session continuity or permission to resurrect disposed custody.

### Envoy 1.36.0: long connections are retained or terminated, not magically transferred

Envoy's pinned hot-restart contract initializes the new process, including discovery/health checks, before taking listener sockets; the new process listens before old draining begins. Existing connections stay with the old process. They must finish during drain or be terminated; the separate parent-shutdown timer closes remaining connections. The contract also names platform/socket/concurrency caveats. [V1]

The separately pinned draining contract makes the word “drain” precise: immediate listener closure differs from `?graceful`, which discourages requests while continuing to accept connections until its drain timeout, with protocol-filter-specific behavior. [V2]

**Applicable lesson:** distinguish new work, established sessions and physical lifetime; label every admission boundary. Persistent agent sessions resemble the long-lived case more than one HTTP request. **Not copied:** this make-before-break design relies on valid coexistence and capacity. It is not a justification to add overlapping AR generations or claim checkpoint transfer is live process migration.

### systemd 258: failed reload and failed service are deliberately separate

The pinned service manual recommends completion-aware reload notification or a synchronous reload command, rather than treating a sent signal as completion. It documents failed reload timeout while the service continues running. The exact implementation records `reload_result = SERVICE_FAILURE_TIMEOUT` and calls `service_enter_running` after killing the reload control process. That helper checks the surviving service and notification state; this is separation of reload failure from service failure, not a promise to revive an independently failed daemon. [S1, S2]

**Applicable lesson:** an ordinary update attempt may fail or be postponed while the current service remains active. Its completion signal must mean more than “request sent.” **Limit:** systemd's running state cannot roll back arbitrary daemon mutations, restore a closed credential route or prove provider effect truth. The candidate/old-service implementation must make aborted preparation non-destructive. Copying a timeout alone supplies none of that.

### Kubernetes 1.36 documentation snapshot: progress status is not recovery or physical death

The version-branch Deployment guide states that exceeding the progress deadline reports failure and the controller keeps retrying; Kubernetes does not automatically roll back a stalled Deployment. Availability/surge settings control rollout behavior, and terminating Pods may still consume resources. The Pod-lifecycle guide distinguishes endpoint readiness from serving existing traffic and warns that force API deletion does not wait for node termination confirmation; the resource may continue running indefinitely. [K1, K2]

**Applicable lesson:** retain explicit desired-update and observed-service status, plus custody reconciliation. “Update pending,” “drain deadline elapsed” or deletion from a registry cannot prove that an old process or external effect vanished. **Not copied:** no Kubernetes control plane, duplicate store or universal reconcile manager is justified for this local product operation.

### Erlang/OTP 29.1.2: refusing retirement is a legitimate result; coexistence has limits

The official `code` contract permits current and old module code to execute concurrently. `soft_purge` refuses when processes still reference old code; hard purge kills lingering processes, and loading another generation can purge older code. [E1]

**Applicable lesson:** refusing an update/retirement can preserve work; forcing progress has a concrete interruption cost. Even a mature VM does not grant infinite generation retention or preserve arbitrary external effects. **Not copied:** BEAM code switching and state callbacks do not supply JavaScript object replacement, agent checkpoint compatibility or external custody. No additional OTP experiment is needed to establish this documented tradeoff.

## 3. Candidate policies and honest liveness tradeoffs

Ranked for the confirmed static-restart baseline and the inspected missing ordinary-update API. These remain proposals. Rank is not adoption or a claim that all profiles should use the same policy.

| Rank / candidate | Ordinary-service behavior | Update/work guarantee and failure case | Fit and prerequisites |
| --- | --- | --- | --- |
| **1. Prepare safely; defer before sealing; commit stop only at genuine quiescence** | Current service continues accepting its permitted work while update is pending. No reopening is needed if no stop begins. | Preserves normal accepted-work policy. Update can starve under continuous arrivals, indefinitely unresolved work or indefinitely open sessions. A ready artifact does not remove that tradeoff. | Best minimal candidate for bounded independent turns. Needs the real admission owner to atomically verify quiescence and commit stop, including pending durable acceptance and cleanup debt. A prior poll followed by disposal has a race. For sessions, needs an explicit close/continuity decision first. |
| **2. Bounded reversible new-operation pause; abort update attempt if drain fails** | Deliberately interrupts fresh admission only during the bounded attempt; unchanged healthy service can resume if all resume conditions hold. | Finishes the finite admitted cohort naturally where its profile allows; unresolved work remains owned. Repeated failed attempts can still disrupt users and updates can starve. Bounding attempts alone is not a fleet availability SLO. | Requires a new narrow product-owned admission-pause and recovery contract, separate from all current shutdown/dispatch seals. Use only if a real maintenance need justifies this added behavior. |
| **3. Owner-selected maintenance grace then existing authorized cancellation/cutoff (2B)** | New admission closes for maintenance; accepted work may be interrupted under its existing operation policy. | Pushes toward closure but has no unconditional deadline when external/physical outcome is unknown. Once cutoff/close/disposal starts, keep the same owner sealed and reconcile; no automatic resume. | Appropriate if the owner selects this work-interruption tradeoff. Existing cutoff/close mechanics are reusable, but the schedule, disposition, update recovery and replacement readiness integration are still product work. |
| **4. Literal permanent seal, wait and indefinitely defer (ambiguous 2A reading)** | May remain unavailable forever to fresh work while update remains pending. Current provider seal can also block delegated preparation. | May preserve some running work, but has no ordinary availability or update-progress guarantee. | Do not recommend as the default. It could only be an explicitly selected indefinite maintenance state with honest status and recovery, rather than a promised benign defer. |
| **Outside present scope: overlap old/new generations with exclusive-effect fencing** | May preserve service while old work/sessions remain | Requires coexistence, isolation, capacity, compatibility, active-head publication, cross-generation effect/custody fencing and independent retirement | Industry precedent exists, but current baseline does not require it. Do not introduce it to repair an ambiguous ordinary defer sentence. |

### Bounded turns and persistent sessions require different quiescence predicates

For a bounded contained-turn profile, a finite duration claim must identify what is actually bounded: provider compute, owner deadlines, dispatch attempts, shutdown waits, external effects and receipt resolution are different quantities. An operation called “bounded” may still retain unknown external outcome indefinitely. Natural completion of a finite fixed cohort requires eventual settlement of each member, not merely a timeout configuration.

At an admission barrier, a command already queued ahead of the barrier may become accepted after the wall-clock stop request. That is accepted work if the owner serialized it first. Fresh identity acceptance after *observed completed* barrier is the rejected case. Duplicate readback, observation, cancellation and reconciliation should follow the existing policy rather than be accidentally blocked as fresh work. The historical RST-01 queue/absence oracle already demonstrated these distinctions. [F2]

For interactive sessions, an empty active-turn slot may still retain the provider process, conversation, grants, pending replies, event streams, checkpoints and queued inputs. The store's durable queue policy and live session closure remain authoritative. ADR-0091 rejects queued undispatched inputs during close, forbids silent restore/fresh fallback and blocks the next handoff after uncertainty. Therefore an owner must select one of: wait for explicit session closure, explicitly authorize maintenance closure with its visible consequences, or separately qualify checkpoint/restore continuity. “Wait until idle” alone does not answer it. [A7]

### Resume conditions for the temporary-pause candidate

These are proposed requirements for a **future** narrow reversible pause, not existing behavior and not permission to reopen current shutdown APIs:

1. The update attempt is definitively aborted or deferred before irreversible cutoff, revocation, session close, dispatch seal, resource disposal, publication/authority transfer or incompatible migration.
2. The old instance, authority revision and selected head remain current, healthy and able to admit this scope under its existing policy. Candidate work has not irreversibly changed shared/exclusive resources. Candidate cleanup debt remains retained by its owner and does not consume resources needed to resume safely.
3. The exact attempt owns the pause; a stale attempt cannot remove a newer maintenance/security/failure barrier. The actual admission owner serializes pause, admissions, abort/resume and any permanent stop. Pause only new operation/session admission; preserve the existing reply, targeted control, observation and reconciliation paths needed for accepted work to settle. Blocking every scheduled call can deadlock that drain, especially when a provider waits for a reply.
4. Already accepted operations/sessions retain their identities, reservations, effects and unresolved truth. Resuming fresh permitted work does not replay, declare success or release custody for an unknown operation. Whether unrelated work can proceed depends on that owner's scope and capacity rules.
5. Crash recovery can distinguish an abortable pre-disposal attempt from irreversible shutdown using existing authoritative records/observations. If that distinction cannot be proved, fail closed and reconcile. A lost controller Promise is insufficient.

If any irreversible action has happened, recovery is an owned continuation/reconciliation or a freshly authorized restart with applicable new identities and compatibility checks. It is not “undo dispose.” [A1, A2, A7]

### Failure and starvation must be reported separately

| Situation | Honest result |
| --- | --- |
| Candidate invalid before side effects | Reject candidate; existing service remains active. No update admission pause is needed. |
| Candidate readiness fails while old service is unchanged | Reject candidate and retain/retry candidate cleanup debt; keep old service active where its health/authority permits. |
| Candidate needs exclusive resources or incompatible state mutation to become ready | Full pre-start readiness cannot occur beside the old service; record an explicit maintenance/recovery boundary. Do not promise safe defer after arbitrary preparation. |
| Natural drain exceeds ordinary attempt budget, no irreversible action | Either continue active service by deferring before stop, or abort a qualified temporary pause and resume under the conditions above. Accepted work remains owned. |
| Shutdown/cutoff/session close already started and its wait expires | Incomplete shutdown or `reconcile_required`; keep irreversible barrier. Retry/join cleanup through existing owner. |
| Old service retired but replacement startup fails | Outage/recovery state. A preflight pass did not guarantee startup. Start a freshly authorized compatible recovery instance if policy permits; never reopen a disposed old object by flag reset. |
| Continuous normal arrivals or long-lived open session | Work/service preservation can starve an ordinary update. Surface the pending update/age and let explicitly authorized maintenance policy resolve it. Do not silently promote to cancellation. |
| Lost external response after commit | Same operation identity and owner reconciliation; neither update cancellation nor replacement grants replay permission. |

There is no policy that simultaneously promises arbitrary accepted work never interrupted, ordinary admission never paused, every indefinite session preserved, exclusive resources never overlapped, and an unconditional finite update deadline. Additional boundedness/coexistence assumptions or an explicit interruption tradeoff must be named. This is reasoning about conflicting promises; a finite timeout experiment cannot prove an infinite liveness guarantee.

## 4. Sizing, confidence and the decision brief repair

The previous 2A/2B ranges were explicitly conditional customization increments, not full production quotes. Their assumed owned admission/closure ports are not demonstrated for this ordinary operation. **Production `0` cannot be retained as an unconditional fact for a reversible pause, atomic quiescence-and-stop, session continuity, or crash-safe update recovery.** Existing immutable graph construction and actual shutdown remain reusable; this does not invalidate them or justify a new shared runtime. [F1]

The requested separate P/I/T comparison is available in `reports/update-sizing-supplement.md` as **hypothetical local-mechanics budgets only**, with confidence 3/10 and explicit missing durable inventory/atomicity/recovery prerequisites. They are not current AR residual estimates or persistent-session delivery quotes. Whole-delivery unknowns below remain unchanged.

Suggested judgment scores below describe the **conditional achievable contract after prerequisites**, not observed uptime. Whole-product LOC remains **unknown** until the exact selected profile and operation owner are specified. Contract confidence and estimate confidence are separate.

| Candidate | Reliability /10 | Contract recommendation confidence /10 | Complexity /10 | New/changed production, integration, test LOC |
| --- | ---: | ---: | ---: | --- |
| Quiescent pre-seal defer for one bounded-turn slice | 8 | 7 | 4 | Unknown at current owner boundary; inventory actual admission/accepted-work/quiescence port first. Earlier residual range is not validated by this research. |
| Qualified temporary pause for that same slice | 8 | 5 | 6 | Unknown; additionally needs attempt ownership, safe abort/resume and recovery behavior. No neutral manager or new canonical store included. |
| Explicit maintenance grace/cutoff on existing owners | 8 | 6 | 5 | Unknown whole scope; earlier 2B incremental allowance may be reusable only after actual owner ports, closure/deployment and failure-recovery inventory. |
| Transparent persistent-session continuity through update | Not rateable without selected guarantee | 3 | 8 | Not estimated; exact checkpoint compatibility, live custody, handoff uncertainty, queue disposition and product policy are unresolved. |

Reliability 8 is not a claim of equal availability: the first preserves service while postponing updates, the second deliberately pauses fresh work, the third permits cancellation, and all retain uncertainty. Estimate confidence for all current whole-delivery costs is low. Scores should not conceal that their user-visible promises differ.

Proposed owner-brief replacement, for discussion only:

> Ordinary update preference preserves accepted work and keeps a healthy current service active while the update is pending. Prepare only candidate checks that are safe beside the active service. Defer before irreversible shutdown unless the actual owner can establish the selected profile's quiescent boundary atomically with stopping new admissions. Continuous load, unresolved outcomes and open sessions may postpone an ordinary update indefinitely. A bounded temporary new-operation pause is an additional product policy requiring explicit abort/resume/recovery guarantees; current shutdown seals cannot serve as that pause. If maintenance cancellation is selected, use existing authorized cutoff/close and exact custody/receipt closure. Once irreversible shutdown begins, a timeout cannot reopen that instance or justify uncertain-work replay.

This repairs the missing promise while preserving the owner's right to choose maintenance behavior. It neither adopts a new 2C option automatically nor authorizes changing AR's accepted close semantics.

## 5. Experiments: reviewed decision to reuse evidence and stop

The required pre-implementation plan is `plans/update-spike-plan.md`. It proposed a conditional two-case real receiver/effect-child check with independent acceptance/absence/physical-exit oracles and two broken controls. Independent `deep_plan_critic` reviewed the plan and **approved the no-new-spike default**. Root agreed after current-owner inspection: absent a real reversible/quiescence port, adding a toy gate would test an invented contract and would not justify the product estimate.

The independent critic subsequently read this full report and passed its source mapping/ranking/unknown-cost and no-experiment conclusions, with one wording repair now incorporated: a temporary fresh-admission pause must preserve reply/control/observation/reconciliation needed by existing work, rather than copy the broad interactive shutdown gate.

**No new spike was built or run.** No dependency was installed, provider contacted, credential accessed or experiment process launched. Existing evidence reused without rerun:

- RST-01: actual serialized permanent seal, pre-seal queued acceptance, post-seal fresh-identity rejection, operation-specific acquisition/launch absence and fresh-worker canonical readback.
- RST-02: real construction/resource handles, readiness failure and retained cleanup debt without candidate publication.
- RST-03: real late success cannot overwrite canonical cancellation; result/IPC disconnect is not physical exit or reservation release; an earlier synced external file effect persists.

Those are frozen fixture results with their earlier limitations, not AR product qualification or proof of a reversible update gate. The original unsealed receiver failures remain failures. [F2]

Reopen experiment planning only after the owning product identifies a concrete admission/quiescence operation and a real uncertainty that can change design or sizing. Then use a minimal real boundary with an independently observed accepted cohort, durable operation readback and actual retained physical resources; include an intentionally broken barrier and a forbidden-resume control. Do not implement an asynchronous universal manager, per-call Temporal workflow or parallel durability layer to demonstrate a simple policy.

## Source ledger

All industry sources below were retrieved/inspected **2026-11-06 UTC**. Versioned source pins are intentionally the bounded versions inspected, not claims about the latest release. Blob IDs bind exact file content returned by the GitHub connector. Mutable documentation branches/pages are labeled. Source inspection, upstream-test inspection and earlier executed evidence remain distinct.

| ID | Primary authority / exact pin | Inspected location / limit |
| --- | --- | --- |
| A1 | [AR ADR-0009](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0009-contained-turn-private-access-and-host-shutdown-boundary.md), blob `2d50e07c40413d7042b4cac906739c53073c61fb` | Full document; cancellation vs actual Host disposal/custody. |
| A2 | [AR ADR-0010](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0010-contained-agent-turn-v1-operation-authority.md), blob `672a4e122259da239822fb675ad1ff69e3460f31` | Unknown outcomes, no-blind-retry, orthogonal receipt/terminal facts; not a generic successor-operation protocol. |
| A3 | [AR Host disposal](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/agent-runtime-host-disposal.ts), blob `81a3be33c40987008c334e41aa17b031a37ccb8f` | Interface, timeout constant, `dispose`, `#finishDisposal`; inspected, not executed. |
| A4 | [AR Host-custodied composition](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/host-custodied-agent-runtime-host.ts), blob `7bd6a64a0c08f860275203902eac611cc20fa5b6` | Synchronous provider seal before durable cancellation can suspend. |
| A5 | [Codex owner](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/composition/codex-current-kernel-owner.ts), blob `d5f345e16001c23218ba690a5e00bf73b4105924`; [Claude owner](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/composition/claude-current-kernel-owner.ts), blob `dfbe2956a898a780678aa51086f04db8da4940ef`; [Docker owner](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/composition/docker-codex-host-kernel-owner.ts), blob `a6550a6e08f1855abfc8f388a6e14d561eb02d33` | Permanent seal and delegated creator guards. Not evidence these routes are production-qualified. |
| A6 | [Interactive session Host](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/features/interactive-session-runtime/application/use-cases/create-session-host.ts), blob `20503591653a9848e3c80e75918e3d7496e8cfe6` | Full small owner; synchronous schedule admission, retained sessions, persistent closing on failed cleanup. |
| A7 | [AR ADR-0091](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md), blob `d492a490f0c6c04434d4560840802a25eedd5d29` | Full accepted additive interactive authority. Synthetic/implementation/deployment readiness remain separate. |
| A8 | [Current-owner shutdown test](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/tests/features/contained-agent-turn/current-owner-shutdown-admission.test.ts), blob `c27782100b10084aeeba7d4f5b144919bd54df8b` | Upstream synthetic test inspection only; not executed here. |
| F1 | [Current EF OD-003](https://github.com/agent-teams-ai/extension-foundation/blob/99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md); [restart validation](https://github.com/agent-teams-ai/extension-foundation/blob/99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d/docs/research/static-composition-and-controlled-restart-validation.md) | Full local source reads; owner-confirmed static baseline and still-proposed 2A/2B conditional estimates. |
| F2 | [EF boundary/failure campaign](https://github.com/agent-teams-ai/extension-foundation/blob/99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d/docs/research/plugin-boundary-and-failure-experiments.md) | Full record read; archived earlier RST results reused as reported, no new replay/qualification. |
| N1 | [Controlling NGINX](https://nginx.org/en/docs/control.html), **moving unversioned page** | Changing configuration; executable upgrade; old clients and narrow rollback procedure. |
| N2 | [NGINX 1.28.0 process cycle](https://github.com/nginx/nginx/blob/release-1.28.0/src/os/unix/ngx_process_cycle.c), blob `5bc5ce9792df0d251b6a9dc943a0f2370335f4ca` | `ngx_reconfigure`, source lines 200–270 retrieved; init-cycle failure, new workers, delay, old shutdown. |
| N3 | [NGINX core timer 1.28.0](https://github.com/nginx/nginx/blob/release-1.28.0/src/core/ngx_cycle.c), blob `a75bdf8786fa4f2c4dd45129741bfcf4b5849263`; [directive docs](https://nginx.org/en/docs/ngx_core_module.html#worker_shutdown_timeout), **moving unversioned page** | Source lines 1400–1475 retrieved; optional timer and connection close/error handler behavior. |
| V1 | [Envoy 1.36.0 hot restart](https://www.envoyproxy.io/docs/envoy/v1.36.0/intro/arch_overview/operations/hot_restart); [exact tag source](https://github.com/envoyproxy/envoy/blob/v1.36.0/docs/root/intro/arch_overview/operations/hot_restart.rst), blob `8a6f09eabafe7cc33002757f47d7e902a05b6460` | Full short contract; initialization/drain order, separate shutdown timer, no connection transfer and caveats. |
| V2 | [Envoy 1.36.0 draining](https://www.envoyproxy.io/docs/envoy/v1.36.0/intro/arch_overview/operations/draining); [tag source](https://github.com/envoyproxy/envoy/blob/v1.36.0/docs/root/intro/arch_overview/operations/draining.rst), blob `cacdcc9950889d557404685c5b373acbc73432fd` | Full short contract; immediate vs graceful listener closure/filter behavior. |
| S1 | [systemd 258 service manual source](https://github.com/systemd/systemd/blob/v258/man/systemd.service.xml), blob `68663e9ed81685f15ba5e63dc79123dfc011dd00` | `notify-reload`, `ExecReload`, `TimeoutStartSec`; `/man/258/` web open timed out, source retrieved successfully. |
| S2 | [systemd 258 service implementation](https://github.com/systemd/systemd/blob/v258/src/core/service.c), blob `c8cda0609942fcda179a8d62828976d9c3fdd71c` | Reload timeout branch around lines 4430–4438. Source inspection only; no daemon run. |
| K1 | [Kubernetes Deployment docs, release-1.36 branch](https://github.com/kubernetes/website/blob/release-1.36/content/en/docs/concepts/workloads/controllers/deployment.md), exact blob `2ec9ba7c01996e278991f54886d4f9fd97c2c20b` | Mutable version documentation branch; failed-progress, rollout/availability and terminating-resource caveats. Current moving webpage also consulted, not treated as immutable. |
| K2 | [Kubernetes Pod lifecycle docs, release-1.36 branch](https://github.com/kubernetes/website/blob/release-1.36/content/en/docs/concepts/workloads/pods/pod-lifecycle.md), exact blob `da4d0f437e596a171022f427f0ec9e4696f9eef6` | Mutable version documentation branch; terminating endpoint serving vs ready, force-deletion confirmation warning. |
| E1 | [OTP `code`, displayed OTP 29.1.2/kernel 11.0.4](https://www.erlang.org/doc/apps/kernel/code.html); [tag source](https://github.com/erlang/otp/blob/OTP-29.1.2/lib/kernel/src/code.erl), blob `30f4d06a07982ac0967fe0f105ef849158f48d5f` | Current/old code and `soft_purge`/`purge` contract; exact version source, no VM experiment. |
