# First customization seam: current authority, actual extension contracts and independent delivery

Date: 2026-11-06. Investigator: seam research. Evidence class: source inspection and primary-source research; any later executed diagnostic is recorded separately below. No governed code, production API, publication, commit or deployment changed here.

## Recommendation

**Withdraw contained-provider-first 1A as the preferred next journey.** It was conditional on an unnamed useful variation and overlooked an accepted, more relevant product decision already present at the same inspected AR revision. Agent Runtime ADR-0091 accepts the owner-directed A–F interactive-session/provider extraction slice, a consumer-owned erased provider SPI, external provider packaging and an explicit real consumer. It explicitly leaves contained-turn frozen and forbids widening the ordinary Codex contract under its existing profile. This is an authority correction, not a new `1D` vote and not adoption of an unreviewed public EF SPI. [AR1, AR2]

Continue the admitted interactive slice through its actual remaining package/Host/authority qualifications. Reuse the already specified contract instead of extracting a new contained provider facade because its internal port looks convenient. If the current user customization need is different, name its behavior and trust placement first; configuration, a declarative contribution, a narrow extension point, an ordinary library and an execution provider are different author journeys. The chosen code directory cannot select the user's need.

**The accessible old-provider prototype is not established as ADR0091's delivery target.** Its PR1 body explicitly places the extraction under legacy Desktop ownership and excludes future Orchestrator/runtime work. Comparing that separate donor snapshot with current AR is therefore exploratory reuse/compatibility evidence, not an ADR0091 delivery blocker, a supported-release defect, or a mandate to integrate/repair/merge the old provider PR. AR's public erased-SPI packing test and that prototype's own-contract packing test do not prove the two artifacts work together. Preserve the useful mismatch and establish the intended provider artifact/authority before any actual integration recommendation. [AR3, EXT1–EXT5]

## Evidence provenance and authority

The entire common brief and complete current EF OD-003 were read before conclusions. AR was cloned read-only and detached at `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e` (commit 2026-11-06; observed 2026-11-06). EF OD-003 is the current local draft at `99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d`; the document's dated owner brief references its preceding research head. Primary sources below are exact pinned files unless explicitly identified as moving documentation. Source inspection is not execution of the tests those files contain.

The authenticated GitHub request for the exact ADR-referenced `agent-teams-ai/provider-implementations` returned HTTP404 on 2026-11-06. This is an access observation, not proof the repository does not exist. Installed repository search found `agent-teams-ai/old-provider-implementations`. Its default `bootstrap` branch is `97785f6096dd25c43c80394dbd58f416798069f2` (2026-10-24), containing four bootstrap files only. Actual implementation is in open PR1, head `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`, base `bootstrap`. Open PR2, `076f11c71532e8ebb7530a9272f4de3731232661`, targets PR1's branch and corrects OpenCode V2 native envelopes before Host integration. Neither was merged when observed. Do not call the implementation branch current released main. [EXT1, EXT2]

## 1. The three actual AR execution surfaces

| Surface | Source contract and current construction | Actual guarantee/limit | Implication for plugin advice |
| --- | --- | --- | --- |
| Contained turn | Private provider execution port; exact `codex | claude` outer selection; owner-created provider and custody; seven explicit AE dependencies | Exact route qualification, immutable authority and closure evidence. Linux Codex registry row is implementation-only; Claude refuses `claude-broker-seam-absent` | Existing port is an internal substitution boundary, not evidence that ordinary authors may receive its authorities |
| Ordinary Codex user session | Accepted ADR-0090; curated `createAgentRuntimeHost(options)` closes execution/storage/scope options; private eight-module graph supplies exactly seven AE dependencies | Current-user cooperative cleanup; exact macOS arm64/Codex0.153.4/Spark/workspace-write profile; one attempt and explicit receipts; live campaign unqualified | Ordinary default must not be omitted, but its closed profile is not an arbitrary provider extension point |
| Interactive session | Accepted ADR-0091; erased `./interactive-contracts`; `createInteractiveSessionHost`; separate provider driver port and trusted store/authority/custody/context inputs | Persistent session technical ownership; SDK consumption != provider acceptance; explicit restore; control/closure uncertainty preserved; real provider/deployment unqualified | Already admitted relevant provider extraction; finish its actual independent-package and owning-consumer evidence |

The product architecture explicitly says ordinary user-session execution is the default and Host Custody is an optional profile defaulted off. It also makes sandbox limits orthogonal to uid/custody. The earlier contained-only shortlist therefore selected a narrower, privileged path without establishing that it matched the owner's current desired customization. That default document contains deferred assembly work and does not itself qualify the ordinary implementation. [AR4]

### Contained: an ordinary author must not implement the owners

`ContainedTurnKernelProviderPort.execute` receives adapter/ProviderAccess snapshots, authority digest, operation/attempt/custody/effect/workspace identities, cancellation query, output emitter and Host-owned delegated start. That is a provider-to-kernel contract whose source types connect to proofs and immutable execution identity. Beside it, `ContainedTurnKernelCustodyPort` reserves custody, owns process creation observation, completion boundaries, physical containment, closure attestation and identity-bound release. Outer product composition separately maps Provider Access and Runtime Security. [AR5]

It would be a privilege leak to equate arbitrary factory injection with plugin extensibility and let a user adapter supply custody, route enforcement, grant owners or authoritative receipts. Conversely, the adapter need not import a universal Host implementation: a curated product-specific facade could pass bounded execution requests and typed observations while trusted composition retains process and authority. The point is to design only the substitutable behavior that a real provider needs, not to publish all internal vocabulary. This is a proposed design inference, not an adopted SPI.

The feature README expressly records Codex whole-turn buffered assistant output and Claude incremental output plus cancellation parity gaps. A shared method shape cannot erase those differences. The current Linux implementation-only registry and missing Claude broker seam remain delivery prerequisites; packaging the adapter would not supply them. [AR6]

### Ordinary: a smaller profile does not mean interchangeable guarantees

ADR-0090 separates `process` from `provider`. `OrdinaryProcessPort` reserves, launches once after dispatch claim and observes process/output closure. `OrdinaryProviderPort` consumes an opaque transport and non-confidential credential facts, interprets protocol, emits output and reports provider terminal status. Its `supported` shape contains the literal manifest `ordinary-codex-macos-arm64-0.153.4-v1`; it is not a free provider string disguised as a generic contract. The concrete adapter validates exact model, version, cwd, sandbox, permission and ephemeral-thread facts. [AR7]

This is useful counterevidence to a contained-first assumption: a provider's protocol can vary independently of physical process ownership. But it is also counterevidence to simply exposing the ordinary port. A named different model, permission profile, auth route or protocol may change the exact evidence tuple and require a successor contract/qualification. Native provider `plugins` and related capabilities are explicitly disabled in this profile; enabling a vendor's plugin system would be a distinct authority expansion, not a shortcut to Agent Runtime extensibility. [AR7]

### Interactive: public type contract is already a deliberate product boundary

ADR-0091's SPI includes `DriverFactory.open`, session submit/observe/reply/targeted interrupt/readiness/checkpoint/close, typed failures and confirmed/required capabilities. SDK DTOs, native session IDs, spawn types and checkpoint bytes remain implementation-private. The source barrel exports only erased types; package.json admits `./interactive-contracts` separately from `.` and `./composition`. Both Agent Execution and Embedded Runtime packages remain private `0.0.0`. A curated import path is a usable boundary within private packaging; it is not stable public-marketplace publication. [AR1–AR3]

The production Host factory captures explicit provider/store/authority/custody/context ports, composes the current static GM graph and owns a real private-directory descriptor lock. The capability returned to ordinary consumers is separate from trusted scheduling controls (`dispatch`, `pumpOutput`, `recover`, `checkpoint`). This is an important direction of dependency: an independently delivered driver provides technical session behavior, while product authority and operational lifecycle stay outside it. [AR8]

## 2. An exploratory donor comparison reveals a concrete compatibility mismatch

**Scope correction from independent cross-review:** the accessible old-provider PR1 describes a separate legacy Desktop extraction and expressly excludes future Runtime/Orchestrator work. Its similarly named Session SPI is not sufficient provenance to call it ADR0091's intended implementation. The table and source probe below compare exact snapshots for potential reuse only; the result cannot justify fixing current AR or that PR, creating a new contract owner, or merging the PR. First establish the actual selected implementation and reviewed contract revision.

Current AR and external PR1 share much nominal vocabulary but not an identical SPI:

| Contract item | AR `f990…` | External PR1 `7573…` | Compatibility consequence to investigate |
| --- | --- | --- | --- |
| `EventPayload` | text/tool/tool-result/usage/result/interaction/diagnostic | additionally `compaction` | External driver may emit a variant AR's event union does not admit |
| Question reply | answers only | answers or explicit denial | Wider consumer obligation may affect adapter substitution; direction matters |
| Input | content and stable IDs | optional immutable attachment references | Optional addition is not automatically a compatibility failure, but AR supplies no attachment journey |
| Factory contract identity | `@agent-teams/agent-execution/interactive-contracts` | `@agent-teams/provider-session-contracts` | External factory signature explicitly returns the latter; no exact joining proof follows from similar names |

External `createClaudeDriverFactory` returns its imported `DriverFactory` explicitly. Its public facade exports that function. Its packed consumer checks that factory against its own separate contracts, imports the concrete facade and exercises synthetic Codex subprocesses. AR's erased-SPI test instead manually tars/extracts only Agent Execution dist plus manifest outside checkout, strictly compiles that type consumer, verifies no runtime exports and rejects a provider-specific type. It does not exercise normal package-manager installation/dependency closure. Both tests are valuable, but neither composes these exact artifacts with each other. [EXT3–EXT5, AR3]

Current internal Host tests inspect the actual graph's independent binding oracle, resource isolation, unknown cleanup retention, descriptor lock, restoration, held-open/held-restore disposal races and mutated caller identity. They import internal compiled paths and use the owner's fake. The draft Claude experiment has separate SDK transport/localhost and packed executable-resolution tests. Repeating those tests would not close the missing cross-artifact boundary. [AR9, AR10]

For any real selected pair, the residual deliverable is compatibility provenance and conformance, not a new container, registry or universal manager. These exploratory snapshots are not established as that pair. A major/new contract revision or a narrowing anti-corruption mapper might eventually be appropriate if the relevant owner chooses reuse and defines the added semantics. Silently ignoring compaction while claiming full semantic compatibility is unjustified. Do not mutate either prototype to manufacture a pass during research.

## 3. Two mature comparisons answer the relevant contract question

Root separately owns HashiCorp go-plugin, avoiding duplicate research here. Backstage is the closest TS static-composition example; VS Code is the closest broad no-fork customization example. These are source/official-document inspections, not local executions or universal superiority claims.

### Backstage: extension points are owned product APIs, distinct from internal service replacement

Observed source pin `3978b972588f333882991d98a52a5d855f6afa05`, 2026-11-06T13:00:54Z; inspected catalog-node package `2.2.7-next.1` and backend-plugin-api `1.11.1-next.0`. This is a development pin, not a stable-release claim. Current official docs were read 2026-11-06. [BS1–BS4]

Backstage explicitly starts with static configuration for light customization, then plugin-owned extension points when deeper behavior is needed. Modules consume the plugin's node-library contract without depending directly on plugin implementation. It prefers several small extension points, permits additive-only registration under intentional installation, and uses setters with duplicate rejection for single-implementation behavior. Breaking an established extension point calls for a new named point plus deprecation, rather than quietly widening one global object. [BS1]

The catalog source shows a concrete distinction: `catalogProcessingExtensionPoint.addEntityProvider` and `.addProcessor` admit useful new ingestion/processing behavior. The separately packaged GitHub module registers `GithubEntityProvider` and a location analyzer through those points, while declaring logger/config/scheduler/auth/catalog/lifecycle dependencies explicitly. The user outcome is a new source of catalog entities, not repackaging the same plugin. [BS3, BS4]

Counterevidence matters. Modules are deployed with the plugin in one backend, not independently live replaced with process isolation. Backstage's release policy acknowledges hundreds of packages and manages compatible combinations with release bundles and skew rules; individual packages use semver but public API stability has explicit producer exceptions for Utility APIs/Backend Services. Its lifecycle hooks do not prove AR custody closure. Reusing its framework would conflict with already owned GM composition; the transferable lesson is narrow owner extension contracts plus tested version sets. [BS2]

### VS Code: one capability enables many implementations because selection/merging/failure semantics are public

Observed source pin `29ad5e7ec8d963aa67226f58a4472697b21d6f35`, 2026-11-06T20:20:31Z; `vscode.d.ts` blob `e85341e3b011c62d427c9ef3d959ee38e24a1d1a`. This is development source inspection. Moving official docs were read 2026-11-06; several pages display 2026-11-04. [VS1–VS6]

The formatting provider is a capability-specific interface: a document, formatting options and cancellation token produce edits. Its registration contract says how multiple providers are selected and how the selected provider's failure affects the operation. Hover providers have a different public rule: parallel invocation and merged results with individual failure isolation. The system does not infer either policy from generic registration. [VS1]

The ecosystem author can supply a new language service, formatter, grammar or view while the editor keeps the interaction and rendering authority. Declarative contributions handle simpler cases. This is the useful scaling pattern: stable per-capability vocabulary, explicit applicability and bounded selection, reusable tooling/samples, then more independently packaged implementations. One capability need not become a universal lifecycle interface. [VS2]

Compatibility is a maintained obligation: extensions declare `engines.vscode`; stable API is separated from experimental proposals whose use is restricted to development/Insiders and not ordinary Marketplace publishing. An API existing in source is therefore different from a stable authoring surface. [VS3, VS4]

Counterevidence is decisive for security claims: official runtime-security documentation says the extension host has the same permissions as VS Code, including files/network/processes. Extension Host separation protects responsiveness/UI boundaries and supports placement/lazy activation; it is not a hostile-author permission sandbox. The architecture expressly prevents direct DOM customization, which leaves some demands outside the no-fork API. No-forcing-fork means supported extension needs can be met through admitted contracts; it cannot mean arbitrary replacement of all authority or every internal behavior. [VS5, VS6]

## 4. How this grows to hundreds/thousands without a platform rewrite

This is engineering inference from the comparisons and fixed owner constraints, not a measured AR capacity claim.

1. Keep the catalog independent of the selected graph. Thousands of available artifacts need not mean thousands of active drivers, processes, tenants or running turns.
2. Add a capability because a user needs independently variable behavior. Give that capability an owner, stable IDs/revisions, selection/cardinality and failure semantics. Most modules remain statically composed implementation details.
3. Keep contracts small and separately consumable. Publish only established vocabulary; do not export GM containers, graphs, lifecycle managers or private security objects as plugin context.
4. Test each provider against a reusable owner conformance kit and representative compatibility sets. A linear matrix of admitted provider versions/profile revisions is meaningful; testing every pair of unrelated modules is not automatically necessary. Interacting capabilities still need explicit integration tests.
5. Retain exact implementation, protocol/binary, configuration, credential-route and state-codec identities where effects require them. Semver is useful selection information, not execution qualification or physical closure proof.
6. Use explicit chosen startup composition and controlled restart. No marketplace implies permission to replace security, canonical state or process custody. Untrusted author code requires a separate admitted placement/effect boundary.

This limits growth to useful extension contracts and their real cross-capability dependencies. It avoids a central plugin manager becoming a universal service locator. Existing graph-growth/packed-consumer research is reusable evidence about its named dimensions; it is not proof of thousands of simultaneous provider sessions.

## 5. Cost decomposition and ratings

**The prior 1A range is not a delivery quote for the already admitted interactive slice.** Its seam assumptions targeted a frozen contained path; applying that range to ADR0091 would count existing work as new and hide the missing external compatibility/authority/deployment work. Existing source inventory at AR `f990…`: interactive AE feature13 TS files/883 physical lines; interactive Embedded Host feature20 TS files/405 physical lines, excluding outer composition and tests. Ordinary Codex adapter5 TS files/714 physical lines. These are inventory, not implementation estimates or quality metrics.

The useful decomposition for the interactive slice is:

| Cost bucket | New/changed production | Owning-product integration | Focused tests | Prerequisite / uncertainty |
| --- | ---: | ---: | ---: | --- |
| Source-contract compatibility diagnostic proposed here | 0 | 0 | <=30 TS probe LOC + bounded orchestration | Source only; no release gate; exact result recorded separately |
| Reconcile the exact contract identities and supported variants | 0–250 | 50–200 | 200–600 | Only if mismatch is actually on intended selected release pair; a new revision/adapter may be needed. Do not budget owner-approved expanded semantics as a few aliases |
| Exact packed driver + unchanged real public Host consumer | 0 | 100–250 | 200–500 | Requires legitimately built current artifacts and dependencies; cannot inherit draft-contract test claims |
| Real Provider Access/security/tool authority and credential route | Unknown | Unknown | Unknown | Must name actual account/credential route, tool set, scope and authority owners; fixtures prove no real credentials |
| Real SDK/native launcher/custody/platform delivery | Unknown | Unknown | Unknown | Exact SDK/CLI/OS package, process closure, native delivery/signing as applicable; existing native owner reused |
| User product/Orchestrator/desktop behavior and final fork removal | Unknown | Unknown | Unknown | Product-selected consumer journey, real tools and completion semantics; cannot be inferred from adapter registration |
| Public ecosystem compatibility/documentation/conformance support | Unknown | Unknown | Unknown | Separately selected publication surface and supported-version policy; private0.0.0 prototype has no stable release promise |

The first three rows overlap if delivered as one coherent integration; do not add them mechanically. Ranges are hypotheses for bounded compatibility work, not release commitments; unknown rows can dominate total cost. Existing generated schema, moved algorithms and vendor code are not new handwritten production LOC.

Ratings (/10; complexity10 harder):

| Recommendation / claim | Reliability after its named gate | Confidence now | Complexity | Reason |
| --- | ---: | ---: | ---: | --- |
| Follow ADR0091 ownership and existing erased SPI instead of contained-first extraction | 8 | 9 | 4 | Direct accepted authority and real existing source; real route qualification separate |
| Reuse the exact AR+legacy external PR1 pair unchanged | Unrated | 2 | Unresolved | Not an established intended delivery pair; distinct contracts and separate product authority |
| Narrow source compatibility diagnostic | 9 | 9 | 1 | Finite exact closure, independent current-AR contract oracle; only proves assignability |
| Broad public hostile-plugin system from current ports | Unrated | 2 | 9 | Authority/effect/isolation/public-version obligations are not supplied by private ports |

Confidence in the authority correction is substantially higher than confidence in the total delivery estimate. Reliability8 describes achievable scoped guarantees under exact qualification, not observed availability, all-plugin safety or deployment readiness.

## 6. Experiment disposition

The initial full packed/Host plan and narrower source-contract addendum are retained at `plans/seam-spike-plan.md`. Astra cross-review approved the source-only addendum; root then explicitly authorized exactly three strict/noEmit compiler calls and no SDK/Host/package fallback. That bounded source diagnostic was executed on2026-11-06 with Node24.22.1 and independently installed TypeScript7.0.2, in under the15-minute cap. No dependencies were installed and no production source was changed.

| Exact source-contract assignment | Exit code | Observed diagnostic | Meaning |
| --- | ---: | --- | --- |
| Current AR → same current AR | 0 | No diagnostics | Environment/resolution setup control only |
| External legacy PR1 → current AR | 1 | TS2322, `driver.observe()` can yield `compaction`, absent from AR `Event` | These exact declared factory contracts cannot substitute unchanged in this direction |
| Current AR → external legacy PR1 | 1 | TS2322, `driver.respondToInteraction` cannot accept external question denial without answers | Reverse direction also incompatible; not a capability advertisement test |

The emitted `listFiles` inventories match the six AR source files and three external contract source files declared in the plan, plus compiler standard libraries and the11 total fixture TS lines. The real Claude public facade and factory were inspected/hashed as provenance: its explicit return annotation is the exact external `DriverFactory`. Their SDK implementation closure was **not compiled or executed**. No package was built/packed, no public Host was run, no real provider/authentication was used, no runtime result was observed, and no state/custody guarantee follows from the type outcomes. The compiler used strict checking, `skipLibCheck:false`, exact optional properties, unchecked-index checking, NodeNext/ES2024 and `types:[]`; no assertions/suppressions/shims/copied SPI were used.

Retained raw evidence: `seam-probe/source-manifest.json` (commits, every source blob/SHA256, wrapper and resolved native TS7.0.2 executable identity), `results.json` (exact commands/exit codes/output hashes/compiler-listed closure), all three `.ts` inputs/configurations and their separate stdout/stderr files. The11 exact original files are retained under `source-snapshots/` with a separate snapshot manifest and reproduction README. `external-pr1-observed.json` preserves the fetched PR body/draft/head and explicit legacy Desktop scope. This source comparison confirms exploratory incompatibility, not a supported-release bug or an intended ADR0091 delivery blocker. No fourth compiler invocation or further experiment followed the decisive result. Independent Astra result review verified all11 hashes/pins, the setup control and both semantic TS2322 results, with no missing-module/dependency error mistaken for incompatibility.

## Primary source ledger

All retrieved 2026-11-06. GitHub source links carry exact commits; moving docs are called out. Read-only investigation did not execute upstream tests.

### Agent Runtime at f990acc26e1b8071ae22d0b87a2ddd3672be8e2e

- AR1 — [ADR-0091, accepted2026-10-21](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md).
- AR2 — [Interactive erased source barrel](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/interactive-contracts.ts), [exact provider SPI](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/interactive-agent-session/application/ports/outbound/interactive-provider-driver.ts), [package export map](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/package.json).
- AR3 — [Erased SPI outside-checkout package test](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/tests/package/interactive-contracts-packed-consumer.test.ts).
- AR4 — [Ordinary default/optional Host Custody](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/host-custody-optional-default.md).
- AR5 — [Contained kernel provider/custody ports](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/application/ports/outbound/contained-turn-execution-ports.ts), [exact product composition](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/contained-turn-feature-composition.ts), [ADR0012 owner separation](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0012-provider-access-authority-in-contained-turn-composition.md).
- AR6 — [Feature cancellation/output limits](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/README.md), [qualification registry](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/qualification-registry.json).
- AR7 — [ADR0090 accepted ordinary profile](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0090-ordinary-user-session-codex-execution-profile.md), [ordinary ports](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/application/ordinary-ports.ts), [concrete config](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/adapters/outbound/ordinary-codex/ordinary-codex-config.ts).
- AR8 — [Interactive public composition factory](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/interactive-session-host.ts), [Host dependency contracts](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/features/interactive-session-runtime/composition/interactive-session-runtime.contracts.ts).
- AR9 — [Interactive Host tests](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/tests/features/interactive-session-runtime/host.test.ts), [prospective qualification plan](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/spikes/interactive-session-c-first-slice-qualification.md), [readiness authority](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/readiness.md).
- AR10 — [Draft experiment README](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/experiments/interactive-provider-contract/README.md), [separate packed experiment test](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/experiments/interactive-provider-contract/test/packed-consumer.test.ts).

### Accessible external provider prototype

- EXT1 — [PR1, observed open](https://github.com/agent-teams-ai/old-provider-implementations/pull/1), [bootstrap source](https://github.com/agent-teams-ai/old-provider-implementations/tree/97785f6096dd25c43c80394dbd58f416798069f2), [PR2, observed open](https://github.com/agent-teams-ai/old-provider-implementations/pull/2).
- EXT2 — [PR1 README and extraction provenance](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/README.md).
- EXT3 — [Exact separate session contract](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-session-contracts/src/features/provider-session-contracts/contracts/session.ts).
- EXT4 — [Public Claude facade](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-implementations/src/claude.ts), [actual factory return signature](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-implementations/src/features/provider-session-implementation/adapters/claude-sdk/factory.ts).
- EXT5 — [Own-contract packed provider test](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-implementations/tests/package/packed-consumer.test.ts), [private package/exports](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-implementations/package.json).

### Mature primary comparisons

- BS1 — [Backstage extension points, moving official docs](https://backstage.io/docs/backend-system/architecture/extension-points/); [module constraints, moving official docs](https://backstage.io/docs/backend-system/architecture/modules/).
- BS2 — [Release/version/skew/producer policy, moving official docs](https://backstage.io/docs/overview/versioning-policy/).
- BS3 — [Exact catalog extension point source, blobac41d383d5bf991d9b35b5a08e59082b0458f755](https://github.com/backstage/backstage/blob/3978b972588f333882991d98a52a5d855f6afa05/plugins/catalog-node/src/extensions.ts).
- BS4 — [Exact GitHub module, blob6177b886973a52a81b845cb6ccbfab4caa46d69b](https://github.com/backstage/backstage/blob/3978b972588f333882991d98a52a5d855f6afa05/plugins/catalog-backend-module-github/src/module/githubCatalogModule.ts).
- VS1 — [Exact published-shape declaration source](https://github.com/microsoft/vscode/blob/29ad5e7ec8d963aa67226f58a4472697b21d6f35/src/vscode-dts/vscode.d.ts).
- VS2 — [Extension capability categories/restrictions, moving official docs](https://code.visualstudio.com/api/extension-capabilities/overview).
- VS3 — [Engine compatibility and package delivery, moving official docs](https://code.visualstudio.com/api/working-with-extensions/publishing-extension#visual-studio-code-compatibility).
- VS4 — [Proposed API compatibility/publication limits, moving official docs](https://code.visualstudio.com/api/advanced-topics/using-proposed-api).
- VS5 — [Runtime extension permissions, moving official docs](https://code.visualstudio.com/docs/configure/extensions/extension-runtime-security).
- VS6 — [Extension Host placement/lazy activation/performance, moving official docs](https://code.visualstudio.com/api/advanced-topics/extension-host).
