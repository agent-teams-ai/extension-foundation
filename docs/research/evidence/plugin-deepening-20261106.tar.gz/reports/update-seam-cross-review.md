# Independent cross-review: admitted interactive contract versus legacy provider extraction

Date: **2026-11-06 UTC**. Reviewer: update-policy investigator. Scope: independent read of the seam research/plan, exact relevant source, and fresh PR metadata. No production edits or additional experiment execution.

## Disposition

**Pass the authority correction and narrowed source-contract diagnostic; require the legacy-target limitation at the recommendation, not only in the appendix.** Existing ADR-0091 is a materially stronger basis for further provider-contract investigation than inventing a second contained-turn SPI around an unnamed behavior. This is a correction to evidence and work priority. It does not make the old external provider PR the intended current AR artifact, qualify deployment, or authorize changing frozen contained-turn.

### Independently verified current AR authority and source

I read accepted ADR-0091 in full and independently inspected the curated `src/interactive-contracts.ts`, exact interactive provider port, package export map, public `createInteractiveSessionHost` and erased-SPI package test at AR `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`.

ADR-0091 admits the additive interactive feature, erased runtime-owned SPI and external implementation direction under the existing A–F instruction. The code has a private `0.0.0` package with an explicit erased subpath and a real Host composition source that captures provider/store/authority/custody/context and resource ownership. Accepted contract, source implementation, package accessibility, actual independent consumer, real-provider operation and supported deployment are still different evidence classes. Do not describe them collectively as a released, qualified integration. [C1–C3]

The existing package test manually stages dist and manifest, creates/extracts an archive outside checkout, then strictly compiles the erased type closure without SDK/workspace dependencies and checks no runtime exports. That is valuable, narrow evidence if executed. It is not an ordinary package-manager installation of the entire dependency graph, and I did not rerun it. A new contracts package is not implied by `private: true` or by a source-contract mismatch. [C3]

### Independently verified legacy extraction target

A fresh GitHub metadata read of `agent-teams-ai/old-provider-implementations` PR1 returned open, draft, unmerged, head `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`, base `bootstrap` at `97785f6096dd25c43c80394dbd58f416798069f2`, observed **2026-11-06**. Its body explicitly assigns the extraction to the existing Desktop migration, preserves Desktop ownership of durable inputs/process custody/product state, and excludes future Orchestrator/runtime work. The PR body is mutable metadata; the head pins the inspected source, not an immutable copy of that body. [C4]

Local exact source independently confirms the extraction donor `4e37051ed390da84842eb27535c8e9b07a0364b7`, separate provider-session-contracts, the additional `compaction` event/question-denial variants, and a Claude factory explicitly returning that separate contract's `DriverFactory`. Exact inspected blobs: external contract `bd4668e0cf16ee7c2c2eb0d7b63863049b7cb5f6`, factory `5da0f3dca76bed8f69e8358aea3783f4c695c91e`, extraction provenance `3bc5ab8566050186a4f01a576bdc97a18439fb08`. [C5]

This establishes an **exploratory mismatch between two exact source snapshots**. It does not establish that current AR intended to support that legacy PR unchanged, that a supported release regressed, or that ADR-0091 delivery requires merging/fixing that PR. Reconcile target consumer and lineage before recommending a mapper, contract widening or package extraction. A truthful versioned contract split may be correct.

## Plan review

The initial packed-plus-Host H1/H2 plan is unnecessary before its provenance/compatibility prerequisite is resolved. The narrower strict TypeScript source-contract probe is reasonable: unchanged AR and external public type closures, AR→AR setup control, external→AR primary check and reverse directional diagnostic, exact compiler/source hashes, `noEmit`, strict/no suppression, no dependency installation or runtime/SDK execution. It can tell whether and why those source types substitute. It cannot establish packed installation, the factory implementation's full closure, a real Host journey or intended-release compatibility.

The AR→AR control validates the setup, not independent behavior. The external→AR case must remain a normal failed compiler result when it rejects, rather than a green expected-failure qualification. Stop after the decisive result; no implicit compatibility shim, contract promotion, SDK build or H2 fallback follows. I did not review a completed result because none was available at this review cut.

### Subsequent report correction and result-artifact review

The seam investigator incorporated the requested provenance limit in the top recommendation and §2 and narrowed the package-test language to manual archive extraction/type-closure evidence. I reread those corrected sections: the remaining recommendation no longer treats the legacy PR as an intended ADR-0091 blocker.

The bounded source probe then became available. I independently read all three tiny consumer inputs, common compiler configuration, recorded commands/exit codes, compiler-listed source closures and raw diagnostics without rerunning the compiler. Recorded AR→AR exits 0; legacy→AR exits 1 with TS2322 on the additional `compaction` output; AR→legacy exits 1 with TS2322 because question-denial replies without answers are not admitted by current AR. The listed non-library files match the planned six AR and three external contract sources plus the relevant consumer. No SDK/factory implementation or runtime Host appears in that compiled closure. The two failures are semantic assignability diagnostics, not missing-module failures. **Pass this narrow artifact/result interpretation.** I did not independently rehash every retained source snapshot; the separate plan/result critic performed that check. Evidence: `seam-probe/results.json`, the three `.ts` inputs/configurations and separate stdout/stderr.

**Ordinary update policy need not block this investigation.** The admitted type/export and static startup-composition boundary can be inspected and tested without choosing whether persistent sessions are interrupted for maintenance. Actual runtime restart/rollout qualification later needs the chosen session/queue/continuity policy. Avoid a new dependency that makes an unanswered maintenance preference prevent already authorized contract provenance work.

## Interaction with update-policy estimates

The existing SPI can support contract investigation while all update policies remain proposed. A persistent interactive session must not inherit a bounded-turn update estimate: close rejects queued undispatched inputs, never reopens, and exact checkpoint restore creates a new generation without restoring effect truth or callbacks. Any transparent continuity promise remains unestimated. The independent update report's proposed local admission ranges, if supplied, must be visibly partial and conditional; they cannot be transferred to this admitted interactive delivery.

## Primary sources

All source inspection/metadata retrieval above occurred **2026-11-06 UTC**.

- C1 — [AR accepted ADR-0091](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md), blob `d492a490f0c6c04434d4560840802a25eedd5d29`.
- C2 — [AR erased barrel](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/interactive-contracts.ts), [provider port](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/interactive-agent-session/application/ports/outbound/interactive-provider-driver.ts), [public Host composition source](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/interactive-session-host.ts).
- C3 — [AR package exports](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/package.json), [erased SPI archived-consumer test source](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/tests/package/interactive-contracts-packed-consumer.test.ts).
- C4 — [Old-provider PR1](https://github.com/agent-teams-ai/old-provider-implementations/pull/1), current metadata/body observed at this review; source head/base listed above.
- C5 — [External contract](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-session-contracts/src/features/provider-session-contracts/contracts/session.ts), [factory](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/packages/provider-implementations/src/features/provider-session-implementation/adapters/claude-sdk/factory.ts), [source-extraction provenance](https://github.com/agent-teams-ai/old-provider-implementations/blob/7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9/provenance/source-extraction.json).
