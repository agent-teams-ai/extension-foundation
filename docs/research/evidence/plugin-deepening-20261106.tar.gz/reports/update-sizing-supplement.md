# Supplemental comparison budgets for ordinary update mechanics

Date: **2026-11-06 UTC**. Status: hypothetical planning bands only. These are **not source-validated estimates of current AR delivery**, not accepted options, and not a substitute for the unknown whole-product cost in `reports/update-research.md`.

The owner requested separate new/changed production, integration and test LOC per option. The earlier unconditional-looking `P0` is not defensible: current shutdown APIs do not provide an ordinary-update ingress pause, safe resume or atomic quiescence-and-stop. The following offers a narrower conditional comparison without fabricating the missing durable semantics or pretending that persistent sessions are bounded turns.

## Exact hypothetical scope and prerequisites

One trusted local process, one selected **bounded-turn** profile, one owning operation, static composition and controlled restart. No live generation overlap and no new shared runtime/package. Existing operation store, authority, custody, artifact ownership, selected-restart configuration and recovery records remain authoritative.

Before these bands can apply, the actual owning product must already provide:

- A complete authoritative inventory of accepted/pending operations, admission attempts, retained physical resources and reconciliation/cleanup debt for the actual restart closure, not merely a JS call count.
- An existing owner transaction/serialization boundary that can combine the inventory/quiescence decision with admission/stop authority; an external poll and later flag write is insufficient.
- An existing operation/recovery record and boot path that can record/read back selected update identity and distinguish a pre-disposal attempt from irreversible stop. No new canonical update store, schema or distributed protocol is included below.
- Working actual disposal/cutoff/closure ports and an already specified one-instance artifact/start/readiness path. Credential/custody/platform prerequisites are not supplied by the gate.

**The inspected AR surfaces do not establish all these prerequisites.** Designing and implementing missing durable inventory/atomicity/recovery semantics is **outside these bands and currently unestimated**. If those gaps require store or authority changes, these numbers are not a total or a ceiling and should not be presented as the actual residual quote. The present admitted ADR-0091 interactive slice is not this hypothetical profile.

## Conditional local comparison

Columns are disjoint new/changed handwritten LOC. Production includes local contract/owner behavior; integration includes one product update use case and composition/status wiring; tests include focused fixtures and rejecting cases. Exclude existing, mechanically moved/generated/vendor code and documentation. Do not add rows: they are alternatives with substantial shared work.

| Future bounded-turn policy | Production LOC | Integration LOC | Tests LOC | Sizing confidence /10 |
| --- | ---: | ---: | ---: | ---: |
| Safely prepare; defer before seal; atomically begin irreversible stop only at quiescence | **120–300** | **100–250** | **350–800** | **3** |
| Separate bounded temporary fresh-admission pause; abort attempt and safely resume before any irreversible action | **220–500** | **150–350** | **550–1,200** | **3** |
| Separate fresh-admission gate; grace for accepted work; then existing authorized cutoff/disposal and exact closure | **160–350** | **180–400** | **500–1,100** | **3** |
| Literal indefinite permanent seal-and-wait | Not a recommended comparison budget | Not estimated | Not estimated | No ordinary availability promise |
| Persistent interactive continuity across update | **Unknown** | **Unknown** | **Unknown** | **2** |

The ranges are approximately factor-of-two engineering hypotheses for these **local mechanics only**, not measurements. Their upper endpoints do not include unknown missing prerequisite work. Reliability/complexity judgments and different availability/interruption promises are in the main report; equal reliability numbers cannot imply equal user experience.

### Why these are nonzero production changes

The inspected `AgentRuntimeHostDisposalLifecycle` exposes disposal, active-call tracking and contained operation status/cancellation, but no ordinary-update gate. `HostDisposalOrchestrator.dispose()` irreversibly marks disposed and requests cancellation; its wait retry does not resume. Current provider owners' `sealAdmission` also blocks delegated preparation/creation. A local policy therefore needs real new owner behavior at **new-operation ingress**, without using those shutdown seals for natural grace. [U1]

For the first row, the production allowance covers a narrow typed eligibility/result contract, a new-admission ordering branch joined to the owner's already available complete inventory, and an irreversible stop transition only when the authoritative predicate succeeds. Integration prepares permitted candidate checks, invokes that owner operation, records pending/refused/started status through existing records and calls existing disposal/start/readiness in order. Tests cover an acceptance already ahead of the barrier, fresh-identity rejection/absence after commit, non-quiescent defer while service still works, stale authority and missing physical closure. It does not build the authoritative inventory or atomic store protocol.

The second row additionally needs attempt-specific pause ownership, preserved reply/control/observe/reconcile paths, bounded attempt-abort and authority/head/health checks before releasing only its own temporary gate. Tests add failed drain with accepted unresolved work, continued reply progress, stale timeout/resume refusal, candidate cleanup debt and no resume after permanent stop. No mutation of the current shutdown flag is included.

The third row shares the separate ingress/accepted-cohort work, but does not implement resume after cutoff. Integration adds the product's selected grace and existing exact cancellation/disposal/closure status, retaining unknown outcomes. Tests distinguish request/receipt/physical closure and ensure irreversible state stays sealed. Actual current `dispose()` cannot be used to start a natural grace because it requests cutoff immediately; the new gate precedes it. [U1]

## Exclusions that can dominate real delivery

Authoritative accepted-work enumeration across crash/restart, new durable transaction/fencing semantics, cross-process admission, schema changes/migration, candidate artifact custody, real provider process qualification, output/effect reconciliation, native delivery/signing, real credentials/tools, product/UI experience, health/readiness implementation, backup/restore, release/support/OS qualification, and optional Temporal adaptation are all separately scoped. A new generic manager or parallel store is neither included nor recommended.

Persistent interactive sessions add unresolved session/queue/continuity promises. Existing close rejects queued undispatched inputs; restore is explicit and exact and does not restore effect truth. No bounded-turn arithmetic should be substituted for that work. [U2]

**Maintenance policy does not block current contract investigation.** The existing ADR-0091 erased type/export provenance and independent provider-contract investigation can continue at static startup boundaries while ordinary maintenance preference remains open. Defer runtime update qualification until the actual session/queue policy and missing owners are concrete.

## Review and sources

Independent `deep_plan_critic` reviewed these proposed bands and accepted them **only** as supplemental low-confidence hypothetical local-mechanics budgets, requiring the complete accepted-work/debt inventory and same-authority atomicity prerequisites above. The critic rejected treating them as current interactive residual work or a source-validated whole-delivery estimate. No implementation or benchmark validates these ranges.

- U1 — AR `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`: [disposal interface/implementation](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/agent-runtime-host-disposal.ts), [Codex current owner](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/composition/codex-current-kernel-owner.ts), source-inspected 2026-11-06; exact blobs retained in the main report.
- U2 — [Accepted AR ADR-0091 at the same pin](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md), full source-inspected 2026-11-06.
