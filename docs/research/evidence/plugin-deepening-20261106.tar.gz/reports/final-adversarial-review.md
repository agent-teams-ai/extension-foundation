# Final adversarial review of the deepened plugin recommendation

Date: **2026-11-06 UTC**. Scope: independent source and retained-evidence review. No compiler, provider, package, Host, lifecycle or capacity scenario was run. No governed decision, production source or external repository was changed by this reviewer.

## Disposition

**The two central corrections survive adversarial review:** withdraw contained-provider-first as the current recommendation, and replace the ambiguous permanent-seal-and-defer promise with explicitly different service/update policies. Neither correction justifies a new manager, contract owner, runtime or implementation campaign. The currently reviewed reports already preserve the most important qualifications. Final synthesis should retain the material scope conditions below prominently rather than relegating them to an evidence appendix.

This is not a finding that the whole plugin architecture is complete. It is a correction to an incorrectly narrowed first-slice recommendation and to an underspecified update promise.

## 1. The admitted provider journey must not substitute for the broad customization goal

I independently read accepted AR ADR-0091 in full at `f990acc26e1b8071ae22d0b87a2ddd3672be8e2e`, together with the current modular-research reconciliation. ADR-0091 selects the scoped persistent Claude/session extraction, erased runtime-owned contract, external implementation direction and product consumers. It explicitly freezes contained-turn and declines to widen the ordinary Codex profile. The modular-research document separately says its future harness shortlist neither reopens nor replaces that admitted path. Consequently, the earlier contained-first preference was based on incomplete authority at the **same pin**, not a newly changed upstream decision. [A1, A2]

**Material synthesis requirement:** say both that this is the correct current provider slice and that it is only one customization family. It does not settle supported UI contributions, commands, data formats, product-owned extension points, ordinary libraries, build-time product variants, public publication, hostile execution or a complete authoring experience. Do not translate “ADR-0091 is already selected” into “the broad user plugin vision is already selected or delivered,” or ask the user to choose that accepted slice again.

The existing EF customization research already distinguishes what is variable, when binding changes, compatibility and trust/failure placement; it also distinguishes contribution, replacement, ordered composition, plugin-owned extension and product variant. Reuse that map instead of manufacturing a new universal API or suggesting every useful plugin implement the interactive provider interface. The real gap is coverage and qualification of useful user journeys through their existing owners. A normal contribution author should not inherit Host retirement, receipt or custody machinery merely because one provider family needs it. [F1]

I found no source basis for rejecting the interactive direction in favor of a generic platform rewrite. Equally, no inspected source proves that this direction alone covers the user's hundreds/thousands-of-plugins goal. Installed artifacts, selected graph, active instances, sessions, processes and churn remain distinct capacity dimensions.

## 2. Preserve the legacy comparison's exact scope

The retained external PR metadata explicitly places `old-provider-implementations` PR1 under legacy Desktop extraction and excludes future Runtime/Orchestrator work. The compared source head is `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`; it is not established as the intended ADR-0091 delivery. The HTTP404 for the named `provider-implementations` repository is an access observation, not proof of nonexistence. [P1]

**Material synthesis requirement:** the two failed assignments are exploratory compatibility evidence for those exact snapshots. They establish neither a supported-release regression nor an ADR-0091 implementation blocker. They do not justify merging the old PR, widening AR, dropping compaction, adding a shim, or extracting contracts into another owner. Identifying the intended implementation and its reviewed contract revision is a provenance task before actual integration; it is not automatically a new architecture vote.

ADR-0091 itself permits a separately packed runtime-owned contracts package only if isolated packaging proves the private runtime package cannot supply the type dependency. This source probe supplies no such packaging result. The current report correctly distinguishes the existing manually archived erased-type test from full package-manager dependency installation. [A1, P2]

## 3. Update policy repair is valid, but its ranking stays conditional

I independently inspected `HostDisposalOrchestrator`, the interactive Host implementation and ADR-0091. Actual disposal sets the permanent disposed/closing state before cleanup; retrying a failed wait does not reset that state. Interactive close rejects queued undispatched inputs and never reopens a session. A pause that blocks reply/control/observation needed by existing work would undermine the proposed natural drain. A finished turn does not establish that a persistent session, interaction, checkpoint, retained process or cleanup obligation has ended. [A1, A3, A4]

Thus permanent seal plus indefinite unresolved work can leave fresh admission unavailable indefinitely. That consequence does not need another simulation. Current source does not establish the new reversible pause or atomic quiescence-and-stop needed by the proposed alternatives. A homemade gate in the old RST fixture would not establish it either. **The no-new-update-spike disposition is correct.** Reused RST evidence remains fixture evidence about its original boundaries.

**Material synthesis requirement:** permission for downtime is not selection of indefinite maintenance, forced cancellation, preservation of every live session, or starvation of updates. Prefer pre-seal deferral only under its stated objective of keeping healthy service active and preserving accepted work. It may postpone an update indefinitely. A deliberate maintenance policy may instead be right when the owner values progress and accepts interruption, but physical/effect uncertainty still prevents an unconditional completion deadline. Neither policy is already selected here.

“Affected scope” must remain the actual dependent/process/resource closure to restart, not merely one plugin identifier. Preserve the existing distinction between safe inert validation and preparation that requires exclusive resources or incompatible migration. Safe checks before shutdown cannot establish that replacement startup will succeed after the old owner retires. Update failure and serving failure need separate honest status, without inventing another canonical store or coordinator. [F1, U1]

The unanswered maintenance choice need not block source-contract provenance, independent packaging work authorized under ADR-0091, or ordinary static startup composition. It belongs before the actual runtime restart claim.

## 4. The observed probe supports only the claims now attached to it

I read the three consumer inputs, compiler configurations, README, recorded results and raw semantic diagnostics. The setup assignment uses the same AR contract on both sides and exits 0. Legacy-to-AR exits 1 with TS2322 because `observe()` admits the additional `compaction` event. AR-to-legacy exits 1 with TS2322 because AR's question reply does not accept the external denied-question form without answers. The recorded strict configuration uses no emit, no library skipping, exact optional properties and no ambient package types. The 11 fixture lines add no assertion, suppression or copied interface. [P2]

The source aliases deliberately resolve source barrels. The external Claude facade/factory annotation is provenance; its SDK implementation closure is not compiled. These are three compiler invocations, not three runtime scenarios, a package test, full factory compilation, a real provider exercise or Host E2E. A compiler reporting one decisive mismatch per direction does not certify that these are the only possible semantic differences. The report need not enumerate hypothetical differences to preserve that limit.

I did not rehash the snapshots or rerun the compiler; the independent plan/result critic's 11/11 byte/hash review remains that reviewer's evidence. I found no discrepancy between retained diagnostics and the final seam-report interpretation. No additional execution is warranted by this review.

## 5. Numerical comparisons are partial planning aids, not delivery estimates

The supplemental update bands explicitly assume a bounded-turn profile with existing complete accepted-work/debt inventory, same-owner serialization/atomicity, recovery records, custody and a specified restart/readiness path. Those prerequisites are not all established in the inspected product; implementing them lies outside the ranges. The actual admitted interactive slice is not that hypothetical profile. [U2]

**Material synthesis requirement:** place “unknown whole-delivery cost” beside the numbers, not several paragraphs away. Label the bands local mechanics, confidence 3/10, and nonadditive alternatives. Keep production, owning-product integration and focused tests separate. The old `P0` should not survive as an unconditional residual quote for new gate, quiescence, recovery or continuity semantics. Existing implementation inventory and moved/vendor/generated code are not new handwritten LOC.

Reliability 8/10 means a judgment about the named achievable contract after qualification. It is not measured uptime, equal availability, a likelihood of safe untrusted execution, or evidence of ecosystem-scale capacity. Confidence in the authority correction is high; confidence in whole delivery remains low. The reports currently make these distinctions; a condensed comparison must preserve them.

## Reviewed material and primary anchors

Reviewed the complete common owner brief; seam, update, process-plugin, sizing, cross-review and plan-critique reports; both spike plans; probe README/inputs/configurations/results/diagnostics; accepted ADR-0091; relevant current lifecycle source; current AR modular-research reconciliation; EF OD-003's current provider/update proposal; and EF's broad customization/authoring material. This review does not independently revalidate all upstream industry fetches or execute upstream tests.

- **A1:** [AR ADR-0091, exact inspected pin](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md).
- **A2:** [AR modular-research reconciliation at the same pin](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/agent-runtime-modular-research.md).
- **A3:** [Host-disposal source](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/agent-runtime-host-disposal.ts).
- **A4:** [Interactive Host source](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/features/interactive-session-runtime/application/use-cases/create-session-host.ts).
- **F1:** [EF customization map at research head 99a5b9](https://github.com/agent-teams-ai/extension-foundation/blob/99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d/docs/research/customization-without-forks-and-scale.md).
- **P1:** Retained `seam-probe/external-pr1-observed.json`, plus report provenance for the exact repository-access observation.
- **P2:** Retained `seam-probe/README.md`, three `.ts` inputs/configurations, `results.json`, separate stdout/stderr; `reports/plan-critique.md` documents the independent source-hash review.
- **U1:** `reports/update-research.md`, including bounded source-search scope, failure outcomes and no-new-spike disposition.
- **U2:** `reports/update-sizing-supplement.md`, including the absent prerequisite work and whole-delivery exclusions.

Final governed synthesis was not yet present at this review cut. Its subsequent review, if requested, should be recorded as an addendum rather than implied by this verdict.

## Subsequent governed-draft review

Read the complete new `authoring/docs/research/plugin-choice-deepening-2026-11-06.md` and the corrected OD-003 provider/update section, including its surrounding shared-mechanics choices. **Pass the substantive synthesis.** The broad-capability limitation is now prominent immediately after the authority correction. The source probe is expressly source-only, its legacy comparison is not an ADR-0091 blocker, update alternatives remain proposed, no new update experiment is claimed, and conditional local-mechanics costs sit beside absent prerequisites and unknown total delivery. The existing authority/custody separation and optional Temporal boundary remain intact.

One concrete consistency correction was sent to root: the older OD-003 Shared Host Mechanics paragraph still says “The next actual owner choice is the first real capability.” In the now-corrected document that can be read as reopening the accepted provider direction. Qualify it as the next **additional** capability or shared Host mechanism beyond already admitted work, with its actual availability/trust/deployment/lifetime promise. This is a navigation/authority clarification, not a new architectural decision or a request to implement anything.

This verdict covers document content at the review cut. It does not claim that evidence archives already exist, that documentation gates passed, that a particular commit was pushed, or that hosted CI qualified the resulting exact head; those publication checks belong to root's subsequent delivery.
