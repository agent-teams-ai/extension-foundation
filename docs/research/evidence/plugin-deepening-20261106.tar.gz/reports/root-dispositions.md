# Root synthesis dispositions

Date: 2026-11-06 UTC. This records the research delivery before publication checks. No production implementation, accepted ADR, dependency pin, public release or merge is authorized by this record.

## Team and common scope

Two GPT-6.1 Sol xhigh researchers investigated the current extension seam and ordinary-update policy. Two independent GPT-6 Astra xhigh critics reviewed the same significant questions, plans and retained results. The update researcher also independently cross-reviewed the seam and legacy PR provenance. Root read the common findings, exact authority and raw compiler diagnostics, and researched HashiCorp go-plugin/Vault as a third industry lane. Shared owner vision and constraints are retained in brief.md; the primary-source reports supply precise scope and limitations.

## Material findings and dispositions

| Finding | Disposition |
| --- | --- |
| Previous contained-first recommendation overlooked accepted AR ADR-0091 at the exact same f990acc source pin | Correct current OD-003 and maintained navigation; withdraw that recommendation. Do not describe it as upstream drift or request another vote on the accepted interactive direction. |
| Provider extraction is only one author journey | Add prominent caveat in the new synthesis and OD-003. Preserve the existing broader contribution/replacement/composition/trust map; do not impose provider lifecycle on all plugins. |
| Accessible old-provider PR1 explicitly belongs to legacy Desktop and excludes future Runtime/Orchestrator | Retain comparison as exploratory only. No current ADR-0091 implementation blocker, supported release regression, merge or automatic API repair follows. HTTP404 for the named repository remains an access observation. |
| Actual current shutdown seals are irreversible and can fence accepted-but-not-yet-prepared work | Withdraw ambiguous seal/wait/defer and unconditional-looking P0 quote. Preserve actual shutdown semantics. Rank pre-seal deferral only under explicit availability/work-preservation objectives; maintenance remains unselected. |
| Interactive sessions outlive individual turns | Preserve accepted queue rejection on close, unknown cleanup, explicit exact restoration and new generations. No transparent session-migration promise. |
| Reversible pause or atomic quiescence owner API is absent from inspected surfaces | Do not invent one in an old receiver harness. Retain reviewed update plan and no-new-spike disposition. Current contract work is not blocked by that dependent product preference. |
| Narrow source check supplies meaningful directional incompatibility diagnostics | Run exactly the approved three compiler checks, preserve results and stop. No runtime/packed fallback after decisive rejection. |
| Additional shared runtime/native language lacks a demonstrated residual concern | Reuse current owners and mechanisms; preserve library-first direction for a real shared concern, without a second supervisor, state owner or workflow per call. |
| Supplemental LOC requested by owner but complete prerequisites absent | Retain hypothetical local bounded-turn comparison only, P/I/T distinct, sizing confidence 3/10 and whole delivery unknown beside the ranges. Never transfer those numbers to current interactive delivery. |

The second critic's last consistency finding concerned the lower OD-003 Shared Host Mechanics paragraph saying the next owner choice was the first capability. Root changed it to an **additional capability or shared Host mechanism beyond the already admitted AR ADR-0091 provider slice**. That preserves the larger open decision without reopening the accepted journey. No accepted decision body changed.

## Execution census and review

There are exactly three new TypeScript consumer files, 11 source lines total. TypeScript 7.0.2 with strict/noEmit/skipLibCheck:false/exactOptionalPropertyTypes/noUncheckedIndexedAccess returned:

- AR to AR: exit 0, setup control.
- Legacy external to AR: exit 1, TS2322 caused by compaction in returned observations.
- AR to legacy external: exit 1, TS2322 caused by denied-question reply input.

These are source assignability checks using exact public source barrels, not installed packages, full factory compilation, SDK/Host execution or E2E. The independent plan/result critic verified all 11 original contract/signature file hashes against exact Git source. The source closure is 6 AR + 3 external files; 2 additional files establish the actual public Claude facade/factory annotation. Snapshots remain unchanged evidence. Root inspected raw outputs, command/configuration and limitation statements. The final critic read retained inputs/diagnostics independently without rerunning them.

No new update runtime experiment, provider process, Go/Vault/server deployment, dependency install for the probe, real credential route or thousand-provider capacity run occurred. Prior RST experiments and existing upstream tests are retained/reused evidence with their earlier scope, not fresh executions. The source checks do not exhaust every possible contract difference.

## Documentation and publication boundary

Root used the repository's Docs Protocol info/find/new preview and guarded apply, manually added the exact index link and refreshed bounded context. Maintained current research and OD-003 now point to the deeper correction; prior packets remain immutable historical evidence. The evidence archive retains plans, complete investigator/critic reports, source ledgers, exact original probes and raw outcomes.

Publication gates and GitHub receipts are reported separately against the actual final commit. This record does not preclaim them. The installed Engineering Foundation 1.7.2 entry route eagerly reaches API Extractor 7.58.12's embedded TypeScript 5.9.3; prior documented compiler-policy conflict is unchanged. Root does not initialize that legacy route for check/fast/changed or detach/assert-registry, weaken its scope, repin dependencies or claim it passed locally. Frozen registry installation and unchanged dependency/lock inputs remain separately observable; the standalone Docs Protocol route is available. New fixture code was actually checked with TS7.0.2. A hosted pipeline success does not itself erase the embedded-compiler policy gap.
