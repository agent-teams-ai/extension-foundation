# Process plugin cross-check: HashiCorp go-plugin and Vault

Observed 2026-11-06 UTC. Source research only; no Go build, Vault deployment,
plugin binary execution or performance experiment. This is reusable evidence,
not technology adoption, an accepted ADR or production qualification.

## Exact source status

The GitHub API reported go-plugin `v1.8.0`, published 2026-04-29, as its latest
release at this observation. The inspected release commit is
`155dcddc94873a285e14b7fa24b2f6ab6139668e`; moving main was separately observed at
`415e29b9562b51ba63782ecbd719927b022c43eb`. Findings below refer to release bytes,
not an assumption that main and the release coincide. Vault documentation was
the moving v2.x documentation, retrieved on the same date. Exact identities,
URLs and inspected scope are in `sources/process-plugin-pins.json`.

## Consumer contract and implementation are distinct

go-plugin supports consumer-defined interfaces with explicit RPC adapters,
separate plugin executables and protocol version negotiation. Its documented
transport assumptions are local reliable connections, not arbitrary remote
distributed plugin services. These are useful examples of separating a semantic
contract from its transport implementation. Version negotiation alone does not
establish every schema, behavior, capability or deployment combination. [G1]

**Our inference:** keep the accepted AR interactive consumer contract under its
current owner. An external implementation should not import product workflows
or choose custody authority. A structural TypeScript match is one useful check,
not conformance or a supported release promise. This supports checking the real
contract pair rather than extracting a speculative universal SDK.

## A process boundary is not a complete permission boundary

The server explicitly identifies its magic cookie as a launch/UX guard rather
than a security measure. [G3] The release client inherits the host environment
unless `SkipHostEnv` is enabled, can check the executable checksum, and supports
automatic mutual TLS. It rejects checksum verification combined with reattach,
and rejects broker multiplexing combined with reattach. These are separate
configuration constraints, not a universal safe-reconnect contract. [G2]

**Our inference:** a separately running plugin still needs qualified secret,
filesystem, network, effect and child-process policy. A checksum does not choose
grants, and authenticated RPC does not prove the implementation is trustworthy.
Do not infer AR session restoration or a fresh generation's authority from a
PID, socket or connection. ADR-0091's explicit restoration semantics remain the
applicable product contract. [A1]

## Shutdown completion and historical corrections

The release client's `Kill` requests protocol closure, waits up to two seconds
in one graceful phase, then can call the runner's kill with a background
context; deferred cleanup also waits for client goroutines. The two-second
timer is not a total cleanup deadline or proof about every descendant and
external effect. [G2]

The v1.8.0 release records fixes to pipe-wait synchronization and a runner pidfd
leak. These are historical fixes in that release, not evidence that those bugs
remain present. [G4]

**Our inference:** a mature library is valuable, but the exact method's result
must match the caller's claimed guarantee. Reuse current custody; do not turn a
transport shutdown acknowledgement into natural work completion, durable
terminal truth or physical retirement.

## Registration, activation and scale

Vault distinguishes registration in the catalog from activation on a mount. It
checks artifact identity, replicates catalog entries separately from local
artifact distribution, and manages external process lifetime itself. Its
multiplexing-capable plugins can serve multiple mounts/namespaces through one
process. [V1] Vault also distinguishes source repository provenance from
built-in versus external execution, and permits versioned plugin registration
and selection. [V2]

**Our inference:** thousands of installed packages do not require thousands of
live processes. Measure catalog size, selected composition, live instances,
sessions, process count and version churn separately. Multiplexing changes the
shared failure domain; it is not automatically suitable for mutually untrusted
authors or tenants. Independent repository, independently published package,
and independent operating authority are different design axes.

## Transfer recommendation and explicit non-selection

Reuse these lessons: narrow consumer contracts, explicit compatibility,
separate registration and activation, product-owned lifetime, honest closure,
and capacity measured by execution profile. No inspected finding justifies a
new Go/Rust sidecar, supervisor or neutral Host for the current trusted static
interactive adapter. A qualified commodity RPC mechanism can be compared if a
future concrete profile requires a process transport; that question has not
been selected by this source review.

## Primary sources

- [G1] [go-plugin README at the inspected release](https://github.com/hashicorp/go-plugin/blob/155dcddc94873a285e14b7fa24b2f6ab6139668e/README.md).
- [G2] [Release client implementation](https://github.com/hashicorp/go-plugin/blob/155dcddc94873a285e14b7fa24b2f6ab6139668e/client.go), inspected config, Start, Kill and related guard excerpts.
- [G3] [Release server implementation](https://github.com/hashicorp/go-plugin/blob/155dcddc94873a285e14b7fa24b2f6ab6139668e/server.go), inspected handshake/config and serve guards.
- [G4] [Release v1.8.0](https://github.com/hashicorp/go-plugin/releases/tag/v1.8.0), GitHub API release body retrieved successfully; a later search-service page open failed and is not substituted for the API observation.
- [V1] [Vault plugin architecture](https://developer.hashicorp.com/vault/docs/plugins/plugin-architecture), moving documentation.
- [V2] [Vault plugin ecosystem](https://developer.hashicorp.com/vault/docs/plugins), moving documentation.
- [A1] [Accepted AR ADR-0091](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md).
