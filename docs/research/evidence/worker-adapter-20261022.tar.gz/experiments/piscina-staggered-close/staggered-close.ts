import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Piscina } from 'piscina';

type Outcome = { status: 'fulfilled'; value: unknown } | { status: 'rejected'; name: string; message: string };
type Task = { state: SharedArrayBuffer; slot: number; id: string };
const filename = fileURLToPath(new URL('../../worker-adapter/dist/piscina-worker.js', import.meta.url));
const manifestPath = new URL('../../worker-adapter/node_modules/piscina/package.json', import.meta.url);
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as { name: string; version: string };
const init = new Int32Array(new SharedArrayBuffer(64));
const cells = new Int32Array(new SharedArrayBuffer(64));
function release(state: Int32Array, slot: number): void { Atomics.store(state, slot, 1); Atomics.notify(state, slot); }
function observe(p: PromiseLike<unknown>): Promise<Outcome> { return Promise.resolve(p).then(value => ({ status: 'fulfilled' as const, value }), (error: unknown) => ({ status: 'rejected' as const, name: error instanceof Error ? error.name : typeof error, message: error instanceof Error ? error.message : String(error) })); }
async function until(f: () => boolean): Promise<void> { const deadline = Date.now() + 3000; while (!f()) { if (Date.now() > deadline) throw Error('barrier timeout'); await delay(1); } }
release(init, 1);
const pool = new Piscina<Task, string>({ filename, minThreads: 2, maxThreads: 2, maxQueue: 4, closeTimeout: 1000, workerData: { init: init.buffer } });
const errors: string[] = []; const exits: { code: number }[] = [];
pool.on('error', (error: Error) => errors.push(error.message));
for (const worker of pool.threads) worker.on('exit', code => exits.push({ code }));
const watchdog = setTimeout(() => { console.error('WATCHDOG'); process.exit(2); }, 6000);
try {
  const a = observe(pool.run({ state: cells.buffer, slot: 0, id: 'A' }));
  const b = observe(pool.run({ state: cells.buffer, slot: 4, id: 'B' }));
  await until(() => Atomics.load(cells, 0) === 1 && Atomics.load(cells, 4) === 1);
  const beforeClose = Array.from(cells.slice(0, 8));
  const closing = observe(pool.close({ force: false }));
  release(cells, 1);
  const earlyClose = await Promise.race([closing, delay(300).then(() => ({ status: 'pending-after-300ms' as const }))]);
  const afterOneRelease = { earlyClose, cells: Array.from(cells.slice(0, 8)), errors: [...errors], exits: [...exits] };
  release(cells, 5);
  const [aResult, bResult, closeResult] = await Promise.all([a, b, closing]);
  const result = { name: 'piscina-two-workers-staggered-close-force-false', node: process.version, piscina: manifest.version, beforeClose, afterOneRelease, aResult, bResult, closeResult, cells: Array.from(cells.slice(0, 8)), errors, exits };
  console.log(JSON.stringify(result));
  assert.equal(beforeClose[0], 1); assert.equal(beforeClose[4], 1);
  assert.equal(earlyClose.status, 'fulfilled');
  assert.equal(aResult.status, 'fulfilled'); assert.equal(bResult.status, 'rejected');
  assert.equal(afterOneRelease.cells[5], 0); assert.equal(afterOneRelease.cells[6], 0); assert.equal(afterOneRelease.cells[7], 0);
  assert.deepEqual(errors, []); assert.equal(exits.length, 2);
  console.log(JSON.stringify({ summary: { cases: 1, passed: 1, scope: 'observed premature close and running-task loss in exact two-worker fixture' } }));
} finally { release(cells, 1); release(cells, 5); await pool.destroy(); clearTimeout(watchdog); }
