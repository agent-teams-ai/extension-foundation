# Disposable rejecting fixture: Piscina two-worker staggered close

Executed 2026-10-22. This is **one new rejecting case**, separate from the unchanged
eight-case worker-adapter experiment. It is not a benchmark, production adapter or
multi-platform qualification. It was prompted by a concrete source-level concern,
not a rerun of the prior campaign.

## Exact scope and observed result

The fixture reuses the already installed and integrity-verified Piscina **5.3.2**,
Node **26.11.1**, TypeScript **7.0.2** and Node declarations **26.6.5** from
`../worker-adapter/`. No new dependency installation was performed. `node_modules`
here is a local convenience symlink to that experiment's install; its lockfile,
tarballs and package identity evidence remain there. `compiler.log` records the
selected compiler. The inherited strict configuration keeps
`noUncheckedIndexedAccess` and `exactOptionalPropertyTypes`, with the same explicit
`skipLibCheck:true` dependency-declaration caveat as the parent experiment.

Both workers use the original compiled `piscina-worker.js`/`task.js`; their ordinary
TypeScript sources remain unchanged in the parent experiment. Two tasks are
positively confirmed started by separate Atomics cells before `close({force:false})`.
The library timeout is 1,000ms. Only task A's barrier is released. A 300ms
observation race distinguishes early close from waiting for B; elapsed runtime is
not treated as a performance measurement.

**Observed:** close fulfilled during that race with **no error event** and two
actual underlying Worker exits. A fulfilled and its finally marker ran. B rejected
`Terminating worker thread`; at the early-close snapshot its release, normal
completion and finally cells all remained zero. Releasing B after the snapshot
did not produce completion/finally. The fixture's assertions confirm this exact
rejecting observation; its `cases:1,passed:1` means the failure-mode assertion
passed, **not** that multiworker graceful drain was qualified.

## Source explanation

Installed `piscina/src/index.ts` lines 704–730 initialize a scalar completed-worker
counter, register the same callback once before iterating all workers and once
per worker, and increment that counter whenever the callback sees an empty
worker. The callback does not deduplicate worker identity. Installed
`src/worker_pool/base.ts` lines 106–113 invoke all registered callbacks on task
completion. `dist/index.js` has the same logic. For two busy workers, completion
of one worker therefore reaches the flush count; `close` proceeds to `destroy`
while the other task remains active. This explains the executed observation;
the execution trace is the direct behavioral evidence.

The source-level finding uses the exact installed npm archive, whose `src/index.ts`
matches upstream commit `6c7e54630a8c28a96ce5c0625b463d849d21171c` as recorded by
the parent experiment. Primary pinned sources:

- <https://github.com/piscinajs/piscina/blob/6c7e54630a8c28a96ce5c0625b463d849d21171c/src/index.ts>
- <https://github.com/piscinajs/piscina/blob/6c7e54630a8c28a96ce5c0625b463d849d21171c/src/worker_pool/base.ts>

## Implication and limits

Piscina's fulfilled `close()` cannot independently certify natural task drain,
even when no close-timeout error was emitted, for this exact multiworker case.
The candidate single-worker profile retains its prior positive evidence; no claim
about all one-worker sequences follows. Keep explicit fixed one-worker bounds
for that candidate, independently account every accepted task, and require an
upstream fix or separately demonstrated adapter strategy before promising
multiworker graceful retirement. Do not silently fork/patch the package or
infer physical/effect cleanup from task outcomes.

No cancellation/respawn, concurrent-tasks-per-worker, browser, other OS, churn,
memory, canonical publication/admission, effect or complete retirement test was
added. No second run of this new fixture was performed. The original eight cases
and their repeat are unchanged and distinct evidence.

## Reproduction

Restore the parent experiment's exact frozen dependencies first using its retained
`pnpm-lock.yaml` and reproduction instructions. From this directory, in a fresh
extraction without `node_modules`, build its original worker sources and create the
convenience link before compiling this one fixture:

```bash
/tmp/plugin-portability-toolchain-20261022/bin/node ../worker-adapter/node_modules/typescript/bin/tsc -p ../worker-adapter/tsconfig.json
ln -s ../worker-adapter/node_modules node_modules
/tmp/plugin-portability-toolchain-20261022/bin/node ../worker-adapter/node_modules/typescript/bin/tsc --version
/tmp/plugin-portability-toolchain-20261022/bin/node ../worker-adapter/node_modules/typescript/bin/tsc
/tmp/plugin-portability-toolchain-20261022/bin/node dist/staggered-close.js
```

Keep an existing correct link rather than creating it twice. The commands above
are reproduction instructions; no additional run was executed while writing them.

The 6-second complete watchdog and 3-second positive-start deadlines bound a
broken fixture. Cleanup retains both barriers and destroys the actual pool.

## Honest preflight correction

An initial disposable scratch `.mjs` preflight completed its action but failed
before printing a result because metadata lookup attempted the unexported
`piscina/package.json` package subpath. Its source and exact reported error are
retained as `preflight-source.mjs.txt` and `run-preflight-metadata-error.log`.
That run is **not counted as passing evidence**. The final ordinary `.ts`
fixture reads metadata as a filesystem observation, compiles under the inherited
strict profile, records its result and independently asserts the rejection.
