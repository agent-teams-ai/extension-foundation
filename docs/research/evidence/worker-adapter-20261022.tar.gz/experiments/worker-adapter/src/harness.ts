import assert from 'node:assert/strict';
import { once } from 'node:events';
import { Worker } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
import { Piscina } from 'piscina';
import * as workerpool from 'workerpool';
import type { Task } from './task.js';

type Outcome = { status: 'fulfilled'; value: unknown } | { status: 'rejected'; name: string; message: string };
const results: unknown[] = [];
const watchdog = setTimeout(() => { console.error('WATCHDOG: 30 seconds exceeded'); process.exit(2); }, 30_000);
function error(value: unknown): { name: string; message: string } {
  return value instanceof Error ? { name: value.name, message: value.message } : { name: typeof value, message: String(value) };
}
function observe<T>(promise: PromiseLike<T>): Promise<Outcome> {
  return Promise.resolve(promise).then(value => ({ status: 'fulfilled' as const, value }), value => ({ status: 'rejected' as const, ...error(value) }));
}
async function until(predicate: () => boolean, label: string): Promise<void> {
  const deadline = Date.now() + 3000;
  while (!predicate()) {
    if (Date.now() > deadline) throw new Error(`barrier timeout: ${label}`);
    await delay(1);
  }
}
function release(cells: Int32Array, index: number): void { Atomics.store(cells, index, 1); Atomics.notify(cells, index); }
function memory(): Int32Array<SharedArrayBuffer> { return new Int32Array(new SharedArrayBuffer(64)); }
function task(cells: Int32Array<SharedArrayBuffer>, slot: number, id: string): Task { return { state: cells.buffer, slot, id }; }
function snapshot(cells: Int32Array, slot: number): number[] { return Array.from(cells.slice(slot, slot + 4)); }
function record(name: string, data: object): void { const result = { name, ...data }; results.push(result); console.log(JSON.stringify(result)); }
function piscina(closeTimeout = 1000): { pool: Piscina<Task, string>; init: Int32Array<SharedArrayBuffer>; exits: unknown[]; errors: unknown[] } {
  const init = memory(); release(init, 1);
  const pool = new Piscina<Task, string>({ filename: fileURLToPath(new URL('./piscina-worker.js', import.meta.url)), minThreads: 1, maxThreads: 1, maxQueue: 4, closeTimeout, workerData: { init: init.buffer } });
  const exits: unknown[] = []; const errors: unknown[] = [];
  for (const worker of pool.threads) worker.on('exit', code => exits.push({ code }));
  pool.on('error', e => errors.push(error(e)));
  return { pool, init, exits, errors };
}

async function piscinaGraceful(force: boolean): Promise<void> {
  const { pool, exits, errors } = piscina(); const cells = memory();
  try {
    const a = observe(pool.run(task(cells, 0, 'A')));
    await until(() => Atomics.load(cells, 0) === 1, 'A started');
    const b = observe(pool.run(task(cells, 4, 'B'))); assert.equal(pool.queueSize, 1);
    const closing = observe(pool.close({ force }));
    const late = await observe(pool.run(task(cells, 8, 'late-during-close')));
    assert.equal(late.status, 'rejected');
    release(cells, 1); release(cells, 5);
    const [aResult, bResult, closeResult] = await Promise.all([a, b, closing]);
    assert.equal(aResult.status, 'fulfilled'); assert.equal(closeResult.status, 'fulfilled');
    assert.equal(bResult.status, force ? 'rejected' : 'fulfilled');
    assert.equal(exits.length, 1);
    record(`piscina-close-force-${force}`, { aResult, bResult, closeResult, late, a: snapshot(cells, 0), b: snapshot(cells, 4), exits, errors });
  } finally { release(cells, 1); release(cells, 5); await pool.destroy(); }
}

async function piscinaTimeout(): Promise<void> {
  const { pool, exits, errors } = piscina(50); const cells = memory();
  try {
    const a = observe(pool.run(task(cells, 0, 'A'))); await until(() => Atomics.load(cells, 0) === 1, 'A started');
    const b = observe(pool.run(task(cells, 4, 'B')));
    const closeResult = await observe(pool.close()); const [aResult, bResult] = await Promise.all([a, b]);
    assert.equal(closeResult.status, 'fulfilled'); assert.equal(aResult.status, 'rejected'); assert.equal(bResult.status, 'rejected');
    assert.equal(Atomics.load(cells, 3), 0); assert.equal(exits.length, 1); assert.equal(errors.length, 1);
    record('piscina-close-timeout', { closeResult, aResult, bResult, a: snapshot(cells, 0), b: snapshot(cells, 4), exits, errors });
  } finally { release(cells, 1); release(cells, 5); await pool.destroy(); }
}

async function piscinaReadiness(): Promise<void> {
  const init = memory(); const cells = memory(); const exits: number[] = [];
  const pool = new Piscina<Task, string>({ filename: fileURLToPath(new URL('./piscina-worker.js', import.meta.url)), minThreads: 1, maxThreads: 1, workerData: { init: init.buffer } });
  pool.on('error', () => undefined); for (const w of pool.threads) w.on('exit', code => exits.push(code));
  try {
    const outcome = observe(pool.run(task(cells, 0, 'ready-task')));
    await until(() => Atomics.load(init, 0) === 1, 'module initializer');
    const before = { initialized: Atomics.load(init, 0), ready: Atomics.load(init, 2), taskStarted: Atomics.load(cells, 0) };
    assert.deepEqual(before, { initialized: 1, ready: 0, taskStarted: 0 });
    release(init, 1); release(cells, 1); const result = await outcome; assert.equal(result.status, 'fulfilled');
    await pool.close(); assert.equal(exits.length, 1);
    record('piscina-exported-promise-readiness', { before, readyAfter: Atomics.load(init, 2), result, exits });
  } finally { release(init, 1); release(cells, 1); await pool.destroy(); }
}

async function workerpoolGraceful(): Promise<void> {
  const cells = memory(); let terminateHooks = 0;
  const pool = workerpool.pool(fileURLToPath(new URL('./workerpool-worker.js', import.meta.url)), { minWorkers: 0, maxWorkers: 1, workerType: 'thread', onTerminateWorker: () => { terminateHooks++; } });
  try {
    const a = observe(pool.exec('runTask', [task(cells, 0, 'A')])); await until(() => Atomics.load(cells, 0) === 1, 'A started');
    const b = observe(pool.exec('runTask', [task(cells, 4, 'B')])); assert.equal(pool.stats().pendingTasks, 1);
    const closing = observe(pool.terminate(false, 1000));
    const duringRaw = pool.exec('runTask', [task(cells, 8, 'during-terminate')]);
    const duringAdmission = { pending: duringRaw.pending, stats: pool.stats() };
    const during = observe(duringRaw);
    assert.equal(duringAdmission.pending, true); assert.equal(duringAdmission.stats.pendingTasks, 1);
    const queuedResult = await b;
    assert.equal(queuedResult.status, 'rejected');
    release(cells, 1); const [aResult, closeResult] = await Promise.all([a, closing]);
    assert.equal(aResult.status, 'fulfilled'); assert.equal(closeResult.status, 'fulfilled');
    // Public exec after terminate tests whether terminate is a permanent admission seal.
    release(cells, 9); release(cells, 13);
    const afterTerminate = await observe(pool.exec('runTask', [task(cells, 12, 'after-terminate')]));
    const duringResult = await during;
    assert.equal(afterTerminate.status, 'fulfilled');
    assert.equal(duringResult.status, 'fulfilled');
    record('workerpool-graceful-then-readmit', { aResult, queuedResult, closeResult, duringAdmission, duringResult, afterTerminate, a: snapshot(cells, 0), b: snapshot(cells, 4), terminateHooks, statsAfterReadmit: pool.stats(), exitEvidence: 'public hook only; no underlying Worker exit handle exposed here' });
  } finally { release(cells, 1); release(cells, 5); release(cells, 9); release(cells, 13); await pool.terminate(true); }
}

async function workerpoolTimeout(forceAfterTimeout: boolean): Promise<void> {
  const cells = memory(); let terminateHooks = 0;
  const pool = workerpool.pool(fileURLToPath(new URL('./workerpool-worker.js', import.meta.url)), { minWorkers: 0, maxWorkers: 1, workerType: 'thread', onTerminateWorker: () => { terminateHooks++; } });
  try {
    let settled = false;
    const a = observe(pool.exec('runTask', [task(cells, 0, 'A')])).then(result => { settled = true; return result; });
    await until(() => Atomics.load(cells, 0) === 1, 'A started');
    const closeResult = await observe(pool.terminate(false, 50));
    const atTimeout = { aSettled: settled, a: snapshot(cells, 0), terminateHooks, stats: pool.stats() };
    assert.equal(closeResult.status, 'fulfilled'); assert.equal(settled, false); assert.equal(Atomics.load(cells, 3), 0);
    let forcedResult: Outcome | undefined;
    if (forceAfterTimeout) forcedResult = await observe(pool.terminate(true)); else release(cells, 1);
    const aResult = await a;
    assert.equal(aResult.status, forceAfterTimeout ? 'rejected' : 'fulfilled');
    assert.equal(Atomics.load(cells, 3), forceAfterTimeout ? 0 : 1);
    record(`workerpool-timeout-force-after-${forceAfterTimeout}`, { closeResult, atTimeout, forcedResult, aResult, a: snapshot(cells, 0), terminateHooks, stats: pool.stats(), exitEvidence: 'public hook only; no underlying Worker exit handle exposed here' });
  } finally { release(cells, 1); await pool.terminate(true); }
}

async function directReadinessAndTerminate(): Promise<void> {
  const init = memory(); const cells = memory(); const exits: number[] = [];
  const worker = new Worker(new URL('./direct-worker.js', import.meta.url), { workerData: { init: init.buffer } });
  worker.on('exit', code => exits.push(code));
  try {
    await once(worker, 'online'); await until(() => Atomics.load(init, 0) === 1, 'module initializer');
    const before = { online: true, initialized: Atomics.load(init, 0), ready: Atomics.load(init, 2) };
    assert.equal(before.ready, 0); const readyMessage = once(worker, 'message'); release(init, 1); await readyMessage;
    worker.postMessage(task(cells, 0, 'A')); await until(() => Atomics.load(cells, 0) === 1, 'A started');
    const termination = await worker.terminate(); assert.equal(exits.length, 1); assert.equal(Atomics.load(cells, 3), 0);
    record('direct-online-readiness-termination', { before, readyAfter: Atomics.load(init, 2), termination, exits, a: snapshot(cells, 0) });
  } finally { release(init, 1); release(cells, 1); await worker.terminate(); }
}

try {
  await piscinaGraceful(false); await piscinaGraceful(true); await piscinaTimeout(); await piscinaReadiness();
  await workerpoolGraceful(); await workerpoolTimeout(false); await workerpoolTimeout(true); await directReadinessAndTerminate();
  console.log(JSON.stringify({ summary: { cases: results.length, passed: results.length, node: process.version, platform: process.platform, arch: process.arch } }));
} catch (e) { console.error(e); process.exitCode = 1; } finally { clearTimeout(watchdog); }
