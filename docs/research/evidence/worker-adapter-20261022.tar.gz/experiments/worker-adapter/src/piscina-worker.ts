import { workerData } from 'node:worker_threads';
import { runTask } from './task.js';
const init = new Int32Array((workerData as { init: SharedArrayBuffer }).init);
export default new Promise<typeof runTask>((resolve) => {
  setImmediate(() => {
    Atomics.store(init, 0, 1);
    while (Atomics.load(init, 1) === 0) Atomics.wait(init, 1, 0);
    Atomics.store(init, 2, 1);
    resolve(runTask);
  });
});
