import * as workerpool from 'workerpool';
import { runTask } from './task.js';
workerpool.worker({ runTask });
