import { parentPort, workerData } from 'node:worker_threads';
import { runTask, type Task } from './task.js';
const init = new Int32Array((workerData as { init: SharedArrayBuffer }).init);
Atomics.store(init, 0, 1);
while (Atomics.load(init, 1) === 0) Atomics.wait(init, 1, 0);
Atomics.store(init, 2, 1);
parentPort!.postMessage({ ready: true });
parentPort!.on('message', (task: Task) => parentPort!.postMessage({ result: runTask(task) }));
