export interface Task { state: SharedArrayBuffer; slot: number; id: string }
// Four cells per task: started, release, completed, finally-executed.
export function runTask(task: Task): string {
  const state = new Int32Array(task.state);
  Atomics.store(state, task.slot, 1);
  try {
    while (Atomics.load(state, task.slot + 1) === 0) Atomics.wait(state, task.slot + 1, 0);
    Atomics.store(state, task.slot + 2, 1);
    return task.id;
  } finally { Atomics.store(state, task.slot + 3, 1); }
}
