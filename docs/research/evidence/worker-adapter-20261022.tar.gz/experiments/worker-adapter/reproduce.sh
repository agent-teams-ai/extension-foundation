#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="/tmp/plugin-portability-toolchain-20261022/bin:$PATH"
node --version
pnpm --version
NODE_USE_ENV_PROXY=1 pnpm install --frozen-lockfile --ignore-scripts
pnpm exec tsc --version
pnpm check
pnpm build
node dist/harness.js
