import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { cp, mkdir, mkdtemp, readFile, readdir, realpath, writeFile } from "node:fs/promises";
import { dirname, join, relative } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const experiment = fileURLToPath(new URL("../", import.meta.url));
const inputs = join(experiment, "inputs");
const compiler = join(experiment, "node_modules/typescript/bin/tsc");
const packageManager = process.env.npm_execpath;
assert.ok(packageManager, "Run through pnpm e2e so the exact installed CLI is retained");
const sha256 = (data: Uint8Array | string) => createHash("sha256").update(data).digest("hex");
function object(value: unknown): Record<string, unknown> {
  assert.ok(typeof value === "object" && value !== null && !Array.isArray(value));
  return value as Record<string, unknown>;
}
async function json(path: string): Promise<Record<string, unknown>> {
  const value: unknown = JSON.parse(await readFile(path, "utf8")); return object(value);
}
async function writeJson(path: string, value: unknown) {
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`);
}
async function inventory(path: string, prefix = ""): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  for (const item of (await readdir(path, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const name = prefix + item.name;
    if (item.isDirectory()) Object.assign(result, await inventory(join(path, item.name), name + "/"));
    else { assert.ok(item.isFile(), `Unexpected non-file in package: ${name}`); result[name] = sha256(await readFile(join(path, item.name))); }
  }
  return result;
}
const tagged = (type: string, value: string | bigint) => ({ type, value: typeof value === "bigint" ? { type: "bigint", value: value.toString() } : value });
const requested = tagged("TargetId", "fixture-extension");
const absent = { kind: "not-found", targetId: requested };
// Literal expected facts are independent of B/H, its profile and actual results.
function candidate(target: string, host: string, version: string, evidence: string) {
  return { kind: "candidate", authenticatedHandshakeRequired: true,
    proposedProtocolVersion: tagged("HostProtocolVersion", 3n), observation: {
      targetId: tagged("TargetId", target), hostInstanceId: tagged("HostInstanceId", host),
      supervisorInstanceId: tagged("SupervisorInstanceId", "fixture-supervisor"),
      hostBootGeneration: tagged("HostBootGeneration", 7n),
      componentVersion: tagged("ComponentVersion", version), capabilities: [tagged("HostCapabilityId", "host.control.v1")],
      protocolRange: { minimum: tagged("HostProtocolVersion", 1n), maximum: tagged("HostProtocolVersion", 3n) },
      freshness: { evidenceRef: tagged("HostFreshnessEvidenceRef", evidence), kind: "expiry",
        observedAt: tagged("EpochMicroseconds", 1_000_000n), validUntil: tagged("EpochMicroseconds", 2_000_000n) },
    } };
}
const expectedB = candidate("fixture-extension", "fixture-host-b", "2.0.0-b", "fixture-evidence-b");
const expectedDelegated = candidate("fixture-delegated", "fixture-host-baseline", "1.0.0", "fixture-evidence-baseline");

test("packed public-package integration invokes the unchanged discovery use case", { timeout: 600_000 }, async t => {
  const runs = join(experiment, ".runs"); await mkdir(runs, { recursive: true });
  const runRoot = await mkdtemp(join(runs, "run-"));
  const logs = join(runRoot, "logs"); await mkdir(logs);
  const commands: Record<string, unknown>[] = [];
  const children: Record<string, unknown>[] = [];
  const passed: string[] = [];
  let sequence = 0;
  const run = async (command: string, args: string[], cwd: string) => {
    const result = spawnSync(command, args, { cwd, encoding: "utf8", timeout: 180_000, maxBuffer: 8 * 1024 * 1024,
      env: { ...process.env, npm_config_ignore_scripts: "true", NO_COLOR: "1", NODE_TEST_CONTEXT: undefined } });
    const name = `${String(++sequence).padStart(3, "0")}.log`;
    await writeFile(join(logs, name), (result.stdout ?? "") + (result.stderr ?? ""));
    commands.push({ command, args, cwd: relative(experiment, cwd), status: result.status, signal: result.signal, log: name });
    assert.equal(result.error, undefined, result.error?.message);
    assert.equal(result.status, 0, `${command} ${args.join(" ")}\n${result.stdout}\n${result.stderr}`);
    return result.stdout ?? "";
  };
  const pnpm = (args: string[], cwd: string) => run(process.execPath, [packageManager, ...args], cwd);
  const check = async (name: string, body: () => void | Promise<void>) => {
    await t.test(name, async () => { await body(); passed.push(name); });
  };
  const child = async (cwd: string, mode: string) => {
    const text = await run(process.execPath, ["consumer.js", mode], cwd);
    const value: unknown = JSON.parse(text); const receipt = object(value);
    assert.equal(receipt.mode, mode); assert.equal(typeof receipt.pid, "number");
    children.push({ consumerRoot: relative(runRoot, cwd), ...receipt }); return receipt;
  };
  const base = object((await json(join(inputs, "base-preset.original.json"))).compilerOptions);
  const node = object((await json(join(inputs, "node-preset.original.json"))).compilerOptions);
  const common = { ...base, ...node, strict: true, skipLibCheck: false, types: ["node"] };
  const typed = async (cwd: string, options: Record<string, unknown> = {}) => {
    const config = join(cwd, "tsconfig.e2e.json");
    await writeJson(config, { compilerOptions: { ...common, rootDir: "src", outDir: "dist",
      declaration: true, declarationMap: true, ...options }, include: ["src/**/*.ts"] });
    await run(process.execPath, [compiler, "--project", config, "--pretty", "false"], cwd);
  };
  const packRoot = join(runRoot, "packs"); await mkdir(packRoot);
  const pack = async (cwd: string) => {
    const text = await pnpm(["pack", "--json", "--skip-manifest-obfuscation", "--pack-destination", packRoot], cwd);
    const parsed: unknown = JSON.parse(text.slice(text.indexOf("{"))); const report = object(parsed);
    assert.equal(typeof report.filename, "string"); return String(report.filename);
  };
  const local = (file: string) => `file:${file.replaceAll("\\", "/")}`;
  const core = join(inputs, "get-modular-core-0.5.0.tgz");
  const assembly = join(inputs, "get-modular-assembly-0.5.0.tgz");
  const inputsBefore = await inventory(inputs);
  let packageEvidence: Record<string, unknown> = {};
  try {
    assert.equal((await pnpm(["--version"], experiment)).trim(), "11.25.0");
    assert.equal((await json(join(experiment, "node_modules/typescript/package.json"))).version, "7.0.2");
    assert.equal((await run(process.execPath, [compiler, "--version"], experiment)).trim(), "Version 7.0.2");
    assert.equal(sha256(await readFile(core)), "7943f054427282b68cd57e3f790acca62e14cbae67ea62b227f363a8d2614328");
    assert.equal(sha256(await readFile(assembly)), "6112f57755ff9cf3f7b3379b8f932421499cf5db3320b7e4c3aefd998ec36862");
    const a = join(runRoot, "a"); await cp(join(inputs, "a"), a, { recursive: true });
    const aOptions = object((await json(join(a, "tsconfig.json"))).compilerOptions);
    const parentOptions = object((await json(join(inputs, "root-tsconfig.original.json"))).compilerOptions);
    await typed(a, { ...parentOptions, ...aOptions });
    const aPack = await pack(a);
    const h = join(runRoot, "helper"); await cp(join(experiment, "fixtures/helper"), h, { recursive: true });
    await typed(h); const hPack = await pack(h);
    const b = join(runRoot, "extension"); await cp(join(experiment, "fixtures/extension"), b, { recursive: true });
    const bManifest = await json(join(b, "package.json"));
    await writeJson(join(b, "package.json"), { ...bManifest,
      devDependencies: { "@agent-teams/local-host-control": local(aPack) } });
    await writeJson(join(b, "pnpm-workspace.yaml"), { packages: ["."],
      overrides: { "@plugin-e2e/discovery-helper": local(hPack) } });
    await pnpm(["install", "--ignore-scripts"], b);
    await typed(b);
    await pnpm(["install", "--frozen-lockfile", "--ignore-scripts"], b);
    const bPack = await pack(b);
    const dependencies = { "@agent-teams/local-host-control": local(aPack),
      "@get-modular/core": local(core), "@get-modular/assembly": local(assembly) };
    const manifest = (extended: boolean) => ({ private: true, type: "module",
      dependencies: { ...dependencies, ...(extended ? { "@plugin-e2e/discovery-extension": local(bPack),
        "@plugin-e2e/discovery-helper": local(hPack) } : {}) } });
    const consumer = async (name: string, extended: boolean) => {
      const cwd = join(runRoot, name); await mkdir(cwd);
      await writeJson(join(cwd, "package.json"), manifest(extended));
      await writeJson(join(cwd, "pnpm-workspace.yaml"), { packages: ["."], overrides: {
        "@get-modular/core": local(core), ...(extended ? { "@plugin-e2e/discovery-helper": local(hPack) } : {}) } });
      await pnpm(["install", "--ignore-scripts"], cwd);
      const lock = await readFile(join(cwd, "pnpm-lock.yaml"));
      await pnpm(["install", "--frozen-lockfile", "--ignore-scripts"], cwd);
      assert.deepEqual(await readFile(join(cwd, "pnpm-lock.yaml")), lock);
      return cwd;
    };
    const expanded = await consumer("extended-consumer", true);
    await cp(join(experiment, "consumer"), join(expanded, "src"), { recursive: true });
    await typed(expanded);
    const executeIn = async (cwd: string) => {
      for (const name of ["composition.js", "consumer.js"]) await cp(join(expanded, "dist", name), join(cwd, name));
    };
    const baseline = await consumer("baseline-consumer", false);
    const restored = await consumer("restored-consumer", false);
    await executeIn(baseline); await executeIn(expanded); await executeIn(restored);
    const aInventory = await inventory(await realpath(join(baseline, "node_modules/@agent-teams/local-host-control")));
    await check("isolated strict builds and exact installed package identities", async () => {
      for (const cwd of [baseline, expanded, restored]) {
        assert.deepEqual(await inventory(await realpath(join(cwd, "node_modules/@agent-teams/local-host-control"))), aInventory);
        const selectedCore = await realpath(join(cwd, "node_modules/@get-modular/core"));
        const selectedAssembly = await realpath(join(cwd, "node_modules/@get-modular/assembly"));
        assert.equal(await realpath(join(dirname(dirname(selectedAssembly)), "@get-modular/core")), selectedCore);
        for (const name of ["@get-modular/core", "@get-modular/assembly"])
          assert.equal((await json(join(cwd, "node_modules", name, "package.json"))).version, "0.5.0");
        assert.equal(sha256(await readFile(join(cwd, "consumer.js"))), sha256(await readFile(join(expanded, "dist/consumer.js"))));
      }
      for (const cwd of [baseline, restored])
        await assert.rejects(realpath(join(cwd, "node_modules/@plugin-e2e/discovery-extension")), { code: "ENOENT" });
      assert.deepEqual(await inventory(join(a, "src")), await inventory(join(inputs, "a/src")));
      assert.deepEqual(await inventory(inputs), inputsBefore);
    });
    const initial = await child(baseline, "baseline");
    await check("baseline invokes discovery and preserves delegated outcome", () => {
      assert.deepEqual(initial.results, { primary: absent, delegated: expectedDelegated });
      assert.deepEqual(initial.factories, ["baseline", "discovery"]);
      assert.deepEqual(initial.evaluations, { b: false, h: false });
      assert.deepEqual(initial.observations, { baselineReads: 2, bReads: 0 });
    });
    const selected = await child(expanded, "extended");
    await check("independently packed B and H change A result and preserve delegation", () => {
      assert.deepEqual(selected.results, { primary: expectedB, delegated: expectedDelegated });
      assert.deepEqual(selected.factories, ["baseline", "extension", "discovery"]);
      assert.deepEqual(selected.evaluations, { b: true, h: true });
      assert.deepEqual(selected.observations, { baselineReads: 1, bReads: 2 });
    });
    const reversed = await child(expanded, "extended-reversed");
    await check("enumeration reversal preserves actual selected plan digest and result", () => {
      assert.deepEqual(reversed.preparation, selected.preparation); assert.deepEqual(reversed.results, selected.results);
      assert.deepEqual(reversed.factories, selected.factories); assert.deepEqual(reversed.observations, selected.observations);
    });
    const refused = await child(expanded, "ambiguous"); const refusedReverse = await child(expanded, "ambiguous-reversed");
    await check("real GM ambiguity rejects before all factories and executable B or H", () => {
      const expected = { status: "failed", code: "assembly.prepare.unresolved-binding", diagnostics: [], cause: [{
        consumerImplementationId: "plugin-e2e/discovery/consumer/default", slotId: "source",
        capabilityId: "plugin-e2e/discovery/source", cardinality: "required", groupPath: [],
        candidates: ["plugin-e2e/discovery/baseline/default", "plugin-e2e/discovery/extension/b"] }] };
      for (const receipt of [refused, refusedReverse]) {
        assert.deepEqual(receipt.preparation, expected); assert.deepEqual(receipt.factories, []);
        assert.deepEqual(receipt.evaluations, { b: false, h: false }); assert.deepEqual(receipt.results, {});
        assert.deepEqual(receipt.observations, { baselineReads: 0, bReads: 0 });
      }
    });
    for (const [mode, expected] of [
      ["source-failure", { kind: "unavailable", reason: "source-failure", targetId: requested }],
      ["target-mismatch", { kind: "rejected", reason: "target-mismatch", targetId: requested }],
      ["expiry", { kind: "expired", targetId: requested, validUntil: tagged("EpochMicroseconds", 2_000_000n) }],
    ] as const) {
      const receipt = await child(expanded, mode);
      await check(`installed A preserves ${mode} through selected B`, () => {
        assert.deepEqual(receipt.results, { primary: expected }); assert.deepEqual(receipt.evaluations, { b: true, h: true });
        assert.equal(JSON.stringify(receipt.results).includes("fixture-sensitive-source-failure"), false);
      });
    }
    const independent = await child(expanded, "async-binding");
    await check("old pending source and fresh B instance retain independent bindings", () => {
      assert.deepEqual(independent.results, { fresh: expectedB, old: absent, oldAgain: absent });
      assert.deepEqual(independent.observations, { oldPendingBeforeRelease: true,
        bCallsBeforeOldAgain: 1, bCallsAfterOldAgain: 1, baselineReads: 2, bReads: 1 });
    });
    const removed = await child(restored, "baseline");
    await check("fresh consumer without B restores literal baseline with unchanged A", () => {
      assert.deepEqual(removed.results, { primary: absent, delegated: expectedDelegated });
      assert.deepEqual(removed.factories, ["baseline", "discovery"]); assert.deepEqual(removed.evaluations, { b: false, h: false });
      assert.deepEqual(removed.observations, { baselineReads: 2, bReads: 0 });
    });
    packageEvidence = { aInstalledFiles: aInventory, aSource: await inventory(join(inputs, "a")),
      archives: await inventory(packRoot), roots: { baseline, expanded, restored } };
    assert.equal(passed.length, 10, "Every named scenario must complete successfully");
  } finally {
    await writeJson(join(runRoot, "receipt.json"), { scope: "public-package integration E2E; not product plugin Host or custody",
      status: passed.length === 10 ? "passed" : "failed", node: process.version, platform: process.platform,
      compiler: "7.0.2", manager: "11.25.0", passed, commands, children, packageEvidence, inputs: inputsBefore });
    process.stdout.write(`Evidence: ${runRoot}\n`);
  }
});
