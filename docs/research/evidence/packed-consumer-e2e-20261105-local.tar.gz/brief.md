# Plugin E2E continuation — 2026-11-05

The latest owner instruction is "доделай е2е" after the detailed industry/scale report. Resume practical verification, preserve work, commit/push to existing EF draft PR55. No merge was requested in this thread. Prior authorization covers extensive minimal realistic spikes before large production implementation, planning followed by independent critics, actual E2E rather than pretending documentation is runtime qualification.

## Vision and fixed boundaries
- Deep useful customization without product forks, independent plugins extending other plugins, hundreds/thousands of modules, predictable behavior and author ergonomics.
- Clean Architecture, SOLID, DRY, Pluggable. No overengineering, no blanket feature flags, no generic second Host/PluginManager/supervisor/container.
- GM sole neutral composition owner. EF neutral extension/artifact/trust/protocol/conformance owner; no product domain model or competing composition implementation. Products own concrete points, grants, admission, readiness and state. Existing execution owner keeps physical custody.
- Static composition + controlled restart accepted; optional Temporal adapter only where qualified. TS main language; other language only concrete boundary benefit. Preserve accepted Rust custody decisions, no speculative rewrite.
- New maintained JS-runtime code strict TypeScript >=7.0.2, .ts (no .mts, no TS5.9 compiler initialization even embedded). Read all relevant AGENTS and central engineering standard. Accepted ADRs and frozen evidence immutable.
- Distinguish source docs, inspected implementation, actual execution, historical fixed bugs and proposals. Test names/counts/actual receipts matter. No fake-green runner.
- Major alternatives scores confidence/reliability/complexity /10 plus separately scoped production/integration/test LOC; state uncertainty, no invented precise total.
- Use existing public APIs/real consumers where feasible. If a product seam is absent, identify it exactly and don't call a synthetic demo product E2E. Do all useful bounded work without inventing an entire runtime.
- Skill docs-authoring/DocsProtocol route governs repo docs. Preserve research/counterexamples and independent reports for future agents.

## Current source and evidence
Shared root: /workspace/scratch/f863b9d38368/plugin-industry-2026-11-05/repos
EF checked out docs/plugin-research-hot-reload-20261021 at 2b10732cfeff8121cbb23cd89063bc5ccba5b3c7, PR55 open draft; all current required hosted checks now success (the old pull_request-target duplicates skipped). No files dirty at start.
GM local main5fb83478dd7b95216be92c4d3077eddf2774eef8; current source may advance—check before selecting.
Orchestrator local main5a8496ce711909e381c5bc817fff5500be9a1761; ADR0117 pins Core/Assembly0.5.0 and CMS a3a079baca2c6af48c9d45bc08992825be1c2bbd, FMS1.1. Native PG accepted. Do not silently upgrade product adoption.
GM latest registry observed last round Core/Assembly0.7.1, Conformance0.5.1, Resources0.2.1, Observation0.2.0; main-only Nov2–5 repairs are not published bytes.
Read EF docs/research/plugin-industry-and-scale-review-2026-11-05.md, plugin-system-research-reference.md, plugin-boundary-and-failure-experiments.md and relevant tests.

## Priority evidence from critics
1. Useful no-fork A+B+conflict journey: independently packed B extends A's public contract, replaces the provider actually used by existing consumers, changes a useful workflow/UI outcome, preserves other A behavior. No private imports/workspace aliases/source edits. Explicit config order may change outcomes; discovery order alone must not choose singleton. Removing B+restart restores baseline.
2. Same actual artifact handoff under verify-then-replace including helper dependency. Hash != byte custody. Reuse existing executor/artifact owner.
3. Bounded async overload/noisy contributor/fair progress and repeated failed setup/restart/cleanup, observer resurrection, no post-seal admission.
4. Supported upgrade compatibility/rejection/migration; deliberate MVP breaks allowed.
Do not rerun unchanged scale toy matrices; 1024 live scoped sync receivers already tested by GM. N1000 finite construction is not active plugin fleet capacity.

## Tooling status
gh absent. Central organization standard permits connected GitHub route when absent; do not fake author identity. Root publishes via connector existing authenticated owner and verifies exact tree/head. Agents do not commit/push.
EF pinned Foundation1.7.2 CLI statically initializes API Extractor7.58.12 -> TS5.9.3. Workspace TS7.0.2. Last round local Foundation-based gates not executed under current compiler rule; independent DocsProtocol gate8/8 pass. Hosted CI all pass separately and does not erase the policy conflict. Investigate qualified owning fix, no pin/lock hacks, fake suppression or editing node_modules.

## Collaboration
Use only assigned scope; root owns repo edits until a file ownership assignment is explicit. Save reports under /workspace/scratch/f863b9d38368/plugin-e2e-2026-11-05/reports. All requested agents use GPT-6.1 Sol xhigh. Read-only investigators can coordinate via messages. Do not spawn further agents while all4 slots in use. Never imply independent review is extra execution evidence.
