import { componentVersion, epochMicroseconds, hostBootGeneration, hostCapabilityId, hostFreshnessEvidenceRef, hostInstanceId, hostProtocolRange, hostProtocolVersion, supervisorInstanceId, targetId, } from "@agent-teams/local-host-control";
import { composeDiscovery } from "./composition.js";
const mode = process.argv[2];
const allowedModes = ["baseline", "extended", "extended-reversed", "ambiguous", "ambiguous-reversed",
    "source-failure", "target-mismatch", "expiry", "async-binding"];
if (mode === undefined || !allowedModes.includes(mode))
    throw new Error("Unknown child mode");
const observed = { factories: [], baselineReads: 0, bReads: 0 };
const query = (value) => ({
    targetId: targetId(value), requiredCapabilities: [hostCapabilityId("host.control.v1")],
    supportedProtocolRange: hostProtocolRange(hostProtocolVersion(2n), hostProtocolVersion(4n)),
});
const baseline = {
    async read(target) {
        observed.baselineReads += 1;
        if (target.value !== "fixture-delegated")
            return { kind: "not-found", targetId: target };
        return { kind: "observed", observation: {
                capabilities: [hostCapabilityId("host.control.v1")], componentVersion: componentVersion("1.0.0"),
                freshness: { evidenceRef: hostFreshnessEvidenceRef("fixture-evidence-baseline"), kind: "expiry",
                    observedAt: epochMicroseconds(1000000n), validUntil: epochMicroseconds(2000000n) },
                hostBootGeneration: hostBootGeneration(7n), hostInstanceId: hostInstanceId("fixture-host-baseline"),
                protocolRange: hostProtocolRange(hostProtocolVersion(1n), hostProtocolVersion(3n)),
                supervisorInstanceId: supervisorInstanceId("fixture-supervisor"), targetId: target,
            } };
    },
};
const wrap = mode === "source-failure" ? source => ({ async read(target) {
        await source.read(target);
        throw new Error("fixture-sensitive-source-failure");
    } }) : mode === "target-mismatch" ? source => ({ async read(target) {
        const result = await source.read(target);
        return result.kind === "observed"
            ? { kind: "observed", observation: { ...result.observation, targetId: targetId("fixture-foreign") } } : result;
    } }) : undefined;
const options = {
    extended: mode !== "baseline", reversed: mode.endsWith("reversed"), ambiguous: mode.startsWith("ambiguous"),
    ...(mode === "expiry" ? { now: 2000000n } : {}), ...(wrap === undefined ? {} : { wrap }),
};
async function construct(source, selected) {
    const preparation = await composeDiscovery(source, observed, selected);
    if (preparation.status !== "prepared")
        return { preparation, root: undefined };
    const outcome = await preparation.prepared.run();
    if (outcome.status !== "succeeded")
        throw new Error(`Construction did not succeed: ${outcome.status}`);
    return { preparation, root: outcome.roots.discovery };
}
const results = {};
const checks = {};
let selected;
if (mode === "async-binding") {
    let enter = () => { throw new Error("Missing entered gate"); };
    let release = () => { throw new Error("Missing release gate"); };
    const entered = new Promise(resolve => { enter = resolve; });
    const gate = new Promise(resolve => { release = resolve; });
    let held = true;
    const old = await construct({ async read(target) { if (held) {
            enter();
            await gate;
        } return baseline.read(target); } }, { extended: false });
    if (old.root === undefined)
        throw new Error("Old instance unavailable");
    let oldSettled = false;
    const pending = old.root.discover(query("fixture-extension")).then(result => { oldSettled = true; return result; });
    await entered;
    selected = await construct(baseline, { extended: true });
    if (selected.root === undefined)
        throw new Error("Fresh instance unavailable");
    results.fresh = await selected.root.discover(query("fixture-extension"));
    checks.oldPendingBeforeRelease = !oldSettled;
    held = false;
    release();
    results.old = await pending;
    checks.bCallsBeforeOldAgain = observed.bReads;
    results.oldAgain = await old.root.discover(query("fixture-extension"));
    checks.bCallsAfterOldAgain = observed.bReads;
}
else {
    selected = await construct(baseline, options);
    if (selected.root !== undefined) {
        results.primary = await selected.root.discover(query("fixture-extension"));
        if (["baseline", "extended", "extended-reversed"].includes(mode))
            results.delegated = await selected.root.discover(query("fixture-delegated"));
    }
}
const preparation = selected.preparation.status === "prepared"
    ? { status: "prepared", plan: selected.preparation.composition.plan, digest: selected.preparation.composition.digest }
    : { status: "failed", code: selected.preparation.error.code, cause: selected.preparation.error.cause,
        diagnostics: selected.preparation.diagnostics };
const receipt = {
    mode, pid: process.pid, preparation, factories: observed.factories,
    evaluations: { b: Reflect.get(globalThis, Symbol.for("plugin-e2e/extension-evaluated")) === true,
        h: Reflect.get(globalThis, Symbol.for("plugin-e2e/helper-evaluated")) === true },
    results, observations: { ...checks, baselineReads: observed.baselineReads, bReads: observed.bReads },
};
process.stdout.write(`${JSON.stringify(receipt, (_key, value) => typeof value === "bigint" ? { type: "bigint", value: value.toString() } : value)}\n`);
