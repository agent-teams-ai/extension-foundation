import { createHostDiscovery, epochMicroseconds, microseconds, } from "@agent-teams/local-host-control";
import { required } from "@get-modular/core";
import { assemblyFor, declareModule, defineContract, implement } from "@get-modular/assembly";
const Source = defineContract()({ id: "plugin-e2e/discovery/source", revision: 1 });
const owner = { authority: "plugin-e2e", path: ["discovery"] };
const baselineDeclaration = declareModule({
    moduleId: "plugin-e2e/discovery/baseline", implementationId: "plugin-e2e/discovery/baseline/default",
    owner, provides: [Source.provide()], slots: [],
});
const extensionDeclaration = declareModule({
    moduleId: "plugin-e2e/discovery/extension", implementationId: "plugin-e2e/discovery/extension/b",
    owner, provides: [Source.provide()], slots: [Source.slot("source", required())],
});
const discoveryDeclaration = declareModule({
    moduleId: "plugin-e2e/discovery/consumer", implementationId: "plugin-e2e/discovery/consumer/default",
    owner, provides: [], slots: [Source.slot("source", required())],
});
export async function composeDiscovery(source, observed, options) {
    const baseline = implement()(baselineDeclaration, async () => {
        observed.factories.push("baseline");
        return { instance: source, capabilities: { [Source.id]: source } };
    });
    const extension = implement()(extensionDeclaration, async (dependencies) => {
        observed.factories.push("extension");
        const { createCandidateSource } = await import("@plugin-e2e/discovery-extension");
        const candidate = createCandidateSource(dependencies.source);
        const counted = { read: target => { observed.bReads += 1; return candidate.read(target); } };
        const selected = options.wrap === undefined ? counted : options.wrap(counted);
        return { instance: selected, capabilities: { [Source.id]: selected } };
    });
    const discovery = implement()(discoveryDeclaration, async (dependencies) => {
        observed.factories.push("discovery");
        const instance = createHostDiscovery({
            source: dependencies.source,
            clock: { now: () => epochMicroseconds(options.now ?? 1500000n) },
            freshnessPolicy: { maximumFutureSkew: microseconds(100000n), maximumObservationAge: microseconds(1000000n) },
        });
        return { instance, capabilities: {} };
    });
    const bindings = options.extended && options.ambiguous !== true ? [{
            consumerImplementationId: discoveryDeclaration.implementationId, slotId: "source",
            providerImplementationIds: [extensionDeclaration.implementationId],
        }] : [];
    const modules = options.extended
        ? options.reversed === true ? [discovery, extension, baseline] : [baseline, extension, discovery]
        : [baseline, discovery];
    return assemblyFor().prepare({ profileId: "plugin-e2e/discovery", modules, roots: { discovery }, bindings });
}
