# Packed consumer E2E — local evidence checkpoint

Observed 2026-11-05. This bundle retains the reviewed plan, owning context,
seven investigator/critic reports, strict experiment sources, actual local
run output and the exact hosted workflow staged at commit
`11fa2e2450a8aba62823544fc3129318918e9696` in EF draft PR55.

## Read first

- `experiment/README.md`: exact reproduction and deliberately limited scope.
- `reports/e2e-consumer-plan.md`, `e2e-artifact-plan-critique.md` and
  `e2e-plan-second-critique.md`: actual seam selection and pre-execution critique.
- `reports/e2e-execution-artifact-review.md` and
  `e2e-execution-behavior-review.md`: independent corrected execution review.
- `reports/e2e-toolchain-audit.md` and `e2e-hosted-validation-review.md`:
  native compiler release/managed-adoption distinction and hosted setup review.
- `validation/experiment-run-3.log` and
  `experiment/.runs/run-3Tudbb/receipt.json`: corrected final local execution.

## Actual local runs

| Run | Outcome and meaning |
| --- | --- |
| `run-kICLsH` / run-1 log | Failed while installing B: pnpm 11 ignored package.json overrides and attempted registry resolution of the unpublished fixture helper. No scenario passed. The failed package/configuration and command logs remain. |
| `run-Wto5ej` / run-2 log | Eleven TAP passes (ten scenarios plus parent), but A's prepack did run despite the intended suppression. This proves its actual behavior/build output only. The old driver snapshot is in validation/pre-review-inputs. |
| `run-3Tudbb` / run-3 log | Eleven TAP passes, zero failures/cancellations/skips. Corrected explicit pack suppression, before/after dist equality, complete-body receipt success and both emitted consumer-file equality all executed. |

The final local runtime is Linux Node24.22.1, pnpm11.25.0, strict TS7.0.2.
Twenty-seven recorded subprocess commands exit zero with no signal; ten fresh
scenario children complete. Independent reviewers performed read-only artifact
and behavior comparisons, not additional runtime runs.

The pnpm suppression probe is separately retained. It did not rewrite the old
run's evidence; it packed a retained A directory to a new validation destination
using the explicit supported option. A's source and original manifest remain
unchanged throughout. The first failed driver was not snapshotted separately;
its actual generated package/configuration, command and failure output are
retained. The final input archive is the supported reproducible experiment.

## Validation and limits

The initial reviewed-plan full DocsProtocol gate passed eight tests, zero
failures/skips. Execution prose initially failed spelling on an opaque temporary
run suffix; the prose now uses a descriptive label while raw evidence retains
the exact suffix. The corrected docs check passed catalog81 and87prose files.
Hosted experiment and repository CI are pending at this local checkpoint;
their completed artifacts belong in the subsequent hosted evidence bundle.

Dependency stores and downloaded Foundation vendor archives are deliberately
excluded. Their inspected release metadata, loader excerpts, archive hashes and
SRI comparison summary are retained. Generated owned outputs, tarballs, actual
locks, exact workflow and logs are included. Frozen GM packages are retained
historical inputs, not newly authenticated registry releases.

This proves bounded public-package integration with a trusted TEST consumer.
It does not instantiate a product plugin Host or prove production admission,
artifact custody, hostile isolation, zero-downtime replacement, restart/drain,
cleanup, fairness, upgrade migrations or fleet throughput. Existing accepted
owners, ADRs, dependency Cohort and required gates are unchanged.
