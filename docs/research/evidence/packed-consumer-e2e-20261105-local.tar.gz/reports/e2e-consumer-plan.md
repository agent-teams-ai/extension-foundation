# Actual-consumer seam assessment and bounded E2E plan

Date: 2026-11-05. Status: **read-only source assessment; proposed execution, no test pass claimed**.

## Recommendation

There is no materialized public plugin seam in the inspected EF/Orchestrator product that can honestly complete the requested product-level A + independent B + conflict journey today. Do not build another Host or publish an extension SPI to manufacture one.

The strongest immediately executable bounded work is an **independently packed adapter exercising the unchanged real Orchestrator Host Discovery use case**, with the existing public `HostDiscoverySource` port. Pack A (`@agent-teams/local-host-control`), build B in a separate consumer against A's installed public declarations, and run baseline → B → baseline in fresh processes. Add only a thin TEST composition using the accepted GM 0.5.0 pair if root selects the conflict slice described below. It can prove public-package substitutability, actual use-case consumption, deterministic selection/refusal, and preserved validation. It cannot prove an existing app/UI workflow, product restart admission, artifact custody, hostile-code isolation, asynchronous fleet capacity, or production plugin adoption.

The baseline source is a **fixture**, because A ships no source adapter/default locator. A is a real private product library, **not an existing feature plugin**. B is an independently built adapter package, **not an admitted installable product plugin**. Those distinctions must stay in every result headline.

## Inputs and authority actually inspected

Read the full shared `brief.md` and `quality-standard.md` before repository inspection. Read all three root `AGENTS.md` files; EF's OD-003 and relevant existing plugin research; Orchestrator ADR-0117, its current composition profile and materialized package surfaces; GM's system boundary, current contract, current public exports and authoring guidance. Accepted/frozen files are read-only.

| Source | Exact inspected identity | Relevant finding |
| --- | --- | --- |
| EF checkout | `2b10732cfeff8121cbb23cd89063bc5ccba5b3c7` | No `src` product runtime; qualification/research fixtures do not constitute an extension runtime. |
| GM checkout | `5fb83478dd7b95216be92c4d3077eddf2774eef8` | Public Core/Assembly plus current guide; current main is not Orchestrator's accepted dependency baseline. |
| Orchestrator checkout | `5a8496ce711909e381c5bc817fff5500be9a1761` | Two materialized packages, no materialized app files, no production `@get-modular/*` imports. |
| Orchestrator adopted composition | Core/Assembly `0.5.0`; CMS `a3a079baca2c6af48c9d45bc08992825be1c2bbd`, full document SHA-256 `e5cb510c5ea83e54a6833cc40b6ad31fc5cf8c70d9838e4e0c6923edc6f70919` | ADR-0117 retains these exact pins; first production materialization/foundation gates remain. |
| Existing TEST Host | `agent-teams-ai/modularity-host-test@fa11296f0c69d80216dec0c44d9742368a913a9d` | AGENTS/README/full implementation plan explicitly say fixed synthetic in-memory Host, not product conformance. Root package still selects archived GM 0.1.0 and Node 24; 0.2.0 replay was separate evidence. |
| Agent Runtime navigation/source audit | Public main resolved to `ab0387c02fe75ed0c9bb456caaad9a6d2723795b`; file/tree blobs retrieved through GitHub | Real passive/ordinary GM adoption exists, but default Host replacement seam is owner-local, not public. See below. |

Current EF hosted success is separate from this read-only report. No old failing check is asserted here. No code, compiler, package installation or new execution was run for this plan. SHA-256 was recomputed on the two retained GM archives without executing them.

## Why the existing products do not supply the requested journey

### EF

`docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md` explicitly leaves production extension Host, public SPI, invocation protocol and extension-state migration unresolved. Its owner-confirmed baseline is static composition with controlled restart; that confirmation does not publish a plugin contract. EF's `tests/qualification/` and `fixtures/qualification-toy-package/` are explicitly qualification subjects, not actual product consumers.

### Orchestrator

The actual materialized source inventory under `apps/` and `packages/` contains only:

1. `packages/contexts/agent-context`: immutable sandbox-manifest use case and PostgreSQL adapter.
2. `packages/platform/local-host-control`: read-only Host Discovery use case.

`rg` found every `createHostDiscovery` consumer in package tests and every `createSandboxManifestFeature` consumer in package tests. No materialized application consumes either. The root manifest contains no GM dependency; no production `@get-modular/*` import was found in the inspected roots. This is an architecture selection awaiting its implementation, not an already functioning plugin Host.

Sandbox Manifest exports `.`, `./api`, and `./module`. `createSandboxManifestFeature` accepts `pool`, `migrationPool`, `authorization`, optional `nextId`, and internally constructs its PostgreSQL store. Its store port is private. Replacing `authorization` would replace a grant/security boundary; it is not an ordinary plugin customization candidate. Replacing `pg.Pool` or `nextId` would not demonstrate useful independent feature extension.

Host Discovery instead has a narrow non-authoritative source port that is already public and was designed for later concrete source adapters. It is the best honest product-code slice.

### Agent Runtime exclusion check

Fetched current `AGENTS.md`, README, readiness/adoption navigation, package manifests, composition barrels and the actual default Host/root implementation. The real private packages expose public package entrypoints, and the passive/ordinary scope adopts Core/Assembly `0.6.0`, Resources `0.2.0`, development Conformance `0.4.0`, CMS `b70ba39304ac71964175c42a77309406a7c30ca2`.

`packages/apps/embedded-runtime/package.json` exports `.` and `./composition`. Its `src/composition.ts` publishes `createDefaultAgentRuntimeHost` and narrow composition facilities. But `src/composition/default-agent-runtime-host.ts` defines public `DefaultAgentRuntimeHostOptions` as only `{ signal?: AbortSignal }`. `createRuntimeSetupAttempt(... factoriesForAttempt ...)` is explicitly owner-local and absent from the package composition barrel. `runtime-setup-assembly.ts` has the real selected factories and bindings, but those are not the public replacement surface. A no-fork B cannot replace the provider used by the default Host through that public factory.

`@agent-teams/runtime-configuration/composition` publicly exports parser/classifier/source-reader contracts and feature constructors. These could support another packed use-case adapter experiment, but exercising a newly constructed feature would not replace the default Host's selected provider. It has a much larger dependency/custody surface and offers no stronger product-plugin claim than Host Discovery. Do not deep-import the owner-local root or expose it incidentally to obtain a green test.

This was a bounded exclusion audit of the named surfaces, not proof that every AR source file has no possible extension point. No provider commands, credentials, native custody changes or real agent launch were involved.

## Exact chosen public seam

Repository-relative paths below are under `agent-teams-orchestrator` at the exact commit above.

| Purpose | Owning path/public import |
| --- | --- |
| A manifest/export map | `packages/platform/local-host-control/package.json` — private version `0.0.0`, sole public package export `.` → `dist/index.js` / `dist/index.d.ts` |
| Public package import | `@agent-teams/local-host-control` |
| Public barrel | `packages/platform/local-host-control/src/index.ts` → `src/features/host-discovery/index.ts` |
| Source contract | `src/features/host-discovery/application/ports/host-discovery-source.ts` — `HostDiscoverySource.read(targetId): Promise<HostDiscoverySourceResult>` |
| Actual consumer factory | `src/features/host-discovery/application/discover-local-host.ts` — `createHostDiscovery({ source, clock, freshnessPolicy }): HostDiscovery` |
| Actual operation | `HostDiscovery.discover(query): Promise<DiscoverLocalHostResult>` |
| Exact public data/constructors | `src/features/host-discovery/application/model/host-discovery.ts` — nominal target/instance/protocol/time constructors, observation/query/result types |
| Contract limits | `src/features/host-discovery/README.md` — candidate is not authenticated, ready, connected or trusted; locator/process/ensure remain outside this slice |
| Existing source tests | `tests/features/host-discovery/host-discovery.test.mjs` and `host-discovery-model.test.mjs` |
| Existing pack route | `tests/package/packed-package.test.mjs` — actual isolated package installation, but runtime probe currently only checks factory presence |

The use case snapshots/validates dependencies, validates the query before source access, reads its source at most once, validates the returned target and complete observation, applies freshness policy, then evaluates compatibility. Source exceptions become `unavailable/source-failure`; raw error details are not returned. A `candidate` always contains `authenticatedHandshakeRequired: true`. These are actual implementation behaviors worth preserving through replacement.

## Smallest executable slice

### Packaging and ownership

Create one new disposable TEST directory under the new task root, with a parent evidence runner and separate build/install roots for A, B, optional C, and consumer. Do not mutate any existing repo or its dependency lock during the experiment.

1. Copy A's package source/config from the pinned clean Orchestrator Git objects into a disposable build context. Build with strict TypeScript `7.0.2`; the existing source inherits its TypeScript preset, so resolve and read the preset as data without initializing the Foundation CLI. An equivalent self-contained strict build profile may be used for the disposable consumer build only if every difference and the absence of repository-gate qualification are recorded. Do not silently weaken source compiler options.
2. Pack actual A with its existing name/export map/version. Preserve archive bytes, file inventory, package identity and full source provenance. No new export or source edit in A.
3. In B's independent build root install only the exact A archive plus compiler/declaration tooling. B imports types and constructors only from `@agent-teams/local-host-control`, never `dist`, `src`, repository aliases, symlinked workspaces or `paths`. B cannot see A source in its compiler include roots.
4. B exports `createCandidateSource(fallback: HostDiscoverySource): HostDiscoverySource`. For one explicit TEST target it returns a fresh valid observation constructed by a separately authored static helper; for other targets it delegates to the supplied baseline source. The helper is another `.ts` source emitted into B's own distributable closure, not another runtime system.
5. Pack B, then install A+B into a separate consumer root with scripts disabled and a frozen exact lock. Check that A resolves to the same single installed package root from B and the consumer. B uses an exact dependency/peer identity qualified by the manifest; no workspace ranges remain in packed manifests.
6. The consumer calls the unchanged actual A `createHostDiscovery` and `discover`, observes the returned outcome and source/fallback invocations, and serializes bigint fields as explicit decimal strings for receipts. It must never call B in parallel just to report B's independent output.

A contains no baseline source. Author a small fixture baseline source returning a known valid candidate for `fixture-delegated`, `not-found` for `fixture-extension`, and named failure observations for targeted controls. B changes only `fixture-extension`. The parent oracle states all expected target/instance/protocol/result values independently of B's helper and profiles.

### GM conflict slice: justified only as integration, not a compiler benchmark

Adding roughly 70–120 fixture integration lines using existing GM public APIs is justified for the requested applied singleton conflict at the same actual use case. Keep one conflict/permutation pair within approximately 60 test lines. Do not re-test the neutral semantics matrix or add a new selection framework. The final recommendation is to include this bounded slice; its value is that the real A use case receives the actual selected independent B, and a conflicting configuration cannot construct it. This remains a TEST graph, not a newly admitted product graph or SPI.

Use exactly Core/Assembly `0.5.0`, the already accepted Orchestrator pair. Existing retained archive bytes are available at GM `research/releases/0.5.0-train/`:

| Archive | Recomputed SHA-256 |
| --- | --- |
| `get-modular-core-0.5.0.tgz` | `7943f054427282b68cd57e3f790acca62e14cbae67ea62b227f363a8d2614328` |
| `get-modular-assembly-0.5.0.tgz` | `6112f57755ff9cf3f7b3379b8f932421499cf5db3320b7e4c3aefd998ec36862` |

The retained release-intent says these were packed from `74ce8cf14695660926fdc5575d8f4d957535213a`, merged as `99816e452630715558306db2370baa2af49575e6` with equal tree. Its historical publication status is not a current registry receipt. Execute these explicitly identified retained bytes, or independently obtain/verify the exact published 0.5.0 pair and record its actual identity. Do not call retained packs registry artifacts without that readback. Assembly's archive manifest depends on exactly Core `0.5.0`; verify resolution reaches these bytes for both consumer and Assembly.

Actual 0.5.0 archive public declarations were read: `@get-modular/assembly` exports `assemblyFor`, `defineContract`, `declareModule`, `implement`, `group`, `input`; `@get-modular/core` exports cardinality helpers. No private source imports or Resources/Lifecycle Kernel are needed for these pure/borrow-only modules.

TEST-only shape:

- `baseline` module publishes a fixture-owned `baseline-source` capability typed as A's public `HostDiscoverySource`.
- `default-source` module requires baseline-source and republishes it as `source`.
- `B-source` module requires baseline-source and publishes `source` by invoking installed B's public factory. Lazy `import('fixture-b')` inside its factory lets conflict rejection prove zero B executable evaluation.
- `discovery` root requires `source`, creates actual A `createHostDiscovery`, and exposes its actual `HostDiscovery` result to the child runner.
- A tiny optional C package implements the same A source type for the conflict control; it is also lazy-loaded only inside its factory.

Each selected profile is a literal, explicit tuple. Baseline selects baseline + default-source + discovery; B selects baseline + B-source + discovery. Conflict selects baseline + B-source + C-source + discovery with no binding for discovery.source. No last-writer rule, numeric priority, scanner, registry, plugin manager or dynamic loader admission is introduced. Repair is explicit configuration selecting B or C alone. A repaired C profile must consume its declared baseline-source dependency too, or omit the otherwise unreachable baseline module; do not ignore Core's closure rules.

Call public `assemblyFor<Capabilities>().prepare({ profileId, modules, roots })`. Assert the conflict returns `assembly.prepare.unresolved-binding`, with discovery consumer, source slot/capability and the exact sorted B/C candidates; no `prepared.run` occurs, and all factories/evaluation markers remain zero. Reverse entry discovery/module order with the same selected IDs and obtain the same refusal. Valid B profile permutations must preserve the same plan/digest/binding and user-visible outcome. This adds evidence about wiring real A through GM, not another claim about GM's already-tested resolver.

All descriptors live in TEST composition, not A/B business code. B implements the ordinary public port and has no GM dependency. This experiment **does not adopt GM in Orchestrator** or claim first-scope production conformance. The selected CMS pin/current delta must be retained as source context if this becomes maintained research; a production adoption requires its owning migration/conformance route.

### Fresh-process protocol and outcomes

Use one parent process with fresh child subprocesses for each selected scenario. Existing Node subprocess ownership is sufficient; no supervisor abstraction. Parent uses explicit bounded child identity, `exit` receipt, stdout/stderr retention, and failure-only cleanup if a watchdog expires. A watchdog kill fails the row. Do not infer physical exit from `kill()` or an IPC send. Pass a minimal allowlisted environment and only TEST directories.

Expected core journey:

1. **Baseline**: actual A `discover(fixture-extension)` → `not-found`; delegated target → the independently pinned baseline candidate. Retain actual source call counts and child boot nonce/PID.
2. **A + B**: same actual operation/query → candidate `host-extension-b`, protocol `3`, mandatory later authenticated handshake. Delegated target still produces baseline candidate and one fallback call.
3. **Remove B + restart**: fresh consumer installation/profile with A and default fixture source only, B absent from package manifest and installed directory; same operation → original `not-found` and delegated candidate. Retain fresh process/boot identity and exact unchanged A archive/installed bytes. Reusing an old A/B import cache is forbidden.

This demonstrates fresh-process static reconstruction. There is no product running lifecycle owner to seal, drain or restart; describe this as test-process restart, never product controlled-restart conformance.

One small asynchronous join can use the existing API without adding lifecycle machinery: start an old A instance whose original source waits on a controlled promise; construct a fresh A instance with B and obtain its candidate; release the old source and observe the original baseline result. Its next call must still use its originally captured source. This demonstrates per-instance dependency capture and finite independent progress. It does not demonstrate retirement, post-seal admission, cancellation, queue fairness or closure of old execution resources. No sleeps are needed.

## Planned acceptance and negative controls

These are proposed named rows, not execution counts. Keep one actual TAP/JSON scenario receipt per row and reject missing/duplicate/skipped/cancelled/unexpected rows.

| Proposed row | Independent expected result / falsifier |
| --- | --- |
| `public-boundary` | A+B install from tarballs only; no private import/alias; B compiler cannot access A source; A runtime root resolution and declarations verified. |
| `baseline` | Actual A discover returns pinned `not-found` and delegated baseline candidate; exactly one source read per valid query. |
| `replacement-used` | Actual A discover returns B's pinned distinct candidate; parent expectations do not import B helper. A direct call to B alone is insufficient. |
| `delegation-preserved` | B delegates unhandled explicit target once and preserves independently pinned baseline result. |
| `restored-without-b` | B absent, fresh process, unchanged A bytes, original actual A outputs restored. |
| `old-pending-fresh-b` | Controlled old-source wait does not prevent fresh B instance progress; releasing old yields baseline, and its next call retains its original binding. |
| `discovery-permutation` | Same declared B configuration, reversed module order, identical selected source/output and plan digest. |
| `singleton-conflict` | B+C both selected, public GM preparation refusal with actionable exact candidate IDs; no source/factory evaluation. |
| `singleton-conflict-permutation` | Same refusal/candidates after discovery order reversal; no winner chosen by order. |
| `explicit-conflict-repair` | Select B alone (or separately C alone); same actual A use case consumes that explicitly chosen provider. |
| `target-substitution` | B returns a structurally typed observation for the wrong target; A returns `rejected/target-mismatch`. |
| `expiry-preserved` | At exact `validUntil`, A returns `expired` for B; no candidate result. |
| `compatibility-preserved` | Missing required capability or disjoint supported protocol yields A's typed `incompatible` result. One credible case is enough here; existing A suite owns the complete matrix. |
| `exception-redaction` | Throwing B source produces `unavailable/source-failure`, no raw error/secret-shaped marker in output. |
| `type-negative` | Independently compiled incorrect B return contract is rejected by TS7; expected diagnostic is explicit and separate from the valid build. |
| `wrong-wiring-mutant` | Temporarily wire default source under selected B factory; `replacement-used` must fail for its intended output reason. Restore exact source, rerun affected row only. |

Do not add every existing model edge case again. Preserve meaningful rejection evidence, not only final process exit zero. Runtime-negative data should be semantically invalid while remaining correctly modeled, or cross an explicit unknown/JSON boundary; do not introduce `any`, double assertions, `@ts-nocheck` or weakened strict options.

## Scope limits and exact missing product work

Successful execution allows the statement: **“An independent packed adapter implementing a real product-owned public port changed the unchanged packed Host Discovery use case, preserved named validation outcomes, and restored its fixture baseline after a fresh process; GM deterministically refused the named ambiguous configuration.”**

It does not allow “production plugin E2E completed.” Missing product responsibilities are concrete:

- an actual app/Host consumer of Host Discovery with an admitted concrete source/locator;
- product-owned extension admission/selection/configuration and contribution identity/grants;
- a supported product plugin packaging/export/compatibility surface beyond private test archives;
- the useful app/UI/user workflow that consumes discovery and later authenticates/connects;
- actual artifact owner handing admitted complete bytes to execution, including helpers;
- an existing runtime admission seal, readiness/routing, drain, physical execution owner and cleanup/recovery path for extension generations.

Those cannot be supplied by labeling the fixture runner a product Host. Creating them is production work under the relevant unresolved product decisions, not this research task. B cannot replace trusted authorization or readiness merely because it supplies discovery observations.

The helper's installed-byte hash and successful import prove the tested package closure was used under the controlled run. **They do not prove verify-to-execute byte custody.** No actual product plugin artifact handoff exists in the inspected seam. Repeating writable-file hashing and mutation here could reproduce the old race, but would not close the real custody gap; leave that priority unqualified until the actual owner exists. Likewise no queue/admission/concurrency promises follow from a pure discovery port.

## Alternatives, cost and decision

Scores are engineering judgments for each named scope, not availability/security metrics. LOC estimates are incremental hand-maintained source, roughly factor-two uncertainty, excluding unchanged A/GM libraries, generated output, locks, evidence archives, provider execution, native packaging and product implementation.

| Option | Confidence /10 | Achievable reliability /10 | Complexity /10 | New production LOC | Fixture integration LOC | Tests/packaging/evidence LOC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Packed A+B actual Host Discovery port, baseline/restoration/validation | 9 | 9 in this pure trusted single-operation scope | 2 | 0 | 70–120 | 220–330 |
| Same plus thin GM0.5.0 conflict/wiring slice | 9 | 9 for explicit selected-set construction/refusal | 3 | 0 | +70–120 | +40–60 |
| Extend existing synthetic TestHost | 8 | 8 for its finite in-memory promises | 5 | 0 | 150–350 for new surface/pin adaptation | 300–700; still no product consumer |
| Add product plugin Host/SPI now | 3 | 5 while its own decisions/qualifications are absent | 8 | Not honestly estimable from this seam | Not estimated | Not estimated |

Recommended execution budget: **zero new production code**, approximately **140–240 fixture integration** and **260–390 tests/packaging/evidence** if GM conflict is included, with a hard planning envelope of **500–700 new TypeScript lines**. These are a decomposition of the same bounded work, not additive separate projects; the earlier broad research estimates must not be used to grow it. If optional rows push beyond the envelope, keep source throw, target mismatch, exact expiry, captured-old-instance/fresh-B and conflict/permutation; defer duplicate compatibility, deep-import, or generic compiler controls already covered by A/GM unless a new failure requires them. An independently packed helper H can replace the internal helper to prove installed transitive resolution with about 10–20 source lines; change hostInstanceId/componentVersion (the actual contract has no locator URI). That is optional artifact-resolution evidence and still no byte-custody qualification.

Use `.ts`, `type: module`, strict TypeScript7.0.2 for all new maintained source, helpers, tests and runner, with an effective checked project including every file. Node26.11.1 and pnpm11.18.0 match current task/product tooling and the GM0.5 archive engine range. Inspect all initialized compiler versions first. Avoid invoking Foundation1.7.2 CLI because its embedded API Extractor currently initializes TS5.9.3; record any affected blocked repository gate honestly and keep the independent experiment's typecheck separate. A strict standalone experiment does not replace required repository checks when root later publishes its documentation/evidence.

## Handoff

No repo files were changed, no installs/pack/build/runtime tests were executed, and no commits were made by this investigator. The next action is independent critique and root selection of the bounded experiment. If selected, retain exact sources, archive hashes/locks, compiler/version/resolution facts, named scenario execution and failed controls before integrating the report/evidence into EF through its DocsProtocol route. Existing frozen archives and accepted ADR bodies remain unchanged.
