# Independent artifact and execution review

Observed 2026-11-05. Read-only review of the executed source, retained artifacts and logs; no tests were run and no implementation was edited. Reviewed the common brief, quality standard and prior artifact critique first, then the complete runner, consumer, composition, B/H fixtures, manifests, effective strict configs, provenance, successful receipt/log and retained initial failure.

## Disposition

**PASS for corrected run 3 within the actual public-package integration boundary.** The run demonstrates an independently authored, separately packed B/H source adapter changing the result of the unchanged real A discovery use case through actual GM 0.5.0 construction. It also demonstrates preserved delegation, deterministic ambiguity rejection, three meaningful A rejection paths, independent old/new source binding and baseline restoration in a fresh consumer process without B installed.

This is materially stronger than the previous packed smoke, which checked exports/declarations without invoking the useful discovery workflow. It is not complete product plugin E2E, an external plugin ecosystem, production controlled restart, artifact custody, authorization/readiness qualification, isolation, or admission/cleanup/fairness qualification.

Corrected run 3 now passes with explicit pack lifecycle suppression, dist preservation assertions, full-body receipt completion and equality checks for both emitted consumer files. No further implementation fix is required within this bounded scope. Run 2 remains retained with its original prepack caveat; the correction does not retroactively change its build route.

## Corrected final run 3

Read `validation/experiment-run-3.log`, `experiment/.runs/run-3Tudbb/receipt.json`, all three recorded pack commands, the relevant `logs/004.log` and the current driver. Run 3 again has **10 named checks plus enclosing test: 11 passed; 0 failed, cancelled, skipped or todo**, on Linux Node24.22.1 / TS7.0.2 / pnpm11.25.0. All 27 subprocess statuses are 0 with null signal. Its ten child invocations have PIDs 354, 366, 378, 390, 398, 406, 418, 430, 442 and 454. Current maintained TS total is **433 physical lines**.

Each pack command explicitly contains `--config.ignore-scripts=true`; A's `004.log` is only pack JSON and has no prepack output. The inspected driver compares complete dist inventories before/after every pack, checks both `consumer.js` and `composition.js` across all consumers, and sets `completed = true` only after final evidence assembly and the exact passed-count assertion. Receipt status derives from that completed fact.

I independently repeated only read-only artifact comparisons for run 3: complete archive/installed file-set and byte equality passes for A20/B4/H4 files, and B resolves A/H to the same physical installed copies as the consumer. A and H archive hashes equal run 2; B's archive hash changes because its preserved devDependency points at the new run's A archive path. This is not a behavior/authoritative-source change.

| Final identity | SHA-256 |
| --- | --- |
| Current `experiment/src/e2e.test.ts` | `91f4e5dd2fe94a88231105ee40ae125c8cc5220a0c8eb1d0807c095a8bab8e82` |
| Run-3 receipt | `22bdb7630190d1fc31cb188f251b5f1644a22464b16f7a995d1f68d0ad913197` |
| Run-3 full log | `45fdea7bb56a61e31957643cb5753cd52b673aeab1ac0c463795e00f29112a8c` |
| Run-3 A archive | `c031c16073dc609f9f9070ace8e48396416d6c50d3ed2cc375e377aa31e658c9` |
| Run-3 B archive | `f55f3654539acee09dd4fee0c051cb050bc789e139445adc5a809d39fb5a5d43` |
| Run-3 H archive | `3c32c05404aa5ad0bc6196c365961141565d4464f0d07a62ab35cc5c3a2380cb` |

No tests or compilers were executed by this reviewer. These final read-only checks and the actual new run close the intended explicit-build packaging gap; all runtime/ownership limits below still apply.

## Historical run 2 and initial failure

- Reviewed historical driver snapshot: `validation/pre-review-inputs/e2e.test.ts`, SHA-256 `c735d3e56c65aed26d6949333fb3f368fb8a31083cd3462c800e1b678c421bd9`. Current runner was subsequently changed by root; this review does not silently bind run 2 to that newer source.
- Successful retained run: `experiment/.runs/run-Wto5ej/receipt.json`.
- Full runner log: `validation/experiment-run-2.log`.
- Actual Node result: **11 tests passed**: ten named child checks plus their enclosing test; **0 failed, cancelled, skipped or todo**. This is not eleven independent scenario groups.
- Execution profile: Linux, Node **24.22.1**, TypeScript **7.0.2**, pnpm **11.25.0**. The receipt binds 27 successful subprocess commands and ten child-process invocations. All command statuses are 0 and signals null. Child PIDs are 408, 420, 432, 444, 452, 460, 472, 484, 496 and 508.
- Five new maintained TS files total **431 physical lines** (231 runner, 67 composition, 94 consumer, 32 B, 7 H), within the initial 500-line scope. Copied A source, generated output and configs are separate.
- Successful receipt SHA-256: `cb0717c9496cb96bcebcf26b08d89092c6abc1c995bdc3dac7373b70a31c0d0c`.
- Full successful log SHA-256: `d489b31f75efc85a7ceaca1639c933503e68262bebe51e189e4df35b90363223`.

The first `run-kICLsH` remains an actual failed run: zero passed checks; initial extension installation requested the unpublished helper from npm and received 404 because pnpm ignored the old `package.json` overrides location. The corrected run places the local override in `pnpm-workspace.yaml`. The failed receipt and `validation/experiment-run-1.log` are retained, not converted into an expected-failure pass.

## What was independently checked from the retained bytes

I performed read-only comparisons rather than rerunning the experiment:

1. All ten A input files listed in `inputs/provenance.json` match their recorded SHA-256 and the corresponding actual Orchestrator checkout bytes. The checkout is at `5a8496ce711909e381c5bc817fff5500be9a1761` and has a clean tracked working tree. This confirms unchanged source/package input, not merely the assertion `source_modified: false`.
2. For each packed A/B/H archive, the complete regular-file member set equals the installed package's regular-file set in the extended consumer, and every file's bytes match. Counts: A 20 files, B 4, H 4. No source-tree alias is needed to explain the observed runtime.
3. B's installed A peer and H dependency resolve to the same physical installed package targets as the corresponding consumer packages. B's packed manifest explicitly declares exact H dependency `0.0.0` and exact A peer `0.0.0`. The helper is also a direct consumer dependency under the same local override; this is a closed local fixture installation, not a registry-installability claim.
4. Effective B and consumer configs use strict TS7 checking, including exact optional properties, unchecked-index checking and `skipLibCheck: false`; compiler source paths and `--version` are recorded. A retains its original source and manifest. The explicit build uses data-only copied Foundation compiler presets, not the blocked Foundation CLI. **However, read `logs/004.log`: actual `prepack` runs `pnpm run clean && pnpm run build`, deletes dist and rebuilds with A's original `tsconfig.json`. That copy extends the experiment ancestor TS config and uses the current TS7 compiler, according to root's path investigation; it is not the intended explicit `tsconfig.e2e.json` build-only route. The installed archive bytes checked above are the actual final prepack-produced bytes.**

Archive SHA-256 values in the successful receipt:

| Artifact | SHA-256 |
| --- | --- |
| A `agent-teams-local-host-control-0.0.0.tgz` | `c031c16073dc609f9f9070ace8e48396416d6c50d3ed2cc375e377aa31e658c9` |
| B `plugin-e2e-discovery-extension-0.0.0.tgz` | `a017d7f95ff6dd363152bccd3a1629c3046a9ed6eeda4f0d87523f4eab07723c` |
| H `plugin-e2e-discovery-helper-0.0.0.tgz` | `3c32c05404aa5ad0bc6196c365961141565d4464f0d07a62ab35cc5c3a2380cb` |

These comparisons verify the retained local artifact/installation correspondence. They do not authenticate a publisher, establish signature/OCI admission, prove an immutable dependency closure through future execution, or exercise verify-then-replace enforcement.

## Assertion quality and false-green assessment

**Useful end-to-end path.** B imports only A's public package root and H's public root. Its returned `HostDiscoverySource` is the provider actually consumed by A's real `createHostDiscovery().discover()` call. H's host-instance/version values appear in the exact expected candidate. The delegated target still reaches the baseline source. The test does not substitute a direct call to B for invocation of A.

**Independent oracle.** Parent expected candidate objects are literal tagged values, with protocol 3, exact host/version/evidence, freshness and `authenticatedHandshakeRequired: true`. The parent does not import B/H identity constants or generate its expected source selection from the actual GM plan. The delegated expected result is separately fixed. Actual factory/read counts independently constrain the path.

**Real rejection controls.** Source failure, target mismatch and exact-expiry cases invoke selected B and then the unchanged A use case. They check exact expected results; source-error text is not exposed. The expiry test uses fixed now exactly equal to `validUntil`, with no sleep-based timing inference. These are consumer-owned test controls, not feature flags added to product A or B.

**Composition conflict and inert executable selection.** The ambiguous graph omits discovery's explicit source binding and actual GM preparation reports the expected two sorted candidates. Factories, reads and B/H top-level evaluation flags remain zero/false in both tuple orders. The working extended run proves those marker oracles are reachable. Explicit binding to B, rather than tuple order, repairs the same graph; reversing the tuple preserves the actual plan/digest and results. This is applied integration evidence, not another implementation of GM resolution.

**Asynchronous row.** The old source really awaits a gate reached before construction of the fresh B instance. Fresh B returns while old remains pending; after release, old and oldAgain produce baseline, with B call count unchanged by oldAgain. This proves captured per-instance dependencies and finite concurrent progress. No stop, cleanup, abandonment or process lifecycle promise is tested by it.

**Runner integrity.** The runner clears `NODE_TEST_CONTEXT` for subprocesses and requires exact passed check count, avoiding the historical inherited nested-test issue. Actual runtime children are ordinary program invocations, and failure on nonzero status/JSON mismatch would stop the parent. The successful log includes each named check and real Node counts. No missing/no-op test route or skipped scenario was found.

**Small future hardening concern, not a false successful run:** receipt `status` is derived solely from `passed.length === 10`. An error after the tenth check, for example while reading final `packageEvidence`, could leave a receipt marked passed even though the Node parent fails. The current successful run has complete packageEvidence and a passing parent, so this did not occur. Root has now patched the driver to track successful completion of the entire outer body separately and derive receipt status from that terminal fact; keep Node's actual result authoritative for the historical run. This does not require replaying unchanged product scenarios merely to reinterpret the retained run.

## Build-route correction disposition

Root independently caught the A lifecycle mismatch after my initial runtime/package review. The actual prepack output is retained after the pack JSON in `run-Wto5ej/logs/004.log`; the log parser's successful JSON parse is not proof that no scripts ran. Environment `npm_config_ignore_scripts` and a root `.npmrc` did not achieve the intended suppression in this actual pack command.

Read-only inspection of installed pnpm 11.25.0's `dist/pnpm.mjs` shows its pack `api(opts)` invokes `prepack` and `prepare` only when `!opts.ignoreScripts`, and similarly gates `postpack`. Root's separate `validation/pack-suppression-probe.log` observes `pnpm --config.ignore-scripts=true pack --json --skip-manifest-obfuscation` completing with only pack JSON and no lifecycle execution. This is consistent with that actual owner option. I did not execute the probe or any compiler.

The patched driver passes the explicit configuration flag, inventories dist before/after pack, uses actual workspace configuration, tracks full-body completion and checks both consumer/composition emitted bytes. Root's run 3 subsequently completed and was inspected as recorded above. Preserve run 2 and its driver unchanged, and retain run 3 as separate new execution evidence. No claim about successful suppression or explicit-build output preservation belongs to run 2.

## Required reporting dispositions

- Say **fresh-process removal/recomposition restores baseline**. The test creates separate clean baseline/extended/restored directories and synchronously joins child completion. It does not stop/restart a running product, seal ingress, drain in-flight work or qualify production controlled restart.
- Say **unchanged copied A source/package inputs**, rebuilt and packed with the declared strict compiler. A is private `0.0.0`; this is not proof of a released production A artifact or unchanged already-published JS bytes.
- Call A's baseline source **fixture-owned**. A ships the discovery workflow/public port, not that default source or a materialized application shell. B extends the exposed port and preserves supplied fallback behavior; it does not replace an existing deployed application's source.
- The runner's first check does not itself compare every B/H archive member to installed bytes. This independent review adds that exact retained-byte comparison. Keep that distinction if describing automation coverage.
- Do not claim closed, verified or immutable artifact custody from hashes, lockfiles, frozen reinstall, installed-file equality, top-level markers or successful child exit. No mutation-between-verification-and-load test occurs here; the earlier PB-02 counterexample and missing production handoff remain unresolved.
- The finite TEST evaluation symbols contain no service instances or authority. They are observations, not a production registry. No generic runtime, public SPI, supervisor or new product behavior was introduced.
- Do not add post-seal, asynchronous overload/fairness, repeated failed-setup cleanup, observer-resurrection, supported-upgrade or hostile-execution qualification to this run's coverage. Those are separately scoped existing evidence or still-missing joins.

Within these limits corrected run 3 is useful, coherent and sufficient. Stop optional scenario expansion and preserve the original failure, run-2 caveat, old driver and corrected run-3 evidence before publication.
