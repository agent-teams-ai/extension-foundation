# E2E toolchain audit — 2026-11-05

## Result and decision boundary

**The executable compiler defect already has an owning, published fix. Engineering Foundation 1.10.0 replaced API Extractor with native TypeScript 7.0.2; 1.10.2, 2.1.2 and current stable 3.1.0 also contain that fix. Extension Foundation cannot adopt one by changing its Foundation pin alone: its installed managed Docs Cohort closes five exact package coordinates, and the current central registry has no native-capable successor Cohort.**

The smallest legitimate next step is an explicitly unqualified, coherent successor proposal and disposable compatibility qualification, followed by the existing **central data-only Cohort qualification route**. It is not another extractor implementation, a package override, a node_modules edit, or a weakened gate. Actual consumer activation follows a genuinely qualified central record and its declared transition.

This audit performed source, installed-manifest, public registry metadata and archive-byte reads only. It did not import or initialize TypeScript 5.x/6.x, run any affected Foundation CLI, install packages, change a repository, commit, publish or dispatch a workflow. Downloaded package archives were inspected as data. No new runtime qualification is claimed.

## Exact inspected subjects

| Subject | Identity |
| --- | --- |
| Extension Foundation checkout | `2b10732cfeff8121cbb23cd89063bc5ccba5b3c7`, branch `docs/plugin-research-hot-reload-20261021` |
| Installed Foundation | `@agent-teams/engineering-foundation@1.7.2` |
| Installed executable extractor | `@microsoft/api-extractor@7.58.12` |
| Its embedded compiler | `typescript@5.9.3` |
| Consumer compiler | `typescript@7.0.2` |
| Live Engineering Foundation main | `e38d8444f74cceef37c366f4e28ed1918b214d4a`, 2026-11-05T12:15:14Z |
| Live central .github main | `0b44c64c824f536bd1b085341e7669bcc64ef124`, 2026-11-04T21:14:58Z |
| Owning native migration | PR408, merged `93b6ec468c50cd6110e2a9284ae7c0de170b01af` on 2026-10-19 |
| Latest public Foundation release | `3.1.0`, release/source `99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef`, GitHub published 2026-11-01T17:30:22Z |
| Latest public TypeScript | npm `latest: 7.0.2`; next/beta are 7.1 prereleases |
| Latest public API Extractor | npm `latest: 7.60.1`, exact dependency `typescript: 6.0.3`; still below the adopted floor |

Sources: [owning native PR408](https://github.com/agent-teams-ai/engineering-foundation/pull/408), [Foundation package changelog at inspected main](https://github.com/agent-teams-ai/engineering-foundation/blob/e38d8444f74cceef37c366f4e28ed1918b214d4a/packages/engineering-foundation/CHANGELOG.md), [Foundation registry metadata](https://registry.npmjs.org/@agent-teams%2fengineering-foundation), [TypeScript registry metadata](https://registry.npmjs.org/typescript), [current API Extractor metadata](https://registry.npmjs.org/@microsoft%2fapi-extractor/7.60.1).

## Why 1.7.2 is blocked even for unrelated commands

Installed `dist/cli.js` statically imports `composition/command-host.js`. The latter imports Foundation checking and its capability registry; `composition/capability-modules.js` statically imports the public-API capability at line13. Its outbound adapter imports the executable API Extractor. Extractor's CompilerState loads its own TypeScript5.9.3 before command selection.

The mandatory runner is affected too: `dist/node-test-cli.js` imports `isolateNodeTestCliContext` from the same command host. A selected source-dependency capability, an ostensibly harmless status/schema command, and the Node mandatory-runner path cannot undo eager initialization by selecting a different operation.

This is a compiler-initialization policy conflict, even if an invocation never parses a consumer project. Current hosted PR55 successes are separate actual CI observations; they cannot establish exclusive execution under the 7.0.2 floor. This audit did not rerun those blocked paths.

The five enabled Extension Foundation capabilities are source dependencies, local documentation references, ADR governance, repository agent workflow and workspace dependency declarations. Public-API compatibility is not enabled here, so this consumer does not currently need a released public-API baseline transition. Installing a native-capable Foundation does not activate that capability.

## What the released native fix actually does

The native adapter retains the existing `PublicApiExtractor` and `PublicApiObserver` ports and Microsoft API model. It removes the executable `@microsoft/api-extractor` dependency, pins actual `typescript@7.0.2`, and identifies the new extractor as `typescript-native/7.0.2`. The pinned loader checks the native platform package's exact name/version. The model package `@microsoft/api-extractor-model@7.33.10` has no TypeScript dependency; retaining its name is not evidence that the old extractor executes.

The owner contract preserves closed declaration inputs, diagnostics, failed observations and release-owned baseline policy. A public `--native-transition` route exists for consumers with old API baselines; it is not needed merely to upgrade this pre-production consumer, and it does not authorize relabeling historical extraction evidence.

Independent artifact inspection downloaded four public release archives, recalculated SHA-512 SRI and scanned their emitted JavaScript without evaluation:

| Foundation | GitHub release source | SHA-256 of downloaded archive | Native TS | Preset export |
| --- | --- | --- | --- | --- |
| 1.10.0 | `aed890a6ac09762d9f487ed2624e64a873935868` | `0b9fcd6a674cc98f718ce57ee9d7c114981078a0d3a5cd0a6eaada28a3810ad8` | 7.0.2 | retained |
| 1.10.2 | `4ca4ad30b1efc5e3b43a2c012348ea8afea21864` | `12159a29495e3343b95b3ec6a615b414f0a6bba07ceb85802595f21f4fbecb3b` | 7.0.2 | retained |
| 2.1.2 | `d815b1176c263f4d2e66421822b84b15db591dfc` | `89bb2de23f5917aee31b5f0ff71d6215629a3a1b3f1aa79ef6bba52699e7cc9c` | 7.0.2 | retained |
| 3.1.0 | `99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef` | `e2379583c9ed8535b93bc2eabddfed9f43650f9982fb98bbcbb6d9864a314b02` | 7.0.2 | removed |

All four match registry SRI and contain native async SDK imports, with no static imports of the executable API Extractor package in the inspected emitted JavaScript. These observations establish archive contents, **not cryptographic publisher authentication or successful execution**. Metadata exposes npm signature/attestation evidence, but this audit did not execute the independent cryptographic verifier.

Detailed evidence is in `toolchain-inspection/archive-inspection-summary.json`, beside the four untouched archives, their metadata and extracted pinned-loader text. Foundation3.0.1 additionally fixes signature proofs to use the async native SDK; current3.1.0 includes that correction. Available old1.x packages are not being represented as a maintained LTS branch; no such support commitment was established.

Sources: [native adapter contract](https://github.com/agent-teams-ai/engineering-foundation/blob/99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef/docs/architecture/public-api-compatibility.md), [pinned loader](https://github.com/agent-teams-ai/engineering-foundation/blob/99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef/packages/engineering-foundation/src/capabilities/public-api-compatibility/adapters/outbound/api-extractor/load-pinned-audit-sdk.ts), [native baseline transition](https://github.com/agent-teams-ai/engineering-foundation/blob/99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef/docs/reference/public-api-native-transition.md).

## The actual consumer adoption blocker

The consumer's `architecture/foundation/docs-consumer-integration.json` and generated `docs-protocol-managed-state.json` bind Cohort `docs-2026-10-03-stable31`:

| Managed coordinate | Exact version |
| --- | --- |
| Repository Mutation | 0.2.2 |
| Document Authoring | 0.3.2 |
| Docs Protocol | 0.6.2 |
| Docs Protocol Agent Teams | 0.3.2 |
| Engineering Foundation | 1.7.2 |

The record digest is `sha256:15ef4d89c312593f5ecee9e0c9890f4ffa487e4d869682dec688460f2f4fc0c8`; immutable QUALIFIED event digest is `sha256:7273eab4e9b555bde22a2c89f4b98735c0d668afb6144b5983e030ee942c420f`. Its schemas are profile3/Cohort2/state2/receipt3; managed operations are Node24. The source profile separately supports ordinary repository tooling on Node24.21.0+ and Node26.11.1+.

At central main `0b44c64...`, `governance/docs-qualified-cohorts.json` ends at stable31 and event186 RECOMMENDED. There is no registered native-capable1.10.x/2.x/3.x target. The registry's current filename remains authoritative; 404s at speculative `docs-qualified-cohorts-v2.json` / `docs-protocol-policy-v3.json` do not imply missing generation3 source support. Current validators already support generation3 mapping, but mapping is not a concrete qualified record.

The latest published adapter0.6.1 has stable31 origin assets and explicit2-to3 preparation/finalization/rollback machinery (released0.6.0); earlier0.5.5 lacked that operational path. Its release-source README still contains historical “unreleased” wording, so the actual changelog and emitted/source implementation must be distinguished from that stale status sentence. Adapter0.5.1, contemporaneous with Foundation1.10.0, lacks the stable31 historical bundle. A proposed minimal tuple must therefore prove the actual existing-consumer upgrade and rollback behavior; dependency agreement alone does not qualify its operational route.

`currentSourceExecutors: []` in the transition catalog is an observation, not proof that every ordinary same-generation transition is absent. Current source/released0.6.1 has22 direct historical bundles, including stable31. No arbitrary new target is embedded into its own published package. The central record supplies qualified target authority.

Sources: [central registry](https://github.com/agent-teams-ai/.github/blob/0b44c64c824f536bd1b085341e7669bcc64ef124/governance/docs-qualified-cohorts.json), [central generation3 guidance](https://github.com/agent-teams-ai/.github/blob/0b44c64c824f536bd1b085341e7669bcc64ef124/docs/governance/docs-gen3-current-policy-mapping.md), [managed package changelog](https://github.com/agent-teams-ai/engineering-foundation/blob/99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef/packages/docs-protocol-agent-teams/CHANGELOG.md), [managed owner contract](https://github.com/agent-teams-ai/engineering-foundation/blob/99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef/docs/architecture/managed-docs-consumer-integration.md).

## Smallest legitimate qualification route

### 1. Produce a reviewable candidate; keep its status honest

Use already published exact packages, authenticate their archives/provenance, inspect their complete managed dependency DAG, acquire the real runtime closure and published Skill/caller/transition asset bytes, and compute digests with the owning algorithms.

A bounded compatibility candidate can retain Foundation1.x presets. Foundation1.10.0 is the smallest compiler-fixing release and retains Mutation0.2.2/Authoring0.3.2; the contemporaneous adapter is0.5.1 with Docs0.6.2. Foundation1.10.2 instead belongs with Mutation0.3.0/Authoring0.3.3/Docs0.6.3/adapter0.5.2. Neither tuple has central qualification or proven stable31 transition in this audit. Do not mix1.10.2 with old exact transitive mechanisms.

The current coherent public train is Foundation3.1.0 / Docs0.6.6 / adapter0.6.1 / Authoring0.3.6 / Mutation0.4.2. Its already released stable31 handling avoids inventing an older-branch patch, but Foundation3 removes presets. A same-generation Cohort2 qualification might retain the existing Node24 managed contract, provided the real package/controller qualification proves it; selecting generation3 is a separate deliberate runtime/profile migration. Do not assume a new generation is mandatory merely because package versions increased.

A disposable compatibility experiment may run native-capable tools before any consumer activation. It must not call a mocked local record a qualified Cohort or bypass protected-main selection. If a public operation requires qualified authority, retain that refusal rather than replacing its authority reader for a success claim.

### 2. Use central's existing data-only publication/qualification process

The owning repository is **agent-teams-ai/.github**, not Extension Foundation. Its existing `.github/workflows/docs-cohort-append-only.yml` accepts only the registry plus create-only inert Cohort evidence and exactly referenced new runtime-closure files in a lifecycle PR. It requires fresh default-branch base, preserves all prior records/events and uses **base-owned** validation code.

The workflow runs real npm signature/provenance, exact published dependency/asset/runtime-closure and workflow verification. Its local counterpart is:

```sh
pnpm governance:cohorts:verify -- \
  --registry /absolute/path/to/proposed-registry.json \
  --schema governance/docs-qualified-cohorts.schema.json \
  --changed-from /absolute/path/to/retained-base-registry.json
```

The verifier invokes authenticated `gh` and isolated npm/pnpm operations; `gh` is absent in this workspace. Connector reads do not substitute for a cryptographic verification receipt. The existing hosted route provides the required tooling and read credential. A data proposal is concrete review material, but cannot claim VERIFIED/QUALIFIED until actual owner verification succeeds.

Append publication, verification and qualification events only from real evidence. Declare stable31 as an upgrade origin and qualified rollback target, with Extension Foundation's immutable repository ID1333298097 as an explicit canary if selected. No passive release-age waiting is required by accepted central ADR0001 item9.

### 3. Execute the already-owned registry and consumer qualification

Producer workflow `public-managed-registry-canary.yml` accepts exact `expected_commit`, `cohort_id`, `authority_revision`. It requires a registered central canary candidate, current protected central main and genuine QUALIFIED/CANARY authority. It observes the selected real runtime (Node24.21.0 for generation2, Node26.11.1 for generation3), installs public archives, verifies signatures and public imports, and emits its own bounded receipt.

That workflow cannot qualify an arbitrary unregistered tuple. `agent-teams-docs-managed qualify` similarly produces **supporting consumer evidence**, not a central Cohort or CANARY event. Actual default-branch consumer check-run evidence remains necessary for central CANARY, followed by RECOMMENDED where appropriate.

Once authority exists, use the managed owner's public `upgrade --to <real-cohort-id> --target-generation 2` for an ordinary same-generation proposal, or the explicitly retained generation2-to3 prepare/finalize/restore route for a deliberate runtime migration. Preserve original and inverse images, exact controller/kernel builds, unresolved transaction/recovery state and both positive and rejected activation evidence.

Sources: [base-owned lifecycle workflow](https://github.com/agent-teams-ai/.github/blob/0b44c64c824f536bd1b085341e7669bcc64ef124/.github/workflows/docs-cohort-append-only.yml), [live verifier](https://github.com/agent-teams-ai/.github/blob/0b44c64c824f536bd1b085341e7669bcc64ef124/scripts/verify-docs-cohort-evidence.mjs), [public registry canary](https://github.com/agent-teams-ai/engineering-foundation/blob/99b7dac2fd3c3b2b1b024a8a640f6e13ec79dbef/.github/workflows/public-managed-registry-canary.yml), [accepted lifecycle authority](https://github.com/agent-teams-ai/.github/blob/0b44c64c824f536bd1b085341e7669bcc64ef124/docs/decisions/0001-qualified-docs-cohorts.md).

## Consumer file plan after target qualification

This is a plan, not assigned edits or a pre-authorized new Cohort identity.

1. **Managed owner output:** root `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `architecture/foundation/docs-consumer-integration.json`, generated `docs-protocol-managed-state.json`, managed Skill, caller workflow and managed AGENTS block. Let the existing managed transaction produce these bytes. Preserve historical records.
2. **Consumer-owned explanations:** update the live tooling/adoption section of `docs/architecture/feature-module-standard-profile.md` and applicable AGENTS prose with exact qualified tuple, actual runtime evidence and remaining gaps. Do not edit accepted ADRs.
3. **For Foundation3 only:** add exact published `stack-toolchain` as development-only, admit it in the exact-registry policy and migrate `tsconfig.json` preset. Update `architecture/checks/package-topology.mjs` preset expectation and the corresponding topology/scaffolding disposable fixtures. Existing package-policy fixture at `tests/package-policy-characterization.test.mjs` encodes1.7.2 and needs review. There is no installed FMS package here to upgrade; do not add one simply because the producer's migration guide discusses it. No quality-source-coverage activation is implied.
4. **Compiler initialization regression:** if adding a current-floor preflight, use new ordinary strict `architecture/checks/compiler-floor.ts` and `tests/compiler-floor.test.ts`, reading package metadata before imports. Its negative fixture must demonstrate refusal of an embedded below-floor copy before any affected entrypoint runs. Do not require the currently blocked compiler to execute to test the refusal.
5. **Strict scriptcheck coverage:** current root tsconfig has `files: []`; qualification tsconfig covers only `tests/qualification/**/*.ts`. There is no existing scriptcheck command/project. New maintained tooling/tests need an effective strict `tsconfig.scriptcheck.json` (or another existing-owner selected project), a real `scriptcheck` command included in required `typecheck`, and a focused rejecting gate regression. Node type stripping alone is not evidence. Avoid turning this into a mass migration of unrelated legacy.mjs.
6. **Runtime verification:** preserve .node-version26.11.1 and engine union `>=24.21.0 <25 || >=26.11.1 <27`. Execute the actual consumer suites physically on both24.21.0 and26.11.1 with its exact pnpm11.18.0 unless a qualified managed runtime migration changes its owning manager contract. Both current Linux full CI jobs use26.11.1 (one via .node-version); they do not independently prove a Node24 run. An additive Node24 lane may be appropriate if the adoption requires persistent hosted coverage; preserve current required context names rather than silently repurposing one.

### Existing obligations that must survive unchanged

`tests/foundation-upgrade.test.mjs` exercises the installed public mandatory runner with inherited parent NODE_TEST_CONTEXT. Keep all actual cases: completed success; omitted/skipped/unfinished/todo/failed rejection; exact OS exception positive with wrong OS/status/identity/blanket-OS rejection; full ancestry and test-kind binding. Preserve the real custody suite and its three exact required identities:

- `manifest verification requires externally supplied exact manifest identity`
- `capture requires a canonical clean repository root`
- `Windows remains verifier-only and rejects capture before source I/O`

Only the current exact win32 and linux/darwin skip exceptions remain admitted. Profile tests must still bind the entire selected entry file list and require the custody runner in **both** architecture chains.

Keep `tests/node-compatibility.test.mjs` positives under the actually executing Node24/26, below-floor and Node25/27 rejection, incompatible dependency engine/peer rejection, and rejecting locked peer-graph validation after a frozen install. Preserve pnpm-discovery hardening and export-byte identity checks. Run existing changed, fast and complete checks only after the installed compiler closure is permitted, plus the independent Docs gate and platform-specific required CI. A partial successful test set must not be relabeled as a full gate.

## Options, cost and recommendation

Scores are scoped engineering judgments, not measured availability; higher complexity is more work. LOC ranges are incremental maintained code estimates, exclude generated lockfiles, Cohort data/evidence, formatting and CI/release operations.

| Option | Confidence /10 | Achievable reliability /10 | Complexity /10 | Production LOC | Integration/tooling LOC | Tests/fixtures LOC |
| --- | --- | --- | --- | --- | --- | --- |
| Qualify a coherent native1.10.x tuple through existing Cohort2, preserve presets | 7 | 8 | 4 | 0 extractor; 0–100 only if a real older adapter transition gap is found | 40–140 consumer, plus authority data | 100–240 |
| Qualify current3.1.0 train through existing Cohort2 first; migrate presets coherently | 8 | 9 | 5 | 0 extractor/adapter expected | 100–260 consumer | 140–300 |
| Adopt current3.1.0 with deliberate generation3 Node26 managed transition | 7 | 9 | 7 | 0 expected if published controller meets scope | 180–400 consumer and runtime binding | 220–500 |
| Implement another native extractor/backport by default | 2 | 6 | 8 | unnecessary duplicate; no defensible bounded estimate | additional release/adoption work still required | substantial existing-oracle qualification |

The optional compiler preflight plus strict scriptcheck route is separately about80–180 tooling LOC and160–300 test/fixture LOC, whichever adoption is selected. It does not itself unblock execution.

**Recommended:** retain the current consumer pin while preparing the smallest genuine candidate and continue unaffected E2E. Prefer the current3.1.0 train if a data-only Cohort2 qualification can prove the actual stable31 route without a runtime migration; it reuses the released origin/controller fixes. Use1.10.x only after a bounded compatibility result justifies its smaller consumer diff and confirms the real origin/rollback route. Neither choice should launch a central framework overhaul. The work missing today is coherent owning qualification/registration and consumer adoption; the old embedded compiler does not need to be fixed again.

## Evidence and limitations retained

- Four native-capable archives inspected with matching SRI; zero legacy executable Extractor imports found in their emitted JavaScript.
- Installed1.7.2 import graph and exact lockfile dependencies inspected without evaluation.
- Current source, releases, PR408 and central registry/transition state read live.
- No full transitive installed-closure execution, cryptographic publisher audit, registry-canary dispatch, managed upgrade/rollback, consumer gate or new independent runtime test was executed in this audit.
- The original checkout remained clean during the final read-only status check.

