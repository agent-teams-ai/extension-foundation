# Second independent critique of the bounded public-package E2E plan

Date: 2026-11-05. Status: **APPROVE WITH THE REVISIONS BELOW**. This is a preimplementation review, not an execution receipt. No installation, build, runtime test, repository edit, commit or push was performed for this review. Only this task-local report was written.

## Decision and value

Proceed with the unchanged real `@agent-teams/local-host-control` package, an independently compiled and packed source adapter B, a small helper in B's distributable closure, and an isolated fresh consumer. The result should be titled **public-package integration E2E: independently packed Host Discovery adapter substitution**. The real product use case is exercised, but its surrounding application, plugin Host and admission system are absent. This experiment cannot complete full plugin Host/UI/custody/restart qualification.

The experiment has a concrete incremental purpose. The existing `tests/package/packed-package.test.mjs` installs an A archive and checks factory presence plus a declaration consumer; it does not invoke the discovery operation. Existing source tests already check target mismatch, exact expiry and source exceptions. Their repetition here earns value only because those same protections are observed through a separately built adapter and the installed public package boundary. It is not discovery of three new product invariants or a replacement for A's source test matrix.

B must affect the result of A's actual `discover` call. A marker printed by B, a direct independent B call, or a GM plan that is never used to create A would be insufficient. A useful bounded result is: the baseline fixture reports the extension target missing; B supplies a distinct candidate for that target; B delegates another target and preserves its baseline result; removing B and starting a fresh consumer restores both baseline outcomes. Every candidate must still require an authenticated handshake. The fixture is furnishing observations, not granting trust, readiness or launch authority.

There is no shipped default source adapter and no materialized application consumer to replace. Call the baseline a **fixture source**, A a **real private product library**, and B an **independently packaged adapter**. Do not rename these into an existing feature plugin, installed application provider or admitted EF artifact.

## Scope actually inspected

Read the complete task brief, the retained Engineering Quality Standard, both preceding planning reports, and the GM and Orchestrator root `AGENTS.md` files. Inspected the unchanged Orchestrator public barrel, source port and model, `discover-local-host.ts`, package manifest/configuration, existing packed test and relevant source tests. Read the **retained 0.5.0 archive** public declarations and README rather than assuming current GM main describes those bytes.

| Input | Inspected identity or path |
| --- | --- |
| Orchestrator checkout | `5a8496ce711909e381c5bc817fff5500be9a1761` |
| GM checkout | `5fb83478dd7b95216be92c4d3077eddf2774eef8` |
| Product port and consumer | `packages/platform/local-host-control/src/features/host-discovery/application/{ports/host-discovery-source.ts,discover-local-host.ts}` |
| Existing public-package evidence | `packages/platform/local-host-control/tests/package/packed-package.test.mjs` |
| GM retained bytes | `research/releases/0.5.0-train/get-modular-{core,assembly}-0.5.0.tgz` |
| GM archive API evidence | Assembly `dist/features/construction/types.d.ts` and README; Core `dist/features/authoring/wire-types.d.ts` |

No registry-origin authentication, archive re-execution or complete product audit is claimed by this review. The earlier reports supply the absent Host/SPI and product-boundary assessment; this reviewer independently checked the selected executable seam and retained GM API shape.

## GM: useful only as a thin, natural composition experiment

**Keep GM, with three TEST entries and one Source capability; drop C and the extra baseline-source capability.** Root accepted this revision during review.

1. The fixture baseline entry provides `Source`.
2. B's TEST composition entry requires `Source` in a fallback slot and provides `Source` by invoking installed B's ordinary public factory with that fallback.
3. The discovery TEST entry requires `Source` and creates the actual unchanged A `createHostDiscovery` with that selected value.

Retained Assembly 0.5.0 explicitly completes required slots against the single **other** module entry providing the capability. B therefore has exactly one eligible fallback, the baseline, while discovery has two eligible providers, baseline and B. With both selected and no discovery binding, the actual resolver must reject. The explicit binding row uses the public Core shape: `consumerImplementationId`, `slotId`, `providerImplementationIds: [B-id]`. This repairs discovery's ambiguity without discarding B's baseline dependency or leaving an unreachable artificial C entry.

This is a natural decorator graph: B wraps the port it extends. It adds genuine cross-package integration evidence if A is instantiated inside the selected discovery factory and the returned instance supplies the tested operation. It does not add new neutral resolver semantics, prove a product adoption of GM, or make the fixture a production composition root. All descriptors remain in TEST composition; B depends on A's public contract, not GM.

Use the same selected module IDs/profile/binding for the B-bound order permutations. Assert identical compiled plan and digest, selected provider identity, exact A outcome, and call observations. Do not compare the baseline and B profiles' digest as though they should be equal. For the ambiguous profile, assert public error code `assembly.prepare.unresolved-binding` plus the exact consumer/slot/capability and sorted two candidates; do not snapshot unrelated opaque diagnostics. Reverse module enumeration and obtain the same refusal. This is two configurations and their permutations, not a matrix.

Measure all factory calls directly. A rejected prepare must leave **all** factory counts at zero and must never call `prepared.run`. If asserting no B executable evaluation as well, import B only inside its factory and retain a direct evaluation observation; zero factory calls alone proves only the factory boundary. Do not introduce an evaluator or marker framework for that stronger statement.

If a retained 0.5.0 API or closure rule invalidates this tiny graph, report the specific failure. Do not patch the archive, upgrade the accepted pair, construct a manual resolver, or add graph nodes just to recover a green result.

## Minimum independent oracles

Root owns literal expectations independently from B/H and from the selected composition profile. The driver may use public A types to typecheck expectations; it must not import B's helper, call B to compute its answer, or derive the expected provider from the same profile being tested. Compare exact closed results for rejection cases so a leaked raw error cannot hide behind a matching `kind` field. Serialize bigints as explicit decimal strings, preserving identity and units.

| Check | Minimum expected result and decisive observation |
| --- | --- |
| Baseline | Extension target returns exact `not-found`; delegated target returns the pinned baseline candidate; one source read for each valid query. |
| B used by A | Same extension query returns a distinct pinned candidate through A: expected target, host instance, boot generation, component version, proposed protocol and `authenticatedHandshakeRequired: true`. H's contribution must reach one of those observed fields. |
| Delegation | Same delegated query has the independent baseline candidate and exactly one fallback read. Do not merely assert deep equality with an earlier unvalidated result. |
| Restored | Fresh child with B absent returns the original literal baseline expectations; A's archive, exported surface and installed executable/declaration bytes remain identical. |
| Wrong target | A structurally valid B observation for another target returns exactly `rejected/target-mismatch` and the requested target. Keep other observation fields valid so the test cannot pass for the wrong reason. |
| Throw | Source throws a unique sentinel; A returns exactly `unavailable/source-failure` and requested target, without the sentinel. Do not serialize the thrown error into the public result yourself. |
| Exact expiry | Fixed injected `now == validUntil` returns exact `expired`, requested target and that expiry value. Use an otherwise fresh, compatible observation and no sleep. |
| GM refusal/repair | Same real A consumer is ambiguous with baseline+B and no binding; explicit discovery-to-B binding succeeds; module-order reversal changes neither result. |
| Pending old/new instances | Begin an old instance's read and observe it has entered but is unresolved. Construct and invoke a new instance with B; its B candidate must arrive while the old read is still pending. Release old; expect the literal baseline result. Invoke old again; it still uses its original source and causes no additional B call. |

The pending test uses a local deferred promise and explicit entry/release observations. It needs no scheduler, generation registry, replacement manager, retirement, drain or cancellation API. It proves per-instance binding and concurrent independence. It does not prove that captured source objects are deeply immutable or that an actual product can retire an old generation safely. Existing A source tests already check query/policy snapshots across an await; avoid turning this into a duplicate mutation matrix.

A single compatibility rejection is useful if it fits the budget, but the three required controls above are sufficient for this bounded slice. Full malformed-input, transport, capability and protocol matrices stay with A's existing owner.

## Artifact, version, lock and type checks

The receipts must distinguish source identity, installed-byte identity, observed execution and unproved custody. Use ordinary package-manager and child-process APIs; no loader or supervisor abstraction.

- **A source and packaging:** build an unchanged copy of A's exact Git source in a disposable context. Preserve the original package name/version/private status/export map and its public declarations. Compare copied source to the selected Git objects. Record any standalone build-config differences from the actual inherited preset; reading that JSON preset does not require initializing Foundation's CLI. A self-contained strict build is experiment evidence, not a claim that all repository gates ran.
- **B and helper:** compile B in a separate project against installed A declarations only. No source aliases, deep imports, `paths`, repository symlinks or fallback to the source checkout. H may be a separately packed dependency if that is the selected closure question; if H is merely another emitted file inside B, describe it that way and do not claim independent dependency installation evidence. Do not add both forms. A separate H is small enough; C is not needed.
- **Installed resolution:** preserve tarball hashes, package manifest/export facts and installed file hashes for A/B/H. Resolve A from the consumer and B contexts, and Core from Assembly and consumer, recording physical roots and versions. Require the selected A bytes and exact Core/Assembly 0.5.0 pair; do not infer byte identity from version strings. A's public tagged values are structural data, so duplicate-package checks are dependency-identity checks, not proof of a runtime nominal-token requirement.
- **Lock:** retain the exact consumer manifest, package-manager version and complete lock. Make one resolution/install step explicit, then frozen installation into a fresh isolated consumer with scripts disabled. Distinguish creating a lock from verifying it. B-removed restoration should use an A-only manifest/lock and no B installed directory; merely not selecting an installed B supports a narrower deselection claim.
- **Compiler:** resolve and inspect every compiler/parser implementation that will initialize before execution. Use strict TypeScript 7.0.2 or newer, ordinary `.ts`, package `type: module`, and emitted JS/declarations for package imports. Effective strict checking must cover every new fixture/helper/composition/child/driver/oracle file. No compiler `paths` or broad assertion may bypass the installed declaration boundary. Successful type stripping is not a typecheck.
- **Pinned tooling restriction:** do not execute Foundation 1.7.2's API Extractor/TS5.9 path or the retained GM package's old compiler-floor test command. The new consumer typecheck uses the allowed compiler. Inspecting a legacy compiler version as data and executing it are different actions. Keep any blocked required repository gate separately visible.
- **Run identity:** record actual executable/version, named scenario, child identity, exit code/signal and successful joined process completion. A watchdog kill fails that row. Require exact expected scenario identities with zero missing/duplicate/skipped/cancelled rows. Do not count compile/install rows as discovery passes.

Hashing installed files and then importing them does not establish verify-to-execute custody. Do not add the optional writable-helper mutation demonstration: PB-02 already supplies that falsifier, and this seam has no real executor/admission handoff for a new custody pass.

## Size and stop conditions

The original planner's combined estimate of 160–310 fixture integration plus 350–630 tests/packaging/evidence lines is **510–940 maintained lines** and is not compatible with the initial 500-line target. Reduce scope before implementation: remove C, the second Source capability, optional custody mutation, optional compatibility duplication, generic fixture builders and generic receipt infrastructure. A few declarative package/tsconfig/lock files are appropriate; they cannot hide maintained runtime logic.

| Component | Target incremental maintained TypeScript lines |
| --- | ---: |
| B plus small helper | 35–55 |
| Baseline and deferred source fixture | 30–45 |
| Three-entry GM composition/refusal/permutation | 65–100 |
| Child scenarios and independent exact oracles | 100–140 |
| Parent packing/install/identity/process driver | 90–125 |
| Total planning range | **320–465** |

These are engineering estimates, not a promised measured result. Count all newly maintained TS, including fixture source written inside template strings, and report the actual inventory. Exclude unchanged borrowed A/GM source, generated output and lock data explicitly. Root has permitted a **documented exception up to 700 lines only if actual packaging/receipt needs justify the measured excess**. Aim at 500; do not spend the exception on optional scenarios or a framework. More than 700 or any production API/runtime change requires a new scope decision.

| Alternative, with scope held explicit | Confidence /10 | Reliability within that scope /10 | Complexity /10 | Incremental production LOC | Incremental integration/test LOC |
| --- | ---: | ---: | ---: | ---: | ---: |
| Selected packed port + minimal GM graph | 9 | 9 for the named package/wiring/results observations | 3 | 0 | 320–465 target; measured ceiling as above |
| Packed port only, omit GM | 9 | 9 for substitution and retained product checks | 2 | 0 | Approximately 65–100 fewer; conflict integration remains untested |
| New generic Host/loader/custodian | 2 for the requested product qualification | Not honestly rated without an owning product contract | 8 | Unscoped | Unscoped |

Stop after one coherent baseline/B/restored sequence, the two GM order controls, three negative controls and one pending-instance scenario. No scale rerun, admission seal, async limiter, restart churn framework, new product port or source edit in A. Retain failures as failures and publish the exact limitation: **public-package integration E2E completed if execution passes; full product plugin E2E remains incomplete because the application consumer, public plugin Host/SPI and artifact-admission-to-execution handoff are absent.**

## Coordination

Sent root the value/budget findings and the three-entry same-capability proposal. Root accepted the revision, retained the 500-line aim with the conditional measured 700-line maximum, and split implementation ownership between its independent driver/oracles and the planner's fixture/composition work. Sent the planner the exact ambiguity/binding shape and minimum target/throw/expiry/pending controls. Coordination and agreement are review evidence only; no runtime outcome follows from this approval.
