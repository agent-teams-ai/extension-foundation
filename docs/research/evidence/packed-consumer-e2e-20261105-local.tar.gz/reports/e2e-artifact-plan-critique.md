# E2E artifact and lifetime plan critique

Observed: 2026-11-05. Read-only planning review; no installs, executions, repository edits or commits were performed. This report is a new task-local artifact, not a normative repository document or another test receipt.

## Decision

The strongest immediately useful bounded slice is an **external packed consumer of an existing exported product port**, with independently packed replacement B and helper H, explicit GM selection, and fresh child-process runs. Its honest result is public-package customization and packaging integration evidence. It cannot close product plugin E2E, production artifact custody, admission sealing or application/UI restart qualification because those concrete production seams are not materialized in the inspected repositories.

Do not repeat PB-02's mutable-path race under a new name, build a loader/custodian to make it green, or add a Host framework. Preserve PB-02 as the already executed falsifier until an owning product has an actual verification-to-execution handoff. Likewise, do not create a new async scheduler merely to claim fair progress. Existing owners already cover substantial narrow lifecycle behavior.

## Inputs and inspected authority

Read the full task brief and retained organization Engineering Quality Standard first. Read the root AGENTS instructions in EF, GM and Orchestrator. Inspected these exact local heads:

| Repository | Local source identity |
| --- | --- |
| Extension Foundation | `2b10732cfeff8121cbb23cd89063bc5ccba5b3c7` |
| Get Modular | `5fb83478dd7b95216be92c4d3077eddf2774eef8` |
| Orchestrator | `5a8496ce711909e381c5bc817fff5500be9a1761` (task brief; same local tree inspected) |

Primary local sources: EF `docs/research/plugin-industry-and-scale-review-2026-11-05.md`, `plugin-system-research-reference.md`, `plugin-boundary-and-failure-experiments.md`, `docs/architecture/extension-model.md`, accepted ADR-0014, OD-003; actual archived PB-02 and corrected restart TypeScript; GM `packages/assembly/README.md`, `packages/lifecycle-kernel/README.md`, `docs/architecture/common-assembly.md`, packed Assembly harness, actual semantic attempt/lifetime/workload sources, Observation load/admission/engine sources and closing/reentrancy tests; Orchestrator local-host-control exported source/use case and existing packed package test.

This is source inspection and review of retained execution reports. No historical archive was re-executed or independently requalified in this assignment.

## Existing owners: what exists and what does not

### Composition and construction

GM public Core/Assembly already provides inert contracts/declarations, explicit binding, preparation rejection before factories, typed construction, per-run inputs and created journals. Group order is navigation, not provider priority. Assembly does not grant, load plugins, define readiness, rollback, dispose or own process custody. Its packed harness verifies archive/installed-byte correspondence, public-root runtime/type consumption and closed subpaths; it explicitly reports `registryOriginAuthenticatedByHarness: false`.

The lifecycle kernel remains a private optional candidate. Its own README says it performs synchronous generation/lease bookkeeping, not executable loading, async supervision or disposal. Using it would neither qualify a product nor fill a custody gap; no current static package-port experiment needs it.

### Artifact handoff

EF defines a plugin artifact as an independently distributable immutable signed OCI artifact. The inspected EF tree does not ship a production plugin loader, admission service or public extension runtime. ADR-0014 assigns literal loaders and runtime lifetime to products. OD-003 keeps the public SPI and runtime choices unresolved. A package tarball used in a research test is not thereby an admitted EF plugin artifact.

The actual PB-02 archived `src/pb2.ts` reads **both** entry and helper hashes, validates the expected complete receipt, emits `verified-full`, waits for the parent's barrier and then imports the entry. The retained parent replaces a path after that ACK. The changed entry executes. This is stronger than an entry-only-hash demonstration and already falsifies hashing-as-custody. The same archive separately shows helper-only changes, stale helper retention under root-only ESM cache busting, and coherent unchanged A/B directories in fresh processes. These need no new generic reproduction.

No real product loader/verified artifact-to-executor handoff was found in these inspected package sources. The retained AR Rust custody direction is an existing owner constraint, not inspected production release evidence in this assignment. Do not replace it with another Node/Rust custodian or import a synthetic keeper into EF.

### Product port available now

Orchestrator `@agent-teams/local-host-control@0.0.0` is private but has an explicit public package export `.`. It exports `HostDiscoverySource` and `createHostDiscovery({ clock, freshnessPolicy, source })`. The unchanged use case consumes `source.read(targetId)`, snapshots/validates its result, rejects target mismatch and malformed observations, and evaluates freshness and compatibility. A returned observation is a candidate requiring an authenticated handshake; source replacement is not launch or authorization authority. The exported observation has no transport locator/URI field; do not invent one for the experiment.

This is a suitable real port for a packed integration experiment. It has **no shipped built-in source implementation** to preserve or replace, and no materialized application consumer was found by the consumer planner. A test-authored baseline source must remain visibly test-authored. Replacing that source proves substitution into a real use case, not replacement of an already deployed application's provider.

The existing package test packs and installs the actual package and checks exported factory presence/declaration consumption. It does not invoke a complete useful discovery journey. That is a genuine small gap the new experiment can improve.

## Proposed bounded check set

### P1 — independently packed source B changes the actual discovery workflow

Reuse the actual A package unchanged. Compile test-owned baseline source and independently packed B/H from strict TypeScript 7.0.2+; B imports A's types/public entry only. H is an ordinary separate transitive dependency used by B to compute a candidate host-instance or component-version value. Install the archives into a disposable external consumer; no workspace aliases, private imports, deep imports, source-directory symlinks or in-place modifications to A.

Run the same public `createHostDiscovery().discover()` consumer with baseline and with B. Assert independently written exact output oracles: expected target, candidate host instance/boot-generation/component-version facts, protocol/capability result and `authenticatedHandshakeRequired: true`. Require B/H's effect to reach the actual candidate outcome; a second unrelated B function call is insufficient. Preserve unchanged behavior through the same workflow: target mismatch, stale/expired observation and unsupported required capability must retain exact documented rejection behavior. The fixture sources choose only discovery observation data; they do not replace trust, clock or authority policy.

Use GM explicit profile binding if GM selection is included; do not duplicate its resolver. With two selected candidate source entries and no binding, reject before either factory runs. With an explicit binding to B, discovery order permutations leave B selected. If ordered contributions are not part of this port, do not invent ordering just to create a conflict case.

Receipts must bind A/B/H archive hashes, physically installed file hashes, package versions/exports, exact compiler/runtime identities, selected provider ID, the real output, rejection output and actual executed test identities. A's archive and installed bytes must remain equal across baseline/B/removed-B runs. B can wrap a supplied fixture baseline source and delegate unhandled targets to it, demonstrating preservation of baseline behavior without claiming that baseline is a shipped product adapter.

Minimum rejection controls are source failure -> `{ kind: "unavailable", reason: "source-failure", targetId }`, a well-shaped observation for another target -> `{ kind: "rejected", reason: "target-mismatch", targetId }`, and `validUntil == fixedNow` -> `expired`. These use the unchanged A use case with exact independent expected values; no wall-clock sleep is necessary. A missing required capability -> `incompatible` with exact `missingCapabilities` is a small optional fourth control.

One useful asynchronous test needs no new lifecycle. Begin discovery on old A instance while its original source is held; construct a new A instance with B; the new instance returns the B candidate for the same query; release the old source and assert the old result remains the baseline; invoke old again and observe its original source, with no B call. `resolveDependencies()` captures source/read bindings at construction. This proves per-instance binding and concurrent independence, not retirement, drain, immutable captured state, or a product replacement protocol. Budget approximately 35–55 TS lines.

**Classification:** real exported-package integration and independently packaged adapter substitution. Not public EF SPI, published plugin ecosystem, product E2E, UI customization or hostile plugin safety.

### P2 — static restart and removal, using existing child-process test ownership

Run baseline -> B selected -> B removed through fresh ordinary child-process lifetimes. Keep A archive and consumer call logic fixed. Observe the owned child's actual result and joined `exit`/`close` before the next child. Removing B plus fresh startup restores the independent baseline oracle. A same-process `prepare()` call or query suffix on the entry import does not count as restart.

Do not introduce generation routing, active-head state, drain or durable restart orchestration into this package experiment. There is no product admission API to seal here. Claims are restricted to a trusted disposable child with no arbitrary descendants; the owned process's exit does not prove all possible descendant cleanup.

**Stopping criterion:** one coherent A/B/A sequence, both provider-discovery permutations, one ambiguous-selection rejection and ordinary child completion. No scale matrix or repeated timing benchmark.

### P3 — installed helper mutation: optional single counterexample only

If the independently packed helper introduces a genuinely new package-resolution question, use one deterministic pre-import barrier in the existing child harness: parent and child agree the complete installed B/H receipt; parent replaces **only H** at the actual resolved installed path; child then imports the package and invokes the same discovery workflow. A substituted helper marker/output must be observed separately from the unchanged entry hash. A fresh no-mutation child is the positive control.

This can establish the exact transitive installed-package resolution boundary and preserve a useful negative example. It cannot produce a custody pass. A final verification immediately before import still leaves a race and is not an enforcement fix. Do not make this mandatory: if it merely restates PB-02, skip it and reference that retained counterexample.

For future **actual** custody qualification, the same externally controlled mutation must hit the real owner's artifact handoff. Accept only: replacement is prevented at the promised boundary, or the real owner refuses execution **before any substituted top-level marker evaluates**. Both entry and helper/dependency mutation are required when the promised closure includes dependencies. Freeze the actual owned closure through evaluation, not just the receipt. Name the supported artifact/dependency/runtime profile and actual enforcement owner; fail/stop rather than building an owner inside the test.

### P4 — post-seal/async/restart/observer cases stay with existing owners

A synthetic package discovery consumer has no admission-seal contract. Do not attach a lifecycle kernel or invent `seal()` solely to claim this row is green.

Already present narrow evidence should be reused accurately:

- GM semantic lifetime L-01..L-03 checks late construction/readiness and publication cannot reopen stopped ingress; L-04/L-05 checks reentrant stop and actual cancellation; L-06 checks partial setup physical release; L-07 retains and retries cleanup debt; L-08 keeps one abandoning observer from replacing the actual close flight; L-09 checks effect permission after an await.
- L-10 actually sets `createAttempt(..., { capacity: 1 })`, holds accepted work, observes a coded overload rejection without runner entry, then stops/cancels that same owner. Its sibling test proves capacity is available immediately after awaited success/failure.
- W-01 demonstrates a separate right attempt makes fresh progress while left stops. W-02/W-03's 64/16 overload is **test scheduling**, not actual owner enforcement: attempts have infinite capacity and the outer test uses `active >= 16` to refuse excess requests. Do not describe that row as global fairness, real limiter enforcement or product throughput.
- EF corrected RST-01 already observes queued permanent seal ACK; rejected identities have unchanged canonical bytes, no reserve/permission/launch and remain absent after fresh-worker restart. Earlier acceptance stays distinguishable from post-seal acceptance. RST-02 joins readiness failure to retained real file/journal cleanup debt/retry. RST-03 separates late result/IPC disconnect from physical child exit.
- Observation already has real latest-only async lanes, one pending newest snapshot, subscriber/source close detachment, cancellation/drain and reentrant reporter checks. `load.test.mjs` R23 explicitly proves closing from `onLoading` or reporter cannot reacquire pending work. `close-reporting.test.ts` keeps the provider through the loader's unfinished `finally` and joins reporter reentry to the same close flight. `subscriptions.test.mjs` proves no delivery/new load after close while the drain waits. These directly address observer resurrection mechanics, although they are library tests, not an application's status/catalog observer loop.

Only add a new joined async case when a selected consumer actually adopts the owner. Otherwise classify remaining product asynchronous fairness, sustained overload, repeated startup churn and status-observer resurrection as unqualified, not passed. If a bounded new synthetic churn check is desired, cap it to three attempts: partial setup rejection, readiness rejection with first cleanup failure/retry, then successful fresh attempt. Assert same retained owners, zero forbidden publication/effects, exact release/debt identity and fresh successful behavior. It remains a TEST-owner regression, not a product or fleet promise. It is lower priority than P1/P2.

## Effort and alternatives

These are incremental hand-maintained estimates, excluding generated emitted JavaScript, vendor packages and unchanged borrowed fixture copies. No production implementation is authorized by this review. Scores are judgments within each stated scope, not availability metrics.

| Alternative | Confidence /10 | Achievable reliability /10 | Complexity /10 | Production LOC | Integration/tooling LOC | Tests/fixtures LOC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| P1/P2 real public-port packed consumer, reuse GM/test process owner | 9 | 9 for exact public package/selection/restart observations | 3 | 0 | 80–150 | 220–350 |
| Optional P3 single packed-helper race counterexample | 8 | 9 for detecting the selected substitution; no custody guarantee | 3 | 0 | 0–40 | 60–100 |
| New synthetic repeated-failure/observer host matrix | 6 | 7 within its artificial contract | 6 | 0 | 120–250 | 300–600 |
| Actual product plugin/artifact custody E2E today | 3 | Not rated: concrete owner/loader/product consumer absent | Not defensibly scoped | No defensible estimate | No defensible estimate | No defensible estimate |

Hard initial budget: **at most 500 new maintained TS lines** across P1/P2 (plus approximately 30–60 declarative configuration lines), reusing existing packing/process/public contract helpers where feasible. If finishing honest public-port coverage requires a new loader, scheduler, runtime registry, generic manager or production change, stop and report the missing seam. P3 is optional and should keep the complete bounded experiment at most about 600 maintained TS lines. Do not grow a framework to hit a scenario checklist.

## Acceptance and stopping criteria

1. Strict compiler >=7.0.2 covers every new maintained `.ts` fixture and runner. Preflight actual compiler paths, including embedded tooling; no TS5.9 initialization, suppression or node_modules edits. Existing Foundation 1.7.2 blocked gate remains an independent owning issue.
2. A/B/H are independently packed, installed and imported via their public package surfaces. The test uses generated JS from their authoritative strict TS, not handwritten new JS/.mts helpers.
3. The actual unchanged discovery use case changes its useful candidate output with B/H and restores baseline with B removed plus fresh child startup. Product invariants in the same workflow remain enforced.
4. Explicit binding selects the provider. Provider enumeration order alone cannot select a singleton; ambiguity rejects with zero factory evaluation in the exercised GM seam.
5. Receipts contain actual named executed checks and no skipped/cancelled/unexpected-failure rows silently counted as passes. Preserve failed controls separately. Compile/install success is not invocation success.
6. Hash/source/installed-byte equality and runtime observations have separate fields and claims. No claim of byte custody, provenance authentication, hostile isolation, arbitrary unload, data migration or physical descendant cleanup follows from package loading.
7. Product E2E remains explicitly incomplete with the exact missing owner stated: an application consuming the selected extension point and a real product/executor artifact-admission handoff. Do not redefine a synthetic fixture into that owner.
8. Stop after the bounded decisive journey and controls. Do not repeat unchanged N1000/1,024-live/dense/lifecycle matrices, migrate Orchestrator's accepted GM/CMS pin, install a new runtime, modify frozen archives/accepted ADRs, commit or publish from this assignment.

## Coordination

Sent the consumer planner the public-port limits, the need for a real invoked outcome, independent H, exact package-byte receipts and A/B/A fresh-process sequence. The planner independently found no materialized application consumer and selected the same local-host-control public port as the maximum honest current seam. Root requested and received pre-implementation approval for this bounded scope, the three minimum rejection controls and the pure per-instance async binding test. The planner proposed B wrapping a fallback source and exact retained GM 0.5.0 archives, preserving the consumer's accepted package baseline rather than adopting current GM main. This agreement is review evidence, not additional runtime execution.
