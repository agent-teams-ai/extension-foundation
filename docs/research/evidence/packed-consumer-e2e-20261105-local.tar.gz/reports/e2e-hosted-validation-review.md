# Hosted validation review — packed consumer E2E

Date: 2026-11-05. Scope: read-only recommendation for the completed local public-package experiment. No workflow, source, dependency, managed Cohort or required-gate changes were made in this review; no compiler or Foundation CLI was executed.

## Recommendation

Run the exact reviewed research archive in four disposable hosted jobs: Linux on each supported Node minimum, macOS on the default Node minimum, and Windows Server 2022 on the default Node minimum. Extract outside the EF checkout, install only the experiment's frozen dependency graph, and invoke its existing `pnpm e2e` entry. This is a bounded continuation of the public-package integration experiment. It adds no plugin authority and makes no product Host, admission, custody, lifecycle or registry-provenance claim.

The independent route is legitimate because its complete maintained TypeScript driver receives an explicit strict TypeScript 7.0.2 check before execution, and the same exact compiler builds the copied A package, B/H and consumer. It must not be described as passing EF's full gate or resolving Foundation 1.7.2's embedded TypeScript 5.9.3 conflict.

## Exact matrix and actions

| Job identity | Hosted image | Test Node | Coverage |
| --- | --- | --- | --- |
| packed-consumer-linux-node24 | `ubuntu-24.04` x64 | `24.21.0` | Lower supported Node 24 boundary, Linux packing and installation. |
| packed-consumer-linux-node26 | `ubuntu-24.04` x64 | `26.11.1` | Default supported Node 26 boundary. |
| packed-consumer-macos-node26 | `macos-15` arm64 | `26.11.1` | macOS filesystem/package execution plus a second native compiler architecture. |
| packed-consumer-windows-node26 | `windows-2022` x64 | `26.11.1` | Windows drive paths, pnpm shims, archive file references and subprocess behavior. |

Use an explicit four-row include matrix, `fail-fast: false`, and a 20-minute job timeout. The driver already has a ten-minute outer test deadline and three-minute individual child deadlines. A six-row Cartesian product is unnecessary for this finite experiment: the two Linux rows cover both Node families; the other rows cover platform differences. If only two Linux rows are run, report Linux-only evidence and leave macOS/Windows unqualified. Do not skip a failing platform to obtain a broader green claim.

The official runner-images inventory at commit `42d27e4a2c1232e5640a88ed42a974c8918ecd28` confirms these labels and architectures. `macos-15` is arm64; use `macos-15-intel` only if x64 is deliberately selected instead. Hosted image labels are versioned OS selections, not immutable machine-image pins: retain each job's actual image version and runner metadata.

| Action | Exact immutable action commit | Release identity / runtime |
| --- | --- | --- |
| `actions/checkout` | `3d3c42e5aac5ba805825da76410c181273ba90b1` | v7.0.1; `node24`. Matches existing EF CI. |
| `actions/setup-node` | `820762786026740c76f36085b0efc47a31fe5020` | v7.0.0; `node24`. Matches existing EF CI. |
| `pnpm/action-setup` | `0ebf47130e4866e96fce0953f49152a61190b271` | v6.0.9; `node24`; peeled commit of the existing EF action version. |
| `actions/upload-artifact` | `cf430e030ddbb5b0abf93d22962f4752f3646cd9` | v7.0.2; `node24`. Parent's previously used pin, verified against official tag and action source. |

The existing EF pnpm setup pin `008330803749db0355799c700092d9a85fd074e9` is the **annotated tag object**, which points to commit `0ebf47130e4866e96fce0953f49152a61190b271`. Pinning the peeled commit selects the same published action version without depending on a tag-object identity. This does not require unrelated edits to existing CI.

Action-host `node24` and the selected test Node are separate runtimes. Setup-node must install the exact matrix version before pnpm setup. The action-host patch version is owned by GitHub's runner; record the selected test executable/version rather than claiming every action ran that exact patch.

## Two setup pitfalls to avoid

**Bind pnpm setup to the extracted experiment manifest.** EF root declares pnpm 11.18.0; the experiment declares 11.25.0. At the inspected v6.0.9 action commit, supplying `version: 11.25.0` while leaving `package_json_file` at its default causes a deliberate mismatch error. The action reads the workspace-root manifest even if later run steps have an external working directory.

The action implements manifest lookup using `path.join(GITHUB_WORKSPACE, packageJsonFile)`, and its input contract requires a relative path. Consequently an absolute `$RUNNER_TEMP/.../package.json` is not a reliable binding. After staging the archive, compute `os.path.relpath(extracted_manifest, GITHUB_WORKSPACE)` in the host extraction step, expose it as a step output, and pass that relative value as `package_json_file`. Fail on an unsupported cross-drive Windows path; never fall back to EF root. A relative path deliberately leading to the sibling temporary directory selects the existing experiment manifest without adding a duplicate toolchain manifest.

Set pnpm setup `version: 11.25.0`, `run_install: false`, `standalone: false`, and `cache: false`. Set setup-node `package-manager-cache: false` and omit its `cache` input. The first finite qualification run gains little from cache complexity. The pnpm action uses a committed-integrity npm bootstrap of pnpm 11.7.0 and then self-updates to the requested version; this is package-manager bootstrap, not execution of an old TypeScript compiler. The driver independently asserts actual pnpm 11.25.0.

**Preserve hidden evidence deliberately.** Upload-artifact excludes hidden files by default. The receipts live under `.runs`. Either copy only selected receipts/logs into an ordinary evidence directory, or set `include-hidden-files: true` with narrow paths for `.runs/run-*/receipt.json` and `.runs/run-*/logs/*.log`. Do not upload the entire `.runs` tree: it also contains installed dependencies and generated working copies.

## Safe handling of this exact research archive

The parent plans a committed branch-only input archive containing exclusively regular files, with a reviewed per-member ledger at creation. This is a fixed research input, not an arbitrary extension or admission API. Preserve that boundary.

1. Verify the complete committed archive SHA-256 before parsing or writing anything. Bind the expected digest to the reviewed workflow/research record. A digest confirms the selected bytes; it does not establish custody or independent provenance.
2. Create a fresh, short directory beneath `RUNNER_TEMP`, outside the checkout and outside any pre-existing pnpm workspace. Never extract over source, `node_modules`, a previous run or an arbitrary caller-selected directory.
3. Use Python's mature stdlib `tarfile` reader to enumerate and validate every member first. Do not use `extractall`. Accept regular files only; reject directories, symlinks, hard links, devices and FIFOs. This matches the proposed archive's positive file-only contract.
4. Require canonical POSIX relative member names under the one expected archive root. Reject empty or dot components, `..`, absolute paths, backslashes, drive/UNC syntax, colons/Windows alternate data streams, Windows reserved names and trailing spaces/dots. Reject duplicate names and case-fold collisions, and a file name that is another member's parent. Check the complete set and individual byte sizes against the reviewed ledger, with finite member/total-size limits chosen from the actual finalized archive.
5. After all members pass, create parent directories and write each regular member's bytes into the fresh destination using exclusive creation. Resolve each destination beneath that destination root, reject escape, and check written size and member SHA-256 against the ledger. Do not apply tar ownership, permissions or link metadata. Do not recursively unpack the retained GM tarballs: they remain ordinary input files for pnpm.
6. Retain the outer archive identity, member-ledger identity and extraction result with the hosted evidence. The final archive digest cannot be supplied by this review because the final input archive has not yet been authored.

The Python choice has a specific boundary advantage: reuse of the platform archive parser before the npm graph exists, without introducing a handwritten JavaScript parser or a second application runtime. It does not replace or weaken strict TypeScript checking of the maintained experiment code. Manual validated member writes avoid relying on a particular Python `extractall(filter=...)` API version. Keep this as bounded workflow host glue, without creating a generic archive service, plugin loader or signature authority.

## Exact execution route

After checkout with `persist-credentials: false`, use the reviewed head SHA for a pull request and the event SHA for push/merge-group/manual execution. Use read-only `contents` permission; no repository-write, OIDC, package-write, extra product checkouts, custom tokens or secrets are needed. Do not use `pull_request_target` or a privileged workflow-run handoff for PR code.

The staged experiment's working directory is the only install/run working directory:

```text
pnpm install --frozen-lockfile --ignore-scripts --engine-strict --strict-peer-dependencies
pnpm e2e
```

Do not call an EF root script, root install, recursive workspace command, Foundation CLI, old mandatory Node runner, copied A `check`/`prepack` script, or an unpinned `pnpm dlx`/`npx` compiler. The runner already explicitly builds A and suppresses lifecycle scripts for packing using pnpm configuration; it verifies packing preserves the compiled output. Its current child invocations use the executing Node binary and actual pnpm JavaScript CLI path, avoiding direct Windows `.cmd` execution.

The installed experiment lock contains TypeScript 7.0.2, its exact 7.0.2 platform optional packages, Node type definitions 24.13.3 and undici type definitions 7.18.2. It contains no Foundation or API Extractor dependency. Its tsconfig spells strict options directly; retained Foundation presets are JSON data, not executable imports. Native packages for Linux x64, macOS arm64/x64 and Windows x64/arm64 are already represented in the lock. Do not disable optional dependencies: the selected native compiler package is required.

All fixture packages are installed through ordinary packed `file:` archive dependencies. Their overrides select the exact retained Core and independently packed helper archive; they do not alias workspace source. Do not add `NODE_PATH`, TypeScript `paths`, source symlinks or an npm scope registry authority. Retained GM 0.5.0 tarballs remain explicitly unauthenticated historical bytes; hosted reruns do not convert them into fresh registry-origin evidence.

## Required result and evidence

The test process must exit zero; no `continue-on-error`, test-name filtering or platform exceptions are appropriate here. Retain the complete Node test summary and the runner receipt showing `status: passed`, the ten named completed scenarios, child outcomes, command outcomes and installed/archive inventories. Successful type stripping alone is not typecheck evidence: the existing `e2e` script explicitly runs `pnpm typecheck` first, then the driver compiles A/B/H/consumer with the same local TS7 compiler.

Upload narrow diagnostic artifacts on success and failure with unique matrix/run-attempt names and finite retention. Preserve the original failing job result if receipt upload succeeds. A missing receipt after early install/typecheck failure is a failed or incomplete run, never a pass. Include actual checked-out commit, archive digest, Node version/platform/architecture, pnpm version, compiler identity and image version in the review record. The current receipt includes Node version and platform but not architecture; host metadata can provide architecture without changing the runner.

The existing EF `required-node-tests.json` protects three exact custody identities and their exact Windows/POSIX applicability. Do not add unrelated research identities to it, remove its checks, or claim this experiment replaces it. The existing `node-compatibility` suite binds root pnpm 11.18.0 and the mandatory-runner contract, so it is not the command for this experiment. The workflow changes fall under EF's configured full-scan paths; hosted experiment success remains separate evidence from the existing root gates and their known embedded-compiler conflict.

For the proposed temporary branch-only hosted run, retain the exact input archive, workflow text, commit/tree identities, run IDs, job conclusions and downloaded receipts in the research evidence. Removing the temporary workflow after successful finite qualification is reasonable; do not turn one experiment into new central governance or imply continuous coverage after removal.

## Cost and confidence

These are engineering judgments for this finite slice, not availability measurements. Estimates are incremental and exclude the existing experiment, copied A/GM inputs and hosted service maintenance.

| Option | Confidence /10 | Scoped reliability /10 | Complexity /10 | New production LOC | Integration/host glue LOC | New test LOC |
| --- | --- | --- | --- | --- | --- | --- |
| Four exact rows, checked fixed archive, existing strict TS7 entry | 9 | 9 after all four actually pass | 3 | 0 | Approximately 100–160 YAML/Python lines | 0; reuse ten existing named scenarios |
| Linux Node24+26 only | 9 for Linux | 8 for Linux; other OS unqualified | 2 | 0 | Approximately 90–145 | 0 |
| Upgrade EF/Foundation/Cohort before this independent experiment | 4 as a delivery prerequisite | Not qualified by this review | 8 | Separate owning change | Unbounded here | Separate owning qualification |

The four-row route is the smallest recommendation that covers both supported Node families and each requested OS. Platform execution is still pending at this read-only review checkpoint. A green local run and this review do not predict away Windows/macOS failures; the proposed jobs resolve that uncertainty directly.

## Inspected identities and sources

Local source snapshot inspected for this report:

| File | SHA-256 |
| --- | --- |
| experiment/package.json | `b6181d636c98b3ad00f78109e226eb0c1ae541182f7566612a2bdaa99b7eba3d` |
| experiment/pnpm-lock.yaml | `7be86a8a676d6a876cbe0dee8ee21db85e716c9743d1f59e784e1ccf876bc5ed` |
| experiment/tsconfig.json | `25061c1d2cf0468d17211a9783f1da31a72722882873860fc1f35233905e71e8` |
| experiment/src/e2e.test.ts | `91f4e5dd2fe94a88231105ee40ae125c8cc5220a0c8eb1d0807c095a8bab8e82` |

The uninstalled experiment snapshot currently consists of 28 files and 160,776 bytes, excluding node_modules and retained run output. These are inspection facts, not the yet-to-be-finalized archive's limits or identity. Recompute the final member ledger after any maintained-source correction.

Local policy/source reads: `brief.md`, `quality-standard.md`; EF `AGENTS.md`, `.github/workflows/ci.yml`, `.github/workflows/docs-protocol.yml`, `architecture/foundation/repository-agent-workflow.yaml`, `architecture/foundation/scaffolding.yaml`, `architecture/foundation/required-node-tests.json`, `tests/node-compatibility.test.mjs`, `tests/foundation-upgrade.test.mjs`, root package.json; experiment package.json, lock, tsconfig, driver, copied A manifest and retained preset/provenance data.

Official metadata/source read on 2026-11-05:

- [Checkout v7.0.1 tag identity](https://api.github.com/repos/actions/checkout/git/ref/tags/v7.0.1) and [exact action source](https://github.com/actions/checkout/blob/3d3c42e5aac5ba805825da76410c181273ba90b1/action.yml).
- [Setup-node v7.0.0 tag identity](https://api.github.com/repos/actions/setup-node/git/ref/tags/v7.0.0) and [exact action source](https://github.com/actions/setup-node/blob/820762786026740c76f36085b0efc47a31fe5020/action.yml).
- [Pnpm v6.0.9 annotated tag](https://api.github.com/repos/pnpm/action-setup/git/tags/008330803749db0355799c700092d9a85fd074e9), [exact action contract](https://github.com/pnpm/action-setup/blob/0ebf47130e4866e96fce0953f49152a61190b271/action.yml), [exact manifest lookup/bootstrap implementation](https://github.com/pnpm/action-setup/blob/0ebf47130e4866e96fce0953f49152a61190b271/src/install-pnpm/run.ts) and [bootstrap lock](https://github.com/pnpm/action-setup/blob/0ebf47130e4866e96fce0953f49152a61190b271/src/install-pnpm/bootstrap/pnpm-lock.json).
- [Upload-artifact v7.0.2 tag identity](https://api.github.com/repos/actions/upload-artifact/git/ref/tags/v7.0.2) and [exact action source](https://github.com/actions/upload-artifact/blob/cf430e030ddbb5b0abf93d22962f4752f3646cd9/action.yml).
- [Runner label/architecture inventory](https://github.com/actions/runner-images/blob/42d27e4a2c1232e5640a88ed42a974c8918ecd28/README.md), [Windows 2022 software](https://github.com/actions/runner-images/blob/42d27e4a2c1232e5640a88ed42a974c8918ecd28/images/windows/Windows2022-Readme.md) and [macOS 15 arm64 software](https://github.com/actions/runner-images/blob/42d27e4a2c1232e5640a88ed42a974c8918ecd28/images/macos/macos-15-arm64-Readme.md).

## Final review of the concrete branch-only workflow

The parent subsequently prepared the actual candidate workflow and frozen archive. I reviewed them read-only before push; **there are no blocking findings for these exact input bytes**. This is a source/metadata and archive-content review, not hosted execution evidence.

| Reviewed item | Exact identity |
| --- | --- |
| `.github/workflows/packed-consumer-e2e-research.yml` | SHA-256 `33e311faad52a2e45c43aa9a2be20e26ab54cefb84cfd0ecf81b284efd7ed7d1` |
| `docs/research/evidence/packed-consumer-e2e-20261105-inputs.tar.gz` | SHA-256 `61fc7aa6b921ce9e68ea8c52165aa08ca6f0f06efdae114e3a23bf779cbbd500`; 105,046 compressed bytes |
| `docs/research/evidence/packed-consumer-e2e-20261105-inputs.json` | SHA-256 `83c454db9933466741658dbcfe8a2fc6dcdd30cd5cf53c95a1729776fcd66191` |
| Final member set | 29 regular files; 165,527 expanded bytes; all member sizes and SHA-256 identities independently match the ledger |

The finalized archive adds the reviewed experiment README relative to the earlier 28-file inspection snapshot. The package, lock, strict tsconfig and runner identities above remain identical.

The candidate implements the recommended four exact matrix rows, read-only token permission, credential-free checkout, branch/path-limited push trigger, hash-bound staging outside the checkout, setup-node before pnpm setup, relative extracted-manifest binding, pinned pnpm 11.25.0, explicit frozen/ignored-script installation, the unchanged strict e2e entry, and failure-preserving shell pipelines. It does not install EF root dependencies or run Foundation/API Extractor. The collector runs with `always()`, skips every `node_modules` directory and all symlink files, and preserves actual command logs, receipts, generated configs, packed outputs and exact inputs in a tar archive. This is larger than the narrow receipts/logs-only recommendation but is bounded by this finite experiment and is useful reproducibility evidence. The uploader uses the verified v7.0.2 commit, unique matrix/SHA/attempt names and fourteen-day retention.

The extraction code checks the hardcoded complete archive digest before parsing; matches exactly 29 unique case-folded, ordinary relative file entries against the selected ledger; checks each declared byte length; and verifies each member SHA-256 before its write. It uses manual member writes rather than applying tar metadata. The specific finalized names have additionally been inspected independently for canonical names, Windows reserved names, trailing dots/spaces, collisions and parent/file conflicts; all are clean.

The candidate does not implement every generic extractor hardening item proposed earlier, including a separate explicit total-byte ceiling, all Windows pathname rules, independent per-member write containment, exclusive creation, and validation of every member payload before the first file write. **These are nonblocking for the selected scope:** the hardcoded outer digest already fixes the exact finite archive whose members were independently checked, and a write failure stops the job before installation. Do not broaden the workflow into an arbitrary-archive service or describe these checks as a general hostile-input extractor. A future archive changes its reviewed digest/ledger and requires the same bounded review.

The chosen fifteen-minute timeout is acceptable for the first finite run. Twenty minutes remains a reasonable adjustment only if install/network latency consumes the budget; timeout cannot be treated as a pass. Automatic package-manager caching remains harmless with the selected pnpm root, but explicitly disabling setup-node `package-manager-cache` would make the intended no-cache setup clearer; it is not a blocker.

The final candidate workflow and input archive are ready for the parent's authorized push and real four-platform execution. Job results and actual receipts must still be inspected before declaring hosted validation complete. No compiler, test command, workflow trigger or remote mutation was executed by this reviewer.

### Final explicit setup options checkpoint

Read the final concrete workflow again after the parent added only three explicit setup inputs: setup-node `package-manager-cache: false`, pnpm setup `standalone: false`, and pnpm setup `cache: false`.

- **Latest reviewed workflow SHA-256:** `40feb0f6f51085221627f992931c8865c99c28c406babc56a6a9c3a842d1b5d3`.
- Prior reviewed workflow identity `33e311faad52a2e45c43aa9a2be20e26ab54cefb84cfd0ecf81b284efd7ed7d1` is retained above as history.
- The fixed archive and ledger identities remain those in the preceding concrete review.
- **Decision: no blocking findings; ready for the authorized push and actual hosted execution.** The three explicit options align setup with the review's intended no-cache, selected-Node route. They add no runtime authority, root install or old compiler initialization. No compiler, test, workflow or remote action was executed in this follow-up.



