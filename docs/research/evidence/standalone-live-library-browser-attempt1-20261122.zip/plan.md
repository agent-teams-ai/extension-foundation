# Bounded native React/Vite/Yjs browser continuity probe

Written before browser execution, 2026-11-22. Extends the previously successful
plugin-reload-browser-input-20261122-v2.tar.gz fixture; does not replace Vite HMR
or React Refresh. Frozen dependencies remain React/React DOM 19.3.1, Vite 8.3.8,
plugin-react 6.3.0, Playwright 1.65.1, TypeScript 7.0.2, corresponding exact types;
only Yjs 13.6.33 is added. Hosted execution is owned by the root agent.

Three sequential scenarios share one actual browser page:

1. Dirty host-owned Y.Doc and UndoManager, a focused textarea with selected caret
   range, and plugin v1 projection. Write the real v2 source file; wait for native
   HMR. Independent DOM assertions require changed projection behavior, same
   textarea identity/value/focus/selection, same document identity and exactly
   one declared plugin subscription plus one real DOM event listener. Undo and
   Redo must actually change the textarea and plugin projection after updating.
2. Write v3 with a changed hook signature; plugin remount is expected. Require
   a new plugin DOM identity but the original host textarea/document/draft/history.
   A real user edit and Undo/Redo must reach only the current subscription.
3. Write a strictly type-correct candidate that reports its own initialization
   failure then throws during actual module evaluation. The host renders that
   explicit diagnostic; it does not infer readiness from an HMR acknowledgement.
   Require an actual browser/Vite error, retained usable v3 DOM/projection/event
   listener and draft. Then perform a new user edit through v3 and Undo it, so
   usable-v3 is established by computation, not only retained DOM. Write repaired
   v4 and require genuine recovered output.

The candidate failure diagnostic is fixture instrumentation for this known
initialization failure, not a generic exception detector or new update manager.
The plugin receives only getSnapshot/subscribe returning strings and cleanup;
no mutable Y.Doc/Y.Text or history object is passed to it. This is a trusted-code
API discipline demonstration, not an in-process security sandbox. Host controls
text mutations and Undo/Redo. Exact callback cleanup belongs to the component.

Use the prior fixture's independent-edit spacing (100 ms) to avoid the known
Chokidar same-path suppression window. No rapid-burst watcher guarantee follows.
Assertions are on actual DOM, document identity, focus/selection, user actions,
real event responses and trace ordering; counters alone are not cleanup proof.
Preserve console/errors, watch events, comparisons, final sources, screenshot
and all failures. Typecheck every valid and deliberately rejecting variant
before browser execution. Frozen install; no suppression or skipLibCheck.

Not covered: production switching, IME/composition, collaboration provider or
network persistence, schema migration, arbitrary raw-reference revocation,
crash recovery, general candidate rollback, memory bounds or leak freedom.
