import { useEffect, useState, useSyncExternalStore } from 'react';
import { Plugin } from './Plugin.tsx';
import { draftRead, hostActions } from './state.ts';
import { failureEvent, type CandidateFailure } from './probe.ts';
export function Host() {
  const value = useSyncExternalStore(draftRead.subscribe, draftRead.getSnapshot);
  const [failure, setFailure] = useState<CandidateFailure | null>(null);
  useEffect(() => {
    const listener = (event: Event) => {
      if (!(event instanceof CustomEvent)) return;
      const detail: unknown = event.detail;
      if (typeof detail !== 'object' || detail === null || !('candidate' in detail) || !('message' in detail)) return;
      if (typeof detail.candidate !== 'string' || typeof detail.message !== 'string') return;
      setFailure({ candidate: detail.candidate, message: detail.message });
    };
    window.addEventListener(failureEvent, listener);
    return () => window.removeEventListener(failureEvent, listener);
  }, []);
  return <main>
    <h1>Native live-feedback continuity probe</h1>
    <label>Host-owned draft<textarea data-testid="draft" value={value} onChange={event => hostActions.replace(event.target.value)} /></label>
    <button data-testid="undo" onClick={hostActions.undo}>Undo</button>
    <button data-testid="redo" onClick={hostActions.redo}>Redo</button>
    <p data-testid="candidate-failure" role="status">{failure ? `Candidate ${failure.candidate} failed: ${failure.message}` : 'No candidate failure reported'}</p>
    <p>The panel reports the currently usable view. The failure above remains in diagnostic history after recovery.</p>
    <Plugin draft={draftRead} />
  </main>;
}
