import { failureEvent } from './probe.ts';
import type { ReadDraft } from './probe.ts';
function rejectCandidate(): void {
  const message = 'intentional candidate initialization failure';
  window.dispatchEvent(new CustomEvent(failureEvent, { detail: { candidate: 'bad-v4', message } }));
  throw new Error(message);
}
rejectCandidate();
export function Plugin({ draft }: { draft: ReadDraft }) {
  return <output>{draft.getSnapshot()}</output>;
}
