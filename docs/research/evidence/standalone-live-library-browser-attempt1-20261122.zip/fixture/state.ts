import * as Y from 'yjs';
import { probe, type ReadDraft } from './probe.ts';
const document = new Y.Doc();
probe.documentId = document.guid;
const text = document.getText('user-draft');
const origin = Symbol('host-user');
const history = new Y.UndoManager(text, { trackedOrigins: new Set([origin]), captureTimeout: 0 });
export const draftRead: ReadDraft = Object.freeze({
  getSnapshot: () => text.toString(),
  subscribe(listener: () => void) {
    text.observe(listener);
    return () => text.unobserve(listener);
  },
});
export const hostActions = Object.freeze({
  replace(value: string) {
    document.transact(() => { text.delete(0, text.length); text.insert(0, value); }, origin);
  },
  undo() { history.undo(); },
  redo() { history.redo(); },
});
