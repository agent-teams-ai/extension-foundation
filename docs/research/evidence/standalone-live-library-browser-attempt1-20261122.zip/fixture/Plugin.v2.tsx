import { useEffect, useState } from 'react';
import { probe, type ReadDraft } from './probe.ts';
export function Plugin({ draft }: { draft: ReadDraft }) {
  const [value, setValue] = useState(() => draft.getSnapshot());
  useEffect(() => {
    probe.trace.push('plugin:v2:setup');
    probe.activeSubscriptions++;
    probe.subscriptionsCreated++;
    const onDraft = () => {
      probe.trace.push('plugin:v2:draft');
      setValue(draft.getSnapshot());
    };
    const unsubscribe = draft.subscribe(onDraft);
    setValue(draft.getSnapshot());
    const event = () => { probe.trace.push('plugin:v2:event'); };
    window.addEventListener('research-plugin-event', event);
    return () => {
      unsubscribe();
      window.removeEventListener('research-plugin-event', event);
      probe.activeSubscriptions--;
      probe.subscriptionsRemoved++;
      probe.trace.push('plugin:v2:cleanup');
    };
  }, [draft]);
  return <section data-testid="plugin">
    <h2 data-testid="usable-version">v2</h2>
    <output data-testid="projection">{'v2 · ' + value.toUpperCase()}</output>
  </section>;
}
