import { useEffect, useState, useMemo } from 'react';
import { probe, type ReadDraft } from './probe.ts';
export function Plugin({ draft }: { draft: ReadDraft }) {
  const [value, setValue] = useState(() => draft.getSnapshot());
  const extra = useMemo(() => "remount-boundary", []);
  useEffect(() => {
    probe.trace.push('plugin:v4:setup');
    probe.activeSubscriptions++;
    probe.subscriptionsCreated++;
    const onDraft = () => {
      probe.trace.push('plugin:v4:draft');
      setValue(draft.getSnapshot());
    };
    const unsubscribe = draft.subscribe(onDraft);
    setValue(draft.getSnapshot());
    const event = () => { probe.trace.push('plugin:v4:event'); };
    window.addEventListener('research-plugin-event', event);
    return () => {
      unsubscribe();
      window.removeEventListener('research-plugin-event', event);
      probe.activeSubscriptions--;
      probe.subscriptionsRemoved++;
      probe.trace.push('plugin:v4:cleanup');
    };
  }, [draft]);
  return <section data-testid="plugin" data-boundary={extra}>
    <h2 data-testid="usable-version">v4</h2>
    <output data-testid="projection">{'v4 · ' + String(value.length)}</output>
  </section>;
}
