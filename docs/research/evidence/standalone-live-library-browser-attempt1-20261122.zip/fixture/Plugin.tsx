import { useEffect, useState } from 'react';
import { probe, type ReadDraft } from './probe.ts';
export function Plugin({ draft }: { draft: ReadDraft }) {
  const [value, setValue] = useState(() => draft.getSnapshot());
  useEffect(() => {
    probe.trace.push('plugin:v1:setup');
    probe.activeSubscriptions++;
    probe.subscriptionsCreated++;
    const onDraft = () => {
      probe.trace.push('plugin:v1:draft');
      setValue(draft.getSnapshot());
    };
    const unsubscribe = draft.subscribe(onDraft);
    setValue(draft.getSnapshot());
    const event = () => { probe.trace.push('plugin:v1:event'); };
    window.addEventListener('research-plugin-event', event);
    return () => {
      unsubscribe();
      window.removeEventListener('research-plugin-event', event);
      probe.activeSubscriptions--;
      probe.subscriptionsRemoved++;
      probe.trace.push('plugin:v1:cleanup');
    };
  }, [draft]);
  return <section data-testid="plugin">
    <h2 data-testid="usable-version">v1</h2>
    <output data-testid="projection">{'v1 · ' + value}</output>
  </section>;
}
