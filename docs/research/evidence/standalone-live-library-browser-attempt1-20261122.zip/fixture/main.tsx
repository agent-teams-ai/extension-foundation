import { createRoot } from 'react-dom/client';
import { Host } from './Host.tsx';
import './probe.ts';
const element = document.getElementById('root');
if (!element) throw new Error('Missing root');
createRoot(element).render(<Host />);
