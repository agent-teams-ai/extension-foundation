export interface FeedbackProbe {
  documentId: string;
  trace: string[];
  activeSubscriptions: number;
  subscriptionsCreated: number;
  subscriptionsRemoved: number;
}
export const probe: FeedbackProbe = {
  documentId: crypto.randomUUID(), trace: [], activeSubscriptions: 0,
  subscriptionsCreated: 0, subscriptionsRemoved: 0,
};
declare global { interface Window { feedbackProbe: FeedbackProbe; } }
window.feedbackProbe = probe;
export interface ReadDraft {
  getSnapshot(): string;
  subscribe(listener: () => void): () => void;
}
export interface CandidateFailure { candidate: string; message: string; }
export const failureEvent = 'research-candidate-failure';
