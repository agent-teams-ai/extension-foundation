# Live feedback, component updates, and state continuity

Date: 2026-11-22, Europe/Kiev. **Research and a bounded native probe; no production
API or dependency adoption.** This adds five mechanism families and a Theia
comparison to EF PR55's earlier Flutter/React/Vite work. Existing evidence is
not rerun or relabelled.

## Decision

Keep user documents and their history under a stable state owner. Treat views,
analyzers, executors, and host processes as separately replaceable consumers.
Choose the smallest *supported* update boundary; show its actual consequences.
A loaded module, selected implementation, rendered view, usable capability, and
retired predecessor are different observations.

Reuse a released loader/lifecycle/CRDT where its unit fits. The portable library
should contribute update coordination and facts at existing ownership boundaries,
not a competing router, resource supervisor, dependency resolver, state store,
or universal editor framework.

**New execution evidence:** seven Yjs 13.6.33 cases passed on Node 24.22.3; strict
TypeScript 7.0.2 passed with dependency declaration checking. Actual document
binary updates were exchanged between Y.Doc instances. Source blobs and installed
runtime bytes match the released npm archive. Browser behavior, durable storage,
provider networking, and production isolation were not exercised. [P01]

## 1. Source traces and failure behavior

### Module Federation: loading is useful; force registration is not retirement

Inspected 2.9.3, commit `40688424f13ea9d4338b9a0cf230e8f1ac4d3835`.
In `remote/index.ts`, force registration invokes removal before installing the
replacement. Removal changes registration, manifest/global/module caches and some
share records, and catches/logs errors. The path does not invoke an application
unmount/resource-disposal protocol. A retained export is not revoked by deleting
its loader cache; that last point follows JavaScript reference semantics, not a
native federation experiment. [F01]

The same load path records original failure plus `recovered: true` when an error
hook supplies a fallback. Existing hooks can expose the selected share provider
and distinguish the candidate share record from the record that remains registered.
Use these facts rather than infer success from a resolved loading promise.
A fallback may keep the panel useful while the requested candidate is still
unavailable. [F01, F11]

Historical issue 4045 describes cached expose chunks surviving forced
re-registration. The maintainer warns that forced changes can disrupt singleton
sharing and suggests versioned build identity. The issue is closed
`not_planned`; this is failure-mode evidence, **not a reproduced 2.9.3 defect**.
Immutable identity must cover the entry, chunks, and compatible shared-dependency
closure. Merely changing an entry URL is an insufficient qualification test. [F10]

**Reuse:** enhanced runtime loading, hooks, and existing framework bridges when
remote modules fit the product. **Gate:** load v1 and v2 together using the actual
bundler; invoke a retained v1 export after v2 preparation; inspect selected shares,
chunk identity, and actual owner cleanup. Do not promote `force: true` into a
generic update transaction.

### single-spa: a timeout has a precise, narrower meaning

Inspected 6.0.3, commit `b619c26f0a39bbc8f175805a361a88a22fbd6d9b`.
`reasonableTime` observes the lifecycle promise. With default
`dieOnTimeout: false`, expiry reports an error and keeps waiting. With
`dieOnTimeout: true`, it rejects its wrapper; it does not cancel the lifecycle
function. A later callback may still execute. [F02]

`unload.js` permits unloading an already unmounted app or a load failure;
otherwise it can return without unloading. Success deletes lifecycle bookkeeping
and returns to NOT_LOADED. Failure has separate broken status. The public
`waitForUnmount` option therefore has material behavior; unloading a module is
not evidence that arbitrary listeners it created are gone. [F03, F18]

**Reuse:** the existing app/parcel lifecycle if that is already the composition
unit. **Avoid:** another wrapper lifecycle for every method or resource.
**Gate:** deliberately delay unmount past its deadline, then release it and observe
late effects. The operator should see “cleanup delayed/failed” separately from
“new version selected”; elapsed time cannot prove release.

### Yjs: document, history, view, and write authority have separate lifetimes

Inspected 13.6.33, commit `9ea3a4fb57b814292ce18dfd13c4f422e44e6c5c`.
UndoManager first filters transaction scope/origin, then merges captures using a
time window without checking origin equality. `stopCapturing()` creates an
intentional boundary. `clear()` removes history; `destroy()` unregisters capture
listeners and does not call `clear()`. These mechanisms do not authorize writes.
[F04, F09]

Y.Doc destruction clears lifecycle handling; retained references matter. Its
public transaction forwarding does not consult `isDestroyed`. The experiment
below deliberately exercises this misuse to reject “destroy is a write fence” as
a design assumption. Do not adopt post-destroy access as a supported policy.
[F05, F13, P01]

| Real public-API case | Observed outcome | Consequence |
| --- | --- | --- |
| Replace exact view subscriptions; keep document/history | Only the new observer receives later edits; Undo/Redo still work | View disposal need not discard the draft |
| Adjacent edits from two tracked origins | One undo item; explicit stopCapturing yields two | Version changes need an intentional undo-grouping policy |
| Remove old origin from history and unsubscribe old view | Its late write still commits and reaches a peer | State owner must reject unauthorized writes before mutation |
| Clear history | Draft remains; Undo/Redo unavailable | “Clear history” and “discard draft” are separate actions |
| Encode document and restore into a new document/history | Content survives; previous Undo history does not | Hot restart needs an honest history-restoration promise |
| Restore encoded relative caret after peer prepend | Logical position resolves at index 3 instead of old index 2 | Reuse relative positions for compatible collaborative text |
| Write through retained text after Doc.destroy | Mutation and peer transfer still occur | Destruction is not reference revocation; misuse negative control |

All seven expected outcomes were documented before execution. The probe uses
actual Yjs transactions, observer removal, UndoManager, encoding/merging, and
relative-position codecs. It implements no replacement coordinator or mock
CRDT. First typecheck and runtime attempts passed. [P01]

A router gate cannot revoke a mutable Y.Doc/Y.Text already held by old code.
For revocable writes, use the existing host-owned mutation surface and avoid
exporting those references, or explicitly declare the resulting trust/lifetime
limit. A TypeScript readonly annotation does not enforce that boundary. [P01;
design consequence]

For collaborative editing, reuse document/history primitives and a maintained
editor binding. Relative-position resolution can return null when its referenced
type is unavailable/deleted; the view needs a deliberate fallback selection.
For an ordinary form, the existing host draft store is usually sufficient.
Neither choice solves arbitrary schema migration. [F12; recommendation]

### VS Code and Theia: expose the supported host boundary

VS Code 1.147.0 source, commit
`8a14f0cc1b08d531eb83255ea3764ae22aa932b5`, rejects dynamic removal once
`activationStarted` is set. Whole-host stopping gathers veto reasons and stops
host managers in reverse order. This provides two useful patterns: explicit
eligibility and understandable restart consequences. It does not promise
arbitrary replacement of active extension objects. [F06]

The documented host profiles differ: local/remote Node and browser WebWorker;
actual placement depends on extension capabilities and available hosts.
A browser adapter must not inherit Node filesystem/process assumptions. Theia
likewise separates runtime-installed API-bound extensions from compile-time DI
modules with access to internals. Replacing a composition module is a different
operation from restarting a plugin host. [F08, F14, F16]

Theia's old plugin-authoring page is explicitly deprecated; current guidance
recommends VS Code or Theia extensions instead of its special frontend-plugin
mechanism. Do not turn an attractive historical direct-UI example into the new
library's compatibility promise. [F14, F15]

**Reuse:** capability/contribution contracts, eligibility checks, host-level
fallback and scoped diagnostics. Embedding a full IDE platform is unjustified
for this library. **Gate:** restart the chosen boundary with real dirty documents,
remote services, and active work; verify which state survives.

### Web Components: registry identity constrains the replacement unit

The HTML Standard rejects a repeated name or constructor within the same
CustomElementRegistry. Scoped registries are a separate registration mechanism;
they do not rewrite already constructed objects. The standard also distinguishes
state-preserving moves using `connectedMoveCallback` from ordinary
disconnect/reconnect reactions. [F07]

Use a fresh supported subtree/registry or generation-specific tag only when
Web Components fit the integration. Do not implement a general prototype
rewriter or assume that moving a node has no lifecycle effects. Registry support
must be qualified against the product's actual browser matrix; this research
did not run that browser check. Framework-owned components should keep their
framework's supported lifecycle.

## 2. User journey: changes become visible without ambiguous state

This is a proposed integration flow, not a new state machine API.

1. **Preview:** show affected capability/view, requested version, current selected
   version, supported boundary, and explicit consequences for draft/history.
   Background preparation may continue while the user types. A hidden candidate
   must have isolated candidate resources or be limited to safe passive work;
   rendering it does not grant authority to emit mutations.
2. **Qualify:** load with the existing loader, prepare with the existing owner,
   and ask the product for a meaningful capability check. Examples are an
   analyzer returning a result for a known document revision, or a new panel
   producing its first usable render. Network prefetch alone proves neither.
3. **Select and render:** the authoritative owner selects an eligible candidate.
   Preserve the stable document and compatible session state; replace only
   declared view subscriptions/resources. Show “selected v2; panel still v1”
   until the v2 view acknowledges its first meaningful result.
4. **Retire:** old work reports its owning version and whether it can complete,
   must be cancelled, or remains blocked. Late results are checked at the owning
   mutation boundary. Failed cleanup stays visible even if v2 already works.
5. **Recover:** if readiness fails before selection, keep the current version and
   explain the failed check. After selection, a rollback is a new authorized
   transition with current state compatibility checks. It does not rewind user
   edits. A host restart states whether content, history, caret, and pending work
   are preserved, restored, reset, or unknown.

An illustrative status is:
“Analyzer v2 selected; panel v1 still visible; v1 has 2 admitted operations;
draft retained; Undo retained; one cleanup callback failed.”
The counts must come from an existing owner, not reconstructed from log timing.
A simple panel plus per-component status is enough; no UI framework is required.

## 3. Bounded diagnostic projection

Use existing owner snapshots and event/telemetry mechanisms. Keep the projection
read-only; commands return to the current authority.

| Fact | Its owner | Diagnostic rule |
| --- | --- | --- |
| Candidate artifact/version | Loader/artifact catalog | Show immutable identity and failed preparation stage |
| Selected version and authority revision | Existing selection owner | Never infer selection from import or render completion |
| Rendered/result version and document revision | View/capability adapter | Report only acknowledged useful output |
| Old admitted operations/resources | Existing operation/resource owner | “Unknown” is valid; absence of logs is not zero |
| Draft/history policy and schema compatibility | Existing state owner | Report content/history/caret independently |
| Failure, fallback, last confirmed cleanup | Owning lifecycle and loader | Preserve original error and fallback provenance |

For the optional UI projection, coalesce display updates by component, cap recent
diagnostics, redact user content, and resynchronize from an authoritative snapshot
after gaps or reconnect. Ordering uses owner-issued revisions, not wall clocks.
The authoritative owner, not a lagging projection, decides command eligibility.
Retry only when the underlying owner permits it.

Distinguish decision hooks from telemetry observers. A diagnostic exporter should
not block activation or turn a successful transition into failure. For a vendor
hook used as an observer, contain exporter errors inside that adapter; do not
assume all hook systems isolate errors. This is an integration design requirement,
not a claim of a reproduced Module Federation hook defect.

XState is not needed merely to draw status. A product may use it for its existing
interaction workflow, but this lane did not qualify its released implementation
and recommends no new dependency. The same restriction applies to adding a
second event bus or store just for the update panel.

## 4. Mistakes to prevent

| Warning | Safer practice | Evidence or decisive check |
| --- | --- | --- |
| Treat forced cache eviction as successful replacement | Separate immutable loading, selection, and owner retirement | F01, F10; real bundler/retained-export check |
| Count a fallback as requested-candidate readiness | Preserve failure and label fallback version | F11; fail real remote loading |
| Let a timeout masquerade as resource release | Track deadline and actual cleanup separately | F02; late lifecycle completion |
| Recreate document/history with every UI mount | Keep the compatible state owner stable; dispose exact subscriptions | P01 cases 1 and 5 |
| Use origins as authorization | Validate generation/capability at the actual state owner before mutation | P01 cases 3 and 7 |
| Merge edits accidentally across a semantic transition | Deliberately set capture boundaries; do not always clear Undo | P01 cases 2 and 4 |
| Promise restart preserves all session state | Specify document, Undo, cursor, and work independently | P01 cases 5 and 6 |
| Remount several plugin pieces independently while they share globals | Determine shared-runtime/dependency closure first | F10; coexistence qualification |
| Assume active IDE extensions are dynamically removable | Advertise eligibility and the actual restart boundary | F06 |
| Treat every scoped registry as broadly available/redefinable | Browser-matrix check and supported subtree lifecycle | F07 |
| Retain every old view, Undo item, artifact and executor indefinitely | Different retention budgets and pin reasons per owner | Recommendation; prolonged-edit/resource test |
| Make UI status a second control authority | Read-only bounded projection of existing facts | Recommendation; reconnect/out-of-order event test |

There is no automatic “rollback Undo”: user undo changes content; implementation
rollback selects code. An old version can be eligible only if it accepts the
current state and dependency contracts. Keeping an artifact does not prove its
executor, credentials, schema, or external effects are reversible.

## 5. What to qualify next, and what not to build yet

The next browser case should use the actual product renderer and a dirty draft:
type during preparation, retain a logical cursor, exercise IME composition/focus,
then fail the candidate's useful readiness after loading. Check actual listener
removal, late results, and visible candidate/selected/rendered versions.
Node Yjs success proves none of those browser details.

Additional decisive checks are: history memory under prolonged editing and
pruning; destroyed-document retained references cannot bypass the product's
write boundary; incompatible schema/view state refuses automatic reuse; a true
host restart restores exactly the promised subset; federation shares and chunk
identities remain consistent while old work drains. A null relative cursor must
have a documented fallback.

**Recommended first slice:** a TS adapter plus one optional status projection in
the existing product, with framework lifecycle and existing state/resource owners.
Keep the core platform-neutral; Wasm can later implement the execution boundary
without owning DOM, Undo, or the user document. Adopt Yjs only where collaborative
state merits it; adopt federation/single-spa only when their composition units
match. No universal migration engine, snapshot serializer for closures,
prototype patcher, or replacement UI framework is justified by this evidence.

## Evidence map

- Exact pinned sources, official docs, historical issue classification:
  [sources.json](sources.json).
- Findings with applicability and falsification checks:
  [findings.json](findings.json).
- Prior expectations: [probe/PLAN.md](probe/PLAN.md).
- Actual cases: [probe/state-continuity.test.ts](probe/state-continuity.test.ts).
- First execution: [runtime-attempt1.log](probe/evidence/runtime-attempt1.log);
  [typecheck-attempt1.log](probe/evidence/typecheck-attempt1.log).
- Machine observations: [results.json](probe/evidence/results.json).
- Released archive integrity and exact inspected source matching:
  [package-provenance.json](probe/evidence/package-provenance.json).
- Exact dependencies: package.json and pnpm-lock.yaml in probe. Exclude
  node_modules from research commits.

Early-checkpoint correction: F06 initially mentioned pending-activation
settlement without verifying it. The ledger now claims only observed activation
eligibility, veto reasons, and reverse-order host stopping.
