# Native Yjs continuity qualification

This private scratch probe tests released Yjs behavior, not a new coordinator.
Expected observations were written in PLAN.md before execution. Seven cases
passed on the first runtime attempt; strict TypeScript 7.0.2 produced no
diagnostics with dependency checking enabled. Node was 24.22.3, pnpm 11.25.0.

## Reproduce

Use Node in the package engine range and the exact pinned pnpm version:

```sh
pnpm install --frozen-lockfile --ignore-scripts --strict-peer-dependencies
pnpm typecheck
pnpm test
```

The lockfile pins Yjs 13.6.33, TypeScript 7.0.2 and Node types 24.13.3.
No TS suppression, any cast, generated declaration patch or skipLibCheck is
used. Test source runs through Node's native TypeScript support after the
separate strict compile check. No browser or durable network provider runs.

## Evidence

- evidence/runtime-attempt1.log: first execution, seven passing cases.
- evidence/typecheck-attempt1.log: first strict compiler output.
- evidence/results.json: actual observed values, written by the test process.
- evidence/package-provenance.json: released archive SHA-512 matches registry;
  installed runtime/source bytes match archive; UndoManager and Doc Git blob
  identities match the independently inspected pinned source.
- evidence/*-registry.json: exact release and compiler metadata.
- evidence/installed-dependencies.json and version logs: local toolchain.

The archive was inspected in memory, not vendored. node_modules is excluded
from the research packet. The post-destroy case deliberately misuses a retained
reference as a negative control; it establishes no supported access policy.
All other cases use public observer, transaction, history and document codecs.
No production E2E, schema migration, authorization enforcement, memory bound,
resource leak freedom, browser cursor/focus behavior or networking guarantee
is claimed.
