import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import test, { after } from "node:test";
import * as Y from "yjs";

const observations: Array<{ name: string; value: unknown }> = [];
function observe(name: string, value: unknown): void {
  observations.push({ name, value });
  process.stdout.write(`OBSERVATION ${JSON.stringify({ name, value })}\n`);
}

after(async () => {
  await mkdir("evidence", { recursive: true });
  await writeFile("evidence/results.json", JSON.stringify({
    node: process.version,
    package: "yjs@13.6.33",
    sourceRevision: "9ea3a4fb57b814292ce18dfd13c4f422e44e6c5c",
    scope: "Real public Yjs APIs and binary document updates; no browser or durable network execution.",
    observations,
  }, null, 2) + "\n");
});

test("stable draft and history survive exact view subscription replacement", () => {
  const doc = new Y.Doc();
  const draft = doc.getText("draft");
  draft.insert(0, "seed");
  const userOrigin = Symbol("stable-user");
  const history = new Y.UndoManager(draft, {
    trackedOrigins: new Set([userOrigin]), captureTimeout: 0,
  });
  const views: string[] = [];
  const oldView = (): void => { views.push(`v1:${draft.toString()}`); };
  const newView = (): void => { views.push(`v2:${draft.toString()}`); };
  try {
    draft.observe(oldView);
    doc.transact(() => draft.insert(draft.length, "A"), userOrigin);
    draft.unobserve(oldView);
    draft.observe(newView);
    doc.transact(() => draft.insert(draft.length, "B"), userOrigin);
    assert.equal(draft.toString(), "seedAB");
    assert.deepEqual(views, ["v1:seedA", "v2:seedAB"]);
    history.undo();
    assert.equal(draft.toString(), "seedA");
    history.undo();
    assert.equal(draft.toString(), "seed");
    history.redo();
    assert.equal(draft.toString(), "seedA");
    assert.deepEqual(views, ["v1:seedA", "v2:seedAB", "v2:seedA", "v2:seed", "v2:seedA"]);
    observe("stable-owner", { draft: draft.toString(), views, historySurvived: true });
  } finally {
    draft.unobserve(newView);
    history.clear(); history.destroy(); doc.destroy();
  }
});

test("different tracked origins coalesce unless transition explicitly stops capture", () => {
  const outcomes: Array<{ boundary: boolean; entriesBeforeUndo: number; afterUndo: string }> = [];
  for (const boundary of [false, true]) {
    const doc = new Y.Doc();
    const draft = doc.getText("draft");
    const before = Symbol("generation-one");
    const next = Symbol("generation-two");
    const history = new Y.UndoManager(draft, {
      trackedOrigins: new Set([before, next]), captureTimeout: 60_000,
    });
    try {
      doc.transact(() => draft.insert(0, "A"), before);
      if (boundary) history.stopCapturing();
      doc.transact(() => draft.insert(1, "B"), next);
      const entriesBeforeUndo = history.undoStack.length;
      assert.equal(entriesBeforeUndo, boundary ? 2 : 1);
      history.undo();
      assert.equal(draft.toString(), boundary ? "A" : "");
      outcomes.push({ boundary, entriesBeforeUndo, afterUndo: draft.toString() });
    } finally {
      history.clear(); history.destroy(); doc.destroy();
    }
  }
  observe("capture-boundary", outcomes);
});

test("untracked old origin can still write and its change transfers to a peer", () => {
  const doc = new Y.Doc();
  const peer = new Y.Doc();
  const draft = doc.getText("draft");
  const oldOrigin = Symbol("retired-view");
  const userOrigin = Symbol("current-view");
  const history = new Y.UndoManager(draft, {
    trackedOrigins: new Set([oldOrigin, userOrigin]), captureTimeout: 0,
  });
  let oldObserverCalls = 0;
  const oldObserver = (): void => { oldObserverCalls++; };
  try {
    draft.observe(oldObserver);
    draft.unobserve(oldObserver);
    history.removeTrackedOrigin(oldOrigin);
    doc.transact(() => draft.insert(0, "old"), oldOrigin);
    assert.equal(history.canUndo(), false);
    doc.transact(() => draft.insert(draft.length, "+new"), userOrigin);
    assert.equal(draft.toString(), "old+new");
    history.undo();
    assert.equal(draft.toString(), "old");
    assert.equal(oldObserverCalls, 0);
    Y.applyUpdate(peer, Y.encodeStateAsUpdate(doc), "binary-transfer");
    assert.equal(peer.getText("draft").toString(), "old");
    observe("origins-not-authority", {
      untrackedWriteAccepted: true, oldObserverCalls,
      afterCurrentUndo: draft.toString(), peerDraft: peer.getText("draft").toString(),
    });
  } finally {
    history.clear(); history.destroy(); doc.destroy(); peer.destroy();
  }
});

test("history clear preserves current user content", () => {
  const doc = new Y.Doc();
  const draft = doc.getText("draft");
  const history = new Y.UndoManager(draft);
  try {
    draft.insert(0, "user draft");
    assert.equal(history.canUndo(), true);
    history.clear();
    assert.equal(history.canUndo(), false);
    assert.equal(history.canRedo(), false);
    assert.equal(history.undo(), null);
    assert.equal(draft.toString(), "user draft");
    observe("clear-history", { draft: draft.toString(), canUndo: history.canUndo() });
  } finally {
    history.destroy(); doc.destroy();
  }
});

test("document encoding preserves data but does not serialize UndoManager history", () => {
  const oldDoc = new Y.Doc();
  const restoredDoc = new Y.Doc();
  const oldDraft = oldDoc.getText("draft");
  const oldHistory = new Y.UndoManager(oldDraft);
  try {
    oldDraft.insert(0, "saved draft");
    assert.equal(oldHistory.canUndo(), true);
    Y.applyUpdate(restoredDoc, Y.encodeStateAsUpdate(oldDoc), "restore");
    const restoredDraft = restoredDoc.getText("draft");
    const freshHistory = new Y.UndoManager(restoredDraft);
    try {
      assert.equal(restoredDraft.toString(), "saved draft");
      assert.equal(freshHistory.canUndo(), false);
      assert.equal(freshHistory.undo(), null);
      assert.equal(restoredDraft.toString(), "saved draft");
      observe("restore-content", { oldCanUndo: oldHistory.canUndo(), restoredCanUndo: freshHistory.canUndo(), draft: restoredDraft.toString() });
    } finally {
      freshHistory.destroy();
    }
  } finally {
    oldHistory.clear(); oldHistory.destroy(); oldDoc.destroy(); restoredDoc.destroy();
  }
});

test("relative caret survives peer insertion and re-binding while numeric index differs", () => {
  const doc = new Y.Doc();
  const peer = new Y.Doc();
  const draft = doc.getText("draft");
  try {
    draft.insert(0, "ab");
    const originalNumericIndex = 2;
    const relativeBytes = Y.encodeRelativePosition(
      Y.createRelativePositionFromTypeIndex(draft, originalNumericIndex),
    );
    Y.applyUpdate(peer, Y.encodeStateAsUpdate(doc), "initial-sync");
    peer.getText("draft").insert(0, "X");
    Y.applyUpdate(doc, Y.encodeStateAsUpdate(peer), "peer-sync");
    const resolved = Y.createAbsolutePositionFromRelativePosition(
      Y.decodeRelativePosition(relativeBytes), doc,
    );
    assert.ok(resolved);
    assert.equal(draft.toString(), "Xab");
    assert.equal(resolved.type, draft);
    assert.equal(resolved.index, 3);
    assert.notEqual(resolved.index, originalNumericIndex);
    observe("relative-caret", { draft: draft.toString(), originalNumericIndex, restoredIndex: resolved.index });
  } finally {
    doc.destroy(); peer.destroy();
  }
});

test("destroyed document negative control does not provide a retained-reference write fence", () => {
  const doc = new Y.Doc();
  const peer = new Y.Doc();
  const retained = doc.getText("draft");
  try {
    retained.insert(0, "live");
    doc.destroy();
    assert.equal(doc.isDestroyed, true);
    retained.insert(retained.length, "+late");
    assert.equal(retained.toString(), "live+late");
    Y.applyUpdate(peer, Y.encodeStateAsUpdate(doc), "negative-control");
    assert.equal(peer.getText("draft").toString(), "live+late");
    observe("destroy-not-write-fence", {
      destroyed: doc.isDestroyed, retainedDraft: retained.toString(),
      peerDraft: peer.getText("draft").toString(),
      qualification: "misuse counterexample; not a supported post-destroy operating policy",
    });
  } finally {
    if (!doc.isDestroyed) doc.destroy();
    peer.destroy();
  }
});
