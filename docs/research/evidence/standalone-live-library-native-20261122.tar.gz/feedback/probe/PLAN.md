# Yjs state continuity probe

Date 2026-11-22 Europe/Kiev. Exact package Yjs 13.6.33; source
9ea3a4fb57b814292ce18dfd13c4f422e44e6c5c. TypeScript 7.0.2 with strict checking,
including dependency declarations; Node 24.22.3. No new public runtime API.

The independent expected outcomes come from public Yjs docs plus inspected
UndoManager/Doc source before execution. Use real Y.Doc instances, actual CRDT
binary updates and actual public observer/history/relative-position APIs.
No fake transport implementation is required: in-memory binary transfer checks
the public codec/merge boundary, not network persistence or browser rendering.

Seven cases:

1. A stable document and history survive replacing exact view subscriptions;
   the old view stops observing, the new view sees subsequent edits and Undo.
2. Two distinct tracked origins within a deliberately large capture window
   coalesce into one Undo; stopCapturing provides the contrasting boundary.
3. Removing a retired origin from history tracking does not deny a later write
   by that origin. The late change survives Undo of the current user edit and
   is actually transferred to a second document. This is not write authority.
4. Clearing history leaves the current draft intact.
5. Encoding/restoring the document preserves content but does not serialize
   the JavaScript UndoManager history into the new owner automatically.
6. The public relative-position codec preserves a caret's logical location
   after a peer inserts before it; reusing the old numeric index differs.
7. Calling through a retained text reference after Doc.destroy is a negative
   control against treating destruction as a write fence. Source predicts the
   data can still change; no supported post-destroy usage policy is inferred.

Each case owns and destroys its own documents/history. No arbitrary schema
migration, collaborative network convergence, renderer lifecycle, leak-free
claim, UI-ready signal or production old-version authorization follows.
