# Independent review: Yjs state-continuity probe

Reviewer: version/state research lane. Date: 2026-11-22 UTC.

**Verdict: the seven-case native evidence supports the stated bounded Yjs claims. No blocking issue found; no rerun needed.** This is a review of source, pre-execution plan, recorded results, installed package source and provenance, not another execution.

## Evidence inspected

- `feedback/probe/PLAN.md`, `state-continuity.test.ts`, package/TypeScript configuration.
- First typecheck and runtime logs: strict TypeScript 7.0.2 passed; Node 24.22.3 recorded 7 passed, 0 failed, 0 skipped.
- `evidence/results.json`, installed dependencies and released-tarball/source-blob provenance.
- Installed Yjs 13.6.33 `src/utils/UndoManager.js` origin filter, grouping, clear and destroy; `src/utils/Doc.js` transact/destroy.
- Report and source ledger distinguish executed APIs from source-only lifecycle assertions.

## Findings

1. **Origin is history metadata, not authority.** The test removes a tracked origin and observer, then the retained text still accepts a write. Undo removes only the current tracked edit. The old edit reaches a second document through real binary encoding/application. This directly supports the warning against treating history tracking or observer disposal as a mutation gate.
2. **Mutable-reference escape is the critical implementation boundary.** A gate in a command/router layer cannot revoke a previously supplied raw Y.Doc/Y.Text reference. If the product promises rejection of old-version writes, the actual mutable owner must not be bypassable through that reference. Use the existing authority's command/data boundary or a separately qualified execution boundary. This is an architectural consequence; the probe does not implement revocation.
3. **View replacement is precisely bounded.** Exact old callback removal and new callback installation are asserted, including subsequent Undo/Redo. This verifies the Yjs subscription/history behavior; it does not prove renderer teardown, DOM identity, native resources or leak freedom. The report does not claim those.
4. **Undo grouping is supported.** Both tracked origins merge within the explicit capture window; stopCapturing creates the contrasting two-item result. The released handler filters origins before time-based merging and does not compare successive origins during that merge.
5. **Content persistence and history persistence are correctly separated.** The restored document receives the data; a newly created UndoManager does not acquire the previous JavaScript manager's history. The test does not exercise a history persistence plugin, durable storage or a network provider.
6. **Caret evidence is one concrete codec case.** A relative position resolves after a peer prepend while the old absolute index differs. Deleted/unavailable-type fallback remains documentation-based, not executed here.
7. **Post-destroy write is correctly labeled a misuse negative control.** It invalidates the assumption that isDestroyed revokes retained data references in this release. It does not establish supported post-destroy semantics or promise that future releases behave identically.

## Suggested synthesis wording

“Yjs can preserve a compatible document and its Undo manager while views change. Origins select history capture; they do not authorize writes. Revocable plugin code must not retain an unchecked mutable document reference. The tested codec preserves content and relative caret position; process/browser restart, network durability, schema migration and actual write rejection remain separate qualifications.”

No new coordinator, persistence store or lifetime owner is needed to apply these findings.
