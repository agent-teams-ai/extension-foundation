import assert from 'node:assert/strict';
import { AsyncLocalStorage } from 'node:async_hooks';
import { EventEmitter } from 'node:events';
import { mkdtemp, open, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';

type Revision = Readonly<{ revision: string }>;
const a: Revision = Object.freeze({ revision: 'A' });
const b: Revision = Object.freeze({ revision: 'B' });
const c: Revision = Object.freeze({ revision: 'C' });

test('await preserves operation context across a later admission', async () => {
  const context = new AsyncLocalStorage<Revision>();
  const gate = Promise.withResolvers<void>();
  const operation = context.run(a, async () => {
    assert.equal(context.getStore(), a);
    await gate.promise;
    return context.getStore();
  });
  context.run(b, () => {
    assert.equal(context.getStore(), b);
    gate.resolve();
  });
  assert.equal(await operation, a);
  assert.equal(context.getStore(), undefined);
});

test('event emission and bound registration select different contexts', () => {
  const context = new AsyncLocalStorage<Revision>();
  const emitter = new EventEmitter();
  const seen: Array<readonly [string, string | undefined]> = [];
  context.run(a, () => {
    emitter.on('operation', () => seen.push(['plain', context.getStore()?.revision]));
    emitter.on('operation', AsyncLocalStorage.bind(() => {
      seen.push(['bound', context.getStore()?.revision]);
    }));
  });
  context.run(b, () => emitter.emit('operation'));
  context.run(c, () => emitter.emit('operation'));
  assert.deepEqual(seen, [
    ['plain', 'B'], ['bound', 'A'], ['plain', 'C'], ['bound', 'A'],
  ]);
  emitter.removeAllListeners();
});

test('snapshot captures a mutable store reference, not its value', () => {
  const context = new AsyncLocalStorage<{ revision: string }>();
  const mutable = { revision: 'A' };
  const captured = context.run(mutable, () => AsyncLocalStorage.snapshot());
  mutable.revision = 'B';
  assert.equal(captured(() => context.getStore()), mutable);
  assert.equal(captured(() => context.getStore()?.revision), 'B');
});

test('async iterator body and finalizer follow consumption context', async () => {
  const context = new AsyncLocalStorage<Revision>();
  const finalizers: Array<string | undefined> = [];
  async function* values(): AsyncGenerator<string | undefined, void, unknown> {
    try {
      yield context.getStore()?.revision;
      yield context.getStore()?.revision;
    } finally {
      finalizers.push(context.getStore()?.revision);
    }
  }

  const unbound = context.run(a, () => values());
  assert.equal((await context.run(b, () => unbound.next())).value, 'B');
  await context.run(c, () => unbound.return());
  assert.deepEqual(finalizers, ['C']);

  const bound = context.run(a, () => values());
  const captured = context.run(a, () => AsyncLocalStorage.snapshot());
  const result = await context.run(b, async () => {
    const item = await captured(() => bound.next());
    assert.equal(context.getStore(), b);
    return item;
  });
  assert.equal(result.value, 'A');
  await context.run(c, () => captured(() => bound.return()));
  assert.deepEqual(finalizers, ['C', 'A']);
});

test('captured context does not keep a closed native resource usable', async () => {
  const context = new AsyncLocalStorage<Revision>();
  const directory = await mkdtemp(join(tmpdir(), 'plugin-version-context-'));
  const file = await open(join(directory, 'resource.txt'), 'w+');
  try {
    await file.writeFile('owned by revision A');
    const captured = context.run(a, () => AsyncLocalStorage.snapshot());
    await file.close();
    await context.run(b, async () => {
      await assert.rejects(captured(async () => {
        assert.equal(context.getStore(), a);
        return file.readFile('utf8');
      }), { code: 'EBADF' });
      assert.equal(context.getStore(), b);
    });
  } finally {
    await file.close();
    await rm(directory, { recursive: true, force: true });
  }
});
