# Native async-context qualification

Written before execution, 2026-11-22. Scope: Node's released native context APIs, not a plugin lifecycle implementation. Exact runtime expected: Node 24.22.3; TypeScript 7.0.2; @types/node 24.13.3; pnpm 11.25.0.

Independent observable oracles:

1. A Promise suspended under revision A resumes under A while unrelated code runs under B. A deterministic Promise barrier replaces sleeps.
2. An ordinary EventEmitter listener observes emission context; a bound listener observes registration context. Binding a permanent listener can therefore retain an old revision for future independent actions.
3. A snapshot retains the original store object by reference. Mutating the object after capture changes what captured code reads.
4. An async generator created under A but consumed under B executes under B. Binding each next/return operation to A controls body and finally context; creation alone does not.
5. Captured revision context does not keep a real file handle usable. After close, a captured callback still identifies A but readFile rejects with EBADF.

Every test calls native Node APIs. There is no supervisor, reference counter, cleanup manager, replacement policy, or mock runtime. Passing does not prove browser portability, worker/process propagation, resource ownership, cancellation, or safe reload. Upstream Temporal/Golem/Restate tests are source inspection only.

Run: `pnpm install --ignore-scripts`, `pnpm typecheck`, `pnpm test`. Preserve logs, exact lockfile, and SHA-256 manifest. This is a bounded dependency-free runtime probe; TypeScript and declarations are development tools only.
