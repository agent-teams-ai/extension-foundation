# Version routing, retention and durable state evolution

Research completed **2026-11-22 (UTC)**. This packet extends the earlier live-plugin research with released implementation inspection and a bounded native experiment. It proposes contracts for a standalone library; it does not introduce another deployment controller, persistence engine or resource owner.

## Recommendation

Use **explicit operation identity plus the host's existing lifecycle authority**. A TypeScript adapter can reuse native asynchronous context tracking. Durable engines should remain optional integrations: their history, recovery and endpoint rules are substantial infrastructure, not interchangeable execution details.

The strongest additions to the design are:

- Track **new-work routing, active operations, cleanup completion and retained recovery/history dependencies separately**.
- Persist a durable update attempt's selected inputs before its side effects; retries must keep that identity or create an explicit new attempt.
- Distinguish declared compatibility from which compatible version should receive work.
- Report backend guarantees accurately. A CLI preflight is weaker than a server-enforced transition.
- Bound old-version retention without invalidating live references or misreporting unfinished cleanup.

Evidence IDs resolve in `sources.json`; actionable warnings are in `findings.json`.

## Evidence and exact versions

| System | Released identity inspected | What was actually done |
|---|---|---|
| Temporal 1.32.2 | `6d085822273f4336796e6959c73ab1d14a23eb77`; published 2026-11-02 | Official docs, drainage query, delete/reactivation implementation and upstream test names/assertions |
| Golem 1.6.3 | `b277b3ddfbcf02cf52b921e9c41f5816bbd55de7`; published 2026-11-06 | Release-pinned documentation, update queue, snapshot selection, failure table and integration tests |
| Restate 1.8.1 | `20efb1b83a39b8227451e531c366e067588ae9ee`; published 2026-10-21 | Deployment pin persistence/resolution, CLI deletion, server deletion and validation test |
| Orleans 10.4.2 | `876ffe0338e41bc6339e85ee5696dbee6cf9a4c4`; published 2026-10-30 | Official compatibility guidance, version director, selector and upgrade tests |
| Crossbeam Epoch 0.9.21 | `2920c984290229ab4e0ca0452ef09e48a82063f3` | Released guard source; no Rust execution |
| Node 24.22.3 | `e63cab040c09d43ceef8cb35508c40044614e906`; release tag dated 2026-11-11 | Native runtime **5/5 tests passed**, strict TypeScript 7.0.2 check passed |

Temporal, Golem, Restate, Orleans and Crossbeam were **not deployed or executed** here. Their upstream tests are inspected evidence, not our passing tests. The Node probe has pre-execution oracles, lockfile, logs and hashes. No performance conclusion follows from its short runtime.

## 1. Temporal: drainage does not answer every retention question

Temporal separates Current, Ramping and a workflow's Target version. A pinned workflow stays on its selected Worker Deployment Version, while auto-upgrade requires replay-compatible code. The ramp cohort is based on Workflow ID. This supports stable operation assignment; choosing again independently for each callback would provide different semantics. [V01]

Two boundaries matter for a plugin library:

1. **Drained counts open pinned workflows.** Closed histories can still execute old workflow code when queried within retention, if workers for that version remain available.
2. An independent Activity on a task queue outside the pinned deployment follows that queue's routing. Pinning the parent does not automatically freeze all dependencies. [V01]

The released `GetVersionDrainageStatus` query filters deployment identity, pinned behavior and Running status; zero produces Drained. This directly corroborates what the status excludes. [V13]

The deletion code additionally rejects relevant current/ramping or still-draining conditions and active pollers. It orders asynchronous forget propagation against other propagations. Reactivation paths wait for deletion propagation where necessary; comments explicitly identify an unprotected deleted flag. The code includes history-version branches, so this is evidence of a handled race, not a claim that every modern propagation lacks revisions. [V14]

Relevant upstream tests include `TestDeleteVersion_Drained_But_Pollers_Exist`, `TestDeleteVersion_ThenRecreateByPolling` and reactivation tests for overrides, start and reset. None ran locally. [V15]

**Apply:** the library should expose why an old generation remains: operation, resource finalizer, durable invocation, retained query/recovery requirement, or rollback reservation. “No active calls” may permit stopping an executor while still retaining its immutable artifact and codec. The product must decide whether historical execution remains supported; retention policy should make that choice visible.

**Cost:** using Temporal for this purpose entails its service, SDK workflow restrictions, histories and old-worker capacity. For an existing Temporal host, adapt its versioning authority. Do not build a second workflow history or independently move its pinned work.

## 2. Restate: immutable deployment endpoints; deletion guarantees need inspection

Restate keeps an invocation on its chosen deployment across retries. Old endpoints therefore need to survive while their invocations remain unfinished. Virtual Object state persists across deployments, so version pinning still requires compatible state evolution. Its docs recommend shorter execution units when a long invocation would retain old infrastructure for days or months. [V03]

The released invoker resolves a recorded deployment and service protocol; it does not substitute the newest endpoint when that record exists. Otherwise it chooses a current deployment. A partition-state command persists the chosen deployment in invocation metadata. That command also handles a cancellation-after-pinning case. These paths demonstrate persistent identity and a relevant cancellation race, but inspecting them does **not** establish every acknowledgement/crash ordering in the full protocol. [V16, V31]

### Important mismatch between UX and server capability

In 1.8.1, the CLI inspects whether a deployment is drained and refuses unsafe removal unless force is requested. It then sends **force=true regardless**, with a comment that the server does not yet support graceful validation. The server rejects non-forced deletion; `bulk_delete_validation` explicitly asserts that rejection. [V17, V18]

This is not a reproduced production incident. It establishes that **CLI preflight is not an atomic server-side “delete only if safe” primitive**. A concurrent routing/schema change between inspection and deletion remains a qualification scenario.

**Apply:** adapter capabilities must say whether safe deletion is enforced by the backend, checked provisionally, or unsupported. Preserve the host's existing serialization/coordination authority. Do not silently downgrade a generic “retire safely” call into force.

For a Restate deployment already present in the host, its existing Kubernetes operator is a candidate for deployment/registration/drain management; assess it before adding our own controller. Restate source headers identify Business Source License terms; treat integration and copying server code as different adoption decisions. [V03, V16]

## 3. Golem: update admission, selected recovery inputs and outcome are distinct

Golem's automatic and manual updates solve different problems. Automatic updates validate retained execution history; manual updates reach an invocation boundary and migrate through application snapshot functions. A new deployed component revision alone does not update existing agents. A reset/redeploy that discards state is a separate operation. [V21]

The release contains an especially useful recovery design:

- An update first has an **admission identity**.
- When an automatic update reaches the queue head, the engine chooses a snapshot-assisted or full-history strategy.
- The selected record contains source revision/start index, target revision, snapshot identity and filesystem snapshot where applicable.
- The choice is recorded before execution. Recovery uses that choice; it does not silently switch to the latest snapshot.
- Terminal failure and temporary unavailability have different outcomes. [V19, V21, V25, V26]

The queue fold refines an unselected automatic head only when admission index and target revision match. The snapshot selector returns `PersistStrategy` for an unselected head and does not reconsider candidates for an already frozen assisted selection. Stale source identity instead fails the head. This is a concrete defense against a retry changing what “this update” means. [V19, V25]

### Source-inspected negative examples

| Upstream case | Observable assertion or distinction | Status |
|---|---|---|
| Selected snapshot rejected | One failed update; healthy source revision preserved; no hidden fallback within that attempt | Inspected integration test |
| Payload unavailable once | Retry eventually succeeds with snapshot-assisted provenance | Inspected integration test |
| Payload missing | One failure with unavailable-snapshot reason; source revision retained | Inspected integration test |
| Two automatic targets queued | Two distinct admission identities; strategy chosen as each reaches the head; first assisted, second not necessarily assisted | Inspected integration test |
| Interrupted manual load | Pending work can load again on next start rather than inventing success/failure | Pinned docs and failure-table inspection |

Tests are in `hot_update.rs`. The name “retries the same record” is stronger than the downloaded-payload test's exposed assertions alone; the frozen-selection implementation supplies the corresponding identity evidence. [V20, V25, V26]

A later **new** request may legitimately choose a different strategy after prior incompatibility. That does not contradict “no fallback inside the same attempt.” This distinction should appear in operation history and user-visible retry controls.

**Apply only where durability is promised:** ask the existing state authority to store the update identity and baseline receipt. A process-local TS host without durable recovery should say so; it does not need a custom oplog to imitate Golem.

**Limits:** replay/snapshot migration does not reverse arbitrary external writes. Restoring an earlier heap or artifact after a newer version wrote shared data requires a compatible reader, a separately validated migration, or compensation. A stopped callback can still have a network request in flight. Such outcomes require the owning service's idempotency/fencing/transaction mechanisms, not a claimed universal reload rollback.

**Cost:** Golem brings a Wasm durable execution platform and host-mediated replay semantics. It is a useful optional backend or source of requirements, not a small universal TS hot-reload library. Its inspected source headers identify Golem Source License v1.1; do not assume permissive-code reuse. [V19, V25]

## 4. Orleans: compatibility and version preference should remain independent

Orleans separates a compatibility director from a version selector. In the inspected backward-compatible director, compatibility is the numeric relation `requestedVersion <= currentVersion`. The minimum selector then chooses the lowest accepted available version. This is executable policy over declarations, not semantic verification of code or persisted data. [V22, V23]

Upgrade tests separately cover minimum, latest, all-compatible and compatible-version distribution. Their assertions show that deploying V2 need not move every activation to V2; incompatible calls and selection policy affect activation behavior. We inspected these tests without starting Orleans. [V28]

The official deployment guidance includes mixed-version staging/rolling strategies and limitations for stateless workers/streaming agents. Its backward-compatibility guidance favors incremental contract evolution. [V07, V08, V32]

**Apply:** keep at least three decisions explicit: which contract/schema pairs are accepted, which accepted revision new operations prefer, and how an existing session remains pinned or migrates. A numeric version or semver range alone cannot prove migration safety.

For shared state, qualify both directions: can V2 read old state, and can a still-running V1 read state written by V2? Additive rollout plus delayed removal often permits both, but field semantics and invariants still need application-specific evidence. A UI “rollback code” action should be unavailable or qualified when the old reader cannot interpret current durable state.

**Cost:** Orleans is attractive inside an existing .NET actor application. Embedding or reproducing its membership/placement/activation system merely to support TS plugins would expand this library's scope substantially.

## 5. RCU and Crossbeam: no readers is not cleanup completed

RCU separates removing a published reference from reclaiming its resource after pre-existing readers finish. New readers must no longer acquire the removed reference. This is a useful lifecycle ordering model. It does not imply porting kernel memory-order machinery into JavaScript. [V10]

A more specific lesson comes from unloadable modules: waiting for a reader grace period does **not** wait for already queued RCU callbacks. Module unload first stops producers, then waits for the appropriate callback barrier. Timers or callbacks that re-enqueue work must be stopped before that final barrier. [V29]

Crossbeam Epoch's released guard documentation also provides no fixed time by which a deferred destructor runs; in theory it may never run. It is a memory-reclamation primitive, not a bounded asynchronous shutdown service. [V27]

**Apply:** the existing lifecycle owner should provide separate observable completion for active operations and finalization. A deadline may justify cancel/restart policy, but it cannot convert unresolved finalization into a successful receipt. Repeated updates need limits on retained generations, memory and pending cleanup. When the budget is exceeded, queue/refuse/coalesce another update according to explicit policy; do not destroy still-used state. [V11; design inference]

Long-lived connections should define an update boundary: per request/message, explicit session checkpoint, or whole-session retention. The system cannot both pin forever and guarantee bounded retention without an escape policy.

## 6. Executed native probe: useful TypeScript building block

The experiment uses released Node APIs directly. It has no lifecycle manager, fake runtime or reference-count implementation. `PLAN.md` was saved before execution. Exact tooling: Node 24.22.3, pnpm 11.25.0, TypeScript 7.0.2 and @types/node 24.13.3. Strict checking includes `skipLibCheck: false`. [V24, V30]

| Case | Actual observation |
|---|---|
| Suspended Promise under A; later B context | Await resumes under A |
| EventEmitter listener registered under A | Ordinary listener follows B/C emission context; bound listener keeps A |
| Snapshot of mutable store | Reads the same object after its revision changes from A to B |
| Generator created under A, consumed under B/C | Body/finalizer follow consumption; binding next/return makes them run under A |
| Captured A callback after native file close | Context remains A; real read fails with EBADF |

**Result: 5 passed, 0 failed, 0 skipped; strict typecheck exit 0.** Logs and `results.json` record the scope; the SHA-256 manifest allows integrity verification.

Consequences for the TS adapter:

- Reuse `AsyncLocalStorage`/`snapshot` where Node is the host. Immutable revision tokens are an enforced caller contract; snapshot does not freeze or clone them.
- Capture context at the lifetime of an operation. Permanently binding an event subscription can accidentally pin all future independent actions to the installation revision.
- Delayed iterable consumption needs correct handling of `next`, `return` and, where exposed, `throw`. The probe exercises next/return; throw remains unqualified.
- Ambient context **does not acquire, release or revoke resource ownership**. The host must retain that authority. A Promise returning a stream/iterator can settle before consumption finishes; its settlement does not close the operation. Iterator lifetime and detached work remain the existing owner's responsibility. The probe has no admission gate; its A/B contexts represent already chosen identities.
- Cross-process, worker and browser propagation were not exercised. Keep explicit operation identity available at those boundaries rather than assuming ALS transfers.

## 7. Implementable contract boundaries

These are proposed responsibilities to map onto existing host services, not additional mandatory components.

| Concern | Minimum information to expose | Authority |
|---|---|---|
| Routing | Desired revision, published routing revision, operation/session pin | Existing host router or backend versioning service |
| Compatibility | Contract version, durable schema range, supported migration direction | Plugin declarations plus real qualification |
| Durable attempt | Attempt ID, source/target identity, chosen baseline, terminal result | Existing durable state/update backend |
| Retention | Referenced artifact/codec/history plus reason, count/size and deadline policy | Existing artifact/state stores and lifecycle owner |
| Cleanup | Operations settled; finalizers settled; unresolved resources and escalation | Existing lifetime/supervision owner |
| Remote effects | Stable idempotency key or fence receipt where the receiver supports it | Effect-owning service |
| UI | New actions' revision, this session's revision, migration/reset status, blockers | Read model of those receipts; never another writer |

The useful UI distinction is concrete: **“new actions use B; this stream still uses A; A is retained for one stream and one cleanup”**. When state must reset, identify which state is lost and which remains durable. Keep update history keyed by attempt, so a repeated click or a lost acknowledgement resolves to an existing outcome instead of starting an invisible second migration.

## 8. Prioritized qualification plan

Only the Node probe is executed. The remaining cases are explicit future gates against real chosen adapters.

| Priority | Failure injection | Independent oracle |
|---|---|---|
| P0 | Close last live operation while retained-history query still exists | History query remains supported by retained code or is explicitly rejected by the selected retention policy; no false “fully removable” status |
| P0 | Operation finishes but a finalizer is held | New work reaches B; A's cleanup receipt stays incomplete until the real resource settles |
| P0 | V1 remains active while V2 changes shared state; then code rollback | Actual V1 read/write invariants remain valid, or admission/rollback is rejected before incompatibility |
| P0 | Kill after durable baseline selection; create newer snapshot; restart | Same attempt uses recorded baseline or reports a new attempt; no silent re-selection |
| P0 | Lose update acknowledgement and retry | Existing authority returns the same terminal outcome; external effect sink records no duplicate accepted effect for its idempotency key |
| P0 | Held network effect completes after version replacement/cancel | Receiver enforces the declared fence/idempotency policy, or result is explicitly reported uncertain; local abort alone is insufficient |
| P1 | Retire, republish same identity, delay older propagation | Final routing matches authority revision; stale forget cannot erase republished state |
| P1 | Hold a real stream while many updates arrive | Budget bounds retention/admission; the held stream remains usable until its declared finish/cancel boundary |
| P1 | Delayed generator return/throw and callback re-enqueue | Correct operation identity and exactly observed cleanup; no producer remains able to append hidden old work |
| P1 | Direct backend delete versus CLI preflight | Capability disclosure matches server enforcement; provisional inspection never masquerades as atomic safe retirement |

Start with one Node adapter and its real resource/state boundary, then one optional durable backend. Add broader runtime ports only after their cancellation, serialization, effect and retention differences are explicit. This keeps the portable library's policy small while reusing mature execution and storage mechanisms.
