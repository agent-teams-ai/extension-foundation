# Plugin loading and execution boundaries — proposed experiments

Date: 2026-10-26 UTC. Status: **plan only; implementation and execution await root's cross-review/go**.
Owner: `plugin_boundary_research`. Writable scope after approval:
`experiments/plugin-boundaries/` and `reports/plugin-boundaries.md`.

## Decision and scope

The accepted baseline is static composition with controlled restart. The immediate
question is how little loading/custody machinery is needed to make that baseline
honest for independently supplied trusted plugins. This plan selects three small
experiments that can distinguish promises which the earlier evidence could not:

1. Does selection and rejection happen before **module evaluation**, as well as
   before author factory calls?
2. Do artifact receipts describe the bytes Node actually evaluates, including a
   helper imported by the selected entry, and what does a fresh process change?
3. Which initialization failures can an observer contain using ordinary Node
   mechanisms, and which facts require actual thread/process exit evidence?

No universal Host, SPI, mutable registry, scheduler, new supervisor, production
package or security sandbox will be implemented. No downloaded third-party
plugin executes. All active fixtures are benign, owned TypeScript modules with
bounded file markers, deliberate throws, a never-settling promise, or an
allocation-free loop running only inside an owned child/Worker. Ordinary module
composition remains in-process where its accepted trust/availability profile fits.

The plan does **not** propose an independent delayed-cleanup registration test.
The sampled current product has immutable sandbox-manifest registration, not a
replaceable callback registry, and the historical GM resource fixture already
covers late acquisition/cleanup ownership. Inventing a registry here would test
our invention. Reopen only if cross-review identifies an existing relevant
registration boundary and a decision its result changes.

## Authority and existing evidence read

- Full current `context.md`, historical `20261025/context.md`, frozen archive
  `README.md`, static restart report/source, EF `AGENTS.md`, EF docs-authoring
  route, central retained Engineering Quality Standard, relevant EF ADR-0011,
  ADR-0014, OD-003, research hub, OpenClaw audit, platform and Node reload records.
- EF source identity from shared brief:
  `84f43b9db68781474257f8dc0277b4d73de49ebf`; GM current source:
  `b1866ac5328231b7fe1d63ed136e7a905a2facc1`. These are restored read-only inputs,
  not a claim that this agent independently refreshed remote heads.
- GM current AGENTS and Consumer Module Standard preserve product-owned literal
  imports, grants, readiness, cleanup and recovery. Whole selected graph and
  loader correspondence must reject before candidate import. GM never owns
  executable discovery. Current standard complete-file SHA256:
  `3c5814ebf1ab1bd17688e49955aa0baa2ee91dd3a369adcea4d38aaccd53ba86`.
- Earlier S02 proves zero factory calls for missing/ambiguous/duplicate graph
  entries. `tests/static-selection.test.ts` imports both provider modules before
  the test body; `tests/selection.ts` also statically imports A and B. Therefore
  this is deliberately not evidence of zero top-level module evaluation.
  Frozen source SHA256s respectively:
  `ba95e1e6436b73b4be2f53004541547c8fffd81c742118abf6d37bb25e98597f` and
  `af9754833d1577fe44002854b04acf10cd1f04bb19e8c40f58437062afbe327f`.
- Prior 12 fresh-process A/B cycles bind the selected provider emitted file hash
  and plan digest. They did not mutate a transitive helper between integrity
  checking and loading. Existing pool research already disproves equivalence of
  generic close fulfillment, accepted-task completion and physical retirement.
  Repeating those pool packages would not resolve a new choice.
- OpenClaw audit is a pinned source review at
  `33ccaae2f522c3ae299aaf8b195fa166ab536bd8`, not a run of that product. It records
  a strong inert manifest path and an explicit runtime-export compatibility path
  where a disabled plugin's import-time listener survives registry disposal.
  It also records expected-digest module binding, source custody, ESM retention,
  and separate observer versus cleanup promises. Audit complete-file SHA256:
  `b9968036e73b9f51e42db95ca6e4ad3696d520bce9151035ee7f2ceca75f3b10`.
- Root retained central standard SHA256:
  `aa712863fda2f7b830250f17ae005fb17e6379e62dd59b1ac685b9410defa52a`.

The standalone plan is outside governed EF docs. Root owns any subsequent EF
integration and its docs-protocol commands; this agent does not bypass or mutate
that protocol.

## Current primary-source research

Retrieved online 2026-10-26. Moving documentation is marked as such. No external
application or plugin was installed or executed during this research.

| Source | Directly documented fact | Consequence/inference for this plan |
| --- | --- | --- |
| [Node ESM, v26.12.1 rendered current docs](https://nodejs.org/api/esm.html#file-urls) | Distinct query/fragment URLs can load a module multiple times; ESM has its own cache. | Changing only the entry URL need not version its helper URLs. Test actual helper behavior; do not infer unload from re-import. |
| [Node Worker docs, v26.12.1 rendered current docs](https://nodejs.org/api/worker_threads.html#workerterminate) | `terminate()` stops Worker JS as soon as possible and fulfills at `exit`; Worker `process.exit()` affects its thread. | Separate timeout observation, request to terminate, `exit`, and OS thread absence. |
| [Worker resource limits](https://nodejs.org/api/worker_threads.html#new-workerfilename-options) | Limits concern its JS engine, exclude external data such as ArrayBuffers, and do not prevent global OOM abort. | No total-memory or process-crash containment claim from a Worker test; no OOM injection needed. |
| [Node process permissions, v26.12.1 rendered current docs](https://nodejs.org/api/permissions.html) | Permission Model is intended for trusted code and explicitly does not protect against malicious code. | Permission request denial and execution placement are separate from a hostile-code boundary. No sandbox claim can pass this plan. |
| [Node child processes](https://nodejs.org/api/child_process.html#subprocesskilled) | `killed` indicates successful signal sending, not completed termination; Linux parent kill need not kill descendants. | Observe owned PID disappearance and list explicit descendants; signal success alone fails the oracle. |
| [VS Code extension manifest](https://code.visualstudio.com/api/references/extension-manifest) | Manifest declares compatibility and separate Node/browser entries. | Compatibility/placement can be learned before entry evaluation; a common API does not erase target differences. |
| [VS Code extension host](https://code.visualstudio.com/api/advanced-topics/extension-host), page dated 2026-10-21 | Local/remote Node and browser Worker hosts have distinct runtimes; extensions load lazily. | Model selected loading and failure domains explicitly without adopting VS Code's host. |
| [VS Code runtime security](https://code.visualstudio.com/docs/configure/extensions/extension-runtime-security) | Extension host has VS Code's permissions, including files, network and child processes. | UI stability separation does not mean OS security isolation. |
| [Vault plugin architecture, rendered v2.x current](https://developer.hashicorp.com/vault/docs/plugins/plugin-architecture) | Catalog checksum verification occurs before process execution; registration does not itself start a process. | Mature precedent separates inert catalog facts, bytes verification and execution. This does not certify Node package closure or TOCTOU safety. |

Versioned Node v26.11.1 download documentation and raw GitHub tag URLs were
attempted but inaccessible through the search tool. The accessible current docs
rendered **v26.12.1**. They are source grounding, not a substitute for recording
the actual executed Node version. System Node observed is **v24.22.1**. Root is
arranging the shared Node26/TS7 profile; use it if supplied, otherwise request a
scoped execution-version decision rather than relabel the runtime. No dependency
freshness or production pin changes are proposed.

## PB-01 — reject before evaluating selected executable code

**Uncertain question.** Can the smallest target-local loading seam uphold the
accepted zero-evaluation promise for unselected candidates, incompatible graph
metadata and known mismatched executable bytes? Where exactly does the prior
zero-factory evidence stop?

**Decision changed.** Retain separate inert metadata and executable files with a
closed literal loader table. If a required gate needs information exported only
by executable code, classify that compatibility path as a weaker trusted profile
or reject it. Do not claim that GM's construction gate supplies artifact admission.

**Real boundary.** Fixed-name JSON declarations are read as bytes; public released
`@get-modular/core` compiles the chosen declaration graph; the target root owns
two or three explicit `() => import('./fixtures/a.js')` literal entries. Reuse
the historical public-consumer declaration shape and negative graph input; root
supplies exact public package identities/locked dependency access. No deep GM
imports or recreated compiler. The child entry's complete pre-admission runtime
import closure excludes executable A/B modules and barrels re-exporting them;
review the handful of imports rather than adding a graph scanner. Public Core
receives parsed inert JSON or declaration-only inputs, and its actual public
diagnostic is retained. If the released package cannot express the chosen inert
input, report unavailable rather than substituting a compiler or using an
incompatible cast. Imports remain deferred until selection, graph
compatibility, exact loader correspondence and this fixture's byte receipt pass.

**Test-owned components.** Tiny JSON metadata reader, fixed compatibility/profile
inputs, literal loader table, SHA256 comparison and admission sequencing. They
are a disposable proposed product seam, not an existing qualified admission
implementation. Marker modules and their intentionally bad variants are owned
fixtures. A passing row establishes feasibility and observed ordering only.

**Smallest scenarios.** Fresh owned child for each row:

| Row | Input/action | Independent expected observation |
| --- | --- | --- |
| P1 positive | Select compatible A with matching receipt, leave B installed/unselected | A evaluation marker exists once; A callable returns hard-coded `A`; B marker absent. |
| P2 metadata only | Read and compile declarations, invoke no loader | All entry markers absent; public compiler returns plan or specified diagnostic. |
| P3 graph mismatch | Selected provider revision conflicts with consumer declaration | Public Core reports `binding.compatibility-mismatch`; A marker absent. |
| P4 byte mismatch | Change selected emitted entry after receipt creation, before admission | Mismatch rejection and selected entry marker absent. |
| P5 loader mismatch | Selected executable ID missing from the selected loader mapping | Fail before entry evaluation; no scan/import fallback. Full installed table may contain unselected B; equality concerns the selected implementation set and selected loader mapping. |
| P6 negative control | Deliberately import the same marker/throw fixture before checking its exported metadata | Marker exists although later policy rejects; zero factory calls cannot conceal it. |

**Oracle.** The outer parent creates a unique empty marker directory and reads
its file contents after the child's exit. Files contain fixed literal values
known independently of the adapter. Each fixture writes its first marker
synchronously so absence cannot mean unflushed asynchronous I/O. Every rejection
row must reach its intended gate, return its specified diagnostic and exit
normally. A timeout-killed child with absent markers cannot pass. The positive
direct import resolves the same marker-writing file at the same path/writable
marker directory. Successful actual invocation must match
`A`, not a value copied from metadata. Child diagnostics and counters corroborate;
they do not replace external file observation. Include a direct selected import
positive to prove that an absent marker was not caused by a broken path or unwritable
directory. No timers need be inferred from absence.

**Falsifiers.** Any rejected/unselected entry marker; successful imported wrong
entry; inability to express the compiler incompatibility without executable
metadata; valid A fails actual invocation. The intentionally bad control must
produce its marker, otherwise the experiment is invalid rather than green.

**Caps, cleanup and stop.** At most six fresh children, sequential; eight seconds
wall clock per child and 60 seconds total; stdout/stderr 128 KiB each, markers
under 16 KiB total. Outer parent kills only its exact child on deadline, records
exit and `/proc` PID/start-time evidence, then removes only its unique temporary
directory. Stop after one complete run plus one independently requested repeat;
do not expand into a manifest schema or conformance framework.

## PB-02 — entry identity, helper bytes and controlled-restart recovery

**Uncertain question.** Which incorrect byte claims survive an entry-only hash or
entry-only ESM cache-busting scheme? Does fresh-process import observe the expected
closed artifact when the old process retains helper/module state?

**Decision changed.** For the accepted baseline, bind an immutable complete build
artifact/receipt and execute it in a fresh process after controlled restart.
Immutable custody is an explicit precondition, not something a complete hash or
fresh process enforces against a concurrent writer. Fresh process execution
replaces ESM cache/code lifetime; it does not authenticate receipts or close
Node's later path-based open race.
If runtime package installs are subsequently admitted, qualify closure ownership
and the verify/load race with the existing artifact/custody owner; do not invent
a runtime loader or imply one entry hash is sufficient.

**Real boundary.** Node ESM import and filesystem loading of an owned entry that
imports one helper and returns a distinctive literal. Read the entry and helper
bytes independently with Node crypto or `sha256sum`. Ordinary module URLs and
one explicitly bad query-string entry variant are the mechanisms under test.
No framework, loader hooks, symlinks, native addons or untrusted payloads.

**Test-owned pieces.** Two owned artifact directories A/B, two literal loaders,
fixed expected `old-entry/old-helper` and `new-entry/new-helper` outputs, parent
barriers that permit an intentional filesystem edit, and the illustrative
entry-only verification check. An optional two-file manifest checker may be
under 30 lines, but its positive result cannot qualify real artifact admission.

**Smallest scenarios.**

1. **Negative control: helper mutation.** Hash the selected entry; replace only
   helper bytes before the first fresh-process import. The entry hash remains
   equal, while actual invocation reads the changed helper and its marker.
   Independent full two-file hashes differ. This falsifies entry-only identity.
2. **ESM graph control.** Import old entry/helper. Edit only helper, then re-import
   entry with a distinct query URL in that same owned child. Record actual
   callable output and helper evaluation markers. Then start a fresh owned child
   at the unchanged entry path and invoke. Expected same-process old helper versus
   fresh-process changed helper is a hypothesis to observe, not asserted success.
3. **Verify/load gap.** Verify the complete known entry+helper two-file receipt,
   then ACK that exact full receipt. Parent atomically replaces the entry file at
   the same task-owned path and releases the child's unchanged literal import.
   Observe replacement marker/output despite the earlier matching full receipt;
   retain both files' before/after hashes. Closure hashing detects earlier helper
   changes but does not close a later path-based load gap. No timing sleep is
   used; this is an explicit barrier
   reproducing the gap, not a claim about race frequency.
4. **Coherent positive.** Use distinct prebuilt A/B directories, each entry and
   helper retained unchanged; import them in separate fresh children. Check
   independent expected two-file digests, literal output and exact parent PID
   absence afterward. This proves the small static-restart mechanism, not that
   writable files are immutable against a hostile writer.

**Oracle.** Outer-parent byte hashes before/after controlled mutation; fixed
literal invocation outputs; helper and entry marker files; exact command,
process incarnation and exit evidence. Metadata does not supply expected output.
An entry-only gate's acceptance is evidence of its insufficiency, not a pass of
artifact security. The positive uses separate artifact directories so its
dependency URLs actually differ.

**Falsifiers.** Same-process query import observes an unexpected helper, or the
fresh process does not reflect actual helper bytes; no marker in a supposedly
evaluated file; the barrier mutates the wrong file; coherent A/B yields mixed
output. Retain a surprising cache result and inspect exact URLs before changing
the hypothesis. Do not add hand-written cache eviction to make it green.

**Caps, cleanup and stop.** Four groups, at most eight sequential owned children,
eight seconds each/90 seconds total; two tiny helpers; disk payload and logs
under 2 MiB. No churn benchmark. All paths below task-owned short temporary root;
same outer watchdog and exact PID cleanup as PB-01. Stop when these counterexamples
and coherent positive are observed; package-signature verification, archive
extraction, OCI transport and hostile filesystem races remain explicitly untested.

## PB-03 — initialization deadlines versus physical containment

**Uncertain question.** For a selected trusted plugin whose initialization hangs,
which placement preserves the observation owner's responsiveness and allows
bounded physical retirement? What arbitrary side effects survive a rejected
initialization even after its execution owner exits?

**Decision changed.** Keep in-process initialization only where host-blocking
risk is acceptable. Use a Worker for independently interruptible pure-JS startup
when shared process fate and OS authority fit; use the existing process custody
owner when a process boundary is required. The result cannot select a new
supervisor or hostile-code isolation implementation.

**Real boundary.** Real Node event loops, `Worker`, and direct `spawn(process.execPath,
args)` without a shell. Every trial has an independent outer test parent. The
in-process trial's "host" is itself a disposable child, so a loop never blocks
the orchestrating agent or shared long-lived process. Parent sends explicit
nonce-bearing pings, not inferred heartbeats. A tiny file marker is the only
external effect.

**Fixtures and scenarios.**

| Trial | Behavior | Decisive observation |
| --- | --- | --- |
| C1 cooperative positive | Initialization resolves and responds to a callable probe | Ping works, expected response arrives, graceful close and actual owned PID/TID absence observed. |
| C2 asynchronous non-settlement | Top-level marker, then readiness returns a promise held forever | Same-loop timer/ping observation can run while readiness remains unsettled. Harness IPC explicitly retains host liveness; no plugin native-resource leak is inferred from a pending Promise. Parent ends exact owner afterward. |
| C3 synchronous in-process loop | Marker then allocation-free loop during import or initializer | Independent outer ping deadline expires; inner timeout cannot report; outer parent kills exact host and verifies exit/PID absence. |
| C4 Worker loop | Same loop in a Worker, host receives pings | Host remains responsive; explicit terminate is followed by `exit` and disappearance of exact OS TID; marker remains. |
| C5 process loop | Same loop in a child plugin process, host receives pings | Host responsive; signal-send is recorded separately from `exit`/PID absence; marker remains. |
| C6 partial import failure | Marker write followed by throw before factory/readiness | Import rejects, but marker persists; zero readiness/factory progress is not zero external effect. |

Use the same fixture operation for C3/C4/C5. Choose either import-time or
initializer loop as the first decisive trial; repeat the second location only
if it changes the proposed contract. Do not multiply every row by every placement.

**Independent oracle.** Require a successful nonce ping before starting the
plugin action and a different nonce sent after its explicit start/loop marker.
Only the latter proves responsiveness during the fault. The independent parent
owns the blocked-host deadline; a buffered earlier response cannot pass.
The 500 ms cap is an observation bound, not an SLO. Parent checks monotonic
timestamps and directly inspects `/proc/<pid>/stat` start time and PID absence.
Worker performs a synchronous syscall from its own JavaScript thread to record
Linux OS TID from `/proc/thread-self` before looping; never use async libuv I/O
or the host's thread-self. Outer observer directly proves that task identity
live before termination and then checks the same task's later absence
under `/proc/<host-pid>/task/<tid>`. Node `worker.threadId` is recorded separately
because it is not an OS TID. Parse stat's parenthesized comm field without a
space-free-token assumption. Missing post-termination path is meaningful only
after the same task was independently observed live. `terminate()` fulfillment/`exit` are corroborating
runtime observations. If this container cannot independently observe task
identity, mark physical Worker absence **unqualified**, retaining `exit` only.
No `finally` marker is required from forced termination, and absence of that
marker is not treated as proof of cleanup.

**Falsifiers.** Host sibling ping fails in Worker/process placement; exact worker
task or child survives the termination bound; the outer oracle cannot identify
the owned incarnation; cooperative positive fails; partial import failure lacks
the known pre-throw marker. A marker remaining after process/thread termination
is an expected counterexample to external-effect rollback, not cleanup failure.

**Caps and custody.** One trial at a time; at most outer parent + host child +
one Worker/plugin child. Readiness/ping observation window 500 ms after explicit
start marker, five-second absolute trial deadline, two-second termination
deadline, 60 seconds group wall cap. One allocation-free loop at most; no memory
exhaustion, native crash, network or arbitrary descendant spawning. Worker
resource limit 32 MiB old generation is a convenience cap only, not an RSS claim;
host child V8 heap cap 64 MiB. At most 128 KiB output per trial. Watchdog escalation
targets only stored PID/start-time identity, rechecking the still-live incarnation
before signaling a numeric PID. Owned child enumeration means this harness's
explicit direct handles; complete descendant inventory remains unqualified.
Observe exit and, where stdio closure is claimed, close separately. Never `pkill`
or pattern-kill.

**Cleanup and stop.** Preserve evidence first, terminate outstanding exact owned
execution owners, then delete task marker directories. Expected loop-owner
termination is part of the selected mechanism; deadline failure and emergency
watchdog rescue are separate failed outcomes. Register all direct handles and
identities before releasing a hanging action, and start no next loop or remove
marker directory while custody is unresolved. A trial that exceeds its
cap fails and stops the group until its cleanup debt is resolved. No promise or
signal receipt alone releases capacity. Stop after selected containment rows;
global OOM/native faults, process-tree containment, cross-OS behavior, security
sandboxing and arbitrary external effects remain outside the evidence.

## Comparison before execution

Engineering judgments for the same narrow trusted-plugin scope, not availability
measurements. Confidence reflects existing sources/evidence; reliability is the
achievable stated promise; complexity is maintenance burden (higher is harder).
LOC estimates are incremental, approximately ×2 uncertain; operational packaging
and OS qualification are additional, non-LOC costs. All new code in this campaign
is **test/fixture**, with zero production implementation authorized.

| Choice | Confidence /10 | Reliability /10 | Complexity /10 | Future new production LOC | Future product integration LOC | This experiment's test/fixture LOC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Inert metadata + whole-graph compile + literal selected import under static build custody | 9 | 9 for zero evaluation of excluded entries under the declared profile | 2 | 0–50 | 60–140 | 150–240 PB-01 |
| Entry-only hash and timestamped root import as complete artifact identity/reload | 9 that it is insufficient | 2 for full-code coherence | 2 | 0–20 | 20–60 | 100–170 PB-02 counterexamples |
| Complete immutable build artifact + fresh process controlled restart | 9 | 9 for a closed trusted artifact and process-owned code lifetime | 3 | 0–50 | 80–180 | 50–100 additional PB-02 |
| In-process trusted startup with observer timeout | 10 | 3 for a bounded host-blocking/physical-stop promise | 1 | 0 | 15–40 | C2/C3 share PB-03 fixture |
| Worker startup with independent observation and explicit retirement | 9 | 8 for pure-JS loop interruption; no whole-process/security claim | 4 | 0 if existing adapter fits | 60–140 | 180–300 PB-03 total |
| Existing process custody adapter for startup and fresh-code lifetime | 8 | 9 for the owned process under the tested Linux profile; no OS-permission claim | 5 | 0 if existing custody fits | 100–220 | Shared PB-03 fixture |

No native rewrite is warranted by this plan: Node's existing boundaries directly
answer the selected questions. A native/OS-enforced execution profile would need
a concrete denied capability/resource promise and separate deployment evidence.

## Resource coordination and retained deliverables

Observed disk on 2026-10-26: shared overlay has only **35 MiB** free; `/tmp` and
workspace share it. Root was notified. Do not install independently, copy bulk
repos, download a browser/native runtime, or delete another track's files. Use
one root-managed toolchain and package access. Expected new source/retained data
under 3 MiB, transient emitted output under 3 MiB. Reuse historical fixture inputs
by copying only named small files and never editing frozen evidence.

Before a go-run, record exact Node, TS7 compiler, dependency/payload hashes,
OS/kernel, compiler flags and command. All new maintained runtime/test code is
ordinary strict `.ts`; emitted `.js` is generated output. No `.mjs`/`.mts` shortcut,
no `skipLibCheck` relaxation and no new test framework dependency. Record any
unavailable real public GM package row as unavailable, never substitute a mock
compiler.

Retain under `experiments/plugin-boundaries/`: brief reproduction instructions;
exact source and lock/profile references; source/digest manifest; raw bounded
stdout/stderr; per-row JSON observations; process/task identities before and
after cleanup; failed attempts and corrections; toolchain identity. The report
separates inspected source, proposed tests, executed observations and production
claims. It will include critic comments with disposition and remaining gaps.

## Pre-execution review disposition

`plans/critique-plugin-boundaries-by-restart.md` approved the three questions
subject to R1–R6. All six are accepted and incorporated above: actual public Core
diagnostics from inert-only import closure; normally completed rejection rows
and synchronous same-path marker control; selected-loader correspondence;
complete two-file verify/load race; Worker-local synchronous TID plus independent
live-before observation; pre/post-action nonce probes; pending-Promise claim
narrowing; and exact direct-handle custody with expected termination versus
watchdog failure separated. These changes add no experiment group or runtime
framework. Estimated incremental fixture cost20–60 LOC fits the existing ranges.
No implementation/execution has occurred.

Root granted execution after review. State peer critique
`plans/critique-restart-and-boundaries-by-state.md` M3–M6 is also accepted:
complete two-file receipt and parent verification before mutation; frozen parent
receipt/expected literals; normal gate completion; narrowed pending-Promise claim;
and surviving outer observer retains every explicit nested plugin PID/start-time
before go, so inner-host loss cannot discard cleanup authority. P1 doubles as
the selected marker positive; PB03 partial-import failure reuses PB01's actual
marker/throw control rather than spawning another duplicate child. Root authorized
the UID0 bounded6MiB task footprint despite0 unprivileged available blocks; this
does not alter PostgreSQL's separate disk prerequisite. Shared dependencies are
read-only through the experiment-owned symlink. No installs or dependency edits.

**Global stop rule:** cross-review can remove a group whose result cannot change
a named choice. Once each approved group's uncertainty is resolved or a real
component/resource limit makes it unexecutable, retain that outcome and stop.
No optional stress/churn expansion or framework implementation follows by
implication.
