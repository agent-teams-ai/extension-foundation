Plugin boundary and failure campaign: reviewed planning snapshot, 2026-10-26.
These are non-normative questions, source research, proposed scenarios and independent plan criticism. They are not execution results or production qualification. Later result archives bind actually executed sources and outcomes.
Start context.md, then the three track plans and their cross-critiques. Root approved minimal restart/loading experiments after mandatory refinements. Native state execution retains its resource guard; the initial toy state-conversion proposal is being reconsidered against the accepted real Drizzle migrator, before implementation.
Original 2026-10-25 evidence is unchanged and remains in static-restart-validation-20261025.tar.gz. No accepted ADR is changed by this snapshot.
