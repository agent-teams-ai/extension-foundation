#!/usr/bin/env bash
set -euo pipefail
: "${NATIVE_ROOT:?}" "${EVIDENCE:?}" "${GITHUB_ENV:?}"
test "$(id -u)" -ne 0
proof="$NATIVE_ROOT/provenance"; native="$NATIVE_ROOT/server"; clients="$NATIVE_ROOT/clients"
mkdir -p "$native" "$clients" "$NATIVE_ROOT/lib-links" "$NATIVE_ROOT/clusters"
gpgv --keyring "$proof/pgdg.gpg" "$proof/InRelease" > "$EVIDENCE/pgdg-signature.log" 2>&1
test "$(sha256sum "$proof/Packages.bz2" | cut -d' ' -f1)" = c7b59a75901101e020a1ba2838afe3e461acad104d8c4b3b5a7c22e341f965ec
grep -F 'c7b59a75901101e020a1ba2838afe3e461acad104d8c4b3b5a7c22e341f965ec 904666 main/binary-amd64/Packages.bz2' "$proof/InRelease" > "$EVIDENCE/pgdg-index-binding.txt"
bzcat "$proof/Packages.bz2" | awk 'BEGIN {RS=""; FS="\n"; OFS="\t"}
  {delete f; for(i=1;i<=NF;i++){n=index($i,": "); if(n && $i !~ /^[ \t]/) f[substr($i,1,n-1)]=substr($i,n+2)}
   if((f["Package"]=="libpq5" || f["Package"]=="postgresql-client-18") && f["Version"]=="18.4-1.pgdg24.04+1" && f["Architecture"]=="amd64")
     print f["Package"],f["Version"],f["Architecture"],f["Filename"],f["Size"],f["SHA256"]}' | sort > "$EVIDENCE/signed-package-fields.tsv"
jq -r '.[] | [.Package,.Version,.Architecture,.Filename,.Size,.SHA256] | @tsv' "$proof/selected18.4-records.json" | sort > "$EVIDENCE/selected-package-fields.tsv"
test "$(wc -l < "$EVIDENCE/signed-package-fields.tsv")" = 2
cmp "$EVIDENCE/signed-package-fields.tsv" "$EVIDENCE/selected-package-fields.tsv"
cp "$proof/selected18.4-records.json" "$EVIDENCE/pgdg-selected-records.json"
fetch() { curl --fail --location --proto '=https' --connect-timeout 5 --max-time 25 --max-filesize 120000000 "$1" -o "$2"; }
sri='jVw/MdDtIX/vICH/DKIe6/mHpiCggdx6QVyza4vt/NbcZFsL0KhwglF6F1Koqx3gRBZ9XtN+vi63EsqSyqOSxA=='
fetch 'https://registry.npmjs.org/@embedded-postgres%2flinux-x64/18.4.0-beta.17' "$EVIDENCE/server-registry.json"
test "$(jq -r '.dist.integrity' "$EVIDENCE/server-registry.json")" = "sha512-$sri"
fetch 'https://registry.npmjs.org/@embedded-postgres/linux-x64/-/linux-x64-18.4.0-beta.17.tgz' "$NATIVE_ROOT/server.tgz"
test "$(openssl dgst -sha512 -binary "$NATIVE_ROOT/server.tgz" | base64 -w0)" = "$sri"
tar --no-same-owner -xzf "$NATIVE_ROOT/server.tgz" --strip-components=1 -C "$native"
test "$(jq -r '.version' "$native/package.json")" = 18.4.0-beta.17
# Reproduce declared native library aliases in an owned overlay; do not run package hooks or edit package bytes.
cp "$native/native/pg-symlinks.json" "$EVIDENCE/server-pg-symlinks.json"
jq -e 'type=="array" and all(.[]; (.source|type)=="string" and (.target|type)=="string")' "$native/native/pg-symlinks.json" > /dev/null
jq -r '.[] | [.source,.target] | @tsv' "$native/native/pg-symlinks.json" | while IFS=$'\t' read -r src dst; do
  [[ "$src" =~ ^native/lib/[^/]+$ && "$dst" =~ ^native/lib/[^/]+$ ]]
  test -f "$native/$src"
  ln -s "$native/$src" "$NATIVE_ROOT/lib-links/$(basename "$dst")"
done
for package in libpq5 postgresql-client-18; do
  record=$(jq -ce --arg p "$package" '.[] | select(.Package==$p and .Version=="18.4-1.pgdg24.04+1" and .Architecture=="amd64")' "$proof/selected18.4-records.json")
  file="$NATIVE_ROOT/$package.deb"
  fetch "https://apt.postgresql.org/pub/repos/apt/$(jq -r '.Filename' <<< "$record")" "$file"
  printf '%s  %s\n' "$(jq -r '.SHA256' <<< "$record")" "$file" | sha256sum -c -
  dpkg-deb -f "$file" > "$EVIDENCE/$package-control.txt"
  dpkg-deb -x "$file" "$clients"
done
lib="$clients/usr/lib/x86_64-linux-gnu"
export LD_LIBRARY_PATH="$lib:$NATIVE_ROOT/lib-links:$native/native/lib"
serverbin="$native/native/bin"; helperbin="$clients/usr/lib/postgresql/18/bin"
for executable in "$serverbin/postgres" "$serverbin/initdb" "$serverbin/pg_ctl" "$helperbin/pg_dump" "$helperbin/pg_restore" "$helperbin/pg_dumpall" "$helperbin/psql"; do
  "$executable" --version >> "$EVIDENCE/native-versions.txt"
  dependencies=$(ldd "$executable")
  printf '%s\n%s\n' "$executable" "$dependencies" >> "$EVIDENCE/native-ldd.txt"
  ! grep -F 'not found' <<< "$dependencies"
  if grep -Fq 'libpq.so.5 =>' <<< "$dependencies"; then grep -Fq "libpq.so.5 => $lib/libpq.so.5" <<< "$dependencies"; fi
done
! grep -F 'not found' "$EVIDENCE/native-ldd.txt"
grep -F "libpq.so.5 => $lib/libpq.so.5" "$EVIDENCE/native-ldd.txt" > "$EVIDENCE/selected-libpq.txt"
find "$native/native" "$clients/usr/lib" -type f -print0 | sort -z | xargs -0 sha256sum > "$EVIDENCE/native-file-hashes.txt"
cp "$proof/InRelease" "$EVIDENCE/pgdg-InRelease.txt"
sha256sum "$proof/ACCC4CF8.asc" "$proof/pgdg.gpg" "$proof/Packages.bz2" "$NATIVE_ROOT/server.tgz" "$NATIVE_ROOT/libpq5.deb" "$NATIVE_ROOT/postgresql-client-18.deb" > "$EVIDENCE/native-source-hashes.txt"
jq -n --arg sri "sha512-$sri" --slurpfile packages "$proof/selected18.4-records.json" '{serverPackage:"@embedded-postgres/linux-x64@18.4.0-beta.17",serverIntegrity:$sri,pgdgPackages:$packages[0],signatureEvidence:"pgdg-signature.log",nativeDependencies:"native-ldd.txt",hashes:"native-file-hashes.txt",supplyChainQualification:false}' > "$EVIDENCE/native-provenance.json"
{
  printf 'STATE_RECOVERY_POSTGRES_BIN=%s\nSTATE_RECOVERY_HELPER_BIN=%s\n' "$serverbin" "$helperbin"
  printf 'STATE_RECOVERY_TEMP_BASE=%s\nSTATE_RECOVERY_OUTPUT=%s\n' "$NATIVE_ROOT/clusters" "$EVIDENCE/sr1"
  printf 'STATE_RECOVERY_PROVENANCE_JSON=%s\nLD_LIBRARY_PATH=%s\n' "$EVIDENCE/native-provenance.json" "$LD_LIBRARY_PATH"
} >> "$GITHUB_ENV"
