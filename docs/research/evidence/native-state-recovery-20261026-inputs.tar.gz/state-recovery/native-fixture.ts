import assert from 'node:assert/strict';
import {spawn, type ChildProcess} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir, mkdtemp, readFile, rm, statfs, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {Pool} from 'pg';

const nativeChildren = new Set<ChildProcess>();
export const nativeEvents: unknown[] = [];
export const nativeRoots: {root: string; removed: boolean; debt?: string}[] = [];
export function required(name: string): string {
  const value = process.env[name];
  assert.ok(value, `Explicit ${name} is required`);
  return value;
}
export async function diskGuard(path: string): Promise<void> {
  const space = await statfs(path, {bigint: true});
  assert.ok(space.bavail * space.bsize >= 1024n ** 3n, 'Native run requires at least 1GiB available; no relaxed fallback');
}
export async function command(executable: string, args: readonly string[], output: string, label: string) {
  const child = spawn(executable, [...args], {detached: true, stdio: ['ignore', 'pipe', 'pipe']});
  nativeChildren.add(child);
  let stdout = '';
  let stderr = '';
  let deadline = false;
  const kill = () => {if (child.pid !== undefined) {try {process.kill(-child.pid, 'SIGKILL');} catch { /* Exit is independently awaited. */ }}};
  child.stdout?.on('data', (chunk: Buffer) => {stdout += chunk.toString(); if (stdout.length > 1024 * 1024) kill();});
  child.stderr?.on('data', (chunk: Buffer) => {stderr += chunk.toString(); if (stderr.length > 1024 * 1024) kill();});
  const timer = setTimeout(() => {deadline = true; kill();}, 30_000);
  const code = await new Promise<number>(resolve => {
    child.once('error', cause => {stderr += String(cause);});
    child.once('close', (value, signal) => {
      nativeEvents.push({kind: 'native-command-close', label, pid: child.pid, code: value, signal, deadline});
      resolve(deadline ? -1 : value ?? -1);
    });
  });
  clearTimeout(timer);
  nativeChildren.delete(child);
  await writeFile(join(output, `${label}.log`), stdout + stderr + `\nexit=${code}\n`);
  return {code, stdout, stderr};
}
export async function checked(executable: string, args: readonly string[], output: string, label: string) {
  const answer = await command(executable, args, output, label);
  assert.equal(answer.code, 0, `${label}: ${answer.stderr}`);
  return answer;
}
export async function binaryIdentity(paths: readonly string[]) {
  return Promise.all(paths.map(async path => ({path,
    sha256: createHash('sha256').update(await readFile(path)).digest('hex')})));
}
export function killOwnedPostmasterGroups(): void {
  for (const child of nativeChildren) {
    if (child.pid !== undefined && child.exitCode === null && child.signalCode === null) {
      // These detached process groups are created only by this fixture, one postmaster each.
      try {process.kill(-child.pid, 'SIGKILL');} catch (cause) {
        nativeEvents.push({kind: 'group-kill-error', pid: child.pid, error: String(cause)});
      }
    }
  }
}
export async function ownedCluster(bin: string, parent: string, output: string, label: string, owner: string) {
  await diskGuard(parent);
  const root = await mkdtemp(join(parent, `sr1-${label}-`));
  const rootFact: {root: string; removed: boolean; debt?: string} = {root, removed: false};
  nativeRoots.push(rootFact);
  const data = join(root, 'data');
  const socket = join(root, 's');
  let postmaster: ChildProcess | undefined;
  let stopped = false;
  let exit: Promise<void> | undefined;
  let log = '';
  const pools: Pool[] = [];
  function pool(user: string, database = 'TEST_feature') {
    const value = new Pool({host: socket, user, database, max: 2, connectionTimeoutMillis: 2000,
      options: '-c statement_timeout=5000 -c lock_timeout=3000'});
    value.on('error', error => nativeEvents.push({kind: 'pool-error', label, error: error.message}));
    pools.push(value);
    return value;
  }
  async function stop(): Promise<void> {
    await Promise.all(pools.map(value => value.ended ? Promise.resolve() : value.end()));
    if (postmaster !== undefined && postmaster.exitCode === null && postmaster.signalCode === null) {
      await checked(join(bin, 'pg_ctl'), ['-D', data, '-m', 'fast', '-w', '-t', '10', 'stop'], output, `${label}-stop`);
      assert.ok(exit);
      await exit;
      assert.equal(postmaster.exitCode, 0);
    }
    const status = await command(join(bin, 'pg_ctl'), ['-D', data, 'status'], output, `${label}-status`);
    assert.equal(status.code, 3, 'Only status3 proves this owned cluster stopped');
    const pid = postmaster?.pid;
    if (pid !== undefined) assert.throws(() => process.kill(pid, 0), {code: 'ESRCH'});
    stopped = true;
    await writeFile(join(output, `${label}-server.log`), log);
  }
  try {
    await mkdir(socket, {mode: 0o700});
    await checked(join(bin, 'initdb'), ['-D', data, '-A', 'trust', '-U', owner, '--no-locale', '--encoding=UTF8'], output, `${label}-initdb`);
    postmaster = spawn(join(bin, 'postgres'), ['-D', data, '-k', socket, '-h', '', '-c', 'fsync=on',
      '-c', 'full_page_writes=on', '-c', 'synchronous_commit=on', '-c', 'max_connections=12',
      '-c', 'log_min_duration_statement=0', '-c', 'log_line_prefix=%m pid=%p session=%c tx=%x '],
    {detached: true, stdio: ['ignore', 'pipe', 'pipe']});
    assert.ok(postmaster.pid);
    nativeChildren.add(postmaster);
    postmaster.stdout?.on('data', (chunk: Buffer) => {log += chunk.toString();});
    postmaster.stderr?.on('data', (chunk: Buffer) => {log += chunk.toString();});
    const active = postmaster;
    exit = new Promise<void>((resolve, reject) => {
      active.once('error', reject);
      active.once('exit', (code, signal) => {
        nativeEvents.push({label, pid: active.pid, code, signal});
        nativeChildren.delete(active);
        resolve();
      });
    });
    const end = Date.now() + 10_000;
    while (!log.includes('database system is ready to accept connections')) {
      assert.ok(active.exitCode === null && active.signalCode === null && Date.now() < end, `Readiness failed: ${log}`);
      await delay(20);
    }
    const bootstrap = pool(owner, 'postgres');
    const identity = (await bootstrap.query<Record<string, unknown>>(`SELECT version(),system_identifier::text AS system_identifier,
      current_setting('data_directory') AS data_directory,current_setting('fsync') AS fsync,
      current_setting('full_page_writes') AS full_page_writes,current_setting('synchronous_commit') AS synchronous_commit
      FROM pg_control_system()`)).rows[0];
    assert.ok(identity);
    assert.equal(identity.data_directory, data);
    assert.match(String(identity.version), /PostgreSQL 18\.4\b/);
    for (const name of ['fsync', 'full_page_writes', 'synchronous_commit']) assert.equal(identity[name], 'on');
    return {root, data, socket, pool, bootstrap, identity, stop, logSnapshot: () => log,
      async remove() {assert.ok(stopped); await rm(root, {recursive: true, force: true}); rootFact.removed = true;}};
  } catch (cause) {
    rootFact.debt = `Initialization failed before owner returned; root retained and removal unproved: ${String(cause)}`;
    if (postmaster?.pid !== undefined) {
      try {process.kill(-postmaster.pid, 'SIGKILL');} catch { /* Original failure is retained. */ }
      await exit?.catch(() => {});
    }
    await Promise.all(pools.map(value => value.ended ? Promise.resolve() : value.end())).catch(cleanup => {
      rootFact.debt += `; pool cleanup error: ${String(cleanup)}`;
    });
    await writeFile(join(output, `${label}-server.log`), log).catch(() => {});
    throw cause;
  }
}
