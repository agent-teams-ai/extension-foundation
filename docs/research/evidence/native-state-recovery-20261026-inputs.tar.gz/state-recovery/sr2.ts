import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {Client, type Pool} from 'pg';
import {drizzle} from 'drizzle-orm/node-postgres';
import {migrate} from 'drizzle-orm/node-postgres/migrator';
import type {MigrationConfig} from 'drizzle-orm/migrator';
import {diskGuard, killOwnedPostmasterGroups, nativeEvents, nativeRoots, ownedCluster, required} from './native-fixture.js';

assert.equal(process.version, 'v26.11.1');
assert.notEqual(process.getuid?.(), 0);
const bin = required('STATE_RECOVERY_POSTGRES_BIN');
const temporary = required('STATE_RECOVERY_TEMP_BASE');
const output = required('STATE_RECOVERY_OUTPUT');
await mkdir(output, {recursive: true});
await diskGuard(temporary);
const names = ['20261026000000_m0', '20261026000001_m1', '20261026000002_m2'] as const;
const evidence: Record<string, unknown> = {kind: 'sr2-public-drizzle-migrator', releaseQualification: false,
  node: process.version, orm: '1.0.0-rc.4', source: '748058e837d9c4247330e3d45580cbdae52bffda', nativeEvents, nativeRoots,
  scope: 'Warm current metadata; transactional pending migrations; participating owner lock only'};
let cluster: Awaited<ReturnType<typeof ownedCluster>> | undefined;
let emergency = false;
let status = 1;
const watchdog = setTimeout(() => {emergency = true; killOwnedPostmasterGroups();}, 120_000);
type State = {counter: string; journal: {id: number; name: string; hash: string}[]; partial: string | null; added: boolean};
async function sqlFile(config: MigrationConfig, index: 0 | 1 | 2, text: string) {
  const name = names[index];
  const folder = join(config.migrationsFolder, name);
  await mkdir(folder, {recursive: true});
  await writeFile(join(folder, 'migration.sql'), text);
  return {name, hash: createHash('sha256').update(text).digest('hex')};
}
function config(group: string): MigrationConfig {
  assert.match(group, /^sr2_[abc]$/);
  return {migrationsFolder: join(output, 'sql', group), migrationsSchema: `${group}_journal`, migrationsTable: 'entries'};
}
async function state(owner: Pool, group: string): Promise<State> {
  const journal = (await owner.query<{id: number; name: string; hash: string}>(
    `SELECT id,name,hash FROM "${group}_journal".entries ORDER BY id`)).rows;
  const counter = (await owner.query<{n: string}>(`SELECT n::text AS n FROM "${group}".counter`)).rows[0];
  assert.ok(counter);
  const partial = (await owner.query<{name: string | null}>('SELECT to_regclass($1)::text AS name', [`${group}.partial`])).rows[0];
  const added = (await owner.query(`SELECT 1 FROM information_schema.columns WHERE table_schema=$1
    AND table_name='counter' AND column_name='qualified'`, [group])).rowCount === 1;
  return {counter: counter.n, journal, partial: partial?.name ?? null, added};
}
function expectedJournal(actual: State, expected: readonly {name: string; hash: string}[]) {
  // SERIAL IDs can have gaps after rollback. Identity/hash/multiplicity, not contiguous IDs, is decisive.
  assert.deepEqual(actual.journal.map(({name, hash}) => ({name, hash})), expected);
}
async function withClients<T>(socket: string, body: (a: Client, b: Client, pids: number[]) => Promise<T>): Promise<T> {
  const clients = ['A', 'B'].map(label => new Client({host: socket, user: 'TEST_migration_owner', database: 'postgres',
    application_name: `sr2-${label}`, connectionTimeoutMillis: 2000,
    options: '-c statement_timeout=3000 -c lock_timeout=2000'}));
  const a = clients[0]; const b = clients[1]; assert.ok(a && b);
  for (const client of clients) client.on('error', cause => nativeEvents.push({kind: 'migration-client-error', message: cause.message}));
  try {
    await Promise.all(clients.map(client => client.connect()));
    const pids = await Promise.all(clients.map(async client => (await client.query<{pid: number}>('SELECT pg_backend_pid() AS pid')).rows[0]?.pid));
    assert.ok(pids.every((pid): pid is number => pid !== undefined));
    return await body(a, b, pids);
  } finally {await Promise.all(clients.map(client => client.end()));}
}
async function waitFor<T>(probe: () => Promise<T | undefined>, label: string): Promise<T> {
  const deadline = Date.now() + 1800;
  while (Date.now() < deadline) {
    const observed = await probe();
    if (observed !== undefined) return observed;
    await delay(10);
  }
  throw new Error(`Real server boundary was not observed: ${label}`);
}
async function advisoryRows(owner: Pool, pids: readonly number[]) {
  return (await owner.query<{pid: number; objid: string; granted: boolean; blockers: number[]}>(
    `SELECT pid,objid::text AS objid,granted,pg_blocking_pids(pid) AS blockers FROM pg_locks
    WHERE locktype='advisory' AND pid=ANY($1::int[]) ORDER BY pid,objid,granted`, [[...pids]])).rows;
}
function errorChain(value: unknown): unknown[] {
  const chain: unknown[] = [];
  let current = value;
  for (let i = 0; i < 6 && typeof current === 'object' && current !== null; i++) {
    chain.push({name: 'name' in current ? current.name : undefined,
      message: 'message' in current ? current.message : undefined, code: 'code' in current ? current.code : undefined});
    current = 'cause' in current ? current.cause : undefined;
  }
  return chain;
}
async function earlyLock(client: Client, key: string, selected: MigrationConfig) {
  await client.query('SELECT pg_advisory_lock($1::bigint)', [key]);
  try {return await migrate(drizzle({client: client}), selected);}
  finally {await client.query('SELECT pg_advisory_unlock($1::bigint)', [key]);}
}
async function concurrency(owner: Pool, socket: string, corrected: boolean) {
  const group = corrected ? 'sr2_b' : 'sr2_a';
  const selected = config(group);
  return withClients(socket, async (a, b, pids) => {
    const m0 = await sqlFile(selected, 0, `CREATE SCHEMA "${group}";\n--> statement-breakpoint\nCREATE TABLE "${group}".counter(n integer NOT NULL);\n--> statement-breakpoint\nINSERT INTO "${group}".counter VALUES(0);`);
    await migrate(drizzle({client: a}), selected);
    const before = await state(owner, group);
    expectedJournal(before, [m0]); assert.equal(before.counter, '0');
    const barrierKey = corrected ? '901002' : '901001';
    const frontKey = '902002';
    const m1 = await sqlFile(selected, 1, `SELECT pg_advisory_xact_lock(${barrierKey}::bigint);\n--> statement-breakpoint\nUPDATE "${group}".counter SET n=n+1;`);
    const holder = await owner.connect();
    let actualLocks: unknown;
    let outcomes: PromiseSettledResult<unknown>[] = [];
    try {
      await holder.query('BEGIN');
      await holder.query('SELECT pg_advisory_xact_lock($1::bigint)', [barrierKey]);
      const all = Promise.allSettled([corrected ? earlyLock(a, frontKey, selected) : migrate(drizzle({client: a}), selected),
        corrected ? earlyLock(b, frontKey, selected) : migrate(drizzle({client: b}), selected)]);
      try {
        actualLocks = await waitFor(async () => {
          const locks = await advisoryRows(owner, pids);
          const bodyWaiters = locks.filter(row => row.objid === barrierKey && !row.granted);
          if (!corrected) return bodyWaiters.length === 2 ? locks : undefined;
          const frontWaiters = locks.filter(row => row.objid === frontKey && !row.granted);
          const frontOwner = locks.find(row => row.objid === frontKey && row.granted);
          return bodyWaiters.length === 1 && frontWaiters.length === 1 && frontOwner !== undefined
            && frontWaiters[0]?.blockers.includes(frontOwner.pid) ? locks : undefined;
        }, corrected ? 'body waiter plus early owner-lock waiter' : 'both genuinely pending body waiters');
      } finally {await holder.query('ROLLBACK'); outcomes = await all;}
    } finally {await holder.query('ROLLBACK').catch(() => {}); holder.release();}
    const after = await state(owner, group);
    const failures = outcomes.filter(row => row.status === 'rejected');
    if (corrected) {
      assert.equal(failures.length, 0);
      assert.equal(after.counter, '1'); expectedJournal(after, [m0, m1]);
    }
    return {group, pids, before, actualLocks, outcomes: outcomes.map(row => row.status === 'fulfilled'
      ? {status: row.status, value: row.value} : {status: row.status, errors: errorChain(row.reason)}), after,
    needsOwnerSerialization: failures.length > 0 || after.counter !== '1' || after.journal.length !== 2};
  });
}
async function rollbackRetry(owner: Pool, socket: string, logs: () => string) {
  const group = 'sr2_c'; const selected = config(group);
  return withClients(socket, async (a, _b, pids) => {
    const pid = pids[0]; assert.ok(pid);
    const m0 = await sqlFile(selected, 0, `CREATE SCHEMA "${group}";\n--> statement-breakpoint\nCREATE TABLE "${group}".counter(n integer NOT NULL);\n--> statement-breakpoint\nINSERT INTO "${group}".counter VALUES(0);`);
    await migrate(drizzle({client: a}), selected);
    const m1 = await sqlFile(selected, 1, `UPDATE "${group}".counter SET n=n+1;\n--> statement-breakpoint\nCREATE TABLE "${group}".partial(id text);`);
    const m2 = await sqlFile(selected, 2, `ALTER TABLE "${group}".counter ADD COLUMN qualified text;`);
    const before = await state(owner, group); expectedJournal(before, [m0]);
    const holder = await owner.connect();
    let waited: unknown;
    let failure: unknown;
    let completedJournal: string[] = [];
    try {
      await holder.query('BEGIN');
      await holder.query(`LOCK TABLE "${group}".counter IN ACCESS SHARE MODE`);
      await a.query("SET lock_timeout='500ms'");
      const logStart = logs().length;
      const attempt = migrate(drizzle({client: a}), selected).then(() => undefined, cause => cause as unknown);
      waited = await waitFor(async () => {
        const rows = (await owner.query(`SELECT a.pid,a.query,a.wait_event_type,pg_blocking_pids(a.pid) AS blockers
          FROM pg_stat_activity a WHERE a.pid=$1 AND a.wait_event_type='Lock'
          AND a.query LIKE '%ALTER TABLE%'`, [pid])).rows;
        return rows.length === 1 ? rows : undefined;
      }, 'actual later ALTER waiting after earlier journal insertion');
      completedJournal = logs().slice(logStart).split('\n').filter(line => line.includes(`pid=${pid} `));
      assert.ok(completedJournal.some(line => /duration:.*execute .*insert into/i.test(line)
        && line.includes(`"${group}_journal"."entries"`)), 'Require actual native extended Execute completion for M1 journal');
      assert.ok(completedJournal.some(line => line.includes(names[1])), 'Correlate completed M1 parameters/name on exact backend');
      failure = await attempt;
      assert.ok(errorChain(failure).some(row => typeof row === 'object' && row !== null && 'code' in row && row.code === '55P03'));
      assert.equal((await a.query('SELECT 1 AS usable')).rows[0]?.usable, 1, 'Library must complete rollback, leaving client usable');
    } finally {await holder.query('ROLLBACK'); holder.release();}
    const afterFailure = await state(owner, group);
    assert.deepEqual(afterFailure, before, 'Actual earlier data, DDL and M1 journal must all roll back');
    await migrate(drizzle({client: a}), selected);
    const afterRetry = await state(owner, group);
    assert.equal(afterRetry.counter, '1'); assert.equal(afterRetry.partial, `${group}.partial`); assert.equal(afterRetry.added, true);
    expectedJournal(afterRetry, [m0, m1, m2]);
    const noOpHolder = await owner.connect();
    let noOpLog: string;
    try {
      await noOpHolder.query('BEGIN'); await noOpHolder.query(`LOCK TABLE "${group}".counter IN ACCESS SHARE MODE`);
      const start = logs().length;
      await migrate(drizzle({client: a}), selected);
      noOpLog = logs().slice(start).split('\n').filter(line => line.includes(`pid=${pid} `)).join('\n');
      assert.doesNotMatch(noOpLog, /ALTER TABLE/);
      assert.deepEqual(await state(owner, group), afterRetry);
    } finally {await noOpHolder.query('ROLLBACK'); noOpHolder.release();}
    return {group, pid, before, waited, completedJournal, errors: errorChain(failure), afterFailure,
      afterRetry, noOpUnderSameBlocker: {unchanged: true, actualServerLog: noOpLog}};
  });
}
try {
  evidence.provenance = JSON.parse(await readFile(required('STATE_RECOVERY_PROVENANCE_JSON'), 'utf8')) as unknown;
  cluster = await ownedCluster(bin, temporary, output, 'migrator', 'TEST_migration_owner');
  evidence.identity = cluster.identity;
  const unwrapped = await concurrency(cluster.bootstrap, cluster.socket, false);
  evidence.unwrappedConcurrentPending = unwrapped;
  if (unwrapped.needsOwnerSerialization) evidence.sameClientEarlyOwnerLock = await concurrency(cluster.bootstrap, cluster.socket, true);
  else evidence.sameClientEarlyOwnerLock = {status: 'omitted', reason: 'Unwrapped observed serialization; inspect source/result before recommending a wrapper'};
  evidence.blockedDdlRollbackRetryNoOp = await rollbackRetry(cluster.bootstrap, cluster.socket, cluster.logSnapshot);
  status = 0;
} catch (cause) {evidence.error = errorChain(cause);}
finally {
  clearTimeout(watchdog);
  const cleanupDeadline = setTimeout(() => {emergency = true; killOwnedPostmasterGroups();}, 15_000);
  try {if (cluster !== undefined) {await cluster.stop(); await cluster.remove();}
    evidence.cleanupComplete = nativeRoots.every(value => value.removed); if (evidence.cleanupComplete !== true) status = 1;}
  catch (cause) {evidence.cleanupError = errorChain(cause); status = 1; killOwnedPostmasterGroups();}
  finally {clearTimeout(cleanupDeadline);}
  if (emergency) {status = 1; evidence.watchdogUsed = true;}
  evidence.outcome = status === 0 ? 'bounded-public-migrator-observations-complete' : 'failed';
  await writeFile(join(output, 'results.json'), JSON.stringify(evidence, null, 2) + '\n');
}
process.exitCode = status;
