import assert from 'node:assert/strict';
import type {Pool} from 'pg';
import type {ManifestRequestContext, SandboxManifest} from './fixture/agent-context/features/sandbox-manifest/application/api.js';

export const contextA: ManifestRequestContext = {tenantId: 'TEST_tenant_a',
  projectId: 'tenants/TEST_tenant_a/projects/TEST_project', principalId: 'TEST_principal'};
export const contextB: ManifestRequestContext = {tenantId: 'TEST_tenant_b',
  projectId: 'tenants/TEST_tenant_b/projects/TEST_project', principalId: 'TEST_principal'};
export function manifest(context: ManifestRequestContext, id: string): SandboxManifest {
  return {name: `${context.projectId}/contextManifests/${id}`, workspace: `${context.projectId}/workspaces/workspace`,
    agentProfileVersion: `${context.projectId}/agentProfileVersions/profile`,
    runPolicySnapshot: `${context.projectId}/runPolicySnapshots/policy`,
    instructionRef: 'instructions:exact-9007199254740993', createdAt: '-1'};
}
export const initial = [{context: contextA, value: manifest(contextA, 'one'), event: 'TEST_event_a_one'},
  {context: contextA, value: manifest(contextA, 'two'), event: 'TEST_event_a_two'},
  {context: contextB, value: manifest(contextB, 'one'), event: 'TEST_event_b_one'}] as const;
export const next = {context: contextB, value: manifest(contextB, 'after-restore'), event: 'TEST_event_b_after_restore'};

export async function snapshot(owner: Pool) {
  const facts = (await owner.query(`SELECT tenant_id,project_id,name,fingerprint,facts,
    to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS.US') AS instant
    FROM agent_context.manifests ORDER BY name`)).rows;
  const outbox = (await owner.query('SELECT * FROM agent_context.outbox ORDER BY resource_name')).rows;
  return {facts, outbox};
}
export async function expectedRows(owner: Pool, records: readonly typeof next[]) {
  const actual = await snapshot(owner);
  const sorted = [...records].sort((a, b) => a.value.name.localeCompare(b.value.name));
  assert.deepEqual(actual.facts.map(row => ({tenant_id: row.tenant_id, project_id: row.project_id,
    name: row.name, facts: row.facts, instant: row.instant})), sorted.map(row => ({tenant_id: row.context.tenantId,
    project_id: row.context.projectId, name: row.value.name, facts: row.value, instant: '1969-12-31 23:59:59.999999'})));
  assert.deepEqual(actual.outbox, sorted.map(row => ({tenant_id: row.context.tenantId, project_id: row.context.projectId,
    event_id: row.event, resource_name: row.value.name, kind: 'SandboxManifestCreated'})));
  return actual;
}
export async function catalog(owner: Pool) {
  const tables = (await owner.query(`SELECT c.relname,c.relrowsecurity,c.relforcerowsecurity,
    c.relowner::regrole::text AS owner FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE n.nspname='agent_context' AND c.relkind='r' ORDER BY c.relname`)).rows;
  const policies = (await owner.query(`SELECT c.relname,p.polname,p.polpermissive,p.polcmd,
    pg_get_expr(p.polqual,p.polrelid) AS using_expression,pg_get_expr(p.polwithcheck,p.polrelid) AS check_expression
    FROM pg_policy p JOIN pg_class c ON c.oid=p.polrelid JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE n.nspname='agent_context' ORDER BY c.relname,p.polname`)).rows;
  const grants = (await owner.query(`SELECT table_name,grantee,privilege_type,is_grantable
    FROM information_schema.table_privileges WHERE table_schema='agent_context'
    AND grantee IN ('TEST_source_owner','test_runtime') ORDER BY table_name,grantee,privilege_type`)).rows;
  const schema = (await owner.query(`SELECT nspowner::regrole::text AS owner,
    has_schema_privilege('test_runtime','agent_context','USAGE') AS runtime_usage,
    has_schema_privilege('test_runtime','agent_context','CREATE') AS runtime_create
    FROM pg_namespace WHERE nspname='agent_context'`)).rows;
  assert.equal(tables.length, 2);
  assert.ok(tables.every(row => row.relrowsecurity === true && row.relforcerowsecurity === true && row.owner === '"TEST_source_owner"'));
  assert.equal(policies.length, 2);
  assert.deepEqual(schema, [{owner: '"TEST_source_owner"', runtime_usage: true, runtime_create: false}]);
  return {tables, policies, grants, schema};
}
async function rejectedSql(runtime: Pool, sql: string, values: readonly unknown[] = [], kind: 'rls' | 'privilege' = 'rls') {
  const client = await runtime.connect();
  let code: unknown;
  let message = '';
  try {
    await client.query('BEGIN');
    await client.query("SELECT set_config('app.tenant_id',$1,true)", [contextB.tenantId]);
    try {await client.query(sql, [...values]);} catch (cause) {
      code = typeof cause === 'object' && cause !== null && 'code' in cause ? cause.code : undefined;
      message = cause instanceof Error ? cause.message : String(cause);
    }
  } finally {await client.query('ROLLBACK'); client.release();}
  assert.equal(code, '42501', 'Require actual PostgreSQL policy/privilege rejection');
  assert.match(message, kind === 'rls' ? /row-level security policy/i : /permission denied/i,
    'Distinguish RLS WITH CHECK from ordinary missing privilege');
  return {code, message, kind};
}
export async function runtimeEnforcement(runtime: Pool, owner: Pool) {
  const identity = (await runtime.query(`SELECT session_user,current_user,r.rolsuper,r.rolbypassrls,r.rolinherit
    FROM pg_roles r WHERE r.rolname=current_user`)).rows;
  assert.deepEqual(identity, [{session_user: 'test_runtime', current_user: 'test_runtime',
    rolsuper: false, rolbypassrls: false, rolinherit: false}]);
  const memberships = (await runtime.query(`SELECT roleid::regrole::text AS role FROM pg_auth_members
    WHERE member=(SELECT oid FROM pg_roles WHERE rolname=current_user)`)).rows;
  assert.deepEqual(memberships, []);
  const effectiveDml = (await runtime.query(`SELECT
    has_table_privilege(current_user,'agent_context.manifests','INSERT') AS manifests_insert,
    has_table_privilege(current_user,'agent_context.manifests','UPDATE') AS manifests_update,
    has_table_privilege(current_user,'agent_context.outbox','INSERT') AS outbox_insert,
    has_table_privilege(current_user,'agent_context.outbox','UPDATE') AS outbox_update`)).rows;
  assert.deepEqual(effectiveDml, [{manifests_insert: true, manifests_update: true, outbox_insert: true, outbox_update: true}]);
  const before = await snapshot(owner);
  const client = await runtime.connect();
  try {
    await client.query('BEGIN');
    await client.query("SELECT set_config('app.tenant_id',$1,true)", [contextB.tenantId]);
    // No application tenant predicate: PostgreSQL itself must hide foreign rows.
    const visible = (await client.query('SELECT name FROM agent_context.manifests ORDER BY name')).rows;
    const events = (await client.query('SELECT event_id FROM agent_context.outbox ORDER BY event_id')).rows;
    assert.deepEqual(visible, [{name: initial[2].value.name}]);
    assert.deepEqual(events, [{event_id: initial[2].event}]);
  } finally {await client.query('ROLLBACK'); client.release();}
  const rejections = [];
  rejections.push(await rejectedSql(runtime, `INSERT INTO agent_context.manifests
    (tenant_id,project_id,name,fingerprint,facts,created_at) VALUES($1,$2,'TEST_foreign','TEST_hash','{}','2000-01-01')`,
  [contextA.tenantId, contextA.projectId]));
  rejections.push(await rejectedSql(runtime, 'UPDATE agent_context.manifests SET tenant_id=$1 WHERE name=$2',
    [contextA.tenantId, initial[2].value.name]));
  rejections.push(await rejectedSql(runtime, `INSERT INTO agent_context.outbox VALUES($1,$2,'TEST_foreign_event','TEST_foreign','TEST_kind')`,
    [contextA.tenantId, contextA.projectId]));
  rejections.push(await rejectedSql(runtime, 'UPDATE agent_context.outbox SET tenant_id=$1 WHERE event_id=$2',
    [contextA.tenantId, initial[2].event]));
  const ddl = await rejectedSql(runtime, 'CREATE TABLE agent_context.TEST_forbidden(id text)', [], 'privilege');
  assert.deepEqual(await snapshot(owner), before);
  return {identity, memberships, effectiveDml, ownRowsVisible: true, foreignRowsAbsent: true,
    directWriteRejections: rejections, runtimeDdlRejected: ddl};
}
