import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createSandboxManifestFeature} from './fixture/agent-context/index.js';
import {binaryIdentity, checked, command, diskGuard, killOwnedPostmasterGroups,
  nativeEvents, nativeRoots, ownedCluster, required} from './native-fixture.js';
import {catalog, contextB, expectedRows, initial, next, runtimeEnforcement, snapshot} from './sr1-oracles.js';

// Disposable research driver. No target migration/GRANT/policy repairs are permitted after restore.
assert.equal(process.version, 'v26.11.1');
assert.notEqual(process.getuid?.(), 0, 'PostgreSQL must run as the root-provided unprivileged research identity');
const bin = required('STATE_RECOVERY_POSTGRES_BIN');
const helpers = required('STATE_RECOVERY_HELPER_BIN');
const temporary = required('STATE_RECOVERY_TEMP_BASE');
const output = required('STATE_RECOVERY_OUTPUT');
const provenance = required('STATE_RECOVERY_PROVENANCE_JSON');
await mkdir(output, {recursive: true});
await diskGuard(temporary);
const archive = join(output, 'feature.dump');
const globals = join(output, 'globals.sql');
const rows: {name: string; status: string; detail?: unknown}[] = [];
const result: Record<string, unknown> = {kind: 'sr1-logical-restore', releaseQualification: false,
  node: process.version, platform: process.platform, arch: process.arch, uid: process.getuid?.(),
  evidencePin: 'aaabc1e7cd2e2482668530e4412e61c2bca1f515', rows, nativeEvents, nativeRoots};
let source: Awaited<ReturnType<typeof ownedCluster>> | undefined;
let target: Awaited<ReturnType<typeof ownedCluster>> | undefined;
let status = 1;
let emergency = false;
const watchdog = setTimeout(() => {
  emergency = true;
  result.outerDeadlineExceeded = true;
  killOwnedPostmasterGroups();
}, 180_000);
const check = (name: string, detail?: unknown) => rows.push({name, status: 'passed', ...(detail === undefined ? {} : {detail})});
try {
  // Caller-supplied provenance records actual archive/package hashes, paths and native dependency resolution.
  result.provenance = JSON.parse(await readFile(provenance, 'utf8')) as unknown;
  const tools = ['pg_dump', 'pg_restore', 'pg_dumpall', 'psql'];
  for (const tool of tools) {
    const observed = await checked(join(helpers, tool), ['--version'], output, `${tool}-version`);
    assert.match(observed.stdout, /18\.4\b/, `Exact18.4 helper required: ${tool}`);
  }
  result.binaryIdentities = await binaryIdentity([
    ...['postgres', 'initdb', 'pg_ctl'].map(tool => join(bin, tool)), ...tools.map(tool => join(helpers, tool)),
  ]);
  source = await ownedCluster(bin, temporary, output, 'source', 'TEST_source_owner');
  result.sourceIdentity = source.identity;
  result.sourceRoot = source.root;
  await source.bootstrap.query('CREATE ROLE test_runtime LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT');
  await source.bootstrap.query('CREATE DATABASE "TEST_feature" OWNER "TEST_source_owner" TEMPLATE template0');
  const owner = source.pool('TEST_source_owner');
  const runtime = source.pool('test_runtime');
  const make = (event: string) => createSandboxManifestFeature({pool: runtime, migrationPool: owner,
    authorization: {async assertAuthorized() {}}, nextId: () => event});
  await make('TEST_unused').migrate();
  await owner.query('GRANT USAGE ON SCHEMA agent_context TO test_runtime');
  await owner.query('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA agent_context TO test_runtime');
  for (const row of initial) {
    await make(row.event).seedManifest(row.context, row.value);
    assert.deepEqual(await make(row.event).api.getManifest(row.context, {name: row.value.name}), row.value);
  }
  await make(initial[0].event).seedManifest(initial[0].context, initial[0].value);
  const original = await expectedRows(owner, initial);
  const originalCatalog = await catalog(owner);
  result.sourceEnforcement = await runtimeEnforcement(runtime, owner);
  await writeFile(join(output, 'source-expected.json'), JSON.stringify({initial, original, originalCatalog}, null, 2));
  check('actual-feature-source-state-and-direct-runtime-enforcement');

  const oldHelper = process.env.STATE_RECOVERY_PG17_DUMP;
  if (oldHelper !== undefined) {
    const oldVersion = await command(oldHelper, ['--version'], output, 'pg17-version');
    if (oldVersion.code === 0 && /17\./.test(oldVersion.stdout)) {
      const rejected = await command(oldHelper, ['-w', '-h', source.socket, '-U', 'TEST_source_owner',
        '-d', 'TEST_feature', '-Fc', '-f', join(output, 'pg17-rejected.dump')], output, 'pg17-newer-server-rejection');
      assert.notEqual(rejected.code, 0);
      assert.match(rejected.stderr, /server version.*18\.4[\s\S]*pg_dump version.*17\.|aborting because of server version mismatch/i);
      rows.push({name: 'older-major-helper-control', status: 'expected-rejection'});
    } else rows.push({name: 'older-major-helper-control', status: 'unavailable', detail: oldVersion});
  } else rows.push({name: 'older-major-helper-control', status: 'unavailable', detail: 'Optional existing PG17 helper not provided'});

  await checked(join(helpers, 'pg_dump'), ['-w', '-h', source.socket, '-U', 'TEST_source_owner',
    '-d', 'TEST_feature', '-Fc', '--compress=none', '-f', archive], output, 'dump');
  await checked(join(helpers, 'pg_dumpall'), ['-w', '-h', source.socket, '-U', 'TEST_source_owner',
    '--globals-only', '--no-role-passwords', '-f', globals], output, 'dump-globals');
  await checked(join(helpers, 'pg_restore'), ['--list', archive], output, 'archive-toc');
  const archiveHash = createHash('sha256').update(await readFile(archive)).digest('hex');
  result.archiveSha256 = archiveHash;
  result.globalsSha256 = createHash('sha256').update(await readFile(globals)).digest('hex');
  await source.stop();
  check('archive-retained-and-source-physically-stopped');

  target = await ownedCluster(bin, temporary, output, 'target', 'TEST_restore_bootstrap');
  result.targetIdentity = target.identity;
  result.targetRoot = target.root;
  assert.notEqual(target.identity.system_identifier, source.identity.system_identifier);
  await target.bootstrap.query('CREATE DATABASE "TEST_feature" OWNER "TEST_restore_bootstrap" TEMPLATE template0');
  const incomplete = await command(join(helpers, 'pg_restore'), ['-w', '-h', target.socket, '-U', 'TEST_restore_bootstrap',
    '-d', 'TEST_feature', '--single-transaction', '--exit-on-error', archive], output, 'missing-role-restore');
  assert.notEqual(incomplete.code, 0);
  assert.match(incomplete.stderr, /role .* does not exist/i);
  const targetBootstrapDb = target.pool('TEST_restore_bootstrap');
  assert.deepEqual((await targetBootstrapDb.query(`SELECT nspname FROM pg_namespace WHERE nspname='agent_context'`)).rows, []);
  assert.deepEqual((await targetBootstrapDb.query(`SELECT schemaname,tablename FROM pg_tables WHERE schemaname='agent_context'`)).rows, []);
  check('missing-role-restore-failed-with-no-partial-feature-schema', {code: incomplete.code});
  await targetBootstrapDb.end();

  await checked(join(helpers, 'psql'), ['-X', '-w', '-h', target.socket, '-U', 'TEST_restore_bootstrap',
    '-d', 'postgres', '-v', 'ON_ERROR_STOP=1', '-f', globals], output, 'restore-globals');
  await target.bootstrap.query('DROP DATABASE "TEST_feature"');
  await target.bootstrap.query('CREATE DATABASE "TEST_feature" OWNER "TEST_source_owner" TEMPLATE template0');
  await checked(join(helpers, 'pg_restore'), ['-w', '-h', target.socket, '-U', 'TEST_restore_bootstrap',
    '-d', 'TEST_feature', '--single-transaction', '--exit-on-error', archive], output, 'restore-complete');
  assert.equal(createHash('sha256').update(await readFile(archive)).digest('hex'), archiveHash);
  const restoredOwner = target.pool('TEST_source_owner');
  const restoredRuntime = target.pool('test_runtime');
  assert.deepEqual(await snapshot(restoredOwner), original);
  assert.deepEqual(await catalog(restoredOwner), originalCatalog);
  result.targetEnforcement = await runtimeEnforcement(restoredRuntime, restoredOwner);
  const restored = (event: string) => createSandboxManifestFeature({pool: restoredRuntime, migrationPool: restoredOwner,
    authorization: {async assertAuthorized() {}}, nextId: () => event});
  for (const row of initial) {
    assert.deepEqual(await restored(row.event).api.getManifest(row.context, {name: row.value.name}), row.value);
  }
  // This API validation rejection is additional evidence; direct SQL above is the RLS oracle.
  await assert.rejects(restored('TEST_wrong').api.getManifest(contextB, {name: initial[0].value.name}), {code: 'INVALID_ARGUMENT'});
  await restored('TEST_duplicate_must_not_append').seedManifest(initial[0].context, initial[0].value);
  await restored('TEST_duplicate_must_not_append').seedManifest(initial[0].context, initial[0].value);
  assert.deepEqual(await snapshot(restoredOwner), original);
  await restored(next.event).seedManifest(next.context, next.value);
  const after = await expectedRows(restoredOwner, [...initial, next]);
  await writeFile(join(output, 'target-readback.json'), JSON.stringify({after, originalCatalog,
    targetEnforcement: result.targetEnforcement}, null, 2));
  check('fresh-cluster-exact-state-acl-rls-idempotent-retry-and-new-outbox-transaction');
  status = 0;
} catch (cause) {
  result.error = cause instanceof Error ? {name: cause.name, message: cause.message, stack: cause.stack} : String(cause);
  rows.push({name: 'unexpected-failure', status: 'failed', detail: result.error});
} finally {
  clearTimeout(watchdog);
  const cleanupDeadline = setTimeout(() => {
    emergency = true;
    killOwnedPostmasterGroups();
  }, 15_000);
  try {
    for (const cluster of [target, source]) {
      if (cluster !== undefined) {await cluster.stop(); await cluster.remove();}
    }
    result.clustersStoppedAndOwnedRootsRemoved = nativeRoots.every(value => value.removed);
    if (result.clustersStoppedAndOwnedRootsRemoved !== true) status = 1;
  } catch (cause) {
    result.cleanupError = String(cause);
    result.clustersStoppedAndOwnedRootsRemoved = false;
    killOwnedPostmasterGroups();
    status = 1;
  } finally {clearTimeout(cleanupDeadline);}
  if (emergency) {status = 1; result.watchdogUsed = true;}
  result.outcome = status === 0 ? 'passed-bounded-single-database-restore' : 'failed';
  await writeFile(join(output, 'results.json'), JSON.stringify(result, null, 2) + '\n');
}
process.exitCode = status;
