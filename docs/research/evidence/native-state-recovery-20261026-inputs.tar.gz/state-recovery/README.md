# State-recovery disposable research fixture

Prepared2026-10-26. Zero production or product-integration code. Read the approved/revised campaign plan and critic dispositions before execution. This directory is the portable archive root; include source, `fixture/`, exact manifest/lock/workspace/tsconfig files and `planning/`. Exclude `node_modules/` and generated `out/`.

## Current gates

- SR1's own source, unchanged copied feature and pg declarations pass strict TS7.0.2 with skipLibCheck:false.
- **SR2 is blocked and must not be emitted or executed.** Exact accepted pre-GA drizzle-orm1.0.0-rc.4 produces47 shipped-declaration diagnostics under the same strict profile. Its source and failure logs are retained; no vendor edits, suppression or dependency repin is authorized.
- No local cluster has run: the unchanged1GiB available-space guard cannot be met. Root is preparing an isolated least-permission Ubuntu24.04 CI job for SR1 only.

## SR1 invocation

The CI job stages exact Node26.11.1/pnpm11.18.0 and the declared frozen dependencies with scripts disabled, plus qualified native PostgreSQL18.4 server and separately identified18.4 client helpers. It provides an ordinary unprivileged user and a private writable native workspace with at least1GiB available. Native data must not use a shared service/cluster.

Set these exact environment variables:

| Variable | Meaning |
| --- | --- |
| `STATE_RECOVERY_POSTGRES_BIN` | Absolute directory containing actual postgres/initdb/pg_ctl18.4; original research server payload preferred and supplier retained. |
| `STATE_RECOVERY_HELPER_BIN` | Absolute directory containing externally sourced pg_dump/pg_restore/pg_dumpall/psql18.4; native library resolution must be recorded. |
| `STATE_RECOVERY_TEMP_BASE` | Short, private, writable native workspace root; minimum1GiB available enforced before each initdb. |
| `STATE_RECOVERY_OUTPUT` | Absolute retained evidence directory for this SR1 invocation. |
| `STATE_RECOVERY_PROVENANCE_JSON` | Existing JSON with exact download URLs, package/archive expected and measured hashes/integrities, supplier/version, native library resolution, OS/runtime identity. |
| `STATE_RECOVERY_PG17_DUMP` | Optional existing pg_dump17 path for the rejecting major-version control; no PG17 install is required. |

Run `bash run-ci.sh` from this directory. It installs frozen/ignore-scripts, performs an SR1-only strict typecheck/build and invokes `node out/sr1.js`. Any failed gate stops; no bypass path exists. Root's reviewed job has contents:read only, no secrets, exact action pins, a15-minute job cap,120-second acquisition cap,240-second external native cap and always-upload of output/failed logs. The driver's180-second observation and15-second cleanup watchdogs remain unchanged. Outer termination is failed/unproved cleanup; a shell timeout is not exit proof.

The native driver owns private Unix-socket clusters and exact detached postmaster/helper groups. Normal cleanup closes pools, fast-stops postmasters, checks status3 and actual PID absence, then removes only its owned data roots. Watchdog use is a failure, not successful graceful drain. Preserve outputs on any failure.

## Native supplier distinction

SR1 qualifies one actual engine/helper pairing. It does not assert that embedded-postgres ships helpers, certify a production wrapper pin, test power loss/PITR or establish a whole-product recovery point. Prefer the prior exact embedded-postgres Linux18.4 payload for the server and separately sourced PGDG noble18.4 clients/libpq. A different supplier must be explicit in provenance/results, never labeled the original payload rerun.

Relevant external client assets are the official PGDG `postgresql-client-18_18.4-1.pgdg24.04+1_amd64.deb` and `libpq5_18.4-1.pgdg24.04+1_amd64.deb`. Their paths/source index URLs are in the plan. Hash locally downloaded bytes and bind them to upstream metadata where available; a self-recorded SHA alone is not signature verification.

## Evidence already retained

`planning/` includes the unmodified V1 plan, exact upstream Drizzle release-source snapshots, registry dist metadata/lock integrity, six exact installed source-map bindings, unchanged feature source-copy hashes, failed default-sandbox registry retrieval and install/typecheck logs. Source-map equality is not an independently rebuilt package or an upstream signature claim. SR1 RLS assertions use the actual restored runtime role and direct SQL; API validation is not substituted for database policy enforcement.
