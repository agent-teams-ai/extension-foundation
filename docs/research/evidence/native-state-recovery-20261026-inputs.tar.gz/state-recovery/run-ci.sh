#!/usr/bin/env bash
set -euo pipefail

# Run from the archive root. Dependency/native staging and provenance belong to the CI job.
# SR2 is intentionally blocked by its red exact-RC4 strict declaration gate.
: "${STATE_RECOVERY_POSTGRES_BIN:?explicit PostgreSQL18.4 server directory required}"
: "${STATE_RECOVERY_HELPER_BIN:?explicit separately sourced PostgreSQL18.4 client directory required}"
: "${STATE_RECOVERY_TEMP_BASE:?explicit private native workspace required}"
: "${STATE_RECOVERY_OUTPUT:?explicit retained SR1 evidence directory required}"
: "${STATE_RECOVERY_PROVENANCE_JSON:?exact downloaded artifact/native dependency provenance required}"
mkdir -p "$STATE_RECOVERY_OUTPUT"
node --version > "$STATE_RECOVERY_OUTPUT/node-version.txt"
pnpm --version > "$STATE_RECOVERY_OUTPUT/pnpm-version.txt"
test "$(node --version)" = v26.11.1
test "$(pnpm --version)" = 11.18.0
test "$(id -u)" != 0
pnpm install --frozen-lockfile --ignore-scripts > "$STATE_RECOVERY_OUTPUT/frozen-install.log" 2>&1
node_modules/.bin/tsc --version > "$STATE_RECOVERY_OUTPUT/compiler-version.txt"
node_modules/.bin/tsc -p tsconfig.sr1.json --noEmit --pretty false > "$STATE_RECOVERY_OUTPUT/typecheck.log" 2>&1
node_modules/.bin/tsc -p tsconfig.sr1.json --pretty false > "$STATE_RECOVERY_OUTPUT/build.log" 2>&1
# External job containment/timeout must survive this shell and retain exact owned group cleanup.
node out/sr1.js > "$STATE_RECOVERY_OUTPUT/driver.log" 2>&1
