# Exact native state recovery research inputs

Prepared 2026-10-26 for the bounded SR1-only GitHub Actions experiment. No native execution pass is claimed in this input snapshot. Read review/owner-context.md, review/state-recovery-plan.md and all pre-run critiques. Final strict SR1 build passed and root independently verified every final source-manifest member. The separately prepared SR2 remains blocked by 47 exact RC4 vendor declaration diagnostics; do not emit or run it around that gate.

Verify SHA256SUMS from this archive root. Bootstrap verifies the retained PGDG signature, compressed index and exact tuple binding before fetching package bytes, and verifies the original18.4 server package SRI. Server payload and external helper provenance remain distinct. No installed binaries/dependencies/physical DB roots are embedded.

review/workflow.yml is the exact reviewed workflow snapshot; bootstrap-native.sh and state-recovery/run-ci.sh are its executed entry scripts. Root publishes the workflow separately on the existing draft branch only. Restore uses actual source-stop/distinct-target readback, exact values/outbox, restored non-superuser RLS and independent failed-restore/privilege controls. No production distribution/admission or whole-product backup is qualified.

Outer timeout124/137 means failed execution and cleanup unproved. The runner's job containment is last resort, not a positive custody observation. The tiny synthetic logical feature.dump/globals/TOC and failed logs are retained in the resulting artifact; physical data roots are excluded.
