# State-track review of native SR1 CI preparation

Date:2026-10-26. **Disposition: GO for publication/materialization of the reviewed SR1-only workflow, subject to root's final input-tar/SHA verification. No remaining script blocker in the reviewed revision.** This is read-only source/data inspection; I did not download native assets, execute bootstrap/workflow, start a cluster or claim a restore result.

Reviewed identities:

- `plans/native-state-recovery-workflow.yml`: SHA256 `6d7bb78f6d771917c9b302d2a6374b2e9e3caa3a943d5c945a193e7c627c21b8`.
- `plans/bootstrap-native.sh`: SHA256 `7913af0fc912388a39d52a4f10d5d1950981c60dc197a1835ca114a91c0d1d51`.
- Current exact source/lock/runner contract in `experiments/state-recovery/`, particularly `run-ci.sh`, `tsconfig.sr1.json`, final reviewed driver/oracles/native fixture and `planning/final-sr1-source-manifest.json`.
- Existing retained PGDG InRelease/Packages/selected records, npm server-registry identity and package-linked symlink reader/hydrator source at npm gitHead `8c8c16d1b81bec8ae3315d59a050654086a85e23`.

## Concrete gates inspected

| Concern | Disposition |
| --- | --- |
| Least permission | Fixed repository/branch/path trigger, contents:read, no secrets, no pull_request_target, checkout credentials not persisted. Actions use exact repository/official pins. No write permission is needed for the experiment. |
| Budgets | Root's revised15-minute job/120-second acquisition/240-second external invocation provide staging margin without changing the driver's180-second observation,15-second cleanup watchdog or SQL limits. Setup/native/upload steps are separately capped. |
| Entry/environment | Archive root `state-recovery/` supplies `bash run-ci.sh`; its SR1-only strict check/build invokes `node out/sr1.js`. Bootstrap writes every required STATE_RECOVERY_* variable and LD_LIBRARY_PATH to GITHUB_ENV. SR2 remains blocked and has no execution path. |
| User/storage | Workflow and driver require nonroot UID. Driver enforces the unchanged1GiB available-space guard before each initdb and uses task-owned private roots/Unix sockets. This does not reuse a local17.10 candidate. |
| Signed client selection | gpgv checks retained InRelease; its exact SHA256/size entry binds retained Packages.bz2. Runtime extraction compares both selected package tuples—Package, Version, Architecture, Filename, Size, SHA256—with that verified index and requires exactly2 rows. Each downloaded deb then matches the signed-index-bound SHA. This closes the earlier unsigned-selected-JSON gap. |
| Server supplier | Exact `@embedded-postgres/linux-x64@18.4.0-beta.17` registry/tarball and pinned sha512 SRI are distinct from external PGDG clients. Extracted package version is checked; driver requires actual SQL PostgreSQL18.4 and helper18.4 versions. No npm hook or local17 binary is substituted. |
| Native libraries | Actual ldd output is retained per executable, missing libraries reject, and every reported libpq resolves to the selected PGDG directory. Actual file/source hashes retain the combined pairing rather than claiming the wrapper ships helpers. |
| Logical archive retention | Updated always-upload includes the tiny synthetic `feature.dump`, globals, logs and readbacks. Physical DB data remain outside evidence/upload. This closes the earlier `.dump` exclusion mismatch with SR1's retention contract. |

## pg-symlinks provenance and field interpretation

The package-linked reader records **source as the real target bytes** and **target as the alias pathname**. The retained hydrator creates that alias pointing at the source. Bootstrap's owned overlay reproduces that direction without modifying package bytes or executing its hook. Actual `native/pg-symlinks.json` comes from the SRI-verified18.4 npm tarball and is copied into evidence; source-code format knowledge does not replace that actual payload receipt. Array/string/path checks fail closed. A valid empty array no longer fails merely because jq emitted no records.

This is a specific research setup for the selected payload, not full hook/Supervisor/distribution qualification. If the actual18.4 list contains a path outside the declared library-alias shape or dependencies fail to resolve, retain the bootstrap failure; do not edit aliases or accept another supplier without a reviewed disposition.

## Final materialization check still owed by root

No actual final input tar/SHA was present when I reviewed these scripts. Before publication, verify the produced archive—not just its recipe—against this layout:

- `bootstrap-native.sh` equals the reviewed script.
- `state-recovery/` contains the exact manifest/lock/workspace, configs, SR1 source, unchanged feature copies, runner, README and retained planning/gate evidence. Exclude node_modules/out and all native data roots. The blocked SR2 source may be retained as evidence, never compiled/executed through this entry.
- `provenance/` contains the retained signed index/key/selected records used by bootstrap. Package JSON fields/SRI must remain the reviewed18.4 values.
- The repository SHA file names the actual tar path used by `sha256sum -c` from repository root; tar members resolve beneath NATIVE_ROOT with the expected three top-level entries.
- Match source bytes against `planning/final-sr1-source-manifest.json`; final SR1 strict build passed after independent critic GO. README was aligned to the reviewed15-minute CI budget afterward; no TS source changed after that build.

These are a final input-integrity review, not another native test or a request for new architecture.

## Outcome/cleanup interpretation

Outer timeout can terminate the JavaScript owner before finally and its detached native groups have proved exit. The workflow now labels124/137 as **failed outer termination / cleanup unproved**, which is the truthful result; isolated ephemeral job containment does not become a successful graceful-stop/PID-absence receipt. Normal driver success still requires actual exit/status3/PID absence and removal of every immediately registered root. Initializer-created roots that fail before return now remain explicit debt, so the final cleanup flag cannot falsely become true merely because source/target variables stayed undefined.

Always-upload is best effort under the job's enclosing timeout/cancellation. If the job itself is terminated before evidence can upload, report missing/unqualified evidence; do not invent a pass. This limitation does not require another supervisor or a broader failure matrix for the selected isolated SR1 run.

The earlier acquisition/selected-JSON/archive-retention concerns were sent directly to the CI owner and are closed in the reviewed revision. Final input bundle verification is the only remaining prepublication condition. Native success/failure remains to be observed after root launches the job.
