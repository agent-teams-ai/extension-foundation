# Isolated native research CI — workflow and prepublication review

Date: 2026-10-26 UTC. **Prepared/reviewed only; this agent did not publish or run
the workflow, download native binaries, install dependencies or start a database.**
Root owns packaging the final reviewed inputs, repository changes, push and hosted
execution. No production package/runtime or deployment authority follows.

## Disposition

The candidate is an isolated **SR1-only** research job. Revised SR2 remains blocked
by the actual exact-Drizzle-RC4 strict declaration gate; neither this workflow nor
the portable runner emits/runs SR2, skips vendor checking, changes dependencies,
or repairs the fixture to bypass that result.

Root's later infrastructure review changed the original desired10-minute job to
**15 minutes**, with120s bootstrap inside a3-minute step,240s external native run
inside a5-minute step, and a2-minute always-upload step. This is a reviewed
pre-execution acquisition/log budget. The existing driver180s, native command30s,
SQL/deadline assertions, unprivileged UID and **1GiB available-block guard remain
unchanged**. A source-only UID0 exception used by other tracks does not satisfy
the PostgreSQL guard.

The workflow is71 lines and bootstrap62 lines,133 combined. It reuses the
repository's exact existing checkout/pnpm/setup-node action pins, exact Node26.11.1
and pnpm11.18.0, and the state fixture's frozen TS7.0.2 dependency profile. The
portable `run-ci.sh` supplies the actual strict SR1 typecheck/build and invocation.

## Candidate files and publication layout

- Candidate `plans/native-state-recovery-workflow.yml` publishes as
  `.github/workflows/native-state-recovery-research.yml`.
- Candidate `plans/bootstrap-native.sh` is packaged inside the input archive,
  rather than becoming an unrelated standalone CI system.
- Root creates `docs/research/evidence/native-state-recovery-20261026-inputs.tar.gz`
  and its `.sha256` sidecar. The checksum entry must use the archive's full
  repository-relative path because verification runs from repository root.

Required archive members:

```text
bootstrap-native.sh
provenance/ACCC4CF8.asc
provenance/pgdg.gpg
provenance/InRelease
provenance/Packages.bz2
provenance/selected18.4-records.json
state-recovery/package.json
state-recovery/pnpm-lock.yaml
state-recovery/pnpm-workspace.yaml
state-recovery/tsconfig.json
state-recovery/tsconfig.sr1.json
state-recovery/run-ci.sh
state-recovery/native-fixture.ts
state-recovery/sr1.ts
state-recovery/sr1-oracles.ts
state-recovery/fixture/agent-context/**
state-recovery/planning/**
```

Preserve SR2's blocked source/gate evidence if included for research provenance,
but never add an SR2 runtime path. Exclude `node_modules`, emitted `out`, native
binaries and physical database roots. Root is coordinating the final state-owner
snapshot after the actual RLS-versus-ACL42501 oracle refinement. The input archive
must bind that final source, not an earlier preparatory copy.

## Native provenance: signed binding is available

Authoritative metadata was retrieved from official endpoints, totalling about
1.1MiB, under root's≤5MiB metadata authorization. Default sandbox networking failed
with an unreachable proxy; approved read-only network escalation succeeded.
No helper/server package binary was downloaded locally.

The retained `plans/native-tooling-provenance/` includes:

- Official PGDG key from `https://www.postgresql.org/media/keys/ACCC4CF8.asc`.
- Official `https://apt.postgresql.org/pub/repos/apt/dists/noble-pgdg/InRelease`,
  dated2026-10-26 20:14:48 UTC. `gpgv` reports a good PostgreSQL Debian Repository
  signature under fingerprint `B97B0AFCAA1A47F044F244A07FCC7D46ACCC4CF8`.
- The signed entry for `main/binary-amd64/Packages.bz2`, size904666,
  SHA256 `c7b59a75901101e020a1ba2838afe3e461acad104d8c4b3b5a7c22e341f965ec`.
- Actual compressed index and independently extracted exact18.4 package records.

The bootstrap verifies the retained signature and index digest, extracts the
six relevant fields directly from that authenticated compressed index, and
compares the two complete tuples with selected JSON **before fetching packages**.
Thus the JSON is not merely an asserted independent checksum binding.

| Exact package | Size | SHA256 from signed index |
| --- | ---: | --- |
| `libpq5_18.4-1.pgdg24.04+1_amd64.deb` |256172|`632e63bd7e66c3a5a1b539f77dbc76a823f63b9d99fb2ac67bb334c84e4b8a17`|
| `postgresql-client-18_18.4-1.pgdg24.04+1_amd64.deb` |2095260|`ff3fb9af478e4bdada47168681d9987917fd3170b043c612d6d01f0c923469c2`|

Both are fetched from the official PGDG pool and SHA-checked before `dpkg-deb -x`
into an owned directory; no system apt install, sudo or maintainer scripts run.
Actual package control data, native version output, per-executable `ldd` output,
selected libpq path and native file/source hashes are retained. Every executable
that links `libpq.so.5` must resolve it from the extracted selected libpq directory,
not a system major/version. Missing native dependencies fail bootstrap.

The server is the exact original
`@embedded-postgres/linux-x64@18.4.0-beta.17` registry tarball, verified against
the frozen historical SRI
`sha512-jVw/MdDtIX/vICH/DKIe6/mHpiCggdx6QVyza4vt/NbcZFsL0KhwglF6F1Koqx3gRBZ9XtN+vi63EsqSyqOSxA==`.
Actual official registry metadata was retrieved and retained; its gitHead is
`8c8c16d1b81bec8ae3315d59a050654086a85e23`, unpacked size59216961, file count1029.
The discovered local path cited during early planning was actually17.10.0; it is
not used. The job fetches and verifies the18.4 payload directly.

No package hook runs. Exact18.4-linked primary source was checked:

- `packages/linux-x64/scripts/hydrate-symlinks.js`, Git blob
  `32aa2c32b3395157fa027a1699856ac274a415c5`, SHA256
  `3596fdda55321a3672bd77bcaecf00d46462914409346ccfa1932a19c5977e11`.
- `packages/symlink-reader/src/index.ts`, Git blob
  `be9334654b59c4b61ef06a8ba1f44d0fbfc4f390`, SHA256
  `d7e39193be67d5643f69ed3b7a30fa33561d9879a4b37f773370c8a3b08c3f2e`.

The generator defines source as the real file and target as the alias, with
paths relative to package root. Both retrieved Git blob identities were
independently recomputed. The bootstrap reads and retains the **actual verified
18.4 payload's** manifest, validates its array/string shape (including valid empty
array), and creates declared direct-library aliases only in a separate owned
overlay. It does not edit package bytes. A broader/nonlibrary alias shape fails
closed; actual native layout is runtime evidence, not inferred from the earlier17
payload. Raw manifest and ldd logs make that outcome reviewable.

This is a bounded research provenance check, not release signing, package
attestation verification or a qualified distribution pipeline.

## Action pin verification and least privilege

The [official upload-artifact v7.0.2 release](https://github.com/actions/upload-artifact/releases/tag/v7.0.2)
links to [commit cf430e030ddbb5b0abf93d22962f4752f3646cd9](https://github.com/actions/upload-artifact/commit/cf430e030ddbb5b0abf93d22962f4752f3646cd9).
The official immutable `action.yml` was retrieved and retained; it confirms
`runs.using:node24` and the exact path/exclusions, retention, compression and
missing-file inputs used. Actions' own Node24 execution differs from the
experiment's exact setup-node26.11.1 runtime; that is explicit.

The job has `contents:read` only; other GitHub token permissions are omitted.
It has no secrets inputs, credential persistence, pull_request_target, PR comment,
status write, deployment, id-token or workflow mutation. It triggers only on push
to the exact existing draft branch and changes to this workflow or its input
archive/checksum family, with an owning-repository condition. No workflow_dispatch
or broad PR trigger is added. No fixture, dependency or policy edit is made by CI.

`if:always()` staging creates identity/disk/status evidence even after an earlier
setup action fails, then refuses acquisition if prior status was not success.
The artifact action always runs and fails if no retained files exist. Its path
is an explicit evidence directory outside physical cluster roots. Root clarified
that the tiny synthetic logical `feature.dump`, failed optional PG17 dump if any,
globals SQL and TOC/hashes **must remain retained**; physical cluster/data roots
remain excluded. There are no real user databases or credentials.

## Independent risk/falsifier review

| Risk | Concrete rejection or claim limit |
| --- | --- |
| Archive/source drift | Reviewed checksum fails before extraction; root must check exact final fixture members and preserve source/lock identity. |
| Invalid PGDG provenance or wrong selected JSON | Signature, authenticated index hash, direct tuple extraction and `cmp` fail before native acquisition. |
| Wrong server bytes or changed npm metadata | Frozen expected SRI is checked against metadata and actual tarball before extraction/native invocation. |
| Wrong native helper/library | Signed package SHA, exact runtime18.4 assertions, each ldd libpq resolution and missing-library checks reject. No17/18.6 fallback. |
| Insufficient writable space/root execution | Actual unprivileged UID and unchanged statfs1GiB guard fail; no current-user or PostgreSQL exception is substituted. |
| SR2 declaration failure | No emission/runtime path; strict SR1 subset only. Vendor gate remains red, not skipped or weakened. |
| Host driver blocks beyond same-loop timer | Independent shell `timeout` is the outer observation bound. Exit124/137 is explicitly failed with cleanup unproved. |
| Detached postmaster survives outer timeout | Parent timeout does not prove descendant cleanup. No broad process kill is added; classify failed/unproved and rely on disposable hosted-job containment as last resort. Only a positive driver result proves its own pg_ctl status3, actual exit and ESRCH checks. |
| Upload lost at job deadline |15-minute job versus at most1+1+1+3+5 minutes of prior step caps leaves4 minutes; upload is separately bounded2 minutes. Infrastructure scheduling/cancellation still cannot guarantee artifact retention. |
| Overclaim from logical restore | One exact fixture/database/engine/helper profile only; no physical backup, power-loss, coherent product snapshot, supply-chain release or production integration claim. |

Checks actually performed before publication: `bash -n` on bootstrap; YAML syntax
load and structural assertions for exact branch, contents-read permission,
15-minute job and absence of secret/pull_request_target/sudo/skipLibCheck strings;
official action descriptor review; PGDG signature/index/record validation;
exact18.4 source/blob review. These are **not** a hosted CI success or a native
restore result. Root's hosted run and retained exit/results will determine that.

The tiny awaited-async refinement plan was also reviewed separately for its owner:
one actual retained `await initialize()`, same-process release-to-ready positive,
message-order/marker oracle and normal exit. That does not expand this native job.
