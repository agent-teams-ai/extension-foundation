# Independent native restore pre-run criticism

Review date: 2026-10-26. Reviewer: independent native-restore critic. This is source review before the first native SR1 CI execution. No test, cluster, native executable, package download, install or product-source mutation was performed by this reviewer. Official PostgreSQL18 documentation was retrieved read-only to check the error-code/security distinction.

## Disposition

**GO for the first bounded SR1 native CI execution, conditional on the track owner's final unchanged strict SR1 check/build and root's final reviewed-input archive/checksum verification.** All three concrete findings below were corrected during review and are closed by source inspection. This disposition does not authorize SR2: its exact Drizzle RC4 strict gate remains red, and SR2 must not be emitted or run.

The selected SR1 question remains valuable and sufficiently small: whether the exact embedded-postgres native 18.4 payload, with separately sourced signed-index-bound PGDG 18.4 client/libpq packages, can restore the unchanged historical Agent Context feature into a genuinely different cluster after the source has stopped. No additional database, operating-system, migration-library or Temporal matrix is requested.

## Concrete must-fix findings and dispositions

### NR1 — SQLSTATE42501 alone could misclassify an ACL failure as an RLS WITH CHECK failure

**Initial source fact:** `sr1-oracles.ts` used one `rejectedSql()` function that accepted only SQLSTATE42501 for four foreign-tenant INSERT/UPDATE attempts and the runtime DDL denial. The initial oracle did not check effective INSERT/UPDATE permissions or the actual error message. Own-tenant SELECT succeeded, but there was no successful UPDATE control. Source-to-target grant equality alone could preserve the same missing UPDATE grant.

**Consequence/inference:** a role lacking UPDATE permission could satisfy the foreign-tenant UPDATE rejection without PostgreSQL evaluating the intended WITH CHECK policy. That would make part of a green RLS claim unsupported. PostgreSQL's version18 documentation identifies42501 as `insufficient_privilege`; row security operates in addition to ordinary object privileges. Primary references: [error codes](https://www.postgresql.org/docs/18/errcodes-appendix.html) and [row security](https://www.postgresql.org/docs/18/ddl-rowsecurity.html), retrieved2026-10-26. These current version18 pages inform interpretation; they are not evidence of an executed18.4 result.

**Correction inspected:** `runtimeEnforcement()` now separately requires effective INSERT and UPDATE privilege on both manifests and outbox with four individual `has_table_privilege()` checks. Each foreign DML rejection requires42501 **and** an actual row-security-policy diagnostic. DDL requires the separate permission-denied diagnostic. Actual codes/messages/kinds are retained in the returned result. Existing direct unqualified SELECT checks, owner readback after rollback, unchanged migration, source/target catalog comparison and public feature INSERTs remain supporting evidence.

**Disposition:** closed by source inspection. Matching the fixed-version, no-locale fixture's server diagnostic is a deliberately narrow research oracle, not a proposed public error-classification contract. No new positive DML matrix is needed for this selected run.

### NR2 — The workflow discarded the exact logical archive required by the retention contract

**Initial source fact:** the upload step excluded every `**/*.dump`. That included SR1's positive `feature.dump`, despite the plan requiring exact archive retention and the archive being small synthetic fixture data. Hashes, TOC and logs would remain, but the restore input bytes would disappear with the runner.

**Correction inspected:** the workflow upload now includes the complete evidence directory, explicitly retains the synthetic logical archive, and excludes only physical database data directories. `globals.sql`, the archive, TOC, command logs and failed-control output therefore fall within the upload path.

**Disposition:** closed by source inspection. Root still owns the final reviewed input archive/checksum and publication. Artifact upload success and the retained bytes must be checked after the actual CI run; this review does not claim they already exist.

### NR3 — Initializer failure could report cleanup complete while leaving an owned cluster root

**Source fact at initial review:** `ownedCluster()` calls `mkdtemp()` before initialization completes. The caller assigns `source`/`target` only after the entire initializer returns. Its error handler writes the server log, attempts an exact owned group kill, awaits the child when available and closes pools, but does not remove the owned root or return/register it for outer cleanup. If initialization throws before returning, `sr1.ts` sees an undefined cluster and can set `clustersStoppedAndOwnedRootsRemoved=true` after cleaning only the clusters it knows about.

**Consequence/inference:** the run still fails overall, but its cleanup-complete field can be false. An initdb error can leave a root without any postmaster, while a startup/identity error can leave a root whose absence was never proved. This is a concrete false cleanup claim, not a request for general descendant/process custody.

**Smallest correction:** keep an explicit record of initializer-created roots and mark cleanup debt until exact owned cleanup is proved, or make the initializer's error path prove its owned postmaster stopped and remove its exact root. A failed or interrupted proof must remain cleanup-unproved. Preserve the original startup error and root identity rather than replacing it with cleanup success.

**Correction inspected:** `nativeRoots` now registers each root immediately after `mkdtemp()`, before socket creation. Initialization failure leaves the root recorded with `removed:false` and explicit retained-root debt, preserves the original error, and does not substitute a cleanup-success claim. On the returned-cluster path, `remove()` requires the stop proof and sets `removed:true` only after the actual owned-root removal succeeds. SR1's final cleanup field derives from every registered root, including any initializer that never returned. The registry itself is included in retained results.

**Disposition:** closed by source inspection. Retaining explicit failed cleanup debt is sufficient for this narrow experiment; a broader startup repair subsystem or fault-injection suite is not requested. The track owner and root were notified directly before execution.

## Selected source boundaries reviewed

The following observations explain why no broader alternative is requested. They are inspected source facts, not newly executed results.

| Selected uncertainty | Source observation and exact limit |
| --- | --- |
| Different cluster and source unavailable | Source fast-stop awaits its actual postmaster exit, requires `pg_ctl status`3 and exact PID absence before creating target. Target gets a fresh root/socket and must report a different `pg_control_system()` system identifier and its own exact `data_directory`. Every restore/readback connection uses the target socket. This is finite owned-postmaster evidence, not a generic custody proof. |
| Restored runtime is not privileged owner/bootstrap | Runtime SQL asserts session/current user `test_runtime`, NOSUPERUSER, NOBYPASSRLS, NOINHERIT and no memberships. Catalog checks require restored table ownership by the separate source-owner role and forced/enabled RLS. |
| RLS cannot be only an application predicate | Runtime SELECTs both tables without tenant predicates and requires the literal B row/event while A is absent. The four rejected foreign DML commands and the NR1 correction cover WITH CHECK separately. The trusted `app.tenant_id` context assumption remains explicit. |
| Archive/globals and schema authority | Source takes an unfiltered custom archive plus globals. Mandatory missing-role restore must fail transactionally and leave no feature namespace/tables. Target then applies retained globals and the same archive; it calls no feature migration, GRANT or policy repair. The archive is rehashed after restore. There is no code that rewrites globals. |
| Actual feature/outbox and precision | Seeding/reading/retrying uses the unchanged product feature. Independent SQL requires the literal negative one-microsecond instant and literal string-valued facts/outbox identities. Two duplicate seeds must leave the complete snapshot unchanged; one new seed must add exactly one expected manifest/outbox pair. The scope is one real historical feature, not fresh-main product or whole-product restore. |
| Correct native suppliers | Bootstrap binds the embedded server tarball to its exact recorded SRI and independently verifies PGDG InRelease, index hash, selected package fields and downloaded package hashes. Explicit executable paths and actual helper versions are checked; target/source SQL checks actual server18.4. Resolved libpq is recorded from the extracted18.4 client package. Loader output/native hashes are retained. This does not qualify signing/offline distribution or imply the embedded package ships the external helpers. |
| Strict source boundary | `run-ci.sh` performs frozen ignore-scripts installation and SR1-only strict noEmit/build gates. The SR1 config overrides the combined include list and imports no Drizzle. `skipLibCheck:false`, exact optional checking and `noEmitOnError:true` remain intact. No SR2 command occurs. |
| Deadline versus cleanup | Driver watchdog use forces failure. External124/137 is explicitly failed/cleanup-unproved; isolated job containment is the final fallback. Neither timeout nor runner teardown is promoted to complete cleanup. NR3's correction closes the startup-path false cleanup field. |

## Final reviewed source identities

Hashes were read after all three corrections were present. They identify the inspected bytes, not a build or runtime result. Root must regenerate and verify the publication input bundle from these final files.

| File | SHA256 |
| --- | --- |
| `experiments/state-recovery/sr1.ts` | `6662ffcd07cd69661e34f296e117238a8d59578ba07219c0a01173c141354729` |
| `experiments/state-recovery/sr1-oracles.ts` | `553a8a76e73f77d392b7d1a19ca371b7bec3f788c798b18f1ae9c39889ff5986` |
| `experiments/state-recovery/native-fixture.ts` | `2795e6dae5bdf97953347f8e7132dc67c228dbc297346779b2610512b1987b0f` |
| `experiments/state-recovery/run-ci.sh` | `7fb89f2e5c2b337e95c8576f260adcad55ea5ff711a22bf43eead043e5645f46` |
| `experiments/state-recovery/tsconfig.sr1.json` | `f3a2705d1c55b23efdcfcd29de98b57ee615d0c3517d01009b08e1cb11e47ce5` |
| `plans/native-state-recovery-workflow.yml` | `6d7bb78f6d771917c9b302d2a6374b2e9e3caa3a943d5c945a193e7c627c21b8` |
| `plans/bootstrap-native.sh` | `7913af0fc912388a39d52a4f10d5d1950981c60dc197a1835ca114a91c0d1d51` |

## Size, confidence and stop rule

Recommended course: keep the existing exact native restore experiment and apply only the three corrections above. Estimated new production code:0LOC. Product integration:0LOC. Disposable fixture/oracle changes for NR1/NR3: approximately25–70LOC total; workflow retention change: approximately1–3LOC. These are pre-fix estimates with approximately×2 uncertainty, not a request to build an abstraction or new supervisor. No alternative library, native component or language is justified by these findings.

Engineering judgments, scoped to this single restore experiment: confidence in the review8/10; achievable reliability of the corrected experiment's narrow evidence8/10; complexity3/10, where higher complexity means greater maintenance burden. These are not availability measurements or a production qualification.

The corrected cleanup path and final source inspection are complete. Stop this review after handing the findings and identities to the track owner/root. The track owner retains its normal final strict SR1 gate, and root owns the first bounded CI run. After that run, assess its actual evidence against the existing plan; do not expand the scenario matrix merely to improve the review score.
