# State-recovery revision2: independent restart-track critique

Date: 2026-10-26. Review target: revised `plans/state-recovery.md` and its retained
Drizzle rc.4 primary-source snapshots. Status: **pre-execution source/plan review;
no state-recovery test, package install, native download or cluster was run.**

## Disposition

**Approve revised SR2's bounded experiment design after the small evidence
refinements below. Keep native SR1/SR2 execution blocked until root independently
satisfies their unchanged disk, exact dependency and native-tool prerequisites.**
SR1 source preparation can continue under the existing authorization.

Replacing the invented precision policy with the actual selected Drizzle
migrator materially improves decision value. The proposed race has a credible
source basis and a real SQL falsifier. The plan tests a named mature component
and a narrow existing-owner integration seam, rather than implementing a custom
migration state machine and proving it consistent with its own rules.

## Source facts independently inspected

I read all of revision2 and the relevant complete functions in
`experiments/state-recovery/planning/drizzle-rc4-primary-source.json`. That file
retains official `drizzle-team/drizzle-orm` source at
`748058e837d9c4247330e3d45580cbdae52bffda`, retrieved 2026-10-26. It is source
evidence, not installed-package or local execution evidence.

The retained `pg-core/async/session.ts` actually does metadata setup/upgrade,
reads the migration table, computes `migrationsToRun`, then opens the transaction
that executes the SQL and each migration's journal insertion. Its new migration
table has a serial primary key; the inspected definition does not make migration
`name` unique. `migrator.utils.ts` chooses pending rows by names in the earlier
read. `node-postgres/session.ts` uses the supplied Client for its transaction,
awaits BEGIN/body/COMMIT, and awaits ROLLBACK on a body error. Its Pool branch
would check out another client, which is why the plan's explicitly checked-out
physical Client requirement matters.

**Inference, not executed result:** after warm M0 setup, A and B can both select
M1 before either body commits. An advisory transaction lock inside M1 serializes
its SQL too late to refresh that selection. If both actually reach the held body
lock, subsequent duplicate counter/journal effects are a meaningful hypothesis;
if they do not, the planned race is unresolved rather than qualified. A session
lock on that same physical Client before public `migrate()` plausibly encloses
the vulnerable read. None of this establishes a product migration defect or a
promise that Drizzle advertises concurrent-startup serialization.

## Execution blockers: resolve these before the native run

### B1 — Actual admitted package and binaries, not only Git source

The experiment must execute actual public `drizzle-orm@1.0.0-rc.4` and the
declared pg client under the strict TS7 profile. Root must provide the exact
resolved package bytes/lock integrity and native PostgreSQL18.4/client payloads.
Confirm that the shipped migrator's relevant behavior agrees with the retained
rc.4 source before attributing a result to it. An official source tag is not a
tarball-to-source equivalence or a qualified runtime installation.

Compilation failure under `skipLibCheck:false`, unavailable exact package or
incompatible public API remains failed/unavailable evidence. Do not substitute
an older stable migrator, rc.5, a hand-written pending selector or relaxed
compiler flags. The plan already commits to this; it is a concrete execution
gate rather than a request to change the design or repin a product.

### B2 — The current native disk guard remains binding

The plan declares a 1GiB free-space guard and 350MiB owned reservation. Root's
small-source permission for the present nearly-full shared host does not satisfy
that native guard. Neither root UID access to reserved blocks nor a successful
tiny file write constitutes this qualification. Record actual guard readings
before each initdb and keep the native row unexecuted if they fail. A remote/CI
runner would still need the same source, provenance, disk and bounded cleanup
proof; this critique does not authorize one.

### B3 — Concretize the pre-timeout journal completion oracle

SR2-C appropriately places a real M1 journal insert before blocked M2 DDL. But a
query logger that fires **before** sending SQL is not evidence that the insert
completed. An independent connection also cannot simply read that uncommitted
journal row as if it were committed state. Do not implement either shortcut.

Specify the small actual observation before running: retain server statement
completion evidence associated with the migration backend PID/session, plus the
real later ALTER waiter and final rollback. One suitable bounded setting is
statement-duration logging for completed statements (`log_min_duration_statement=0`)
with PID/session identification and the SQL text/parameters needed to identify
M1's actual journal insertion. For extended protocol, distinguish Parse/Bind
from Execute completion. A narrow pass-through Client observer may corroborate
the completed original query promise; it must not replace results or create
success responses. No new migration ledger is needed.

The later independent committed read must prove counter0, absent partial table,
absent new column and only M0 journal rows. Together with completed M1 statements
and blocked M2 on the same transaction/backend, that is a meaningful rollback
oracle. Source sequence and a scheduled logger alone would be weaker evidence.

Official PostgreSQL18 logging documentation, checked 2026-10-26, describes
completed-statement duration logging and recommends PID/session correlation
when statement text and duration are emitted separately:
<https://www.postgresql.org/docs/18/runtime-config-logging.html>.

## Required small scope/oracle clarifications

### C1 — Bind both lock boundaries to the actual same physical sessions

The plan already requires exact PIDs, lock keys and blocker relations. Preserve
that in implementation: record `pg_backend_pid()` on each checked-out Client
and connect Drizzle to that same Client, not a Pool or a second checkout. In A,
both A/B must be actual waiters for the parent's body key after M1 is known
pending. In B, A owns the distinct session front lock while B is actually waiting
for it; A's body wait is a different observed lock boundary.

Use `pg_locks` granted/waiting rows and `pg_blocking_pids()` rather than inferring
the blocker from a sleep or a loose self-join. Capture the actual database,
classid/objid/objsubid representation of the declared keys. PostgreSQL18 documents
that advisory keys have those representations and recommends `pg_blocking_pids`
for the blocker relation:
<https://www.postgresql.org/docs/18/view-pg-locks.html>.

The 2s acquisition limits and 5s boundary poll cap must not lead a timed-out
acquisition to be reported as observed contention. Hold/release from named
server observations within the declared bound. If two true waiters were not
observed before timeout, retain an unresolved/failed setup and stop or correct
that setup once; do not call the desired race passed.

On all paths, release the parent's barrier, explicitly roll back a blocker
transaction and unlock/discard each migration Client. Require an actually usable
same Client after the planned rollback and no retained owner lock before moving
to the next group. The early wrapper must not hold a lock across plugin/provider
execution; this experiment only invokes the existing migrator and test SQL.

### C2 — Keep the claim warm-metadata and directional

A deliberately applies M0 so both runners see the current journal format.
That is the right small boundary: it avoids incidental cold metadata DDL
obscuring the pending-selection race. The result therefore qualifies concurrent
**pending work with existing current metadata**, not all concurrent cold
bootstrap/metadata-upgrade behavior. Do not add a cold-bootstrap matrix merely
to broaden the claim. The wrapper encloses the whole unchanged call, but that
fact is not independently executed qualification of every metadata upgrade.

If A serializes or rejects differently from the source hypothesis, retain the
actual outcome and investigate exact shipped source/SQL. If B's second public
call returns void, report void plus the independent no-body/journal evidence;
do not invent an already-applied receipt. An exclusive product migration
placement remains a separate product responsibility, not an assumption proved
by this disposable harness.

### C3 — Do not require rollback of serial sequence allocation

The rc.4 journal uses `SERIAL`. An aborted M1 journal insertion can consume a
sequence value even while its row, DDL and counter update roll back. Check exact
committed rows/name/hash multiplicity and business counter state, allowing ID
gaps. Do not reset the sequence to make an overly broad byte-for-byte rollback
assertion pass. PostgreSQL18 explicitly documents that nextval values are not
reclaimed on transaction abort:
<https://www.postgresql.org/docs/18/functions-sequence.html>.

This is an acceptable transactional limitation, not a failing rollback of the
selected data/DDL/journal-row postcondition. No extra sequence experiment is
needed.

## Native backup provenance: adequate plan, preserve these distinctions

SR1 now has a sufficiently strong bounded false-positive control: actual
transactional restore before source/runtime roles exist, nonzero native result,
independent feature-object absence, then globals + the identical archive into a
distinct target, without migrations/GRANT/policy repairs. Actual runtime-role
identity, predicate-free RLS reads, WITH CHECK rejections and usable subsequent
manifest/outbox writes are all necessary and already present in revision2.

The PGDG18.4 client packages are **external helpers**, even if they make restore
work with the measured embedded18.4 server. A positive cannot be described as
the embedded payload shipping backup/restore tools. Retain exact official URLs,
downloaded package hashes, package control metadata, dependency resolution,
executable versions/hashes and the source/target binary identities. Version text
alone does not prove which libpq was loaded. A local checksum proves retained
identity, not upstream signature provenance.

Historical signed index binding may be unavailable for this minor. The plan
already requires recording that limitation rather than asserting authenticity.
For a bounded research observation, official-source retrieval plus exact bytes
and an explicit missing-signature limitation is an acceptable limit; it is not
production distribution/signing qualification. Do not add a source-build fallback
or download extra versions just to improve that row during this campaign.

Quiescent single-database archive plus fixture globals is sufficient for SR1's
named reconstruction question. It does not restore production credentials,
cross-store recovery points, later writes, external effects or a Temporal
database. Actual source shutdown and distinct target system/data-directory
observations remain indispensable. The optional existing PG17 helper rejection
may stay omitted if unavailable; it is not a prerequisite for the stronger
mandatory missing-role control.

## What can proceed and what should stay deferred

| Item | Review disposition |
| --- | --- |
| SR1 small strict source preparation | Continue under existing root authorization. |
| Native SR1/SR2 execution | Blocked until root satisfies disk/native/dependency gates and approves the concrete execution environment. |
| SR2 A/C/D on actual rc.4 public migrate | Approve design after completed-statement oracle is specified and warm-metadata scope is retained. |
| SR2 B narrow same-Client wrapper | Conditional on actual A showing a missing serialization property; no wrapper if unnecessary. |
| Precision/backward-compatibility toy example | Correctly withdrawn; do not restore it as more coverage. |
| Cold bootstrap, process kill, high contention, full schema compatibility or native helper release | Deferred; no result-changing need within this selected campaign. |

No additional production code, package or migration framework is justified.
Estimated refinement cost is 10–40 fixture/observation LOC within the existing
driver, with x2 uncertainty; new production/integration code remains zero. These
recommendations are engineering inference from the actual source and PostgreSQL
documentation, not newly executed state-recovery findings.
