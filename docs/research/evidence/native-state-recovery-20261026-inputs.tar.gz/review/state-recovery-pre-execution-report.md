# State recovery: restore preparation and actual Drizzle readiness blocker

Observation date:2026-10-26. **SR1 source and strict gate are prepared; native CI is pending. SR2 is blocked by the exact dependency's strict declaration gate and was not emitted/executed.** This report separates locally executed package/typechecking observations, inspected source and proposed native scenarios. Zero production and zero product-integration code was added.

## Findings that change the next decision

The unavailable logical-restore capability now has a concrete fresh-cluster test using the unchanged real Agent Context feature. Its strict TS7 source/pg-declaration check passes. **No restore/native cluster has run in this campaign:** the local1GiB available-space gate cannot be met. Root is arranging isolated Ubuntu24.04 CI with that same guard and exact suppliers. A source/typecheck pass does not qualify restore.

Reusing the selected migration library instead of inventing a migrator exposed a real readiness blocker: **drizzle-orm1.0.0-rc.4 produces47 shipped-declaration diagnostics** under the owning strict TS7.0.2 profile with skipLibCheck:false and exactOptionalPropertyTypes:true. The final check has zero own-source diagnostics. Root requires that gate remain red and prohibits SR2 emission/runtime bypass, suppression, vendor patches or silent repinning.

Exact rc.4 source preserves a meaningful unexecuted concurrency question: pending migration names are selected before the transaction, without an early serialization lock in that selected path. That is source evidence, not an observed migration race. The original invented time-precision procedure was withdrawn because it mostly proved its own policy/arithmetic. The revised real-library contention/rollback design is retained for a qualified package/profile.

## Authority remains unchanged

The baseline is static composition and controlled restart, including downtime. Orchestrator ADR-0114/0115 select native PostgreSQL and Fully Local V1. Owner-accepted ADR-0116 selects native Temporal on **unmerged PR90**. This work does not merge that branch, reopen its engine choice, turn ordinary calls into workflows, or assign domain/schema/custody authority to EF/GM. No new Host, supervisor, scheduler, schema manager or effect ledger was built.

Current ADR-0052 explicitly pins the initial pre-GA Drizzle ORM/Kit baseline to1.0.0-rc.4 and calls for a compatible-GA readiness review when production persistence materializes. ADR-0114 retains adapter-local Drizzle while superseding the old SQLite engine premise. OD-003 retains dependency readiness. The RC was therefore installed exactly for research; a current stable/newer RC does not silently replace it.

## Executed local observations

| Surface | Actual result | Limit |
| --- | --- | --- |
| Reused product feature |12 `.ts` files copied unchanged from frozen Agent Context source `aaabc1e7cd2e2482668530e4412e61c2bca1f515`; per-file hashes retained. | Historical real boundary, not fresh-main/product E2E. |
| Tool/dependency profile |Node26.11.1, pnpm11.18.0, TS7.0.2, pg/@types/pg8.23.1, @types/node26.6.5. | Other tracks use shared Node types24.19.1; no byte-identical-toolchain claim. |
| Dependency preparation |Exact research lock resolved once, then frozen ignore-scripts installation passed. | No product dependency edit or native/postinstall script execution. |
| Disk footprint |Shared store grew31,268,864 bytes plus995,328 bytes of task node_modules directory/link allocation, approximately30.77MiB if all concurrent store growth belongs here. | Root accepted the0.77MiB overage; no shared-store deletion/vendor trimming or further package download work. |
| Installed Drizzle |Exact1.0.0-rc.4; integrity `sha512-BT+pf+qoiYHqltoA88Jmf6ilGMXPlpfE0hEJKc2adRtMCAl25Swk/t5gXcWxZNAwdtf3F5gCd2FpeOyP/pT0Hw==`. | Registry signature/attestation metadata retained, not independently verified; gitHead absent from npm-view output. |
| Source binding |Six installed source-map originals exactly equal inspected release source `748058e837d9c4247330e3d45580cbdae52bffda`; emitted JS hashes retained. | Not an independently rebuilt package or signature audit. |
| SR1 strict gate |Initial and final SR1-only noEmit checks passed. Final config has noEmitOnError:true. | No native/source/helper execution. |
| SR2 strict gate |Final combined noEmit check:47 vendor-only diagnostics, zero own-source diagnostics. | Red; no SR2 emission/runtime. |

Raw source, lock, registry metadata, installation/typechecking logs, source bindings and diagnostic summary are under `experiments/state-recovery/planning/`. New runtime source is ordinary strict `.ts`. No `.mjs/.mts` shortcut, declaration suppression or compiler weakening was introduced.

### Final dependency diagnostic categories

| Code | Count | Observed category |
| --- | ---: | --- |
| TS2339 |33|Builder declarations refer to missing `config` properties. |
| TS2344 |5|Generic constraints include keys outside the declaration's allowed members. |
| TS2420 |3|Interface implementations fail, including policy exact-optional behavior and SQLWrapper membership. |
| TS2559 |2|PG/Cockroach role classes have no common properties with their config interfaces. |
| TS2636 |4|Column-builder variance annotations are inconsistent under the selected compiler. |
| **Total** |**47**|All final errors originate in shipped dependency declarations. |

Attempt1 also contained8 own-source constructor errors: the driver initially used the older `drizzle(client)` spelling. Inspecting the actual rc.4 public signature corrected it to `drizzle({client})`; attempt2 has no own-source errors. Both attempts remain retained. This fixture correction is separate from the dependency's47 diagnostics. The noEmit-only logs precede the explicit noEmitOnError:true addition; all future emitted builds stop rather than leave partial output.

The result establishes a package/profile readiness failure, not a PostgreSQL defect, reproduced data-loss incident or failed native migrator scenario. A runtime success could not make these declarations pass, and no runtime result is claimed.

## SR1 prepared boundary and execution conditions

The driver seeds actual public feature commands, preserves literal exact values/outbox identities, takes an unfiltered custom archive and globals, physically stops the source, and restores the same archive into another cluster/system identifier. Mandatory missing-role restoration must fail transactionally with no partial feature schema. The target receives **no** feature.migrate(), GRANT or policy repair before verification.

The actual restored runtime connection must be NOSUPERUSER/NOBYPASSRLS and neither owner nor bootstrap. Direct SQL without application tenant predicates tests own visibility/foreign absence; foreign INSERT and tenant-changing UPDATE test WITH CHECK on manifests and outbox. Catalog RLS flags/policies/grants, exact negative microseconds, duplicate immutable seed and a new manifest/outbox transaction are independent checks. An API scope-validation rejection is explicitly additional, not the RLS oracle.

The optional PG17 control is ordered before source shutdown and never supplies the positive dump. Actual18.4 helper versions/native hashes and independent supplier provenance are required. Early existence-only inventory was not qualification: root's later inventory found a local17.10 candidate. CI must obtain the frozen18.4 supplier and identify it truthfully.

Independent pre-run criticism closed two concrete false-positive paths before source freeze. The four foreign DML probes now require the actual RLS-specific server message as well as42501, and four individual effective INSERT/UPDATE privilege checks must be true across both tables; DDL privilege denial is separate. Every native root is registered immediately after allocation, before initialization can fail; initializer failure retains its path/debt and original error, while removal is recorded only after stop proof and actual rm. Final cleanup derives from all registered roots, including an initializer that never returned. No extra native failure matrix was introduced. The final reviewed SR1 strict build passed; its22-input source/lock/config manifest is `planning/final-sr1-source-manifest.json`.

Portable archive root is `experiments/state-recovery/`, excluding `node_modules/` and `out/`. `bash run-ci.sh` performs frozen/ignore-scripts install, SR1-only strict check/build and `node out/sr1.js`. Its README lists exact environment/provenance inputs. Root's reviewed job retains contents:read only, no secrets, exact action pins, a15-minute job cap,120-second acquisition cap,240-second external native cap and always-upload. Driver180-second observations/15-second cleanup watchdog remain unchanged. It requires unprivileged UID, private Unix sockets, explicit paths and at least1GiB available before initdb. Normal cleanup fast-stops exact owned postmasters, observes exit/status3/PID absence, then removes owned roots; watchdog/outer termination fails qualification with cleanup unproved.

Prepared source does not establish successful restore, whole-product backup, PITR, signed/offline release, power-loss durability or generic process custody. A future pass with external PGDG helpers would qualify that exact pairing, **not** prove embedded-postgres ships helpers. Helper/engine packages and resolved native libraries must retain separate provenance.

## SR2 source inference and retained unexecuted design

The official [rc.4 node-postgres migrator](https://github.com/drizzle-team/drizzle-orm/blob/748058e837d9c4247330e3d45580cbdae52bffda/drizzle-orm/src/node-postgres/migrator.ts) delegates to the [PG async core](https://github.com/drizzle-team/drizzle-orm/blob/748058e837d9c4247330e3d45580cbdae52bffda/drizzle-orm/src/pg-core/async/session.ts). Metadata setup/read precedes the pending-migration transaction. [Selection uses migration names](https://github.com/drizzle-team/drizzle-orm/blob/748058e837d9c4247330e3d45580cbdae52bffda/drizzle-orm/src/migrator.utils.ts), with no early serialization lock in that path. The [node-postgres session](https://github.com/drizzle-team/drizzle-orm/blob/748058e837d9c4247330e3d45580cbdae52bffda/drizzle-orm/src/node-postgres/session.ts) can use one checked-out Client and rolls back failed transactions.

The proposed real-library test requires both unwrapped callers to reach a parent-held migration-body barrier while the migration is genuinely pending. Only if needed, a tiny same-Client session advisory lock before public migrate would cover metadata/read/pending selection. No copied migrator/custom journal is proposed.

For rollback, M1 actually changes data/DDL and inserts its **library** journal row before M2 blocks on ALTER. Native completed extended-Execute logging with PID/session/name correlation, plus the later real ALTER waiter, proves that earlier insert completed. A pre-send JS logger is insufficient. Timeout must roll back all prior pending data/DDL/journal changes; identical input retry must commit once. SERIAL gaps are allowed. Rerunning already-applied inputs under the same blocker is the no-op sensitivity control. All remain unexecuted behind the strict gate.

## Read-only stable/GA readiness check

Official npm metadata retrieved2026-10-26 reports ORM `latest=0.45.4` and `rc=1.0.0-rc.5`. The [official0.45.4 release](https://github.com/drizzle-team/drizzle-orm/releases/tag/0.45.4) is marked Latest. No1.0 non-prerelease is identified by these tags. The [official v1 upgrade guide](https://orm.drizzle.team/docs/upgrade-v1) still directs users to RC and describes a migration-folder change. This check installed/adopted no candidate.

| Readiness-review input | Exact version | Logical unpacked bytes | Qualification status |
| --- | --- | ---: | --- |
| Non-prerelease ORM |0.45.4|10,517,974|Distinct stable candidate; not tested compatible. |
| Non-prerelease Kit |0.31.11|10,267,562|Separate tooling input; public runtime migration research does not require its installation. |
| Newer RC ORM |1.0.0-rc.5|17,842,566|Still prerelease; freshness does not resolve rc.4 type failures. |

Stable0.45.4 integrity is `sha512-NiM1YZpJ2UxyeE67DpDDZ+Tsw4YLX3trSlkNT7Tm9eKoUNb1LvaAaQzXgYQsWs+AQ9TUmmwMmBOCXuqqxUWKKQ==`; exact official release source is `eab8bedbb65d5429c54e612ddbd88aa23091d398`. Inspected source supports node-postgres/pg>=8 and checked-out Client construction. It requires the older `meta/_journal.json` layout and selects against latest created_at, whereas rc.4 uses named folders/journal rows. Those are different migration inputs/semantics; this is no automatic downgrade of real RC history.

**Inference:** considering exact0.45.4 fits ADR-0052's expressly contemplated compatible-GA/readiness review now that the local-node:sqlite requirement is superseded. Calling it product-compatible or GA-qualified still requires the owning review and strict qualification; `latest` alone is insufficient. No evidence here says its declarations pass required TS7 flags. It was not installed, typechecked, repinned or adopted.

If later authorized, no pg/@types/pg8.23.1 or @types/node26.6.5 change is expected merely to inspect this candidate; actual peer/declaration closure must be checked rather than auto-installing unrelated drivers. ORM logical payload is about10MiB before filesystem/store overhead. Prepared SR2 adaptation is estimated20–60 integration and50–100 fixture/oracle lines for migration-input/journal differences, approximately×2 uncertainty;0 production lines authorized. Confidence in considering this bounded candidate is6/10, expected reliability remains unqualified, complexity4/10. These are engineering judgments, not adoption/uptime scores.

## Failures retained and next disposition

The first registry request failed with sandbox EPERM and is retained. Authorized metadata retrieval/frozen install succeeded. The first compiler failure included the constructor misuse and vendor errors; the second retained only47 vendor diagnostics. No failures were discarded or blended into a pass aggregate.

Keep SR1 independent for its approved isolated native gate. Keep SR2 red/unexecuted until the owning readiness decision supplies a qualified profile. Source inference preserves the early-lock question without building a parallel engine. Root owns product pins/ADRs, repository/CI integration and checkpoint/push.
