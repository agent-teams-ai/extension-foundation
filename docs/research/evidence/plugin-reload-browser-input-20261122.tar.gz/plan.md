# Native browser HMR research plan, 2026-11-22

Disposable evidence, not a production plugin implementation. Use released Vite
and React Fast Refresh rather than writing a module loader. Native Chromium must
observe actual filesystem-driven HMR through Vite's real server and browser client.

Questions with independent expected results:

1. A component change with unchanged initializer and hook signature retains its
   local state. The surrounding host draft and document identity remain the same.
2. A hook-signature change remounts the component; local state resets while the
   parent-owned draft remains. No whole-application reload is needed for this case.
3. An effect with an empty dependency list is cleaned up and recreated during
   refresh. A real DOM event reaches exactly the current listener. A captured async
   callback can nevertheless finish with its old code after refresh.
4. A raw Vite HMR module that throws on new evaluation has already had its old
   resource disposed. Re-import acceptance is not a transactional activation or
   a guarantee that old resources stay usable. Recovery constructs a new resource.
5. A separately changed initializer is expected to remount in the exact selected
   transform, which includes the initializer source in its refresh signature.
   Record the actual classification as a check against that hypothesis. A subsequent
   full reload uses the new initializer and creates a new host draft. Retained
   hot-reload state is not in general identical to a clean start.

Independent source review corrected an early assumption before execution: React's
upstream tests include initializer changes that cause remounts. Flutter's retained
initialization behavior must not be projected onto React or every Vite transform.
The selected plugin-react6.3.0 uses Vite's Oxc transform by default; the locked
Rolldown1.2.19 uses oxc_transformer0.156.0. Source
[refresh.rs](https://github.com/oxc-project/oxc/blob/75efdca4747c4ad9b252542743098d4894f8005b/crates/oxc_transformer/src/jsx/refresh.rs)
includes the complete first useState argument in the signature, including the
arrow initializer. This supplies the independent pre-execution expected reset.

This tests development HMR only, not production authorization, hostile code,
generic state migration, operation-affine dependency closure or physical unload.
Expected activation failure and its raw console evidence are retained. No timing
benchmark or zero-leak claim follows from one component and one listener.

All maintained runtime/test sources use strict TypeScript 7.0.2. The changing
component/module variants are independently checked files. Native launch may be
restricted locally; in that case preserve the failure and use an ordinary hosted
research runner with identical frozen input and exact locked dependencies.
