# Shared research and critic brief — 2026-10-22

This is a working brief, not a new architecture decision. Every researcher and critic receives this context and must read the relevant primary authorities below. Final evidence belongs in governed repository research; scratch notes are intermediate.

## User's full direction

Build a powerful modular TypeScript system with hundreds or thousands of modules and potentially thousands of user plugins. Users should customize deeply through plugins instead of forking the product. Preserve explicit responsibility and authority, Clean Architecture, SOLID, DRY and Pluggable design. Prefer mature existing open-source mechanisms over bespoke substitutes. Avoid overengineering and speculative managers. Reliability, maintainability and convenient extension authoring matter more than language fashion or syntactic brevity.

Investigate gradual old/new implementation replacement like graceful server deployment, an independent reusable library/package/repository, Temporal through an adapter, and selective Rust or another language where there is concrete advantage. Main application remains TypeScript. Document a lasting instruction for agents to consider other languages with evidence, rather than automatically choosing TypeScript for every critical component. Same public concepts across Node/Web/Desktop matter; unsupported guarantees must be explicit rather than hidden behind no-op adapters.

Use GPT-6.1 Sol xhigh researchers and overlapping independent critics. Give all of them the vision, authoritative constraints, previous evidence and candidate proposals. Preserve sources, good/bad patterns, uncertainty and review dispositions. Structure knowledge through existing Docs Protocol and agent navigation. Respect approved ADRs; genuine conflicts require a concrete owner discussion. Alternatives need confidence, achievable reliability and complexity /10 plus separate production/test handwritten LOC with scope and assumptions.

## Freshly verified repository state

- EF PR55 open draft, research branch `docs/plugin-research-hot-reload-20261021`, head466e35a62481a6b21f2062524bb92c7eb221bb8c; main9ea7024672ae06a15c701fa1e23bf6db37975e20.
- GM PR210 open draft, latest/navigation branch head8249c674ad53458b31d6ad06803ceb76e29ff4c7; maineadd9d391657ae6f508a874dd30e923bdc4054f0.
- Orchestrator PR88 open draft, head477b3445c4c66416121559894cf6f393c9450c72, targeting PR86 branch `docs/mandatory-modules-and-collaboration`.
- PR86 advanced to0f0338002eb713fa390cb47bc8acdb5d8efd1d91; its base main98f653172215e2a2c73cc484db3fa4fe72ed21ba unchanged. It includes newer approved human-collaboration/Execution Directory work and further research. Do not overwrite it.
- Organization `.github` observed atd17901e6975fdb4388b1f75cad901e7f448aebbe. Current Engineering Quality Standard expressly requires library-first design for shared concerns, purpose-neutral universal identities, external ordinary-project use, a real consumer plus disposable conformance in the first delivery. A consumer is not an incubator for duplicated mechanisms. This still does not authorize speculative packages or override accepted ADRs.
- Agent Runtime main8d89b28f07426846b3ded7c6bd933363d9dc468c has explicit deferred Rust custody research and a retained synthetic experiment. Proposed `custody-keeper`/`custody-init` repos were unavailable (404); no availability claim follows. User has approved direction toward separate native custody components; source says migration itself is separate/unimplemented. Do not create another supervisor.

All clones: `repos/extension-foundation`, `repos/get-modular`, `repos/agent-teams-orchestrator`, `repos/.github`, `repos/agent-runtime` beneath this brief's directory.

## Required existing authorities

Read EF `AGENTS.md`, relevant architecture docs, ADR0011/0014/0015 and OD003; GM ADR0029 and `packages/lifecycle-kernel/README.md`; Orchestrator ADR0110, ADR0027 and relevant OD005/OD035/OD041/OD043. Read `.github/docs/engineering-quality-standard.md`. New TypeScript remains ordinary `.ts`, strict typechecked, compiler7.0.2+ where applicable. Accepted documents stay byte-immutable; researched mechanism is not production or public-SPI approval.

GM owns inert declaration and identity grammar, deterministic immutable composition and construction. EF owns neutral extension artifact, trust, custody and lifecycle protocol/conformance obligations. Products own domain contracts, execution placement, effective grants, durable publication/admission, routing, effects, recovery and physical retirement. Domain/application see consumer-owned narrow ports. Shared mechanical implementation does not transfer operational authority. No extension code in a DB transaction; no second generic outbox/workflow engine or global service locator.

IMPORTANT: GM ADR0029 already admits exactly one optional dependency-free synchronous local generation/lease bookkeeping candidate, `@get-modular/lifecycle-kernel`. It imports neither Core, Assembly, EF, Node nor another runtime; no IO, timers, callbacks or Promises. It is already independent of composition as a package. It owns stage/activate/quiesce/retire and exact token membership/custody; public release and real production adoption are pending. A new replacement library must not duplicate or silently move/release/rename this accepted kernel. Distinguish rollout-operation progress from kernel facts and canonical product facts. Extraction or widened authority needs a successor decision.

EF OD003 already has a shared Host mechanics discussion, rejects overlapping lifecycle FSMs, keeps public SPI/placement/migration open. EF package publication needs its real-slice/independent-conformance evidence; Orchestrator OD041 retains two independent integrations for production EF adoption. Library-first intent can shape a mechanism now; it is not automatic qualification.

Orchestrator ADR0027 selects Temporal as replaceable durable Run Orchestration adapter, product data stays authoritative. Existing OD005 retained Temporal spikes are prior evidence, not newly executed proof. OD035 excludes a local Temporal service in default Desktop and keeps OpenWorkflow as a separate future candidate. Verify exact versions and newer primary docs before repeating historical missing-feature claims.

## Previous research and candidate, not a fixed conclusion

Read EF `docs/research/plugin-system-research-reference.md`, `hot-reload-and-generation-replacement.md`, `plugin-research-review-and-decision-record.md`, and the relevant platform/system/ecosystem/stateful evidence. Eight records preserve20 comparison cases and14 patterns. Prior independent critiques already rejected universal unload, automatic effect rollback and workers-as-hostile-sandbox claims.

Candidate first profile: trusted overlap-safe bounded request cohort, fresh immutable GM per generation in Node worker, canonical state external, initially read-only external behavior; no exclusive-resource transfer/private-state migration/live function or stream escape. One active/candidate and bounded unresolved predecessor; don't accumulate generations indefinitely. This is a qualification target, not an accepted Node-worker runtime.

Local beginCall, pending accounting and canonical acceptance are separate transitions. Pending attempts consume capacity. Dispatch requires confirmed acceptance plus still-valid local authority; unknown ACK reconciles the same operation without blind retry. Quiesce rejects new admission while accepted closed-cohort work can finish. Retire revokes invocation, custody can remain. Timeout is not cleanup settlement or physical absence. Preserve the real cleanup flight and infrastructure; rollback prepares old immutable bytes as a fresh monotonic generation. Local leases are not resource-enforced distributed fencing. Physical exit does not undo remote writes.

Prior production estimate3k–5.5k TS plus5k–9k tests assumes existing auth/transactions/durable-operation/recovery infrastructure, not a full ecosystem or merely a routing prototype. All new estimates must name marginal vs total cost and avoid charging shared infrastructure to every static module.

## Questions each critic must challenge independently

1. Can a small neutral library be independently useful without a second kernel/coordinator or mandatory GM/EF/Temporal/org credentials? What belongs in its per-instance mechanism, adapters and consumer policy?
2. What existing OSS is actually reusable, at what version/license/support envelope, and what essential protocol remains ours? Platform/server/VM behavior is not automatically a reusable library.
3. Does Temporal reduce durable rollout work for an already admitted deployment, and what happens offline/on Desktop? Does it stay outside per-call fast path and actual reference/process custody?
4. Where does Rust demonstrably improve reuse, physical custody, CPU cost or fault containment? What new FFI/ABI/platform/release burden or distributed uncertainty appears? Preserve existing AR ownership.
5. How does deep customization without forks preserve invariants? Which contributions, explicit provider replacement and ordered composition are valid, and how are conflicts/compatibility/errors explained? Avoid monkeypatching internals or runtime mutations of existing consumers.
6. Which counts really scale: installed descriptors, active instances, execution realms, tenants, dependency edges, independent versions, concurrent work and reload churn? No thousand-plugin performance claim from a descriptor count.
7. Which doubts can be resolved with a bounded disposable experiment, and which are actual owner decisions? Do not rerun unchanged prior broad campaigns or label proposed tests as passed.

Reports: primary URLs, retrieval dates and immutable pin/caveat, facts vs inference vs executed experiment, scoped recommendation, strongest counterarguments, alternatives/scores/LOC, rejecting scenarios and remaining uncertainty. Root curates into existing governed research and records reviewer dispositions.

## Final follow-up findings (2026-10-22)

The clean governed EF continuation is /tmp/plugin-docs-followup-20261022, based on the same PR55 HEAD. The original writer transaction/evidence remains untouched; exact supported create workflow succeeded in the clean checkout. No dependency patch or gate reduction was used.

Central .github main advanced to86a85d6beda07e6e5ee7806646f700bc4e4db173. Its new backend reference requires explicit consumer adoption. Native PostgreSQL local reference differs from accepted Orchestrator ADR0048/0049 SQLite context authority; OD035 is OPEN and retains SQLite/OpenWorkflow qualification. Do not silently adopt local PostgreSQL or Temporal. Language-policy candidate002a7f9c8b17d35aff80866c6b3a2b8e4c454e44 adds evidence-based language guidance and passed full unchanged central gate outside the restricted sandbox.

The original eight-case Node Worker/Piscina5.3.2/workerpool10.0.3 experiment passed and repeated unchanged; it is narrowly scoped and retains the strict dependency-declaration failure/skipLibCheck caveat. workerpool timeout terminate fulfilled while the blocked task remained active. Final evidence critique added ONE two-worker Piscina case: close(force:false) fulfilled without error after A finished while B was terminated without finally. Source and result are separate; no broad rerun or universal one-worker qualification follows.

Final architecture critique joined failed-candidate custody with capacity: observer timeout does not free the candidate slot while startup/cleanup remains live. Aggregate limits must name tenant/cohort/replica denominators. Final handoff is exact-generation endpoint/owned queue acceptance after last await or user conversion, not CPU start. Original Host/execution incarnation binds acceptance; scheduler epochs are enforced at command receivers. Forced exit differs from callback settlement and external debt. A shared neutral driver implementation is permitted; duplicate authoritative facts or independently advancing drivers are excluded.
