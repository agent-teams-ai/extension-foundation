# Final organization language-policy review — 2026-10-22

Working research/critic notes for the root curator. This does not accept a
product architecture decision or publish a runtime. The shared `context.md` was
read in full before work. No implementation, new dependency, package version,
accepted ADR, published standard or product checkout was changed.

## Result and source state

The organization `.github` language-guidance branch now integrates the complete
new upstream backend/tooling guidance without conflict:

- Checkout: `repos/.github`.
- Branch: `docs/evidence-based-language-selection-20261022`.
- Starting HEAD: `d17901e6975fdb4388b1f75cad901e7f448aebbe`, with the root's
  existing uncommitted language section in `docs/engineering-quality-standard.md`.
- Fetched upstream `origin/main`: `86a85d6beda07e6e5ee7806646f700bc4e4db173`.
- Integrated candidate HEAD: `002a7f9c8b17d35aff80866c6b3a2b8e4c454e44`.
- Both raw author and committer: `iliya <iliyazelenkog@gmail.com>`.
- Diff from upstream: one file, `docs/engineering-quality-standard.md`, 53 added
  lines. Upstream AGENTS, README, backend-stack and development-tools changes are
  retained verbatim. Worktree clean after rebase.
- No push, PR creation, merge, release or remote mutation was performed. Fetch
  was read-only. The original uncommitted language diff is also retained at
  `/tmp/plugin-language-policy-original-20261022.patch` as an intermediate backup.

The root's proposed section is preserved substantively: TypeScript remains the
main application language; criticality alone mandates neither TypeScript nor
Rust; compare mature reuse and the current owner; preserve narrow consumer-owned
ports; include binding/process alternatives, ABI/protocol, platform, packaging,
debugging and release cost; score confidence, achievable scoped reliability and
complexity /10; distinguish production/integration LOC from test/fixture LOC and
incremental from total cost; ordinary new JavaScript-runtime source remains `.ts`
with strict owner-selected TypeScript 7.0.2+ qualification and existing pin/adoption
authority intact.

Two narrow refinements were made before the local commit/rebase:

1. **Custody qualification:** preserve the existing physical-custody owner and
   qualify the selected implementation; a deferred native migration or synthetic
   experiment is not a qualified reusable implementation. This avoids implying
   the currently deferred Agent Runtime Rust work is an available qualified
   dependency while still rejecting a second supervisor.
2. **Reference versus adoption:** a reference stack does not adopt a consumer's
   storage, workflow engine or local deployment profile. This reinforces existing
   governance in the face of the newly added backend reference without rewriting
   that reference or any product decision.

Primary candidate: [quality standard at this local commit](https://github.com/agent-teams-ai/.github/blob/002a7f9c8b17d35aff80866c6b3a2b8e4c454e44/docs/engineering-quality-standard.md).
This commit is local and was not pushed, so the URL is a provenance coordinate,
not a claim that GitHub serves it.

## Material product boundary: local PostgreSQL versus accepted SQLite

This is the concrete owner issue to retain in the final synthesis. The new
[backend reference at 86a85d6](https://github.com/agent-teams-ai/.github/blob/86a85d6beda07e6e5ee7806646f700bc4e4db173/docs/backend-stack.md)
selects native PostgreSQL for both server and fully local backend profiles and
describes `embedded-postgres` behind a Node Supervisor adapter. It expressly
requires local adoption of an applicable subset at an exact reviewed central
commit and preserves accepted product ADRs. Its existence does not supersede
Orchestrator persistence.

Orchestrator accepted
[ADR-0048](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/decisions/0048-single-persistence-authority-and-logical-transfer.md)
states local authority uses each context's SQLite file, hosted authority uses its
PostgreSQL schema, connected Desktop uses hosted authority, and transfers are
logical export/import rather than bidirectional database replication.
[ADR-0049](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/decisions/0049-exact-persistence-and-instant-profile.md)
also fixes exact-value/instant mappings for SQLite and PostgreSQL. A central
PostgreSQL local profile can be a future alternative, but product adoption would
require the owning persistence decision process, an explicit successor where
needed and fresh migration/recovery/packaging evidence. Do not reinterpret a
central reference link as that adoption.

Precise status: **ADR-0048/0049 are accepted. OD-035 is open**, not an accepted
ADR. Nevertheless, OD-035 records the current local direction and unresolved
qualification constraints; research must not silently discard them.

## Temporal review

The new central reference and Orchestrator are aligned on the high-level hosted
boundary: Temporal is a replaceable workflow adapter, while the product owns
business state. The central local section additionally says the local workflow
engine remains a separate owned selection and server Temporal does not imply
local Temporal. Therefore there is no automatic Temporal migration conflict to
repair in central prose.

The exact product authorities inspected are:

- [ADR-0027](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/decisions/0027-temporal-as-run-orchestration-adapter.md):
  Run Orchestration owns business state, retry/escalation/compensation policy,
  application idempotency and reconciliation. Temporal history owns durable
  execution progress only. Other contexts do not transfer ownership to Run
  Orchestration merely by reusing Temporal infrastructure.
- [OD-005](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/open-decisions/OD-005-temporal-workflow-boundary.md):
  the first official Temporal adapter/worker uses the pinned Node TypeScript SDK;
  Go/Rust/mixed workflow workers require measured operational need plus a new
  ADR. The language policy expressly preserves this requirement. Its retained
  two 35/35 spike runs are historical evidence, not newly executed trials here.
- [OD-035](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/open-decisions/OD-035-local-durable-workflow-engine.md):
  local scheduling remains open; SQLite crash/restart/duplicate/timer/upgrade
  behavior and Windows/macOS/Linux redistribution need qualification. No local
  Temporal service is introduced. OpenWorkflow is a preferred spike candidate,
  not an accepted production dependency. Its 2026-08-09 `0.9.2` capability/roadmap
  observations are historical; this review did not reverify current upstream
  versions or repeat historical missing-feature claims as current facts.

**Inference:** durable rollout orchestration may use an already admitted Temporal
adapter for intent, waits and retry/reconciliation progress. Neither Temporal nor
a language change can own the actual live worker references, GM token membership,
OS process handles, product publication/admission fences, cleanup settlement or
remote-effect receipts. Keep Temporal outside the per-call fast path and reuse
consumer idempotency/authority rather than create a generic rollout workflow DSL
or second outbox. Desktop/offline inability to reach Temporal cannot be hidden by
an in-memory/no-op adapter claiming equivalent durability.

## Custody and reuse critique

[Agent Runtime follow-up at 8d89b28](https://github.com/agent-teams-ai/agent-runtime/blob/8d89b28f07426846b3ded7c6bd933363d9dc468c/docs/architecture/rust-custody-migration-follow-up.md)
explicitly defers the Rust custody migration as separate work after PR69. It
recommends host-side keeper plus in-container custody-init; TypeScript retains
provider SDKs, operation authority, Provider Access, Runtime Security policy and
HTTP/TLS. The associated
[production gates](https://github.com/agent-teams-ai/agent-runtime/blob/8d89b28f07426846b3ded7c6bd933363d9dc468c/docs/spikes/rust-system-boundaries-production-gates.md)
remain open. Synthetic feasibility is useful evidence; it is not a released
binary or production qualification. This review made no availability claim for
the previously unavailable keeper/init repositories.

Strongest case for selective Rust is a complete, bounded technical custody
lifecycle whose system integration/failure requirements justify native code and
its release burden. Rust does not make remote writes reversible, establish
distributed fencing, provide hostile containment through process groups, or prove
physical cleanup from an elapsed timer. An in-process FFI binding can still crash
the host; a separate process adds framing, correlation, backpressure, uncertain
acknowledgment, version negotiation and supported-platform work. Choose the
required boundary first. Do not create a plugin-specific supervisor alongside
the existing runtime custody owner.

The reusable synchronous local kernel already has an accepted identity and
owner:
[GM ADR-0029 at 8249c67](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md)
and [package README](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/packages/lifecycle-kernel/README.md).
It is a candidate with zero runtime dependencies, no Node/Core/Assembly/EF,
no IO/timer/callback/Promise and one Host-local membership authority. Calling its
bookkeeping retirement does not prove physical cleanup. Do not rewrite it in
Rust, rename/move/release it or duplicate its phases to create a separate
replacement library under a general language instruction.

[EF OD-003 at 466e35a](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md)
already admits research of common validation, request correlation, cancellation
transport and conformance mechanics, while rejecting a second overlapping FSM,
coordinator and global registry. ADR0014/0015 preserve immutable composition and
product operational authority. The central library-first rule supports one
neutral mechanism and an ordinary independent-project consumer; it does not
publish EF's open public SPI or satisfy its independent implementation gates.

**Inference:** a small portable correlation/framing/conformance mechanism could
be useful independently of GM, EF, Temporal and organization credentials if a real
common contract is demonstrated. That is a qualification question, not approval
for a new generic manager. Same public concepts across Web/Node/Desktop require
honest supported guarantees; adapter parity must not fabricate Node-like exit
acknowledgment in browsers or hostile isolation in trusted workers.

Deep customization should expose owned contribution contracts, explicit provider
replacement and deterministic ordered composition with conflict diagnostics.
It does not require monkeypatches, live mutation of immutable consumers, a process
per static module, or a wire protocol for ordinary TypeScript function calls.
Count active instances, independent versions, execution realms, tenants, graph
edges, admitted concurrency and reload churn separately from inert descriptors;
this prose policy establishes no thousand-plugin throughput result.

## Policy options and estimates

Scores are reviewer judgments for **the documented language-selection policy**,
not measured runtime availability. Higher complexity means more maintenance or
decision burden. LOC are handwritten new production/integration and test/fixture
code for this policy delivery; existing source is unchanged. They are not full
replacement-runtime estimates.

| Option | Confidence /10 | Achievable scoped reliability /10 | Complexity /10 | New prod/integration LOC | New test/fixture LOC | Assessment |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Evidence-based selective language reuse with owner/adoption boundaries | 9 | 9 | 2 | 0 | 0 | Recommended; 53 lines prose, existing mandatory gates; all later implementation estimates must include platforms and release work. |
| TypeScript for every responsibility regardless of measured native needs | 5 | 6 | 2 initially | 0 for policy; later unknown | 0 for policy; later unknown | Preserves short-term toolchain simplicity but can force bespoke/weak system custody and conflicts with owner direction. |
| Prefer Rust for every critical component | 3 | 5 | 8 | 0 for policy; migration unknown | 0 for policy; qualification unknown | Reject: criticality does not demonstrate benefit; creates cross-language maintenance and can violate accepted TS worker/custody decisions. |

The accepted Agent Runtime follow-up's historical whole-custody estimate is
8k–13k new/substantially reworked production and 10k–18k test LOC, with 10k–16k
removed, confidence roughly 6/10. Its first Linux synthetic slice was estimated
3k–5k production and 4k–7k tests **within those totals**. These are source-recorded
old estimates, not this review's current quote; re-estimate from then-current
code before authorizing implementation and do not add them per ordinary module.

Strongest counterargument to the recommendation is that scoring/LOC can become
ceremony for minor choices. The guidance limits this requirement to significant
language/runtime choices, adds no new routine approval gate and asks for bounded
experiments only if they can change the decision. Scores should disclose evidence
and uncertainty rather than simulate measurements.

## Executed verification

Toolchain: `PATH=/tmp/plugin-portability-toolchain-20261022/bin:$PATH`, official
Node `v26.11.1`, repository pnpm `11.18.0`; dependencies and lockfile unchanged.

- `git diff --check`: PASS before commit and after rebase.
- Sandbox `node --test scripts/check-quality-scope.test.mjs`: FAIL, reproducing
  the previous gate failure at the file envelope.
- Sandbox direct `node scripts/check-quality-scope.test.mjs`: 42/44 PASS; two
  installed-subprocess controls fail. Typed-source rejection has status 1 but
  empty diagnostics, then the nested mandatory positive control exits 1 instead
  of 0. The environment has neither NODE_OPTIONS nor NODE_TEST_CONTEXT at the
  initial command boundary. No source change was inferred from absent diagnostics.
- **Identical installed `pnpm test:critical` outside the sandbox: PASS**, all eight
  mandatory identities completed. This bounds the prior failure to the restricted
  execution environment; the exact lower-level sandbox interference is not
  established. No environment scrubber, assertion change, scope shrink, baseline,
  exclusion, skip or suppression was added.
- **Complete required `pnpm check` at integrated HEAD outside the sandbox: PASS,
  exit 0.** Precheck source census, strict lint/source boundaries/typecheck,
  Renovate, governance/cohort/community/workflow checks, all eight critical
  identities, **5,621 current tests and nine frozen historical tests** pass.
  Both full-test partitions have zero failures, cancellations, skips or todos.
  Full log: `/tmp/plugin-organization-language-final-check-20261022.log`.
  Total full-test counts are 5,630; the critical identities also execute through
  their existing separate mandatory route and are not additional distinct tests.
- Final post-gate HEAD/upstream and raw owner identity rechecked unchanged;
  worktree remains clean and the diff remains one file with 53 prose lines.

No new prose-only tests were written. Required repository tests remain intact.
No product qualification, new benchmark, Temporal experiment, native build or
platform custody campaign was executed by this review.
