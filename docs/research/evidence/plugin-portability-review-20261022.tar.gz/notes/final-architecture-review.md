# Final independent architecture review

Review cut: **2026-10-22**. This is a fresh architecture critique of the shared
vision, four curated supplements, three previous critics, the existing primary
authorities and the in-progress EF assembly. It is not an adoption, publication,
production-runtime decision or independent rerun of the retained experiments.
I read the shared brief before reviewing. I made no repository or curated-file
edits and ran no builds, broad tests, runtime experiments or native programs.

## Verdict

**The architecture direction is coherent and proportionate if it remains a
qualification hypothesis: one deliberate shared mechanism where a residual
invariant warrants it, the accepted GM kernel for its local bookkeeping, one
product-authorized operation, and existing executor/durability/custody owners.**
The first useful delivery should be one real supported extension family and one
bounded update promise. It should not attempt a universal plugin platform,
every customization category, a new workflow engine, a native kernel rewrite or
cross-platform equivalence of physical guarantees.

The proposal answers the reusable-library question substantively: the existing
kernel already is composition-independent; execution/RPC reuse may leave a
finite generation/incarnation-affine protocol or shared driver/test kit. If that
residue is real, implement it deliberately once from its first delivery with a
real consumer and ordinary external fixture. It need not be a new repository.
A new repository is reasonable when independently useful releases/consumers
justify its additional ownership and release work. Repository location alone
neither proves nor defeats architectural independence.

The strongest simpler alternative remains supported contribution/provider seams
with controlled restart. That can deliver extensive customization without forks
at much lower implementation cost. Fine-grained dynamic replacement must earn
its availability benefit for an actual capability.

**Documentation can finish now.** The remaining implementation evidence does not
justify holding research open or asking the owner for speculative permissions.
The primary remaining semantic clarification I found beyond the earlier critics
is retained custody after a **failed candidate**, described next.

## Priority finding FA-01: failed preparations retain their capacity slots

**Priority:** medium/high implementation risk; a short clarification is enough
for the research. **Locations:** central hot-reload proposal, “Proposed protocol
and fixed envelope,” preparation step, and startup/timeout failure rows; reusable
mechanisms supplement, retention-cap objection; customization aggregate-budget
paragraph.

The envelope says one candidate and at most one unresolved predecessor, and
blocks new candidates while a predecessor remains unresolved. It separately
says to retain the real startup flight. Those obligations should be joined
explicitly. An unsuccessful candidate never became a predecessor, so a careless
implementation could forget its candidate slot when the rollout request fails.

**Rejecting trace:** candidate C1 times out while startup/cleanup still runs;
the observer reports failed preparation and frees the candidate slot; C2 starts
and does the same; repeated retries accumulate workers, ports, artifact roots or
late acquisitions while the original active generation never changes. The
predecessor limit never activates. This is possible with ordinary asynchronous
turns and does not depend on an exotic platform failure.

**Suggested exact addition:**

> A failed, aborted or timed-out preparation continues to occupy its candidate
> or retained-owner capacity until its actual execution/custody is settled under
> the selected profile. Ending an observer or rollout request does not free that
> capacity. Releasing the slot requires exact-owner cleanup/absence evidence and
> the applicable remaining-debt disposition; do not reclassify a still-live
> candidate as merely a historical failed operation.

The existing product capacity owner enforces this. No extra scheduler, manager,
kernel phase or durable journal is needed. For an admitted pool profile, count
all owned executor incarnations and replicas, including ones whose creation or
termination remains unresolved. A failed candidate can block further updates
while the old active generation keeps serving; that is the honest availability
tradeoff of bounded retention.

## Previously identified corrections: verify once in assembly, do not re-research

At my inspection the assembly was explicitly still in progress. The root
confirmed it was already addressing the following. They are not newly invented
findings or reasons to restart unchanged checks:

| Existing issue | Required final wording/behavior |
| --- | --- |
| LF-01 local dispatch join | After the final await/user conversion, the same Host agent checks exact token/disposition and performs its owned exact-generation handoff without another asynchronous or user-code gap. Queue acceptance can be the handoff; CPU start need not be. No cross-agent/database atomicity is implied. |
| LF-02 incarnation | Acceptance/readback binds the original operation, generation and execution/Host incarnation. Old accepted status cannot recreate local nominal authority after restart. Valid accepted old work need not remain the current head. |
| LF-03 scheduler switch | Receivers reject stale operation/revision/incarnation/epoch commands; stopping old workflow starts alone is insufficient. Previously accepted effects still need reconciliation. |
| LF-04 cleanup versus forced exit | Forced exit can make a local continuation impossible without proving its finally or external postconditions. Report physical absence, failed/impossible cleanup and external debt separately. Do not retain an impossible Promise forever merely to manufacture natural completion. |
| CS-06 scope of caps | Label operation/endpoint/cohort/tenant/Host budgets and enforce aggregate owned resources across tenants, cohorts and pool replicas through the existing product capacity owner. Per-cohort bounds are not fleet bounds. |
| F3 Temporal LOC | Gross adaptation allowance is not measured net increment. A conservatively additive scenario may be shown as such; actual net equals new adapter work minus the driver work removed. |

The same assembly pass should remove the old review table's categorical
process-reliability advantage where it compares the **same bounded logical
promise**. A process can provide stronger containment evidence while still having
more installation/protocol failure modes. Keep different promises separately
scoped rather than ranking languages from 8 versus 9.

## Independent answers to all requested architecture questions

### Gradual old/new replacement and maturity of reuse

The NGINX analogy is useful for make-before-break, readiness, old-work retention
and bounded operational resources. Its server/process ownership is not a
portable plugin library. The current research correctly changes the unit to a
closed capability cohort and rejects live mutation of an existing GM graph.

Closure is the hard granularity rule: if A captured B, replacing B alone does
not update A. Include the affected dependent/retention closure or cross a stable
data request boundary. A callback, iterator, remote proxy or session that escapes
that request changes the lifetime promise. This is already captured in the
curated customization and reuse notes; no new generic session framework belongs
in the initial slice.

The inspected mature options each remove real work at their own boundary:
Piscina for task/pool mechanics; workerpool for cross-target task execution;
Comlink for appropriate message RPC; Temporal for durable scheduling/history;
ArcSwap/ordinary immutable references for snapshot retention; existing OS/AR
owners for actual execution custody. The executed worker experiment is stronger
than the short README claims and must take precedence for the exact exercised
version/mode. No evidence supports workerpool fulfillment or a termination hook
as universal exit evidence, or Piscina close fulfillment as natural completion.

Do not combine every library merely to demonstrate reuse. Piscina already
correlates task results, so adding Comlink around its task method can be
unnecessary. A message-oriented long-lived Worker may have a real Comlink need.
Comlink's convenient proxy/callback surface also permits precisely the lifetime
escape excluded from the first profile. Keep a validated data surface and raw
library types inside the adapter. These are source/retained-experiment facts and
inferences from the inspected record, not a new runtime qualification here.

The important unanswered reuse question is small: **what invariant remains
after subtracting the selected libraries and accepted kernel?** A shared driver
can still be the correct answer. Its private progress may sequence authorized
commands and observations without owning canonical policy. Duplication arises
from independently driving coordinators or independently editable copies of
facts, not from the mere word “driver” or use of ports/callbacks.

### Independent package and repository

There is no need to move, copy or rename `@get-modular/lifecycle-kernel` to meet
the independence goal. ADR-0029 already intentionally excludes GM composition,
EF, Node, other runtime dependencies, IO and async machinery from that package.
Its candidate/source/release/adoption gates still matter. A source-admitted
candidate exercised through a packed public root is not a released stable SPI.

A useful residual package should have a finite observable contract, per-instance
state, rejecting cases and an ordinary external use without organization
credentials or product catalogs. If only a few product identity/error mappings
remain, keep them with the product and reuse the existing implementations. If a
nontrivial generation-bound protocol repeats, centralize it from the outset.
Neither an abstract manager with dozens of hooks nor a new repository with no
residual responsibility improves the user's modularity goal.

EF's ordinary-library admission, stable extension SPI, GM release and
Orchestrator's two independent product integrations are distinct claims. They
coexist; I found no genuine approval deadlock. A single coherent delivery can
provide a candidate mechanism, real consumer and external fixtures without
publishing before qualification or deep-importing a private kernel.

### Temporal and local operation

The adapter boundary is sound and already supported by Orchestrator ADR-0027:
product commands and state own decisions; Temporal owns execution progress.
Use its durable waits/retries when already qualified or when a genuine
long-lived/distributed operation warrants them. Keep it outside ordinary request
admission and outside the replacement closure it coordinates. Activity retries
can overlap timed-out attempts; exact product operation/receiver fencing remains
necessary. A library cannot turn Temporal start and a product DB commit into
one transaction.

The newer central backend reference does not silently adopt native PostgreSQL,
NATS/Dapr packaging or local Temporal into Orchestrator. Its own scope/adoption
section preserves local owner records, and its fully-local section explicitly
keeps workflow-engine selection separate. OD-035 still records SQLite-qualified
local-engine research and excludes bundled local Temporal. Future adoption of a
different local persistence/packaging scope is a concrete product decision with
real costs; the research should record the difference, not resolve it by copying
the central stack table.

No reason was found to introduce Restate, DBOS, Dapr Workflow or a bespoke
durability engine solely for this plugin operation. They can be retained as
scoped alternatives without changing the accepted adapter direction.

### Rust and other languages

Keep the narrow language-selection instruction. It is a useful lasting response
to the user's request: compare actual mature mechanisms and complete integration
cost before defaulting to TS or Rust. The separately approved Rust keeper/init
direction has a plausible benefit at exact OS custody and Host-failure
boundaries. The source still says production migration is deferred; proposed
repository unavailability does not authorize a replacement keeper.

The existing local FSM has no demonstrated native performance or memory-safety
deficit warranting an FFI rewrite. A Node-API computation can reduce call overhead
but shares process fate; a sidecar adds protocol/install/release work while
providing another failure boundary. Wasm changes the supported plugin ABI and
capability model. All can be useful for concrete workloads; none proves
distributed acceptance, effect rollback or cleanup by its language alone.

Preferred Protobuf encoding remains a direction for a justified cross-language
service boundary, not a selected keeper schema/transport. Do not generate public
policy semantics from native implementation internals or require wire models for
ordinary in-process TS ports. The curated corrections handle this accurately.

### Thousands of modules and supported customization without forks

The proposed owned seams are broad enough to support meaningful deep
customization: contributions, explicit provider replacement, justified ordered
behavior, plugin-owned extension points and build-time variants. Protected
invariants remain fixed even when the product owner can qualify another
implementation of enforcement. An ordinary plugin cannot select the authority
that admits itself. This is a coherent Liskov/authorization boundary rather than
a ban on all security customization.

The next real slice should make the author workflow concrete without inventing
a new public API now. A small conceptual recipe can show: add a feature-owned
inert contribution and implementation; select it in a product profile; receive
an attributable conflict when two candidates compete. A second recipe can show
explicit provider substitution, affected dependent closure and a truthful
restart-required outcome. Normal authors should not implement canonical CAS,
Temporal histories or retirement reconciliation to contribute a menu item.
The host/SDK owns those mechanisms for an enrolled dynamic profile.

“Without forks” should mean supported seams permit documented customization,
including restart/build-time replacements. A missing seam may require an
upstream contract change. That preserves a strong practical promise without
claiming arbitrary access to internals. Exact diagnostics, provider implementer
compatibility, packed version combinations and configuration provenance matter
more than another universal `Plugin` interface.

Scale remains multidimensional. Descriptor count alone does not specify active
graphs, tenant isolation, dependency edges, workers, retained incarnations,
in-flight requests, copied bytes or replacement churn. Grouping trusted cohorts
reduces overhead while enlarging shared failure/privilege/replacement scope.
Independent user plugins cannot be grouped solely because the arithmetic looks
better. The retained N1000 source-check result does not qualify compiler or
runtime growth. No additional thousand-plugin campaign is needed to finish
honest research wording.

## Genuine owner choices, opposing costs and planning judgments

All ratings are **/10 ordinal engineering judgments**; reliability means
achievable correctness inside the stated profile after qualification, not
measured uptime. Higher complexity means more burden. LOC means maintained
handwritten production/integration code and independent tests/fixtures,
separately. It excludes dependencies/generated messages/docs, business provider
logic, new authorization/durability systems, full installers and unrelated
migration. Ranges are roughly ±2× and overlap; do not add alternative totals.

| Actual choice and scope | Confidence | Reliability | Complexity | Production LOC | Test/fixture LOC | Opposing costs |
| --- | ---: | ---: | ---: | --- | --- | --- |
| Owned contribution/provider seams with restart for one extension family | 9 | 8 within restart promise | 3 | 250–700 total | 500–1,200 total | Lower operational burden; update interrupts the selected runtime/session. |
| Full bounded trusted read-only Node cohort, direct Worker, existing product infrastructure | 7 | 8 | 6 | 3,000–5,500 total | 5,000–9,000 total | Better overlap availability; admission/recovery/retention still dominate cost. |
| Same promise using a fitting **single-worker** Piscina task profile | 6–7 for fit, declaration/profile qualification remains | 8 after qualification | 6 | 2,500–5,500 total, savings unmeasured | 4,500–9,500 total | Deletes task plumbing; adds pool incarnation/readiness/cancel semantics and dependency qualification. Multiworker drain is not covered by this row. |
| Residual neutral protocol/driver/test kit, if the first uses demonstrate it | 6 until subtraction | 8 within finite contract | 3–5 | 200–800 **within** complete cohort total | 600–1,800 within total | One maintained invariant; package/release compatibility is overhead if only method renaming remains. |
| Temporal scheduling adapter on qualified infrastructure | 8 for fit | Same Host ceiling; stronger scheduling recovery | 7 complete slice | 600–1,400 gross allowance; net unknown | 1,200–2,500 gross; subtraction unknown | Durable coordination versus deployment/history/replay work; unnecessary for a short local rotation with existing scheduling. |
| Thin TS adapter to a qualified native custody owner | 7 for fit; availability not established | 8 for same logical promise; separately stronger physical evidence | 6–7 | 300–800 incremental; native/release development extra | 800–2,000 incremental | Physical owner can survive Host failure; multi-platform binaries, protocol and release burden remain. |
| New Rust rewrite of the existing local FSM | 3 | No demonstrated improvement; 7 for that proposal | 8 | 1,000–2,400 code/release glue **plus** unchanged product protocol | 1,500–3,500 plus unchanged protocol fixtures | No demonstrated missing capability; adds boundary/parity/platform work. |

The owner decisions to carry forward are limited:

1. **First real capability and update promise.** Choose the supported
   customization family, placement, bounded authority/retry semantics and
   update-availability budget. Restart is a credible alternative, not failure.
2. **Residual shared concern and owner.** After subtracting executor/RPC/kernel
   mechanics, select a package/repository only for a concrete useful
   responsibility. Preserve the accepted kernel identity and existing admission
   route. A separate repo is an ownership/release choice, not a correctness
   mechanism.
3. **Supported operational envelope.** Choose actual aggregate resource and
   retention budgets and accepted degraded/update-blocked outcomes. Routine
   implementation of those caps belongs to engineering; no new capacity manager
   is implied.
4. **Scheduling scope, if the real operation needs it.** Direct bounded driver
   versus an existing Temporal adapter is a feature-level cost/operability
   choice. The hosted Temporal direction and future local track are settled.
   A future native-PostgreSQL local adoption must deliberately reconcile its
   product persistence/packaging qualifications; that is not required now.

Routine private handoff helpers, error mappings, payload fields, exact identity
correlation, source wording and focused fixture mechanics should not be returned
to the owner as extra approval questions. Nor should this review ask whether
local WeakMap tokens are distributed fences or whether a browser has Node exit
evidence; these are technical facts already resolved by the record.

## Evidence that can change an implementation decision

Reuse the retained eight-case executor experiment. Add only missing cases
relevant to the selected real slice: late failed-candidate cleanup retaining its
slot; pool cancel/respawn/readiness identity if a pool remains; acceptance/Host
restart and final handoff; stale scheduler receiver; forced exit with debt;
provider substitution/conflict author task; bounded aggregate retained resources.
An ordinary packed external project should use the actual proposed root without
org credentials or GM composition. Keep the expected oracle independent.

No new broad test campaign, native migration, public package release, two new
production integrations or runtime N1000 benchmark is a prerequisite to finishing
the present research. Those claims still require their actual evidence if made
later. The first candidate remains clearly a hypothesis, not a shipping runtime
or public SPI.

## Authorities and provenance

Primary local authorities actually inspected include EF AGENTS, ADR-0014,
ADR-0015, OD-003, architecture overview and ADR-0011's applicable admission,
publication/fence and effect-proof sections; GM ADR-0029, kernel README and
actual `kernel.ts`; Orchestrator ADR-0027, OD-035, OD-041 and relevant ADR-0110
static/resource sections; central Engineering Quality Standard and backend-stack
reference. The four curated notes, all three prior critics and retained worker
experiment report were read. The `/tmp/plugin-docs-followup-20261022` assembly
was in progress, so this review is not a claim of final assembled-byte approval.

- EF reviewed checkout: `466e35a62481a6b21f2062524bb92c7eb221bb8c`;
  [ADR-0014](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0014-product-local-module-authoring-composition-and-generation-guardrails.md),
  [ADR-0015](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0015-authorize-get-modular-semantic-extraction.md),
  [OD-003](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md),
  [overview/package admission](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/architecture/overview.md).
- GM reviewed checkout: `8249c674ad53458b31d6ad06803ceb76e29ff4c7`;
  [ADR-0029](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md),
  [kernel source](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/packages/lifecycle-kernel/src/features/lifecycle/kernel.ts).
- Orchestrator reviewed checkout: `477b3445c4c66416121559894cf6f393c9450c72`;
  [ADR-0027](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/decisions/0027-temporal-as-run-orchestration-adapter.md),
  [OD-035](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/open-decisions/OD-035-local-durable-workflow-engine.md),
  [OD-041](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/open-decisions/OD-041-shared-extension-foundation-and-artifact-distribution.md).
- Central retained baseline `d17901e6975fdb4388b1f75cad901e7f448aebbe`, plus
  current local language guidance and backend-stack text. Parent supplied newer
  central main `86a85d6`; I read the corresponding local backend reference but
  did not independently reverify that remote commit. Its reviewed-adoption and
  separate-local-workflow qualifications are explicit. A `gh` attempt was
  unavailable in this critic shell; no remote verification claim follows.
- Upstream dependency facts are credited to the curated source ledgers and
  exact retained experiment identities. This critic did not reinstall or
  independently recertify all release/license/platform claims.

## Late assembly verification and contrary evidence

Before handoff I re-read the central proposal's updated protocol section. It
now explicitly includes aggregate cap scope, execution incarnation, retained
failed-candidate capacity and the possibility of indefinitely blocked future
replacement; the forced-exit/debt and local-handoff clarifications are also
present. **FA-01 is addressed in that assembly.** This is a focused semantic read,
not a full final-byte/reachability qualification of a concurrently edited tree.

The parent then reported new independently executed contrary evidence from the
final evidence critic: one staggered two-Worker Piscina 5.3.2 case had
`close({force:false})` fulfill without error while A completed and B remained
barrier-blocked; both Worker exits were observed, B rejected and B's finally did
not run. I did not inspect that new harness/log, so this is explicitly credited
to the parent/evidence critic, not my own execution or independent certification.
It does not rewrite the original eight single-worker cases.

This result strengthens the existing architectural rule: **successful pool close
is not natural completion evidence for every accepted task**, even without an
observed timeout. Retain per-operation outcomes and actual owner/exit evidence.
Keep the candidate reuse recommendation bounded to its exercised single-worker
envelope, downgrade multiworker reuse until its semantics are qualified, and do
not add tests to this architecture review. If a pool requires lifecycle bypasses
or hiding task loss to satisfy the desired promise, select the direct execution
adapter rather than preserving the pool merely for nominal reuse. Existing
kernel/canonical authority and the independent library conclusion are unchanged.

**Disposition:** complete the already planned evidence/consistency incorporation
and finish the research. No new universal runtime, speculative owner gate or
approval blocker is justified. The remaining executor/profile decisions are
concrete implementation choices under existing owners.
