# Independent critique: ownership, reuse and the remaining library boundary

Reviewer: ownership/reuse critic, 2026-10-22. This is an independent architectural
review of the supplied candidate, not an implementation decision. Source review
was performed; no package install, runtime experiment, benchmark, fault-injection
suite or production qualification was executed. Ratings and LOC below are
planning judgments. Accepted decisions remain unchanged.

## Conclusion

**The best proposal is the existing narrow kernel, one execution owner and one
product-owned lifecycle operation, with commodity execution/RPC reused where it
actually fits. A new generic replacement manager is not justified. A small
independent library may be justified, but the reports have not yet established
how much mechanism remains after adopting those existing components.**

This is not an argument for implementing copies in products and extracting them
later. The current library-first rule is explicit: an expected shared concern
gets one owner and a deliberate library contract from its first delivery. The
missing step is to name the concern that is genuinely shared, subtract existing
mechanisms, and prove the residue with the first real slice and ordinary external
projects in that delivery. That may yield a useful small package, an adapter/test
kit under an existing neutral owner, or upstream reuse plus a small amount of
product-specific glue. It does not yet select a new repository.

The proposed bounded trusted read-only request cohort is a defensible
qualification target. It does not demonstrate the full user's desired ecosystem
yet. The customization supplement usefully separates build-time extensibility,
public contribution points, UI surfaces and dynamic replacement. Preserve those
distinctions: requiring every extension author to understand durable generation
retirement would defeat the author experience the user wants.

**Disposition:** incorporate the research after the wording/accounting corrections
below. There is no reason to block the documentation on a production Host, native
keeper release or thousand-plugin campaign. Do not turn the report into package,
runtime, public-SPI or adoption approval. A concrete implementation still needs
its real capability, admitted placement, available dependency and package-owner
decisions.

## Authorities actually read

I read `context.md`, all three researcher reports, the root
`customization-scale.md`, EF AGENTS, its architecture overview and extension model,
accepted ADR-0011/0014/0015, OD-003, research hub/proposal/review record and relevant
ecosystem evidence; GM ADR-0029, the lifecycle-kernel README and its actual
`kernel.ts`; Orchestrator ADR-0110/0027, OD-005/035/041/043; AR's Rust-custody
follow-up and optional-default record; and the central Engineering Quality
Standard including the root's drafted language guidance.

Checked local heads: GM `8249c674ad53458b31d6ad06803ceb76e29ff4c7`, EF
`466e35a62481a6b21f2062524bb92c7eb221bb8c`. Other source pins are the supplied
context/report observations, not newly asserted remote-head checks. The current
central guideline was read from the shared checkout; its new language section is
draft work, not already adopted policy in every consumer.

## Severity-ranked findings

### F1 — High: the new reusable mechanism is still a hypothesis, not an established responsibility

**Locations:** `replacement-reuse.md` recommendation and “Portable package shape
and ownership”; `temporal-adapter.md` recommendation's separately owned
library/repository paragraph; EF OD-003 “Shared Host Mechanics.”

**Problem:** The candidate correctly protects product authority but still leans
toward retaining a deliberate library for request correlation, cancellation,
framing and observations before subtracting the responsibilities already supplied
by the chosen executor/RPC. A library that simply renames every dependency
operation can become an extra compatibility layer without owning a coherent
invariant. Calling callbacks `prepare`, `publish`, `drain` and `retire` would also
allow an autonomous coordinator to reappear by interface indirection.

**Counterexample:** A stateless task provider uses workerpool's task execution,
queue, result/error transport and cancellation. The existing GM kernel owns local
phase/token bookkeeping. The product operation owns its durable command and
publication. If the residual code only adds product artifact IDs and maps errors,
there is no evidence for another request-correlation subsystem or runtime
generation manager. Conversely, an independently useful finite message validator
that rejects wrong-incarnation results and preserves cancellation/outcome
distinctions could be a real shared concern.

**Remediation:** Retain the library-first intent, but make the next design present
an ownership subtraction table: exact mechanism already supplied; exact invariant
still shared; external use without GM/EF/Temporal/organization credentials;
per-instance state; public inputs/outputs; and the real second use or concrete
repeated need. Count standard-library operations and upstream APIs as reuse. A
reusable adapter or conformance kit can be sufficient. Do not require a daemon,
registry, scheduler port, rollout DSL or new repository simply to make it look
like a library.

**Recommended disposition:** adopt as a refinement to the recommendation, not a
rejection of a new repository. Selecting/publishing a new package remains blocked
until its actual responsibility and admission are concrete. Research can finish
now by recording that conditional conclusion.

### F2 — High: a task pool does not automatically preserve the proposed worker-generation profile

**Locations:** `replacement-reuse.md` Piscina/workerpool sections and comparative
spike; EF `hot-reload-and-generation-replacement.md` fixed envelope and per-generation
worker protocol.

**Problem:** “One pool per generation” is not equivalent to “one initialized
worker/execution incarnation per generation.” Pool policies can create several
instances, recycle idle instances, replace workers, or terminate a worker when
cancelling one task. The report acknowledges intentional replication but does not
yet define the corresponding readiness/incarnation/retention model.

**Counterexample:** A pool initialized with defaults starts multiple workers
according to available CPU capacity, while the Host reports one worker per active
generation. Or cancelling one task kills its worker, after which another accepted
operation reaches a new worker instance under the same pool label. A readiness
receipt for the first instance cannot prove the later instance's readiness or
custody. Treating pool `drain` as retirement remains wrong even if the queue is
empty.

**Primary recheck:** Current official Piscina API docs describe CPU-based
min/max thread defaults, idle retirement, and cancellation of a running task by
stopping its worker. They also say abortable tasks cannot share a thread. These
are moving-doc observations, not verified behavior of the inspected release
tarball. This does not disqualify Piscina; it makes the adapter profile a real
selection question. [X1–X3]

**Remediation:** Start with the direct Worker implementation as the semantic
baseline. For the pool experiment specify min/max worker count, task concurrency,
queue ownership, immutable script, restart/respawn behavior, per-incarnation
readiness and disposition of every accepted operation. Test cancellation of one
request while another is pending, crash/replacement during old-work drain, and
worker creation after quiesce. If the selected pool cannot expose the necessary
facts through supported APIs, choose direct Worker rather than deep-importing or
building a parallel supervisor. A pool may win for a deliberately replicated
stateless task profile; that is an explicitly revised profile.

**Recommended disposition:** add this rejecting scenario to research now. Block
executor selection, not the documentation or the whole architecture. Neither
direct Worker nor Piscina is qualified yet.

### F3 — Medium: “additional” and “net” Temporal LOC are being treated as the same quantity

**Locations:** `temporal-adapter.md` alternatives table, particularly
`+600–1,400 net; 3,600–6,900 total`, and the preceding “common floor” paragraph;
the different integration/release columns in `rust-language-boundary.md`.

**Problem:** The base estimate includes product publication/admission/recovery
wiring. Temporal can replace some driver timing, wake-up and retry work while
adding adapter, workflow and deployment work. No component-level subtraction is
shown, so a positive adapter estimate cannot honestly be called a demonstrated
net increment. “These rows may substitute” does not repair arithmetic that adds
all of one row to the full baseline. Likewise, a release/configuration column
must be described as additional or included before readers compare totals.

**Counterexample:** In an already qualified Temporal deployment, 700 lines of
existing driver code disappear and 900 lines of integration are added. The net
is 200, not 900. In another product there is no driver to remove, so all 900 are
additional. Both fit the recommendation but imply different total ownership.

**Remediation:** Label the current +600–1,400 as **gross adaptation allowance**
unless the direct driver being replaced is separately bounded. Give a broad
complete-slice budget without claiming known net savings, or show retained base
+ adapter – removed driver. Keep native keeper development, GM release/adoption
qualification, installer/security qualification and shared infrastructure outside
small glue estimates explicitly. Report handwritten production/configuration
versus tests separately; do not subtract removed source from new/reworked source
and call that delivery cost.

**Recommended disposition:** correct before these numbers become a user-facing
comparison. This is a documentation correction, not an owner decision or an
implementation blocker.

### F4 — Medium: no new library must be inferred from an incomplete reuse inventory

**Locations:** `replacement-reuse.md` “most portable reusable part” and admonition
against bespoke RPC; the transport-only cost rows.

**Problem:** The report investigates execution pools well, but its candidate
residue includes RPC/correlation mechanics without comparing an existing
message-RPC library directly. The report's own instruction to avoid bespoke RPC
should apply to that residue. This is a coverage gap, not proof a better complete
replacement library was missed.

**Counterexample / primary counterevidence:** Comlink already offers
`postMessage` RPC and a Node worker adapter, under Apache-2.0. Its proxy/reference
and finalizer facilities also make it a poor source for any automatic-retirement
claim: releasing a proxy is not proving cleanup or remote absence. A narrow
data-only invocation surface might reuse RPC while excluding proxy escape. Its
current README is moving documentation; no exact release/package train was
verified in this critique. [X4]

**Remediation:** Do not add a broad library survey. Add one concrete RPC reuse
comparison if the implementation proposal still contains custom correlation or
transport. Check supported public APIs, limits/cancellation/EOF behavior and the
ability to prevent long-lived function/object escape. Reject it explicitly if
the adapter cost exceeds direct messages. The first library-first delivery then
owns only demonstrably missing semantics.

**Recommended disposition:** record the bounded gap and comparison trigger now.
Not a blocker for the research report. Any claim that the generic residue must
be newly implemented is premature.

### F5 — Medium: ordered-many is not yet an around-behavior execution contract

**Locations:** `customization-scale.md` “Compose steps around behavior” row and
author qualification scenarios; EF ADR-0014 dependency cardinalities.

**Problem:** The supplement correctly makes execution semantics owner-defined.
The next implementer could still read deterministic ordered bindings as a
ready-made middleware model. ADR-0014 expressly says ordered-many defines
cardinality/order, not retries, concurrency or execution. It cannot supply
effect/cancellation semantics through the binding algebra.

**Counterexample:** Two hooks each invoke `next()` twice, one retains `next`
past request completion, and one short-circuits after an external mutation. The
profile has a perfectly deterministic provider order while the business effect
and lifetime contract is undefined. Another failure is a middleware extension
receiving authority broader than the provider it wraps.

**Remediation:** For the first actual around-behavior seam specify whether next
may be called zero, once or more; whether it may escape; short-circuit/result
ownership; error and cancellation propagation; and grants at each host-mediated
effect. This belongs to the consuming capability contract. Do not implement a
universal middleware engine in GM or EF. If no real requested seam needs this,
keep it an example of a possible profile rather than first-delivery scope.

**Recommended disposition:** retain the supplement, add this counterexample to
the scoped qualification guidance. No owner discussion is needed to keep these
semantics out of GM; choosing a genuine product hook does need its owner.

### F6 — Medium: a preferred Protobuf direction is not an approved keeper wire contract

**Locations:** `rust-language-boundary.md` recommendation and narrow native-process
section, which describe an “approved cross-language Protobuf contract.”

**Problem:** The recovered owner preference supports Protobuf for real public or
service boundaries. It does not demonstrate an existing selected keeper schema,
handshake or production transport. AR's actual custody follow-up still lists
private IPC, launch identity/authorization, descriptor transfer, lost-ACK and
binary/protocol qualification as discussion work. The root independently found
ADR-0001's sequencing rule that public Protobuf/ConnectRPC/SDK schemas follow
stabilized domain and recovery contracts. No contrary keeper protocol authority
was found in this review.

**Counterexample:** An implementer treats a generated Protobuf message ID as
native process authority or selects gRPC automatically, while actual authenticated
local bootstrap, inherited handles and recovery readback remain unspecified. A
codec choice alone proves none of them.

**Remediation:** Say **preferred encoding direction for an eventual justified
cross-language boundary**; identify the keeper's exact schema, transport and
compatibility evidence as unqualified/unpublished. Preserve synthetic bounded
NDJSON as historical evidence, not the production API or a competing public
contract. Stabilize command/recovery semantics before choosing generated wire
shapes. Protobuf does not require gRPC/ConnectRPC or a wire boundary between
ordinary in-process TypeScript modules.

**Recommended disposition:** accept the root's proposed correction before
curation. This blocks a claim of existing protocol approval, not the research or
native-component direction.

### F7 — Low: the ratings are scoped judgments and must not become cross-scope reliability rankings

**Locations:** all alternatives tables, especially native keeper/process 9/10
versus trusted worker 8/10; static restart 8 or 9 in different reports.

**Problem:** A stronger failure boundary and a higher general reliability rating
are different claims. A process has a materially different operational surface,
while restart has a different availability promise. The reports label ratings
as engineering judgment, which is good, but readers may still infer that Rust or
processes are categorically more reliable. No equivalent-workload comparison
supports that inference.

**Counterexample:** A trusted bounded CPU-free provider meets its request promise
in a worker; the equivalent process profile fails binary installation or version
negotiation on one supported Desktop target. For that product the stronger
potential isolation boundary did not produce more reliable delivery.

**Remediation:** Rate alternatives against the same selected promise, keep
physical fault containment as a separate property, and give “not comparable” or
a separately scoped row when the promise changes. Do not average report scores
or imply decimal/one-point precision. State that historical LOC/rating scopes
are preserved rather than newly measured.

**Recommended disposition:** qualification to retain in the synthesis, not a
reason to reject alternatives or rerun benchmarks now.

## The admission gates coexist; this is not an unresolved owner conflict

The following are materially different evidence claims. None can be used as a
shortcut for another.

| Claim | Relevant evidence / authority |
| --- | --- |
| Deliberately shared ordinary mechanism | Current central standard: one owner, real consumer plus ordinary disposable projects in its first delivery; product is not an incubation copy. |
| EF source/package admission | EF architecture overview: exact accepted owner/package identity, populated implementation, current topology and independently verified admission evidence; ordinary-library and independent release/deployment bases are recognized. |
| Exported internal/candidate mechanism | Can be exercised through the intended public root in packed disposable projects without constituting a stable extension SPI. Candidate/source/publication claims remain separate. |
| Stable public extension SPI | EF OD-003/ADR-0011 retained floor: real slice, stable owner, two independently authored conforming implementations, compatibility/negative fixtures, executable conformance and accepted publication decision. |
| Production EF adoption in Orchestrator | OD-041's two independent product integrations and distribution/trust/lifecycle evidence, irrespective of an EF-local ordinary-library gate. |
| Existing GM lifecycle candidate/release/adoption | ADR-0029's exact candidate identity, packed evidence and staged gates; a different package cannot copy/move/release it by implication. |

EF's architecture overview is more precise than the compressed AGENTS sentence:
it expressly distinguishes ordinary-library package admission from public
extension SPI publication. A callback fixture and a worker fixture can qualify a
small mechanism and test oracle. They do not become two independently authored
SPI implementations when both delegate the defining semantics to the same hidden
code. Two products using that code can prove integration independence without
being two implementations. Use the evidence label appropriate to the claim.

One coherent same-delivery candidate with a real authorized slice and packed
external fixtures avoids the supposed “cannot prove consumer until published /
cannot publish until consumer” loop. It does not require publishing first or
deep-importing the currently private GM candidate. The package/adoption approvals
still occur through their actual owners.

## What the independent library could genuinely own

The current GM kernel is already composition-independent. Its zero runtime
dependencies and local WeakMap token membership are actual source facts, not a
promise of a separate asynchronous runtime. Its accepted name/location can be
retained without requiring a universal consumer to compose with GM Core or
Assembly. Do not invent another generation/token/phase model simply to give a
new package content.

A plausible residual library responsibility is a **finite, per-instance,
generation/incarnation-bound data protocol**, including validation/limits and
observable request/cancel/result distinctions not already supplied by the
executor. Its independence is tested by an ordinary external project. It should
not require product durable records, artifact trust, scheduler selection or
native credentials to import/use the mechanical subset. Its optional product
adapters translate those facts; they do not create default authorities.

This remains conditional. If the executor/RPC and selected codecs already own
that contract adequately, a few typed mappings and a reusable conformance kit
may be all that is left. There is no obligation to fill a new repository. If
several products demonstrably need the same nontrivial invariant, implement one
library from the outset rather than local copies. Repository independence,
package independence, authority independence and deployment independence are
separate choices.

## Best proposal and strongest alternatives

The recommended dynamic slice keeps **one product lifecycle operation as the
coordinator**, the existing kernel as the local admission/custody fact owner,
and the chosen execution owner as the source of physical observations. Durable
scheduling is an optional adapter of that operation. The native custody
implementation may live in separate neutral repositories while the consuming
product retains its authority: physical ownership moves as one complete
lifecycle, instead of adding a second actor controlling the same process.

The strongest same-promise alternative is the identical authority/protocol using
a fitting commodity task pool. It wins only if its supported lifecycle actually
reduces maintained code under the selected profile. The strongest simpler
product option is controlled restart with build-time/static extension selection.
It can provide substantial customization without forks; it offers a different
update-availability promise.

Scores below are /10 judgments; complexity increases with burden. LOC means new
maintained nonblank handwritten production/configuration versus tests/fixtures,
not dependencies/generated messages, docs or total existing source. Total rows
refer to ONE bounded capability cohort with existing product persistence,
authorization, durable operations and appropriate execution ownership. Missing
prerequisites invalidate the totals. Ranges overlap and must not be summed.

| Alternative and exact scope | Confidence | Achievable reliability | Complexity | Production LOC | Test/fixture LOC |
| --- | ---: | ---: | ---: | --- | --- |
| Direct Worker + existing kernel + existing product operation, complete bounded trusted read-only profile | 7 | 8 | 6 | 3,000–5,500 total | 5,000–9,000 total |
| Same promise through a fitting Piscina/workerpool profile | 6 | 8 | 6 | 2,500–5,500 total | 4,500–9,500 total |
| Small genuinely shared protocol/validation adapter within either total | 6 until subtraction/real slice | 8 within finite contract | 3 | 200–700 within total | 600–1,600 within total |
| Pure static/build-time owned contribution/provider seams and controlled restart | 9 | 8 within restart promise | 3 | 250–700 for one extension family | 500–1,200 |
| Optional Temporal adaptation on already qualified infrastructure | 8 for fit | 8 for same Host promise | 7 complete slice | 600–1,400 gross adaptation allowance; net/total unproven | 1,200–2,500 gross, reuse/subtraction unproven |
| Thin adapter to an already qualified native custody component | 7 | 8 for same bounded promise; physical evidence stronger where qualified | 6 | 300–700 incremental TS, release work extra | 800–1,800 incremental |
| New broad cross-platform coordinator, mutable rebinding, private-state migration | 3 | 5 before narrower contract | 9 | 8,000–16,000 before domain migration | 12,000–24,000 |

The small shared-mechanism estimate is a proposed bounded responsibility, not
evidence that an extra package is necessary, available or admitted. It is inside
the full protocol estimate. Kernel release/adoption and native custody migration
are not purchased by adapter lines. The retained AR 8k–13k production / 10k–18k
test migration estimate is historical, separate, not started and not a plugin
mechanism estimate. Existing user-approved separate native-component direction
must be preserved without relabeling that deferred source as production-ready.

## Independent answers to the remaining common questions

**Temporal and offline operation.** The report keeps Temporal off the ordinary
request path, preserves application command identities, and handles Activity
retry/unknown outcomes correctly. This is the right boundary. Temporal can remove
durable scheduling work; it cannot replace canonical admission, exact local
reference custody or OS evidence. ADR-0027 already selects its adapter role;
OD-035 excludes a bundled local Temporal service and retains a distinct local
qualification track. Do not introduce Restate/DBOS/Dapr solely to avoid this
bounded adapter. The current-versus-historical OpenWorkflow correction is useful;
the old missing-feature list must not be repeated as current fact.

**Rust.** The native report correctly distinguishes safe-memory benefits from
protocol correctness, addons from process containment, Wasmtime from Extism JS,
and OS custody from policy. Its new-language checklist and the root's lasting
language guidance are proportionate. Preserve ordinary TS/strict typechecking
and the selected TS7.0.2+ baseline without claiming a moving guideline upgrades
every approved pin. The process boundary can improve physical custody even with
TS policy; rewriting the pure existing kernel supplies no demonstrated benefit.
AR's already identified custody direction is the actual native follow-up owner.
Do not create an extra keeper because its repository names currently return 404.

**Customization.** Small owned contribution points, explicit provider selection,
plugin-owned extension points, protected product invariants and controlled
build-time variants can provide substantial customization. No evidence suggests
that thousands of authors require a universal plugin interface or service bag.
Provider and consumer compatibility are separate promises; packed combinations,
duplicate identity packages, configuration provenance and clear rejecting
diagnostics matter more than adding generic hooks. A missing extension point can
need an upstream contract change; “without forks” cannot mean every future request
is already supported. Pool/read-only cohort work is not a substitute for UI,
session, stream or plugin-to-plugin lifetime semantics.

**Scale.** The root's 200,000-instance example is valid arithmetic under its
explicit assumptions, not evidence that this topology is required. Descriptor,
graph, instance, tenant, version, realm, work and churn counts must remain
separate. The N1000 source-check update is correctly distinguished from compiler
and runtime qualification. No thousand-plugin runtime claim or per-descriptor
worker/Temporal deployment should follow. Reusable Host cost is paid once per
mechanism/profile, not for every statically declared module.

**Sources and support envelope.** The researchers generally separate pinned
source, moving documentation, prior tests and inference well. Preserve the
Piscina release-tag/package-version discrepancy and SDK default-cancellation
conflict rather than smoothing them into stronger claims. Do not promote
repository activity, README assertions or a historical spike into current
support. Comlink and Piscina facts added in this critique are moving official
documentation observations only. Adoption must resolve exact archives, licenses,
supported versions/features and the actual Desktop runtime; a second broad
research campaign is unnecessary to update the documentation honestly.

## Bounded evidence that can change the choice

Use one independent packaged read-only capability and the same authority model to
compare direct Worker with one task-pool adapter. Add workerpool only if the first
cross-target delivery makes its portability useful. Run the smallest experiment
that answers the pool-incarnation and ownership questions: slow accepted call
across publication, candidate failure, cancellation with another accepted task,
worker crash/respawn, lost acceptance ACK, pending finally, stale result and a
short varied churn sequence. Observe actual execution identities, task outcomes,
retained owners and resource stabilization. No second operation store or
supervisor is needed. Reuse unchanged retained qualification inputs where valid.

For the common library boundary, the decisive external fixture is an ordinary
project using the same proposed public root without org credentials or GM
composition. It should expose whether the contract is a reusable mechanism or
just a callback facade over product decisions. Use an independent oracle; do not
generate expected phase/outcome decisions from the implementation under test.

For author experience, independent authors should add one contribution, select a
replacement, diagnose a conflict and upgrade a packed provider. Count changes
outside the owning feature, hidden conventions and actionable diagnostics. Do not
add all proposed customization categories to the first dynamic slice merely to
make a broad checklist pass.

## What really needs an owner answer

1. **First actual capability and promise:** is it overlap-safe/read-only/bounded,
   which placement and availability envelope matter, and why is dynamic update
   needed rather than restart?
2. **Shared mechanism owner and admission:** if the subtraction demonstrates a
   real library, select the existing owner or separate repository, exact package
   identity and initial source/adoption scope. OD-003 already reserves this
   concrete discussion; no extra general approval ritual is required.
3. **Concrete operational joins:** which current product admission, dispatch,
   publication and recovery boundaries implement the promised slice, and which
   dependencies are actually available/qualified? This is partly source inspection
   and partly feature ownership, not a fresh debate over accepted GM/FMS or
   Temporal direction.

Do **not** ask the owner to settle questions that the current sources answer:
whether the GM kernel is composition-independent; whether local tokens are
distributed fences; whether an ordinary library export equals a stable extension
SPI; whether read-only workers need native Host Custody by default; whether
Node/browser exit evidence is identical; or whether the first artifact count
proves runtime scale. These are already settled or technical facts.

The current documentation may state open implementation decisions and finish.
It should not stop on a native migration, new package publication, two new
production implementations, or an N1000 runtime campaign. Conversely, calling
those gates future work is not permission to skip them when the corresponding
production/public claim is eventually made.

## Source register

All added external observations retrieved 2026-10-22. Internal source references
below identify the actual reviewed checkout authorities, not new remote-head
verification. Earlier source pins in the research remain historical evidence.

- **A1:** [Central quality standard at retained baseline](https://github.com/agent-teams-ai/.github/blob/d17901e6975fdb4388b1f75cad901e7f448aebbe/docs/engineering-quality-standard.md): library-first, universal identity, same-delivery real consumer/external projects and accepted-owner preservation. The language guidance reviewed was the root's draft added to the local checkout.
- **A2:** [GM ADR-0029](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md), [kernel README](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/packages/lifecycle-kernel/README.md), [actual kernel](https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/packages/lifecycle-kernel/src/features/lifecycle/kernel.ts): independent zero-dependency local candidate and release limits.
- **A3:** [EF architecture overview](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/architecture/overview.md): package-admission bases, populated implementation/evidence checks and ordinary-library versus public-SPI distinction.
- **A4:** [EF ADR-0011](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0011-extension-admission-custody-and-retirement-closure.md), [ADR-0014](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0014-product-local-module-authoring-composition-and-generation-guardrails.md), [ADR-0015](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0015-authorize-get-modular-semantic-extraction.md), [OD-003](https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md): immutable composition, shared-mechanics TODO and operational/publication boundaries.
- **A5:** Orchestrator reviewed `477b3445c4c66416121559894cf6f393c9450c72`, accepted ADR-0110/0027 and OD-005/035/041/043 in `docs/`: static adoption, adapter ownership, historical Temporal evidence and stricter EF production integration gate. Exact paths are in the source reports and shared checkout.
- **A6:** [AR deferred Rust follow-up](https://github.com/agent-teams-ai/agent-runtime/blob/8d89b28f07426846b3ded7c6bd933363d9dc468c/docs/architecture/rust-custody-migration-follow-up.md), [optional default](https://github.com/agent-teams-ai/agent-runtime/blob/8d89b28f07426846b3ded7c6bd933363d9dc468c/docs/architecture/host-custody-optional-default.md): actual custody owner, historical migration estimate, default-off profile and no started migration. Restored user direction for separate components is supplied task context, not inferred from a released repository.
- **X1:** [Piscina instance API](https://piscinajs.dev/api-reference/Instance/), moving official docs: min/max/idle and queue settings; not a selected package pin.
- **X2:** [Piscina methods](https://piscinajs.dev/api-reference/Methods/), moving official docs: active-task abort stops its worker; abortable tasks cannot share threads. The report's pinned implementation observation about close timeout remains distinct.
- **X3:** [Piscina readiness](https://piscinajs.dev/getting-started/Managing%20Worker%20Threads/), moving official docs: readiness may wait on the module-exported Promise. This is worker readiness, not product canonical authorization.
- **X4:** [Comlink official repository README](https://github.com/GoogleChromeLabs/comlink), moving main: message RPC, Node support, Apache-2.0, proxies and release/finalizer behavior. No exact current release, tarball provenance, compatibility or runtime conformance was established here. Direct pinned raw endpoints for the other projects were unavailable through this critique's browser lookup, so no new exact-source verification is claimed for them.

The candid result is a conditional library recommendation, a strong existing
ownership structure and a useful narrow qualification target. The research is
ready to improve the governed record after these corrections. It is not ready
to select a new universal runtime or promise the entire ecosystem's performance.
