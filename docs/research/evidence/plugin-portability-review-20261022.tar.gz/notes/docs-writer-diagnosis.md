# Docs Protocol writer diagnosis and supported continuation

Observed 2026-10-22. This note is intermediate diagnostic evidence outside both
repository checkouts. It does not change the Docs Protocol or authorize manual
repair of transaction evidence.

## Result

The exact previously approved writer operation succeeded in a clean independent
clone under `/tmp/plugin-docs-followup-20261022`, using the same base commit,
frozen dependency graph, Node, pnpm, metadata, template and Plan digest. A
subsequent repository `pnpm docs:doctor` returned success and `Transaction: idle`.
The original failed checkout, its published document, transaction journal and
cleanup evidence were preserved. No dependency, gate or transaction evidence was
edited. No governed document was hand-created.

Continue research authoring in the successful clone:

- Checkout: `/tmp/plugin-docs-followup-20261022`.
- Branch: `docs/plugin-portability-followup-20261022`.
- Base: `466e35a62481a6b21f2062524bb92c7eb221bb8c`.
- New document: `docs/research/reusable-generation-mechanisms-and-ownership.md`.
- State at handoff: only that document was untracked; its content remained the
  exact generated research template.
- Required manual reachability action reported by the writer: add
  `[Reusable Generation Mechanisms and Ownership](research/reusable-generation-mechanisms-and-ownership.md)`
  to `docs/README.md`.
- Remaining editing, navigation, bounded context refresh, `docs:check` and full
  `docs:protocol:check` belong to the parent research task and have not yet run.
- The local clone's `origin` points at the original local checkout. Set the
  intended canonical GitHub remote before pushing; do not push to the failed
  original checkout.

## Applicable procedure and preserved original failure

Read `.agents/skills/docs-authoring/SKILL.md`, `AGENTS.md`, the retained current
organization Engineering Quality Standard, the installed document-authoring
README, and the relevant installed mutation/recovery sources. The skill requires
repository scripts, identical preview/apply inputs, doctor before recover, and
prohibits hand-editing transaction evidence. The recovery classifier deliberately
returns a manual decision for any unverifiable identity. It does not authorize
optimistic cleanup based merely on byte equality.

Original checkout:
`/workspace/scratch/f863b9d38368/research/plugin-portability-2026-10-22/repos/extension-foundation`.
Its branch/base were `docs/plugin-research-hot-reload-20261021` /
`466e35a62481a6b21f2062524bb92c7eb221bb8c`.
Parent-reported prior commands: exact preview succeeded; apply published 861
bytes and exited recovery-required at final verification; doctor identified the
exact installed recovery artifact; recover returned `unverifiable-identity`.
This diagnosis did not rerun recovery or mutate the failed checkout.

Read-only inspection confirmed the original journal envelope remains `PUBLISHED`:

- Path: `.agent-teams-local/scaffolding-transaction.json`.
- Size: 4,828 bytes.
- SHA-256: `d2e5ad5596da284401119e692692f9b7bb2f95e2e9e57128a8f24395350fed1b`.
- Operation: `document-authoring`, recovery handler contract 3.
- Authoring artifact: `@agent-teams/document-authoring@0.3.2`, build
  `sha256:fc1838b771c929a02ea715ffd17da360a06bde70d634d374db13c681baa92747`.
- Mutation artifact: `@agent-teams/repository-mutation@0.2.2`, build
  `sha256:3b42f99134577c3b1b5178468b9454b0d2a96b3fb8aa5c6dd1e90125649df7f6`.

An empty directory remains at:

```text
docs/research/..foundation-document-15588bddc06362e0743fc83d74cd0286afa51996a1716fc3c85490cb319f2dbe.tmp.foundation-owned-cleanup-a0d920df-91ff-49e5-a2ef-69e5428ce236
```

The retained owned temporary is instead at:

```text
docs/research/.foundation-retired-evidence-/a0d920df-91ff-49e5-a2ef-69e5428ce236/owned-temporary
```

That retained file and the published destination each contain 861 identical bytes
with SHA-256
`4763e85c00e8c98089910b4798d515ba5a3168a62563bb76f960db2cdbfef0e6`.
This fact alone does not clear the recovery barrier.

## Source-backed causal diagnosis

The installed `recapture-document-publication-paths.js` enumerates every
publication path ancestor and rejects any entry whose name contains
`.foundation-owned-cleanup-`, without inspecting whether that entry is empty.
It throws `A document temporary cleanup residue was preserved for manual recovery.`
The file-state adapter catches that error and reports an unverifiable state.
`classify-document-recovery.js` maps an unverifiable destination or temporary to
`{ action: "manual", reason: "unverifiable-identity" }` before considering the
otherwise exact PUBLISHED destination.

The installed `node-cleanup-owned-temporary.js` captures the temporary into a
private quarantine directory, then logically retires the entire directory with
`rename(quarantineDirectory, retiredDirectory)`. It intentionally preserves
terminal evidence instead of using a pathname-based unlink. The normal source
code route does not retain an empty source quarantine after successful rename.
The original observed empty source and retained terminal destination explain
why subsequent state recapture rejects the original checkout. The exact reason
that source directory survived is not proven by this investigation.

The successful exact retry in `/tmp` provides a supported continuation and is
consistent with filesystem/environment-specific behavior. It does not prove a
general filesystem defect or establish that the original evidence may safely be
removed. No supported original-checkout residue-cleanup command was found in the
reviewed installed recovery route. The original remains owner/manual recovery
work and should stay preserved for a tooling-owner investigation.

Read source hashes (paths relative to each named installed package's `dist/`):

| Package | File | SHA-256 |
| --- | --- | --- |
| document-authoring 0.3.2 | `document-authoring/adapters/node/recapture-document-publication-paths.js` | `20378067e7d46b043df5f546b013d8898c791f8e16d31fd71d91e5beb907e13e` |
| document-authoring 0.3.2 | `document-authoring/application/policies/classify-document-recovery.js` | `6f63360d1c3459f66570e678ea0880ceb572ddbf00c133808f27921cb2cfcb97` |
| repository-mutation 0.2.2 | `repository-mutation/adapters/node/node-cleanup-owned-temporary.js` | `c5400e40653a241888783f8cf37fa9389190d456e1b95ebbfa2767a8cb207fd2` |

## Minimal successful continuation trace

1. `git clone --no-hardlinks --branch docs/plugin-research-hot-reload-20261021 ORIGINAL /tmp/plugin-docs-followup-20261022`.
2. Inside the clone, `git checkout -b docs/plugin-portability-followup-20261022 466e35a62481a6b21f2062524bb92c7eb221bb8c`.
3. With `/tmp/plugin-portability-toolchain-20261022/bin` prepended to PATH,
   `pnpm install --frozen-lockfile`. The first sandboxed install stopped before
   installing with `unable to open database file`; repeating the same frozen
   install through approved escalation and `NODE_USE_ENV_PROXY=1` succeeded.
   All 262 packages were reused; the dependency graph was unchanged.
4. `pnpm docs:info` succeeded and confirmed research/architecture ownership,
   the existing research template, active initial status, and manual fixed index.
5. `pnpm docs:find -- --text generation` succeeded with 52 matches, including
   existing research and accepted authority.
6. Exact preview command below with `--dry-run` succeeded. Reviewed destination,
   generated metadata, empty relations/anchors, template and manual index action.
7. Identical command with `--apply` succeeded, exit 0.
8. `pnpm docs:doctor` succeeded, exit 0, authoring build unchanged, filesystem
   `platform-supported`, transaction `idle`.

```sh
pnpm docs:new -- \
  --type research \
  --id research.replacement-reuse \
  --title 'Reusable Generation Mechanisms and Ownership' \
  --owner architecture \
  --summary 'Reuse evidence and ownership choices for an independent generation replacement mechanism.' \
  --apply
```

Both previews and successful apply bind Plan:
`sha256:15588bddc06362e0743fc83d74cd0286afa51996a1716fc3c85490cb319f2dbe`.

Both checkout lockfiles remain 94,819 bytes with SHA-256
`a947cfe3f4d5db4877124f04a822e7bf4d88a98852003d243bb92cd31e136c48`.
Node/pnpm are the supplied Node 26.11.1 / pnpm 11.18.0 toolchain.
The successful generated template is the exact same 861-byte output as the
original published document, SHA-256
`4763e85c00e8c98089910b4798d515ba5a3168a62563bb76f960db2cdbfef0e6`.

No repeated broad experiment, dependency patch, gate reduction, manual
transaction-evidence edit, or manual governed document creation was performed.
