# Final independent evidence review: portability, reuse and customization

Review cut: **2026-10-22**. Reviewer: fresh final evidence critic. This is research
criticism and one narrowly authorized rejecting experiment, not production
qualification, dependency selection, public-SPI approval or an amendment to any
accepted decision. Root owns the governed document edits; this reviewer did not
edit those documents or the curated notes.

## Verdict

**Include the research after preserving the corrections below. Do not promote
either task-pool shutdown API into successful retirement evidence.** The retained
eight-case worker-adapter experiment is valid for its exact cases and package
identities, with the declared TypeScript dependency-check caveat. One additional
two-worker case now demonstrates that published Piscina **5.3.2** can fulfill
`close({force:false})` without a timeout error while terminating another running
task whose barrier was never released. This is a material new limitation of the
multiworker recommendation; it does not invalidate the unchanged one-worker
observations.

The architectural direction otherwise survives criticism: ordinary TypeScript
modules, explicit consumer-owned ports and immutable composition; the existing
GM synchronous lifecycle candidate rather than another kernel; shared mechanical
implementation where an actual residual concern remains; Temporal through an
optional scheduling adapter; and native custody through the existing physical
owner rather than a second supervisor. Deep customization does not require
every ordinary extension author to implement durable lifecycle machinery. Scale
claims still need denominators and selected-topology evidence.

## Review scope and evidence discipline

I read the shared brief, all four curated supplements, `worker-adapter-spike.md`,
`critic-customization-scale.md`, the retained final/repeat logs, harness and worker
sources, effective TypeScript settings, identity/integrity records and relevant
installed Piscina/workerpool source. I independently recomputed both retained
tarball SHA-256 and SHA-512 identities, inspected their manifest versions, and
verified all files in the original `source-sha256.txt` against their recorded
hashes. Those identities match. I inspected Comlink's retained pinned source,
protocol and tag/registry identity. I did not fetch or execute its npm archive.

I also read relevant repository authorities: EF `AGENTS.md`, ADR-0011/0014/0015
and OD-003; GM ADR-0029 and kernel README; Orchestrator ADR-0027/0110, OD-005/035 and
OD-041; current central quality/language guidance and backend stack reference.
The exact source pins already retained by the research remain its provenance.
This report is not a claim to have independently audited every upstream version,
license, advisory or moving webpage in all four researcher ledgers.

Primary pinned Temporal and Comlink web opens returned tool `DisabledError`;
ordinary direct network retrieval also failed at the environment proxy. I did
not invent substitute contents or claim a new current Temporal default check.
Comlink conclusions below are independently supported by the retained exact
source. Temporal's contradictory default annotations remain a disclosed
qualification uncertainty, with explicit cancellation recommended.

### New experiment identity

Separate directory: `../experiments/piscina-staggered-close/`.

- Exact runtime/dependencies: Node **26.11.1**, Piscina **5.3.2**, TypeScript
  **7.0.2**, Node declarations **26.6.5**, reused from the original frozen install.
- Ordinary strict `.ts` source, with inherited `noUncheckedIndexedAccess`,
  `exactOptionalPropertyTypes` and **`skipLibCheck:true`**. The latter has the same
  disclosed third-party declaration limitation as the original experiment.
- One compiled final fixture and one final runtime execution. No broad rerun,
  benchmark, dependency change or mutation of the original eight-case inputs.
- Retained source/config/effective-config/compiler/build/run/hash records,
  reproduction instructions and source explanation. An initial disposable
  scratch preflight failed metadata lookup through an unexported package
  subpath; its source/error are retained and it is not counted as passing.

## Findings requiring accurate research inclusion

### FE-01 — High: Piscina multiworker close can lose running work without a timeout error

**Exact affected document locations:**

- `reusable-generation-mechanisms-and-ownership.md`, “Piscina,” “Review outcome:
  repository choice and pool identity,” and the Piscina alternatives row.
- `worker-adapter-replacement-experiment.md`, outcome, fixture scope, decision
  implications, evidence archive and reproduction sections.
- Any hub, hot-reload or review-record summary describing Piscina as reusable
  graceful drain machinery without the exact single-worker scope.

**Executed evidence:** Both A and B are positively barrier-confirmed running on
two fixed workers before close. The fixture calls `close({force:false})` with a
1,000ms library timeout, then releases A only. Close fulfills during the separate
300ms observation race, with `errors:[]` and **two actual Worker exits**. A
fulfills and its finally marker becomes one. B rejects `Terminating worker
thread`; its release/normal-completion/finally markers are all zero at that
snapshot. Releasing B afterward does not produce completion/finally. The exact
log is `experiments/piscina-staggered-close/run.log`.

The fixture prints `cases:1,passed:1` because its assertion of this rejecting
behavior passed. It does **not** mean multiworker graceful drain passed, or that
the original experiment now has a ninth positive case. Keep the original
eight-case repeat separate.

**Source explanation:** Installed `src/index.ts` lines 704–730 use a scalar
`numberOfWorkersDone` counter, register `checkIfWorkerIsDone` once before the
worker loop and again inside every loop iteration, and increment whenever the
same completed worker has no taskInfos. There is no distinct-worker set.
`src/worker_pool/base.ts` lines 106–113 invoke every registered callback. For two
busy workers, the first worker's completion reaches the count and resolves
flushing; the `finally` path calls `destroy()` while B is still active. The
published compiled implementation carries the same logic. The installed archive
is already integrity-verified; the parent evidence also binds `src/index.ts` to
the inspected upstream commit. [P1,P2]

**Recommended text:**

> The unchanged one-worker fixtures make Piscina a credible task-execution
> candidate, not an approved executor. A separate exact two-worker rejecting
> fixture found that 5.3.2 `close({force:false})` fulfilled with no timeout error
> while terminating another running task. Fulfilled close plus an empty error
> list is therefore insufficient natural-drain evidence. Keep the initial
> candidate explicitly bounded to the exercised one-worker profile, preserve
> independent accepted-task accounting and require an upstream correction or a
> separately demonstrated Host strategy before promising multiworker retirement.

**Research inclusion blocker:** only if summaries omit or contradict this result.
The research itself should not wait for a fix. **Production adoption blocker:**
for a profile relying on pool close to finish accepted multiworker work. A Host
could instead seal admission and wait for all its accepted tasks before closing
the pool; that may fit existing accounting rather than add a new scheduler, but
that strategy was not qualified here. Do not silently fork/patch the library or
declare all one-worker sequences safe from one positive fixture.

### FE-02 — Medium: gross scheduling effort must not be labeled net

**Location:** `temporal-and-rollout-orchestration.md`, “Alternatives and effort,”
Temporal/OpenWorkflow/Restate/DBOS/Dapr rows and immediately following paragraph.

The reviewed original Temporal row said `+600–1,400 net; 3,600–6,900 total`, while
the prose correctly said the displaced direct scheduling work was not measured.
Those are inconsistent evidence claims. A conservative sum can be a budgeting
scenario, not an established total/minimum or measured marginal cost.

**Recommended text:** “600–1,400 gross adapter allowance; net difference unknown”
and “1,200–2,500 gross adapter/replay fixtures; subtract replaced scheduling work
before estimating a net total.” Use the same discipline for the other engine
rows. Do not add all scopes or charge shared Host machinery to every module.

**Disposition:** Root reported and current governed draft shows this corrected.
No new implementation or test is needed. This was a **research inclusion fix**,
not an adoption blocker.

### FE-03 — Medium: preferred Protobuf direction is not an approved keeper contract

**Location:** `critical-components-and-language-boundaries.md`, “Reuse shortlist”
`prost` row, read together with its opening and narrow Rust process section.

The original row called it an implementation of “the approved Protobuf data
contract,” although the surrounding text correctly says exact keeper schema and
transport remain open. AR's follow-up and ADR-0001 do not turn preferred encoding
into a selected production schema, handshake or recovery qualification. [A6]

**Recommended text:** “Codec/code-generation candidate for a future owner-selected
Protobuf contract; no keeper schema or transport is selected here.” Protobuf does
not automatically select gRPC. Internal TS modules remain ordinary owned ports.

**Disposition:** Root corrected this. It is a **research inclusion fix**. The
actual native contract remains a **production design/qualification question**;
do not stall the research or create a second supervisor to fill that gap.

### FE-04 — Medium/high: Comlink is concrete source reuse, with a narrow unqualified envelope

**Location:** `reusable-generation-mechanisms-and-ownership.md`, portable package
shape, Comlink paragraph and source ledger; related customization/reference-escape
guidance and review dispositions.

**Exact evidence:** Comlink 4.4.2, Apache-2.0; annotated tag resolves to
`fd4b52666b1ec62784f8b45cb1108c7e40bc481d`; retained npm metadata reports matching
version and gitHead. Its source supplies request IDs/pending listeners and proxy
transport. The pinned protocol has GET/SET/APPLY/CONSTRUCT/ENDPOINT/RELEASE,
**no task-cancellation message**. Release clears pending listeners, returns no
awaited drain to the proxy caller, and does not await a remote finalizer return.
Proxy/callback transfers can create additional MessageChannels. These are source
facts, not newly executed behavior or TS 7 qualification. [C1–C4]

This weakens any justification for writing correlation/proxy plumbing from
scratch; it does not delete product operation identity, generation validation,
bounded payload/queues, cancellation semantics or actual execution evidence.
Piscina already correlates task results, so wrapping its task API in Comlink
needs an additional actual requirement. A direct long-lived Worker control
endpoint is a more plausible comparison. Expose one narrow validated data
method; do not expose a Host/GM graph or claim public proxy release revokes every
escaped capability.

**Disposition:** Current governed draft now includes version/pin/license,
source-only caveat and correct release/cancellation boundaries. No research
blocker remains if that text stays. **Production qualifier:** ordinary packed
TS 7 consumer and selected transport/profile conformance only if Comlink is
actually selected. Do not install/test it just to finish this research.

### FE-05 — Medium: newest central local reference and historical product profile are separate

**Location:** `temporal-and-rollout-orchestration.md`, authority table,
deployment/portability table and OpenWorkflow local section.

The newer central backend reference at **86a85d6** selects native PostgreSQL for
server and fully local backend reference profiles, while leaving local workflow
selection separately owned. It expressly requires scoped consumer adoption and
preserves existing accepted ADRs. OD-035 and the product deployment profile at
**477b344…** still describe SQLite/OpenWorkflow local qualification. They are
different authorities at different adoption states. [A4,A5]

**Recommended text:** label the latter as that reviewed historical product
profile, link the new central reference and record that adopting PostgreSQL
locally requires the product's actual successor/adoption route. Do not rewrite
an accepted product decision from a `main` navigation link; equally, do not call
SQLite the organization's current universal local backend stack.

**Disposition:** Current governed draft now explicitly records this distinction.
No research blocker. Product local adoption remains its ordinary owner decision.

### FE-06 — High for scale claims: every cap needs a denominator and aggregate owner

**Location:** `customization-without-forks-and-scale.md`, resource dimensions and
capacity arithmetic; hot-reload bounded profile and operational budgets.

One active/candidate/predecessor limit per cohort does not bound a deployment.
Tenant/cohort count and pool replica count multiply workers, queues, artifacts,
cleanup debt and memory. The illustrative 100×20×3×1=6,000 workers is arithmetic,
not a measured capacity requirement. Installed descriptors do not imply resident
execution realms. Sharing a trusted realm changes failure/privilege/retirement
scope and cannot be treated as a free optimization.

**Recommended text:** name per-operation/endpoint/cohort/tenant/execution-owner/
host scope on every budget; use the existing product capacity owner for
aggregate workers/RSS/queues/artifacts/debt, without another generic manager.
The retained N1000 source-check result remains separate from the TS 7 compiler
blocker and runtime/tenant/churn qualification. [A2,A3]

**Disposition:** Current customization draft includes scoped and aggregate caps.
This blocks only unsupported **scale claims**, not research inclusion or ordinary
static module use. No broad thousand-plugin rerun is justified now.

## Claims independently upheld with explicit limits

### The original eight-case evidence is sound for its exact scope

The final/repeat logs each contain eight complete cases and their 8/8 summary.
Task-state cells, deliberately held readiness, explicit error handling, real Node
Worker exit listeners for direct/Piscina cases, and separate task/close promises
avoid the most common false conclusions. The original source hashes still match.

workerpool 10.0.3 `terminate(false,50)` fulfilled and invoked its termination hook
while the barrier-blocked task remained busy/unsettled; later release completed
it. `terminate(true)` separately rejected the task without finally. `exec`
submitted during graceful termination and afterward was accepted. Source
`terminateAndNotify(...).then(removeWorker).always(hook)` plus custom
`always(fn)=then(fn,fn)` explains timeout rejection becoming public fulfillment.
Keep the exact published gitHead 601124cf… for this execution, separate from the
earlier inspected source 17dbcc88…. [P3–P5]

Piscina's one-worker timeout also **fulfilled** after emitting its timeout error,
rejecting both tasks and observing actual Worker exit; finally did not run.
Neither library lets forced termination imply successful cleanup. The new
two-worker case adds that absence of a Piscina timeout error is insufficient,
too. A hook/stats snapshot is not promoted to Node exit where the public API did
not expose one.

The original full dependency declaration check failed inside published Piscina's
`FilledOptions` with `exactOptionalPropertyTypes`; final application checking
passed using `skipLibCheck:true`. That is accurately reported, not full strict
dependency qualification. Adoption needs the selected owner's declaration policy
resolved; it does not automatically require an upstream fix if that supported
profile explicitly permits ordinary third-party skipLibCheck. Never weaken a
repository gate silently.

### One useful library can exist without a second kernel

GM ADR-0029 already admits exactly one independent zero-runtime-dependency
synchronous local membership/lease candidate. It imports no GM Core/Assembly,
EF, Node or other runtime. A second FSM, private deep import or silent rename/
move is not justified by this research. [A1,A2]

Neutral reusable driver code can sequence product-authorized commands without
becoming a business authority. The test is its actual facts and authority:
kernel tokens stay with the kernel; canonical head/grants/receipts stay with the
product; workflow progress stays with its execution engine. A public reusable
package should demonstrate the semantics left after subtracting kernel,
execution and RPC mechanisms, in a real slice and ordinary external fixture in
the same delivery. A separate repository is an ownership/release choice, not
proof of independence. A facade over existing APIs alone is weak justification.

### Temporal remains an optional control-plane adapter

ADR-0027's ownership split is appropriate. Durable coordination can reuse timers,
retries/history/replay through narrow commands; it should not enter each ordinary
plugin invocation, own actual local promises, recover nominal tokens from a
database Boolean or create another outbox. Receiver-side scheduler epochs matter
because an old timed-out Activity can continue after provider switch. Coordinator
workers remain outside the closure they retire. [A3]

OD-005's prior two 35/35 runs are retained historical evidence, not new plugin
rollout qualification. Current source/docs disagreement over default cancellation
is correctly disclosed; select cancellation explicitly. WAIT completion at the
Activity record does not independently prove physical absence of uncooperative
execution or remote effects. No need to resolve an ambiguous default by another
experiment just to finish this memo.

### Selective Rust is strongest at the existing physical boundary

Rust can materially help native memory/OS-handle concerns or an actual bounded
computation/engine; it cannot fix acceptance ambiguity, unfenced writers, stale
scheduler commands or effect reconciliation. An addon shares the Node failure
domain; a process adds IPC/packaging/release/OS obligations; Wasm changes plugin
ABI and capabilities. Safe Rust is not a general distributed-safety proof.

Preserve separate keeper/init direction and the AR deferred migration status.
Unavailable proposed repositories are not installable components. Existing AR
synthetic spike reports deserve reuse/audit, not a claim of independent production
qualification here. ProcessKit/Tini/OS APIs are legitimate subtraction candidates;
a language preference is not enough to rewrite them or add another supervisor.
[A6]

### Deep supported customization is compatible with ordinary authoring

The vocabulary of owned contribution slots, explicit provider substitution,
needed ordered composition, plugin-owned points and build variants is strong
enough for deep supported customization. Deterministic ordering is not a `next`
execution contract; its owner must define escape, short circuit, effects and
cancellation. Alternative providers must preserve implementer as well as caller
compatibility. Protected invariants can have owner-selected replaceable
implementations; ordinary plugins cannot choose their own admission authority.

Ordinary contribution authors implement their narrow contract/declaration and
resource obligations, not durable CAS/admission/retirement machinery. Missing
seams can require an upstream contract change; restart/build-time replacement is
still useful modularity. The bounded read-only Worker qualification does not
qualify every UI/session/callback/plugin-to-plugin lifetime. [A1,A3]

## Independent planning judgments after the evidence correction

These are /10 ordinal engineering judgments, not measured availability.
Reliability applies to the same stated promise after qualification. Higher
complexity means more maintenance. LOC separates maintained handwritten
production/integration code from independent tests/fixtures; dependencies,
generated code, domain behavior, native component development, installers and
new authority infrastructure are excluded. Ranges are rough ±2×, overlap and are
**not additive**. Full Host estimates assume existing product operations,
transactions, authorization, receipts, dispatch/reconciliation and custody.

| Option / exact promise | Confidence | Scoped reliability | Complexity | Production LOC | Test/fixture LOC |
| --- | ---: | ---: | ---: | --- | --- |
| One ordinary extension family: contribution/provider seam, explicit profile, controlled restart | 9 | 8 | 3 | 250–1,000 | 500–1,800 |
| Complete initial bounded trusted one-worker cohort using existing kernel/product authority and direct Worker | 7 | 8 after qualification | 6 | 3,000–5,500 total | 5,000–9,000 total |
| Same one-worker task-shaped promise with fitting Piscina 5.3.2 adapter | 7 for bounded fit, not adoption | 8 after missing qualification | 6 | 2,500–5,500 total; savings unmeasured | 4,500–9,500 total |
| Current 5.3.2 multiworker `close` alone guarantees every accepted running task drains | 2 | 2 for that disproved promise | 6 | No reliable savings claim; change strategy/version first | Retained rejecting case, future focused fix proof only |
| workerpool 10.0.3 public terminate/hook alone guarantees admission seal and physical exit | 2 | 2 for that disproved promise | 6–7 | No reliable complete savings claim | Existing exact rejecting cases retained |
| Comlink data-RPC adapter inside a complete direct-Worker profile | 6 before real slice/TS 7 check | 8 for finite qualified protocol | 3–4 | 150–450 within total | 400–1,000 within total |
| New neutral residual invariant/driver library after subtracting existing mechanisms | 6 until concrete need | 8 within finite demonstrated contract | 3–5 | 200–800 within total | 600–1,800 within total |
| Temporal adapter on already qualified infrastructure | 8 for fit | Same Host ceiling; durable coordination benefit separate | 7 complete slice | 600–1,500 gross allowance; net unknown | 1,200–3,000 gross; net unknown |
| Adapter to already qualified native custody owner | 7 for boundary fit; availability open | 8 for same logical promise; containment separate | 6–7 | 300–800 incremental; component/release extra | 800–2,000 incremental |
| Global hooks/container access/mutable captured-reference replacement for arbitrary plugins | 2 | 3 for broad promise | 9–10 | No honest complete finite estimate | Unbounded lifetime/compatibility surface |

The low scores for **specific disproved pool promises** do not rate either
project's overall quality, browser usefulness or unrelated task features.
Restoring a sound Host strategy can preserve overall correctness by reporting
interrupted/unknown work honestly; that is different from promising seamless
completion. Direct Worker is also only a candidate and has no magic cleanup,
distributed fencing or hostile-sandbox guarantee.

## Stop conditions and remaining owner choices

Finish the research and its navigation/review dispositions now. The inclusion
conditions are accurate scope, exact identities, corrections FE-01–FE-06 and
retained evidence. There is no need to build the production runtime or execute
every proposed authoring/scale/native case to include useful research.

Production selection still needs one real capability and placement; exact
observable replacement promise; selected pool/transport strategy and supported
toolchain declaration policy; the already owned admission/publication/recovery
bridge; actual aggregate budget; the shared mechanism owner after subtraction;
and existing GM/EF/product qualification/publication gates. A real new privileged
seam or changed accepted authority needs its owning decision. Routine payload,
error mapping, diagnostics, documentation and fixture mechanics do not create
another approval ritual.

No further runtime case is requested by this review. Preserve the original eight
cases and repeat, plus this separate focused rejecting case. If production later
chooses a corrected multiworker strategy, its one changed risk deserves a focused
qualification then. Do not start another broad pool, native or thousand-plugin
campaign now.

## Primary evidence references

All source dates/retrieval observations are 2026-10-22 unless the retained ledger
explicitly says historical. Exact local logs/source/manifests are primary
experiment artifacts, not external testimonials.

- **P1:** Piscina exact inspected source, also byte-matched by the parent to
  installed 5.3.2 `src/index.ts`:
  <https://github.com/piscinajs/piscina/blob/6c7e54630a8c28a96ce5c0625b463d849d21171c/src/index.ts>.
- **P2:** Piscina task-done listener mechanics:
  <https://github.com/piscinajs/piscina/blob/6c7e54630a8c28a96ce5c0625b463d849d21171c/src/worker_pool/base.ts>.
  Executed installed copy and compiled code identified in the new fixture hashes.
- **P3:** workerpool published 10.0.3 Pool source:
  <https://github.com/josdejong/workerpool/blob/601124cf86602c1ac88c273a8f99e9c40bea0f16/src/Pool.js>.
- **P4:** workerpool handler:
  <https://github.com/josdejong/workerpool/blob/601124cf86602c1ac88c273a8f99e9c40bea0f16/src/WorkerHandler.js>.
- **P5:** workerpool custom Promise:
  <https://github.com/josdejong/workerpool/blob/601124cf86602c1ac88c273a8f99e9c40bea0f16/src/Promise.js>.
- **C1:** Comlink pinned implementation:
  <https://github.com/GoogleChromeLabs/comlink/blob/fd4b52666b1ec62784f8b45cb1108c7e40bc481d/src/comlink.ts>.
- **C2:** Comlink protocol:
  <https://github.com/GoogleChromeLabs/comlink/blob/fd4b52666b1ec62784f8b45cb1108c7e40bc481d/src/protocol.ts>.
- **C3:** Comlink Node adapter:
  <https://github.com/GoogleChromeLabs/comlink/blob/fd4b52666b1ec62784f8b45cb1108c7e40bc481d/src/node-adapter.ts>.
- **C4:** Comlink tag object:
  <https://api.github.com/repos/GoogleChromeLabs/comlink/git/tags/c72ee3bc6a8de289d3b9be206b96efdbc8a3f3e0>.
  Exact retained tag/npm fields and source bytes under `../sources/comlink/`;
  archive not executed or integrity-verified.
- **A1:** EF authority at 466e35a…:
  <https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/AGENTS.md>;
  ADR-0011/0014/0015 and OD-003 in that checkout.
- **A2:** GM accepted kernel candidate:
  <https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md>;
  corresponding package README and retained N1000 growth source-check record.
- **A3:** Orchestrator at 477b344…: ADR-0027/0110 and OD-005/035/041, inspected in
  local checkout; authority is distinct from the newer current central reference.
- **A4:** New central backend stack:
  <https://github.com/agent-teams-ai/.github/blob/86a85d6beda07e6e5ee7806646f700bc4e4db173/docs/backend-stack.md>.
- **A5:** Historical product local workflow profile:
  <https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/open-decisions/OD-035-local-durable-workflow-engine.md>.
- **A6:** AR deferred native custody follow-up and its ADR-0001/open protocol:
  <https://github.com/agent-teams-ai/agent-runtime/blob/8d89b28f07426846b3ded7c6bd933363d9dc468c/docs/architecture/rust-custody-migration-follow-up.md>.
