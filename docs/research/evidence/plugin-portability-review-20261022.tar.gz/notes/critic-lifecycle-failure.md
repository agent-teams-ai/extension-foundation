# Independent critique: lifecycle interleavings, Temporal and native boundaries

Review cut: **2026-10-22**. Independent adversarial review of the complete shared brief and the replacement/reuse, Temporal, Rust and customization/scale notes. This is research criticism, not approval of an execution placement, package, public SPI, native migration or production runtime. I inspected the local authorities and kernel source; I did **not** run a runtime experiment, build native code, rerun Temporal's retained spikes, inspect a resolved dependency tarball/lock or reproduce the source researchers' entire upstream audit. The parallel Worker/Piscina/workerpool experiment remains independently owned.

## Verdict

**The bounded trusted request-cohort proposal is defensible; the hard part remains the product's acceptance/dispatch/recovery contract, not the local pointer switch or orchestration language.** The four notes preserve the approved division of authority substantially better than a generic hot-reload manager would. I found no reason to replace the accepted GM kernel, add a Rust policy coordinator, route ordinary calls through Temporal, require contained-turn custody for ordinary extensions, or reopen the hosted/local workflow split.

The leading remaining risks are concrete joins: defining the exact local dispatch handoff, interpreting an acceptance result after an await or Host restart, fencing a stale scheduler at the command receiver, and deciding what forced termination proves when a cleanup continuation can no longer complete. These are qualifications of existing obligations, not newly invented distributed machinery. They should be made explicit before a reader turns the research into an implementation promise.

**Documentation disposition:** the current notes are repeatedly and clearly non-normative. Their existence is not blocked by unexecuted implementation cases. A claim that these joins are already solved, or that a source/library status proves them, would be misleading and should block that claim. Most findings below therefore call for short clarifications plus rejecting fixtures in the eventual real slice, rather than a new approval ritual or an implementation prerequisite for finishing the research.

## Authorities actually checked

- EF ADR0011, ADR0014, ADR0015 and OD003; the complete current hot-reload proposal and review record, and the maintained research reference, at checkout `466e35a62481a6b21f2062524bb92c7eb221bb8c`.
- GM ADR0029, candidate README and actual `kernel.ts` at `8249c674ad53458b31d6ad06803ceb76e29ff4c7`. The implementation matches the relevant narrow claims: active-only `beginCall`, active/staged custody acquisition, existing call validity while quiescing, immediate local revocation at retiring/retired, explicit release and zero-count completion. WeakMap identity is local membership, not a transferable grant.
- Orchestrator ADR0027, ADR0110, OD005, OD035, OD041, OD043 and its root agent instructions at `477b3445c4c66416121559894cf6f393c9450c72`. The retained 35/35 + 35/35 Temporal evidence is historical evidence of its documented boundary, not new plugin-replacement evidence. Mandatory static GM/FMS selection is settled; the dynamic Host and stricter two-integration production gate remain separate.
- AR Rust follow-up, optional-default ruling, production gate plan and complete system-boundary spike README at `8d89b28f07426846b3ded7c6bd933363d9dc468c`. Deferred production migration, separate Supervisor/Guardian units, protected readiness channel and owner-crash gaps remain explicit.
- Organization Engineering Quality Standard at `d17901e6975fdb4388b1f75cad901e7f448aebbe`.
- Current official Node Worker, Temporal failure/cancellation/versioning and Wasmtime interruption documentation, retrieved 2026-10-22; see source ledger. Attempts to independently fetch the pinned SDK `activity-options.ts` through the web tool failed, so I do not independently certify the note's SDK-default discrepancy. Its recommendation to select cancellation behavior explicitly is still sound.

## Prioritized findings and exact corrections

### LF-01 — The local handoff must be named; a bare last `checkCall` is underspecified

**Priority:** high implementation risk. **Existing authority:** EF0011's invocation freshness/fence floor, GM0029's local call authority, and the already adopted EF local-lease/canonical-acceptance bridge. **Research disposition:** clarify; do not claim an unresolved implementation has passed.

The existing bridge gets the important ordering right: obtain real local authority while active, retain the pending attempt, obtain canonical acceptance for the same operation/generation, and check local validity before dispatch. What is still easy to implement incorrectly is the word “before.” An arbitrary asynchronous wrapper can separate that check from the point where an executor or an owned queue actually accepts custody of the operation.

#### Rejecting trace A: a check followed by an asynchronous routing gap

1. Host incarnation H1 owns local generation G1 and retains call token L for operation O. O consumes the pending/admitted limit.
2. Canonical acceptance commits O→G1 under its bounded authority policy. H1 receives confirmation.
3. H1 calls `checkCall(L)` successfully, then awaits a connection/queue permit or a generic routing wrapper. **No generation-bound executor or owned immutable-generation queue has yet accepted O.**
4. The lifecycle owner retires G1. L is now revoked. An incorrectly written timeout/finally path additionally releases L or forgets its dispatch continuation.
5. The awaited wrapper resumes and either sends O to the old endpoint, or reads `currentPool` and submits O to G2. The former hands off revoked work; the latter violates O's accepted generation. Premature release can also let retirement appear complete while the continuation remains executable.

This trace does not require Host or worker threads to share a memory race. Two ordinary asynchronous turns suffice. It is also possible through reentrant payload conversion if user code can run between checking and enqueueing.

**Recommended exact addition to the bridge:**

> The adapter defines one local dispatch handoff: acceptance of the operation by the exact retained generation endpoint or by an owned queue that irrevocably captures that endpoint and the operation's custody. After the last asynchronous wait or user-code conversion before that handoff, the Host rechecks the retained token and operation disposition, records the local dispatch attempt and enqueues without another asynchronous or user callback gap. It records confirmed handoff only under the adapter's actual acceptance contract; a thrown error or missing acknowledgment is not automatically proof of non-dispatch. A generic queue that selects a generation later is not that handoff. Payload preparation/validation occurs before the final check. This is a local ordering guarantee, not an atomic transaction with canonical persistence or another execution agent.

**Necessary limit:** enqueueing to an exact immutable-generation pool can itself be a valid handoff. The proposal must not require the token to remain active until the worker's CPU starts. Already accepted and handed-off queue items can remain part of the closed cohort while G1 is quiescing. Ordinary retirement cannot retroactively unsend work. Revocation governs remaining ordinary authority; emergency revocation, effect-gateway enforcement and actual physical stop are separate mechanisms. A pool adapter must make its queue ownership, cancellation settlement, affinity and worker-respawn behavior truthful; it need not expose an impossible global atomic section.

Do not add a second lifecycle FSM to enforce this. The operation record's pending/accepted/handed-off observations and the kernel's phase/token facts have different meanings. Use existing operation/dispatch ownership and a private synchronous handoff helper where the selected adapter supports it.

### LF-02 — Acceptance evidence must identify the original execution, without requiring the old head to remain current

**Priority:** high. **Existing authority:** EF0011 target/generation/audience/fence binding; EF0014's distinct identities; GM0029 local identity; existing crash matrix. **Disposition:** clarify now; qualify in the real adapter.

“Canonical accepted” cannot be a reusable Boolean. The Host must know which operation, generation, execution owner/incarnation, authority policy and bounded validity were accepted. This does **not** mean inventing a new signed-receipt format for a colocated database or declaring all current-head comparisons mandatory at dispatch. An existing durable command receipt/readback can supply the evidence appropriate to its contract.

Old accepted work may intentionally remain valid after publication. Requiring “G1 is still the canonical current head” at every handoff would silently destroy the promised closed-cohort completion. Instead, the adapter must establish that the **specific acceptance** remains dispatchable under its declared policy, including dispatch deadline, cancellation/revocation and incarnation rules; independently, the local token must still be valid at the local handoff.

#### Rejecting trace B: an old acceptance receipt resurrects local authority

1. H1 obtains L and canonical acceptance of O on G1; its acknowledgment or result is lost.
2. H1 crashes. Depending on placement, its local Worker disappears, or an independently owned subprocess remains unresolved. Canonical state still records O as accepted.
3. H2 starts, reconstructs a graph from the same bytes and calls it G1 because the content digest matches. It creates a new kernel token and treats O's old accepted status as permission to dispatch again.
4. An old process or external request may still be live; alternatively, H2 has replayed work whose original result was merely lost. Equal bytes did not preserve the original owner, local token or operation outcome.

**Recommended exact addition:**

> Acceptance/readback is bound to the original operation, runtime generation and execution/Host incarnation under the product's existing authority contract. After an incarnation change, an old accepted record cannot recreate a local token, reattach arbitrary handles, or authorize another dispatch by itself. Reconcile the original execution/effect and fence stale authority first. Any new execution uses an explicitly permitted recovery disposition and fresh runtime identity; uncertain dispatch is not silently converted into “never sent.”

The outcome may honestly be “result lost/retirement pending,” even for a read-only call. A feature owner can separately permit repeatable read computation under a new attempt with defined freshness/authorization semantics. The library must not infer that policy. This avoids both a false exactly-once promise and needless claims that every read can never be retried.

### LF-03 — The scheduler fence must be enforced at receivers, not merely on workflow starts

**Priority:** high for provider replacement or overlapping Activity attempts. **Existing authority:** Orchestrator OD005 and EF0011. **Disposition:** strengthen the existing Temporal paragraph, not a new platform decision.

The Temporal note correctly calls for a scheduler-ownership fence. The strongest counterexample is an old Activity that survives the switch; disabling old starts or terminating workflow history does not stop that Activity.

#### Rejecting trace C: stale cleanup destroys the successor

1. Temporal driver S1, epoch 7, sends a prepare/retire command. The Activity times out while its host action continues.
2. The product checkpoints and selects driver S2, epoch 8. S2 prepares/publishes the successor.
3. S1's delayed retry/cleanup resumes. If the receiver checks only operation ID, current scheduler name, or mutable resource label, it can release S2's resource, publish stale intent, or trigger a new acquisition.

**Recommended exact addition:**

> Every authority-changing command and any existing custody boundary that accepts its technical consequence checks the scheduler ownership epoch plus the exact operation, expected revision and target/resource incarnation. Advancing the canonical fence invalidates later commands from the old driver; cached workflow state or a stable operation ID does not refresh it. Previously accepted bounded actions retain their recorded disposition and require reconciliation; a fence update does not undo their effects.

Use the already owned canonical records and narrow command ports. Do not introduce a replacement-library journal or require the native keeper to decide scheduler policy. The keeper can enforce an opaque fence/target supplied through its admitted contract; the product decides its authority. If no existing receiver can enforce the required fence, the “small adapter” estimate does not apply.

### LF-04 — Forced stop can make a cleanup continuation impossible; terminal outcomes need a truthful branch

**Priority:** medium/high operational risk. **Existing authority:** GM0029's explicit release, EF0011's effect-specific proof, GM0039's retained cleanup flight, and AR's evidence distinctions. **Disposition:** implementation contract to choose; clarify the conjunction now.

The notes correctly reject timeout-as-cleanup and retain the real cleanup flight. A further trap is requiring “the original cleanup callback completed successfully” **and** forced worker exit forever. Once execution has been destroyed, that callback may never settle at its original endpoint. The Host must distinguish pending execution, known failed cleanup, and a callback rendered impossible by physical stop.

**Recommended exact addition:**

> Clean shutdown and forced termination produce different evidence. Forced exit can prove that local continuations cannot execute; it does not prove their finally callbacks ran or their external postconditions. The Host releases local ownership only under the selected profile's proved resource/dispatch postconditions, and records any remaining cleanup/effect debt under its existing recovery owner. A physical-release result must not be promoted to complete lifecycle success while applicable external outcomes remain unresolved.

This is not permission to mark cleanup debt successful. It is also not a demand to retain an impossible Promise forever after an exact worker is proven gone. Resource-owned evidence determines whether a dependency may be released; the chosen outcome vocabulary must say what remains. A forced stop with uncertain external custody still consumes the predecessor slot and blocks the dependent phases required by EF0011. A profile owning only process-local read computation can have fewer remaining postconditions than one owning external registrations.

The one-predecessor cap is a sound safety tradeoff, but it permits indefinite **unavailability of further replacements** after an unreconciled predecessor. Say this explicitly. A deadline bounds observation/escalation, not successful retirement or future update availability. Do not automatically evict old debt to free a slot.

### LF-05 — Temporal's durable coordination is useful only if its lifecycle is outside the closure it drives

**Priority:** medium. **Disposition:** retain the recommendation; add one deployment qualifier.

Temporal should coordinate rollout commands through the already authoritative product operation. It should not own arbitrary JS references, record a second active-head aggregate, or add an Activity to every module call. The existing note handles these well. It also correctly identifies timeout/retry overlap, start-submission uncertainty, old history retention and disconnected local Desktop limitations.

One concrete source-backed addition: current official Worker Versioning guidance advises against enabling versioning for worker-specific task queues, because it is irrelevant to those queues and consumes the per-version queue limit. The note's worker-specific routing discussion should keep host-affinity routing separate from coordinator deployment versioning. Neither a queue name nor a pinned workflow establishes ownership of a restarted Host's handles. [W3]

“One product coordinator” should mean **one authority for rollout decisions and one admitted scheduling driver per operation epoch**, not one necessarily monolithic process. Temporal may own scheduling progress while the product owns the operation and the kernel owns local facts. That division is intentional. It becomes duplication if a direct driver and Temporal both advance the same operation without the canonical fence, or if both independently decide active/retired facts.

The first real capability should use Temporal immediately only if it already has qualified Temporal infrastructure or needs durable cross-host/long-lived coordination. A short single-host rollout with existing timers/dispatch/receipts may need fewer maintained parts through a narrow direct driver. Neither choice changes the call/cleanup protocol. OD035 remains the route for the future fully local engine; no bundled Temporal service follows from shared TypeScript contracts.

### LF-06 — Native custody reuse must preserve the unit being supervised

**Priority:** medium. **Disposition:** preserve Rust direction; reject language-driven expansion.

The Rust note appropriately separates safe computation, native physical custody and distributed authority. Safe Rust does not address the acceptance/send traces above. Node-API's process fate, non-cancelling Promise drops, native release matrix and Wasm host-call interruption limits are material costs, not side details. The existing AR migration direction should be reused rather than treated as an available keeper package.

One clarification matters because the AR spike itself has a **Local Supervisor** that activates executable generations, separately from a Guardian that owns execution custody. Those local deployment generations must not be conflated with a plugin cohort's canonical runtime generation. Reusing that supervisor's stop/reconstruct activation protocol as a hidden implementation of overlap-safe plugin make-before-break would change the promise. Name the supervised unit and its owner; reuse a suitable existing unit rather than creating a second supervisor or copying its state machine.

An addon/Wasm conversion of the pure GM FSM remains a weak alternative absent a real non-JS consumer or a measured defect/budget it fixes. A native process component is justified when it eliminates a demonstrated OS custody gap or supplies a selected engine behind the approved contract. No finding supports dynamic unloading of arbitrary native plugins or requiring native custody for every ordinary current-user plugin.

### LF-07 — A neutral library is plausible; a separate repository is not yet proved necessary

**Priority:** medium design/maintenance risk. **Disposition:** retain library-first; narrow the claim.

The notes properly preserve the existing independently usable GM kernel and keep product policy outside reusable mechanics. Their proposed middle layer—correlation, bounded framing, cancellation transport, generation-affine observations and conformance—could be useful to an ordinary external Host. It can also become an unnecessary package of generic callbacks if all important semantics remain in the consumer.

Before choosing a new repository, demonstrate one coherent capability that remains useful without GM, EF, Temporal or organization policy: for example, an exact-generation request channel whose queue/cancel/close outcomes preserve custody. Compare its actual mechanics with an existing fitting RPC/worker library rather than treating hand-written correlation as automatically ours. The reviewed execution libraries do not prove that a new wire layer is necessary. The current no-complete-library finding is appropriately limited to the inspected set.

The first delivery can still have one real consumer plus ordinary external fixtures, as the current standard requires; it need not wait for two production products. EF public-SPI and Orchestrator production adoption gates remain separate. Architectural independence does not require another repository, and another repository does not establish independence. A migration/rename of the accepted kernel identity needs the explicit successor route already identified.

### LF-08 — Customization is sufficiently powerful if replacement and composition semantics remain explicit

**Priority:** medium ecosystem risk. **Disposition:** accept the vocabulary, with two focused clarifications.

The customization note gives useful breadth without publishing a universal Host interface: owned contributions, explicit provider substitution, ordered composition, plugin-owned points and build-time variants. Its security implementation/invariant distinction is important: owner-qualified enforcement implementations may be swappable; an ordinary plugin cannot select or bypass the authority that admits that same plugin.

Two joins deserve concrete examples in the eventual author experience:

1. Ordered-many is deterministic binding order, not permission to retry, call `next` multiple times, run concurrently or bypass downstream authorization. A middleware/step contract must define those behaviors where relevant, especially once effects are admitted. Do not add one global interception protocol just to support composition.
2. Plugin A extending plugin B still crosses an owned capability boundary. It does not inherit B's grants or right to retain B's old instance. A session, iterator or callback beyond the bounded request lifetime either has its own profile or makes the change restart-required.

The root note already says most of this abstractly. A single rejecting example is more useful than adding a second EF manifest schema. Ordinary contribution authors should use SDK-owned registration/resource ownership; they should not implement the Host's canonical admission or drain machinery to add a menu entry. They remain responsible for the resources the supported author contract explicitly assigns to them.

## Scores and effort: independent assessment

All scores are ordinal engineering judgments for the **first trusted read-only bounded request cohort**, not measured uptime or a probability of success. Differences of one point are not evidence that a subprocess design is universally more reliable than a worker. A stronger crash/custody boundary and a smaller failure surface are different dimensions. The absence of sandbox qualification is not repaired by a score.

The current 3,000–5,500 production / 5,000–9,000 fixture/test floor is plausible **only** as integration over already working canonical transactions, operation receipts, authority/grant enforcement, dispatch/reconciliation and the selected execution owner. It does not fund GM's release qualification, an unavailable keeper, a new effect gateway, a catalogue, arbitrary sessions, domain migration or cross-platform installers. The researchers state these assumptions; preserve them whenever a table is quoted. The transport-only rows must never be used as the complete system total.

| Alternative | Confidence /10 | Achievable scoped reliability /10 | Complexity /10 | Maintained production LOC | Independent tests/fixtures LOC |
| --- | ---: | ---: | ---: | ---: | ---: |
| Existing static seam plus controlled restart | 9 | 8–9 for its restart promise | 2–3 | 150–700 | 300–1,200 |
| Local immutable cohort, no durable/physical-release claim | 8 | 7–8 | 3–4 | 700–1,800 | 1,500–3,500 |
| Bounded Node Worker cohort with the full existing product protocol | 7 | 8 after qualification | 6 | 3,000–5,500 | 5,000–9,000 |
| Same cohort using a fitting Piscina/workerpool adapter | 6–7 before the bounded experiment | 8 under the same promise | 6 | Approximately the same total; plausible savings of hundreds, not thousands | Approximately the same total; library-specific outcome tests substitute for custom transport tests |
| Existing supervised process owner, same read-only protocol | 7 | 8–9 for the named process/custody scope | 7 | 3,500–7,000 | 6,000–11,000 |
| Temporal scheduling adapter where infrastructure already qualifies | 8 | Same Host-safety ceiling; stronger durable scheduling recovery | 7 | +600–1,500 to the common protocol | +1,200–3,000 |
| Newly operated workflow service solely for one local rotation | 3 | No Host-safety gain by installation alone | 9 | No small honest complete estimate | Service/install/recovery qualification additional |
| Rust FSM rewrite/addon instead of the existing kernel | 3 | No demonstrated improvement; 7 at best for the proposed replacement | 7–8 | About 1,000–2,400 across code and release glue, **plus** unchanged product protocol | 1,500–3,500 plus unchanged product protocol tests |
| Already qualified native custody component through a narrow adapter | 7–8 for fit, availability currently unproved | 8–9 for its exact custody promise | 7 | 300–800 adapter, plus separately costed component/release | 800–2,000 adapter/compatibility fixtures |

These deliberately overlap. They are rough planning ranges, around ±2×, not measured source counts or commitments. The existing notes' modest Worker/Piscina delta is more credible than a large savings claim. Qualification may find that a pool deletes code or instead needs more adapter code for this capability. Do not choose a pool based on a few hundred estimated lines.

For document consistency, keep runtime/integration production code and additional release/config code in non-overlapping categories. The Rust table's separate release column is useful; callers must not both include that configuration in a quoted production total and add it again. The historical AR 8k–13k transfer estimate is for its recorded Linux/cooperative-macOS scope and cannot be summed with a new Linux/Windows prototype as though they were independent required deliveries.

## Strongest counterarguments to my critique

**“The EF bridge already says current local dispatch boundary; this adds no new invariant.”** Correct. LF-01 is an implementation clarification and rejecting trace, not a newly discovered hole in the accepted authority model. Keep the correction short; do not create another architecture layer or pretend the current research is false.

**“Accepted work can queue and start after quiesce.”** Correct. The handoff is acceptance by the owned exact-generation executor/queue, not actual CPU start. The trace is deliberately about an await before that handoff or later generation selection. A valid pre-revocation handoff must not be reclassified as a new invocation just because a worker starts it later.

**“More receipts and checks could make the fast path expensive.”** The correction does not require another database round trip or signed message for every local internal call. Use the existing product acceptance contract and its bounded authority policy, capture one cohort per outer operation, and check actual receiver authority where required. Measuring its cost remains necessary; deleting the authority does not optimize the same guarantee.

**“A process crash may prove all Node workers are gone.”** Yes for the exact supported Node placement and local execution closure; no universal surviving subprocess is assumed. H2 must still not resurrect local tokens or assume the outcome of previously accepted external work. A process profile has a different survival/reattachment problem and must state it separately.

**“Read-only computation makes duplicate execution harmless.”** It can, if the feature's semantics, grants, resource budget and freshness policy permit it. That is a useful reason to start read-only. It does not justify changing an operation's selected generation or inferring a generic retry policy for later mutating plugins.

**“A small library with one real consumer is exactly the owner's requested direction.”** Agreed. I reject neither library-first nor early neutral design. I question a new repository/package whose supposedly common layer has no useful, testable behavior after all semantics are pushed into callbacks. The first real and disposable consumers should answer that with code and conformance.

## Remaining owner decisions versus routine engineering

**Actual owner decisions:**

1. Select the real bounded capability, its execution placement and its observable promise: overlap-safe read-only requests, dispatch/authority lifetimes, permitted retry semantics, availability budget and restart-required cases.
2. Name the existing canonical acceptance/dispatch/reconciliation receiver and physical execution/custody owner. If the required receiver-enforced fence or recovery disposition is absent, approve its actual scope and cost rather than pretending it is wiring.
3. Choose the first reusable Host-mechanics contract/owner and whether another package/repository is warranted under EF OD003. Preserve GM0029's admitted identity and its separate release gate.
4. If rollout scheduling warrants it, admit a Temporal adapter for that feature under the existing ports/fence; retain the settled hosted choice and future OD035 local track. Do not reopen those choices globally.
5. For any native component, preserve AR's deferred migration boundary and choose its exact supported target/threat/release profile through the existing owner route. No plugin requirement silently makes the keeper available.

**Routine engineering choices that do not need to be returned to the owner as permission questions:** the private synchronous handoff implementation, exact local record shape, payload preparation order, same-operation readback mappings, error-listener registration, bounded fixture mechanics, artifact pin capture and wording of pending/debt observations—provided they stay within the selected contract. These should be completed and reviewed normally.

## Bounded evidence still needed

Reuse the existing Worker/Piscina/workerpool comparison rather than restart it. Add only uncovered cases justified by the chosen adapter:

- Pause before local handoff, publish/quiesce or retire, then resume. Verify correct refusal or original accepted generation affinity without an unowned continuation.
- Distinguish queue handoff from worker start. Preserve legitimate closed-cohort work, cancellation outcome and exact pool identity; do not silently resubmit to a replacement pool/worker after uncertain execution.
- Lose canonical acceptance acknowledgment, restart the Host, then supply the old receipt. Reject token resurrection and reconcile the original incarnation/operation.
- Keep an old Activity running through a scheduler epoch switch; its later command cannot publish or remove a successor-owned resource.
- Force worker exit during a never-settling finally; report physical evidence, local ownership disposition and external debt separately. The predecessor cap cannot be freed by an observation timeout.
- Keep the same supported data contract in an ordinary external project without organization credentials or GM composition. If an additional RPC/transport library fits, compare maintained adapter code before introducing a new custom wire layer.

None of these is marked passed here. No new broad stress, native packaging or platform campaign is justified merely by this research review.

## Source ledger and retrieval caveats

Local authorities were read at the exact checkout revisions above. Primary source links are evidence identities; they are not instructions to change accepted pins.

- **A1 EF0011:** <https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0011-extension-admission-custody-and-retirement-closure.md>
- **A2 EF0014 / EF0015:** <https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0014-product-local-module-authoring-composition-and-generation-guardrails.md> and <https://github.com/agent-teams-ai/extension-foundation/blob/466e35a62481a6b21f2062524bb92c7eb221bb8c/docs/decisions/0015-authorize-get-modular-semantic-extraction.md>
- **A3 EF proposal / review / OD003:** same EF pin, `docs/research/hot-reload-and-generation-replacement.md`, `docs/research/plugin-research-review-and-decision-record.md` and `docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md`.
- **A4 GM0029 and actual kernel:** <https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md> and <https://github.com/agent-teams-ai/get-modular/blob/8249c674ad53458b31d6ad06803ceb76e29ff4c7/packages/lifecycle-kernel/src/features/lifecycle/kernel.ts>
- **A5 Orchestrator ADR0027 / OD005 / OD035:** <https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/477b3445c4c66416121559894cf6f393c9450c72/docs/decisions/0027-temporal-as-run-orchestration-adapter.md> and corresponding `docs/open-decisions/OD-005-temporal-workflow-boundary.md`, `OD-035-local-durable-workflow-engine.md`.
- **A6 AR custody and qualification:** <https://github.com/agent-teams-ai/agent-runtime/blob/8d89b28f07426846b3ded7c6bd933363d9dc468c/docs/architecture/rust-custody-migration-follow-up.md>, corresponding `host-custody-optional-default.md`, `docs/spikes/rust-system-boundaries-production-gates.md` and `experiments/rust-system-boundaries/README.md`.
- **A7 Shared standard:** <https://github.com/agent-teams-ai/.github/blob/d17901e6975fdb4388b1f75cad901e7f448aebbe/docs/engineering-quality-standard.md>.
- **W1 Current Node Worker docs**, observed v26.12.1, moving source, retrieved 2026-10-22: <https://nodejs.org/api/worker_threads.html>. Message transfer, Worker execution and exit remain separate observations; target adoption was not tested.
- **W2 Temporal failure/cancellation docs**, moving, retrieved 2026-10-22: <https://docs.temporal.io/encyclopedia/detecting-activity-failures> and <https://docs.temporal.io/develop/typescript/workflows/cancellation>. They distinguish timeout-triggered attempts, heartbeat-delivered cancellation, and workflow wait choices. They do not establish physical process absence.
- **W3 Temporal Worker Versioning**, moving, retrieved 2026-10-22: <https://docs.temporal.io/production-deployment/worker-deployments/worker-versioning>. Deployment/build pinning, compatibility floors and the warning about worker-specific queues were independently checked. Latest SDK/server release identities in the researcher note were not independently re-certified here.
- **W4 Wasmtime interruption**, moving, retrieved 2026-10-22: <https://docs.wasmtime.dev/examples-interrupting-wasm.html>. Fuel/epoch guest interruption is an engine facility, not proof of arbitrary host-call cancellation or external-effect rollback. The broader Rust source ledger remains researcher evidence unless specifically checked above.

