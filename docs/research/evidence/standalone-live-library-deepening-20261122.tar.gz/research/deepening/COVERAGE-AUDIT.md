# Independent native coverage audit

Audit date: 2026-11-22. This is a read-only check of frozen inputs, returned native
sources and emitted receipts, not a new runtime execution. Machine detail is in
[COVERAGE-AUDIT.json](COVERAGE-AUDIT.json).

## What is counted

**17 distinct backend cases** = 12 PostgreSQL + 3 Worker/Resources + 2 joint
Worker/PostgreSQL. Backend v2 run 45043862207 returned **17 pass, 0 fail, 0 skipped**.
Backend v1 run 45042722876 remains **16 pass, 1 fail**. Each run returned all 15
source/configuration files matching its own frozen manifest; workflow bytes
match each hosted input receipt. V2 changes exactly one SQLSTATE oracle.

**1 new browser test with 7 scenarios**, not 7 independent browser tests or 70 tests.
Editor v2 run 45042722838 completed CM-1 through CM-7; independent canonical JSON
comparison of every actual/expected record gives **70/70 matching comparisons**.
All 7 returned input files match v2; six are identical to v1. No page or cleanup
errors were recorded. Its exact workflow hash matches the receipt.

The three local Worker passes repeat E03/E04/E05 and do not add to 17. E02 and
state S09 are one test. The earlier React/Vite browser 49 is independent historical
evidence, unchanged and excluded from the new 70 comparisons. Corrective reruns
repeat coverage rather than increasing distinct case counts.

## Backend cases and attempt history

| ID | Lane | Observable case | v1 | v2 |
| --- | --- | --- | --- | --- |
| S01 | state | competing publishers CAS once | passed | passed |
| S02 | state | same attempt serializes and effects replay once | passed | passed |
| S03 | state | attempt identity rejects changed inputs | passed | passed |
| S04 | state | artifact ABA cannot reuse live identity revision or epoch | passed | passed |
| S05 | state | lost application reply reconciles same durable attempt | passed | passed |
| S06 | state | controller death before COMMIT rolls back native transaction | passed | passed |
| S07 | state | KEY SHARE negative control allows old effect after publication | passed | passed |
| S08 | state | SHARE fence orders old effect before new publication | passed | passed |
| S10 | state | rollback requires actual current state compatibility | passed | passed |
| S11 | state | durable baseline cannot silently change after controller restart | passed | passed |
| S12 | state | DO NOTHING CTE fallback can miss the committed winner | passed | passed |
| S13 | state | FK retention metadata excludes dangling canonical reference | failed | passed |
| E03 | execution | close waiter abandonment does not prove native Worker exit | passed | passed |
| E04 | execution | failed cleanup retains a responsive Worker and public close retries it | passed | passed |
| E05 | execution | retention budget counts native exits before acquiring another Worker | passed | passed |
| E01 | joint | real old and new implementation/dependency cohorts straddle DB publication | passed | passed |
| E02 / S09 | joint | S09 stale parent-owned effect is fenced after actual Worker exit | passed | passed |

S13 failed at the first deletion oracle: explicit ON DELETE RESTRICT returned
23001, while the assertion expected 23503. The prohibited deletion was rejected;
the second schedule and final zero-dangling-reference assertion were not reached.
The independent [source/result review](execution/evidence/backend-v1-result-review.md)
approved a separate v2 changing only that expected code. The reverse insertion
expectation remains 23503. The [v2 review](execution/evidence/backend-v2-result-review.md)
confirms both native lock waits and both rejection assertions completed, followed
by the no-dangling SQL assertion. The JSON reports 0 after that assertion; it
does not independently serialize the raw count row. The v1 result stays failed.

E01 retained actual A implementation/dependency execution through B publication;
E02 carried the original A authority into a parent-owned effect after observed
Worker exit. Both are actual Worker/database composition. E01's held operation
is an async generator controlled by two messages, not an HTTP/Readable stream.
E05's capacity policy is single-controller, not concurrent admission qualification.
S05 loses an application reply after acknowledged commit, not a DB wire commit
acknowledgement. S10 uses quiescent toy codecs; S13 is canonical metadata, not
physical blob deletion.

## Editor cases

| Scenario | Native observation |
| --- | --- |
| CM-1 | Public compartment replacement preserves draft, document identity, selection/focus, field/history; subsequent input reaches the new view plugin |
| CM-2 | Negative control: late old lint result overwrites already useful new diagnostics on the same native document |
| CM-3 | Native changed-document guard suppresses old completion; normal No diagnostics placeholder is expected |
| CM-4 | Narrow contribution-generation and revision gate rejects predecessor diagnostics |
| CM-5 | Edit plus Undo restores equal text while revision advances; text equality alone is insufficient |
| CM-6 | Clearing history preserves dirty draft; separately resetting the document has distinct state consequences |
| CM-7 | Native JSON history restores text Undo but omits custom inverse effects despite a working field-value codec |

Editor v1 run 45042075044 completed CM-1/CM-2 and failed CM-3's DOM expectation:
27/28 executed comparisons matched. The changed-document diagnostic-state check
already passed. V2 changes only that placeholder expectation, preserves source
and failure evidence, and completes all seven scenarios. No OS IME, general
semantic-history codec or production plugin loader is claimed.

## Preservation and qualification

All 257 prior packet files survive byte-for-byte: 253 at their original path and
four outer entrypoint/manifest originals under provenance/prior-root. The 11 seed
files and complete FMS source match their retained hashes. The packet adds no
active .github workflows and no production module/public API scaffolding.

Reports and plans can reflect earlier checkpoints. CURRENT.md plus terminal raw
receipts govern the observed status. The corrected backend and editor profiles
have passed their stated native cases; this does not establish a production
library, accepted public API, generic plugin loader or a cross-profile atomic
transaction. Publication of this research packet is a separate step.
