# Annotated acceptance and scenario matrix

Checkpoint: corrected hosted v2 passed one E2E test, all seven scenarios and 70/70 comparisons, with no page or cleanup errors. Run 45042722838, attempt 1, job 137270527195. V1's earlier empty-panel oracle failure remains preserved separately. “Recommended” rows are design transfers, not passed tests. Primary source IDs resolve in `sources.json`.

| ID | Situation | Required observable result | Evidence / responsible owner | Qualification |
| --- | --- | --- | --- | --- |
| CM-1 | Compatible editor contribution replaced | Draft/document object, field value, selection/focus and Undo retained; old listener removed; new interaction handled by new view plugin | Native CodeMirror compartment/history/view lifecycle; editor adapter | Passed v2, 18 comparisons |
| CM-2 | Old linter finishes after new linter on same document | Native late A overwrites visible B; exact two invocations and ordered completion observed | CM_LINT exact release; native diagnostic DOM | Passed negative control v2, 7 comparisons; also observed in v1 |
| CM-3 | Linter input document changed | Existing native document guard suppresses stale diagnostics; empty panel placeholder visible | CM_LINT; native protective counterevidence | Passed corrected v2, 4 comparisons |
| CM-4 | Old generation result on same document/revision | Narrow managed adapter rejects predecessor at application; current native diagnostic/focus/selection remain | Trusted generation/revision gate; editor adapter, not authorization owner | Passed v2, 8 comparisons |
| CM-5 | Edit and Undo produce equal text | Revision advanced; text-only check demonstrably insufficient; native document identity changed | Native history plus host monotonic revision | Passed v2, 7 comparisons |
| CM-6 | User clears history, then separately resets document | First command retains dirty draft/selection/field/content DOM; second explicitly replaces/reset state | Native history compartment and new EditorState | Passed v2, 13 comparisons |
| CM-7 | Serialized text history includes custom inverse effects in memory | Direct Undo reverses field; codec restores field7; after JSON round-trip Undo reverses text but field remains7 | CM_COMMANDS native historyField/invertedEffects APIs | Passed codec-boundary control v2, 12 comparisons plus final no-page-error check |
| UX-11 | New candidate selected but old useful result still visible | Both identities shown; no false success from import/update receipt | Existing browser49 is independent prior evidence; consumer useful receipt | Contract transfer; not re-run here |
| UX-12 | UI result acknowledges old document after publication | Reject or label stale with input/generation provenance | Consumer result adapter; authority epoch is a separate concern | CM-4/5 narrow local coverage only |
| UX-13 | Dirty draft while incompatible schema or view reset is required | Preview retained/reset state and available save/export/defer actions | Product state policy and native editor adapter | Recommended; arbitrary schema migration not qualified |
| UX-14 | Real OS IME composition active during update | Qualified in-place path or explicit deferred disruptive restart; no silently dropped composition | Browser/platform editor integration | Not qualified; synthetic CompositionEvent is insufficient |
| UX-15 | Selection of one plugin affects dependency cohort | Preview resolved affected closure and reasons, with plan revision | Existing planner/composition owner; JB_DYNAMIC_SOURCE analogy | Recommended; no second graph owner |
| UX-16 | User pauses while update is already committed | Pause future admission; show actual current phase and supported recovery | Update operation owner; JB non-cancellable phase | Recommended; not an abort/rollback proof |
| UX-17 | Rapid candidates A/B/C while A is draining | Coalesce only eligible unstarted work; identify superseded candidates; retain unresolved A holds | Update operation owner and policy | Recommended; no new worker queue in UI |
| UX-18 | New version useful, old cleanup failed | Useful state remains visible with cleanup warning, hold reason and owner-supported retry/restart | Resource/cleanup owner; JB_DISPOSER lifetime counterexample | Recommended; no leak-freedom claim |
| UX-19 | Callback reaches disposed or replaced UI | Reject stale generation/connection; shorten scope rather than merely suppressing symptom | Editor/IPC adapter; JB_DISPOSER | Local task gate only; full resource disposal not tested |
| UX-20 | User requests previous code version after data writes | New plan against current state; exact compatibility/compensation outcome | Update+state owners | Recommended; no universal rollback promise |
| UX-21 | Network observer reconnects after missed transitions | Stale badge until snapshot/cursor validated; gap or expiry resync | Existing observation service; SSE_SPEC | Recommended; no native network test in this fixture |
| UX-22 | Observer gets duplicate/out-of-order notice | Snapshot revision governs rendering; mutating action revalidated by owner | Observation adapter; REACT_SNAPSHOT | Recommended; not a distributed state authority |
| UX-23 | Renderer reconnects but worker survives | New channel identity; explicit worker/host status; old work not declared stopped | ELECTRON_PORT existing transport/custody | Source-only, no Electron experiment |
| UX-24 | Activated extension cannot unload independently | Explain concrete host restart scope and affected contributions | VSCODE_HOST/VSCODE_ACTIVATION_SOURCE | Source/docs only |
| UX-25 | Reassemble/build occurs in unusual order | Guard readiness and independently observe usefulness; don't rely on one atomic hook | FLUTTER_FRAMEWORK/FLUTTER_BINDING | Pinned source only |
| UX-26 | Document Undo and global file operation Undo coexist | Focus and target scope explicit; no silent cross-document action | CM_HISTORY_LOCAL | Maintainer guidance; no new global history engine |
| UX-27 | Feature-flag provider becomes ready after reconnect | Re-evaluate rollout intent, preserve provider/domain identity; do not infer update/cleanup success | OPENFEATURE_EVENTS optional adapter | Specification only |
| UX-28 | Already accepted result is followed by input/configuration change | Preserve input provenance; mark stale or refresh rather than treating mapped ranges as proof of continued semantic validity | Native lint range mapping plus owning analysis policy | Source-derived requirement, not a passed CM-4 arrival-gate scenario |

## Native fixture controls

The native linter uses a long configured automatic delay and public `forceLinting` for deterministic starts. The test observes each real source invocation before releasing its promise, observes B's actual native diagnostics DOM before completing A, and asserts no additional invocation masks either result. Changed-document behavior is tested separately rather than blamed on the same-document finding.

The guarded adapter uses public `setDiagnostics`, not a replacement linter/history engine. Its values are trusted fixture metadata. Equal text after Undo is recorded alongside a changed native document identity and a changed revision. The history codec experiment serializes the custom field itself and the historyField, then checks field value before and after Undo; this prevents confusing an absent field codec with an absent inverse effect.

Every native failure must retain its own input and receipt. Repairing a source/control creates a new reviewed input identity; no blind retries or overwriting the original failure. The earlier browser49 fixture and receipts stay immutable.
