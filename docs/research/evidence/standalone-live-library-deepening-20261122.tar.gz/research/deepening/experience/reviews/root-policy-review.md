# Critical review: complete operation, policy and user-visible evidence

Reviewer: `/root/deep_experience_protocol`, 2026-11-22. Read completely:

- `live-library-deepening-20261122/root/REPORT.md`.
- `extension-foundation/docs/research/live-update-reliability-and-industry-evidence-2026-11-22.md` at the source/frozen-input stage.
- Root's pinned OpenFeature events snapshot, including hardening status and conditional context requirements; relevant Argo source locations.

**Verdict:** sound direction and honest source/native separation. No blocker for the frozen editor experiment. Five contract clarifications would materially strengthen the study before it becomes a public guarantee. These are proposed edits; this reviewer did not modify either reviewed document or the frozen input.

## 1. Useful output needs input freshness, not just generation

**Priority: important before an update-result contract is adopted.** The repository outcome table asks for health/render observation correlated to the exact generation. That is necessary but insufficient for the editor case: two tasks of the same generation may concern different document revisions, and an old result can arrive after edit+Undo produces equal text.

Suggested replacement for that cell:

> Consumer usefulness observation correlated to the generation, relevant input revision and declared result criterion; runtime readiness remains a separate receipt.

Suggested adjacent clarification:

> Missing usefulness evidence is not by itself evidence of failed behavior. An unavailable or gapped observer reports stale/unknown observation; the owner follows the declared reconciliation and health policy.

This keeps an import, readiness ping, rendered frame and a correct result distinct without imposing editor revisions on contributions that have no such input. CM-4/5 supplies the concrete local probe; it does not qualify a general health detector.

## 2. Resource scope and physical custody need one precise delegation

**Priority: important ownership wording.** Root's report says resource libraries own custody and execution adapters own physical-stop receipts. A reader could implement two independent shutdown owners. The current experiment instead uses a resource scope to manage the registered cleanup while the execution adapter holds the real Worker and can observe termination.

Suggested wording:

> Resource libraries track scoped ownership, cleanup attempts and debt. The execution adapter retains the physical executor handle and implements the registered stop operation and receipt. The coordinator consumes that result through the existing scope; it does not introduce another supervisor.

This is a wording/ownership clarification, not a reason to replace Resources or add an RPC layer to in-process TypeScript. A failed callback and unobserved physical stop remain different facts.

## 3. Several uncertainties can coexist; do not collapse them into one phase

**Priority: important for predictable recovery UI.** The unknown publication branch is correctly central, but its rule must not spread to unrelated unknowns. An indeterminate publication, lost observer connection, missing useful-result acknowledgement and unconfirmed physical stop have different reconciliation owners and permitted actions.

Suggested addition:

> Selection, useful behavior, observation freshness and predecessor cleanup are independent facts. A selected and useful generation can coexist with cleanup debt. Each unknown result names the unresolved fact, owner and supported next action; the UI does not derive a destructive retry from a generic failed/unknown badge.

Pause should explicitly mean admission of future candidates. It must not abandon a possibly committed attempt or promise to cancel a non-cancellable switch. Coalescing can supersede eligible unstarted candidates, while retaining immutable attempt history and any unresolved resource holds. This belongs to the complete operation's policy, not a UI-local state machine.

## 4. Retention reasons should not all imply a live execution

**Priority: moderate; avoid unnecessary architecture burden.** The retention list usefully separates execution stop from artifact deletion. It should also classify what a hold retains. History, a persisted snapshot or a rollback artifact can require bytes/metadata while requiring no live worker. Conversely a live callback may need its admitted dependency cohort even if a history entry was cleared.

Suggested addition:

> Each hold identifies whether it requires a live execution, artifact bytes, a compatible state/history codec or recovery metadata. Live-generation budgets do not count every historical artifact as a worker, and clearing UI history does not release independently required runtime or recovery holds.

This avoids a design in which unlimited user Undo accidentally means unlimited live generations. It also connects CM-7's semantic history limitation to real retention policy: do not quietly clear custom history merely to make garbage collection pass.

## 5. Distinguish a proposed two-consumer qualification from an existing mandate

**Priority: moderate scope/governance precision.** Root's report requires two independently authored ordinary consumers before public adoption. This is a defensible way to expose an accidentally fixture-shaped API. The canonical quality text requires disposable test projects and at least one real consumer; it does not itself establish a two-consumer gate.

Suggested wording:

> Proposed public-adoption qualification: one complete operation through at least one real consumer and an independently authored second consumer, exercising the stated failures. This strengthens the shared baseline and still needs to be recorded as the library's acceptance criterion.

Do not block the current bounded research or imply that this stronger criterion is already owner-approved. The existing repository table says independent external consumer and reusable operation, which is suitably cautious.

## Small precision edits

- Preparation failure should retain the selected predecessor **if one exists**; a first installation has no predecessor. Acquired candidate resources still require cleanup accounting.
- Source-specific statuses must keep their upstream completion reason. Argo successful termination without the full observation threshold is correctly described as policy, not a defect; keep this qualification in the final user summary.
- OpenFeature's pinned chapter requires an event mechanism and event-driven status; asynchronous context reconciliation is conditional and carries hardening status. The current root report records this correctly. Avoid shortening it to a claim that every provider must emit all six event kinds on every transition.
- A rejected runtime/profile combination or explicitly approved restart scope is the correct fallback. No wording should turn an arbitrary adapter limitation into an automatic full-application restart.

## Protections already present and worth preserving

- Consumers receive the complete update operation; narrow ports do not ask every product to rebuild sequencing/reconciliation.
- Core sequencing, Get Modular graph semantics, product grant/schema/state authority and execution/resource mechanisms retain distinct owners.
- Optional OpenFeature, Kubernetes examples, CodeMirror and execution profiles are not mandatory shared frameworks.
- Original browser49 evidence is not counted again; source-only Argo/OpenFeature findings are not counted as native tests.
- The proposed fixtures do not claim reusable production coordinator, true network commit ambiguity, server failover, real OS IME, arbitrary callbacks, semantic history persistence or physical artifact deletion with disconnected holders.
- Unknown publication is reconciled by immutable attempt, and persisted artifact identity is not presented as a surviving executor heap.

## Result for root

Apply items 1–3 to the proposed contract language now if convenient; items 4–5 can be incorporated into the qualification/retention section without expanding the current implementation. The frozen editor input remains SHA-256 `4b94cb4d40019d77eff78b4cb01c5199197fd9eacbdb0c071c84797df0e63576`.
