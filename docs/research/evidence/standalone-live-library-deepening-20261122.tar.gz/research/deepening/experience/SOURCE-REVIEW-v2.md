# Corrective source review: native editor input v2

Date: 2026-11-22. Original run and explanation: `failure-analysis-v1.md`.

The v1 package, input archive and original failure remain unchanged. The separate `probe-v2/` package changes one line in `browser.test.ts`: CM-3 expects the pinned native panel's `No diagnostics` placeholder while preserving the independent empty native diagnostic-state check and the one-invocation guard.

The package installed the unchanged frozen lock with lifecycle scripts disabled and passed strict TypeScript 7.0.2 checking (exit 0). The other six frozen files are byte-identical to v1. No fixture behavior, timing, native API, guard, scenario or assertion count was changed.

`/root/deep_state_protocol` independently read the diff and pinned lint source and approved the correction: the native renderer creates the placeholder at negative positions when no diagnostics exist, and the fixture installs no phrase translation. Root requested this narrow correction after reading the failed result and will independently review/publish the new input before hosted execution. This lane has not run v2 manually.

See `INPUT-MANIFEST-v2.json` for exact file/archive hashes and `TYPECHECK-v2.json` for the corrected strict-check receipt. V2 is a separately identified corrective experiment; it does not rewrite v1 as a successful suite.
