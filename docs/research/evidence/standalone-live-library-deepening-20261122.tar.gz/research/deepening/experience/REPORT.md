# Live update experience: editor state, late results and explicit recovery

Research checkpoint: 2026-11-22. This lane is a proposed contract for the standalone library and optional consumer adapters. It does not adopt a production API. Exact source records are in `sources.json`; package bytes and hashes in `source-provenance.json`; native test scope in `PROBE-PLAN.md` and `SCENARIOS.md`.

**Outcome:** corrected hosted v2 passed **one browser E2E test, seven scenarios and 70 comparisons** on exact CodeMirror releases, strict TypeScript 7.0.2, Node 24.22.3 and Chromium 159.0.8154.6. It confirms a same-document late-source result can overwrite the new source; a narrow generation/revision guard prevents that controlled overwrite; native reconfiguration preserves the editor; and standard history JSON restores text Undo without preserving a custom inverse effect. The original v1 failure is retained separately; it was a diagnosed empty-panel DOM oracle error. No new input or runtime was changed after its frozen run. [NATIVE_EDITOR_V2]

## 1. Four deeper findings that change the design

### 1.1 A document guard can miss a replaced contribution

The released `@codemirror/lint@6.9.8` scheduler captures the editor state, starts its lint sources, then accepts a completed batch if the current document is the captured document object. Reconfiguring its source schedules a new pass. These protections address changed input, but the completion condition does not compare source identity. Its destroy method clears the timer, not outstanding promises. [CM_LINT]

Hosted v1 and the corrected v2 reproduced the decisive schedule: A starts → same-document source B selected → B becomes visible → A completes and replaces B. The gap is generation freshness, not a missing editor or linter engine. V2 also completed the changed-document positive control: native diagnostic state was empty and the panel showed its normal `No diagnostics` placeholder. A 2025 worker-integration report describes out-of-range stale diagnostics; the maintainer explicitly points out the native scheduler's document protection. That report is context, not the proof of the newly observed native schedule. [NATIVE_EDITOR_V1, NATIVE_EDITOR_V2, CM_ASYNC_CASE]

For explicitly managed plugin tasks, a small adapter can compare contribution generation and monotonic document revision immediately before applying public `setDiagnostics`. Cancellation remains an efficiency request. Returning an empty diagnostic array from a stale source is not a neutral action: it could erase a useful current result. The maintainer explicitly supports `setDiagnostics` without an automatic `linter`. [CM_IMPERATIVE]

V2 accepted managed B and rejected late A although both referenced the same document object and revision 9. Current diagnostics, selection and focus remained intact. In a separate scenario, edit+Undo returned the exact `seed` text while revision advanced from 10 to 12 and native document identity changed; the old completion was rejected. This is a concrete counterexample to text-only freshness, not a claim that CodeMirror's native document-identity protection fails on Undo. [NATIVE_EDITOR_V2]

The generation/revision tuple is a UI freshness boundary. It is separate from state authority epochs, tenant permissions and execution-resource custody. A pure contribution without asynchronous input-dependent results need not adopt this editor-specific interface.

The fixture's input is one document. An analyzer that also reads configuration, another file or a workspace dependency needs the corresponding input identity in its result contract; a document-only revision cannot prove freshness for those additional inputs. The product or existing analysis owner defines that identity, rather than a new universal dependency tracker inside the UI adapter.

There is a second freshness boundary after acceptance: a later edit can make an already rendered result stale. CodeMirror maps existing diagnostic ranges through document changes; that preserves positions, not necessarily the truth of the diagnostic message. The consumer should retain the result's input provenance and mark it stale or refresh it under the declared policy. The arrival gate alone does not qualify this continuing-validity behavior. [CM_LINT; source-only transfer]

### 1.2 Undo restoration has a semantic limit

`@codemirror/commands@6.11.1` provides native history, history grouping, inverse effects and `historyField` serialization. Its `HistEvent` JSON preserves document changes, mappings and selection data; deserialization reconstructs an empty inverse-effects array. A serializable custom field can therefore restore its current value while the history that used to reverse that value no longer contains the required effect. [CM_COMMANDS]

CM-7 completed both controls: direct native Undo restored text `seed` and custom field value 0; native Redo restored the edited value 7. After the standard JSON round-trip, the field codec restored value 7 and text `changed`; Undo returned the text to `seed` while the field stayed 7. This is a capability boundary, not a proposed replacement history engine or an assertion that CodeMirror promises to serialize closures. It is an in-browser serialization/deserialization test, not storage durability or crash recovery. [NATIVE_EDITOR_V2]

The maintainer also distinguishes document-local history from app-wide file operations. Ctrl-Z in document A should not silently reverse an unrelated operation in document B. A plugin version rollback, a database compensation and an editor Undo are different commands with different owners. [CM_HISTORY_LOCAL]

### 1.3 Reconfiguration preserves identities; full state replacement rebuilds views

CodeMirror state reconfiguration retains a field present in both configurations, unless an explicit new field initializer requests reinitialization. A fresh field identity is a fresh piece of state. `EditorView.setState` redraws the document and reinitializes view plugins; dispatching a compartment reconfiguration is the native path when preserving a derived state. [CM_STATE, CM_VIEW]

This gives the editor adapter a useful compatibility rule: keep stable document/history ownership, replace compatible contribution extensions through native compartments, and disclose deliberate field resets. A 2024 wrapper-integration report found that unstable callbacks were causing whole-configuration changes on focus transitions; the reporter fixed the integration, and did not attribute the problem to CodeMirror. [CM_IDENTITY_INTENT, CM_IMPERATIVE]

Preserve public field and extension identities deliberately. Do not construct a general identity registry in the library merely to compensate for consumers remounting their editor on every code version.

### 1.4 Mature reload systems expose non-atomic phases and real lifetime limits

Flutter's pinned binding wraps reassembly in event locking and tells bindings to refresh captured callbacks and derived caches. Its framework still warns that new code can build before `reassemble` runs. The transferable lesson is to define readiness and first useful rendering separately, keep critical input blocking narrow, and tolerate observations outside the expected hook order. These are development mechanisms; the source audit did not run Flutter. [FLUTTER_BINDING, FLUTTER_FRAMEWORK]

JetBrains documents a subtler resource trap: attaching plugin resources to application/project lifetimes can keep them alive after plugin unload, even though a disposer exists and normal lifetime-based leak checks may accept the reference. Use a plugin service or the appropriate shorter UI lifetime. Current dynamic-plugin source recalculates affected module groups, validates the new state and serializes reconfiguration; parts are explicitly non-cancellable. A source TODO flags mutating a product mode before feasibility is known. This is an upstream source observation, not a reproduced released defect. [JB_DISPOSER, JB_DYNAMIC_SOURCE]

## 2. The user-visible contract

The library should own the ready update operation. A consumer UI renders its observations and invokes supported commands; it does not create its own update coordinator from low-level lifecycle callbacks. The dependency planner remains the existing composition owner, authorization and state remain product-owned ports, and runtime adapters retain their actual execution/cleanup ownership.

### Plan preview

Preview identifies the requested contribution, resolved dependency closure and the reason each additional component is affected. It shows compatibility decisions, retained state, reset state, the allowed recovery action and the restart scope. It carries an identity/revision for the owner to revalidate at apply time. A preview must not mutate mode, state or routes merely to discover feasibility. A changed graph or state revision yields a new plan, not an invisible expansion of the old confirmation. [JB_DYNAMIC_SOURCE; proposed library contract]

Display at least these separate facts when they differ:

| User fact | What establishes it | Useful display and action |
| --- | --- | --- |
| Candidate prepared | Preparation receipt for the requested artifact/plan | Preview, supersede or discard if the owner permits |
| Version selected | Authoritative publication/selection receipt | Show current selection even if the visible contribution still uses its predecessor |
| Result useful | Consumer acknowledgement for generation and input revision | Show the actually working result; do not turn a loader event into this acknowledgement |
| Predecessor retained | Owner-reported references/work/resources or unresolved outcomes | Show why it is retained, owner, age and available wait/retry/restart action |
| Cleanup failed | Cleanup result with outstanding resources | Keep failure visible alongside a useful new version; expose supported recovery |
| Observation stale | Disconnection, cursor gap or failed snapshot refresh | Keep last-known content labelled stale; resync before trusting transition controls |

This is not a single linear progress bar: a new version can be useful while cleanup of its predecessor is still unresolved. Nor should a stale observer mark a version healthy just because no error event arrived.

### Pause, coalescing and rapid edits

“Pause automatic updates” controls admission of future candidates. Already selected operations keep their actual phase and supported actions. Unstarted candidates can be coalesced to the newest artifact only under an explicit policy; keep superseded identities in the operation history. A new candidate must not reset a stuck cleanup deadline or make an unresolved predecessor disappear.

Cancellation availability is a capability returned by the operation owner. A committed/non-cancellable phase shows “finishing switch” or “waiting for reconciliation” with details; it must not offer a button that only hides progress while work continues. JetBrains' non-cancellable reconfiguration phase supplies a concrete precedent, not a reason to lock the entire product for every update. [JB_DYNAMIC_SOURCE; proposed library contract]

### Dirty input and composition

Keep the editor/document owner stable across compatible contribution updates. Native transactions preserve selection mappings and history. If a reset or host restart is required, the preview explains which dirty drafts can be checkpointed and which ephemeral state cannot be reconstructed. The choice to save, export, discard or defer belongs to the product's state policy.

Composition is a separate acceptance dimension. Native editor reconfiguration, arbitrary DOM replacement and OS IME input are not interchangeable. The new fixture uses real keyboard/input editing, but does not claim real OS IME qualification. A conservative product can defer disruptive remount/restart until composition finishes, with an explicit timeout policy rather than silently discarding composed text. CodeMirror's history of composition-specific fixes reinforces the need to qualify browser/platform combinations. [CM_VIEW, CM_CHANGELOG; proposed policy]

## 3. Reset, clear and revert must name their object

| Command | Exact scope | What remains / what must be disclosed |
| --- | --- | --- |
| Refresh derived result | Recompute a projection/diagnostic for current generation and input | Draft/history retained; old result may be shown as stale while pending |
| Reset contribution-local state | Reinitialize named ephemeral fields/resources | Declare which UI preferences/caches are lost; document state remains separate |
| Clear Undo/Redo | Remove document history | Draft is retained; older actions become unavailable; CM-6 tests the native mechanism |
| Clear document | Change or replace content under the product's policy | State whether this is itself undoable and which local/remote revision is affected |
| Restore checkpoint | Restore explicitly supported data/history codecs | Report codec/schema identity and omitted state; CM-7 qualifies only the named native codec |
| Revert code version | Plan and apply an earlier artifact against current state | New update operation; no implicit rewind of writes, grants, jobs or document edits |
| Restart execution host | Replace the declared worker/process/cohort | State the impact on other hosted contributions and what remains alive outside that host |
| Remove retained version | Release a version with no required holds under the owning policy | A date or a successful dispose callback alone is not permission to drop still-required recovery evidence |

CodeMirror history is reusable for local editing. It should not become the library's universal operation log. Durable updates and business compensations use their existing owner. [CM_COMMANDS, CM_HISTORY_LOCAL; proposed library contract]

## 4. Observation and reconnect without another control plane

Expose an immutable snapshot and subscription with cleanup, plus operation and stream identities. A React adapter can use `useSyncExternalStore` directly: stable cached snapshots, cleanup and a re-read before DOM application are existing mechanisms. Do not force React, an editor or a global event bus on all consumers. Avoid replacing already useful content with a suspense spinner just because an external update snapshot changed; React's own documentation calls out that UX problem. [REACT_SNAPSHOT]

For a remote observer, native SSE supplies reconnect and `Last-Event-ID`. It does not define the application's retained replay log, sequence-continuity rules or recovery snapshot. The owning observation service should return a snapshot with a cursor, detect expired/gapped cursors and instruct the client to resync. Repeated observations may be deduplicated by identity; commands still go through the operation owner with an expected plan/revision and idempotency identity where supported. This protocol is a proposal, not executed in this editor fixture. [SSE_SPEC]

Use the consumer's existing query client for background snapshot refresh when appropriate; TanStack Query already has focus/staleness handling. Query cache contents are a projection, not authority. OpenFeature's provider/domain-scoped handlers and ready/reconciling/context-changed events are a good lifecycle example and an optional rollout-intent integration; provider readiness does not prove plugin usefulness, resource cleanup or reversible state. [TANSTACK_REFRESH, OPENFEATURE_EVENTS]

## 5. Restart scope and process boundaries

VS Code's current docs distinguish local Node, browser worker and remote Node extension hosts, and describe “Restart Extensions” after updates. Its inspected implementation rejects dynamic removal after activation has started. This is a deliberate scope restriction worth copying as explicit capability reporting, not a claim that every extension can be surgically replaced. [VSCODE_HOST, VSCODE_RESTART, VSCODE_ACTIVATION_SOURCE]

Electron already provides native channels and close notifications. A reloaded renderer can acquire a new client channel while the worker survives. Thus “the UI reconnected” is not evidence that old worker work or externally owned resources stopped. The adapter should carry the current connection/generation identity and report its restart scope; transport closure is one observation among the owner's resource receipts. No Electron runtime was executed here. [ELECTRON_PORT]

## 6. Reuse decisions and bicycle warnings

| Concern | Reuse first | Narrow responsibility that remains |
| --- | --- | --- |
| Editor configuration, document mapping, local history | CodeMirror compartments/transactions/history for consumers that choose it | Declare compatible field identity and supported restoration codec |
| Async diagnostic rendering | Native linter for its supported scheduling; public `setDiagnostics` for externally scheduled tasks | Generation/input-revision result gate where the source contract needs it |
| Observable UI state | Existing owner snapshot/subscription; optional React external-store adapter | Immutable projection and semantic operation receipts |
| Background snapshot refresh | Existing TanStack Query or consumer query layer | Authoritative cursor/gap policy belongs to observation service |
| Rollout selection intent | Optional OpenFeature provider | Update execution, state migration and cleanup remain with update/state owners |
| Desktop cross-process messages | Electron MessagePorts / existing RPC surface | Connection provenance, declared restart scope, external resource custody |
| Collaboration | Existing document protocol only when actually required | Do not make a CRDT a dependency of single-user plugin replacement |

Do not add an all-purpose UI manager, history engine, event bus, identity registry or second reconfiguration graph. The new adapter example is only about the missing freshness check at a native editor boundary. For a production library, make that concern optional and combine it with the existing update operation through a narrow integration contract.

## 7. Evidence and remaining work

| Input | Actual outcome | Preserved evidence |
| --- | --- | --- |
| v1 `4b94cb4…63576` | Hosted attempt 1 failed at CM-3 native empty-panel oracle; CM-1/CM-2 completed, 27/28 comparisons matched | Run 45042075044 and original artifact 14761563185; `failure-analysis-v1.md` |
| v2 `c9d80c3…f81c3` | Hosted attempt 1 passed: one E2E, 7/7 scenarios and 70/70 comparisons; no page or cleanup errors | Run 45042722838, job 137270527195, artifact 14762675791; `native-v2-review/` and `SOURCE-REVIEW-v2.md` |

One new browser E2E test covers seven scenarios, not 70 independent tests. The recorded comparisons are CM-1 18, CM-2 7, CM-3 4, CM-4 8, CM-5 7, CM-6 13, CM-7 12 plus one final no-page-error check. Current source lives in `probe-v2/`; original source remains in `probe/`. The corrected seven-file input is SHA-256 `c9d80c35364f9b2c5ed97a086f0a8ff24a9b2bc675c0666292c1e75ebedf81c3`, 18,027 bytes. The independent monitor retrieved the terminal run/job and complete log, parsed every comparison and saved them under `native-v2-review/`. Source publication commit: `719a6095445d67b1da7fa285bbb5ef8ecc589322`. `INSTALLED-SOURCE-VERIFICATION.json` confirms that all four installed CodeMirror distributions matched the inspected release bytes before execution.

After root downloaded the complete artifact, this lane independently matched its 1,207,123 bytes and SHA-256 `cf885324cc600c3d39037043ec4e5fbec34bd8e285af93e9260e5f6228f0a97e`, verified all seven retained source hashes and confirmed exact equality between artifact result JSON and the separately fetched job-log result. Hosted direct versions match the selected pins and the retained strict check succeeded. `native-v2-review/artifact-verification.json` records those checks.

The native result qualifies this local editor boundary and these controlled completion orders. Continuing freshness of an already accepted result after later edits/configuration changes remains an explicit source-derived policy requirement, not another passed scenario. The fixture's “Useful diagnostics” heading labels rendered diagnostics and does not implement a production health/selection acknowledgement protocol.

This does not requalify prior React/Vite HMR, durable recovery, concurrent backend publication, native plugin isolation, arbitrary resource leak freedom, multi-document collaboration, network observation resync or OS IME. `SCENARIOS.md` marks these gaps explicitly and assigns evidence and ownership instead of treating every desirable outcome as tested.
