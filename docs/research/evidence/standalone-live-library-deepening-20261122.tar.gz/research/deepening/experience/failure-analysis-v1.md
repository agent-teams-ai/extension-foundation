# Native editor v1: preserved failure and minimal oracle correction

Observed 2026-11-22. Run [45042075044](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45042075044), attempt 1, job `137268512653`, terminal failure.

## What happened

The one browser E2E suite completed CM-1 and CM-2, then stopped in CM-3. There were 28 recorded comparisons: 27 matched and the final comparison failed. This is **2 of 7 completed scenarios**, not a passing suite. No page errors or harness cleanup errors were reported.

- CM-1 exercised native compartment replacement while retaining draft, document/content DOM, selection/focus, custom field and working Undo. The old key listener was removed; the current native contribution handled new input.
- CM-2 reproduced the source-generation race on the exact release: source A started; B replaced it with the same document object/revision; B's native diagnostic was rendered; late A then replaced it while selected contribution remained B. Exactly two native source invocations were observed.
- In CM-3, the document object changed and CodeMirror's native diagnostic-state check returned an empty array as expected. The next DOM oracle incorrectly expected no `.cm-diagnosticText` nodes.

The actual native empty panel renders a `.cm-diagnosticText` node containing `No diagnostics`. The pinned `@codemirror/lint@6.9.8` distribution (`source/lint/index.js`, SHA-256 `93c2a30861db4ea35d63a9621b1b6da204a9f7ae9b8792196c72c4480e6539b2`) constructs a placeholder `PanelItem` with `from: -1`, `to: -1`, severity `info` and `view.state.phrase("No diagnostics")` when its item list is empty. That is a presentation item, not an active diagnostic in the editor state.

## Correction

Copy the seven frozen v1 files into the separate `probe-v2/` package. Keep the independent native diagnostic-state assertion `[]`. Change only the next DOM comparison's name and expected array to the actual native empty-state placeholder:

```diff
- compare('native diagnostics DOM remains empty', await page.locator('.cm-diagnosticText').allTextContents(), []);
+ compare('native panel renders its empty-state placeholder', await page.locator('.cm-diagnosticText').allTextContents(), ['No diagnostics']);
```

No source timing, guard, fixture behavior, native call, assertion count or scenario was changed. This does not replace a failing guard with a weaker test: state emptiness and the native empty-panel rendering are still independently checked. The fixture has no phrase translation extension, so the pinned default English placeholder is the appropriate exact expectation.

The original `probe/` files and v1 archive remain unchanged. V2 gets a new strict check, source review and frozen input identity before a separately identified hosted run. This is a diagnosed oracle correction, not a blind retry.

## Custody

Root downloaded artifact `14761563185`; this lane independently read the result JSON and CM-2 screenshot and verified the ZIP bytes: **605,696 bytes**, SHA-256 `5fef20edf7e0e8cc7879f709a4fa3e40b5cf7252f1f26c55acbfaf4131778d6b`.

Evidence remains under `../root/editor-v1-attempt1/`: original `artifact.zip`, extracted `evidence/result.json`, `evidence/browser-trace.zip`, `evidence/CM-2-native-late-source.png` and `evidence/final.png`. The screenshot visibly shows selected B/g5 and rendered native-A on unchanged `seed`, matching the ordered trace. Its fixture heading “Useful diagnostics” is merely a rendered-result label; it is not a production health receipt for the selected generation.

V1 frozen input: SHA-256 `4b94cb4d40019d77eff78b4cb01c5199197fd9eacbdb0c071c84797df0e63576`, 18,005 bytes. The new complete operation, managed freshness gate and history-codec cases still await completion of the remaining scenarios; do not infer them from this partial run.
