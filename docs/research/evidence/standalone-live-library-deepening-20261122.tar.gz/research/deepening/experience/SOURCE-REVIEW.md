# Source review before native browser execution

Date: 2026-11-22. Source package: `probe/`. Plan: `PROBE-PLAN.md`.

## Authorization and review

1. `/root/deep_state_protocol` reviewed and approved the plan: UI freshness is separate from authority, equal text after Undo must not be confused with equal revision, direct and restored semantic Undo need separate checks, and native A/B source starts/completions require observed barriers.
2. `/root` read the plan and approved installation, implementation and strict TypeScript 7.0.2 checking. No native runtime was run during that stage.
3. The implemented package passed strict checking with one resolved TypeScript compiler, 7.0.2. All maintained fixture, typed browser interface and test-runner code are included in the same strict compiler project; library checks are not skipped.
4. `/root/deep_state_protocol` read the implemented source and approved it for a frozen native run. Its review confirmed native A/B ordering, native changed-document counterevidence, equal-text/revision distinction and the independent field-value/inverse-effect codec checks.
5. `/root` read the complete initial 507 LOC implementation. Root required one correction: tracing/teardown failure must not prevent result preservation or hide the original failure. The correction captures each teardown error independently, continues browser/server closure, writes the result and emits its JSON to stdout. A cleanup-only failure fails the test after evidence is emitted; an earlier test failure is preserved.
6. CM-6 now additionally compares the actual editable DOM reference across history-only clearing, matching the stated preservation claim. The corrected source passed strict TypeScript checking again.

Root authorized the hosted native run after these corrections and the strict check. Root owns workflow/input publication and remote execution. This lane has not run the browser test manually. The exact frozen inventory and hashes are in `INPUT-MANIFEST.json`.

## Deliberate constraints

- Native CodeMirror compartments, editor state/history/Undo, linter scheduling and diagnostic rendering remain the mechanisms under test.
- The only adapter behavior is a trusted contribution-generation/input-revision freshness check before public `setDiagnostics`; this is not authorization, revocation, a replacement history engine or another update coordinator.
- Long native lint delay plus public `forceLinting` establishes deterministic source starts. Actual source invocations, B's useful diagnostics and A's later completion are individually observed. Extra invocations fail the corresponding control.
- Snapshot restore includes both historyField and a validated numeric custom-field codec. The test compares the field value before Undo and the missing inverse-effect behavior after Undo.
- Real browser keyboard/input behavior is exercised. OS IME, cross-browser composition, production update publication and remote observation resync remain unqualified.
- The previous React/Vite browser49 input and receipts are untouched. Any correction after native failure requires a new frozen input and preserves the old failure separately.
