# Native editor update and late-result probe plan

Status: completed as corrected hosted v2 on 2026-11-22; one E2E, seven scenarios, 70 comparisons. The original v1 empty-panel oracle failure and one-line v2 correction are preserved separately. This plan records the original scope; see `NATIVE-RESULT.md` for the executed result.

Peer review: `/root/deep_state_protocol` approved this plan on 2026-11-22 with the incorporated precision requirements below. `/root` then approved installation, implementation and strict TypeScript 7.0.2 checking. A separate peer/root source review remains required before native runtime execution; root owns the hosted browser workflow.

## Decision this probe can change

Use native editor reconfiguration and history instead of creating a document/Undo subsystem in the plugin library. Determine the small contract still needed when an asynchronous contribution is replaced while its input text is unchanged. Qualify which editor state can survive an in-place contribution change or an explicit snapshot restore; do not equate either with a general plugin-state migration.

This is additional evidence beside the immutable React/Vite browser49 input and receipts. It does not rerun that fixture, implement another HMR protocol, qualify a production update orchestrator, or make CodeMirror mandatory for consumers.

## Read-only evidence already pinned

Published npm archives were read and SHA512-verified without installing or running them; exact archive/member hashes are in `source-provenance.json`.

| Package | Exact version | Published gitHead |
| --- | --- | --- |
| `@codemirror/state` | 6.7.6 | `651084c8a322b3a19b2bb3e00eee7d4a61d641af` |
| `@codemirror/view` | 6.43.15 | `da63d53a7b1f9011a09481f5fa2397294104d73a` |
| `@codemirror/commands` | 6.11.1 | `5d2ddbbf485a7e8b17c69cf58ebaebf8e375036c` |
| `@codemirror/lint` | 6.9.8 | `f71583124fa13052d0ac1c5ead5813448a429353` |

The registry now names `code.haverbeke.berlin` repositories. A GitHub default-branch read is therefore supplementary; released package bytes, not a presumed mirror branch, ground this experiment.

Two source-supported hypotheses deserve native negative controls:

1. Lint completion checks document object identity, but not the currently configured source identity. Reconfigure source A to B on the same document, complete B first and A later: A may overwrite B. `source/lint/index.js` has the exact `lintPlugin.run/update/destroy` implementation. This is not yet a reproduced released defect.
2. `historyField` JSON serializes changes, mappings and selections, but `HistEvent.fromJSON` restores an empty `effects` array. Document Undo may survive serialization while custom plugin effects in the same history event do not. This is a codec capability boundary, not presumed corruption or an upstream bug.

## Native test surface

Use direct CodeMirror `EditorView`, `Compartment.reconfigure`, `StateField`, `StateEffect`, native history/Undo/Redo, native `linter`, and public `setDiagnostics`/`forEachDiagnostic`. Use Playwright against a Vite-served page with real editable DOM, keyboard input, selection and rendered diagnostics. No React/CRDT wrapper, custom editor/history, monkey-patched internals, or invented reload transport.

Build tooling pins: TypeScript 7.0.2, Node 24.22.3, Vite 8.3.8, Playwright 1.65.1. All maintained fixture/test/config/runner source is `.ts`, `strict: true`; inspect the resolved compiler paths before execution. Exact transitive lock and browser/runtime inventory are recorded. Installation/typecheck/experiment execution require root and peer plan approval first.

## Scenarios and decisive observations

| ID | Native action | Evidence that would support the recommendation | Falsifier / failure handling |
| --- | --- | --- | --- |
| CM-1 | Type a draft, establish native Undo and selection; replace a compartment containing a view contribution and the same state-field identity | Same editor DOM, draft, selection and history; new contribution handles the next interaction; old view plugin `destroy` observed | Record precise failed invariant; do not swap in a handwritten state restore to make it pass |
| CM-2 | Same-document native linter A starts, native linter B replaces it, resolve B then A | Native diagnostics may end at A, exposing a source-generation gap despite a current document | If native source identity already fences A, record protective behavior and remove unnecessary bridge |
| CM-3 | Native linter starts, edit document, resolve the old promise | Old-document diagnostics suppressed by CodeMirror's existing identity protection | Preserve this positive counterevidence; do not describe the native linter as generically unsafe |
| CM-4 | For explicitly managed contribution tasks, call public `setDiagnostics` only after checking the current contribution generation and host document revision at application time | Current result displayed; predecessor completion cannot replace it; completion for a changed document rejected | Gate lives in one small adapter; no new supervisor, authorization owner, editor scheduler or production guarantee |
| CM-5 | Start a task, edit and Undo back to identical text, then complete the original task | Monotonic document revision differs; original result rejected despite equal text | A text-content comparison alone must fail this negative control; no assertion that text equality implies same logical input |
| CM-6 | Remove native history extension in one transaction and re-add it in a second, without changing the document; compare explicit new-state reset | History clear preserves draft, selection and editor; document reset is reported separately and deliberately resets requested state | Do not use one transaction that removes then restores the same field and accidentally preserves history |
| CM-7 | Native edit carries text and a custom inverted state effect; compare direct Undo with `EditorState.toJSON/fromJSON` including `historyField` and a serializable custom field | Direct Undo reverses both; round-trip text/history may restore while custom inverse effect is absent | Report exact codec limitation and require application-owned migration/rebuild policy; do not serialize closures or claim full semantic Undo recovery |

CM-4/5 use trusted host-owned generation/revision values. They qualify stale-result prevention at a UI adapter boundary, not permission revocation or malicious plugin isolation. Cancellation can be requested for efficiency but never supplies the correctness proof. A disposal flag may additionally reject completions after the view owner is disposed; it does not prove all plugin resources were reclaimed.

The UI generation/revision tuple is separate from a durable state authority epoch. CM-2 uses explicit observed source-start and completion barriers for A and B, never timer guesses; any scheduled additional native invocation is recorded. CM-5 records native document object identity after Undo as well as equal text and a changed revision: it challenges a text-only guard, not CodeMirror's native identity guard. CM-7 checks custom field value restoration separately from inverse-effect restoration, both before and after Undo.

## Observability and user control

The fixture labels requested candidate, selected contribution, currently useful rendered result and rejection reason independently. A useful result identifies generation and document revision. Diagnostics from a predecessor are not relabelled as current. The report maps these observations into a consumer UI contract (preview dependency closure, pause/coalesce, version holds, reset/revert actions and resync) without making this fixture a second update authority.

Native OS IME is excluded from a synthetic composition-event claim. Source analysis covers composition-sensitive editor replacement; unless a real input path can be qualified separately, IME remains an explicit unqualified acceptance row.

## Expected artifacts and review boundary

- Exact lockfile, strict compiler output/version, native browser/runtime inventory and deterministic release schedule.
- One native fixture package; tests are grouped by the seven distinct scenarios, with every comparison reported under its scenario rather than called an independent end-to-end test.
- Raw JSON observations, browser trace/screenshots and original failure evidence if any. A corrective attempt receives a separate input identity and evidence directory.
- Narrow adapter code estimated at 25–60 LOC; fixture/UI 200–350 LOC; browser scenarios and strict tooling 200–350 LOC. Estimates exclude third-party source bytes and release work. No production package is delivered by this experiment.
- Engineering judgments: native reconfiguration reuse confidence 9/10, achievable reliability for the stated local UI boundary 8/10, integration complexity 3/10. Same-document lint-race hypothesis confidence 8/10 pending execution. General state migration and OS IME confidence remain unqualified.

Root owns tracked documents, workflow, remote execution, commits and immediate pushes. This lane only owns its isolated scratch directory. Peer must critique source-generation provenance, the equal-text/revision case, history codec interpretation and whether any control accidentally replaces the library mechanism before runtime execution.
