# Native editor result: seven scenarios completed

**Passed:** one browser E2E test with seven scenarios and 70 comparisons. No page errors, console errors or harness cleanup errors. This qualifies the listed native editor boundary, not a production plugin update library.

- Run: [45042722838](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45042722838).
- Attempt 1; job `137270527195`; terminal success.
- Source commit: `719a6095445d67b1da7fa285bbb5ef8ecc589322`.
- Frozen v2 input: 18,027 bytes; SHA-256 `c9d80c35364f9b2c5ed97a086f0a8ff24a9b2bc675c0666292c1e75ebedf81c3`.
- Runtime: Node 24.22.3; Chromium 159.0.8154.6; strict TypeScript 7.0.2.
- Native packages: CodeMirror state 6.7.6, view 6.43.15, commands 6.11.1, lint 6.9.8; Vite 8.3.8 serves the fixture; Playwright 1.65.1 drives the browser.
- Artifact: `14762675791`, 1,207,123 bytes, SHA-256 `cf885324cc600c3d39037043ec4e5fbec34bd8e285af93e9260e5f6228f0a97e`. Root downloaded the ZIP. This lane independently verified its size/hash, all seven source files against the frozen manifest and exact equality of the artifact result with the separately fetched complete job-log result. The retained CM-4 screenshot was visually inspected.

## Actual observations

| Scenario | Comparisons | Observed result |
| --- | ---: | --- |
| CM-1 native contribution reconfiguration | 18 | Actual editor/content DOM, draft/document identity, selection/focus, field value17 and Undo retained; only B handled subsequent input; native pre-update history remained usable |
| CM-2 native late-source negative control | 7 | A started before source B replaced it; B rendered; late A overwrote B on the same document/revision while contribution B remained selected; exactly two source invocations |
| CM-3 native changed-document protection | 4 | Old result did not enter native diagnostic state; native panel displayed its `No diagnostics` placeholder; no confounding extra invocation |
| CM-4 narrow managed generation gate | 8 | B accepted at generation8/revision9; A from generation7 rejected despite identical document/revision; current native diagnostic, focus and selection retained |
| CM-5 equal text after Undo | 7 | Text returned to `seed`, revision advanced10→12 and native document ID changed11→13; completion for revision10 rejected |
| CM-6 clear history versus reset state | 13 | Native Undo/Redo emptied while dirty draft, content DOM, selection/focus and field19 remained; a separate explicit new-state reset changed document and initialized field0 |
| CM-7 native history codec boundary | 12 | Direct native Undo restored text and field7→0; after native JSON history/custom-field restore, field7 and text`changed` were restored; Undo returned text`seed` while field stayed7 |
| Final harness page-error check | 1 | No unhandled page errors; separate cleanup/console arrays were empty |

The narrow adapter uses public `setDiagnostics`; the editor, configuration, native linter, diagnostic renderer, transaction mapping and history remain CodeMirror mechanisms. The gate uses trusted local generation and document-revision metadata. It is not a security boundary, an external effect fence or a cancellation proof.

CM-7 is a JSON serialization/deserialization experiment in one browser. It does not test disk durability or crash restoration. The field codec and the history codec are checked separately, avoiding the false explanation that the custom field was merely never serialized.

## Original failure preserved

Run 45042075044, attempt 1, failed after CM-1/CM-2 at the CM-3 DOM oracle: actual `['No diagnostics']` versus expected `[]`. The native diagnostic-state check itself had matched `[]`. Its original artifact and input remain unchanged. V2 corrects exactly that one DOM expectation and its label; `v1-to-v2.patch` records the difference. No runtime behavior, delay, guard, scenario or assertion count was changed.

See `failure-analysis-v1.md`. Passing v2 does not relabel the original run as successful or add its repeated comparisons to the new result count.

## Explicit remaining gaps

- Real OS IME/composition and other browser/platform combinations.
- Continuing semantic freshness of already accepted output after later edits/config changes; native range mapping alone is not such a proof.
- Results whose inputs include other files, settings or workspace dependencies; the fixture has one document.
- Cross-process/remote task provenance, cancellation, malicious plugin isolation or arbitrary raw-reference revocation.
- Generic semantic Undo serialization, multi-document application history, arbitrary schema migration or durable restore.
- Production publication/reconciliation, full dependency cohort update, resource leak freedom, remote observer gaps and a reusable complete public operation.

The earlier React/Vite browser49 experiment remains independent. This fixture exercises native editor reconfiguration and asynchronous results; it does not repeat or extend that HMR qualification.

## Local evidence

`native-v2-review/` contains independent run/job/artifact metadata, the complete decoded job log, the parsed native result, per-scenario comparison totals and `artifact-verification.json`. The latter records the actual ZIP/source/result checks plus hosted input and installed-version receipts. `INPUT-MANIFEST-v2.json` retains the seven frozen source hashes; `TYPECHECK-v2.json` and `SOURCE-REVIEW-v2.md` retain the pre-execution gates. `REPORT.md`, `SCENARIOS.md`, `findings.json` and `sources.json` now distinguish executed behavior from source-only recommendations.
