# Root backend workflow and evidence review

Date:2026-11-22. Reviewer: state/publication research lane.
Disposition: **approved for the stated hosted experiment; no blocking finding**.
Review was read-only against the root repository. No database/test execution was
performed by this reviewer.

## Exact reviewed objects

- Workflow:`.github/workflows/live-update-backend-reliability.yml`
- Workflow SHA256:`9d30b12d84cf36c0da2d9f96b467caa0cf77d865f02beccf3c3ed4098e6374e5`
- Archive:`docs/research/evidence/live-update-backend-input-20261122-v1.tar.gz`
- Archive size:21514bytes.
- Archive SHA256:`06e8e448698bb2fa7af417c68822bbd4fb5fa5af71c62d2047ab426934814a59`
- Scratch source aggregate:`d8e90b0e58cd496ebfceb3b489dafaf795d0b65727a5a9370845de576bc344f9`
- Reliability document SHA256 at review:`c0c147e9eba790cba5f8d92fa71433bacbe630da78e64ea95107288c1af47c50`

I read the tar members without extracting or executing them. The archive hash
and size match its manifest; all15 names are unique regular files; all15 content
hashes and bytes match both the manifest and the reviewed scratch files in
`state/probe/INPUT.sha256`. There are12 maintained `.ts` files plus package,
lockfile and tsconfig. No runtime source was added or omitted by assembly.

## Workflow gates and outcomes

| Area | Observed configuration | Assessment |
| --- | --- | --- |
| Checkout | Exact event commit, credentials not persisted; contents:read | Appropriate for disposable research |
| Extraction | Archive bytes/hash, exact unique regular-member set, Python data filter, per-file byte/hash check | Preserves reviewed source identity |
| Native service | Ubuntu24.04; PostgreSQL18.7 bookworm digest pinned; disposable database and fixture password; health check | Real single-primary profile, not production/failover |
| Toolchain | Node24.22.3, pnpm11.25.0; direct installed identities checked against exact pins, sole TS7.0.2 package asserted | Real compiler gate before native TypeScript stripping |
| Install | Frozen lock, ignore scripts, engine/peer strict | No substituted compiler or dependency relaxation |
| Compiler | strict/noUncheckedIndexedAccess/exactOptionalPropertyTypes/noEmit; skipLibCheck=false; include**/*.ts | Covers all shared maintained source and declarations |
| Runtime | node:test, strict unhandled rejection behavior, one test-file concurrency |17 unique cases:12DB+3Worker+2joint; E02=S09 counted once |
| Identity | Records commit/run/attempt/workflow hash, input manifest, installed versions, image ID/repo digests; S01 checks native server180007 | Planned identity and actual observed version distinguishable |
| Evidence | Distinct state/execution/joint result paths; runtime/compiler/install logs; input source uploaded under always() | Retains failed attempts and partial observations |

The service image is
`postgres:18.7-bookworm@sha256:194e55feb2597b1465dbee81cc9fd8d204566cd2eb42c8d22fd6c931a38781b1`.
This review approves its configured profile; it does not claim the hosted runtime
has already started or passed. The read-only workflow review adds no DB evidence.

## Reliability document audit

The reviewed document correctly distinguishes selected artifact, useful result,
observer freshness and cleanup debt. It states that the publication protocol is
proposed, leaves policy/public SPI/adoption open, and does not claim persisted
identity reconstructs Worker heap. Unknown publication is not collapsed into a
retryable failure. The backend input section has the correct archive hash/file
count and does not count E02/S09 twice. Local Worker results are scoped to serial
admission and a controlled native generator, without claiming an HTTP transport,
concurrent budget, sandbox or memory bound.

Nonblocking consistency points for the next root-owned evidence update:

1. The mechanism/coverage tables still say Worker probe pending although the
   introduction/frozen-input section records local3/3. Similarly CM2–CM5 are
   grouped as pending although the original editor attempt already reproduced
   CM2 and observed the CM3 state guard before the DOM-oracle failure. Update the
   individual rows from receipts; do not mark the unreached scenarios passed.
2. Add the selected profile explicitly near old-write behavior: strict cutover
   fences *new* predecessor writes, whereas an exact historical effect replay
   returns its original receipt. Compatible writer coexistence may retain an
   effect epoch and requires its own proof; it is not a default ban on old writes.
3. The protected SQL effect is the inserted effect/receipt row, not an arbitrary
   external business action. S10 is a quiescent consumer-codec action; it does
   not prove atomic migration admission or old-writer preservation of new fields.
4. Uploaded source permits post-run comparison to the manifest, but the current
   workflow performs the hash gate before execution. The root should compare
   returned source bytes when closing the evidence receipt, as planned.

No broader test matrix is requested by these notes. Preserve the frozen input
for this run and record a new input only if source actually needs correction.
