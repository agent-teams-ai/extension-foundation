# Backend v1: RESTRICT error-code oracle failure

Run 45042722876, attempt 1; commit 719a6095445d67b1da7fa285bbb5ef8ecc589322;
job 137270527207. Conclusion: **failure**, 17 tests, 16 passed, 1 failed, 0 skipped
or cancelled. Native version: **PostgreSQL 18.7**, `server_version_num=180007`.
The raw log, three result files, runtime identities and original artifact are
retained under `hosted-attempt1/`. No local DB run or rerun occurred.

## Exact failure and reached coverage

S13 expected SQLSTATE 23503 for deleting an artifact held by a concurrent foreign
key reference. The fixture declares `ON DELETE RESTRICT`. PostgreSQL rejected
the deletion with **23001**, `restrict_violation`; the assertion expected
`foreign_key_violation` instead. The runtime prevented the unsafe deletion; this
is a test-oracle error, not an observed loss of referential protection.

The first controlled deletion reached its rejection. The reverse-order schedule
(delete first, then insert a missing-parent hold) and final no-dangling-reference
query were **not reached**. S13 remains failed; it must not be reported as passed
from the expected-looking error alone. The11 other DB cases,3 independent
Worker/Resources cases and2 joint cases passed in this same failed run.

## Primary source confirmation

- [PostgreSQL 18 error-code table](https://www.postgresql.org/docs/18/errcodes-appendix.html)
  distinguishes 23001 (`restrict_violation`) and 23503 (`foreign_key_violation`).
- [Exact18.7 referential-integrity source](https://github.com/postgres/postgres/blob/f5c41f6681c910b3f69951bf6fb97c6d74605d25/src/backend/utils/adt/ri_triggers.c),
  blob `e2768bca84c68eee1431e8c2da9149111a889dd5`, has a separate `is_restrict`
  branch emitting `ERRCODE_RESTRICT_VIOLATION`. Its missing-referenced-row branch
  emits `ERRCODE_FOREIGN_KEY_VIOLATION`.

## Narrow corrective input

Root authorized a separate `probe-v2` copied from the 15 frozen v1 input files.
The only source change is:

```diff
- const rejectedDeletion = assert.rejects(deletion, { code: '23503' });
+ const rejectedDeletion = assert.rejects(deletion, { code: '23001' });
```

The reverse-insertion expectation remains 23503. No SQL, transaction ordering,
barrier, timing, scenario, assertion removal, dependency or compiler configuration
changes. `hosted-attempt1/proposed-v2.diff` retains the exact diff. A new strict
TypeScript 7.0.2 check, source freeze and independent review precede any hosted v2
execution. The v1 sources/archive/outcome remain unchanged.

## Evidence identity audit

Artifact 14761889817 has 45823 bytes and SHA256
`bce0a8e37b6916b47c6c6708e5aab403d71791162a89a577a31f2ebab291b706`.
All 15 returned source/config files match v1's reviewed manifest and scratch bytes.
The run receipt matches the exact commit, original 21514-byte input archive and
workflow hash. Installed pg 8.23.1 / Resources 0.2.2 / TypeScript 7.0.2 and Node 24.22.3
match the frozen profile. Native image repo digest matches the configured 18.7
image. The useful result is partial native evidence with a preserved failed
acceptance row, not a green suite.

## Resolution in a separately frozen v2 run

[Run 45043862207](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45043862207)
at commit `9b33571e1586cc6801629a98b94fa1bc391c98cb` completed 17/17, zero
failed/skipped/cancelled. The single source correction described above remained
the only input-code change. All 15 returned files match the v2 freeze.

S13 reached both native lock-wait orders, awaited the 23001 deletion rejection and
23503 missing-parent insertion rejection, then queried and asserted zero dangling
canonical references. Its JSON receipt records both blocker lists and reports 0
after that assertion; it does not serialize the raw SQL count row. Physical blob
deletion and disconnected runtime custody remain outside the fixture.

The new artifact and independent review are retained separately under
`hosted-attempt2/` and `../execution/evidence/backend-v2-result-review.md`. This
resolution closes the corrected acceptance row; it does not rewrite v1 as a pass.
