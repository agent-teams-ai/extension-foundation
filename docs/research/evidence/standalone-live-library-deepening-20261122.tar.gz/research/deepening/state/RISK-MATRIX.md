# State/publication risk and scenario matrix

Checkpoint 2026-11-22. Hosted v2 run 45043862207 completed **17/17 passed**, zero
skipped/cancelled: 12/12 DB cases, 3/3 independent Worker cases, 2/2 joint cases.
S09 below is joint E02 and is counted once. Actual PostgreSQL 18.7 (`180007`);
source and runtime identities are audited in `hosted-attempt2/result-audit.json`.
The original v1 run remains failed at 16/17; only S13's first SQLSTATE oracle
changed in v2. Its reverse schedule and final invariant now ran successfully.

| ID | v2 result | Fault/risk | Native falsifier/oracle | Scope limit |
| --- | --- | --- | --- | --- |
| S01 | Passed | Two publishers overwrite each other | Two DB lock waiters, exactly one committed CAS, one conflict, coherent receipts | One primary, Read Committed |
| S02 | Passed | Same attempt/effect duplicated; old receipt misclassified | Same terminal publication; one effect; post-cutover historical replay; new stale effect blocked; changed payload/authority rejected | Retained receipts, no pruning |
| S03 | Passed | Attempt ID silently selects new inputs | Target/baseline/revision/cohort mismatch rejected, original unchanged | Toy scalar immutable fields |
| S04 | Passed | Artifact label ABA admits old work | A1/B1/A2 unique live IDs; independently stale revision/epoch/generation reject | Identity policy supplied by caller |
| S05 | Passed | Successful commit loses application reply | Child exits after commit; fresh controller observes/replays same receipt without advance | Not lost PostgreSQL wire ACK; no Worker reconstruction |
| S06 | Passed | Controller killed before commit | Native backend disconnect rolls back; original head/pending attempt; fresh continuation succeeds | Process failure, not database/power failure |
| S07 | Passed negative control | Wrong lock looks like fencing | KEY SHARE permits B update followed by A effect | Deliberately unsafe receiver behavior |
| S08 | Passed | Cutover races old state effect | SHARE creates observed lock wait; old effect precedes publication; new old-epoch effect blocked | Held raw SQL schedule plus reviewed receiver code, not paused plugin callback |
| S09 | Passed as E02 | Terminated guest's dispatched effect survives | Actual Worker exits, delayed guarded sink rejects, distinct unsafe sink accepts | Joint execution lane; physical termination not rollback |
| S10 | Passed | Old code cannot read new state | Native JSONB v2 variant rejected by old codec; rollback admission denied; compatible expanded value works | Quiescent toy codec, not atomic concurrent migration admission |
| S11 | Passed | Retry silently moves recovery baseline | Durable S0 survives controller death and later S1; changed same-attempt input rejects | Bytes/format validation and restore readiness separate |
| S12 | Passed negative control | One statement misses a conflicting winner | DO NOTHING/fallback CTE returns 0 after observed wait; fresh statement returns winner | Specific Read Committed schedule |
| S13 | Passed; v1 oracle failure preserved | Artifact reference races metadata deletion | Both native waits observed; RESTRICT deletion 23001 and missing-parent insertion 23503 asserted; final LEFT JOIN count equals 0. | Canonical metadata only; no physical object-store deletion or disconnected runtime custody guarantee. |

## Unqualified acceptance rows

| Remaining risk | Required owner/evidence before production adoption |
| --- | --- |
| Lost DB COMMIT wire response, primary failover, replica staleness | Actual deployment topology and driver reconciliation fault test |
| Concurrent schema admission with new writer traffic | Application migration owner supplies atomic guard or an explicit drain/write barrier |
| Old writer silently discards new fields or breaks backfill | Actual writer coexistence tests, not just successful old/new decoding; preserve or deliberately migrate each field |
| Old/new compatible writers sharing authority | Separate profile proof; strict exclusive fencing here is not a universal policy |
| Receipt pruning and delayed retries after retention horizon | Provider-specific replay contract plus custody/retention acceptance test |
| Blob deletion with disconnected runtime holder | Artifact owner admission/deletion protocol; native FK alone insufficient |
| Durable workflow replay and live Worker restoration | Existing engine/profile plus actual fresh Worker activation/readiness proof |
| Long SQL effect latency and contention | Bound real receiver critical sections; load qualification in actual application |
