# Review disposition — state probe

Date: 2026-11-22. Plan approved by root and execution peer before implementation.
No native database experiment executed by this lane at this checkpoint.

## Peer changes accepted

- Historical effect replay returns the immutable original receipt after cutover,
  with exact authority/schema and PostgreSQL JSONB semantic-value comparison.
  A new stale effect remains rejected. After uniqueness contention, the receiver
  performs a fresh statement lookup and validates the winner.
- Publication lock order is attempt→head; effect order is head→effect. Same-attempt
  publishers serialize before CAS and return the same terminal outcome.
- Artifact A may be selected again as fresh live A2, never the old A1 identity.
  S04 independently exercises stale publication revision, epoch and generation.
- Fault child checkpoint wait now rejects on early exit/error, kills after a
  bounded timeout, and cannot leave an unused-mode rejection unhandled.
- Scenario setup failures are recorded. S08 is explicitly a held raw SQL lock
  schedule plus inspected receiver composition; no hook executes guest code inside
  a transaction.

## Root source review

The root reviewed the fixture, child and 12 DB scenarios. Read Committed
reconciliation, lock ordering, historical receipt handling, S12 visibility and
FK controls were accepted in principle. Native execution remains gated on the
frozen shared-backend source/hash review. The protected effect is the inserted
database row; this fixture does not claim atomicity with arbitrary external
business effects. S10 remains a quiescent toy codec admission counterexample.

## Compiler disposition

Exact TypeScript 7.0.2; strict/noUncheckedIndexedAccess/exactOptionalPropertyTypes,
noEmit, skipLibCheck=false. Initial check failed 3 times because pg query parameter
arrays were marked readonly. Fresh parameter arrays now use mutable unknown[];
no cast, compiler suppression or weaker configuration was introduced. The
initial and successful reviewed logs are retained separately.

The shared input then added 9 execution-lane TS files and Resources 0.2.2 to the
same package/lock. Its first strict check found 2 Worker narrowing errors, retained
in `typecheck-shared-initial.log`. The execution owner added a checked record type
predicate and read the actual private exit receipt after the asynchronous native
callback. The second shared check passed with unchanged strictness. Runtime input
has 15 files and aggregate SHA256
`d8e90b0e58cd496ebfceb3b489dafaf795d0b65727a5a9370845de576bc344f9`.

Only the execution lane is authorized to run 3 local non-DB Worker cases. Root
owns the hosted PostgreSQL 18.7 run. The image selected by root is
`postgres:18.7-bookworm@sha256:194e55feb2597b1465dbee81cc9fd8d204566cd2eb42c8d22fd6c931a38781b1`;
this is planned runtime identity, not observed server evidence at this checkpoint.

Counts: 12 DB scenarios; S09 is the joint real Worker/DB scenario owned by the
execution lane. It must not be counted twice when combining reports.

## Hosted v1 result and corrected v2 source review

The statements above preserve the original pre-run checkpoint. Hosted run
45042722876 subsequently executed that exact input on PostgreSQL 18.7 (`180007`):
16/17 passed, with S13 failing its first SQLSTATE expectation. Actual `ON DELETE
RESTRICT` returned 23001; the test expected 23503. The reverse insertion branch
and final no-dangling check were not reached. All 15 returned source/config files
match the reviewed input. See `failure-analysis-v1.md` and
`hosted-attempt1/result-audit.json`.

Root authorized a separate `probe-v2`. An independent execution-lane review
compared all 15 files and the pinned PostgreSQL source: only the first deletion
assertion changes to 23001; the reverse insertion expectation stays 23503.
No SQL, transaction schedule, fixture implementation, dependency or compiler
setting changed. The original source/archive remain intact.

The unchanged frozen lock installed successfully. Exact TypeScript 7.0.2 strict
`noEmit` passed over all 12 TS files and dependency declarations; the version and
compiler output are retained in `probe-v2/`. Its 15-file manifest hash is
`6f785a7d9c65343a0d785d74dcf7f371fd206123ae0eff3428ccae627ccdcf24`.
No native v2 execution occurred in this lane. Root owns the next hosted run.

## Terminal v2 result audit

Root's hosted run 45043862207 subsequently completed 17/17, zero skipped, against
commit `9b33571e1586cc6801629a98b94fa1bc391c98cb`. The state lane fetched logs and
artifact read-only; it performed no local native execution or rerun. Actual
PostgreSQL 18.7 (`180007`), image digest and exact compiler/runtime packages match
the reviewed profile. All 15 returned source/config files match frozen v2.
The workflow differs from v1 only in its two source input filenames.

Both S13 lock-wait schedules and its final count assertion passed. An independent
execution-lane result review checked the source, raw counts, identity/exit
receipts and S13 evidence limits. See `hosted-attempt2/result-audit.json` and
`../execution/evidence/backend-v2-result-review.md`. The original v1 failure and
all stated production qualification gaps remain preserved.
