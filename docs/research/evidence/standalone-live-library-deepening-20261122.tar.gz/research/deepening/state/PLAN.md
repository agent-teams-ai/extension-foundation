# Native state/publication/recovery probe — plan before execution

Date: 2026-11-22, Europe/Kiev. Status: root and execution peer reviewed 2026-11-22; implementation approved; no native
PostgreSQL execution yet. This extends the prior native ALS/Yjs/browser evidence
with the actual state receiver and independently connected controllers.

## Boundary and reuse

Use a disposable real PostgreSQL **18.7** service (supported release published
2026-11-12), the released node-postgres driver with an exact verified pin, Node
24.22.3 and strict TypeScript 7.0.2. PostgreSQL 19.0 is newer; this deliberately
qualifies one supported 18.x profile, not every version. Record actual server
version/image identity and all installed package identities. No ORM, migration
framework, lock service, WAL or durable workflow engine is implemented.

The database adapter is a **test host's narrow authority fixture**, not a new
public library or replacement for an application's existing canonical store.
PostgreSQL owns transactions, uniqueness, row locks and crash rollback. One
checked-out client owns each transaction; no transaction uses pool.query.
Candidate/plugin code never executes inside these transactions.

The selected integration mode allows A's admitted computation/stream to finish
on A's retained implementation after B publishes, but fences new A commits to
shared mutable state. This is an explicit mode. It does not prescribe that all
long-lived operations lose write permission during every kind of update.

## Experimental seam

Publication/durable-attempt and shared-effect receiver are separate concerns:

- `readHead()` returns generation, monotonic publication revision, effect epoch
  and immutable cohort ID. These identities are separate; this strict-cutover
  fixture advances both revision and effect epoch on publication.
- `admitAttempt({attemptId, expectedRevision, expectedGeneration,
  targetGeneration, cohortDigest, baselineId})` durably records exact inputs.
  Reusing an ID with different inputs is rejected. Replaying the same inputs
  returns the existing attempt, including its selected baseline.
- `publishAttempt(attemptId)` uses the recorded expected head and returns a
  durable committed/conflict outcome in the same transaction as head mutation.
- `observeAttempt(attemptId)` returns recorded pending/committed/conflict or
  absent/unknown. An absent row is not evidence that external effects never ran.
- `guardedWrite({effectId, generation, effectEpoch, stateSchema, value})` checks the actual
  authority row and commits the effect under the same receiver transaction.
  Same key/different payload or authority is rejected. Replaying an already committed effect after cutover returns its original receipt without a new write; a new stale effect is rejected. The receiver rechecks the committed receipt after unique-key contention with a fresh statement snapshot.

Revisions and effect epochs cross the fixture boundary as decimal strings, not
lossy JS numbers. State schema, live generation, artifact/cohort and publication
revision are independent contract axes; a future compatible-write mode may
preserve an effect epoch across a code publication.
Cohort IDs are inert values supplied by the caller; no dependency grammar or
graph planner is recreated. Lock order: publication takes attempt then head; effects take head then effect. Publication serializes same-attempt callers before CAS; the second observes the original terminal result. No transaction path inverts these locks. Test-only synchronization hooks and raw clients are
kept out of these feature seams.

## Oracles and synchronization

Use explicit inter-process messages and database-visible lock waits
(`pg_blocking_pids`/`pg_stat_activity`) to establish ordering. A sleep is never
the only evidence that concurrent work started or was blocked. Every case has
a bounded timeout and finally cleanup of only its own clients/processes/schema.
No load/throughput conclusion is drawn from these schedules. The deliberately
held FOR SHARE lock is a test barrier; production SQL critical sections must be
bounded and contain no plugin callback or awaited Worker computation.

| ID | Decisive native case | Independent outcome |
| --- | --- | --- |
| S01 | Two connections capture the same expected head and race B versus C | Exactly one CAS publication succeeds; one conflicts; head revision advances once; both durable outcomes are coherent |
| S02 | Two connections concurrently submit the same attempt and publication | One durable attempt, one head advance, identical terminal outcome on replay |
| S03 | Same attempt ID with changed target, baseline or expected revision | Explicit mismatch; original immutable inputs/outcome remain unchanged |
| S04 | A1 → B1 → A2 distinct live generations, artifact/human label A reused; stale request from A1 | Monotonic publication revision and separate effect epoch reject stale publication/write despite repeated human/artifact label |
| S05 | Controller child commits publication, then exits before sending the application reply; fresh child/controller reconciles | Recorded outcome and head agree; same-attempt retry adds no publication/effect; claim is lost application reply, not a simulated lost PostgreSQL wire COMMIT acknowledgement or reconstructed Worker readiness |
| S06 | Controller child holds uncommitted head/outcome changes and is killed | Backend rollback leaves old head and no committed receipt; fresh controller can continue using the already recorded attempt |
| S07 | Negative control: old writer uses FOR KEY SHARE on non-key head revision; B publishes before A commits | Actual late old write succeeds, demonstrating that this weaker lock is not the required fence |
| S08 | Positive control: old writer holds FOR SHARE through its state effect; B publisher contends | Native lock wait is observed; A commits before B publication; after B publishes, a new A write is rejected |
| S09 | A worker exits after a request was dispatched to the parent-owned sink; release that delayed request after B publishes | Guarded sink rejects stale A; separate explicitly unsafe sink accepts it, proving worker termination is not external-effect rollback |
| S10 | New writer stores a v2-only state variant; old decoder attempts read/write after code rollback | Actual old decoder rejects incompatible state; guarded rollback admission is denied; the expanded compatible writer profile remains readable by both |
| S11 | Durable attempt records baseline S0; controller dies; S1 appears; same attempt resumes | Resumed attempt retains S0; a genuinely new attempt may select S1 |
| S12 | Concurrent INSERT ON CONFLICT DO NOTHING + same-statement fallback SELECT encounters another uncommitted insert | Negative-control statement may return no row after the conflict commits; a fresh statement observes the winner; no missing receipt is mislabeled as absent authority |
| S13 | Artifact metadata deletion races a new retained-reference insertion with native FK restriction | No dangling committed canonical reference; identify which transaction succeeds. This does not prove physical object-store deletion or full runtime retention |

S09 is joint integration with the execution lane; it must use real Workers and
the real database effect sink, not only model counters. S10 uses explicit
consumer codecs and disposable JSONB state; a toy codec counterexample does not
qualify arbitrary production schema migrations.

## Evidence and scope

Preserve the pre-execution plan, exact sources/locks/configuration, installation
and strict-compiler logs, actual server identity, test output and machine-readable
observations, all failures and source hashes. Parent owns hosted workflow,
publication and immediate push. Native execution starts only after review.

Estimated fixture/integration code: 500–850 lines; tests/oracles/fault-child:
350–650 lines; research/configuration/evidence: 150–300 lines. No production code
is adopted. Design confidence 8/10, bounded achievable reliability 8/10,
complexity 6/10. These are planning judgments, not availability measurements.

Unqualified: PostgreSQL failover/power loss, distributed replica linearizability,
external network effects, generic workflow replay, every isolation level,
performance/overload bounds, arbitrary migration reversibility and production
library admission.

## Primary source basis already read

- PostgreSQL 18 explicit locking:
  https://www.postgresql.org/docs/18/explicit-locking.html
- PostgreSQL 18 isolation/Read Committed:
  https://www.postgresql.org/docs/18/transaction-iso.html
- PostgreSQL 18 INSERT/ON CONFLICT:
  https://www.postgresql.org/docs/18/sql-insert.html
- PostgreSQL 18.7 released version:
  https://www.postgresql.org/docs/18/release-18-7.html
- node-postgres transaction ownership:
  https://node-postgres.com/features/transactions

Exact source/tag/package identities and additional industry counterexamples are
being recorded in sources.json; these documentation observations are not native
passes.
