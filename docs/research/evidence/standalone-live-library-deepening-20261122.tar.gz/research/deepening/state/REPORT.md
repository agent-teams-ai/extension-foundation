# State, concurrent publication and recovery — deeper checkpoint

Date: 2026-11-22. **Hosted v2: 17/17 passed, zero skipped or cancelled.**
[Run 45043862207](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45043862207)
executed the reviewed input on actual PostgreSQL 18.7 (`180007`), Node 24.22.3,
pg 8.23.1 and Resources 0.2.2, after strict TypeScript 7.0.2 compilation.
Counts are 12/12 DB cases, 3/3 independent Worker cases and 2/2 joint cases.
S09 is joint E02, not additional coverage. Earlier local Worker and hosted v1
passes repeat these cases and are not added to the total. [ST-S19]

**The original v1 failure remains recorded: 16/17.** S13's first assertion
expected SQLSTATE 23503 for `ON DELETE RESTRICT`; PostgreSQL correctly returned
23001. The separate, peer-reviewed v2 changes only that expectation. Reverse
insertion still expects 23503. The new run reached both native wait orders and
the final no-dangling-reference assertion. No SQL, dependency, barrier or compiler
setting changed. See `failure-analysis-v1.md`, the preserved v1 evidence and
`hosted-attempt2/result-audit.json`. [ST-S17–19]

All 15 returned source/config files match frozen v2. `probe/INPUT.json` records
v1; `probe-v2/INPUT.json` records the correction. Initial driver/Worker type errors
remain in separate logs; none was suppressed. No production adapter or public SPI
is proposed. `guardedWrite` atomically inserts the protected effect/receipt row
itself; it does not atomically execute an arbitrary business action at another
service.

## What the native run established

| Observation | Design consequence | Boundary |
| --- | --- | --- |
| Two publishers waited on actual PostgreSQL locks; one CAS committed and one conflicted. Same-attempt publishers returned one terminal result. | Commit head selection and its attempt receipt together; reconcile immutable intent. | One primary at Read Committed; no failover proof. |
| A process exited after commit before its application reply; a fresh controller read and replayed the original receipt. A second process was killed before commit and PostgreSQL rolled back. | Recovery needs an observable same-attempt outcome, not a new update attempt. | Application reply loss, not a dropped PostgreSQL COMMIT wire acknowledgement; no restored Worker heap. |
| `KEY SHARE` allowed an old effect after B publication; `SHARE` made publication wait, then rejected a new old-epoch effect. | Receiver-side authority and the effect must share a bounded SQL transaction. | The held lock is a test barrier, never a plugin callback inside the transaction. |
| A committed old effect replayed its original receipt after cutover; a new stale effect was rejected. | Historical replay is distinct from current write authority. | Receipt retention was not pruned. |
| Real A code/dependency produced 9 then 11 across B publication; B produced 120 then 125. After actual A termination, a delayed parent-owned request still reached the receiver: the fence rejected it, the unsafe control wrote 37. | Keep operation cohort identity and receiver fencing through the whole operation. Physical guest exit cannot cancel dispatched host work. | A literal module cohort and async generator, not arbitrary graph loading or a network stream. |
| `DO NOTHING` plus a same-statement fallback returned no row after a native uniqueness wait; a fresh statement found the winner. | A missing `RETURNING` row is not evidence that nobody committed. | PostgreSQL 18.7 schedule; PostgreSQL 19's native alternative remains source-only. |
| Concurrent retain-before-delete and delete-before-retain both produced native waits and the expected rejection; the final query found no dangling reference. | Reuse native referential protection for canonical retention metadata. | Does not protect physical blob deletion or disconnected runtime custody. |

The audit checked raw counts, image/runtime identities, returned source hashes and
native exit evidence. Independent execution-lane reviews agree with both the
preserved v1 failure and the terminal v2 result. [ST-S18–19]

## Decisions changed by this pass

**Keep the library's ready-to-use update operation; give the existing state
owner narrow publication and effect ports.** A copied generation counter or TTL
lock in the library would not protect a delayed effect at its actual receiver.
The experimental host uses PostgreSQL transactions, row locks, uniqueness and
foreign keys. It does not recreate those mechanisms. Its exact pins are
PostgreSQL 18.7, pg 8.23.1, Node 24.22.3 and TypeScript 7.0.2. [ST-S01–04]

The strict-cutover profile fences predecessor **new writes**, while its admitted
read/computation/stream can finish on retained code. This is one profile; compatible
writer coexistence can have different authority rules. Keep publication revision,
live generation, effect epoch, state schema and immutable artifact identity
separate. Reusing artifact A produces live A2, never resurrection of A1. [ST-F06]

### Concrete mistakes to prevent

| Mistake | Evidence and consequence | Recommended boundary |
| --- | --- | --- |
| Use `FOR KEY SHARE` for a head whose non-key revision changes | PostgreSQL permits the competing non-key update. S07 deliberately demonstrates the unsafe schedule; S08 uses `FOR SHARE`. | Existing state owner checks authority and writes in one bounded SQL transaction. No plugin callback inside it. |
| Retry publication after a timeout as a new attempt | The outcome may already be committed; etcd documents the same uncertainty at an RPC boundary. | Immutable attempt inputs; CAS and terminal receipt commit together; reconcile the same attempt. |
| Return `stale` for every old-epoch request | A previously committed request may be a historical replay. | Return its original validated receipt; reject a new stale effect or changed intent. |
| Treat `INSERT … DO NOTHING RETURNING` plus a same-statement fallback query as guaranteed read-or-create | Under Read Committed, the conflict can be visible to uniqueness enforcement but absent from that statement snapshot. | Fresh statement lookup after conflict, including after a uniqueness wait. S12 is the native negative control. |
| Equate restored DB head with a restored live plugin | Controller durability says nothing about Worker heap/readiness. | Report selected artifact, activation readiness and effect authority independently. |
| Offer unconditional rollback once V2 has written | Vitess itself cannot revert widened values or duplicate values into a stricter old schema. | Evaluate current data and old/new reader/writer compatibility; use the application's migration system. |
| Delete by age or “no current route points here” | Recovery baselines and replay receipts may still be required. | Record retention reasons/custody; native FK protects canonical metadata only. Physical blob deletion remains a separate owner protocol. |

Native observations support the scoped rows above. Broader migration, custody,
provider retry and failover conclusions remain source-grounded implications,
not additional executed passes. [ST-S01–09, ST-S12–15, ST-S19]

## New industry evidence, with limits

**PostgreSQL 19:** released 2026-11-19, it adds native
`INSERT … ON CONFLICT DO SELECT … RETURNING`, an atomic get-or-create with optional
row locking. This is a concrete reuse candidate for a qualified 19 adapter;
do not turn the 18.x two-statement lookup into a universal helper. We checked
both release-tag grammars: 18.7 lacks the syntax. The current frozen runtime
remains18.7;19 is source evidence, not an executed pass. [ST-S16]

**etcd 3.6.0:** its native mutex exposes `IsOwner()` as a creation-revision
comparison. That is reusable inside an etcd transaction; checking ownership in
etcd and then writing PostgreSQL is still two independent commits. Reuse the
actual receiver's primitive, and do not add etcd just to manufacture another
authority service. Its watches are useful notifications, not authoritative
linearizable observations. [ST-S05–06]

**GitLab:** the pinned migration guide separates ignored columns, post-deploy
removal and later cleanup because code versions and ORM schema caches coexist.
Original issue 375343 reports saves failing after a column was added, mitigated
by restarting pods. The issue explicitly asks for reproduction; the suspected
cache mechanism is not a confirmed root cause, and linked incident 7792 was
unavailable. Qualification must include the actual old/new consumers, not just
syntactically additive DDL. [ST-S10–11]

**Vitess 24:** native revert is an independently tracked migration, constrained
by retained artifacts, the last successful table migration and a documented
window. New writes can make reversal impossible. This directly changes the
product action: “select old code” and “restore compatible state” are different
operations with different admission evidence. S10 uses a real stored JSONB
counterexample, but its codec check is quiescent, not a concurrent migration
protocol. [ST-S12]

**AWS/Stripe:** retain intent, not just a UUID. AWS describes rejecting changed
parameters and returning the original logical outcome after resource deletion.
Stripe v1 may replay an original error and permits old keys to be pruned; v2
instead describes resuming failed/partial work within its longer scoped window.
One generic “retry succeeded” flag would erase these differences. External
effect adapters need an explicit provider/API contract and expiry behavior.
No external service call was executed. [ST-S07–09]

**Flink 2.2.0:** stable operator IDs preserve state association; intermediate
savepoints are distinct from side-effect commit/recovery boundaries. Its
NO_CLAIM mode keeps snapshot custody with the user and breaks dependencies with
the first full checkpoint; CLAIM transfers cleanup ownership. We verified the
same-tag enum because the guide's statement about removal of LEGACY is stale:
the enum still includes it as deprecated. Borrow the custody contract, not a
second implementation of Flink checkpointing. [ST-S14–15]

**Original GitHub 2018 postmortem:** divergent writes made immediate failback
unsafe. During recovery, about 200000 queued webhook payloads expired and were
dropped before operators changed the TTL. A long update/recovery can therefore
invalidate “temporary” retention assumptions. This is an operational warning,
not evidence that our single-database fixture reproduces distributed failover.
[ST-S13]

## Reuse and ownership

| Concern | Reuse | Code that remains ours | Do not build |
| --- | --- | --- | --- |
| State publication and guarded effects | Consumer's existing DB transaction/CAS; pg only in this fixture; native get-or-create on qualified PostgreSQL 19 | Map narrow outcomes into update receipts and reconciliation | DB, WAL, lease server, generic transaction DSL |
| Schema evolution | Consumer migration framework; GitLab patterns; Vitess only for a matching stack | Plan compatibility checks and expose blocked rollback reasons | Universal schema interpreter or automatic inverse migration |
| External effects | Provider's idempotency/reconciliation API | Qualified adapter and retained intent | A universal exactly-once claim across unrelated stores |
| Durable workflow recovery | Existing durable engine where requested | Version/custody adapter and visible recovery phase | Workflow replay/checkpoint engine inside default TS core |
| Artifact/state retention | Canonical references plus existing artifact owner | Explain holds, release eligibility and unresolved cleanup | Age-only garbage collector that bypasses ownership |

Prior Temporal/Restate/Golem findings remain prior evidence. This pass adds
receiver-level concurrency, snapshot visibility, original incidents, migration
limits and custody distinctions; it does not recount those earlier engines as
new research.

## Native acceptance and remaining risks

`PLAN.md` defines 13 scenarios:12 isolated DB cases plus S09 jointly with actual
Workers. The suite uses separate connections, `pg_blocking_pids`/native lock waits,
process death and fresh controller connections. Original failures are retained.
The held SQL lock is a test schedule, not permission to hold a production
transaction while waiting for plugin work.

The experiment can qualify one PostgreSQL 18.7/Read Committed schedule. It cannot
qualify database failover, replica reads, arbitrary network effects, every
migration, production latency, distributed physical deletion or restored heap.
In particular, S10 does not prove that an old writer preserves newly introduced
fields or safely participates in dual-write/backfill; readability alone is
insufficient for that coexistence profile.
19 source/evidence records and 13 findings are in `sources.json` and
`findings.json`; scenario status is in `RISK-MATRIX.md`. These include the original
failed run and corrected successful run as separate evidence records, not as
additional industry sources or distinct acceptance cases. Strict compilation
and source review remain distinct from observed native outcomes.
