# Control policy, receipts and evidence depth

Observed 2026-11-22. This lane inspects exact source and documentation; no Argo,
OpenFeature or Kubernetes runtime was executed. Native PostgreSQL/Worker/editor
evidence belongs to the other three lanes. Do not add source-only findings to
their native test counts.

## What a successful update result must explain

Argo Rollouts provides useful distinctions between candidate traffic, stable
traffic, paused analysis and completed rollout. Its analysis documentation and
controller also expose why copying a single green status is insufficient.
At commit `8c9c5ad2182ba7757bb6a35e79d2051afc31feee`,
`assessMetricStatus` returns Successful for a terminated metric with no
measurements; it also has a terminating-success branch after failure/error and
count checks. `assessRunStatus` has the corresponding no-measurements branch.
The documentation explains that premature termination need not satisfy the
consecutive-success threshold. Dry-run metrics deliberately do not decide the
rollout result. These are documented policies, not reproduced defects. [CP-S01]

**Transfer:** retain reason and evidence alongside status. Distinguish an observed
healthy candidate, owner override, a skipped check, insufficient evidence,
timeout, cancellation and cleanup failure. An “active” generation can still have
no observed useful output, and a “retired” intention can still own live resources.
A policy adapter must preserve the upstream meaning when projecting its result.

Argo's rollback window can skip rollout steps for a retained prior ReplicaSet.
That is useful traffic recovery; it does not establish that old code can read
state written since the original rollout. State-lane Vitess and native JSONB
evidence qualify that separate question. The plugin library should expose the
selected rollback/restart action and its current compatibility evidence before
execution, including skipped checks. It should not require Kubernetes to gain
these semantics. [CP-S02]

## Reuse lifecycle notifications without moving authority

The OpenFeature specification at
`b489ba9134ee081cecaf18a28b544ddabc1b25f7` requires explicit ready, error,
configuration-change, stale, reconciling and context-change events. Provider
status is derived from those events. Global/client handlers are scoped to their
provider association; handlers survive provider replacement, and late readiness
registration has specified behavior. A failing handler must not prevent other
handlers from running. Static-context reconciliation requirements carry the
specification's hardening status. [CP-S03]

**Transfer:** OpenFeature is an optional integration for rollout intent, never
an alternative plugin activation owner. A flag change requests an eligible
transition; it does not itself publish the generation or reverse user data.
Represent stale observations honestly, isolate observer failures, and initialize
late subscribers from a coherent snapshot. Reuse native observer/external-store
facilities. A bespoke global event platform is not needed to supply a read-only
library projection.

## The library operation and its policy inputs

The owner has accepted that consumers receive a complete operation. Narrow
ports therefore describe authoritative primitives, not a list of callbacks from
which every product reconstructs the protocol. The core owns decision sequencing
and correlated outcomes. Get Modular owns graph plans. Resource scopes track
ownership, cleanup attempts and debt; the execution adapter retains the physical
handle and implements its registered stop operation and receipt. Products own
grants, schemas and durable publication/effect receivers. The coordinator does
not create a second shutdown owner.

The important branch is **unknown outcome**, not only success/failure. If a
publication reply is lost, eagerly destroying the candidate may kill the selected
generation; retrying a new attempt may advance the head twice. Reconcile the
immutable attempt first. A positively known conflict releases the loser and
requires a new plan for any new predecessor. A durable selected artifact cannot
be presented as a surviving worker heap after host restart. Useful output also
identifies the relevant input revision and result criterion where applicable.
Unknown publication, stale observation and unconfirmed physical stop have
different reconciliation owners; a useful selected version can coexist with
cleanup debt.

The declared policy should answer five independent questions:

1. Which new operations may enter while preparation and publication occur?
2. Which old computations may finish, and which receivers still accept writes?
3. What concrete condition or budget bounds retention of old executions?
4. What happens on deadline, unknown result and cleanup debt?
5. Which user state/history can be preserved, reset, transformed or restored?

These are policy dimensions, not a proposal for a public configuration DSL.
Advertise only combinations supported by the execution and state profiles.
Partial capability must cause a plan rejection or an explicitly disclosed
fallback, never an implicit broader application restart.

## What still needs a separate native qualification

The new fixtures deliberately exercise existing primitives. They do not yet
demonstrate a released reusable coordinator. A proposed stronger adoption gate is
one complete operation through at least one real consumer and an independently
authored second consumer, including conflict, ambiguous publication, unavailable reconciliation,
lost live executor and cleanup failure. Its conformance suite must validate
advertised guarantees through consumer-observed behavior, not only against its
own in-memory model. The second consumer is a proposed acceptance criterion,
not an existing organization requirement or a new blocker for this research.

Further gates remain actual network commit ambiguity/failover, overlapping
multi-controller admission, arbitrary in-flight dependency callbacks, concurrent
schema cutover, persisted semantic Undo, real platform IME, physical artifact
deletion with disconnected holders, external provider retry expiry and measured
latency/resource budgets. A passing editor or database slice does not silently
check those rows.

## Sources

- CP-S01: [Argo analysis documentation](https://github.com/argoproj/argo-rollouts/blob/8c9c5ad2182ba7757bb6a35e79d2051afc31feee/docs/features/analysis.md) and [controller source](https://github.com/argoproj/argo-rollouts/blob/8c9c5ad2182ba7757bb6a35e79d2051afc31feee/analysis/analysis.go).
- CP-S02: [Argo rollback window](https://argoproj.github.io/argo-rollouts/features/rollback/), retrieved 2026-11-22; official documentation, not a native test.
- CP-S03: [OpenFeature event specification](https://github.com/open-feature/spec/blob/b489ba9134ee081cecaf18a28b544ddabc1b25f7/specification/sections/05-events.md), blob `82fdea7be6e448eeb86ea6128a2413dfcabfe2d8`; specification requirements, not SDK implementation evidence.
