import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type BrowserContext, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import type { EditorSnapshot } from './fixture/probe.ts';

const directory = path.dirname(fileURLToPath(import.meta.url));
const evidence = path.join(directory, 'evidence');
interface Comparison { scenario: string; name: string; actual: unknown; expected: unknown; }
const read = (page: Page): Promise<EditorSnapshot> => page.evaluate(() => window.editorProbe.snapshot());
async function reset(page: Page, text = 'seed'): Promise<void> {
  await page.evaluate(text => window.editorProbe.reset(text), text);
}
async function insertAtEnd(page: Page, text: string): Promise<void> {
  await page.evaluate(() => {
    const length = window.editorProbe.snapshot().text.length;
    window.editorProbe.select(length, length);
  });
  await page.keyboard.insertText(text);
}
async function expectDiagnostics(page: Page, message: string): Promise<void> {
  await page.waitForFunction(message => document.querySelector('.cm-diagnosticText')?.textContent === message, message);
}

test('native CodeMirror update, stale completions and history codec across seven scenarios', { timeout: 120_000 }, async () => {
  await mkdir(evidence, { recursive: true });
  let server: ViteDevServer | undefined;
  let browser: Browser | undefined;
  let context: BrowserContext | undefined;
  let page: Page | undefined;
  let scenario = 'setup';
  const comparisons: Comparison[] = [];
  const completedScenarios: string[] = [];
  const observations: Record<string, unknown> = { successful: false };
  const pageErrors: string[] = [];
  const consoleMessages: string[] = [];
  const cleanupErrors: string[] = [];
  let hasPrimaryFailure = false;
  const cleanup = async (step: string, action: () => Promise<unknown>): Promise<void> => {
    try { await action(); } catch (error) { cleanupErrors.push(`${step}: ${String(error)}`); }
  };
  const compare = (name: string, actual: unknown, expected: unknown): void => {
    comparisons.push({ scenario, name, actual, expected });
    assert.deepEqual(actual, expected, `${scenario}: ${name}`);
  };
  try {
    server = await createServer({ configFile: false, root: path.join(directory, 'fixture'),
      server: { host: '127.0.0.1', port: 0, strictPort: false }, logLevel: 'info' });
    await server.listen();
    const address = server.httpServer?.address();
    assert(address && typeof address !== 'string');
    browser = await chromium.launch({ headless: true });
    observations.browserVersion = browser.version();
    observations.nodeVersion = process.version;
    context = await browser.newContext({ viewport: { width: 1200, height: 1000 } });
    await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
    page = await context.newPage();
    page.setDefaultTimeout(10_000);
    page.on('pageerror', error => pageErrors.push(error.message));
    page.on('console', message => consoleMessages.push(`${message.type()}: ${message.text()}`));
    await page.goto(`http://127.0.0.1:${address.port}`);
    await page.waitForFunction(() => Boolean(window.editorProbe));

    scenario = 'CM-1 native compartment replacement';
    await reset(page);
    await insertAtEnd(page, ' draft');
    await page.evaluate(() => { window.editorProbe.setSemantic(17); window.editorProbe.select(2, 7); });
    const before = await read(page);
    const editorDOM = await page.locator('.cm-editor').elementHandle();
    const contentDOM = await page.locator('.cm-content').elementHandle();
    assert(editorDOM && contentDOM);
    await page.evaluate(() => window.editorProbe.replaceContribution('B'));
    const after = await read(page);
    compare('editor DOM retained', await page.locator('.cm-editor').evaluate((element, old) => element === old, editorDOM), true);
    compare('editable content DOM retained', await page.locator('.cm-content').evaluate((element, old) => element === old, contentDOM), true);
    compare('draft retained', after.text, before.text);
    compare('native document identity retained', after.documentId, before.documentId);
    compare('selection retained', after.selection, before.selection);
    compare('focus retained', after.focused, true);
    compare('same field identity retains its value', after.semanticValue, 17);
    compare('native Undo depth retained', after.undoDepth, before.undoDepth);
    compare('there is actual native history', after.undoDepth > 0, true);
    const transitionTrace = after.trace.slice(before.trace.length);
    compare('predecessor native view plugin destroyed', transitionTrace.includes('A:destroy'), true);
    compare('new native view plugin constructed', transitionTrace.includes('B:setup'), true);
    const currentStart = after.trace.length;
    await page.keyboard.press('ArrowRight');
    await page.keyboard.insertText('!');
    const currentTrace = (await read(page)).trace.slice(currentStart);
    compare('old key listener no longer receives real key input', currentTrace.includes('A:key'), false);
    compare('current key listener receives real key input', currentTrace.includes('B:key'), true);
    compare('only current view plugin receives document input', currentTrace.filter(item => item.endsWith(':document')), ['B:document']);
    compare('Undo after replacement succeeds', await page.evaluate(() => window.editorProbe.undo()), true);
    compare('Undo returns to retained draft', (await read(page)).text, before.text);
    compare('second Undo retains pre-replacement history', await page.evaluate(() => window.editorProbe.undo()), true);
    compare('second Undo returns to original document', (await read(page)).text, 'seed');
    observations.CM1 = { before, after, currentTrace };
    completedScenarios.push('CM-1');

    scenario = 'CM-2 native same-document asynchronous source replacement';
    await reset(page);
    await page.evaluate(() => { window.editorProbe.showDiagnostics(); window.editorProbe.startNative('native-A'); });
    compare('A actually started before reconfiguration', (await read(page)).nativeStarted, ['native-A']);
    const nativeAInput = await read(page);
    await page.evaluate(() => { window.editorProbe.replaceContribution('B'); window.editorProbe.startNative('native-B'); });
    compare('B actually started after reconfiguration', (await read(page)).nativeStarted, ['native-A', 'native-B']);
    compare('native sources use same document object', (await read(page)).documentId, nativeAInput.documentId);
    await page.evaluate(() => window.editorProbe.completeNative('native-B'));
    await expectDiagnostics(page, 'native-B');
    const nativeBUseful = await read(page);
    compare('new source B is useful first', nativeBUseful.diagnostics, ['native-B']);
    await page.evaluate(() => window.editorProbe.completeNative('native-A'));
    await expectDiagnostics(page, 'native-A');
    const nativeALate = await read(page);
    compare('negative control: late A overwrites B on same document', nativeALate.diagnostics, ['native-A']);
    compare('current selected contribution is still B', nativeALate.selected, 'B');
    compare('only the two controlled native invocations occurred', nativeALate.nativeStarted, ['native-A', 'native-B']);
    await page.screenshot({ path: path.join(evidence, 'CM-2-native-late-source.png'), fullPage: true });
    observations.CM2 = { nativeAInput, nativeBUseful, nativeALate };
    await page.evaluate(() => window.editorProbe.clearNative());
    completedScenarios.push('CM-2');

    scenario = 'CM-3 native changed-document protection';
    await reset(page);
    await page.evaluate(() => { window.editorProbe.showDiagnostics(); window.editorProbe.startNative('old-document'); });
    const oldInput = await read(page);
    await insertAtEnd(page, ' changed');
    compare('a new native document object exists', (await read(page)).documentId !== oldInput.documentId, true);
    await page.evaluate(() => window.editorProbe.completeNative('old-document'));
    const nativeProtected = await read(page);
    compare('native guard rejects changed-document completion', nativeProtected.diagnostics, []);
    compare('native panel renders its empty-state placeholder', await page.locator('.cm-diagnosticText').allTextContents(), ['No diagnostics']);
    compare('no extra native linter invocation masks the result', nativeProtected.nativeStarted, ['old-document']);
    observations.CM3 = { oldInput, nativeProtected };
    await page.evaluate(() => window.editorProbe.clearNative());
    completedScenarios.push('CM-3');

    scenario = 'CM-4 generation and revision guard at application';
    await reset(page);
    await page.evaluate(() => {
      window.editorProbe.showDiagnostics(); window.editorProbe.select(1, 3);
      window.editorProbe.startManaged('guarded-A'); window.editorProbe.replaceContribution('B');
      window.editorProbe.startManaged('guarded-B');
    });
    const guardedBefore = await read(page);
    const current = await page.evaluate(() => window.editorProbe.completeManaged('guarded-B'));
    await expectDiagnostics(page, 'guarded-B');
    compare('current generation completion accepted', current.reason, 'current');
    const late = await page.evaluate(() => window.editorProbe.completeManaged('guarded-A'));
    compare('same-document predecessor rejected by generation', late.reason, 'generation-changed');
    compare('generation counterexample has same document object', late.sameDocumentObject, true);
    compare('generation counterexample has same revision', late.currentRevision, late.requestedRevision);
    const guardedAfter = await read(page);
    compare('useful current result retained', guardedAfter.diagnostics, ['guarded-B']);
    compare('native current diagnostic remains rendered', await page.locator('.cm-diagnosticText').allTextContents(), ['guarded-B']);
    compare('asynchronous result application preserves focus', guardedAfter.focused, true);
    compare('asynchronous result application preserves selection', guardedAfter.selection, guardedBefore.selection);
    observations.CM4 = { current, late, guardedBefore, guardedAfter };
    await page.screenshot({ path: path.join(evidence, 'CM-4-current-result-retained.png'), fullPage: true });
    completedScenarios.push('CM-4');

    scenario = 'CM-5 identical text after Undo is a new revision';
    await reset(page);
    await page.evaluate(() => { window.editorProbe.showDiagnostics(); window.editorProbe.startManaged('before-edit'); });
    const original = await read(page);
    await insertAtEnd(page, 'X');
    compare('native Undo succeeds', await page.evaluate(() => window.editorProbe.undo()), true);
    const returned = await read(page);
    compare('Undo returns identical text', returned.text, original.text);
    compare('document revision advanced despite equal text', returned.revision > original.revision, true);
    compare('native document identity also changed', returned.documentId !== original.documentId, true);
    const staleRevision = await page.evaluate(() => window.editorProbe.completeManaged('before-edit'));
    compare('text-only guard would have accepted this completion', staleRevision.sameText, true);
    compare('revision gate rejects it', staleRevision.reason, 'document-revision-changed');
    compare('no stale diagnostics applied', (await read(page)).diagnostics, []);
    observations.CM5 = { original, returned, staleRevision };
    completedScenarios.push('CM-5');

    scenario = 'CM-6 history-only clear differs from document reset';
    await reset(page);
    await insertAtEnd(page, ' dirty draft');
    await page.evaluate(() => { window.editorProbe.setSemantic(19); window.editorProbe.select(1, 6); });
    const beforeClear = await read(page);
    const historyContentDOM = await page.locator('.cm-content').elementHandle();
    assert(historyContentDOM);
    await page.evaluate(() => window.editorProbe.clearHistory());
    const afterClear = await read(page);
    compare('history existed before clear', beforeClear.undoDepth > 0, true);
    compare('native Undo history now empty', afterClear.undoDepth, 0);
    compare('native Redo history now empty', afterClear.redoDepth, 0);
    compare('clearing history preserves document identity', afterClear.documentId, beforeClear.documentId);
    compare('clearing history preserves editable DOM', await page.locator('.cm-content').evaluate((element, old) => element === old, historyContentDOM), true);
    compare('clearing history preserves dirty draft', afterClear.text, beforeClear.text);
    compare('clearing history preserves selection', afterClear.selection, beforeClear.selection);
    compare('clearing history preserves plugin field', afterClear.semanticValue, 19);
    compare('clearing history preserves focus', afterClear.focused, true);
    compare('Undo now reports no action', await page.evaluate(() => window.editorProbe.undo()), false);
    await reset(page, 'explicit baseline');
    const afterReset = await read(page);
    compare('explicit new-state reset replaces document', afterReset.text, 'explicit baseline');
    compare('explicit new-state reset reinitializes custom field', afterReset.semanticValue, 0);
    compare('explicit new-state reset starts empty history', afterReset.undoDepth, 0);
    observations.CM6 = { beforeClear, afterClear, afterReset };
    completedScenarios.push('CM-6');

    scenario = 'CM-7 native JSON history restores text but omits custom inverse effects';
    await reset(page);
    await page.evaluate(() => window.editorProbe.editWithSemantic('changed', 7));
    const edited = await read(page);
    compare('custom effect changed field', edited.semanticValue, 7);
    compare('direct native Undo succeeds', await page.evaluate(() => window.editorProbe.undo()), true);
    const directUndo = await read(page);
    compare('direct Undo restores text', directUndo.text, 'seed');
    compare('direct Undo restores custom field through invertedEffects', directUndo.semanticValue, 0);
    compare('direct native Redo succeeds', await page.evaluate(() => window.editorProbe.redo()), true);
    compare('direct Redo restores custom field', (await read(page)).semanticValue, 7);
    const serialized = await page.evaluate(() => window.editorProbe.roundTripHistory());
    const restored = await read(page);
    compare('field codec restores edited value before Undo', restored.semanticValue, 7);
    compare('text restored before Undo', restored.text, 'changed');
    compare('serialized native history retained Undo', restored.undoDepth > 0, true);
    compare('restored native Undo succeeds', await page.evaluate(() => window.editorProbe.undo()), true);
    const restoredUndo = await read(page);
    compare('restored Undo reverses text', restoredUndo.text, 'seed');
    compare('negative control: inverse effect absent after JSON restoration', restoredUndo.semanticValue, 7);
    observations.CM7 = { edited, directUndo, restored, restoredUndo, serialized };
    await page.screenshot({ path: path.join(evidence, 'CM-7-history-codec-boundary.png'), fullPage: true });
    completedScenarios.push('CM-7');
    compare('no unhandled page errors', pageErrors, []);
    observations.successful = true;
  } catch (error) {
    hasPrimaryFailure = true;
    observations.failure = error instanceof Error ? { message: error.message, stack: error.stack } : String(error);
    throw error;
  } finally {
    if (page && !page.isClosed()) {
      observations.finalSnapshot = await read(page).catch(error => ({ failedToRead: String(error) }));
      const finalPage = page;
      await cleanup('final screenshot', () => finalPage.screenshot({ path: path.join(evidence, 'final.png'), fullPage: true }));
    }
    if (context) {
      const finalContext = context;
      await cleanup('trace stop', () => finalContext.tracing.stop({ path: path.join(evidence, 'browser-trace.zip') }));
    }
    if (browser) { const finalBrowser = browser; await cleanup('browser close', () => finalBrowser.close()); }
    if (server) { const finalServer = server; await cleanup('server close', () => finalServer.close()); }
    observations.scenariosSuccessful = observations.successful;
    observations.successful = observations.successful === true && cleanupErrors.length === 0;
    const result = { suite: 'native-editor-contribution-update', scenario, completedScenarios, comparisonCount: comparisons.length,
      observations, comparisons, pageErrors, consoleMessages, cleanupErrors };
    await cleanup('write result', () => writeFile(path.join(evidence, 'result.json'), `${JSON.stringify(result, null, 2)}\n`));
    if (cleanupErrors.length) observations.successful = false;
    process.stdout.write(`NATIVE_EDITOR_RESULT ${JSON.stringify(result)}\n`);
    if (!hasPrimaryFailure && cleanupErrors.length) throw new Error(`Harness cleanup failed: ${cleanupErrors.join('; ')}`);
  }
});
