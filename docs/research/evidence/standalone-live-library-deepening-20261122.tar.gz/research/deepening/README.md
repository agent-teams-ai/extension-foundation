# Deepening evidence map

Four research lanes are retained: [state](state/REPORT.md),
[execution](execution/REPORT.md), [experience](experience/REPORT.md) and
[control policy](control/REPORT.md). Reports/plans/reviews are timestamped
checkpoints; use [CURRENT.md](../../CURRENT.md) and terminal native receipts for
the latest observed outcome.

`inputs/` keeps immutable published input archives and manifests. `probes/`
contains their hash-verified extracted package files, without dependencies.
`hosted/` preserves original native artifacts, extracted outputs and logs,
including failed attempts. `workflow-sources/` contains inert workflow copies,
not an installed CI configuration. The backend owns one package and lock for
database, Worker and joint tests; the editor owns its independent package/lock.

The [coverage audit](COVERAGE-AUDIT.md) separates 17 distinct backend scenarios,
one editor test with seven scenarios, repeat runs and prior browser49 evidence.
Its [machine-readable counterpart](COVERAGE-AUDIT.json) binds inputs and observed
results. [PROVENANCE.json](PROVENANCE.json) identifies reading copies and
explicitly omitted unlicensed upstream raw dumps. All included upstream package
source/trace material retains its exact license notice.
