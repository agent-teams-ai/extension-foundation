# Exact workflow sources

These files are inert evidence, not installed workflows. Each native input
receipt contains the SHA-256 of the workflow bytes used for that run.

| Native profile | Workflow copy | Source commit |
| --- | --- | --- |
| Backend v1, failed 16/17 | [Backend v1](live-update-backend-reliability.yml) | `719a6095445d67b1da7fa285bbb5ef8ecc589322` |
| Backend v2, passed 17/17 | [Backend v2](live-update-backend-reliability-v2.yml) | `9b33571e1586cc6801629a98b94fa1bc391c98cb` |
| Editor v1, failed DOM oracle | [Editor v1](live-update-editor-reliability-v1.yml) | `f4ff3a49e695caef4e75d119ff318259b5937dac` |
| Editor v2, passed 7 scenarios / 70 comparisons | [Editor v2](live-update-editor-reliability.yml) | `719a6095445d67b1da7fa285bbb5ef8ecc589322` |

The final document/ledger reading origin is a later published checkpoint. It
must not replace these exact execution origins or turn the failed v1 attempts
into passing runs.
