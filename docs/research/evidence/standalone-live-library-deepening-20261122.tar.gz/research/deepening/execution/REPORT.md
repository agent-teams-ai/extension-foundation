# Execution, resource ownership and dependency cohorts — deeper evidence

Date: 2026-11-22. Source ledger: `sources.json`; reviewed experimental plan: `PLAN.md`. **All five distinct execution-lane cases passed:** three independent Worker/Resources cases locally and again hosted, plus two joint PostgreSQL cases in run `45042722876`. The containing backend v1 suite remains **16/17, failed** because of the unrelated S13 SQLSTATE oracle. Corrected backend v2 run `45043862207` passed **17/17**, independently verified against all 15 returned frozen files; its one-line S13 correction adds no new distinct case. Prior Resources6, ALS5 and SDK14 are not new results, and the repeated three Worker cases are not added twice.

Native input: `d8e90b0e58cd496ebfceb3b489dafaf795d0b65727a5a9370845de576bc344f9`, verified unchanged before and after. Exact runtime: Node 24.22.3, Resources 0.2.2; single shared backend strictly checked by TypeScript 7.0.2. Raw evidence is in `evidence/local-worker-attempt1/`. Initial compiler findings were retained by the state lane and corrected before this run; they were not native test failures.

Hosted source: `719a6095445d67b1da7fa285bbb5ef8ecc589322`, backend input archive SHA-256 `06e8e448698bb2fa7af417c68822bbd4fb5fa5af71c62d2047ab426934814a59`. All 15 returned files match the frozen manifest. The read-only result review is `evidence/backend-v1-result-review.md`; root retains the original native artifact. PostgreSQL was the exact 18.7 profile. This is disposable fixture composition, not a released update coordinator.

## Decisions changed or sharpened by this pass

1. **Use public Resources for custody, not as an admission mechanism.** Its published 0.2.2 source registers acquisition before invoking setup, waits for pending acquisitions on close, keeps failed cleanup as debt and retries only failed entries in the next close flight. No generation borrowing, routing or DB fencing follows from these APIs. The separate lifecycle-kernel remains `private: true` at Get Modular commit `33c032f8`; copying its state machine would create a second semantic owner. External publication/qualification or a deliberately narrower external contract is still needed before adopting that candidate. [EX-S01–03]
2. **Choose executor by work lifetime.** Native Worker plus Resources is the minimal honest mechanism for this long-lived generation probe. Piscina supplies an actual bounded-task queue, admission pressure, worker pooling and shutdown; default task completion pauses further asynchronous work until another task. That contract can fit CPU work, but a plugin service/stream does not become a bounded task because it runs in a pool. No Piscina/Comlink production dependency is selected by this research. [EX-S04–05]
3. **An RPC release is weaker than a stop receipt.** Comlink's latest release 4.4.2 exposes a synchronous proxy release, does not reject outstanding RPC promises on release, and contains a release-response bookkeeping bug fixed upstream after the release. Current source and released package must not be treated as the same artifact. [EX-S06–10]
4. **Full cohort affinity and resource retention need separate evidence.** A pinned service reference does not retain its underlying resource; retaining a worker does not prove that every external dynamic service call stays in the same cohort. The new fixture will hold an actual A operation while B is published, with distinct entry/dependency files, and separately observe actual worker exit. A parent-owned effect dispatched before exit is fenced at the DB receiver. [EX-S04, EX-S11–15; planned experiment]

## Reuse candidates and exclusion rules

| Candidate | Ready-made responsibility | Critical boundary | Recommendation |
| --- | --- | --- | --- |
| `@get-modular/resources` 0.2.2 | Started-acquisition custody; ordered finalizers; hierarchical scopes; close-flight and debt reports | No live borrower counting; cleanup completion is whatever the registered cleanup actually observes | Reuse through public root API. Register the owned executor as one resource; cleanup awaits its native stop receipt. |
| Native Node Worker 24.22.3 | Isolated JS execution context/module cache; messages; native async terminate/exit | No tenant sandbox, global memory isolation or external-effect rollback | Good first isolated TS execution profile, with narrow host capabilities and explicit artifact URLs. |
| Piscina released 5.3.2 | Worker pool, task queue/backpressure, abortable tasks, `close`/`destroy` | Task result lifetime; abort rejects caller before physical exit; abortable tasks cannot share a worker | Use for bounded task workloads if measured need appears. Qualify close timeout and detached work before using for a generation owner. |
| Comlink released 4.4.2 | Typed remote object/endpoint ergonomics, structured clone/transfer | No operation admission, drain or supervisor; `releaseProxy` is not an awaitable stop | Possible transport adapter, with explicit in-flight ownership and stop settlement. Current release defects block assuming lifecycle completeness. |
| Private lifecycle-kernel candidate | Synchronous per-agent generation/call/custody bookkeeping | Private, instance-local tokens; no executor, callbacks, cleanup or durable authority | Resolve publication and consumer qualification with owner; do not deep-import or clone it. |

Piscina provenance check found a release/tag discrepancy: tag `v5.3.2` resolves to commit `6c7e5463`, whose source manifest says `5.3.1`; the separately downloaded npm tarball declares `5.3.2` and matches registry SHA-512 integrity. Both identities are retained. This is a reason to inspect the actual artifact, not evidence of malicious code. No package execution occurred.

The npm Piscina source/README were subsequently byte-verified against the inspected Git blobs. npm's current Comlink release also resolves to 4.4.2 and the same Git head; downloaded source and shipped ESM distribution both contain the described release-response code, with registry SHA-512 verified. Neither package was installed/executed.

## Actual failure mechanisms worth learning from

### Comlink: release, pending work and collection

At released commit `fd4b5266`, `releaseEndpoint` puts the release response resolver in a fresh map that the normal message listener does not consult. The public proxy release also clears the normal resolver map. Upstream commit `359584cc` (2025-01-13) fixes the map used for release and adds Node/browser regression tests for closing the returned MessagePort. It is later than the current latest release 4.4.2. [EX-S06–07]

Separately, issue #692 reports production calls hanging when a transient proxy is garbage collected during a suspended await; PR #693 proposes delaying endpoint release until outstanding requests drain and was still open at retrieval. Older issue #601 requests rejecting pending RPCs on explicit release. These are upstream reports plus source corroboration; this lane has not reproduced their GC schedules. [EX-S08–10]

**Our exclusion:** endpoint proxies remain strongly owned for the operation lifetime; releasing a proxy, cancelling a waiter, settling an RPC promise and stopping the executor are separate observations. Never rely on FinalizationRegistry to complete a correctness-critical transition. A failed endpoint must settle caller operations explicitly; pending promises cannot disappear from accounting just because a map was cleared.

### .NET: successful unload request does not prove unload

Collectible AssemblyLoadContext unload is cooperative: stacks, external strong roots, delegates, GC handles and even JIT-held temporaries can keep the context alive. Its unload event is a cleanup opportunity, not collection completion. The documented weak-reference/GC observation tests collection, while ordinary user resources still need their own release contract. [EX-S13]

The plugin tutorial also demonstrates a concrete contract-identity trap: copying `PluginBase.dll` into a plugin's private dependency directory can load a second interface identity, so the host no longer recognizes its implementation. Runtime support deliberately shares boundary assemblies while keeping private implementation dependencies separate. Its loader already resolves concurrent cache insertion races; recreating another cache would needlessly duplicate that mechanism. [EX-S14–15]

**Our inference:** a cohort manifest must distinguish immutable implementation dependencies from shared boundary/runtime contracts. Claiming full isolation while sharing mutable module singletons is invalid. A stop contract must say whether it observes request acceptance, execution exit, managed heap reclamation or OS-resource release; these are different adapter capabilities.

### Two shipped runtime fixes illustrate why ownership must be explicit

.NET 10.0.15 includes a NativeAOT EventPipe use-after-free fix: an effectively empty yield-while macro failed to wait for active writers. The upstream backport explicitly says intermittent failure, code review only. It is not a .NET plugin-update reproduction; it is a concrete instance of reclamation proceeding without the promised reader/writer barrier. [EX-S16]

The same release fixes NCrypt concurrent first-handle duplication: two threads could create independent holders for one native handle. The fix serializes the first ownership transition and adds a Windows concurrency test. The report links finalization exceptions capable of terminating the process. Subsequent ordinary parallel use was not the failing window. [EX-S17]

**Our exclusion:** a retention count or completed cancellation request is not proof that every physical user has finished. Ownership transfer must have one linearization point, especially at first acquisition and handoff. Do not clear debt or artifact references before the release operation's authoritative success condition.

## Cohort consistency: what established systems actually guarantee

OSGi Declarative Services gives each reference a static or dynamic policy. Dynamic bindings may change during component lifetime; static replacement deactivates/reactivates the consumer. These are dependency policies, not a promise of atomic replacement of several independently updated references. Bind failures can be logged while activation continues; deactivate/unbind failures are logged while teardown continues. Thus framework lifecycle state is not a sufficient readiness or cleanup-debt oracle for our stronger contract. [EX-S11]

OTP explicitly warns about dependencies between modules, processes and nodes, and about newly spawned processes executing old code between suspension and loading. Existing release machinery should be reused, but its local code operations cannot by themselves establish a whole-application cohort across independent actors. This sharpens, rather than repeats, the earlier two-code-version/purge notes. [EX-S12]

**Selected rule for our library:** an admitted operation captures one immutable cohort binding once. Cohort closure must cover the dependencies whose joint compatibility is required; external dynamic services need an explicit compatible protocol or their own retained binding. A mid-operation lookup of 'latest' is a visible opt-in policy, not the default. Get Modular remains the graph/digest owner; the fixture uses literal A/B manifests and does not implement a resolver.

## Native proof and remaining uncertainty

| Case | Actually observed | Practical limit |
| --- | --- | --- |
| E01 | Real A outputs 9/11 retained A implementation/dependency/cohort while B publication advanced revision/epoch and new B work returned 120/125. | Literal frozen modules and async generator through Worker messages; no arbitrary graph loader or HTTP/Readable stream qualification. |
| E02 / S09 | Native A exit preceded the delayed receiver. The original A epoch remained in the envelope; guarded receiver rejected it against B, while the separate unsafe control committed A's value 37. | Parent-owned request is deliberately held before SQL start; no lost DB wire request or external network rollback proof. |
| E03 | Abandoning a Resources close waiter returned `complete:false, settled:false`; the Worker still answered a ping. After releasing the cleanup barrier, events were terminate requested → native exit → terminate Promise resolved. The pending private receive rejected on native exit. | Explicit Resources waiter abandonment, not a nonexistent Worker AbortSignal API. Forceful Worker termination does not prove guest finalizers ran. |
| E04 | First cleanup failed before termination; `settled:true` reported one failed debt while Worker remained responsive. Public `close()` retry invoked cleanup a second time and produced exactly one native exit with no remaining debt. | Injected pre-stop failure, not arbitrary cleanup idempotency. |
| E05 | At two live Workers, C was refused before another acquisition. A's held generator finished, but the slot remained occupied until A's native exit. C then started; all three acquired Workers exited. | One controller and known Workers; no concurrent reservation or RSS/GC/resource exhaustion bound. |

Native termination receipts carried exit code `1`, as Node documents for a Worker terminated by its parent. The coordinator must correlate the requested stop with that event; code `1` alone is not a reliable UI classification of an unexpected plugin crash. These tests prove the selected stop mechanism, not graceful guest-resource shutdown.

The hosted cases compose real A/B Workers, actual different TS entry and dependency code, public Resources custody and the state lane's PostgreSQL authority. Both assert complete close reports and native exit receipts in finally. Their strict-cutover policy lets A finish computation but rejects new A state commits after B publication.

Still source-only: OSGi, OTP, .NET, Piscina and Comlink; not all execution profiles or general arbitrary-plugin safety are qualified. Native Effect remains a native typed scoped profile, not a Promise wrapper. Production executor publication, portable ABI/cohort manifests, external resource brokers, process-tree termination, memory bounds and distributed/failover behavior remain separate work.

Source IDs above map to exact URLs, tags, commits, evidence class and uncertainties in `sources.json`.

## Contract implications for the standalone library

These are design conclusions from the evidence, not shipped APIs. The library still owns the complete replacement operation; the ordinary consumer should not rebuild admission, cancellation custody, retirement retries or reconciliation.

### Operation affinity is not resource ownership

An operation needs a stable execution binding and an owner that outlives every resource it borrows. Capturing the A function/dependency alone keeps JavaScript objects reachable; it does not stop a separate owner closing A's file, endpoint or worker. Conversely, retaining A's worker does not freeze its calls to a shared mutable service locator. A published version number cannot supply either guarantee.

The useful decomposition is:

| Fact | Who establishes it | When it can end |
| --- | --- | --- |
| Operation admitted to a cohort | Library's admission policy using selected authority | On explicit completion/cancellation policy; a rejected waiter alone is insufficient |
| Executor retained | Existing resource/lease mechanism under the library's operation owner | After all required users finish, or an explicit forced-stop policy revokes them |
| External write authority | The actual receiver, with epoch/idempotency contract | At the receiver's ordered authority transition |
| Executor physically stopped | Runtime adapter observing native event/result | After native evidence, even if the public update already committed |
| Cleanup complete | Registered finalizers and their actual resource contracts | After supported completion or retry semantics; unresolved debt remains observable |
| Artifact collectible | Canonical references plus runtime custody owners | After live, rollback, pending-attempt and recovery references permit deletion |

Our joint probe intentionally ends old write authority at B publication while allowing A's already-admitted calculation to finish. A workflow that must finish its writes would select a different compatible-write or pre-publication drain policy. This must be visible in the plan and receipt, not hidden in an executor's `dispose` method.

### Candidate preparation, late acquisition and exclusivity

Readiness is checked only after custody of a constructed executor is registered. Awaiting a ready handshake inside a factory that has not yet returned its worker would leave cleanup responsibility ambiguous if the handshake fails. The fixture avoids that window using Resources' immediate acquisition registration and a later readiness await.

Resources already owns setups that ignore cancellation and resolve late; do not build a parallel pending-acquisition list unless another runtime contract demonstrates a gap. However, its cooperative setup signal cannot stop arbitrary foreign code. A bounded observer may stop waiting while an acquisition owner remains retained and visible.

Exclusive resources require a declared plan, not optimism that every candidate can warm next to the old owner:

| Physical resource situation | Useful strategy | Required evidence |
| --- | --- | --- |
| Both instances may own independent resources | Prepare B, validate, publish, drain A | Explicit independent ownership, capacity budget |
| A stable host broker can retain the resource | Keep resource in broker; replace consumers through compatible narrow capability | Broker protocol compatibility and retained operation binding; not a global mutable service bag |
| Runtime has real handoff support | Use that mechanism | Transfer receipt, supported platform/options and whether established work transfers |
| Exclusive resource cannot coexist or transfer | Quiesce/drain, release old owner, acquire replacement | Planned availability gap and failure recovery; no zero-downtime claim |

Envoy's versioned hot-restart documentation is a useful known example of the third row: listener socket copies coexist with established connections remaining on the old process, and drain/parent shutdown have separate deadlines. This is a reconfirmed known mechanism, not a new native case. The new library should expose resource conflict/readiness decisions early enough for the UI to explain a restart boundary before publication.

### Bounded generations must include failed and pending owners

Count retained physical owners, including failed-cleanup generations, pending acquisitions and candidate warmup—not just the active routing head. A maximum of two active labels can still leak many old workers if each failed finalizer is removed from the inventory. The local Worker case exercises this narrower statement with native exit receipts; it does not qualify concurrent reservation or process-wide memory bounds.

A production admission policy needs to reserve capacity before acquiring another executor. If the limit is reached, it must choose a documented action: wait for a retained generation, reject the update, or apply an authorized forced-stop policy. Defaulting to unbounded accumulation during rapid edits hides failure until memory exhaustion. Deadline expiry must preserve the unresolved owner/debt, even if foreground waiting ends.

Cleanup retries are capability-specific. Resources 0.2.2 can retry failed entries, so its finalizers must tolerate repeated execution after partial progress. The prior native Effect source study identified a different disposal receipt behavior; a universal retry loop cannot turn that into Resources' guarantee. Persist the first observed cleanup failure and invoke a retry only through a backend contract that actually permits it.

### Runtime profiles need honest capabilities

| Capability question | Ordinary trusted TS / Node Worker | Optional profiles must declare |
| --- | --- | --- |
| What remains native? | Promise/async work and real Node scope/executor lifetimes | Effect's typed error/environment, fiber interruption and Scope; Wasm runtime-specific call/instance lifetime |
| Can running execution be stopped? | In-process TS: cooperative; Worker: native terminate/exit | Exact interruption/epoch/fuel/cancellation mechanism, host-call behavior, physical completion observation |
| What is versioned together? | Explicit implementation/dependency cohort; shared host contracts identified | ABI/WIT/interface identities, shared imports, native-library/process restrictions |
| What crosses the boundary? | Validated structured messages in this fixture | Serialization/transfer/handle ownership, error semantics and per-call authority envelope |
| Is state restored? | Only an application-owned codec/snapshot contract | Supported schema/version conversions; never infer heap restoration from selected artifact |
| What may cleanup retry? | Only the resource contract's failed-entry policy | One-shot versus retry-safe finalizers, unknown outcomes and preserved failure receipt |

A small pure decision policy and evidence vocabulary can be shared without forcing all runtimes into the same execution representation. Native Effect should expose and compose native Effects with the caller's environment/Scope; a foreign Promise boundary needs an explicit contract, not hidden `runPromise` calls. Full cross-driver conformance is a release gate when both ordinary and native consumers actually exist.

### Observable updates should explain coexistence

The update view needs both the selected cohort and retained old owners. A user should be able to see that B serves newly admitted work while operation A is still completing on A, and distinguish that from a replacement waiting for readiness or an old cleanup debt. Attach actual generation/cohort identity to result/progress receipts so the view does not infer the executed version from the current global head.

Expose concrete blockers—one old operation, one unresolved acquisition, one failed finalizer—along with policy and supported action. Do not label a task rejection, proxy release or elapsed timeout as “old version released.” The library should supply these correlated facts; the consumer controls presentation and authorization.

One reporting trap was directly visible in E04: `CloseReport.debts[].cause` held an Error, but ordinary JSON serialization produced `{}`. The fixture retained a separate readable failure string. A durable or cross-worker library receipt needs normalized error code, owner/path, phase and retry semantics; keep the original in-process cause without assuming its properties survive transport. This is a serialization boundary lesson, not a Resources defect or an additional native test.
