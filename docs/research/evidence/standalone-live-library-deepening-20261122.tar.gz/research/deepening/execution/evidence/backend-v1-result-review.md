# Independent backend v1 result and v2 correction review

Reviewer: execution lane, 2026-11-22. Read-only review; no new native execution.

## Native v1 evidence

Reviewed root's original artifact and extracted receipts for run `45042722876`, attempt 1, source `719a6095445d67b1da7fa285bbb5ef8ecc589322`. All 15 returned source/configuration files match the frozen v1 per-file hashes. Hosted compiler identities are TypeScript 7.0.2 / Node 24.22.3; Resources 0.2.2 and pg 8.23.1 are exact.

Raw counts: 12 state scenarios (11 pass, S13 fail), 3 independent Worker scenarios (3 pass), 2 joint scenarios (2 pass). That is **16/17**, not a passing backend suite. E02 and S09 are one joint case, not two. The three local Worker passes are an earlier run of these same three cases, not additional distinct coverage.

E01 records A outputs 9/11 with A entry/dependency and B outputs 120/125 with B entry/dependency. The old A identity and cohort remain unchanged across B publication; admitted revision/epoch advances from 1 to 2 for B. Source manifest hashes agree with the returned literal modules. This is an actual held async generator through Worker messages, not an HTTP/Readable transport or arbitrary graph-loader qualification.

E02 records parent host requests dispatched before B publication, native exit of A before receiver entry, and `terminate-requested → native-exit → terminate-promise-resolved`. The captured request retains A generation/epoch 1. The guarded receiver returns stale against B/epoch 2; the distinct unsafe negative-control effect commits A's value 37. Stopping guest execution does not revoke parent-owned work. The deliberate barrier delays SQL start; no lost wire COMMIT acknowledgement is claimed.

Both joint source tests assert complete final Resources reports and observed native exits in finally. E01 does not persist a separate exit list in its JSON; its passed assertions plus matching executed source support that check. E02 persists the native A receipt explicitly.

## Failure and proposed correction

S13 failed at its first `assert.rejects`: actual SQLSTATE `23001`, expected `23503`. The table uses explicit `ON DELETE RESTRICT`. PostgreSQL `REL_18_7` source `src/backend/utils/adt/ri_triggers.c`, Git blob `e2768bca84c68eee1431e8c2da9149111a889dd5`, chooses `ERRCODE_RESTRICT_VIOLATION` when `is_restrict`; missing-parent insertion has the distinct foreign-key violation path. The observed error is consistent with successful rejection of the forbidden deletion, not evidence that a dangling reference was committed. The second interleaving and final no-dangling check were not reached in v1 and must remain unqualified until v2 runs.

Source: https://github.com/postgres/postgres/blob/REL_18_7/src/backend/utils/adt/ri_triggers.c

Independently compared all 15 frozen input files to `state/probe-v2`: **only `state.test.ts` changes**, in exactly one line: first deletion expectation `23503 → 23001`. Reverse missing-parent insertion still expects `23503`. No receiver SQL, concurrency barrier, source implementation, package or lock changed.

**Review decision: approve this one-line oracle correction as a new frozen v2 input and hosted run.** Preserve v1 failure. This review does not turn v1 into a pass or authorize extra local native execution.
