# Independent native backend v2 result review

Reviewer: execution lane; read-only audit of the returned native artifact and
frozen input. No rerun, source change or new runtime result was produced here.

## Identity and acceptance

- Run **45043862207**, job **137274019386**, attempt 1, source
  `9b33571e1586cc6801629a98b94fa1bc391c98cb`.
- Original artifact: **47,973 bytes**, SHA-256
  `0167363a6a3ddc72527c3ba7b32bf43072c01acf8d5fc9b804150bf6a2a7e052`.
- Input archive: **21,518 bytes**, SHA-256
  `6aad6e191b132c8d6f95c7110d10e8db25ed3011ca8835d2f9586097fa1b732e`.
- All **15 returned source/configuration files** match the frozen v2
  `INPUT.sha256`. All 17 source scenario declarations exactly match the 17 unique
  emitted scenario names: **12 state + 3 Worker + 2 joint**, all passed. The
  native test log independently reports **17 tests, 17 pass, 0 fail, 0 skipped**.
- Node 24.22.3, strict TypeScript 7.0.2, Resources 0.2.2, pg 8.23.1; native
  PostgreSQL reports version number 180007. The returned direct package
  identities match the frozen package cohort.

**Accepted for these 17 fixture cases.** E02/S09 counts once; the local Worker
three and earlier v1 executions are repeats, not extra distinct coverage.

## S13: both lock orders actually completed

The v1-to-v2 source comparison changes exactly the first deletion rejection
oracle from SQLSTATE `23503` to `23001`. The reverse insertion oracle remains
`23503`; no fixture mechanism, dependency or other assertion changed.

For hold-first order, an uncommitted hold made the artifact deletion block.
The returned `deleteBlockers` is `[139]`; `waitForBlock` obtains nonempty
`pg_blocking_pids` before the holder commits. Successful execution of the frozen
`assert.rejects(..., {code: '23001'})` then confirms the restricted deletion was
rejected after that commit.

For delete-first order, an uncommitted deletion made the late hold insertion
block. The returned `holdBlockers` is `[137]`; the same native barrier observes
the waiter before the deleter commits. The unchanged `23503` assertion then
passes. The final SQL left join checks for holds with missing artifact rows and
asserts zero; the emitted result records `danglingReferences: 0`.

The JSON persists both blocker lists and emits the constant reporting value 0
after the awaited native query result has been asserted to equal `'0'`. It does
**not** persist the raw count row or the two SQL error objects; those checks are
supported by matching frozen source plus the successfully completed native
test. This qualifies the
two metadata schedules. Physical blob deletion, runtime leases, concurrent
garbage collection and every possible interleaving remain outside the result.

The original v1 run remains **16/17, failed**. Its reverse schedule and final
no-dangling assertion were not reached; this v2 result does not relabel v1.

## E01/E02 and physical exit boundaries

E01 emits A values `9`/`11` with implementation/dependency A and B values
`120`/`125` with implementation/dependency B. A retains its original admission
and cohort while B becomes selected at revision/effect epoch 2. The receipt
includes exact manifests for the literal entry, dependency, worker host and
protocol. This is a suspended native async-generator operation with controlled
messages, not qualification of a generic dependency resolver or transport stream.

E01's successful source path includes `finally` assertions that both Resources
close reports are complete and each acquired Worker has a native exit receipt.
The E01 JSON does not separately serialize those final exit objects; it must
not be described as containing a full exit transcript.

E02 explicitly persists A's native exit (`threadId: 3`, `code: 1`) and ordering
`terminate-requested → native-exit → terminate-promise-resolved`. Code 1 follows
the requested native termination and is not, by itself, evidence of a crash.
The parent-owned request is dispatched before B publication and survives A's
exit. Only afterwards does the test release the receiver to start SQL. Its
original A generation/epoch remains intact: the guarded write is stale and
absent, while the distinct unsafe negative-control ID commits value 37. Both
scope cleanup reports and native exits are also asserted in `finally`.

These results support receiver-owned fencing after physical guest stop. They
do not simulate a database request already on the wire, a lost COMMIT reply,
external network rollback or reconstruction of a terminated Worker heap.

## Decision

The corrected input earns a separate successful receipt. Retain the failed v1
artifact, one-line patch, both frozen inputs and all exact runtime identities.
Use the result to support narrow mechanisms in the architecture; it does not
establish a released library, public API, arbitrary plugin compatibility,
concurrent capacity admission or fleet-wide atomic update.
