# Execution, resources and cohort probe plan

Status: plan reviewed by root on 2026-11-22; bounded implementation and strict TypeScript checking authorized. Root source review requested a bounded cleanup checkpoint and asserted final close reports/physical exits; both were added. State peer review and shared TypeScript 7.0.2 checking completed. The three independent native Worker cases passed locally on frozen input `d8e90b0e58cd496ebfceb3b489dafaf795d0b65727a5a9370845de576bc344f9`, then both joint cases and the repeated three Worker cases passed in hosted run `45042722876`. Overall backend v1 remains failed 16/17 because of S13's separately reviewed SQLSTATE expectation. Corrected v2 run `45043862207` passed 17/17; independent receipt review matched all 15 files and both S13 wait orders without running another local experiment. This adds evidence to Resources6/ALS5/SDK14; those results remain historical evidence, not new test counts.

## Question and selected policy

Can a prepared replacement execute an actual new TS implementation and dependency cohort, while an admitted operation retains its old cohort, and can we separately prove old execution has stopped and old writes are rejected?

Selected test policy: a request admitted to A may finish computation or a read/stream using A after B is published. Publication of B revokes A's authority to commit shared mutable state. This is an explicit policy choice; another host may drain all writes before publication. The adapter must not silently choose for the host.

## Existing mechanisms versus coordination

| Owner | Reused mechanism | Guarantee exercised | Does not provide |
| --- | --- | --- | --- |
| Node | `Worker`, literal entry URL, ESM imports, `MessagePort`, `terminate()`/`exit` | Separate real execution contexts and module graphs; termination completion observable in parent | Publication, tenant authorization, database fencing, rollback of dispatched host effects |
| `@get-modular/resources` 0.2.2 | Public `createScope`, `resources.setup`, `control.close`, `CloseReport` | Own started acquisition, register cleanup, preserve late-acquisition custody, report cleanup debt | Borrower admission, graph/cohort selection, a process supervisor, physical-stop proof unless cleanup actually waits for it |
| State fixture | PostgreSQL transaction and narrow typed authority API | Commit/reconcile a selected cohort; receiver checks old effect authority | Executing/loading plugin code or restoring worker heap |
| Parent test | Explicit prepared A/B handles and barrier order | End-to-end composition of those mechanisms and independently asserted receipts | Production generation registry/kernel, dependency solver, generic RPC framework |

The published Resources README and archived Resources6 already show repeated `close()` retries only failed cleanup entries after a settled incomplete flight. We will verify the exact published implementation, then exercise debt with a real worker. A missing or different retry contract must remain visible debt, not be compensated with a custom retry loop masquerading as library behavior.

## Keep five identities separate

| Identity | Meaning and lifetime |
| --- | --- |
| `artifactDigest` | Hash of immutable entry and dependency bytes; two worker instances can run the same artifact |
| `cohortDigest` | Immutable set of artifact/dependency identities selected together; fixture computes a deterministic manifest hash, not a dependency resolver |
| `generationId` | One live worker instance; restart from the same artifact creates a new generation |
| `effectEpoch` | Authority under which an operation may commit a receiver-side mutation; distinct field even if this fixture initially advances it with publication |
| `revision` | PostgreSQL publication record concurrency token, encoded as an exact decimal string |

An operation captures its admitted generation, cohort and authority token once. Its later write must use that captured token, never refresh to the current head merely to pass the guard. An attempt ID identifies a publication retry; an effect ID identifies a mutation retry. Neither is a generation ID.

## Narrow fixture seams

State agent owns these experimental DB primitives (names may be finalized by that lane):

- `readHead()`.
- `admitAttempt({ attemptId, expectedRevision, expectedGeneration, targetGeneration, cohortDigest, baselineId })`: persist exact immutable inputs, reject same-ID/different-input reuse.
- `publishAttempt(attemptId)`: atomic head CAS and committed/conflict durable outcome; same-attempt replay returns the original outcome.
- `observeAttempt(attemptId)`: recorded pending/committed/conflict or unknown.
- `guardedWrite({ effectId, generation, effectEpoch, stateSchema, value })`: committed, stale, or same-effect replay. A committed effect replay after cutover returns the original receipt when exact inputs match. The operation's original authority is retained for the delayed parent-owned request.

Execution lane proposes one small fixture handle, kept outside any public production SPI:

- `prepareWorker({ generationId, artifact, scope })`: acquire a literal A/B worker in `resources.setup`; wait for its validated ready message, return the handle.
- `beginComputation({ operationId, admission })`: send a typed message to that exact worker; receive a first result and a parent-controlled continuation barrier.
- `continueComputation(operationId)`: receive final result from the same worker and dependency.
- `requestHostWrite({ operationId, effectId, admission, value })`: emit a message; the parent captures the original envelope and dispatches the DB operation after a separate test barrier.
- `close()` is the Resources scope operation; cleanup awaits `worker.terminate()` and observes `exit`. No homegrown stop receipt is issued before that event.

Transport is fixture-only structured data with validation at the `unknown` message boundary. No returned closure, cross-worker resource object, transferable state claim, or general RPC package is needed for this slice.

## Decisive scenarios

1. **Actual code and full cohort replacement.** A entry imports A dependency; B entry imports B dependency and uses different computation. Record source hashes. Pause admitted A between two dependency calls, publish B in PostgreSQL, start B work, resume A. Assert literal independent A/A and B/B outputs and immutable IDs, not just a changed configuration tag. No dynamic shared service lookup is used mid-operation.
2. **Irrevocable host request outlives guest.** A emits a host mutation envelope which the parent captures before termination. Publish B, close A and wait for native `exit`, then release the parent-owned request. Guarded receiver rejects A's exact stale token. An intentionally unguarded receiver negative control shows the already-dispatched host action can still commit after physical worker exit. Stopping the guest is not accepted as a write fence.
3. **Cancellation versus completed stop.** Observe native terminate Promise and exit order, and ensure no completion receipt appears merely from an abort request or abandoned close waiter. Do not rely on JavaScript `finally` executing inside a forcibly stopped worker.
4. **Cleanup debt has live consequences.** Inject one cleanup failure before actual `terminate`. A settled incomplete report must coexist with a still-live worker capable of answering a message. If published contract permits retry, a later `close` must actually terminate and clear only that debt; count distinct physical exits. This is additional proof beyond the prior listener-only debt test.
5. **Bound retention by physical ownership.** Exercise at most two simultaneously live worker generations under an explicit test policy. While A remains retained for a stream, B is active; admission of C is refused before acquiring another worker. After A's physical close, C can prepare. The oracle counts actual worker creation and exit receipts. No memory/RSS/GC leak bound or fleet policy is inferred.

Do not add another synthetic 250-listener loop, reimplement the previous late-file acquisition case, or claim database durability from an in-memory compare-and-swap.

## Build, running and review gates

- Maintained sources are ordinary strict `.ts`, compiler TypeScript >=7.0.2. Inspect exact resolved compiler and any tooling dependency before execution; no old embedded TS.
- Use root-approved Node >=24.18.0 and <25 (or supported >=26.10.0 <27) with exact version recorded. Pin Resources 0.2.2 and public tarball integrity; do not deep-import its source or private lifecycle-kernel.
- Align to the state lane's one backend package: strict TypeScript 7.0.2 `noEmit` first, then Node 24.22.3 native `.ts` stripping and built-in test runner. Files assemble into `state/probe/execution`; no second package/lock, transpiler or compiler dependency.
- Separate deterministic local execution from hosted PostgreSQL integration. A locally passing worker test is not the DB E2E.
- Typecheck, tests, exact dependency lock, source manifest hashes, runtime identity and raw receipts are retained. The root decides hosted workflow ownership and archive assembly.
- Original estimate: 5-7 `.ts` files, about 300-450 maintained lines. Source review version has 9 files and roughly 500 lines because transport boundary validation and local/DB suites are separate. There is no production runtime package, graph loader, RPC framework or supervisor. If these responsibilities grow, reduce the fixture rather than invent infrastructure.

## Source-only work in parallel

Inspect and record current/pinned .NET collectible contexts and real reclamation failures; OSGi multi-reference binding semantics; OTP code-load/upgrade restrictions not already covered; Piscina worker-task contract; public Resources versus private lifecycle-kernel availability. Findings must state source-inspected, historically reported, proposed or executed. Native Effect remains its own typed scoped profile; no Promise adapter or new Effect execution is planned by this lane.

Reuse evaluation is narrow: Piscina's bounded-task pool, native Worker lifetime, and Comlink endpoint RPC are different responsibilities. Piscina abortable tasks do not share workers; an aborted task's rejection still precedes physical thread exit. Default sync atomics pauses detached async work between tasks. Comlink 4.4.2's public proxy release is not an awaitable drain/termination receipt; released-source and upstream fixes/issues must be distinguished. Do not install these alternatives collectively or build a custom RPC/supervisor to compensate.

## Explicit exclusions

No sandbox guarantee for Node Workers, no arbitrary ESM graph resolver, no coherent cohort guarantee across independent externally hot-swapped services, no heap restoration on restart, no arbitrary plugin cleanup guarantee, no native Effect execution evidence, no Wasm backend execution, no production-ready standalone library claim.

The held operation uses a real async generator inside the Worker resumed by two explicit messages; it does not qualify Node Readable/HTTP/SSE transport stream behavior. The fixture artifact digest hashes the entry source; its cohort manifest also hashes the literal dependency, driver and protocol sources. These known files are evidence inputs, not a new manifest standard.
