# Standalone live-update library: boundaries and reuse

Status: checkpoint 2, 2026-11-22. This is a source-backed architecture lane, not a release or runtime-behavior qualification.

## Direction

A standalone portable library is consistent with current organization policy. The user’s latest direction supersedes the earlier decision’s lack of repository-creation authorization; it does not transfer application authority or permit duplicate lifecycle/composition engines. The previous 150–350-line estimate concerned a consumer integration and cannot be reused as the estimate for a public library. [O1, P1]

The library should implement reusable update coordination and observable outcomes. Consumers still supply authorization, active-head compare-and-swap, artifact/state stores and their migration policies. Third-party runtimes own scheduling, resource scopes and execution. Existing Get Modular composition stays the graph authority; its private lifecycle kernel cannot be copied into a new project as a convenience. [G1, G3, G4]

## Constraints newly verified

- New production repository admission requires full FMS v1.1 and real Foundation/native gates from the first reviewed bootstrap. SDKs and libraries are explicitly covered. Configuration checks alone mean configured_not_qualified. [O4]
- FMS requires feature ownership, not one package per feature. Empty layers/packages and catch-all shared/core directories are discouraged or forbidden as substitutes for ownership. A platform capability does not need fabricated business-domain entities. [O2]
- Ordinary TypeScript consumers and an optional native Effect surface should remain feasible. Current Get Modular provides separate optional native Effect construction; it does not mandate Effect in every reusable library. Native Effect errors, environment, cancellation and Scope should remain native inside that optional execution profile. [G1, G2, G5, G7]
- Cooperative resource debt/retry and native Effect Scope disposal are not interchangeable. Capability contracts must preserve the actual backend behavior. [G1, G3, G7]

## 1. Cohesive module and feature map

Recommendation, not published API: start with one portable live-update module and one real runtime adapter. Features carry semantic ownership; separate packages need independent dependency, release or consumer evidence. The separate repository is settled, its public package names and first supported slice are not. [O1, O2]

| Module | Real features | Owns | External owner |
| --- | --- | --- | --- |
| Portable live-update library | Planning; replacement; observation | Compatibility assessment, immutable intent/plan, one update-operation policy, correlated receipts and progress views | Existing composition, permission, state-storage and lifecycle authorities |
| First runtime adapter | Execution and retirement for one target | Construction, concrete host-call boundary, cancellation/stop observation and cleanup outcomes | Route authorization and state-schema policy |
| Optional native Effect integration | Native execution/construction | Native E/R, Scope/Fiber lifetime and Layer integration | Same shared update policy; no second authority |
| Adapter conformance kit | Capability-profile qualification | Positive/rejecting public-contract cases for independent implementations | Actual runtime behavior |
| Later adapters | Extism; Component Model; renderer/state store | Their distinct ABI/platform/serialization contracts | Ordinary TS consumers incur none of these dependencies |

Planning delegates graph validity and exact bindings to the current composition owner; it explains affected features and selects only supported modes. Replacement applies the authorized protocol. Observation projects facts and cannot activate a version by changing a UI status.

Keep state-transfer coordination inside replacement until it has a demonstrated independent lifecycle. A later feature can coordinate export/validate/import, but schema definitions, migration functions and permission to discard data remain consumer-owned. Do not pre-create empty artifact-store, policy, scheduler, journal or UI packages.

FMS layers appear where real responsibilities exist. Fixed dependencies use static imports, replaceable I/O uses consumer-owned ports, dynamic selection uses the validated graph. Composition contracts, if adopted, contain inert connection metadata and are composition-only dependencies. [O2]

## 2. Dependency direction and portable contracts

Application composition selects adapters; adapters implement a narrow feature-owned provider surface. Application code depends on its outbound contracts; decisions consume inert data. Node, Effect, browser and Wasm SDK types must not leak into the ordinary entrypoint. Optional dependencies become mandatory if pulled into its declaration graph.

A first delivery needs one real consumer plus disposable external projects. Prove ordinary strict TS use without organization credentials or product models. Add a separate native Effect consumer if offering that profile. The real application must consume the public artifact rather than deep-importing the checkout. [O1]

| Shared concept | Meaning | Must remain distinct |
| --- | --- | --- |
| Candidate descriptor | Artifact digest, contract/profile and relevant configuration identity | Human version label versus loaded bytes |
| Update intent | Target, expected head revision, selected state/retention decision | Intent versus authorization |
| Prepared plan | Immutable references to validated composition and supported actions | Product catalogs/framework graphs versus neutral contracts |
| Operation receipt | Correlated readiness, commit accepted/conflicted/unknown, retained old work, cleanup outcome | Requested action, acknowledgement and observed effect |
| State envelope | Schema/version, owner, export/import result | Serialized state versus live handles/closures |
| Update view | Projection of receipts, hold reasons and available actions | Display acknowledgement versus authority commit |

Library release, plugin contract, artifact digest, generation identity, head revision and schema version are separate axes. Kernel tokens belong to their issuing instance; durable identities require a separate contract. [G4]

Do not publish a bag containing every optional port. Public SPI needs the exact external adapter capability, accepted ownership/versioning and independent conformance. The organization permits narrow provider surfaces; it prohibits broad service-provider barrels. [O2, P1]

## 3. Shared decisions, distinct execution semantics

Share one domain-specific update decision/receipt policy. Execution profiles must not independently decide routing or maintain competing authoritative generation counters.

A possible implementation is a deterministic operation transition: validated state plus an observed fact yields the next operation state and concrete next-step requests, such as prepare, attempt publication, reconcile publication or retire predecessor. Requests carry operation/attempt identity; duplicate and late facts are evaluated against it. A local state transition cannot prove that remote publication happened.

Qualify this design against the first slice. Keep it specific to replacement. Adding generic fork/join/retry/timer instructions would create another workflow runtime. A straightforward async use case may be simpler; a second hypothetical driver alone does not justify a public command protocol.

The native Effect profile should call native effects in the caller's environment and owner Scope, retaining its E/R channels. A Promise facade is an intentional foreign boundary with explicit error, cancellation, context and lifetime mapping. Hidden repeated runPromise calls inside cooperating native modules create new roots rather than preserve the original chain. [G1, G7]

Ordinary Promise/AbortSignal support can advertise cooperative cancellation. Cancelling a waiting caller must not discard custody of an acquisition that can still succeed: retain an attempt before acquisition and route late results into cleanup/reconciliation.

| Option | Strength | Cost/condition |
| --- | --- | --- |
| Neutral use case first | Small ordinary TS surface | Add native execution only when a real consumer proves the bridge inadequate |
| Shared finite protocol plus ordinary/native drivers | One decision policy and native semantics in both profiles | Cross-driver conformance; select when both consumers exist |
| Effect-native library plus Promise facade | Strong native resource model | Deliberate mandatory Effect dependency; facade does not make it dependency-neutral |

The app's Effect decision does not select the third option for this library. There must be one active operation owner regardless of implementation choice. [O1, G5]

## 4. Verified reuse boundaries

| Mechanism | Reuse | Limit and decision |
| --- | --- | --- |
| Get Modular Core/Assembly and native Effect lowering | Validated wiring, exact selection, native Layer construction | Fresh mapper identities do not clone borrowed values or private captured Layers; keep one composition owner [G1, G8] |
| Resources 0.2.2 | Setup custody, close-flight joining, late setup settlement, explicit debt/retry | Cooperative cleanup callback completion is not physical release; same/ancestor close can deadlock. First trusted-resource candidate [G3, G9] |
| Lifecycle-kernel 0.1.0 | Existing synchronous generation/admission/lease design | Manifest is private:true; no loader, supervision, permissions or disposal. Official owner/public-release route, no copied kernel/deep import [G4, G10] |
| Effect 4.1.4 Scope/Layer/Fiber/ManagedRuntime | Native resource/work ownership | New Scope can share an identical Layer through MemoMap; escaped/foreign work is outside owner coverage. Optional native profile [E2-E4, G7] |
| Effect 4.1.4 RcMap | Keyed resource reuse and invalidation | Owner close closes indexed entries despite borrowers; invalidation removes one and defers its close while borrowers remain. Cache candidate, not complete generation authority [E1] |
| XState 5.33.4 pure transitions | Mature statechart transitions and action capture | Map private machine state/actions to owned contracts; no publication, custody or migration guarantees. Strong conditional candidate [X2, D1] |
| XState 5.33.4 Promise actors | Actor lifetime and cooperative AbortSignal | Stop aborts; late resolve/reject is ignored after inactivity. Actor stop is not a resource cleanup or physical-stop receipt [X1, X4, D2] |

Registry metadata confirms Get Modular Effect 0.1.1, exact peer Effect 4.1.4 and Core/Assembly ^0.8.0. Integrity is captured in gm-effect-registry.json. This proves package metadata, not installed-tarball behavior. Effect 4.1.4 is a non-prerelease upstream release at the pinned source revision. [R1, E1-E4]

### Counterexamples to preserve

1. **New Scope, old mutable service.** MemoMap keys by Layer identity. Sharing a MemoMap may reuse a live entry; a fresh mapper does not clone borrowed state. Generation configuration/state identity must be intentional; application pools are explicitly borrowed. [E4, G8]
2. **Second close looks clean.** ManagedRuntime completes its disposal Deferred successfully even if the first Scope close fails. A subsequent caller can observe completion without the first failure. A stable terminal receipt must retain the first observed outcome; it cannot invent retryable native cleanup. [E2]
3. **Stopped actor, late allocation.** XState intentionally discards late Promise output. For noncooperative acquisition, custody must exist outside that discarded result. This is an integration mismatch, not a defect claim. [X1, D2]

Current XState v6 docs are beta and contain different restoration APIs. Inspected stable release is 5.33.4. Do not combine beta examples with a v5 dependency. V5 persistence restarts invocations while actions are treated as performed; changed machine logic or nonserializable context can invalidate restoration. Actor snapshots do not atomically journal external effects. [X3, D3, D4]

## 5. Scaling and lifetime

Use one authoritative update lane per target/activation domain, not a global plugin lock. Independent targets can progress concurrently; competing candidates use existing expected-head/fencing authority. A publication timeout remains unknown until reconciliation.

Retain old versions for admitted operations, streams, cleanup attempts, history/replay needs and explicitly shared resources. Resource counts come from their owner; the UI/cache must not create another authoritative count. Consumer policy supplies retention budgets; the library can enforce the decision and explain defer/reject/restart outcomes.

Observers receive bounded snapshots and correlated changes. A slow observer cannot block activation or own the only recovery record. Durable audit/workflow deployment is a separate capability, not a dependency for local updates.

## 6. First-delivery qualification

| Gate | Concrete evidence |
| --- | --- |
| Ordinary external project | Packed compiled JS/declarations pass strict TS7.0.2+ NodeNext and supported bundler profile; no checkout imports, organization credentials or accidental optional dependencies |
| Real application | Public API demonstrates old/new operation affinity and separate visible activation/retirement |
| Capability truth | Unsupported preserve/force/stream modes reject before mutation; weaker adapters cannot claim stronger outcomes |
| Acquisition/cleanup | Late successful acquisition remains owned; failure stays visible; repeated callers receive the declared terminal outcome |
| Authority race | Concurrent candidates, lost commit acknowledgement and stale callbacks reconcile through the existing authority |
| Native Effect, if shipped | Caller context/cancellation survive; scoped work joins; generation-specific versus shared identity is explicit |
| Public adapter SPI, if published | Independently authored implementations pass the same positive/rejecting cases |
| Repository | Full FMS source/profile, real Foundation coverage, exact toolchain and native CI; configuration, hosted checks and required enforcement recorded separately |

No new behavioral probe ran in this lane. Source inspection resolves the bounded implementation claims above; parent work runs independent end-to-end probes. Do not relabel these findings as observed native runtime behavior.

## 7. Scope, cost and maintenance

Planning bands, not measured LOC or commitments. Production excludes tests/generated/reused dependency code. Integration includes adapters and consumer wiring. Rows are incremental; alternative implementation options must not be added together.

| Increment | Production logic | Adapters/integration | Tests/conformance | Docs/build/release tooling | Estimate confidence |
| --- | ---: | ---: | ---: | ---: | ---: |
| First portable slice: one mode/runtime, real plus disposable consumers | 900–1,800 | 500–1,000 | 1,800–3,500 | 600–1,200 | 4/10 |
| Full native Effect profile sharing one policy | 150–400 | 300–700 | 600–1,200 | 150–350 | 5/10 |
| One different runtime, such as Extism | 100–300 | 400–900 | 700–1,500 | 200–450 | 4/10 |
| Durable recovery integration using an existing authority/workflow system | 300–800 | 500–1,200 | 1,000–2,200 | 300–700 | 3/10 |

These bands exclude a complete editor, marketplace, distributed upgrade service and every language/renderer. The old P0/I150–350 allowance concerned one integration increment, not this project. Every additional runtime has ongoing compatibility, failure-conformance and release-maintenance costs; installed LOC is not the useful total-cost metric.

Ratings below are engineering judgments: reliability is potential to meet the stated contract after qualification, not measured availability. Higher complexity means more maintenance burden.

| Approach | Confidence | Reliability potential | Complexity |
| --- | ---: | ---: | ---: |
| Ordinary neutral library; existing mechanism owners; one runtime | 8/10 | 8/10 | 5/10 |
| Shared finite protocol; ordinary and native Effect drivers | 6/10 | 8/10 | 7/10 |
| Mandatory Effect plus explicit Promise facade | 7/10 | 8/10 | 5/10 native, 7/10 neutral consumers |
| XState pure transitions inside the owned protocol feature | 6/10 | 7/10 | 6/10 |
| New universal lifecycle/workflow/scheduler stack | 2/10 | 3/10 | 10/10 |

## 8. Open decisions and resolution tests

- **Lifecycle dependency:** officially consumable owner release or accepted ownership move; private source inspection is not installation.
- **Native Effect now/later:** one ordinary and one real native consumer against the same operation facts; use two drivers only if native context/lifetime demands it.
- **XState versus typed functions:** compare the first operation's actual hierarchical/parallel transition and inspection requirements. Pure API can remove transition machinery without adopting actor lifecycle.
- **State envelope:** actual serialization/validation and failed-import cases on the first backend.
- **Module extraction:** separate real native/platform dependency lifecycles; split other features at FMS conditions.
- **Repository:** provisioning/admission belongs to parent; this lane created no repository or remote change.

Source IDs resolve in sources.json; findings.json separates verified facts, recommendations and unresolved questions. source-provenance.json verifies all 23 retained source snapshots against their upstream Git blobs and maps Effect/XState files to the exact-revision MIT notices in licenses/. These files are inspection inputs, not compiled or executed dependencies.

