# Retained source notices

These files preserve version-pinned upstream implementation as research inspection evidence. The source-to-origin and source-to-license mapping, local hashes and verified upstream Git blob identities are in ../source-provenance.json.

| Retained files | Upstream revision | License notice |
| --- | --- | --- |
| source/E1.ts through source/E4.ts | Effect-TS/effect @ 289a53f7b1fc40049219c6e69022db2fb859c356 | effect-MIT-LICENSE; Copyright (c) 2023 Effectful Technologies Inc |
| source/X1.ts, X2.ts, X3.json and X4.ts | statelyai/xstate @ bd77717b8d33c49af1c8ee4a7e22cebb936cc8b1 | xstate-MIT-LICENSE; Copyright (c) 2015 David Khourshid |

Both license files are byte-identical to LICENSE at the respective source revision. All 23 retained source files are byte-identical to their pinned upstream Git blobs. Before freezing, one tool-added terminal newline was removed from 11 snapshots to restore exact upstream bytes; source-provenance.json records those files.

Organization-owned .github, Get Modular and prior Extension Foundation sources retain their original bytes and source attribution. The archive must retain these notices alongside the third-party source snapshots.

