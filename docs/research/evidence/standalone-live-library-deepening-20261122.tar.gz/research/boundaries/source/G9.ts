import {
  checkCloseOptions, checkName, checkScopeOptions, disposer, follow, invalid, isRecord, isSignal, noop, type Order,
} from "./arguments.js";
import { CloseIncompleteError, InvalidArgumentError, ScopeClosedError } from "./errors.js";
import type {
  CleanupContext, CloseOptions, CloseReport, Debt, Resources, Scope, ScopeControl, ScopeOptions, SetupSpec,
} from "./types.js";

type Where = "live" | "active" | "failed" | "gone";
type Entry = {
  readonly name: string;
  readonly release: ((context: CleanupContext) => unknown) | undefined;
  child: ScopeNode | undefined;
  where: Where;
  cause: unknown;
};
type PendingSetup = { readonly name: string; readonly settled: Promise<void> };
type Flight = {
  readonly escalate: AbortController;
  readonly done: Promise<CloseReport>;
  readonly finish: (report: CloseReport) => void;
  readonly unlink: (() => void)[]; // caller escalate listeners, removed when the flight settles
};
type AbortNotifications = {
  depth: number;
  draining: boolean;
  readonly pending: { readonly node: ScopeNode; readonly flight: Flight }[];
};

const freeze = Object.freeze;
const COMPLETE: CloseReport = freeze({ complete: true, settled: true, debts: freeze([]) });
const COMPACT_AT = 32;
const nodes = new WeakMap<object, ScopeNode>(); // Resources facade -> node: identity brand of this package copy

// A call boundary: an await inside the caller may change `where` behind control-flow narrowing.
function isActive(entry: Entry): boolean {
  return entry.where === "active";
}
class ScopeNode {
  readonly path: readonly string[];
  readonly resources: Resources;
  readonly facade: Scope;
  #parent: ScopeNode | undefined;
  #entry: Entry | undefined;
  readonly #order: Order;
  readonly #notifications: AbortNotifications;
  readonly #setupAbort = new AbortController();
  readonly #children = new Set<ScopeNode>(); // registry: signals walk it, children never subscribe to the parent
  readonly #pending = new Set<PendingSetup>();
  readonly #active = new Set<Entry>();
  #live: Entry[] = []; // LIFO; detached children leave tombstones that are compacted
  #tombstones = 0;
  #failed: Entry[] = []; // attempted and failed, in attempt order
  #requested = false;
  #requestNotified = false;
  #detached = false;
  #flight: Flight | undefined;

  constructor(name: string, parent: ScopeNode | undefined, order: Order) {
    this.path = freeze([...(parent?.path ?? []), name]);
    this.#parent = parent;
    this.#order = order;
    this.#notifications = parent ? parent.#notifications : { depth: 0, draining: false, pending: [] };
    if (parent && parent.#setupAbort.signal.aborted) {
      this.#setupAbort.abort(parent.#setupAbort.signal.reason);
    }
    const resources: Resources = freeze({
      signal: this.#setupAbort.signal,
      setup: <T>(spec: SetupSpec<T>) => this.#setup(spec),
      use: <T extends AsyncDisposable | Disposable>(value: T, entryName: string) => this.#use(value, entryName),
      child: (childOptions: ScopeOptions) => this.#child(childOptions).facade,
    });
    const close = (closeOptions?: CloseOptions): Promise<CloseReport> => this.#close(closeOptions);
    const control: ScopeControl = freeze({
      close,
      async [Symbol.asyncDispose]() {
        const report = await close();
        if (!report.complete) {
          throw new CloseIncompleteError(report);
        }
      },
    });
    nodes.set(resources, this);
    this.resources = resources;
    this.facade = freeze({ resources, control });
    if (parent) {
      this.#entry = { name, release: undefined, child: this, where: "live", cause: undefined };
      parent.#live.push(this.#entry);
      parent.#children.add(this);
    }
  }

  // ---- registration ----
  #setup<T>(spec: SetupSpec<T>): Promise<T> {
    const candidate: unknown = spec;
    if (!isRecord(candidate) || typeof candidate.setup !== "function" || typeof candidate.cleanup !== "function") {
      throw invalid("setup() requires { name, setup, cleanup }"); // synchronous: a programming error, not a runtime outcome
    }
    const name = checkName(candidate.name, "setup()");
    const { setup, cleanup } = spec; // captured once, like Assembly captures factories at bind
    if (this.#requested) {
      return Promise.reject(new ScopeClosedError(this.path));
    }
    let settle!: () => void;
    const record: PendingSetup = { name, settled: new Promise<void>((resolve) => { settle = resolve; }) };
    this.#pending.add(record); // registered before the user callback runs
    let resolveAuthor!: (value: T) => void;
    let rejectAuthor!: (cause: unknown) => void;
    const author = new Promise<T>((resolve, reject) => { resolveAuthor = resolve; rejectAuthor = reject; });
    const acquire = async (): Promise<void> => {
      let value: T;
      try {
        value = await Promise.try(setup, { signal: this.#setupAbort.signal });
      } catch (cause) {
        this.#pending.delete(record);
        settle();
        rejectAuthor(cause);
        return;
      }
      this.#pending.delete(record); // same turn as the push: never two debts for one resource
      this.#live.push({ name, release: (context) => cleanup(value, context), child: undefined, where: "live", cause: undefined });
      settle();
      if (this.#requested) {
        author.catch(noop); // only the late refusal is pre-handled
        rejectAuthor(new ScopeClosedError(this.path));
      } else {
        resolveAuthor(value);
      }
    };
    void acquire();
    return author;
  }

  #use<T>(value: T, name: string): T {
    const release = disposer(value);
    const entryName = checkName(name, "use()");
    if (this.#requested) {
      throw new ScopeClosedError(this.path); // no custody: the caller still owns value
    }
    this.#live.push({ name: entryName, release, child: undefined, where: "live", cause: undefined });
    return value;
  }

  #child(options: ScopeOptions): ScopeNode {
    const checked = checkScopeOptions(options);
    if (this.#requested) {
      throw new ScopeClosedError(this.path);
    }
    return new ScopeNode(checked.name, this, checked.order);
  }

  /** scoped(): a module scope whose setups stop when the run is cancelled, until the factory settles. */
  static openModule(context: unknown, name: string): { node: ScopeNode; unlink: () => void } {
    const scope = isRecord(context) ? context.scope : undefined;
    const parent = isRecord(scope) ? nodes.get(scope) : undefined;
    if (parent === undefined) {
      throw new InvalidArgumentError("resources.scoped.invalid-run-scope",
        "scoped() requires run({ scope }) with the Resources of a scope of this @get-modular/resources copy; pass scope.resources");
    }
    const node = parent.#child({ name });
    const runSignal = isRecord(context) ? context.signal : undefined;
    const unlink = isSignal(runSignal) ? follow(runSignal, () => { node.#abortSetups(runSignal.reason); }) : noop;
    return { node, unlink };
  }

  // ---- tree signals (walk the registry; O(1) child attach and detach) ----
  /** Live iterators preserve child order and reentrant detach/add behavior without recursive calls. */
  #walk(visit: (node: ScopeNode) => boolean): void {
    const cursors: Iterator<ScopeNode>[] = [[this].values()];
    for (let cursor = cursors.at(-1); cursor; cursor = cursors.at(-1)) {
      const next = cursor.next();
      if (next.done === true) {
        cursors.pop();
      } else if (visit(next.value)) {
        cursors.push(next.value.#children.values());
      }
    }
  }

  #abortSetups(reason: unknown): void {
    if (this.#setupAbort.signal.aborted) {
      return;
    }
    this.#notifications.depth += 1;
    try {
      this.#walk((node) => {
        if (node.#setupAbort.signal.aborted) { return false; }
        node.#setupAbort.abort(reason);
        return true;
      });
    } finally {
      this.#finishNotification();
    }
  }

  #request(): void {
    this.#walk((node) => {
      if (node.#requested) { return false; }
      node.#requested = true;
      return true;
    });
  }

  #abortRequested(): void {
    if (this.#requestNotified) {
      return;
    }
    this.#notifications.depth += 1;
    try {
      this.#walk((node) => {
        if (node.#requestNotified) { return false; }
        node.#requestNotified = true; // a reentrant close joins without restarting this walk
        if (!node.#setupAbort.signal.aborted) {
          node.#setupAbort.abort(new ScopeClosedError(node.path));
        }
        return true;
      });
    } finally {
      this.#finishNotification();
    }
  }

  #finishNotification(): void {
    this.#notifications.depth -= 1;
    this.#drainStarts();
  }

  #drainStarts(): void {
    const notifications = this.#notifications;
    if (notifications.depth !== 0 || notifications.draining) {
      return;
    }
    notifications.draining = true;
    try {
      // Child flights append their starts while a parent suspends. Drain the live queue in this turn,
      // after every native abort listener in this tree returns, without recursive child-flight startup.
      for (const pending of notifications.pending) {
        void pending.node.#run(pending.flight);
      }
    } finally {
      notifications.pending.length = 0;
      notifications.draining = false;
    }
  }

  #escalateTree(reason: unknown): void {
    this.#walk((node) => {
      const flight = node.#flight;
      if (flight && !flight.escalate.signal.aborted) {
        flight.escalate.abort(reason);
      }
      return true;
    });
  }

  // ---- close ----
  #close(options: CloseOptions | undefined): Promise<CloseReport> {
    const { escalate, abandon } = checkCloseOptions(options); // before any state change
    this.#request();
    const started = this.#flight === undefined;
    const flight = this.#flight ?? this.#open();
    if (flight && escalate && !flight.escalate.signal.aborted) {
      const unlink = follow(escalate, () => { this.#escalateTree(escalate.reason); });
      if (unlink !== noop) {
        flight.unlink.push(unlink);
      }
    }
    this.#abortRequested(); // sealed subtree and published escalation precede user abort listeners
    if (flight === undefined) {
      return Promise.resolve(COMPLETE);
    }
    if (started) {
      this.#start(flight); // after escalate is linked: the first cleanup already sees it
    }
    if (abandon === undefined) {
      return flight.done;
    }
    if (abandon.aborted) {
      return Promise.resolve(this.#report(false));
    }
    // abandon is per caller: this call resolves with a snapshot, the flight continues in order for everyone else
    return new Promise<CloseReport>((resolve) => {
      const onAbandon = (): void => { resolve(this.#report(false)); };
      abandon.addEventListener("abort", onAbandon, { once: true });
      void (async () => {
        const report = await flight.done;
        abandon.removeEventListener("abort", onAbandon);
        resolve(report);
      })();
    });
  }

  /** Called by the parent's flight: joins or starts this scope's flight; never rejects. */
  #join(escalated: AbortSignal): Promise<CloseReport> {
    this.#request();
    const started = this.#flight === undefined;
    const flight = this.#flight ?? this.#open();
    if (escalated.aborted) {
      this.#escalateTree(escalated.reason);
    }
    this.#abortRequested();
    if (flight === undefined) {
      return Promise.resolve(COMPLETE);
    }
    if (started) {
      this.#start(flight);
    }
    return flight.done;
  }

  #start(flight: Flight): void {
    this.#notifications.pending.push({ node: this, flight });
    this.#drainStarts();
  }

  #open(): Flight | undefined {
    if (this.#failed.length > 0) { // every new flight retries what is still unreleased (Q2)
      for (const entry of this.#failed.toReversed()) {
        if (entry.where === "failed") {
          entry.where = "live";
          this.#live.push(entry);
        }
      }
      this.#failed = [];
    }
    if (this.#live.length === this.#tombstones && this.#pending.size === 0) {
      this.#detach();
      return undefined;
    }
    let finish!: (report: CloseReport) => void;
    const done = new Promise<CloseReport>((resolve) => { finish = resolve; });
    const flight: Flight = { escalate: new AbortController(), done, finish, unlink: [] };
    this.#flight = flight; // published before the first user callback
    for (let parent = this.#parent; parent; parent = parent.#parent) { // an escalated ancestor flight covers new subtree flights
      const ancestor = parent.#flight?.escalate.signal;
      if (ancestor?.aborted === true) {
        flight.escalate.abort(ancestor.reason);
        break;
      }
    }
    return flight;
  }

  #pop(): Entry | undefined {
    for (;;) {
      const entry = this.#live.pop();
      if (entry === undefined) {
        return undefined;
      }
      if (entry.where !== "gone") {
        return entry;
      }
      this.#tombstones -= 1;
    }
  }

  async #run(flight: Flight): Promise<void> {
    for (;;) {
      if (this.#pending.size > 0) {
        await Promise.all(Array.from(this.#pending, (record) => record.settled));
        continue;
      }
      if (this.#order === "concurrent") {
        const batch: Entry[] = [];
        for (let entry = this.#pop(); entry; entry = this.#pop()) {
          batch.push(entry);
        }
        if (batch.length === 0) {
          break;
        }
        await Promise.all(batch.map(async (entry) => this.#invoke(entry, flight)));
        continue;
      }
      const entry = this.#pop();
      if (entry === undefined) {
        break;
      }
      await this.#invoke(entry, flight); // strictly one cleanup at a time
    }
    this.#settle(flight);
  }

  async #invoke(entry: Entry, flight: Flight): Promise<void> {
    entry.where = "active";
    this.#active.add(entry);
    try {
      const child = entry.child;
      if (child) {
        const report = await child.#join(flight.escalate.signal); // the parent waits for the child, whoever else abandons
        if (!report.complete && isActive(entry)) { // the child may have detached the entry meanwhile
          this.#fail(entry, null); // the child's own debts carry the causes
        }
        return;
      }
      await entry.release?.({ escalate: flight.escalate.signal });
      entry.where = "gone"; // released: the closure is dropped with the entry
    } catch (cause) {
      this.#fail(entry, cause); // continue with the next entry (Q1)
    } finally {
      this.#active.delete(entry);
    }
  }

  #fail(entry: Entry, cause: unknown): void {
    entry.where = "failed";
    entry.cause = cause;
    this.#failed.push(entry);
  }

  #settle(flight: Flight): void {
    for (const unlink of flight.unlink.splice(0)) {
      unlink();
    }
    this.#flight = undefined;
    const report = this.#report(true);
    if (report.complete) {
      this.#detach();
    }
    flight.finish(report);
  }

  #detach(): void {
    if (this.#detached) {
      return;
    }
    this.#detached = true;
    const parent = this.#parent;
    const entry = this.#entry;
    if (parent && entry) {
      parent.#children.delete(this);
      parent.#forget(entry);
    }
    this.#parent = undefined;
    this.#entry = undefined;
  }

  #forget(entry: Entry): void {
    const where = entry.where;
    entry.where = "gone";
    entry.child = undefined;
    if (where !== "live") {
      return; // active: the running flight finishes it; failed: dropped at the next flight
    }
    this.#tombstones += 1;
    if (this.#tombstones > COMPACT_AT && this.#tombstones * 2 > this.#live.length) {
      this.#live = this.#live.filter((candidate) => candidate.where !== "gone");
      this.#tombstones = 0;
    }
  }

  // ---- report: release order (failed, running, pending setups, not yet run) ----
  #debts(out: Debt[]): void {
    const cursors: Iterator<ScopeNode | Debt>[] = [this.#debtItems()];
    for (let cursor = cursors.at(-1); cursor; cursor = cursors.at(-1)) {
      const next = cursor.next();
      if (next.done === true) {
        cursors.pop();
      } else if (next.value instanceof ScopeNode) {
        cursors.push(next.value.#debtItems());
      } else {
        out.push(next.value);
      }
    }
  }

  *#debtItems(): Generator<ScopeNode | Debt> {
    for (const entry of this.#failed) {
      if (entry.where === "failed") {
        yield this.#debt(entry, "failed");
      }
    }
    for (const entry of this.#active) {
      if (entry.where === "active") {
        yield this.#debt(entry, "pending");
      }
    }
    for (const record of this.#pending) {
      yield freeze({ path: freeze([...this.path, record.name]), state: "pending" });
    }
    for (const entry of this.#live.toReversed()) {
      if (entry.where === "live") {
        yield this.#debt(entry, "not-run");
      }
    }
  }

  #debt(entry: Entry, state: Debt["state"]): ScopeNode | Debt {
    if (entry.child) {
      return entry.child;
    }
    const path = freeze([...this.path, entry.name]);
    return freeze(state === "failed" ? { path, state, cause: entry.cause } : { path, state });
  }

  #report(settled: boolean): CloseReport {
    const debts: Debt[] = [];
    this.#debts(debts);
    if (debts.length === 0 && settled) {
      return COMPLETE;
    }
    return freeze({ complete: debts.length === 0, settled, debts: freeze(debts) });
  }
}

export function createScope(options: ScopeOptions): Scope {
  const checked = checkScopeOptions(options);
  return new ScopeNode(checked.name, undefined, checked.order).facade;
}

/**
 * Opens one module scope per factory call, synchronously, under run({ scope }).
 * The factory receives every other field of the Assembly context unchanged, plus `resources`; never the run scope.
 */
export function scoped<Deps, R, X extends { readonly signal: AbortSignal; readonly scope: unknown }>(
  name: string,
  factory: (deps: Deps, context: Omit<X, "scope"> & { readonly resources: Resources }) => R,
): (deps: Deps, context: X) => R {
  checkName(name, "scoped()");
  if (typeof factory !== "function") {
    throw invalid("scoped() requires a factory function");
  }
  return (deps, context) => {
    const { node, unlink } = ScopeNode.openModule(context, name); // coded TypeError before the body
    const { scope: _runScope, ...forwarded } = context;
    const moduleContext: Omit<X, "scope"> & { readonly resources: Resources } = { ...forwarded, resources: node.resources };
    freeze(moduleContext);
    let result: R;
    try {
      result = factory(deps, moduleContext);
    } catch (cause) {
      unlink();
      throw cause;
    }
    if (result instanceof Promise) {
      void Promise.prototype.then.call(result, unlink, unlink);
    } else {
      unlink();
    }
    return result;
  };
}
