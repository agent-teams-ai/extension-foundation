# External-consumer ownership criterion

2026-11-22. Design clarification after the standalone blueprint review. This supplements the archived boundaries report; it is not a new API or implementation.

## A reusable runtime must remove orchestration work

The library owns the useful replacement use case: prepare and evaluate a candidate, apply the selected update policy, coordinate the one authoritative publication, handle unknown outcomes, preserve custody across cancellation, request retirement through existing mechanisms, and produce stable receipts/progress. These steps belong to one library operation, not a sequence each consumer must rewrite.

The host owns product authorization, the state schema/migration decision and the meaning of its authoritative head. Ownership does not require all mechanism code to live in the application. A host may delegate an implementation to a library-provided adapter when that remains the sole authority. An existing durable owner must not be shadowed by another local coordinator/store.

Resources, composition and generation bookkeeping are reused below this use case. The private lifecycle-kernel dependency remains an actual release/ownership issue to resolve; it must not be disguised as “the host implements lifecycle” or bypassed with copied bookkeeping.

## Narrow primitives, complete library behavior

| Consumer supplies/selects | Library supplies |
| --- | --- |
| Target/artifact and an authorized policy decision | Executable replacement planning and coordination |
| Existing authoritative commit/read primitive, with actual accepted/conflict/unknown semantics | Correlation, publication/reconciliation decisions and stable operation receipts |
| Product state validation/migration functions and an actual store adapter where needed | Transfer sequencing and ownership of an incomplete attempt |
| A supported shipped runtime adapter, plus real configuration | Runtime construction/invocation/stop integration and cleanup reporting |
| Presentation and telemetry destination | Bounded useful progress and version/retention views |

A giant mandatory interface with prepare/activate/drain/retry/reconcile implementations would return the main work to the consumer. Prefer a complete local profile with real supplied mechanisms, then explicit optional capabilities for durable authority, native Effect or another runtime. Do not make ordinary users implement features that their selected profile does not support.

## Decisive acceptance test

Use an independently authored ordinary consumer. Its integration should configure narrow real primitives and call the library operation. It should not implement the update phase machine, candidate custody, a generation lease counter, watcher recovery orchestration or finalizer retry bookkeeping.

If correct integration requires rebuilding those behaviors, the abstraction boundary has failed. Resolve the existing owner/public-release route or move the reusable behavior to its explicitly accepted owner; do not label the consumer code “adapter glue” and preserve duplicated orchestration.

The real consumer must remain functional without organization credentials, application catalogs or checkout-only imports. The ordinary and native Effect profiles share this criterion even when their execution mechanics differ. First delivery still requires an actual consumer, not only mocks or a disposable example. [Archived sources O1, O2, G4, G10, P1]

This criterion does not require another runtime experiment or speculative API now. It is a release/design acceptance condition for the planned standalone library.

