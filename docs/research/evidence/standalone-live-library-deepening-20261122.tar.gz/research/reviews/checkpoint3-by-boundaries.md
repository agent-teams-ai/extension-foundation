# Independent review: checkpoint 3 workflow, inputs and blueprint

Reviewer: library_boundaries_research. Date: 2026-11-22 UTC.
Scope: proposed EF browser workflow, frozen browser/architecture archives and expanded standalone blueprint. No new runtime experiment executed.

**Verdict: no blocker to commit/push and start the scoped browser workflow.** Browser behavior remains pending hosted execution.

## Verified custody

| Item | Observed identity |
| --- | --- |
| Browser input | 16,829 bytes; SHA-256 f34fa84596ccf743bcf90cc033d33baaf7c49486f46ec3928c271d4cdb96ee28 |
| Browser members | 16 unique regular files, 56,149 uncompressed bytes; every manifest length/hash matches |
| Final browser test | SHA-256 dfc43599657f016986fe6320c0276badbc80aaeeda2828d8982b1a25b2ffae4c; matches the reviewed source and recorded strict-check input |
| Architecture input | 146,133 bytes; SHA-256 a779c2d996cfcd9531b44d4d3b50a4ef89ecf8c6b40c3aa3464170502466ec67 |
| Architecture members | 51 unique regular files, 520,334 uncompressed bytes; every manifest length/hash matches |
| Workflow source | 5,891 bytes; SHA-256 510d0a9ffbb923410e70742e5b5162fa006a696a6c06b26af964c05d9afbf28b |

Both archives contain no absolute/parent-traversal names, symbolic/hard links or special members. Browser basis hash/size matches the retained prior source archive.

Inside the architecture packet, all 23 source snapshots and both exact-revision MIT notices match their upstream Git blob identities and local SHA-256 values. The archived browser review binds the final test, and the archived local-check receipt records strict exit0. Source evidence is preserved with its provenance/licenses.

## Workflow review

The workflow checks out the triggering commit with persistent credentials disabled, has contents:read only, and is limited to the research branch plus relevant workflow/input paths. Action pins match the repository's existing research workflows.

The source step verifies archive bytes/hash, exact manifest membership and regular-file type before standard data-filter extraction, then verifies each extracted member. It writes a receipt binding the triggering commit, run/attempt, archive and workflow hash.

The disposable install is frozen, ignores package scripts and enforces engine/peer contracts. Installed direct versions must match exact declarations, including TypeScript7.0.2. Strict checking precedes the pinned Playwright Chromium installation and one runtime test. Pipefail prevents tee from hiding command failure. Artifact upload runs on failure as well as success and retains actual source, environment, logs and observed outputs.

This review does not claim that the hosted workflow has succeeded, that all dependency internals are independently audited, or that a production runtime is qualified.

## Expanded blueprint

The new architecture and protocol sections preserve the accepted owners: one replacement policy, existing graph/activation authority, consumer schemas/state policy and runtime-specific resource supervision. Ordinary TS and optional native Effect remain explicit alternatives. XState pure transitions are a conditional reuse candidate; actor lifetime does not silently become resource custody.

The protocol keeps lost publication acknowledgement unknown until reconciliation, separates newly admitted work from retained predecessors, and requires useful-output evidence separately from activation. Retention distinguishes live executors, artifacts/codecs, user documents, undo history, temporary resources, business data and diagnostics. Budget exhaustion does not silently authorize force or deletion.

Cost bands are scoped planning judgments with separate production, integration, tests and documentation/tooling. Browser input is clearly pending: one test, three sequential phases, 38 named comparisons. Native mechanism tests are not relabeled as browser or production evidence.

## Nonblocking precision for the next documentation checkpoint

The first-delivery paragraph abbreviates the compiler floor as “strict TS7+”. Use “strict TS7.0.2+” consistently with the actual mandatory floor and checked inputs. This wording does not affect the frozen workflow, which already asserts exactly7.0.2.

No additional runtime test, dependency or source investigation is requested.

