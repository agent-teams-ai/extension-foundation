# Independent review: executed browser recovery v2

Reviewer: library_boundaries_research. Date: 2026-11-22 UTC.

**Verdict: the bounded browser E2E passed; no blocker to recording the result.** This reviews retained source, artifact and actual observations. No runtime rerun was performed.

## Exact evidence checked

- Run45034893087, attempt1, commit0e0bfb1b6468df90391134f4731e3e3df52479d2.
- Artifact14759765045: 101,058 bytes; SHA-256 ecef2ef8fa8a779a29383fbf6e0f94b9d26adbb17444d66e64b575df27e7afba.
- Independently recomputed ZIP digest and all 28 output member hashes/sizes; retained extracted bytes match.
- All 16 frozen source-input files match the v2 manifest. Hosted receipt matches exact commit, run/attempt, input digest and retained workflow hash.
- Runtime log's emitted observation object equals observations.json.
- Exactly one test passed, with zero failures, cancellations, skips and todos. All 49 named comparisons match; all three sequential phases completed.
- Source and observation record contain exactly one explicit public ViteDevServer.reloadModule recovery request.

## What the result establishes

Compatible native HMR and changed-hook remount retain the tested host document/draft/history and textarea identity, focus and selection. The rejecting module causes an actual native error while the previous v3 remains useful for new editing and Undo.

The repaired v4 module evaluates and has a correlated transport receipt while the displayed useful version is still v3. One explicit public native recovery follows. The result then shows actual v4 computation, v3 cleanup before v4 setup, only the current event/document callback responding, original textarea/document/draft retained, and working prior Undo/Redo plus a fresh user edit computed by v4.

Focus and selection are checked at the recovery boundary before subsequent intentional Undo/Redo button clicks. The final snapshot being unfocused after those clicks does not contradict that bounded preservation assertion.

## First failure remains separate

Original v1 still records one failed test after31 matching comparisons and a15-second wait for useful v4. It is not relabeled as passing. v2 establishes explicit recovery for the tested failure, not automatic direct-repair success.

The useful distinction is now demonstrated: imported code and successful HMR transport are weaker evidence than a visibly functioning updated feature.

## Limits

Exact React/Vite/Yjs development profile, Chromium159.0.8154.6 and Node24.22.3; strict compiler7.0.2. This is one same-module body-evaluation failure and its recovery. It is not proof for all syntax/transform/dependency failures, production switching, a complete plugin library, IME, durable/network persistence, schema migration, process-crash recovery, heap bounds or leak freedom.

The evidence supports ending this bounded experiment. No additional run is requested.

