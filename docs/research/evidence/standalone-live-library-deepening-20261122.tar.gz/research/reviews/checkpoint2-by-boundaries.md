# Independent review: checkpoint 2 native evidence

Reviewer: library_boundaries_research. Observation: 2026-11-22 UTC.

**Verdict: no blocking issue.** The immutable packet and the blueprint's native section support the bounded claims. This review inspected archived bytes and source/log correspondence; it did not rerun the probes.

## Custody checked

- Archive size: 47,028 bytes.
- SHA-256: 7dc291bf39df137738f126fd277b8824a43f511297bacae9fcb86b41982d96d6.
- Exactly 40 unique regular members; no absolute paths, parent traversal, symbolic/hard links or special members.
- Member names exactly match the external manifest; all byte lengths and SHA-256 hashes match; 142,091 uncompressed file bytes.
- Internal version manifests match all 13 and 10 referenced members; feedback FILE-MANIFEST matches all 23 referenced members.
- Both independent cross-reviews are present and consistent with the archived tests and blueprint.

## Evidence and claim review

The Node log records five passing tests, no failures/cancellations/skips/todos. The Yjs log records seven with the same zero counts. Both strict configurations include their actual source file and skipLibCheck:false; compiler logs say 7.0.2. The recorded typecheck commands have no diagnostics, and the result/author records report successful exits. First-attempt provenance is the recorded author evidence, not something the archive hash alone establishes.

The five Node cases exercise actual Promise context, EventEmitter callbacks, mutable snapshot reference, generator next/return and native FileHandle close/read failure. They justify the distinction between context affinity and resource custody. The blueprint correctly leaves generator throw and worker/browser/process propagation unqualified; it does not claim an admission gate was tested.

The seven Yjs cases directly establish content/history persistence across exact subscription replacement, explicit capture boundaries, origin filtering without mutation authority, history clear without data clear, document codec without UndoManager serialization, one relative-position codec case and the post-destroy misuse counterexample. The blueprint labels the latter as misuse and correctly explains that a command gate cannot revoke already escaped raw mutable references.

The new native section does not claim browser focus/IME, DOM teardown, network durability, distributed fencing or production hot replacement. Keeping the forthcoming browser experiment separately identified is appropriate.

## Nonblocking metadata note

The manifest retains Europe/Kiev, while this review/current environment uses UTC. The research date remains November 22 in either zone; this does not alter test semantics or custody. Do not mutate the frozen archive merely to restyle metadata.

No rerun, broader test suite or code change is needed for this checkpoint.

