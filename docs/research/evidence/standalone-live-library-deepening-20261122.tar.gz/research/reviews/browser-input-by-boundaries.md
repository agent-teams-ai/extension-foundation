# Independent browser input review

Reviewer: library_boundaries_research. Date: 2026-11-22 UTC.
Scope: pre-execution review of browser/PLAN.md, probe/browser.test.ts, all fixture source, manifest/lockfile, strict compiler configuration and recorded local compiler logs. No browser was executed by this reviewer.

**Verdict: ready to freeze; no remaining blocker.** Runtime outcomes remain unobserved and must be reported honestly if the hosted run fails.

## Substantive checks

- Genuine native path: the test copies the fixture, writes actual Plugin.tsx bytes and runs Vite with the real React plugin. There is no custom HMR accept, substitute update manager, DOM rewriting to fake the new computation, or fallback module loader.
- One test, three sequential phases: compatible native HMR, changed-hook remount, failed candidate and repair. This is not three independent tests; all later phases depend on earlier ones.
- First phase checks actual textarea/plugin ElementHandle identity, dirty text, activeElement and selection range before Undo/Redo. Remount checks changed plugin identity while the host textarea, document identity, focus and selection survive.
- Subscription counters remain explicitly declared fixture accounting. Actual DOM events and Yjs edits/Undo independently assert that only the current callback responds; trace ordering checks cleanup before setup.
- The rejecting module self-reports a diagnostic then genuinely throws at evaluation. A separate console/pageerror observation must corroborate it. The diagnostic is not a readiness signal or generic failure detector; no silent fallback is introduced.
- The host owns Y.Doc, Y.Text and UndoManager. Plugin props expose only string reads and subscription cleanup. Source comments correctly limit this to trusted API discipline, not enforcement against in-process code that bypasses the interface.
- Stored-source identity and original DOM handles make a hidden page reload fail. Watch events, console/errors, comparisons, final Plugin bytes and screenshots are retained for diagnosis.
- Actual package comparison against retained base shows exactly one declared dependency addition: yjs@13.6.33. React/Vite/Playwright/TypeScript and existing type pins are unchanged. The strict project includes the runner and every fixture variant, with skipLibCheck:false and TS7.0.2 recorded. Hosted execution should retain its own successful typecheck/install receipts.

## Review improvement adopted

The initial rejection phase could have mistaken an unchanged DOM projection for a still-functional old view. The author added a new user edit after rejection, requiring v3's transformed output and exactly v3's document observer, followed by Undo restoring the pre-rejection dirty draft. Phase1 also now checks actual observer delivery during Undo instead of relying only on the declared subscription balance. These strengthen existing planned behavior without adding another runtime scenario.

Final failure-evidence adjustment reviewed: native error waiter, UI diagnostic waiter and the file-edit Promise are joined together after registering both waiters. A failed edit or missing diagnostic cannot leave the native waiter temporarily unhandled before evidence cleanup. No oracle was weakened. The final local-check receipt records typecheckExit:0, compiler7.0.2 and matching input hashes, including the reviewed test hash below; it correctly leaves hosted browser execution pending.

## Input identities reviewed

| Path | SHA-256 |
| --- | --- |
| PLAN.md | ad53f52123d8b02e8d9bd64aa63671d80f0b29012e872c52a257d21cce03ffe4 |
| probe/browser.test.ts | dfc43599657f016986fe6320c0276badbc80aaeeda2828d8982b1a25b2ffae4c |
| probe/package.json | 69c563a9aa6c33b66c77f8703706a2f55c4e01789eca4768066eb904468a54e5 |
| probe/pnpm-lock.yaml | bf60f9609153a5c2496ef757cbec93f4e70916d2646bc05a25813e05f976cce4 |
| probe/tsconfig.json | a6dd912ba4ca00935629e593a33ba3908a3c6fb0d4c9086c12767f841b993f76 |

Root owns final archive/member manifest and hosted workflow input identity; this review is not that future archive receipt.

## Limits preserved

No production switching, IME/composition, distributed collaboration, durable storage, state-schema migration, arbitrary raw-reference revocation, crash recovery, general rollback, memory-bound or leak-freedom claim follows. Focus/selection evidence applies to the actual tested textarea and transitions. A successful native dev-HMR result does not qualify production activation authority.

No additional broad test or dependency is requested.

