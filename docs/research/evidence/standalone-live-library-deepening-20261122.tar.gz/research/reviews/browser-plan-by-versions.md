# Independent review: browser continuity plan and inputs

Reviewer: version/state research lane. Date: 2026-11-22 UTC.

**Verdict before browser execution: no blocking issue in the bounded plan or inputs.**
Read browser/PLAN.md, browser.test.ts, fixture state/host/probe modules and every
plugin variant. This review did not run the browser and establishes no pass.

The compatible-update phase compares actual textarea and plugin DOM references,
focus/selection, draft, Y.Doc GUID and useful Undo/Redo. The changed-hook phase
expects a different plugin DOM while retaining the host state, and checks a
real subsequent edit reaches only the current callback. Plugin listener cleanup
is corroborated by real DOM event delivery, not only a counter.

The rejecting candidate reports a known failure through a fixture event and
then actually throws during module evaluation. The report is not itself an
execution oracle: the test independently waits for a matching native browser or
Vite console error. The fixture does not merely print that message in console.
The subsequent edit and Undo require the retained v3 implementation to perform
new work, so a stale rendered value cannot satisfy the usable-view claim.

Only getSnapshot/subscribe strings and cleanup are passed to the plugin. Raw
Y.Doc/Y.Text/UndoManager stay in the host state module. This demonstrates an API
discipline for trusted code: a same-process plugin can still import known host
modules or access other ambient capabilities, so it does not demonstrate a
security sandbox or general revocation. The plan explicitly excludes both.

Keep the exact wording “one declared plugin subscription”: the host's own
useSyncExternalStore subscription also exists. Successful removal of the
fixture's callbacks does not establish arbitrary renderer cleanup, memory
bounds or leak freedom.

The v3-survival assertion after failed native module import is deliberately
strict. Preserve a failing result if that assumption is false; do not add a
custom accept/fallback mechanism to manufacture a passing native-HMR claim.
Independent-edit spacing narrows watcher behavior and does not qualify bursts.

No rerun was requested by this review. Broader production rollback, persistence,
IME, schema migration and cross-runtime lifetime behavior remain unqualified.
