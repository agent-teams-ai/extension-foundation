# Independent browser recovery v2 input review

Reviewer: library_boundaries_research. Date: 2026-11-22 UTC.
Scope: v2 source delta, preparation plan, local strict-check receipt, dependency identity and retained v1 failure. No browser execution by this reviewer.

**Verdict: ready for scoped hosted execution; no blocker.** This qualifies an explicit supported native recovery attempt. It does not turn v1's failed automatic repair into a pass.

## Preserved first failure

The v1 artifact records one failed test, 31 matching comparisons, and a 15-second wait for useful v4 that never succeeds. Compatible HMR, changed-hook remount, host draft/history/focus and continued real v3 editing/Undo after the failed import all succeeded before that failure. The repair file was written and observed; the client logged hot updated while v3 remained active.

Installed Vite 8.3.8 client source independently confirms three relevant mechanics: a new HMRContext clears existing callbacks, fetchUpdate snapshots qualified callbacks before importing, and hot updated is logged even when that snapshot is empty. This supports the stated recovery explanation with the separately traced wrapper footer. Internal browser callback state was not instrumented or observed directly.

This is a same-module body-evaluation failure before acceptance registration. Do not generalize it to every syntax, transform or dependency-import error.

## v2 boundary review

- The original 31 substantive comparison statements are unchanged.
- The stable probe uses public import.meta.hot.on('vite:afterUpdate') only to record path/timestamp. It adds no accept handler, invalidation callback or React Refresh ownership.
- A v4 top-level record captures actual import.meta.url. Matching its timestamp to afterUpdate associates the transport receipt with that evaluated candidate.
- The immediate still-v3 observation is correctly described as a receipt-time fact. It does not prove absence of later automatic rendering; the retained v1 run supplies the separate 15-second negative evidence.
- Exactly one public server.moduleGraph.getModuleByUrl and server.reloadModule intervention is recorded. No callback-map edits, custom client update queue, looped timing retries or forced DOM replacement.
- After recovery, useful v4 output is required independently of the method return or HMR receipt. The test preserves original textarea/document/draft and focus/selection, then exercises prior Undo/Redo and a fresh user edit through the actual v4 observer/computation.
- Declared subscription accounting is corroborated by actual document/event callback behavior. No broader resource-release or leak-freedom claim follows.

## Input identity

Final browser.test.ts SHA-256:
9f627f1ffaba191ff1bd1f1cd2d1d97b008f7a00f7825951ba11827532d07205

All 16 inputs match evidence/local-check.json, which records strict TypeScript7.0.2 exit0. Package and lock bytes are unchanged from v1. Scope is one test, three sequential phases, 49 comparisons. Hosted execution remains pending.

Author reports frozen v2 archive SHA-256 ccfb6d1e509576712d21aa34156e37264997bf355efc55e97df235667c6d1e8f, 18,520 bytes. This review independently verified the source and check receipt; root owns final archive/workflow custody verification.

## Expected reporting

Keep two outcomes: direct native repair failed in v1; explicit public native recovery is tested in v2. If v2 succeeds, report the supported development-server recovery action and actual retained user behavior. This does not establish production activation, automatic universal rollback, IME, durable state or cross-runtime cleanup.

No further experiment beyond this targeted v2 run is requested.

