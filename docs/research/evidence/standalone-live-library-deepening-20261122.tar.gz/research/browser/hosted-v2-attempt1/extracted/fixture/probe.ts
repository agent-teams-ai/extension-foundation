export interface FeedbackProbe {
  documentId: string;
  trace: string[];
  activeSubscriptions: number;
  subscriptionsCreated: number;
  subscriptionsRemoved: number;
  evaluatedModules: Array<{ version: string; url: string }>;
  hmrUpdates: Array<{ path: string; timestamp: number }>;
}
export const probe: FeedbackProbe = {
  documentId: crypto.randomUUID(), trace: [], activeSubscriptions: 0,
  subscriptionsCreated: 0, subscriptionsRemoved: 0, evaluatedModules: [], hmrUpdates: [],
};
declare global { interface Window { feedbackProbe: FeedbackProbe; } }
window.feedbackProbe = probe;
export interface ReadDraft {
  getSnapshot(): string;
  subscribe(listener: () => void): () => void;
}
export interface CandidateFailure { candidate: string; message: string; }
export const failureEvent = 'research-candidate-failure';

// Public native transport observation only; this does not accept or apply updates.
if (import.meta.hot) {
  import.meta.hot.on('vite:afterUpdate', payload => {
    probe.hmrUpdates.push(...payload.updates.map(update => ({ path: update.path, timestamp: update.timestamp })));
  });
}
