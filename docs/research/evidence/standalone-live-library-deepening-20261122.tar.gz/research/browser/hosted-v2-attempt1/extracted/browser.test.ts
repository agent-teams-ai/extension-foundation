import assert from 'node:assert/strict';
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { test } from 'node:test';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import type { FeedbackProbe } from './fixture/probe.ts';

const directory = path.dirname(fileURLToPath(import.meta.url));
const fixture = path.join(directory, 'fixture');
const evidence = path.join(directory, 'evidence');
type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };
interface Comparison { phase: string; name: string; actual: JsonValue; expected: JsonValue; }
async function snapshot(page: Page) {
  return page.evaluate(() => {
    const draft = document.querySelector('[data-testid="draft"]');
    return {
      documentId: window.feedbackProbe.documentId,
      trace: [...window.feedbackProbe.trace],
      activeSubscriptions: window.feedbackProbe.activeSubscriptions,
      subscriptionsCreated: window.feedbackProbe.subscriptionsCreated,
      subscriptionsRemoved: window.feedbackProbe.subscriptionsRemoved,
      evaluatedModules: [...window.feedbackProbe.evaluatedModules],
      hmrUpdates: [...window.feedbackProbe.hmrUpdates],
      focused: document.activeElement === draft,
      selectionStart: draft instanceof HTMLTextAreaElement ? draft.selectionStart : null,
      selectionEnd: draft instanceof HTMLTextAreaElement ? draft.selectionEnd : null,
      usableVersion: document.querySelector('[data-testid="usable-version"]')?.textContent ?? null,
      projection: document.querySelector('[data-testid="projection"]')?.textContent ?? null,
    };
  });
}
async function edit(variant: string, target: string): Promise<void> {
  await delay(100); // Prior fixture's independent-edit profile, not burst watching.
  await writeFile(target, await readFile(path.join(fixture, variant)));
}
async function ready(page: Page, version: string, projection: string): Promise<void> {
  await page.waitForFunction(({ version, projection }) =>
    document.querySelector('[data-testid="usable-version"]')?.textContent === version &&
    document.querySelector('[data-testid="projection"]')?.textContent === projection &&
    window.feedbackProbe.trace.includes(`plugin:${version}:setup`), { version, projection });
}
async function focusSelection(page: Page, start: number, end: number): Promise<void> {
  await page.getByTestId('draft').evaluate((element, selection) => {
    if (!(element instanceof HTMLTextAreaElement)) throw new Error('Expected actual textarea');
    element.focus(); element.setSelectionRange(selection.start, selection.end);
  }, { start, end });
}

test('native HMR retains host state and explicit public recovery restores useful view across three phases', { timeout: 120_000 }, async () => {
  await mkdir(evidence, { recursive: true });
  const work = await mkdtemp(path.join(directory, '.fixture-run-'));
  await cp(fixture, work, { recursive: true });
  await cp(path.join(fixture, 'Plugin.v1.tsx'), path.join(work, 'Plugin.tsx'));
  let server: ViteDevServer | undefined;
  let browser: Browser | undefined;
  let page: Page | undefined;
  let phase = 'initial';
  const comparisons: Comparison[] = [];
  const observations: Record<string, JsonValue> = { completedPhases: [], successful: false };
  const completedPhases: string[] = [];
  const consoleMessages: string[] = [];
  const pageErrors: string[] = [];
  const watchEvents: Array<{ event: string; file: string; at: number }> = [];
  const compare = (name: string, actual: JsonValue, expected: JsonValue): void => {
    comparisons.push({ phase, name, actual, expected });
    assert.deepEqual(actual, expected, `${phase}: ${name}`);
  };
  try {
    server = await createServer({ configFile: false, root: work, plugins: [react()],
      server: { host: '127.0.0.1', port: 0, strictPort: false, hmr: { overlay: false } }, logLevel: 'info' });
    server.watcher.on('all', (event, file) => {
      if (file === path.join(work, 'Plugin.tsx')) watchEvents.push({ event, file: path.basename(file), at: performance.now() });
    });
    await server.listen();
    const address = server.httpServer?.address();
    assert(address && typeof address !== 'string');
    browser = await chromium.launch({ headless: true });
    observations.browserVersion = browser.version();
    observations.nodeVersion = process.version;
    page = await browser.newPage();
    page.setDefaultTimeout(15_000);
    page.on('console', message => consoleMessages.push(`${message.type()}: ${message.text()}`));
    page.on('pageerror', error => pageErrors.push(error.message));
    await page.goto(`http://127.0.0.1:${address.port}`);
    await ready(page, 'v1', 'v1 · ');
    const original = await snapshot(page);
    const textarea = await page.getByTestId('draft').elementHandle();
    const firstPlugin = await page.getByTestId('plugin').elementHandle();
    assert(textarea && firstPlugin);
    const firstDraft = 'Draft BEFORE update';
    const secondDraft = 'Draft AFTER update';
    await page.getByTestId('draft').fill(firstDraft);
    await ready(page, 'v1', `v1 · ${firstDraft}`);
    await focusSelection(page, 3, 8);

    phase = 'compatible-native-hmr';
    await edit('Plugin.v2.tsx', path.join(work, 'Plugin.tsx'));
    await ready(page, 'v2', `v2 · ${firstDraft.toUpperCase()}`);
    const compatible = await snapshot(page);
    compare('actual host textarea identity retained', await page.getByTestId('draft').evaluate((node, old) => node === old, textarea), true);
    compare('actual plugin identity retained', await page.getByTestId('plugin').evaluate((node, old) => node === old, firstPlugin), true);
    compare('actual document identity retained', compatible.documentId, original.documentId);
    compare('dirty host text retained', await page.getByTestId('draft').inputValue(), firstDraft);
    compare('actual textarea focus retained', compatible.focused, true);
    compare('actual selection start retained', compatible.selectionStart, 3);
    compare('actual selection end retained', compatible.selectionEnd, 8);
    compare('one declared plugin subscription', compatible.activeSubscriptions, 1);
    compare('old cleanup before new setup', compatible.trace.indexOf('plugin:v1:cleanup') >= 0 && compatible.trace.indexOf('plugin:v1:cleanup') < compatible.trace.indexOf('plugin:v2:setup'), true);
    let before = compatible.trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-plugin-event')));
    compare('only current actual event listener responds', (await snapshot(page)).trace.slice(before), ['plugin:v2:event']);
    before = (await snapshot(page)).trace.length;
    await page.getByTestId('undo').click();
    await ready(page, 'v2', 'v2 · ');
    compare('Undo retained across HMR changes actual textarea', await page.getByTestId('draft').inputValue(), '');
    compare('only current document observer receives Undo after HMR', (await snapshot(page)).trace.slice(before), ['plugin:v2:draft']);
    await page.getByTestId('redo').click();
    await ready(page, 'v2', `v2 · ${firstDraft.toUpperCase()}`);
    compare('Redo restores pre-update draft', await page.getByTestId('draft').inputValue(), firstDraft);
    completedPhases.push(phase);

    phase = 'hook-signature-remount';
    const secondPlugin = await page.getByTestId('plugin').elementHandle();
    assert(secondPlugin);
    await focusSelection(page, 4, 9);
    await edit('Plugin.v3.tsx', path.join(work, 'Plugin.tsx'));
    await ready(page, 'v3', `v3 · ${firstDraft.toLowerCase()}`);
    const remounted = await snapshot(page);
    compare('changed hook signature remounts actual plugin', await page.getByTestId('plugin').evaluate((node, old) => node !== old, secondPlugin), true);
    compare('host textarea identity survives plugin remount', await page.getByTestId('draft').evaluate((node, old) => node === old, textarea), true);
    compare('host document survives plugin remount', remounted.documentId, original.documentId);
    compare('host focus survives plugin remount', remounted.focused, true);
    compare('host selection survives plugin remount', [remounted.selectionStart, remounted.selectionEnd], [4, 9]);
    compare('one declared subscription after remount', remounted.activeSubscriptions, 1);
    compare('old cleanup observed before remounted setup', remounted.trace.indexOf('plugin:v2:cleanup') >= 0 && remounted.trace.indexOf('plugin:v2:cleanup') < remounted.trace.indexOf('plugin:v3:setup'), true);
    before = remounted.trace.length;
    await page.getByTestId('draft').fill(secondDraft);
    await ready(page, 'v3', `v3 · ${secondDraft.toLowerCase()}`);
    compare('only current actual document observer receives user edit', (await snapshot(page)).trace.slice(before), ['plugin:v3:draft']);
    await page.getByTestId('undo').click();
    await ready(page, 'v3', `v3 · ${firstDraft.toLowerCase()}`);
    compare('Undo after remount restores preceding user draft', await page.getByTestId('draft').inputValue(), firstDraft);
    await page.getByTestId('redo').click();
    await ready(page, 'v3', `v3 · ${secondDraft.toLowerCase()}`);
    compare('Redo after remount restores latest user draft', await page.getByTestId('draft').inputValue(), secondDraft);
    completedPhases.push(phase);

    phase = 'candidate-rejection-and-recovery';
    const nativeCandidateFailure = Promise.race([
      page.waitForEvent('console', { predicate: message => message.text().includes('intentional candidate initialization failure') }),
      page.waitForEvent('pageerror', { predicate: error => error.message.includes('intentional candidate initialization failure') }),
    ]);
    // The diagnostic is self-reported by the rejecting fixture; a real native
    // import error must independently corroborate it. No custom accept/fallback.
    // Await both concurrently so a missing UI report cannot leave the native
    // error waiter rejected but temporarily unhandled before evidence cleanup.
    await Promise.all([
      nativeCandidateFailure,
      page.waitForFunction(() => document.querySelector('[data-testid="candidate-failure"]')?.textContent?.includes('Candidate bad-v4 failed: intentional candidate initialization failure')),
      edit('Plugin.reject.tsx', path.join(work, 'Plugin.tsx')),
    ]);
    compare('actual candidate evaluation error observed', consoleMessages.some(x => x.includes('intentional candidate initialization failure')) || pageErrors.some(x => x.includes('intentional candidate initialization failure')), true);
    const rejected = await snapshot(page);
    compare('visible usable version remains v3 after rejected import', rejected.usableVersion, 'v3');
    compare('actual useful v3 projection remains', rejected.projection, `v3 · ${secondDraft.toLowerCase()}`);
    compare('failed candidate preserves dirty document', await page.getByTestId('draft').inputValue(), secondDraft);
    compare('failed candidate preserves original document identity', rejected.documentId, original.documentId);
    before = rejected.trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-plugin-event')));
    compare('actual usable listener after rejection remains v3', (await snapshot(page)).trace.slice(before), ['plugin:v3:event']);
    before = (await snapshot(page)).trace.length;
    const afterRejectedEdit = 'Still EDITABLE after rejected candidate';
    await page.getByTestId('draft').fill(afterRejectedEdit);
    await ready(page, 'v3', `v3 · ${afterRejectedEdit.toLowerCase()}`);
    compare('usable v3 recomputes a new actual edit after rejection', (await snapshot(page)).trace.slice(before), ['plugin:v3:draft']);
    await page.getByTestId('undo').click();
    await ready(page, 'v3', `v3 · ${secondDraft.toLowerCase()}`);
    compare('Undo remains useful after rejected candidate', await page.getByTestId('draft').inputValue(), secondDraft);
    observations.afterRejection = rejected;
    await page.screenshot({ path: path.join(evidence, 'rejected-candidate.png'), fullPage: true });
    await edit('Plugin.v4.tsx', path.join(work, 'Plugin.tsx'));
    await page.waitForFunction(() => {
      const evaluated = window.feedbackProbe.evaluatedModules.findLast(item => item.version === 'v4');
      if (!evaluated) return false;
      const timestamp = Number(new URL(evaluated.url).searchParams.get('t'));
      return timestamp > 0 && window.feedbackProbe.hmrUpdates.some(update => update.path === '/Plugin.tsx' && update.timestamp === timestamp);
    });
    const directRepair = await snapshot(page);
    observations.directRepairTransportReceipt = directRepair;
    compare('at correlated repair transport receipt useful view is still v3', directRepair.usableVersion, 'v3');
    compare('at repair receipt dirty host document remains intact', await page.getByTestId('draft').inputValue(), secondDraft);
    // This is one explicit public recovery action, separately recorded from
    // the original direct-repair negative case. No callback-map manipulation.
    await focusSelection(page, 2, 7);
    const module = await server.moduleGraph.getModuleByUrl('/Plugin.tsx');
    assert(module, 'Repaired module must exist in the public Vite module graph');
    observations.recoveryInterventions = [{ method: 'ViteDevServer.reloadModule', module: '/Plugin.tsx', reason: 'repair imported but useful-view acknowledgement absent at correlated receipt' }];
    await server.reloadModule(module);
    await ready(page, 'v4', `v4 · ${secondDraft.length}`);
    const recovered = await snapshot(page);
    compare('explicit public recovery visibly supplies v4 computation', recovered.projection, `v4 · ${secondDraft.length}`);
    compare('explicit recovery retains actual textarea focus', recovered.focused, true);
    compare('explicit recovery retains actual selection range', [recovered.selectionStart, recovered.selectionEnd], [2, 7]);
    compare('explicit recovery retains dirty draft content', await page.getByTestId('draft').inputValue(), secondDraft);
    compare('recovery retains actual host textarea', await page.getByTestId('draft').evaluate((node, old) => node === old, textarea), true);
    compare('recovery retains original document', recovered.documentId, original.documentId);
    compare('recovery has one declared subscription', recovered.activeSubscriptions, 1);
    compare('created minus removed subscription balance', recovered.subscriptionsCreated - recovered.subscriptionsRemoved, 1);
    before = recovered.trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-plugin-event')));
    compare('only repaired actual event listener responds', (await snapshot(page)).trace.slice(before), ['plugin:v4:event']);
    before = (await snapshot(page)).trace.length;
    await page.getByTestId('undo').click();
    await ready(page, 'v4', `v4 · ${firstDraft.length}`);
    compare('explicit recovery retains prior Undo history', await page.getByTestId('draft').inputValue(), firstDraft);
    compare('only v4 observer receives retained-history Undo', (await snapshot(page)).trace.slice(before), ['plugin:v4:draft']);
    await page.getByTestId('redo').click();
    await ready(page, 'v4', `v4 · ${secondDraft.length}`);
    compare('explicit recovery retains prior Redo history', await page.getByTestId('draft').inputValue(), secondDraft);
    before = (await snapshot(page)).trace.length;
    const recoveredEdit = 'Recovered view handles NEW input';
    await page.getByTestId('draft').fill(recoveredEdit);
    await ready(page, 'v4', `v4 · ${recoveredEdit.length}`);
    compare('actual new edit reaches only useful v4 observer', (await snapshot(page)).trace.slice(before), ['plugin:v4:draft']);
    compare('v4 computes new actual user edit', await page.getByTestId('projection').textContent(), `v4 · ${recoveredEdit.length}`);
    await page.getByTestId('undo').click();
    await ready(page, 'v4', `v4 · ${secondDraft.length}`);
    compare('Undo of post-recovery user edit preserves preceding draft', await page.getByTestId('draft').inputValue(), secondDraft);
    compare('no unexpected page errors', pageErrors.filter(x => !x.includes('intentional candidate initialization failure')), []);
    await page.screenshot({ path: path.join(evidence, 'recovered-view.png'), fullPage: true });
    completedPhases.push(phase);
    observations.successful = true;
  } finally {
    observations.completedPhases = completedPhases;
    if (page && !page.isClosed()) {
      observations.final = await snapshot(page).catch((error: unknown) => ({ snapshotError: String(error) }));
      await page.screenshot({ path: path.join(evidence, 'final-page.png'), fullPage: true }).catch(() => undefined);
    }
    const result = { testCount: 1, plannedPhases: 3, comparisons, observations, consoleMessages, pageErrors, watchEvents };
    await writeFile(path.join(evidence, 'observations.json'), JSON.stringify(result, null, 2) + '\n');
    process.stdout.write(`FEEDBACK_BROWSER_RESULT ${JSON.stringify(result)}\n`);
    await writeFile(path.join(evidence, 'fixture-final-source.json'), JSON.stringify({ plugin: await readFile(path.join(work, 'Plugin.tsx'), 'utf8') }, null, 2) + '\n');
    await browser?.close();
    await server?.close();
    await rm(work, { recursive: true, force: true });
  }
});
const checkedShape: keyof FeedbackProbe = 'documentId';
void checkedShape;
