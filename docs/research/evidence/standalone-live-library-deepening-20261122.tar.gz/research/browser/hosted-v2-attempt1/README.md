# Native browser outcome: explicit recovery qualified

**Completed successfully** on 2026-11-22. This is one actual browser test with
three phases and 49 successful comparisons, not 49 tests. No rerun was requested.

- Run: https://github.com/agent-teams-ai/extension-foundation/actions/runs/45034893087
- Attempt: 1; job: 137246337441, terminal success.
- Exact commit: 0e0bfb1b6468df90391134f4731e3e3df52479d2.
- Workflow: .github/workflows/standalone-live-library-spikes.yml; SHA-256
  0e84dcad9719bbc3d15b98cd1cba748788916eab907cfa996be675d061491507.
- Frozen v2 input SHA-256:
  ccfb6d1e509576712d21aa34156e37264997bf355efc55e97df235667c6d1e8f.
- Artifact: 14759765045, 101058 bytes; SHA-256
  ecef2ef8fa8a779a29383fbf6e0f94b9d26adbb17444d66e64b575df27e7afba.
- Runtime: Chromium 159.0.8154.6; Node 24.22.3; strict TypeScript 7.0.2.

## Actual behavior

| Phase | Successful comparisons | Observed result |
| --- | ---: | --- |
| Compatible native HMR | 13 | v2 computation changed while original textarea/document/draft/focus/selection and working Undo/Redo survived; exact old observers/listeners were removed |
| Hook-signature remount | 10 | Plugin DOM remounted; host textarea/document/draft/focus/selection and history survived; only current observer handled new user input |
| Rejection and explicit recovery | 26 | Throwing candidate produced a native import error; v3 still handled new edits and Undo; one explicit public reloadModule then produced useful v4 with state and current subscriptions intact |

Repair module evaluation at timestamp 1795359000130 matched the public native
vite:afterUpdate receipt while useful UI remained v3. That is an observation at
the receipt, not a general timing claim. The separately preserved first run
45033310718 supplies the stronger 15-second direct-repair failure evidence.

The harness then made exactly one explicit ViteDevServer.reloadModule request.
The subsequent module evaluation/update timestamp was 1795359000149; real v3
cleanup and v4 setup followed. Actual v4 output, a new user edit, retained prior
Undo/Redo, original document/textarea, and focus/range at the recovery boundary
were asserted independently. Later intentional button clicks naturally moved
focus; the final screenshot is not the focus-preservation oracle.

Final declared plugin subscription balance was 4 created minus 3 removed = 1.
This count describes the plugin's subscriptions; it does not include the host's
useSyncExternalStore subscription or prove absence of arbitrary resource leaks.
Behavioral assertions also checked real observer callbacks and DOM event handling.
Only the expected intentional initialization failure appeared; no page errors.

## Custody and independent verification

Root downloaded the artifact independently, matched its bytes/digest, verified
all 16 frozen source files, workflow/input receipt and actual results, and
visually inspected recovered-view.png. See root-validation.json and extracted/.
The monitoring lane independently fetched terminal run/job metadata, parsed the
native result from the complete job log and matched the workflow source hash.
The result is also available as native-result-from-job-log.json.

The original v1 input/failure and the explicit-recovery v2 input/success remain
separate. Neither frozen input was edited after its run. No custom accept handler,
HMR callback-map mutation, hidden automatic retry or replacement HMR runtime was
introduced. Local typecheck receipts and discovery records are historical
pre-execution/in-progress snapshots; run-terminal.json is the current outcome.

Scope: development HMR on this exact toolchain and browser. This does not qualify
production deployment switching, IME/composition, durable restoration, multiuser
networking, arbitrary schema migration, sandboxing, raw-reference revocation,
resource leak freedom or automatic recovery from every module failure.
