import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/Plugin.reject.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { failureEvent } from "/probe.ts";
var _jsxFileName = "/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.reject.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/@fs/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=29792e0d";
function rejectCandidate() {
	const message = "intentional candidate initialization failure";
	window.dispatchEvent(new CustomEvent(failureEvent, { detail: {
		candidate: "bad-v4",
		message
	} }));
	throw new Error(message);
}
rejectCandidate();
export function Plugin({ draft }) {
	return /* @__PURE__ */ _jsxDEV("output", { children: draft.getSnapshot() }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 10
	}, this);
}
_c = Plugin;
var _c;
$RefreshReg$(_c, "Plugin");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/Plugin.reject.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.reject.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.reject.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.reject.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }
