import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/Plugin.v4.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useMemo = __vite__cjsImport0_react["useMemo"];import __vite__cjsImport0_react from "/@fs/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/node_modules/.vite/deps/react.js?v=469527fb";
import { probe } from "/probe.ts";
var _jsxFileName = "/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.v4.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/@fs/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=29792e0d";
var _s = $RefreshSig$();
export function Plugin({ draft }) {
	_s();
	const [value, setValue] = useState(() => draft.getSnapshot());
	const extra = useMemo(() => "remount-boundary", []);
	useEffect(() => {
		probe.trace.push("plugin:v4:setup");
		probe.activeSubscriptions++;
		probe.subscriptionsCreated++;
		const onDraft = () => {
			probe.trace.push("plugin:v4:draft");
			setValue(draft.getSnapshot());
		};
		const unsubscribe = draft.subscribe(onDraft);
		setValue(draft.getSnapshot());
		const event = () => {
			probe.trace.push("plugin:v4:event");
		};
		window.addEventListener("research-plugin-event", event);
		return () => {
			unsubscribe();
			window.removeEventListener("research-plugin-event", event);
			probe.activeSubscriptions--;
			probe.subscriptionsRemoved++;
			probe.trace.push("plugin:v4:cleanup");
		};
	}, [draft]);
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-testid": "plugin",
		"data-boundary": extra,
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			"data-testid": "usable-version",
			children: "v4"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 5
		}, this), /* @__PURE__ */ _jsxDEV("output", {
			"data-testid": "projection",
			children: "v4 · " + String(value.length)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 5
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 10
	}, this);
}
_s(Plugin, "Ws4ittYLXTkdAJFVK+0DfMMhDAo=");
_c = Plugin;
var _c;
$RefreshReg$(_c, "Plugin");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/Plugin.v4.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.v4.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.v4.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/scratch/95e187720be1/live-library-research-20261122/browser/probe/fixture/Plugin.v4.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }
