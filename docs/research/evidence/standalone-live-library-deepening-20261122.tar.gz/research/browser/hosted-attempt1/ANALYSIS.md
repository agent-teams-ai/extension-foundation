# First native browser attempt: preserved failure and recovery hypothesis

Run 45033310718, attempt 1; job 137241448742; exact commit
bbff6146693fdf6eca320efbb6b67a6ef7a6be1d. Workflow
.github/workflows/standalone-live-library-spikes.yml. Overall result: **failure**.
Hosted input verification, exact installation, strict TypeScript and Chromium
installation passed. Runtime: Node 24.22.3, Chromium 159.0.8154.6.

The single test completed two phases and recorded 31 successful comparisons.
Those include real dirty Y.Doc draft and Undo/Redo survival, actual textarea
identity/focus/selection through compatible HMR and plugin remount, old observer
and listener removal, an actual rejected-module error, and still-useful v3
processing a new user edit plus Undo after the rejected import.

The failure was the next step: browser.test.ts waited 15 seconds for repaired v4
output/setup, but useful UI remained v3. Four real file-change events were
recorded. The client logged hot updated for the repaired path. Final trace had
one declared plugin subscription, three creations/two removals, and no v4 setup.
This is not a watcher event omitted by the 50 ms same-path suppression window.
No custom fallback was installed and no runtime rerun occurred during diagnosis.

Artifact 14758428722 has size 76884 and SHA-256
 d0818be500ebf20631e69c6bac5ca934c1c1a1d15ecce2ee41976657f4a7af6d.
The native job result and terminal metadata are retained in this directory;
root independently downloaded/preserved the full artifact before a new input.

## Source-backed mechanism

- Vite 8.3.8: commit b39e6e63dcbfc3cf4be871acf3554efbd6d0e268,
  packages/vite/src/shared/hmr.ts, blob
  6e2ef7de0de852aec6417e9d91b60556cc2f834b. HMRContext clears existing callbacks.
  fetchUpdate captures qualified callbacks before importing the updated module;
  a self-update still imports with no callbacks; its completion logs hot updated.
- @vitejs/plugin-react 6.3.0 delegates wrapping through vite/internal to the
  installed Rolldown 1.2.19 implementation.
- Rolldown commit b9c75ddc8bd50f2c1a4c7be0b548bdab5cba85ab,
  crates/rolldown_plugin_vite_react_refresh_wrapper/src/lib.rs, blob
  620ef40166bb4705c97b1fc93fbf2722cc23768d, appends accept registration in a
  microtask after the module body. A body that throws never reaches that footer.
- A separate local native transform inspection, without browser execution or
  evaluating the transformed module, confirms context creation precedes our
  throwing body and acceptance follows it. Transformed outputs are retained.

The evidence supports a registration gap: failed evaluation removes old callback
registration without installing replacement acceptance. The repair can reinstall
acceptance while its own update has already captured an empty callback list.
This is source-based causal inference consistent with the browser trace; the
private runtime callback map was not inspected or mutated.

Primary sources:
https://github.com/vitejs/vite/blob/b39e6e63dcbfc3cf4be871acf3554efbd6d0e268/packages/vite/src/shared/hmr.ts
https://github.com/rolldown/rolldown/blob/b9c75ddc8bd50f2c1a4c7be0b548bdab5cba85ab/crates/rolldown_plugin_vite_react_refresh_wrapper/src/lib.rs
https://github.com/vitejs/vite-plugin-react/blob/0e95069a8f90489da74371c9ad35dfc619c1b72e/packages/plugin-react/src/index.ts

## Separate v2 qualification, not a relabelled automatic repair

The public ViteDevServer.reloadModule API is documented to trigger HMR using a
module-graph node: https://vite.dev/guide/api-javascript#vitedevserver . The separate
v2 input observed actual repaired-module evaluation and a matching public
vite:afterUpdate receipt, then requested reloadModule exactly once. Hosted run
45034893087 attempt 1 succeeded with one test, three phases and 49 comparisons,
including useful v4, retained draft/history/textarea/focus/range, real current
observers and a new user edit. See ../hosted-v2-attempt1/README.md.

An API return or transport receipt remains distinct from useful-view
acknowledgement. The original direct-repair negative result stands; the follow-up
qualifies an explicit public recovery intervention on this exact toolchain,
not automatic recovery or a production update protocol.
