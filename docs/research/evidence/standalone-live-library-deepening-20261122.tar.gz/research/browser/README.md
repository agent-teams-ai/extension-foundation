# Native live-feedback browser research: completed

Two immutable inputs and two distinct hosted outcomes are preserved.

| Input | Hosted outcome | What it establishes |
| --- | --- | --- |
| Original input | Run 45033310718, attempt 1: failed after 31 successful comparisons | Actual draft/history/focus/cleanup and rejected-candidate continuity worked; direct repaired-v4 usefulness timed out after 15 seconds despite a native hot-updated log |
| Recovery v2 | Run 45034893087, attempt 1: success; one test, three phases, 49 comparisons | One explicit public ViteDevServer.reloadModule restored useful v4 while host draft/history/textarea/focus/range and actual current observers survived |

The complete successful outcome is in
[hosted-v2-attempt1/README.md](hosted-v2-attempt1/README.md); first failure and
source-identified cause are in
[hosted-attempt1/ANALYSIS.md](hosted-attempt1/ANALYSIS.md).

Package/lockfile and exact versions are identical between the inputs:
Node 24.22.3, pnpm 11.25.0, TypeScript 7.0.2, React/React DOM 19.3.1,
Vite 8.3.8, plugin-react 6.3.0, Playwright 1.65.1, Yjs 13.6.33.
Local and hosted strict checking included every variant with skipLibCheck false.

Both archives/manifests bind their exact 16 files. Frozen plans and local-check
receipts intentionally retain their pre-execution wording. The original failed
input is not silently repaired or relabelled; v2 clearly records the separate
public recovery intervention. No workflow reruns were requested.

The plugin receives only string reads and subscribe/unsubscribe functions.
The host owns the real Y.Doc and UndoManager. This trusted-code API separation
is not a security sandbox: code able to import hostActions by path is not
revoked merely by a TypeScript interface. Plugin subscription counters exclude
the host subscription; real listener and user-edit behavior were tested too.

The rejected candidate's own diagnostic is independently corroborated by its
native import error. Vite's overlay is disabled so the retained view and host
status can be inspected. Failure history remains visible after recovery.
No production-switching, IME, durability, network provider, schema migration,
universal rollback, revocation or resource-leak guarantee follows.

Keep archives, manifests, plans, logs, terminal receipts, reviews and actual
artifacts. Exclude base/ and node_modules from delivered research packets.
