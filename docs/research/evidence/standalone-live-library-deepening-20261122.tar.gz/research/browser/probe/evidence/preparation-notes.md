# Preparation record

No local browser run was attempted. The first dependency-install shell command
was issued from the parent scratch directory; output redirection to a nonexistent
evidence/ path failed before pnpm executed. It was rerun from the probe directory.
Frozen install then succeeded. First strict check passed; subsequent strict
checks correspond to review-driven assertion and Promise-wait refinements.
No compile or browser behavior assertion was weakened. The final check uses an
actual subprocess return code and hashes the checked source in local-check.json.
