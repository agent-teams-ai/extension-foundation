# Browser v2: completed explicit native recovery

Run 45034893087 attempt 1 succeeded on exact commit
0e0bfb1b6468df90391134f4731e3e3df52479d2: **one test, three phases,
49 successful comparisons, one explicit ViteDevServer.reloadModule request**.
Strict TypeScript 7.0.2 and all hosted gates passed. No rerun was requested.

See [hosted-v2-attempt1/README.md](hosted-v2-attempt1/README.md) for full native
observations, artifact identity, independent verification and scope. The
unchanged first input and failed run 45033310718 remain separate evidence.

v2 correlated real repaired-module evaluation with native afterUpdate receipt,
then separately observed useful v4 after the public recovery API. Original
textarea/document/draft/focus/range, previous Undo/Redo and new actual user input
were verified. It uses no custom acceptance, callback registry mutation,
replacement HMR implementation or automatic retry. Exact package/lockfile is
unchanged from v1. Frozen input plans and pre-execution receipts are historical;
the terminal outcome is recorded under hosted-v2-attempt1.
