# Notices for the deeper 2026-11-22 investigation

The original notice bundle, its manifest and provenance remain unchanged. The
following additions cover the new retained materials; the final outer packet
manifest will bind both sets.

[editor-deepening-provenance.json](editor-deepening-provenance.json) records exact
installed-package notice bytes for all 13 runtime packages reachable from the
four direct CodeMirror dependencies: state, view, lint, commands, language,
streamparser, @lezer/common, @lezer/highlight, @lezer/lr,
@marijn/find-cluster-break, crelt, style-mod and w3c-keyname. Each notice is MIT and
copied verbatim from the version resolved by the frozen editor lock. These
notices accompany the published source snapshots and nested diagnostic traces.
No node_modules directory is copied.

The existing Vite 8.3.8 and Rolldown 1.2.19 notices remain applicable to the exact
browser transform toolchain and its diagnostic output. The earlier plugin-react
notice remains for the prior browser profile; it is not a new editor dependency.

[executor-deepening-provenance.json](executor-deepening-provenance.json) records
exact notice files extracted from retained published Resources 0.2.2 (Apache-2.0),
Comlink 4.4.2 (Apache-2.0) and Piscina 5.3.2 (MIT) archives. These three archives are
source/provenance evidence. Their inclusion selects no new production dependency;
only Resources participates in the new native Worker fixture.

Unlicensed copies of the root lane's Argo/OpenFeature raw dumps and a GitLab
documentation dump are deliberately omitted. Their findings, source references,
immutable source identities and receipt hashes remain in the reports/ledgers.
No upstream code is silently relicensed by this research project.
