# Notices retained for the standalone research transfer

Prepared 2026-11-22. These are exact upstream source/package notice files, kept
outside frozen research snapshots. `provenance.json` records source identities,
published archive integrity, local byte counts and SHA256 hashes. No dependency
was installed or executed to collect these notices.

| Notice | Reason / retained material |
| --- | --- |
| `get-modular-LICENSE` | Apache-2.0 notice for the retained Get Modular source snapshots `boundaries/source/G1.md` through `G10.json` (the exact ten paths are in that lane's provenance), at `33c032f829028967825428bc6b049ed6db1c56b2` |
| `extension-foundation-LICENSE` | Apache-2.0 notice for the retained prior Extension Foundation source `boundaries/source/P1.md`, at `f727a488243e8de47bbffb7cf36e01850f79d899` |
| `vite-8.3.8-LICENSE.md` | Complete published Vite notice, including bundled third-party notices; retained with diagnostic transform output from the pinned Vite toolchain |
| `vitejs-plugin-react-6.3.0-LICENSE` | Published plugin-react notice; diagnostic transformed-module dumps include its generated React Refresh instrumentation |
| `rolldown-1.2.19-LICENSE` and `rolldown-1.2.19-THIRD-PARTY-LICENSE` | Published Rolldown notices for the exact transform dependency resolved by the frozen browser lock |

Get Modular and Extension Foundation root `NOTICE` requests returned GitHub API
404 at those exact revisions. The responses are recorded in
`github-fetch-receipts.json`; no separate NOTICE was invented. These observations
concern those paths/revisions and do not assert absence throughout either tree.

The package archives were fetched from their exact public registry coordinates,
their SHA512 integrity matched the frozen `browser/probe/pnpm-lock.yaml`, and
their SHA1 matched registry metadata. License files were read directly from
those archives. The full archives were not added to the payload. Upstream Git
license bytes were verified against their exact Git blob identities; any extra
terminal newline added by tool transport was removed only to restore that byte
identity, as recorded in provenance.

Keep `boundaries/licenses/effect-MIT-LICENSE`,
`boundaries/licenses/xstate-MIT-LICENSE`, their mapping and source provenance in
the final kit too. The final assembler may place this directory under
`THIRD-PARTY-NOTICES/`; the reason paths above refer to the research lane names,
not runtime imports.

This notice bundle selects no license for the new project's original research,
does not relicense the organizational standard, and does not claim a public
package release. The seed remains a private research project. Generated
transform dumps are diagnostic evidence, not runnable modules for consumers.
