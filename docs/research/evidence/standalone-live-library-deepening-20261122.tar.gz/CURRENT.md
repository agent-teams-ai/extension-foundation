# Current evidence — deeper qualification, 2026-11-22

This is an assembled research project, not a released library or production
adoption. Original failed attempts remain failures; corrected inputs have new
identities. See the [case-by-case audit](research/deepening/COVERAGE-AUDIT.md).

## New native evidence

| Profile | Observed result | Receipt |
| --- | --- | --- |
| Backend v2, run 45043862207 | **17/17 passed; 0 skipped** | [Original artifact](research/deepening/hosted/backend-v2-attempt1/artifact.zip), [runtime log](research/deepening/hosted/backend-v2-attempt1/extracted/evidence/hosted-runtime.log), [independent review](research/deepening/execution/evidence/backend-v2-result-review.md) |
| Backend v1, run 45042722876 | **16/17 passed; suite failed** at S13's first SQLSTATE expectation | [Original artifact](research/deepening/hosted/backend-v1-attempt1/artifact.zip), [runtime log](research/deepening/hosted/backend-v1-attempt1/extracted/evidence/hosted-runtime.log) |
| Independent local Worker run | 3/3 passed on the same frozen backend source | [Local receipts](research/deepening/execution/evidence/local-worker-attempt1/execution-results.json) |
| Editor v1, run 45042075044 | One test failed after CM-1/CM-2; 27/28 executed comparisons matched | [Original failure](research/deepening/hosted/editor-v1-attempt1/extracted/evidence/result.json) |
| Editor v2, run 45042722838 | **One browser test passed; all seven scenarios, 70/70 comparisons; no page/cleanup errors** | [Result](research/deepening/hosted/editor-v2-attempt1/extracted/evidence/result.json), [original artifact](research/deepening/hosted/editor-v2-attempt1/artifact.zip) |

Backend v2 ran at `9b33571e1586cc6801629a98b94fa1bc391c98cb`; backend v1 and
editor v2 ran at `719a6095445d67b1da7fa285bbb5ef8ecc589322`. Returned frozen inputs
were checked against their per-file manifests. The new profiles use strict TypeScript 7.0.2
and Node 24.22.3; the browser was Chromium 159.0.8154.6, and PostgreSQL was the
digest-pinned 18.7 profile.

The local Worker result is an earlier execution of three cases included in the
17-case hosted backend, not three additional distinct tests. Joint E02 and state
S09 are one case. The earlier browser49 evidence remains independent historical
coverage and is not part of the new 70 comparisons.

## What the observations establish

- Real A code/dependency work completed on A while B was selected for new work.
  Parent-owned host effects survived guest exit; the guarded database receiver
  rejected A's old epoch, while an intentionally unsafe receiver accepted it.
- Abandoning a close waiter did not stop a Worker. Failed cleanup left a
  responsive Worker and observable debt; the public Resources retry then stopped
  it. A serial two-live-worker policy freed capacity only after native exit.
- PostgreSQL cases exercised publication contention, exact replay, stale
  identity/epoch rejection, lost application reply, uncommitted controller crash,
  row-lock strength, retained baseline, statement-snapshot visibility and both
  hold/deletion orders for canonical artifact references.
- Native CodeMirror replacement preserved draft/history where supported. The
  same-document late lint source replaced a newer result in a negative control;
  the native changed-document guard worked, and the explicit contribution/
  revision gate rejected the predecessor. Clearing history remained separate
  from resetting draft. JSON history restored text Undo but not custom inverse
  effects, despite the custom field value being serialized correctly.

S13 v1 expected foreign-key SQLSTATE 23503 for an explicit ON DELETE RESTRICT
violation; PostgreSQL returned the more specific 23001. The forbidden deletion
was rejected, but the later interleaving and final no-dangling check were not
reached. V2 changes only that first expectation and passes both native wait
orders, the unchanged reverse insertion assertion and final zero-dangling
reference check. The emitted count is a reporting constant after the SQL
assertion, not a serialized raw row. See the reviews of
[v1](research/deepening/execution/evidence/backend-v1-result-review.md) and
[v2](research/deepening/execution/evidence/backend-v2-result-review.md).

Editor v1 incorrectly expected no lint-panel DOM row when the native component
rendered its normal `No diagnostics` placeholder. Editor v2 changed only that
expectation; the native diagnostic-state assertion was retained. Six other
source/configuration files remained identical.

## Scope still open

No production coordinator or public artifact consumer has been delivered. The
private lifecycle-kernel publication gap remains explicit. Existing full FMS
source and the unchanged seed do not claim a qualified production bootstrap;
the recorded Foundation/embedded-compiler cohort conflict remains historical
bootstrap work until separately resolved.

Not qualified here: arbitrary module graphs or plugin code, concurrent capacity
reservation, general graceful guest finalizers, native Effect/Wasm adapters,
server failover or wire COMMIT ambiguity, concurrent schema cutover, external
network effect rollback, physical object-store deletion, measured memory bounds,
persisted semantic Undo restoration, real OS IME and fleet-wide atomic rollout.

No new remote has been provisioned. Final packet publication is separate from
the exact source commits that produced the native evidence.
