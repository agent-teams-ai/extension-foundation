# Managed live plugin updates — portable research project

This project carries the earlier standalone research packet forward with the
deeper 2026-11-22 investigation: durable publication, real executor/resource
lifetimes, dependency cohorts, editor continuity and observable update policy.
The working name is provisional. **There is no released production library,
accepted public API or newly provisioned remote repository in this packet.**

Start with [CURRENT.md](CURRENT.md), then the
[architecture blueprint](docs/architecture/live-library-blueprint.md) and the
[new coverage audit](research/deepening/COVERAGE-AUDIT.md). The intended library
provides the complete useful update operation. Consumers supply narrow
authorization/state primitives and choose supported execution adapters. Ordinary
TypeScript is the first profile; native Effect and Wasm/Extism remain distinct
optional profiles with their own native lifetime/ABI guarantees.

| Topic | Entry point |
| --- | --- |
| Current results and unqualified boundaries | [Current evidence](CURRENT.md) |
| New industry synthesis | [Reliability study reading copy](research/deepening/synthesis/live-update-reliability-and-industry-evidence-2026-11-22.md) |
| Publication, fencing, recovery, state compatibility | [State report](research/deepening/state/REPORT.md) |
| Execution, resource debt, dependency cohorts | [Execution report](research/deepening/execution/REPORT.md) |
| User-visible contribution, history and stale results | [Experience report](research/deepening/experience/REPORT.md) |
| Control policy and evidence semantics | [Control report](research/deepening/control/REPORT.md) |
| Distinct native cases and failed attempts | [Coverage audit](research/deepening/COVERAGE-AUDIT.md) |
| Source/input and copy provenance | [Deepening provenance](research/deepening/PROVENANCE.json) |
| Architecture/bootstrap rules | [Bootstrap](docs/architecture/repository-bootstrap.md), [AGENTS.md](AGENTS.md) |
| Original packet's completed results | [Prior current evidence](research/deepening/historical-baseline.md) |
| Upstream license notices | [Original notices](THIRD-PARTY-NOTICES/README.md), [new retained materials](THIRD-PARTY-NOTICES/DEEPENING.md) |

The new backend is **one private probe package** with one exact dependency lock.
Its 17 distinct cases are 12 database cases, three Worker/Resources cases and two
joint Worker/database cases. The new editor profile is **one browser test with
seven scenarios**. Local repeats, corrected inputs and the earlier 49-comparison
React/Vite experiment do not increase those counts.

Frozen v1 inputs and their original failed receipts stay intact. Corrected
inputs get separate identities. Reading copies can contain earlier “pending”
statements; CURRENT.md and the raw terminal receipts determine the observed
outcome. None of these probes qualifies an arbitrary plugin graph, a production
coordinator, distributed failover, real OS IME or all possible state migration.

The original 11-file seed and complete FMS v1.1 source are unchanged under
`bootstrap/seed-base`. The previous packet's outer manifests/entrypoints are
retained under `provenance/prior-root`; all other original files are preserved.
The current repository document and final lane reading copies originate at
`711c9ee1467bd82e669494d3584efcbb39fceda4`; versioned inputs, workflow sources and
native artifacts retain their own origins in the provenance ledger. The prior
packet originates at `e9277b1c902aeb29a4132b5d5b7e20b908be6c2c`. Relative links in
the new repository document reading copy resolve to its immutable origin.

Probe packages remain separate. No node_modules, active workflow installation,
Git working copy, transient signed download URLs or empty production scaffolding
is shipped. Workflow files are inert evidence under research. Exact notices are
included for retained upstream package sources and diagnostic trace content.

The corrected native profiles passed: backend **17/17**, and one editor test
with **7 scenarios / 70 matching comparisons**. The original failed profiles
remain retained. [MANIFEST.json](MANIFEST.json) hashes every payload file except
itself. The later archive-bearing commit is a descendant of the stated source
origin; archive bytes and hash are recorded externally to avoid self-reference.
