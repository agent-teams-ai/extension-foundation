# Managed live plugin updates — standalone research project

This transferable project preserves the completed 2026-11-22 investigation and
native probes for a reusable live-update library. Its name is provisional; no
production package or remote repository is claimed.

Start with [CURRENT.md](CURRENT.md) for actual results and limits, then the
[complete architecture blueprint](docs/architecture/live-library-blueprint.md).
The library should deliver usable planning, replacement and observation;
applications supply narrow authority/state primitives and select real adapters.
Ordinary TypeScript is the first profile, with optional native Effect/Wasm
profiles only where concrete consumers justify them.

| Area | Entry point |
| --- | --- |
| Architecture and integration boundary | [Blueprint](docs/architecture/live-library-blueprint.md) |
| Version retention, old work and state | [Version report](research/versions/REPORT.md) |
| User feedback, draft and history | [Feedback report](research/feedback/REPORT.md) |
| Reuse, modules and native execution profiles | [Boundary report](research/boundaries/REPORT.md) |
| Actual browser recovery | [Native result](research/browser/hosted-v2-attempt1/README.md) |
| Bootstrap and current tooling conflict | [Recipe](docs/architecture/repository-bootstrap.md) |
| Independent reviews | [Browser result review](research/reviews/browser-v2-result-by-boundaries.md) |
| Working rules | [AGENTS.md](AGENTS.md) |
| Upstream notices and source identities | [Notices](THIRD-PARTY-NOTICES/README.md) |

Each probe is an isolated private project with its own exact lockfile, strict
TypeScript configuration, pre-execution plan and receipts. Do not flatten their
dependency graphs into a new root workspace. No node_modules, credentials,
active hosted workflows, empty production packages or invented admission are
included. The two hosted workflow sources are inert research evidence.

The complete original seed remains under bootstrap/seed-base with its unchanged
manifest. The outer MANIFEST.json identifies this assembled project. Historical
plans/local prechecks remain historical; CURRENT.md and terminal run receipts
state the actual completed outcome.
