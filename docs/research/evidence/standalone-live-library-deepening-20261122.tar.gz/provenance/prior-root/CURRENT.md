# Current evidence — 2026-11-22

## Executed and independently checked

| Experiment | Actual outcome | Evidence |
| --- | --- | --- |
| Native Node async context | 5 tests passed; strict TS7.0.2 passed | [Result](research/versions/probe/results.json), [source](research/versions/probe/async-context.test.ts) |
| Native Yjs state/history | 7 tests passed; strict TS7.0.2 passed | [Result](research/feedback/probe/evidence/results.json), [source](research/feedback/probe/state-continuity.test.ts) |
| Browser original automatic repair | 1 failed test after31 matching comparisons; repaired v4 was not useful within15s | [Analysis](research/browser/hosted-attempt1/ANALYSIS.md), [original artifact](research/browser/hosted-attempt1/artifact.zip) |
| Browser explicit recovery v2 | 1 passed test,3 phases,49/49 comparisons,0 skips; exactly1 public reloadModule | [Outcome](research/browser/hosted-v2-attempt1/README.md), [independent review](research/reviews/browser-v2-result-by-boundaries.md) |

The browser passed on Chromium159.0.8154.6, Node24.22.3 and strict TypeScript7.0.2.
Its exact source was0e0bfb1b6468df90391134f4731e3e3df52479d2, run45034893087,
attempt1. The input, workflow, original artifact, all16 input files and28 output
files are independently hash-verified. Compatible HMR, hook-signature remount,
continued editing after candidate failure, retained draft/Undo/Redo/focus/range
and actual useful v4 after one explicit recovery are covered. Actual new user
input after recovery was computed by v4; old callbacks did not receive the
observed events. This does not prove general resource leak freedom.

## What this changes in the architecture

A loading/transport receipt is insufficient for useful activation. Preserve the
previous useful view during a supported rejected update; expose explicit
recovery with its own result and state/history consequences. Repeated module
evaluation needs an effect-safety contract. Keep document, history and view
lifetimes separate, and track retained old work/resources/history independently
from the version selected for new work.

The portable library must provide the useful replacement operation. An external
consumer should not rebuild its state machine or cleanup orchestration to
integrate it. Reuse current graph/resource/runtime owners through real public
adapters; resolve the private lifecycle-kernel/publication gap explicitly.
The [85-record source ledger](research/synthesis/standalone-live-library-20261122.sources.json)
and [findings register](research/synthesis/standalone-live-library-20261122.findings.json)
retain source inspection, observations, recommendations and uncertainty separately.

## Remaining scope

This is research qualification, not production adoption. A real application
slice plus an independently installed packed-artifact consumer still must prove
the public boundary. IME, other module-error classes, production switching,
network/durable state, schema migration, crash recovery and memory budgets are
not covered by this browser fixture. No other native runs are needed to restate
its bounded result.

The new remote repository has not been created: available authenticated tools
write the existing repository but expose no creation operation; browser creation
requires sign-in. This project is ready to transfer. The original source and all
research checkpoints are already pushed to extension-foundation PR55.

Production bootstrap also has a concrete tooling conflict: the current
RECOMMENDED Docs cohort pins Foundation1.7.2, whose eager CLI dependency chain
reaches embedded TypeScript5.9.3; the baseline requires7.0.2+. Published newer
packages do not themselves update the qualified cohort. The bootstrap recipe
records the compatible-transition work. No blocked Foundation CLI was executed
locally and no dependency override or admission claim was introduced.
