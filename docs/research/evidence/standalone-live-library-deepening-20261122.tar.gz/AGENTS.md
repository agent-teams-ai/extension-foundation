# Agent instructions

This repository seed owns research toward a portable managed live-plugin-update
library. Read README.md, docs/architecture/proposal.md and the bootstrap recipe
before proposing production code. The architecture is a proposal; no production
runtime or universal plugin interface has been adopted.

## Authorities

Before planning, implementing or reviewing maintained code, read the canonical
[Engineering Quality Standard](https://github.com/agent-teams-ai/.github/blob/main/docs/engineering-quality-standard.md),
including its TypeScript and portable-tooling requirements, and the
[development tools catalog](https://github.com/agent-teams-ai/.github/blob/main/docs/development-tools.md).
New production bootstrap follows
[repository admission](https://github.com/agent-teams-ai/.github/blob/main/docs/repository-admission.md#new-repository-bootstrap).

The complete FMS v1.1 source is retained under docs/architecture/source with its
exact canonical identity and digest. Do not edit that snapshot, present it as a
second authority, invent an adopted profile or substitute a summary for full
adoption. Record actual module roles, source coverage and accepted decisions in
the future repository-owned profile when production bootstrap is reviewed.

## Working constraints

- Preserve findings, sources, failures and explicit uncertainty. Commit useful
  checkpoints and push each commit immediately when an authorized remote is
  available. Never claim a push or hosted result that was not observed.
- Reuse appropriate existing mechanisms. Before adding a loader, graph,
  supervisor, state store or lifetime manager, name its current owner and the
  demonstrated missing capability.
- Keep ordinary external consumers free of organization credentials, product
  models and mandatory governance/runtime frameworks. Development tools remain
  development-only; optional adapters carry their own dependencies.
- New maintained JavaScript-runtime logic is TypeScript with an effective strict
  TypeScript 7.0.2-or-newer project, including tests and tooling. Inspect embedded
  compiler versions before execution. Do not run an older compiler or weaken
  checks to obtain success.
- Native probes are isolated private projects with exact lockfiles and bounded
  claims. Retain their executed inputs, expected outcomes and failed attempts.
  Do not relabel a source inspection as execution or a local pass as admission.
- Keep existing owners of routing, durable state, effects and resource lifetime.
  Context propagation, Undo metadata and observer removal are not revocation.
- No empty production packages, ceremonial layers, speculative public exports
  or invented accepted ADRs. Materialize a module with its first real feature.

The seed has no installed managed Docs authoring route. Follow the verified
bootstrap transition before adding one; do not copy another repository's
managed projection or call its blocked Foundation CLI.
