# Managed live plugin updates — research seed

This is an exportable **private research seed**, prepared on 2026-11-22. The
project name is provisional. It contains architecture proposals, immutable
source evidence and isolated qualification probes; it has no production
package, public exports or claim of repository admission.

The intended library supports controlled live updates with explicit operation,
state and cleanup boundaries. Ordinary TypeScript is the first profile under
investigation. Extism/Wasm remains an optional adapter direction. Existing host
composition, resource ownership, durable state and deployment authorities remain
authoritative.

## Start here

- [Architecture proposal](docs/architecture/proposal.md)
- [Bootstrap and transfer recipe](docs/architecture/repository-bootstrap.md)
- [Pinned bill of materials](docs/architecture/repository-bootstrap.bom.json)
- [Complete immutable FMS v1.1 snapshot](docs/architecture/source/feature-module-standard-v1.1.md)
  and [provenance](docs/architecture/source/provenance.json)
- [Research and probe navigation](research/README.md)
- [Local agent instructions](AGENTS.md)

The FMS snapshot is an unchanged reference copy of the canonical organization
standard. It is not a local replacement standard or an adopted profile. Future
production adoption must name the full standard, real owned features and gates.

## Current qualification boundary

The research packet's individual receipts name exactly what ran. A passing
native experiment does not qualify a production library, a public API or remote
required checks. Unexecuted scenarios remain explicitly pending.

At the pinned organization revision, the RECOMMENDED Docs cohort requires
Foundation 1.7.2, whose eager CLI dependency chain reaches TypeScript 5.9.3.
The current engineering baseline requires TypeScript 7.0.2 or newer, including
embedded compilers. Published Foundation 3.0.0 and FMS 0.3.0 do not automatically
replace that managed cohort. The bootstrap recipe records this unresolved
tooling transition; it must not be hidden with overrides or a fabricated pass.

Do not copy the original repository's admission IDs, accepted decisions,
package name or qualification claims into the future destination. A newly
created organization repository begins pending classification and needs its own
reviewed evidence.
