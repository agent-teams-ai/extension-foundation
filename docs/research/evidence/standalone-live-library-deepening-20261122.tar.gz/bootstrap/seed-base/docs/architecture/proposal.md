# Architecture proposal

Status: research proposal, 2026-11-22. Separate portable library/repository is
the confirmed delivery direction. Concrete package names, public contracts,
runtime selection and production admission remain unresolved.

## Responsibilities

The library should make update behavior observable and predictable while
integrating with the host's existing authorities. Distinguish routing for new
work, an operation's selected revision, durable schema compatibility, resource
cleanup and retained recovery/history dependencies. Support explicit failure,
reset and restart outcomes; do not describe routing rollback as undoing writes.

Ordinary TypeScript is the first qualification target. A Node adapter can reuse
AsyncLocalStorage for operation context; a browser integration should reuse the
selected framework's lifecycle. Extism/Wasm is optional and must declare its
different cancellation, serialization, state and host-call limits. Effect can
be a native integration where the consumer adopts it; it is not silently made
a universal dependency.

## FMS mapping proposal

Start with one platform-capability module containing a real controlled
replacement feature: integration with the existing host owner, operation
revision context and the mapping of update receipts. Keep owning contracts,
application behavior, adapters and tests together; add only the layers that
contain real artifacts. The host application composition owns process resources
and lifecycle order. Native context propagation is an internal mechanism.

An optional runtime adapter becomes an integration module only when its native
dependency, independent lifecycle/publication or demonstrated reuse justifies
that boundary. A separately published authoring/client surface uses SDK roles
only if it becomes a real supported capability. Reusable conformance tooling
belongs to a testing capability, not production exports. These are role choices,
not a request to create all packages now.

The profile must reject cross-feature deep imports, undeclared edges/cycles,
unowned production behavior and empty layers. Introduce sub-features or
composition contracts only with their full v1.1 graph/visibility fixtures.

## First concrete production slice to qualify

After its scope and tooling transition are accepted, qualify one controlled
replacement of a TypeScript capability in one real application, using one
replacement mode and its existing activation and resource-lifetime owner.
Native AsyncLocalStorage can carry operation context inside that integration;
it is not the product boundary or a standalone wrapper package. The library
must not introduce a second admission gate, generation kernel, reference
counter or supervisor.

While A is active, hold a real operation or stream under A. A candidate must
actually fail validation or preparation, with rejection observed and new work
still producing A's behavior. Then successfully activate B through the same
owner: new work produces B's behavior, while held work and its stream/finalizer
continue under A. A read-only UI or receipt projection must show active B with
A cleanup pending, then completed only after the owner performs actual cleanup.

Repeat that contract through a neutral external consumer installed from the
packed artifact. The package must compile to JavaScript and declarations and
expose reviewed public surfaces without workspace aliases, product models,
governance runtime, credentials or mandatory Effect/Wasm. Assert actual output
and resource behavior, not only context labels or routing acknowledgements.

Relevant negative cases include mutable context references, iterator next/return
(and throw if exposed), retained callbacks and a resource closed by its owner.
Promise settlement before stream completion must not produce a cleanup receipt.
The five-case native ALS probe is prior mechanism evidence; replacement, user
feedback and the packed consumer still require their own executed gates.
Additional replacement modes, durable recovery and other runtimes remain later
qualification scopes.

## Unresolved bootstrap dependency

The pinned RECOMMENDED Docs cohort and the current compiler floor conflict.
Use the bootstrap recipe and bill of materials for exact versions and resolution
criteria. Keep research transferable while that owning qualification transition
is unresolved. No package install, config checker result or research pass
substitutes for production admission and independently observed protection.
