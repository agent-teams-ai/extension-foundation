# Standalone repository bootstrap and transfer recipe

Prepared **2026-11-22 UTC**, using organization revision `0b44c64c824f536bd1b085341e7669bcc64ef124`. Scope: a reviewable private research seed and a concrete route to production bootstrap. No remote repository, production package, public API or admission record was created.

## 1. Deliverable now: an actual transfer seed

`root/transfer-seed/` already contains:

| Destination | Content and ownership |
|---|---|
| `README.md` | Provisional project, research status, qualification limits and navigation |
| `AGENTS.md` | Explicit routes to organization quality/tool/admission authorities; local research constraints |
| `docs/architecture/proposal.md` | Proposed responsibilities, module roles and first real slice; no accepted ADR claim |
| `docs/architecture/source/feature-module-standard-v1.1.md` | **Entire 38,934-byte immutable standard**, not an excerpt |
| `docs/architecture/source/provenance.json` | Canonical path, commit, Git blob and verified SHA-256 |
| `research/README.md` | Lane/probe navigation and reproduction boundaries |

The assembler copies this recipe and its BOM into `docs/architecture/`; copies the two small metadata/compiler-blocker receipts beside them; and adds the completed lane directories under `research/{versions,feedback,boundaries,reviews}`. Preserve each lane's paths, plans, source ledgers, failures, lockfiles, logs and provenance. Include the browser directory only with its exact frozen inputs and honest current execution receipt.

Exclude `node_modules`, caches, credentials and the original `.git`. Do not flatten independent probe lockfiles into a new workspace. The seed has no root production package or exports. Each probe retains its private package and exact tooling. Seal the actual assembled payload with an outer manifest; verify nested manifests without rewriting historical evidence.

Origin checkpoint `e901903f6a8d7a38bec849626575eddab8e515ff` in extension-foundation records provenance only. Do not copy that repository's package identity, managed Docs projection, admitted repository IDs, accepted decisions or success claims. The future name is provisional, and any organization inventory entry needs its own classification.

## 2. Full FMS 1.1 adoption, when production begins

The source snapshot's verified identity is:

- ID: `agent-teams.feature-module-standard`; version: `v1.1`.
- Canonical repository/path: `agent-teams-ai/.github/docs/architecture/feature-module-standard/v1.1.md`.
- Commit: `0b44c64c824f536bd1b085341e7669bcc64ef124`.
- Git blob: `bd949a9a670862fea851a7791fce772fdef3b4fc`.
- SHA-256: `cfa088ef7396139554fe5e3bcc839271b23299c6b60c569a3a7f1cd7c9f0bc6c`.

The snapshot is an unchanged reference copy; the central standard remains authority. A real production bootstrap must create **one repository-owned adoption profile**, reachable from README, with this complete identity, source commit, actual production/module/application/excluded roots, feature/layer mapping, explicit extension/deviation arrays, architecture document, accepted adoption decision and deterministic enforcement commands. The seed's proposal is not that adoption decision. [B04, B07]

Choose roles by behavior:

| Real capability | Role and initial boundary |
|---|---|
| Runtime-neutral update/context behavior | Platform-capability module, with actual feature slices |
| Host-specific mapping or runtime integration | Feature-owned adapter initially; integration module only when lifecycle, native dependency or reuse justifies extraction |
| Independently supported author/client capability | SDK module only when a real supported surface exists |
| Reusable conformance suites | Testing capability with isolated test-only exports |
| Runnable example/consumer | Thin application composition root; product-specific lifecycle remains there |

No empty adapter packages, `core/utils` ownership dumps, domain aggregates invented for infrastructure, or one-package-per-feature split. Features own contracts, use cases, ports, adapters and tests as appropriate. Sub-features and composition contracts activate the standard's additional visibility, republication, assembly and cycle rules. [B04]

Use the existing `@agent-teams/feature-module-standard@0.3.0` kernel/fixtures/Node runner instead of copying a checker. **This package has no CLI binary.** A thin repository-owned TypeScript gate can call its Node API; the central checker recognizes a native `node scripts/check-features.ts` route. The runner does not prove empty-directory rules, bare-import/alias boundaries or the entire language semantics; pair it with real source-dependency coverage and the required positive/negative topology fixtures. Its Node runner peer is Foundation `^1.8.0 || ^2.0.0 || ^3.0.0`, excluding 1.7.2. [B12; registry metadata]

## 3. Exact tooling: available releases are not managed admission

At the inspected central revision, the current **RECOMMENDED** Docs cohort is:

`docs-2026-10-03-stable31`, final event sequence 186.

| Managed package | Exact version |
|---|---|
| `@agent-teams/docs-protocol` | 0.6.2 |
| `@agent-teams/docs-protocol-agent-teams` | 0.3.2 |
| `@agent-teams/engineering-foundation` | 1.7.2 |
| Transitive document-authoring / repository-mutation | 0.3.2 / 0.2.2 |

Its reusable Docs workflow is pinned at `b30455e32cf5d54ade6d8301637701347e4ce57c`, blob `f1492257de281f40a262042eb989291558147d5f`. Its recorded runtime closure uses pnpm 11.20.0. These are managed-cohort coordinates, not permission to replace the seed probes' manager or locks. [B05, B06]

Separately, the current catalog lists published Foundation **3.0.0**, FMS **0.3.0**, Stack Toolchain **0.1.1** and Docs Protocol **0.6.6**. Exact public npm metadata was read for the first three without installing or executing them. Foundation 3 and Stack 0.1.1 declare TypeScript 7.0.2. These are candidate development tools, **not a new RECOMMENDED Docs cohort or this consumer's qualification**. The Stack README's older 0.1.0 installation example must not override the catalog's 0.1.1 coordinate. [B03, B13; metadata receipt]

### Confirmed blocker before execution

The recommended cohort closure resolves:

`Foundation 1.7.2 → @microsoft/api-extractor 7.58.12 → TypeScript 5.9.3`.

Released source traces the old CLI through command-host, foundation-check, capability registry/modules and the public-API module to an eager API Extractor import. The compiler-blocker receipt inspects the released API Extractor archive without executing it. The current quality standard prohibits initializing embedded compilers below 7.0.2. Root `typescript@7.0.2` does not replace that nested dependency. [B01, B06, B15]

**Do not run the old Foundation CLI gate, suppress the failure, override its transitive compiler, hand-edit immutable cohort evidence or label Foundation 3 a managed-cohort upgrade.** The owning route must qualify/publish/admit a compatible successor cohort or an explicitly reviewed applicable transition. Continue independent research and already qualified native probes meanwhile.

This blocks a truthful combined production-admission claim; it does not prevent retaining the seed or preparing source/configuration proposals.

## 4. Reusable scaffold route

Foundation already provides:

- ScaffoldProfile `foundation.node-typescript-pnpm-esm@1`.
- Recipe `foundation.node-typescript-library-boundary@1`.
- Consumer target catalog and composition policy; verified owner document.
- Reviewable Plan, deterministic Apply and recovery. [B09–B11]

The recipe creates exactly package.json, tsconfig.json and an empty src/index.ts. It supplies a private ESM/declaration-producing package envelope with build/typecheck/test scripts, **not** a repository, feature, tests, workspace references, dependencies or admission. The recipe itself adds no compiler version. Its output must be completed with the first accepted real feature in the same reviewed change; therefore it was **not executed to produce empty packages here**.

After the tooling blocker is resolved and the real target/owner/configuration exist, the released protocol's command shape is:

```sh
agent-teams-foundation scaffold-plan intents/first-feature.yaml --consumer /path/to/new-repository --json
agent-teams-foundation scaffold-apply plans/first-feature.json --consumer /path/to/new-repository --json
```

Save and review the exact emitted Plan before Apply. Neither command installs dependencies or creates a GitHub repository. Do not invent a second scaffold engine or a one-shot plan/apply wrapper.

For the eventual exact development dependency install, use the repository's chosen pinned manager and native lockfile, public scoped/default registry coordinates, lifecycle scripts disabled and exact versions from the then-eligible qualified route. Re-inspect the resolved embedded compiler paths before the first tool launch. Do not use latest, floating dlx/npx, or assume a package's presence establishes adoption. [B01–B03]

## 5. First concrete slice and gates

The proposed first slice is **one controlled replacement of a TypeScript capability in a real host application**. Use one replacement mode and the host's existing activation and resource-lifetime authority. The library integrates that authority with operation revision context and observable update receipts; native AsyncLocalStorage is an internal Node mechanism, not a separate wrapper product. Add no second admission gate, generation kernel, reference counter or supervisor.

Qualify this sequence with actual capability output and resources:

1. While A is active, hold one operation or stream open under A. Submit a candidate that really fails validation or preparation; observe rejection and successful new work still using A.
2. Prepare and activate B through the same existing owner. New work must produce B's behavior; the held operation, stream consumption and finalization must continue with A. A Promise returning a stream is not evidence that its lifetime ended.
3. A read-only UI or receipt projection must distinguish **active B / A cleanup pending** from **active B / A cleanup completed**. Release the held work through its real owner and observe its actual cleanup; elapsed time, a routing acknowledgement or a context label cannot substitute for that evidence.

Run the integration in one real application and repeat its reusable contract through an independent consumer installed from the packed artifact. Retain the relevant mutable-store, retained-callback, iterator next/return and closed-resource negative cases; qualify throw if exposed. The five-case native ALS probe is prior evidence for a mechanism inside this slice, not qualification of replacement, its UI or the published package.

Required evidence before its production bootstrap is claimed:

1. **Full FMS gate and real fixtures:** valid feature for each materialized role; reject unowned behavior, deep imports, undeclared edges/cycles, empty layers and undeclared modules/exceptions. Add v1.1 cases only when those mechanisms are declared.
2. **Actual source census:** Foundation source-dependencies, source-coverage and suppression-governance use the same real module/features and compiler projects; production cannot disappear into excluded/test roots.
3. **Strict compiler and native tests:** all maintained source, tests and tooling checked with TypeScript 7.0.2 or newer. Keep a direct real `tsc --project ...` or build route: the inspected central recognizer accepts Stack presets but does not count `stack-toolchain typecheck` alone as its native compilation witness. Type stripping is execution only.
4. **Scope and typed quality execution:** scope checks do not prove lint success. Run both configured source-coverage modes through the released Foundation route, plus complete Foundation check, assert-dev-only and assert-registry. Do not substitute tool version/help or dry-run output.
5. **Real host and packaged independent consumer:** exercise the replacement/rejection/retention/cleanup sequence above in the actual application and in a consumer outside the workspace using the packed artifact's compiled JS and declarations. Verify public exports and reject deep imports. The external consumer must not need organization credentials, product models, governance runtime, source aliases or mandatory Effect/Wasm.
6. **Repeatable required CI:** the full `check` reaches every required leaf and every declared FMS command. Native jobs are unconditional with complete acyclic needs closures; no path-filtered success, continue-on-error, exit-zero wrapper or hidden environment override. [B01, B02, B07, B14]

The native gate declarations must describe real scripts created with this first feature, not placeholder scripts in the research seed.

## 6. Admission, first PR and remote protection

A new organization repository starts **pending_classification**. Its Docs role would normally be **consumer**, even though its product is a published library; it is not a producer/controller of the Docs toolchain merely because it produces an npm package. Record the owner's actual classification with the real repository identity.

The supported bootstrap route expects default branch `main`, exact pnpm/Bun packageManager and a committed native lockfile. From the reviewed central checkout, render its exact caller:

```sh
node scripts/check-repository-admission.ts render 0b44c64c824f536bd1b085341e7669bcc64ef124
node scripts/onboard-commit-author-identity.mjs render --revision 77a0f46cbfc7688cbabbe12ee819e50ba6f64234
```

Review those bytes and install the canonical workflow destinations; do not copy another consumer's caller/projection. The admission wrapper binds central implementation to `job.workflow_sha`. Its local check reads consumer configuration inertly and never executes consumer code. Success is **configured_not_qualified**. The first installed workflow cannot protect its own first bootstrap PR. [B02, B07, B08]

Managed Docs uses its separate two-phase route: candidate with bootstrap_pending and desired eligible cohort, observed=null; only an independently observed exact required check on the consumer's default-branch revision can establish admitted/bound. Required-check/ruleset enforcement is another dated GitHub observation, not a consequence of a green workflow or merged PR. Identity onboarding's final administrative apply belongs to the authenticated human owner under its documented route.

In this session, repository creation/authenticated administration is unavailable. The exportable seed preserves all work without inventing a remote destination or asking for permission to perform an unavailable operation. Once a destination exists, transfer the sealed seed, prepare the real first feature/bootstrap PR after the tooling conflict is resolved, and qualify its own source, package and hosted gates. [B02]

## Evidence status

Performed: pinned primary-source inspection, complete standard snapshot/digest verification, scoped public package metadata and archive reads, and preparation of actual transfer files. No Foundation/scaffold/Docs runtime was installed or executed for this recipe; no native gates or hosted protections were claimed. Individual research probes retain their separate recorded results.

Exact URLs, source commits, blobs, cohort identity, dependency chain and remaining blockers are in `repository-bootstrap.bom.json`.
