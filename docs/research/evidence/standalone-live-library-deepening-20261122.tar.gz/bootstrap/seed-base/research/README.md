# Research navigation and reproduction

The transfer assembler preserves each lane directory and its evidence identity:

- `versions/REPORT.md`, sources/findings and its native AsyncLocalStorage probe.
- `feedback/REPORT.md`, sources/findings and its native Yjs probe.
- `boundaries/REPORT.md` and that lane's source/qualification records.
- `reviews/` for independent cross-reviews.
- `browser/` only with its actual frozen inputs and current execution receipt;
  a plan or typecheck must not be presented as a completed browser run.

Native probes are independent private packages. Install from each directory's
own committed lockfile with lifecycle scripts disabled, verify the recorded
runtime/compiler coordinates, then use its actual declared scripts. Do not
replace pins with latest, flatten their dependency graphs into a new root
workspace, or reuse another lane's success receipt.

Exclude node_modules, caches and credentials from the transfer. Retain source,
package/lock files, tsconfig, pre-execution plan, logs, provenance, negative
results and manifests. Frozen historical evidence stays unchanged; follow-up
work gets a new receipt and identity. The outer transfer manifest identifies
which files were actually included.
