# Piral lifecycle and public resource ownership — bounded spike plan

Date: 2026-11-23. Status: **BOTH BOUNDED FIXTURES PREPARED; INDEPENDENT SOURCE/ORACLE REVIEW PASS; STRICT TS 7.0.2 CHECKS PASS. NATIVE EXECUTION AWAITS ROOT CHECKPOINT.** See `SPIKE-REVIEW.md` for review chronology and `PREPARATION-RECEIPT.json` for actual preparation outcomes.

Owner task: investigate reusable live module/plugin replacement before selecting technology. Existing Extension Foundation checkout and its original authoring lock remain read-only. Root owns publication and the execution authorization checkpoint. This disposable fixture does not adopt a runtime, public SPI, production policy or any OPEN Q1–Q7 choice.

## 1. Decision this can change

Can a supported, small adapter reuse Piral's actual contribution lifecycle plus the published Resources scope, while reporting honest readiness and old-instance cleanup? Or does its public same-name replacement seam require a weaker, explicitly disruptive update profile than prepare-before-publish with a healthy predecessor?

This is a new native question. Existing MF 4/4 establishes loading/share/evaluation boundaries; SystemJS 2/2 establishes rebinding; PostgreSQL 17/17 establishes selected publication/effect/retention schedules; the seven editor scenarios establish editor/history/contribution boundaries. None executed public Piral same-name replacement, its failure completion contract, or a delayed same-route disposer against a new registration.

The strongest alternative is to use the existing shell and resource mechanisms with a truthful narrow bridge. Do not build another loader, event bus, reference counter, lifecycle kernel or selection authority to make the test pass. The unreleased Get Modular lifecycle kernel is not a dependency candidate for this fixture.

## 2. Source and actual-library boundary

Pinned candidate: published `piral-core@1.12.5`, npm `gitHead` `15af4fd41e049b5880916af81e130cf22e6ac44b`. The ordinary published build is imported through `piral-core`; no copied implementation or private deep import. Its public root exports `createInstance` and public types. `instance.context` exposes actions and `readState`; `config.loadPilet` is a public loader hook. A fixture loader supplies two authored pilets while the real Piral actions, state and managed registrations execute.

Pinned public resource owner: `@get-modular/resources@0.2.2`, imported through its package root. Public `createScope()` returns registration and control facets. Native resource acquisition/release and debt/retry reporting belong to this implementation. A bridge holds each exact scope control and observes its result; it does not reproduce the algorithm.

Read-only source observations to test, not already executed conclusions:

- Piral `addPilet` uses its real load/inject/setup path. Same-name managed registrations are removed before the new setup is known useful. `setup` accepts `void | Promise<void>`; the inspected runner catches/logs rejection. Action fulfillment alone therefore may not be a readiness receipt.
- Piral `teardown` is declared **void**. Asynchronous work initiated there is outside an upstream awaited-teardown promise. A negative control demonstrates that limit; it must not be reported as Piral violating a promised Promise contract.
- The returned page-registration disposer unregisters by route. A delayed old disposer may remove a new same-route registration. Extension disposal carries a reference; it supplies a useful positive contrast. This is a source-predicted delayed-callback boundary, not a blanket product defect claim.
- Resources `close()` reports callback completion and debt, not physical resource release by assertion. Native listener behavior must supply the separate physical observation.

Exact primary source paths are in `SOURCE-INVENTORY.json`. Current organization quality guidance was read at `.github@0b44c64c824f536bd1b085341e7669bcc64ef124`; current GM source at `850bac5fd02fa5697846cc8958ac447d5c2ee7bb` still lists Resources 0.2.2 and leaves lifecycle kernel unreleased. Current source is not silently treated as byte-identical to the published package: installed entrypoints and published tarball/lock identities must be retained separately.

## 3. Deliberately narrow execution profile

Trusted cooperative same-realm browser pilets, one host, one fixed route and one fixed extension slot. Public Piral is rendered through its supported root/component API. A button in the registered page performs a visibly different A/B action. Public `readState` independently observes managed registration state; it never mutates private state.

Each pilet may own one real browser `EventTarget` listener acquired through a public Resources setup in the bridged cases. The test dispatches an event through the actual target and records which listener executes. This is an independent deterministic positive/negative oracle for the registered listener; it is not a claim about all timer/socket/worker resources. A retained callable is separately observable and is not confused with the current route registration.

All concurrency uses explicit started/release/rejected gates and awaited native observations. No race is inferred from a fixed sleep. A bounded outer timeout only fails a stalled fixture; it never proves cleanup, cancellation or publication. Browser page/context cleanup belongs to the runner's `finally` path and must leave no fixture server/process running.

Every separately initialized case uses a fresh browser page and Piral instance and waits for public initial loading completion before dynamic additions. B2 and B3 are one intentionally continuous transition, since B3 retries B2's exact retained A scope; they share no state with P1, P2 or B1. The initial-loading barrier observes public notification/read-state and never changes `app.loading` or modules directly.

No backend DB, production catalog, external business service, real user document or privileged provider is touched. No scope implies sandboxing or arbitrary untrusted-code termination.

## 4. Two declared tests, five named observation cases

### Test 1 — actual Piral completion and delayed-disposal boundary

| Case | Setup and controlled ordering | Independent observed oracle | Falsifier / interpretation |
| --- | --- | --- | --- |
| P1: candidate setup rejects | A is registered and its real page action is useful. Public same-name `addPilet(B)` loads B, whose asynchronous setup acquires its identifiable native listener then rejects. Observe completion and state before fixture cleanup. | Actual A/B page behavior; public registry state; captured A callable; setup error log; public action fulfillment/rejection; native listener invocation. | If the source-predicted result is different, retain actual result and inspect the published cohort. Never infer healthy-predecessor preservation from an action Promise. Acquisition followed by failed setup exposes the candidate-cleanup integration duty. |
| P2: old page disposer resumes after B is useful | A retains its actual `registerPage` disposer behind a gate and also registers an extension. Same-name B registers the same page route and extension name. Verify B useful, then release A's delayed returned disposers. | B page/route before and after the old disposer; public registry entry; independently rendered/registered B extension. The extension's reference-based disposer is the positive contrast. | Source predicts route-only disposal can remove B while reference-based extension disposal preserves B. A failure of this prediction is valid counterevidence, not a reason to change expected behavior silently. Do not generalize unsupported delayed teardown to the synchronous upstream contract. |

The first test explicitly exercises a hostile-to-its-own-state delayed callback in a disposable trusted fixture. Any lost page registration is the intended observation, not a mutation of a real user application.

### Test 2 — explicit cooperative bridge to real public Resources

This fixture-level bridge is an integration candidate, not the completed library. It adds exactly two observations that Piral's action result does not promise: a candidate readiness result and the exact instance's `CloseReport`/cleanup result. It uses actual Resources scopes for acquired native handles. Managed registration ownership stays with Piral.

| Case | Setup and controlled ordering | Independent observed oracle | Boundary retained |
| --- | --- | --- | --- |
| B1: failed candidate remains owned | B acquires its resource through its own scope and rejects setup. The bridge retains the failure result and requests closure of B's exact scope. | Candidate readiness is rejected even if Piral action fulfills; explicit cleanup result; B listener no longer executes; A registration's real fate is reported. | The bridge must **not** promise that Piral restored A or preserved its useful UI. If the existing seam destroys A before B is useful, the profile is explicitly disruptive/failed-after-replacement. |
| B2: useful B with old cleanup debt | A's native cleanup starts and deliberately throws once before removing its listener. B becomes useful through real Piral registration. | B page action works; B listener fires; A listener still fires; actual A scope report is `complete:false` with a failed debt and original cause. | A fulfilled Piral action is not cleanup completion. Only A's resource scope is closed. No deadline, fake success flag or copied debt counter is introduced. |
| B3: explicit retry of the owned debt | The test's explicitly configured policy calls A's same public scope `close()` again, after allowing its cleanup to succeed. | Original debt remains in the retained first result; final A report completes; A listener no longer fires; B listener and B page remain useful. | This tests the bridge's exact-instance ownership in a Piral transition, not the already qualified Resources retry algorithm in isolation. It does not authorize automatic production retry. |

The supported bridge profile separates **synchronous Piral-managed registration cleanup** from **asynchronous owned native cleanup**. It does not schedule an old generic route disposer after B has registered. It must expose that limitation: it cannot transparently adapt arbitrary foreign pilets whose delayed teardown calls back into generation-unaware registration APIs. No interception of a global event bus or private registry is permitted to conceal the P2 counterexample.

Counts will be reported as two declared native tests, five named cases, and the extension reference control inside P2. Individual comparisons are a separate number. Repeated runs or a correction do not increase distinct coverage.

## 5. Provisional dependency/profile inventory and readiness gates

- Local runtime metadata: Node 24.22.3 and pnpm 11.25.0 observed without executing a spike. TypeScript 7.0.2 is installed in existing exact-locked probes. Resources 0.2.2 is installed and its public entrypoint bytes have been read.
- Reuse the previously available Vite 8.3.8 and Playwright 1.65.1 tooling cohort where compatible. Use React 18 / Router 5 for this particular Piral cohort, with exact runtime/type versions determined from official metadata and locked before source execution. Piral-core does not declare these as peerDependencies; do not invent an upstream peer constraint from its umbrella package or dev setup.
- Piral's published root imports its genuine `app.codegen` generator. Use published `vite-plugin-codegen@2.1.0`, also selected by official `piral-cli-vite8`, rather than supplying handwritten default state/router exports. Its bundled generator and public declarations join the static dependency audit. No upstream source build or copied generated-state substitute is allowed.
- Use a new disposable package, not mutation of any prior probe. `package.json`, exact native lock, strict tsconfig, source identity manifest and all new `.ts`/`.tsx` sources are preserved.
- Every maintained source/test/runner is in an effective TypeScript >=7.0.2 project with `strict:true`, `skipLibCheck:false`, checked public declarations and suitable `ES2024`, `ESNext.Disposable`, DOM and Node types. No unchecked `any`, blanket assertion, typecheck suppression, copied declaration shim or weaker compiler mode.
- Before running any package tool, inspect the installed runtime/tool dependency graph and actual compiler/parser resolution for older embedded TypeScript. Upstream published generated JS is legitimate runtime code; upstream build scripts are not executed. A TS<7 initialization dependency blocks that tool, not independent source review.
- Published tarball integrity, exact resolved versions, package entrypoints/exports and installed source hashes are recorded. A lockfile-only preparation or strict compile is not a native execution result.

The current `/usr/bin/chromium` path exists, but this task has not launched it. The preceding local MF run encountered an OS process-singleton socket restriction. Do not weaken that restriction or count a fake DOM as a Chromium pass. Preferred fallback is the existing ordinary hosted browser route with a managed exact Playwright browser. Root owns the frozen-input publication and workflow. Source/profile identity in the result must bind to the actual executed input, not a later docs-only head.

## 6. Preparation, review and execution sequence

1. Independent review of this plan by root and/or the architecture/runtime lane. Record accepted/rejected comments and exact plan hash. No new runtime experiment before approval.
2. After plan approval, prepare a small fixture under `spikes/piral-lifecycle/`: public API app source, exact-instance bridge source, shared observation types, TypeScript browser runner, strict config and exact dependency instructions. Approximate fixture budget 350–600 authored TS/TSX lines; zero production library lines. These are planning bounds, not a target quota.
3. Resolve/install the exact package with scripts disabled through the approved ordinary route; statically audit the actual package/tool graph. If local installation is unavailable, preserve the failure and use existing official artifacts or the ordinary hosted frozen-lock install. Do not bypass permissions, rewrite pins or stop unrelated design work.
4. Effective strict TypeScript 7.0.2 check of all authored files. Retain compiler identity and original failures. A change needed to repair a declaration/interface gap must receive source review; no private implementation copy disguised as a library.
5. Independent source/oracle review of the runnable fixture and its exact input manifest. Confirm real public imports, meaningful failure ordering, physical listener observations, no hidden scheduler/manager and honest completion labels.
6. Root publishes a useful checkpoint and authorizes one bounded native run. On failure, preserve exact source, logs and partial reached/unreached cases; distinguish environment/setup failure, oracle error and real behavioral counterexample. A justified correction gets a separate identity/review, not a relabelled first run.
7. Report results and decision implications. Stop when the stated uncertainty is resolved; do not expand to more shells, operating systems, databases or editor histories without a new concrete reason.

## 7. Output and limits

Deliver `SPIKE-PLAN.md`, `SOURCE-INVENTORY.json`, runnable exact-locked fixture and source/readiness review. After authorized execution, add original native results/logs, source/input identities, per-case event ordering, comparison counts and independent result criticism. Root packages and pushes the evidence; standalone remote provisioning is separate and currently unavailable.

A passing bridge would demonstrate a reusable integration candidate for this declared trusted Piral/Resources profile. It would not establish whole-library E2E, migration/state preservation, arbitrary old-work draining, process isolation, timer/socket cleanup, every pilet format, production package adoption or superiority over a ready stack. A negative result can legitimately require a weaker profile or another public seam instead of more custom coordination.

## 8. Separate optional amendment E1 — Effect scope close is not a join

**Amendment status: root approved bounded preparation; independent source/oracle review passed; no native execution yet.** This adds one Node test with one named case, at most approximately 100 maintained TypeScript lines. It does not add another browser adapter, full Effect application, broad matrix or production dependency. The total campaign is three declared tests and six named cases, with Piral unchanged at two tests/five cases. Install/compile/execute gates and frozen-input review apply independently.

Decision: must a future lifecycle port distinguish requesting idempotent closure from joining the original cleanup operation? The public Effect Scope documentation explicitly says a second `close` returns immediately when the scope is already closed, even if the first operation's finalizers are still running. This is a documented contract, not a vendor bug. Executing the exact published version would prevent an adapter from accidentally treating a repeated close as physical release proof.

Candidate runtime is published `effect@4.1.5`, ordinary public root import only. Source-tag revision is `e3aca1f1484e623cee09b7f3fa18d6ff5d66c0e8`; npm metadata integrity and source review are recorded separately from future installed-byte evidence. Existing Get Modular Effect adapter's peer cohort is not changed or invoked. Installed declarations, dependency graph and compiler remain subject to strict TypeScript 7.0.2 qualification before native execution.

One real Node `EventTarget` listener is registered. Public `Scope.make`, `Scope.addFinalizer`, `Deferred`, `Effect.runFork`, `Scope.close` and `Fiber.join` establish the ordering. The first close runs on a root fiber outside the scope being closed. Its finalizer signals entry and waits on a release gate before removing that exact listener. After observing entry, the test calls close again. On the inspected contract, it returns while the finalizer gate is still closed. Dispatching a real event at that boundary must still invoke the listener. Releasing the gate and joining the original close must be followed by a second dispatch that does not invoke it.

Both observations are retained before assertions. Gate release is guaranteed through cleanup even on a failed oracle, so an unmet expectation cannot strand an uninterruptible finalizer. A bounded process timeout only reports a stalled case and is never used to claim cleanup. There is no private-state polling, copied Scope implementation, alternate scheduler, custom scope manager or assertion that Resources must share Effect's repeated-close semantics.

Primary oracles: native listener invoked before release and absent after original-close join. Completion ordering is observed separately: second close returned while the first finalizer had not removed its listener. If the published version differs from source prediction, record the actual result and stop to inspect the cohort; do not silently change the expected contract. No active-work admission, cross-process behavior, resource class beyond this listener, cancellation policy or automatic production selection is qualified.

## 9. Frozen preparation outcome

Ordinary scripts-disabled installation succeeded for both profiles. The actual installed Linux x64 glibc package-root closures contain 56 distinct package/version pairs for Piral and 5 for Effect. Optional packages for other platforms are represented in their native lockfiles but are not asserted installed. Both actual compiler packages are 7.0.2; the native compiler binary hash is recorded in each `dependency-audit.json`. No upstream build scripts or older compiler were executed.

The first strict Piral check exposed missing SystemJS modules/types required by piral-base's public declarations. Its original inputs and failing log are retained. Installing real SystemJS 6.15.1 and published types 6.15.4 resolved this gap without declarations copied or suppressed. Final strict checks of all authored fixture files/public declarations pass. Piral's genuine official-codegen production build also passes (128 transformed modules); the browser runner will serve this output through public `vite.preview()`.

The independent runtime reviewer passed the exact final candidate after verifying three evidence-preservation corrections. Original teardown failure and primary scenario errors are retained separately; observation writing does not depend on successful browser/server closure; Effect assertion failures populate the JSON failure field. Source totals are 434 TypeScript/TSX lines for Piral including runner/config/types and 83 lines for Effect. These are fixture lines, not production library code.

The candidate hosted workflow has exactly two independent profile jobs with fail-fast disabled, one automatically path-scoped push trigger on the existing draft branch, immutable action pins, read-only permissions and credentials disabled at checkout. Each job verifies the full archive/member manifest, exact installed native-platform closure and compiler identity before strict checking or executing its own cases. Artifact delivery runs even on failure and includes original input, receipts/logs, actual generated output and dependency license/NOTICE texts. This is prepared execution infrastructure, not an already completed run.
