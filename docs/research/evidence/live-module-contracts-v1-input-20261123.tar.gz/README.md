# Frozen live module contract probes

Two bounded disposable profiles are ready for root-owned publication and native execution. **No new native case has run at this checkpoint.** Strict TypeScript 7.0.2 checks pass for both; genuine Piral production generation passes. Source review, original preparation failure, dependency identity, exact native-platform audits and limits are preserved alongside the inputs.

| Profile | Actual libraries | Declared native coverage |
| --- | --- | --- |
| `piral-lifecycle/` | Piral core 1.12.5, React 18.3.1, Router 5.3.4, public Resources 0.2.2; official codegen | 2 tests, P1/P2/B1/B2/B3: readiness failure, delayed route disposer with extension control, candidate cleanup, old-instance debt, explicit exact-scope retry |
| `effect-close/` | Effect 4.1.5 through public exports | 1 test, E1: repeated close returns before original finalizer completion; actual listener disappears after original-close join |

All pilets are trusted and share one realm. The first profile deliberately demonstrates the synchronous managed-registration boundary; its small resource bridge does not preserve the predecessor or repair arbitrary foreign delayed disposers. Neither profile qualifies production adoption, admission/custody, forced cancellation, state migration or a complete update library.

## Reproduction after the reviewed execution checkpoint

Use the exact Node 24.22.3 / pnpm 11.25.0 Linux x64 glibc profile. Verify the input manifest and installed closure using the candidate workflow. Install each package with `pnpm install --frozen-lockfile --ignore-scripts --engine-strict --strict-peer-dependencies`; then run `pnpm typecheck`. Compiler identification and native executable hash must match `dependency-audit.json`. Do not invoke an upstream build or older compiler.

For Piral, run `pnpm build`, install the pinned Playwright browser with `pnpm exec playwright install --with-deps chromium`, and run `pnpm probe`. Its public preview server serves the genuine generated `dist/` bundle. For Effect, run `pnpm probe` after its own strict check. The hosted candidate keeps the two profile jobs independent so browser environment failure does not conceal the separate Node result.

`evidence/observations.json` and original Node-test output provide actual observations. The plan's expected results are hypotheses until the frozen run reports them. Planned/entered/completed cases, comparisons, native declared-test counts and workflow job/step status are separate quantities. Preserve any failure before preparing a corrected input; a retry is not extra distinct coverage.

## Custody and artifacts

`FROZEN-INPUTS.json` identifies maintained input/config/lock and review bytes. The outer archive manifest records every actual member. The archive excludes node_modules, generated dist, transient Vite cache, compiler/browser/native-binding binaries and new native results. Hosted artifacts retain generated output explicitly as generated evidence, plus dependency license/NOTICE texts from `third-party-licenses/`.

`preparation/` retains the first failed strict compilation and its exact input archive, subsequent final strict/build receipts, and source-review findings. SystemJS modules and public types were added through real exact dependencies; no shim or weakened declaration check hid the initial gap. Historical preparation logs are not native PASS receipts.
