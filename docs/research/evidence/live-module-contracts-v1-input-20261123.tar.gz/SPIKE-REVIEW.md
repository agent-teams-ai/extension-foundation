# Spike plan review and response

Date: 2026-11-23. Research only; zero native executions at this checkpoint.

## Root plan review

Root independently read `SPIKE-PLAN.md` sections 1–7 and **approved bounded fixture preparation, not native execution**. Required conditions:

1. Await Piral's initial loading before every scenario; use a fresh fixture/instance per declared test, without carrying prior rejected setup state.
2. P2 observes actual B DOM and public registry plus the exact-reference extension control.
3. The bridge does not repair arbitrary late route disposers or preserve the predecessor. Its contract is limited to cooperative native cleanup and honest observations.
4. Check public declarations strictly; no shims, suppressed type errors or weaker compiler options for incompatible dependencies.
5. The optional Effect case requires a separate explicit plan amendment and current availability/graph review.

Response: all five conditions accepted. They are mandatory input/source review points, not after-the-fact interpretations. Initial loading uses public notification/read-state; no private `app.loading` mutation. Each observation case creates a fresh instance/page to avoid contaminated prior state even within the same declared test. Raw and bridged paths remain visibly separate. Cleanup owns exact listener closures and actual Resources scopes; it does not invent admission counters.

Root requires frozen runnable input identities and independent source/oracle review before publishing and authorizing one bounded run. That execution gate remains pending.

## Runtime reviewer input

`/root/mf_runtime` independently identified the public `createInstance`, `config.loadPilet`, action/readState, managed page/extension and root-render paths at Piral source `15af4fd…`. It corrected the important contract interpretation: `setup` supports a Promise, but `teardown` is void. A deferred teardown experiment is a completion-boundary observation, not evidence of a broken promised async contract.

It proposed the route-only page disposer / reference-bound extension contrast and supplied a source-backed public render recipe. The host must finish initial `requestPilets` loading before dynamic adds, otherwise initial notification can overwrite the module list. This is incorporated as a required precondition.

It also proposed the single optional Effect close-join discriminator and checked public 4.x Scope/Deferred/Fiber APIs. That is source evidence, not approval to execute or a passing runtime result.

## Architecture reviewer input

`/root/architecture_decisions` emphasized that a same-name inject wrapper cannot invent predecessor preservation if the native path already removed A. Public Resources owns cleanup; it does not create callback/stream admission or physical-release authority. Current GM ADR-0030 separates cleanup scopes from the still-private lifecycle kernel's admission bookkeeping. The fixture therefore makes no admitted dynamic-Host/kernel conformance claim and imports no private kernel. Captured callable behavior is observed, not governed by a new reference counter.

## Subsequent review checkpoints

- Effect plan amendment: root approved preparation after reviewing plan SHA256 `0b3787569b4923d12b1259d2263f0867221e494f0abd3b14493b2b428ca8795a` and immutable public Scope source. Added condition: a close2-joins falsifier must still release the gate and join original work through an independent `finally`. Accepted; the runner uses public `Effect.runFork` outside the closed scope and a bounded observer, not a timeout as release evidence.
- Installed dependency/compiler graph: final installed package-root audits contain 56 distinct package/version pairs for Piral and 5 for Effect on Linux x64 glibc. TypeScript/compiler native package and executable are exactly 7.0.2. Published Effect 4.1.5 public runFork declaration is inspected.
- Strict compilation: first Piral run failed on undeclared SystemJS side-effect imports/namespace in published piral-base declarations. Original source/log are retained in `piral-preparation-red-01.tar.gz` and its member manifest. Adding actual SystemJS 6.15.1 and published types 6.15.4 resolved it without shims or weaker checking. Final changed-source Piral and Effect strict compilation passed, as did the genuine 128-module production build.
- Frozen source/oracle review: `/root/mf_runtime` final **PASS** in `CODE-REVIEW.md`/`CODE-REVIEW-inputs.json`. Eight reviewed source/package hashes were independently reread or rechecked; all match the final source candidate. Root preliminary comments were accepted and fixed. This is not execution authorization.
- Native execution: **not started; requires the agreed source review and root checkpoint**.

Root preliminary source review identified two meaningful weaknesses. `startClose` now explicitly rejects a repeated teardown observation instead of replacing the retained first close. Fixture cleanup now retains actual CloseReport values and dispatches the native target before fallback removal, so awaited scope closure alone cannot conceal a live listener or residual debt. Both corrections are fixture observations; Resources remains the cleanup owner.

The runtime reviewer found no dev-only requirement. Browser execution uses public `vite.preview()` over the genuine production output, which already passed build, instead of introducing a dev prebundle profile. Actual action/state/registration and native listener behavior are still exercised in Chromium; production generation is not a native passing result.

Final independent review verified CR01–03: teardown cannot prevent observation writing, cleanup cannot overwrite the primary scenario failure, and Effect assertion failures cannot leave `failure:null`. A DOM wait follows the real button click so React commit timing is observed without a sleep. Both root and runtime reviewer checked actual public runtime use and found no synthetic shell/private kernel substitution. Final publication/workflow review and native execution remain root-owned gates.
