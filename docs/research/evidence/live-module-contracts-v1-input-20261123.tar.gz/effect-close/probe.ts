import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { test } from 'node:test';
import { Deferred, Effect, Exit, Fiber, Scope } from 'effect';

// This is only a stalled-observer failure bound. It never proves release.
async function bounded<T>(operation: Promise<T>, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation, new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label}: observer timeout`)), 3_000);
    })]);
  } finally { clearTimeout(timer); }
}

test('E1: repeated public Scope.close is not a join of the original finalizer', async () => {
  const events: string[] = [];
  const target = new EventTarget();
  let hits = 0;
  const listener = () => { hits++; };
  let beforeRelease: number | undefined;
  let afterJoin: number | undefined;
  let secondReturnedBeforeRelease = false;
  let firstJoined = false;
  let comparisons = 0;
  let failure: unknown;
  const state = await Effect.runPromise(Effect.gen(function* () {
    const scope = yield* Scope.make();
    const entered = yield* Deferred.make<void>();
    const release = yield* Deferred.make<void>();
    yield* Scope.addFinalizer(scope, Effect.gen(function* () {
      events.push('finalizer entered');
      yield* Deferred.succeed(entered, undefined);
      yield* Deferred.await(release);
      target.removeEventListener('probe', listener);
      events.push('finalizer removed exact native listener');
    }));
    return { scope, entered, release };
  }));
  target.addEventListener('probe', listener);
  // Public root fiber, deliberately outside the scope being closed.
  const first = Effect.runFork(Scope.close(state.scope, Exit.succeed(undefined)));
  let second: Promise<void> | undefined;
  try {
    await bounded(Effect.runPromise(Deferred.await(state.entered)), 'finalizer entry');
    second = Effect.runPromise(Scope.close(state.scope, Exit.succeed(undefined)));
    await bounded(second, 'second close');
    events.push('second close returned before test released gate');
    secondReturnedBeforeRelease = true;
    target.dispatchEvent(new Event('probe'));
    beforeRelease = hits;
  } catch (cause) { failure = cause; }
  finally {
    // Even the falsifier "close2 joins" releases this gate before awaiting either close.
    events.push('test releases finalizer gate');
    await Effect.runPromise(Deferred.succeed(state.release, undefined));
    try {
      await bounded(Effect.runPromise(Fiber.join(first)), 'original close join after release');
      firstJoined = true;
      if (second) await bounded(second, 'second close completion after release');
      target.dispatchEvent(new Event('probe'));
      afterJoin = hits;
    } catch (cause) { failure ??= cause; }
    target.removeEventListener('probe', listener);
  }
  try {
    if (failure) throw failure;
    const check = (value: boolean, label: string) => { comparisons++; assert.ok(value, label); };
    check(secondReturnedBeforeRelease, 'close2 returns while original finalizer gate remains closed');
    check(beforeRelease === 1, 'real native listener still fires after close2 returns');
    check(firstJoined, 'original close is joined after release');
    check(afterJoin === beforeRelease, 'exact listener absent after original close join');
    check(events.indexOf('finalizer removed exact native listener') > events.indexOf('test releases finalizer gate'), 'native release follows explicit test gate');
  } catch (cause) { failure ??= cause; throw cause; }
  finally {
    await mkdir('evidence', { recursive: true });
    await writeFile('evidence/observations.json', JSON.stringify({
      case: 'E1', declaredTests: 1, comparisonsAttempted: comparisons, events,
      secondReturnedBeforeRelease, firstJoined, beforeRelease, afterJoin,
      failure: failure instanceof Error ? failure.message : failure === undefined ? null : String(failure),
    }, null, 2) + '\n');
  }
});
