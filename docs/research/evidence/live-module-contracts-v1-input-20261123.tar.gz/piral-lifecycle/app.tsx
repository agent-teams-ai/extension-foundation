import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createInstance, Piral, ExtensionSlot, type Pilet, type PiletMetadata, type PiletApi } from 'piral-core';
import { ownListener, message } from './owned.ts';
import type { Generation, Scenario, Snapshot } from './types.ts';

const input = new URL(location.href).searchParams.get('scenario');
function scenario(value: string | null): Scenario {
  if (value === 'raw-failure' || value === 'raw-disposer' || value === 'bridge-failure' || value === 'bridge-debt') return value;
  throw new Error(`Unrecognized explicit scenario: ${value}`);
}
const selected = scenario(input);
history.replaceState(null, '', `/probe?scenario=${selected}`);
const bridged = selected.startsWith('bridge-');
const rejectsB = selected.endsWith('failure');
const target = new EventTarget();
const hits: Record<Generation, number> = { A: 0, B: 0 };
const events: string[] = [];
const record = (event: string) => { events.push(event); };
const listeners = { A: () => { hits.A++; }, B: () => { hits.B++; } };
const owned = {
  A: ownListener('A', target, listeners.A, record, selected === 'bridge-debt'),
  B: ownListener('B', target, listeners.B, record, false),
};
const delayed = Promise.withResolvers<void>();
let delayedDisposal: Promise<void> | undefined;
let retained: (() => void) | undefined;
let retainedCalls = 0;
let registrationA: unknown;
let registrationB: unknown;
const initial = Promise.withResolvers<void>();

function makePage(generation: Generation) {
  return function UsefulPage() {
    const [count, setCount] = useState(0);
    return <section data-testid={`page-${generation}`}>
      <button onClick={() => setCount(value => value + 1)}>{generation} action</button>
      <output data-testid={`output-${generation}`}>{generation} useful {count}</output>
    </section>;
  };
}
const pages = { A: makePage('A'), B: makePage('B') };
const extensions = {
  A: () => <span data-testid="extension-A">A extension</span>,
  B: () => <span data-testid="extension-B">B extension</span>,
};
const metadata = (generation: Generation): PiletMetadata => ({
  name: 'same-pilet', version: generation === 'A' ? '1.0.0' : '2.0.0', spec: 'fixture',
  dependencies: {}, config: {}, link: 'fixture://same-pilet', basePath: '/',
});
function pilet(generation: Generation): Pilet {
  let disposePage: (() => void) | undefined;
  let disposeExtension: (() => void) | undefined;
  return {
    ...metadata(generation),
    async setup(api: PiletApi) {
      record(`${generation}: setup entered`);
      const finish = async () => {
        if (generation === 'B' && rejectsB) {
          record('B: setup rejected after acquisition');
          throw new Error('B: deliberate readiness rejection');
        }
        disposePage = api.registerPage('/probe', pages[generation]);
        disposeExtension = api.registerExtension('probe-extension', extensions[generation]);
        if (generation === 'A') retained = () => { retainedCalls++; };
        record(`${generation}: registrations installed`);
      };
      if (bridged) await owned[generation].setup(finish);
      else {
        target.addEventListener('probe', listeners[generation]);
        record(`${generation}: raw acquired`);
        await finish();
      }
    },
    teardown() {
      record(`${generation}: Piral teardown invoked`);
      if (generation === 'A' && selected === 'raw-disposer') {
        // Upstream teardown is void: this intentionally delayed callback is not an awaited contract.
        delayedDisposal = delayed.promise.then(() => {
          disposePage?.(); disposeExtension?.();
          record('A: delayed returned disposers invoked');
        });
      }
      if (bridged) owned[generation].startClose();
      else target.removeEventListener('probe', listeners[generation]);
    },
  };
}
const instance = createInstance({
  requestPilets: async () => [],
  loadPilet: async entry => {
    if (!('version' in entry)) throw new Error('Fixture requires an explicit single pilet');
    if (entry.version === '1.0.0') return pilet('A');
    if (entry.version === '2.0.0') return pilet('B');
    throw new Error(`Unexpected pilet version: ${entry.version}`);
  },
  state: { components: { Layout: ({ children }) => <main>{children}<aside><ExtensionSlot name="probe-extension" /></aside></main> } },
});
instance.once('loaded-pilets', () => { record('host: initial loading completed'); initial.resolve(); });
const element = document.getElementById('root');
if (!element) throw new Error('Missing authored fixture root');
const root = createRoot(element);
root.render(<Piral instance={instance} />);

function snapshot(): Snapshot {
  return instance.context.readState(state => {
    const page = state.registry.pages['/probe'];
    return {
      loading: state.app.loading,
      pageGeneration: !page ? null : page.component === registrationB ? 'B' : page.component === registrationA ? 'A' : 'other',
      extensionGenerations: (state.registry.extensions['probe-extension'] ?? []).map(entry =>
        entry.reference === extensions.A ? 'A' : entry.reference === extensions.B ? 'B' : 'other'),
      hits: { ...hits }, retainedCalls, events: [...events],
    };
  });
}
window.probe = {
  ready: initial.promise,
  async add(generation) {
    await initial.promise;
    if (instance.context.readState(state => state.app.loading)) throw new Error('Initial loading is unfinished');
    try {
      await instance.context.addPilet(metadata(generation));
      const component = instance.context.readState(state => state.registry.pages['/probe']?.component);
      if (generation === 'A') registrationA = component; else registrationB = component;
      record(`${generation}: add fulfilled`);
      return { status: 'fulfilled', message: null };
    } catch (cause) { record(`${generation}: add rejected`); return { status: 'rejected', message: message(cause) }; }
  },
  snapshot,
  dispatch() { target.dispatchEvent(new Event('probe')); return snapshot(); },
  callRetained() { if (!retained) throw new Error('A callable was never captured'); retained(); return snapshot(); },
  async releaseOldDisposers() {
    if (!delayedDisposal) throw new Error('No actual delayed teardown was observed');
    delayed.resolve(); await delayedDisposal; return snapshot();
  },
  readiness: generation => owned[generation].readiness,
  closeCandidate: () => owned.B.close(),
  oldCloseReport: () => owned.A.firstReport(),
  retryOldCleanup: () => owned.A.retry(),
  async dispose() {
    try {
      delayed.resolve(); await delayedDisposal;
      await instance.context.removePilet('same-pilet');
      const reports = await Promise.all([owned.A.dispose(), owned.B.dispose()]);
      if (!bridged) {
        target.removeEventListener('probe', listeners.A); target.removeEventListener('probe', listeners.B);
      }
      const hitsBefore = { ...hits };
      target.dispatchEvent(new Event('probe'));
      const hitsAfter = { ...hits };
      return { reports, listenersAbsent: hitsBefore.A === hitsAfter.A && hitsBefore.B === hitsAfter.B, hitsBefore, hitsAfter };
    } finally {
      // Last-resort fixture teardown does not erase the preceding native observation.
      target.removeEventListener('probe', listeners.A); target.removeEventListener('probe', listeners.B);
      root.unmount();
    }
  },
};
