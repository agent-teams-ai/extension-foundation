import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { before, after, test } from 'node:test';
import { chromium, type Browser, type Page } from 'playwright';
import { preview, type PreviewServer } from 'vite';
import type { Scenario } from './types.ts';

let browser: Browser | undefined;
let server: PreviewServer | undefined;
let comparisons = 0;
const observations: { case: string; value: unknown }[] = [];
const completed: string[] = [];
const consoleMessages: { scenario: Scenario; type: string; text: string }[] = [];
const pageErrors: { scenario: Scenario; message: string }[] = [];
const infrastructureFailures: string[] = [];
const check = (condition: boolean, label: string) => { comparisons++; assert.ok(condition, label); };
const retain = (name: string, value: unknown) => { observations.push({ case: name, value }); };
const describe = (error: unknown) => error instanceof Error ? { name: error.name, message: error.message, stack: error.stack ?? null } : { message: String(error) };

before(async () => {
  // Execute the actual production output built from published Piral + its official codegen.
  server = await preview();
  // Ordinary managed Playwright browser. No sandbox flags or alternative fake DOM.
  browser = await chromium.launch({ headless: true });
});
after(async () => {
  const failures: unknown[] = [];
  try {
    try { await browser?.close(); } catch (error) { failures.push(error); }
    const running = server;
    try {
      if (running) await new Promise<void>((resolve, reject) => running.httpServer.close(error => error ? reject(error) : resolve()));
    } catch (error) { failures.push(error); }
    infrastructureFailures.push(...failures.map(error => JSON.stringify(describe(error))));
  }
  finally {
    await mkdir('evidence', { recursive: true });
    await writeFile('evidence/observations.json', JSON.stringify({
      declaredTests: 2, plannedCases: ['P1', 'P2', 'B1', 'B2', 'B3'], completed,
      comparisonsAttempted: comparisons, observations, consoleMessages, pageErrors, infrastructureFailures,
    }, null, 2) + '\n');
  }
  if (failures.length) throw new AggregateError(failures, 'Native host teardown failed; observations retained');
});

async function fresh(selected: Scenario, body: (page: Page) => Promise<void>) {
  if (!browser) throw new Error('Native Chromium did not start');
  const context = await browser.newContext();
  const page = await context.newPage();
  page.on('console', entry => consoleMessages.push({ scenario: selected, type: entry.type(), text: entry.text() }));
  page.on('pageerror', error => pageErrors.push({ scenario: selected, message: error.message }));
  page.setDefaultTimeout(10_000);
  const failures: unknown[] = [];
  try {
    await page.goto(`http://127.0.0.1:4397/probe?scenario=${selected}`);
    await page.waitForFunction(() => typeof window.probe !== 'undefined');
    await page.evaluate(() => window.probe.ready);
    const initial = await page.evaluate(() => window.probe.snapshot());
    check(!initial.loading, `${selected}: public initial loading finished`);
    await body(page);
    check(!pageErrors.some(error => error.scenario === selected), `${selected}: no unexpected browser exception`);
  } catch (error) { failures.push(error); retain(`${selected}: scenario failure`, describe(error)); }
  finally {
    try {
      const cleanup = await page.evaluate(async () => window.probe ? await window.probe.dispose() : undefined);
      if (cleanup) {
        retain(`${selected}: fixture cleanup`, cleanup);
        check(cleanup.reports.every(report => report.complete && report.settled && report.debts.length === 0), `${selected}: fixture cleanup has no residual reported debt`);
        check(cleanup.listenersAbsent, `${selected}: native listeners absent after actual cleanup, before fallback`);
      }
    } catch (error) { failures.push(error); retain(`${selected}: cleanup failure`, describe(error)); }
    try { await context.close(); }
    catch (error) { failures.push(error); retain(`${selected}: context close failure`, describe(error)); }
  }
  if (failures.length) throw new AggregateError(failures, `${selected}: scenario/cleanup failures retained independently`);
}
async function useful(page: Page, generation: 'A' | 'B', expectedCount = 1) {
  await page.getByRole('button', { name: `${generation} action`, exact: true }).click();
  await page.waitForFunction(({ generation, expectedCount }) =>
    document.querySelector(`[data-testid="output-${generation}"]`)?.textContent === `${generation} useful ${expectedCount}`,
  { generation, expectedCount });
  const actual = await page.getByTestId(`output-${generation}`).textContent();
  check(actual === `${generation} useful ${expectedCount}`, `${generation}: real page action changes visible output`);
}
async function installA(page: Page) {
  const added = await page.evaluate(() => window.probe.add('A'));
  check(added.status === 'fulfilled', 'A public add fulfilled');
  await useful(page, 'A');
  const before = await page.evaluate(() => window.probe.snapshot());
  check(before.pageGeneration === 'A', 'A registered through actual public registry');
  check(before.extensionGenerations.join() === 'A', 'A exact extension reference is registered');
}

test('Piral: actual readiness and delayed registration disposal boundary', { timeout: 60_000 }, async () => {
  await fresh('raw-failure', async page => {
    await installA(page);
    const added = await page.evaluate(() => window.probe.add('B')); retain('P1 action', added);
    check(added.status === 'fulfilled', 'P1: public action fulfills despite setup rejection');
    await page.getByTestId('page-A').waitFor({ state: 'detached' });
    check(await page.getByTestId('page-B').count() === 0, 'P1: no useful B page');
    const observed = await page.evaluate(() => window.probe.dispatch()); retain('P1 native/state', observed);
    check(observed.pageGeneration === null && observed.extensionGenerations.length === 0, 'P1: A managed contributions already removed');
    check(observed.hits.A === 0 && observed.hits.B === 1, 'P1: failed candidate listener remains independently observable');
    const retained = await page.evaluate(() => window.probe.callRetained()); retain('P1 retained callback', retained);
    check(retained.retainedCalls === 1, 'P1: captured A callable still executes independently of registration');
    check(consoleMessages.some(entry => entry.scenario === 'raw-failure' && entry.text.includes('B: deliberate readiness rejection')), 'P1: actual Piral error log retained');
    completed.push('P1');
  });
  await fresh('raw-disposer', async page => {
    await installA(page);
    const added = await page.evaluate(() => window.probe.add('B')); retain('P2 action', added);
    check(added.status === 'fulfilled', 'P2: B add fulfills while old disposer gate is closed');
    await useful(page, 'B');
    await page.getByTestId('extension-B').waitFor({ state: 'visible' });
    const before = await page.evaluate(() => window.probe.snapshot()); retain('P2 before old disposer', before);
    check(before.pageGeneration === 'B' && before.extensionGenerations.join() === 'B', 'P2: public B registration and exact extension identity');
    check(!before.events.includes('A: delayed returned disposers invoked'), 'P2: old disposer has not run before useful B');
    const after = await page.evaluate(() => window.probe.releaseOldDisposers()); retain('P2 after old disposer', after);
    await page.getByTestId('page-B').waitFor({ state: 'detached' });
    check(after.pageGeneration === null, 'P2: delayed route-only disposer removed actual B registration');
    check(after.extensionGenerations.join() === 'B', 'P2: exact-reference extension disposal preserved B');
    check(await page.getByTestId('extension-B').isVisible(), 'P2: preserved B extension still renders independently of lost page');
    completed.push('P2');
  });
});

test('Piral + public Resources: candidate ownership and exact old-scope debt', { timeout: 60_000 }, async () => {
  await fresh('bridge-failure', async page => {
    await installA(page);
    const added = await page.evaluate(() => window.probe.add('B')); retain('B1 action', added);
    const ready = await page.evaluate(() => window.probe.readiness('B')); retain('B1 readiness', ready);
    check(added.status === 'fulfilled' && ready.status === 'rejected', 'B1: readiness rejection remains separate from fulfilled action');
    check(ready.message === 'B: deliberate readiness rejection', 'B1: original candidate failure retained');
    const before = await page.evaluate(() => window.probe.dispatch()); retain('B1 before candidate close', before);
    check(before.pageGeneration === null && before.hits.B === 1, 'B1: actual destructive registration boundary and acquired candidate listener');
    const closed = await page.evaluate(() => window.probe.closeCandidate()); retain('B1 candidate scope result', closed);
    check(closed.complete && closed.settled && closed.debts.length === 0, 'B1: real Resources candidate close completes');
    const after = await page.evaluate(() => window.probe.dispatch()); retain('B1 after candidate close', after);
    check(after.hits.B === before.hits.B, 'B1: native B listener no longer executes');
    await page.getByTestId('page-A').waitFor({ state: 'detached' });
    check(await page.getByTestId('page-B').count() === 0, 'B1: bridge makes no restored predecessor or useful candidate claim');
    completed.push('B1');
  });
  await fresh('bridge-debt', async page => {
    await installA(page);
    const added = await page.evaluate(() => window.probe.add('B')); retain('B2 action', added);
    const ready = await page.evaluate(() => window.probe.readiness('B')); retain('B2 readiness', ready);
    check(added.status === 'fulfilled' && ready.status === 'fulfilled', 'B2: B setup actually fulfilled');
    await useful(page, 'B');
    const debt = await page.evaluate(() => window.probe.oldCloseReport()); retain('B2 actual old-scope report', debt);
    check(!debt.complete && debt.settled && debt.debts.length === 1 && debt.debts[0]?.state === 'failed', 'B2: real Resources failure debt remains');
    check(debt.originalCause && debt.debts[0]?.cause === 'A: deliberate cleanup debt', 'B2: exact original cleanup error retained');
    const before = await page.evaluate(() => window.probe.dispatch()); retain('B2 native/state', before);
    check(before.pageGeneration === 'B' && before.hits.A === 1 && before.hits.B === 1, 'B2: useful B and physically live A debt coexist');
    completed.push('B2');
    const retried = await page.evaluate(() => window.probe.retryOldCleanup()); retain('B3 same old-scope retry', retried);
    check(retried.complete && retried.settled && retried.debts.length === 0, 'B3: explicit retry completes old scope');
    const original = await page.evaluate(() => window.probe.oldCloseReport()); retain('B3 retained first report', original);
    check(!original.complete && original.originalCause && original.debts.length === 1, 'B3: successful retry does not rewrite original debt evidence');
    const after = await page.evaluate(() => window.probe.dispatch()); retain('B3 native/state', after);
    check(after.hits.A === before.hits.A && after.hits.B === before.hits.B + 1, 'B3: only exact A listener is removed');
    check(after.pageGeneration === 'B' && after.extensionGenerations.join() === 'B', 'B3: B managed ownership preserved');
    await useful(page, 'B', 2);
    completed.push('B3');
  });
});
