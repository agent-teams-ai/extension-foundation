export type Generation = 'A' | 'B';
export type Scenario = 'raw-failure' | 'raw-disposer' | 'bridge-failure' | 'bridge-debt';
export type Outcome = { status: 'fulfilled' | 'rejected'; message: string | null };
export type Report = {
  complete: boolean;
  settled: boolean;
  debts: { path: readonly string[]; state: string; cause: string | null }[];
  originalCause: boolean;
};
export type Snapshot = {
  loading: boolean;
  pageGeneration: Generation | 'other' | null;
  extensionGenerations: (Generation | 'other')[];
  hits: Record<Generation, number>;
  retainedCalls: number;
  events: string[];
};
export type CleanupReceipt = { reports: Report[]; listenersAbsent: boolean; hitsBefore: Record<Generation, number>; hitsAfter: Record<Generation, number> };
export interface Probe {
  ready: Promise<void>;
  add(generation: Generation): Promise<Outcome>;
  snapshot(): Snapshot;
  dispatch(): Snapshot;
  callRetained(): Snapshot;
  releaseOldDisposers(): Promise<Snapshot>;
  readiness(generation: Generation): Promise<Outcome>;
  closeCandidate(): Promise<Report>;
  oldCloseReport(): Promise<Report>;
  retryOldCleanup(): Promise<Report>;
  dispose(): Promise<CleanupReceipt>;
}
declare global {
  interface Window {
    probe: Probe;
  }
}
