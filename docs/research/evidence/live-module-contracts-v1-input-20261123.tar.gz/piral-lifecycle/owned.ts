import { createScope, type CloseReport } from '@get-modular/resources';
import type { Generation, Outcome, Report } from './types.ts';

export const message = (cause: unknown): string => cause instanceof Error ? cause.message : String(cause);

// Exact scope handle + observations; Resources owns cleanup, debt and retry.
export function ownListener(
  generation: Generation,
  target: EventTarget,
  onEvent: () => void,
  record: (event: string) => void,
  failCleanup: boolean,
) {
  const scope = createScope({ name: generation });
  const readiness = Promise.withResolvers<Outcome>();
  const cleanupError = new Error(`${generation}: deliberate cleanup debt`);
  let permitted = !failCleanup;
  let firstClose: Promise<CloseReport> | undefined;
  const project = (report: CloseReport): Report => ({
    complete: report.complete,
    settled: report.settled,
    debts: report.debts.map(debt => ({
      path: debt.path,
      state: debt.state,
      cause: debt.state === 'failed' ? message(debt.cause) : null,
    })),
    originalCause: report.debts.some(debt => debt.state === 'failed' && debt.cause === cleanupError),
  });
  return {
    readiness: readiness.promise,
    async setup(continuation: () => Promise<void>) {
      try {
        await scope.resources.setup({
          name: 'native-listener',
          setup() { target.addEventListener('probe', onEvent); record(`${generation}: acquired`); return onEvent; },
          cleanup(listener) {
            record(`${generation}: cleanup started`);
            if (!permitted) throw cleanupError;
            target.removeEventListener('probe', listener);
            record(`${generation}: cleanup removed listener`);
          },
        });
        await continuation();
        readiness.resolve({ status: 'fulfilled', message: null });
      } catch (cause) {
        readiness.resolve({ status: 'rejected', message: message(cause) });
        throw cause;
      }
    },
    startClose() {
      if (firstClose) {
        record(`${generation}: repeated teardown observed`);
        throw new Error(`${generation}: bounded fixture expected exactly one teardown; original close retained`);
      }
      firstClose = scope.control.close();
    },
    async firstReport() {
      if (!firstClose) throw new Error('No actual teardown close was observed');
      return project(await firstClose);
    },
    async close() { return project(await scope.control.close()); },
    async retry() { permitted = true; return project(await scope.control.close()); },
    async dispose() { permitted = true; return project(await scope.control.close()); },
  };
}
