import { defineConfig } from 'vite';
import codegen from 'vite-plugin-codegen';

export default defineConfig({
  plugins: [codegen()],
  server: { host: '127.0.0.1', port: 4397, strictPort: true },
  preview: { host: '127.0.0.1', port: 4397, strictPort: true },
});
