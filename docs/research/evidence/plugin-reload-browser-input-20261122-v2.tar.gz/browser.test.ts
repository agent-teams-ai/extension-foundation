import assert from 'node:assert/strict';
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { test } from 'node:test';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import type { ReloadProbe } from './fixture/probe.ts';

const directory = path.dirname(fileURLToPath(import.meta.url));
const evidence = path.join(directory, 'evidence');
const fixture = path.join(directory, 'fixture');

type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };
interface Comparison { name: string; actual: JsonValue; expected: JsonValue; }

async function snapshot(page: Page) {
  return page.evaluate(() => ({
    documentId: window.reloadProbe.documentId,
    trace: [...window.reloadProbe.trace],
    volatileAlive: window.reloadProbe.volatileAlive,
  }));
}

async function waitForTrace(page: Page, entry: string): Promise<void> {
  await page.waitForFunction((expected) => window.reloadProbe.trace.includes(expected), entry);
}

async function applyIndependentEdit(variant: string, target: string): Promise<void> {
  // This is an independent-edit profile, not a high-frequency watcher guarantee.
  // Pinned Chokidar suppresses same-path change events within 50 ms. Separate
  // completed browser scenarios by 100 ms, then write in place (fs.cp unlinks).
  await delay(100);
  await writeFile(target, await readFile(path.join(fixture, variant)));
}

test('native React and Vite distinguish retained state, remount and failed activation', { timeout: 120_000 }, async () => {
  await mkdir(evidence, { recursive: true });
  const work = await mkdtemp(path.join(directory, '.fixture-run-'));
  await cp(fixture, work, { recursive: true });
  await cp(path.join(fixture, 'Plugin.v1.tsx'), path.join(work, 'Plugin.tsx'));
  await cp(path.join(fixture, 'volatile.v1.ts'), path.join(work, 'volatile.ts'));
  let server: ViteDevServer | undefined;
  let browser: Browser | undefined;
  let page: Page | undefined;
  const comparisons: Comparison[] = [];
  const observations: Record<string, JsonValue> = {};
  const consoleMessages: string[] = [];
  const pageErrors: string[] = [];
  const watchEvents: { event: string; file: string; at: number }[] = [];
  const compare = (name: string, actual: JsonValue, expected: JsonValue) => {
    comparisons.push({ name, actual, expected });
    assert.deepEqual(actual, expected, name);
  };
  try {
    server = await createServer({
      configFile: false,
      root: work,
      plugins: [react()],
      server: { host: '127.0.0.1', port: 0, strictPort: false },
      logLevel: 'info',
    });
    server.watcher.on('all', (event, file) => {
      if (file === path.join(work, 'Plugin.tsx') || file === path.join(work, 'volatile.ts')) {
        watchEvents.push({ event, file: path.basename(file), at: performance.now() });
      }
    });
    await server.listen();
    const address = server.httpServer?.address();
    assert(address && typeof address !== 'string');
    browser = await chromium.launch({ headless: true });
    observations.browserVersion = browser.version();
    observations.nodeVersion = process.version;
    page = await browser.newPage();
    page.setDefaultTimeout(15_000);
    page.on('console', (message) => consoleMessages.push(`${message.type()}: ${message.text()}`));
    page.on('pageerror', (error) => pageErrors.push(error.message));
    await page.goto(`http://127.0.0.1:${address.port}`);
    await waitForTrace(page, 'plugin:v1:setup');
    const original = await snapshot(page);
    const originalButton = await page.getByTestId('plugin-value').elementHandle();
    assert(originalButton);
    await page.getByTestId('draft').fill('host draft retained across plugin changes');
    await page.getByTestId('plugin-value').click();
    await page.getByTestId('plugin-value').click();
    compare('initial local state after two independent user actions', await page.getByTestId('plugin-value').textContent(), '13');
    await page.evaluate(() => {
      const start = window.reloadProbe.startSlow;
      if (!start) throw new Error('Old callback not initialized');
      window.reloadProbe.pendingSlow = start();
    });
    await waitForTrace(page, 'slow:v1:started');

    await applyIndependentEdit('Plugin.v2.tsx', path.join(work, 'Plugin.tsx'));
    await page.waitForFunction(() => document.querySelector('[data-testid="plugin-version"]')?.textContent === 'v2');
    await waitForTrace(page, 'plugin:v2:setup');
    const afterCompatible = await snapshot(page);
    compare('compatible update keeps document', afterCompatible.documentId, original.documentId);
    compare('compatible update keeps host draft', await page.getByTestId('draft').inputValue(), 'host draft retained across plugin changes');
    compare('compatible update keeps local state', await page.getByTestId('plugin-value').textContent(), '13');
    compare('compatible update keeps actual button identity', await page.getByTestId('plugin-value').evaluate((element, previous) => element === previous, originalButton), true);
    const cleanupIndex = afterCompatible.trace.indexOf('plugin:v1:cleanup');
    const setupIndex = afterCompatible.trace.indexOf('plugin:v2:setup');
    compare('empty-dependency effect cleanup is observed', cleanupIndex >= 0, true);
    compare('empty-dependency effect cleans up before new setup', cleanupIndex < setupIndex, true);
    const beforeEvent = afterCompatible.trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-plugin-event')));
    compare('exactly current real listener responds', (await snapshot(page)).trace.slice(beforeEvent), ['plugin:v2:event']);
    const slowResult = await page.evaluate(async () => {
      const release = window.reloadProbe.releaseSlow;
      const pending = window.reloadProbe.pendingSlow;
      if (!release || !pending) throw new Error('Missing old captured callback');
      release();
      return await pending;
    });
    compare('old captured callback can finish after HMR cleanup', slowResult, 'v1');
    compare('old completion is actually observed after new setup', (await snapshot(page)).trace.indexOf('slow:v1:completed') > afterCompatible.trace.indexOf('plugin:v2:setup'), true);

    await applyIndependentEdit('Plugin.v3.tsx', path.join(work, 'Plugin.tsx'));
    await page.waitForFunction(() => document.querySelector('[data-testid="plugin-version"]')?.textContent === 'v3');
    await waitForTrace(page, 'plugin:v3:setup');
    compare('new hook resets component local state', await page.getByTestId('plugin-value').textContent(), '11');
    compare('new hook replaces actual button identity', await page.getByTestId('plugin-value').evaluate((element, previous) => element !== previous, originalButton), true);
    compare('component remount keeps parent draft', await page.getByTestId('draft').inputValue(), 'host draft retained across plugin changes');
    compare('component remount keeps document', (await snapshot(page)).documentId, original.documentId);
    const remountTrace = (await snapshot(page)).trace;
    compare('remount cleanup observed', remountTrace.includes('plugin:v2:cleanup'), true);
    const beforeRemountEvent = remountTrace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-plugin-event')));
    compare('remount leaves one actual listener', (await snapshot(page)).trace.slice(beforeRemountEvent), ['plugin:v3:event']);

    await page.getByTestId('plugin-value').click();
    const beforeInitializerButton = await page.getByTestId('plugin-value').elementHandle();
    assert(beforeInitializerButton);
    await applyIndependentEdit('Plugin.v4.tsx', path.join(work, 'Plugin.tsx'));
    await page.waitForFunction(() => document.querySelector('[data-testid="plugin-version"]')?.textContent === 'v4');
    await waitForTrace(page, 'plugin:v4:setup');
    observations.changedInitializerValue = await page.getByTestId('plugin-value').textContent();
    observations.changedInitializerKeptElement = await page.getByTestId('plugin-value').evaluate((element, previous) => element === previous, beforeInitializerButton);
    observations.changedInitializerClassification = observations.changedInitializerKeptElement ? 'preserved-by-selected-transform' : 'remounted-by-selected-transform';
    compare('selected transform remounts after initializer signature change', observations.changedInitializerKeptElement, false);
    compare('initializer signature change resets local state', observations.changedInitializerValue, '99');
    compare('initializer change still keeps host draft', await page.getByTestId('draft').inputValue(), 'host draft retained across plugin changes');
    compare('initializer change still keeps document', (await snapshot(page)).documentId, original.documentId);

    const beforeVolatile = (await snapshot(page)).trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-volatile-event')));
    compare('old raw-module resource works before update', (await snapshot(page)).trace.slice(beforeVolatile), ['volatile:v1:event']);
    await applyIndependentEdit('volatile.broken.ts', path.join(work, 'volatile.ts'));
    await waitForTrace(page, 'volatile:v1:dispose');
    await waitForTrace(page, 'volatile:accept-undefined');
    const afterFailure = await snapshot(page);
    compare('candidate failure has already disposed old resource', afterFailure.volatileAlive, false);
    const beforeFailedEvent = afterFailure.trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-volatile-event')));
    compare('old real listener is absent after failed import', (await snapshot(page)).trace.slice(beforeFailedEvent), []);
    compare('failed raw-module update keeps host document', afterFailure.documentId, original.documentId);
    compare('failed raw-module update keeps unrelated draft', await page.getByTestId('draft').inputValue(), 'host draft retained across plugin changes');
    observations.activationFailureConsole = consoleMessages.filter((entry) => entry.includes('intentional candidate activation failure'));
    compare('actual candidate evaluation error is visible', consoleMessages.some((entry) => entry.includes('intentional candidate activation failure')) || pageErrors.some((entry) => entry.includes('intentional candidate activation failure')), true);

    await applyIndependentEdit('volatile.v3.ts', path.join(work, 'volatile.ts'));
    await waitForTrace(page, 'volatile:v3:setup');
    compare('recovery creates new resource', (await snapshot(page)).volatileAlive, true);
    const beforeRecoveryEvent = (await snapshot(page)).trace.length;
    await page.evaluate(() => window.dispatchEvent(new Event('research-volatile-event')));
    compare('recovery selects new real listener', (await snapshot(page)).trace.slice(beforeRecoveryEvent), ['volatile:v3:event']);
    observations.beforeFullReload = await snapshot(page);
    await page.screenshot({ path: path.join(evidence, 'after-hmr.png'), fullPage: true });
    await page.reload();
    await waitForTrace(page, 'plugin:v4:setup');
    compare('full reload makes a new document', (await snapshot(page)).documentId !== original.documentId, true);
    compare('clean start uses current initializer', await page.getByTestId('plugin-value').textContent(), '99');
    compare('full reload resets in-memory host draft', await page.getByTestId('draft').inputValue(), '');
    compare('no unexpected page errors', pageErrors.filter((message) => !message.includes('intentional candidate activation failure')), []);
    observations.afterFullReload = await snapshot(page);
  } finally {
    if (page && !page.isClosed()) {
      observations.final = await snapshot(page).catch((error: unknown) => ({ snapshotError: String(error) }));
    }
    const result = { comparisons, observations, consoleMessages, pageErrors, watchEvents };
    await writeFile(path.join(evidence, 'observations.json'), JSON.stringify(result, null, 2) + '\n');
    // Retain bounded diagnostic facts in the native job log if upload fails.
    process.stdout.write(`RELOAD_PROBE_RESULT ${JSON.stringify(result)}\n`);
    await writeFile(path.join(evidence, 'fixture-final-source.json'), JSON.stringify({
      plugin: await readFile(path.join(work, 'Plugin.tsx'), 'utf8'),
      volatile: await readFile(path.join(work, 'volatile.ts'), 'utf8'),
    }, null, 2) + '\n');
    await browser?.close();
    await server?.close();
    await rm(work, { recursive: true, force: true });
  }
});

// Compile-time linkage makes the browser instrumentation part of this strict project.
const checkedProbeShape: keyof ReloadProbe = 'documentId';
void checkedProbeShape;
