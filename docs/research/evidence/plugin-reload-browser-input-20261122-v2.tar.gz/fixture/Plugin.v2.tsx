import { useEffect, useState } from 'react';
import { probe } from './probe.ts';

export function Plugin() {
  const [value, setValue] = useState(() => 11);
  useEffect(() => {
    probe.trace.push('plugin:v2:setup');
    const listener = () => { probe.trace.push('plugin:v2:event'); };
    window.addEventListener('research-plugin-event', listener);
    probe.startSlow = async () => {
      const version = 'v2';
      await new Promise<void>((resolve) => { probe.releaseSlow = resolve; });
      probe.trace.push('slow:v2:completed');
      return version;
    };
    return () => {
      window.removeEventListener('research-plugin-event', listener);
      probe.trace.push('plugin:v2:cleanup');
    };
  }, []);
  return <section>
    <h2 data-testid="plugin-version">v2</h2>
    <button data-testid="plugin-value" onClick={() => setValue(value + 1)}>{value}</button>
  </section>;
}
