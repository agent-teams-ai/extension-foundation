import { useEffect, useRef, useState } from 'react';
import { probe } from './probe.ts';

export function Plugin() {
  const [value, setValue] = useState(() => 99);
  const marker = useRef('added-hook');
  useEffect(() => {
    probe.trace.push('plugin:v4:setup');
    const listener = () => { probe.trace.push('plugin:v4:event'); };
    window.addEventListener('research-plugin-event', listener);
    return () => {
      window.removeEventListener('research-plugin-event', listener);
      probe.trace.push('plugin:v4:cleanup');
    };
  }, []);
  return <section data-marker={marker.current}>
    <h2 data-testid="plugin-version">v4</h2>
    <button data-testid="plugin-value" onClick={() => setValue(value + 1)}>{value}</button>
  </section>;
}
