export { version } from './volatile.v1.ts';
