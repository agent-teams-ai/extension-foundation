export interface ReloadProbe {
  documentId: string;
  trace: string[];
  startSlow: (() => Promise<string>) | undefined;
  releaseSlow: (() => void) | undefined;
  pendingSlow: Promise<string> | undefined;
  volatileAlive: boolean;
}

export const probe: ReloadProbe = {
  documentId: crypto.randomUUID(),
  trace: [],
  startSlow: undefined,
  releaseSlow: undefined,
  pendingSlow: undefined,
  volatileAlive: false,
};

declare global {
  interface Window {
    reloadProbe: ReloadProbe;
  }
}
window.reloadProbe = probe;
