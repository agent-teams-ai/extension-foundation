import { useEffect, useState } from 'react';
import { probe } from './probe.ts';

export function Plugin() {
  const [value, setValue] = useState(() => 11);
  useEffect(() => {
    probe.trace.push('plugin:v1:setup');
    const listener = () => { probe.trace.push('plugin:v1:event'); };
    window.addEventListener('research-plugin-event', listener);
    probe.startSlow = async () => {
      const version = 'v1';
      probe.trace.push('slow:v1:started');
      await new Promise<void>((resolve) => { probe.releaseSlow = resolve; });
      probe.trace.push('slow:v1:completed');
      return version;
    };
    return () => {
      window.removeEventListener('research-plugin-event', listener);
      probe.trace.push('plugin:v1:cleanup');
    };
  }, []);
  return <section>
    <h2 data-testid="plugin-version">v1</h2>
    <button data-testid="plugin-value" onClick={() => setValue(value + 1)}>{value}</button>
  </section>;
}
