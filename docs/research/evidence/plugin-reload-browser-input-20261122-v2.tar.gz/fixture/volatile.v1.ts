import { probe } from './probe.ts';

export const version = 'v1';
const listener = () => { probe.trace.push('volatile:v1:event'); };
window.addEventListener('research-volatile-event', listener);
probe.volatileAlive = true;
probe.trace.push('volatile:v1:setup');
if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    window.removeEventListener('research-volatile-event', listener);
    probe.volatileAlive = false;
    probe.trace.push('volatile:v1:dispose');
  });
  import.meta.hot.accept((next) => {
    probe.trace.push(next === undefined ? 'volatile:accept-undefined' : 'volatile:accept-module');
  });
}
