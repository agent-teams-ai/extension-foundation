import { createRoot } from 'react-dom/client';
import { Host } from './Host.tsx';
import './volatile.ts';

const target = document.getElementById('root');
if (!target) throw new Error('Missing fixture root');
createRoot(target).render(<Host />);
