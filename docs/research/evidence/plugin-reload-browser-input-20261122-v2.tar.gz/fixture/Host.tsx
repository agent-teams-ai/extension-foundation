import { useState } from 'react';
import { Plugin } from './Plugin.tsx';

export function Host() {
  const [draft, setDraft] = useState('');
  return <main>
    <h1>Live plugin update research</h1>
    <label>Host-owned draft
      <input data-testid="draft" value={draft} onChange={(event) => setDraft(event.target.value)} />
    </label>
    <Plugin />
  </main>;
}
