export const version = 'broken';
if (import.meta.hot) import.meta.hot.accept();
throw new Error('intentional candidate activation failure');
