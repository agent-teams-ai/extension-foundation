# Read-only recovery audit — plugin choice deepening

Audit date: 2026-11-06 UTC. Source task root: `/workspace/scratch/f863b9d38368/plugin-decision-deepening-2026-11-06`. This audit inspected the supplied visible handoff, normal research artifacts, retained source snapshots, the relevant source checkouts, the EF staged documentation delta, and package metadata. It did not inspect internal tool/conversation logs, credentials, unrelated work, or mutate any repository. The only new file is this recovery report.

## Outcome

The substantive requested research/deepening is already complete locally, including reviewed plans, a deliberately bounded experiment, independent criticism, corrected recommendations, governed synthesis, retained evidence archive and passing standalone documentation gates. The local authoring checkout has eight staged files and still has `HEAD=99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d`. Local state alone therefore does not establish publication of this newest packet. Root must compare the prepared tree with the live PR branch, publish if absent, and retain exact-head publication/CI evidence. No new product implementation, broad experiment campaign, or decision adoption is needed to complete the latest user request.

The most material result is a correction to the previous recommendation, not reinforcement of it:

- The earlier contained-provider-first `1A` recommendation overlooked accepted AR ADR-0091 at the **same source revision**. Current admitted provider work is the persistent interactive Claude/session extraction with runtime-owned types and an ordinary external implementation. It freezes contained-turn and does not reopen ordinary Codex. This is one customization family, not completion of the whole plugin vision.
- The earlier permanent-seal/wait/defer wording can create indefinite admission outage and can fence accepted-but-unprepared work. Actual shutdown remains irreversible. The smallest availability-preserving candidate is to defer before irreversible shutdown, conditional on a real owner-proved atomic quiescence/stop operation; that operation is not established by the inspected source. Deliberate maintenance/cutoff and reversible pause remain different, unselected product policies.
- Old `P0 / I150–350` update estimates and the contained-first shortlist are explicitly retired as current delivery estimates. New numerical bands are hypothetical local bounded-turn mechanics with missing prerequisites and low sizing confidence. Persistent-session delivery remains unestimated.

## Recovered deliverables and review closure

The eight staged EF paths are:

1. `docs/README.md` — adds the new research entry.
2. `docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md` — replaces the mistaken first-slice/update brief, preserves research versus adoption and existing open decisions.
3. `docs/research/plugin-choice-deepening-2026-11-06.md` — 308-line maintained synthesis, current authority, nine industry systems, experiment results, alternatives, scoped LOC/scores and limitations.
4. `docs/research/plugin-research-review-and-decision-record.md` — current correction and authority navigation.
5. `docs/research/plugin-system-research-reference.md` — updated current synthesis and owner navigation.
6. `docs/research/static-composition-and-controlled-restart-validation.md` — distinguishes current accepted direction from obsolete hypotheses.
7. `docs/research/evidence/plugin-deepening-20261106.json` — member manifest.
8. `docs/research/evidence/plugin-deepening-20261106.tar.gz` — complete 44-file research packet.

The staged delta is 658 insertions and 191 deletions plus the archive. No production, integration, accepted ADR, dependency, lockfile or normal repository test source is changed.

Retained reports include `seam-research.md`, `update-research.md`, `process-plugin-crosscheck.md`, `update-sizing-supplement.md`, `update-seam-cross-review.md`, `plan-critique.md`, `final-adversarial-review.md`, and `root-dispositions.md`. The retained account names two GPT-6.1 Sol xhigh investigators, one GPT-6 Astra xhigh plan/result critic and a second independent GPT-6 Astra xhigh final critic, with investigator cross-review and root source checking. This audit relies on their normal saved reports for that historical agent census; it did not access internal execution logs.

Both critics reviewed the actual governed draft. Final corrections were closed: the shared-Host paragraph now concerns an **additional** capability beyond accepted ADR-0091; the future allowance separates product integration from fixture tests; grouped undefined source keys were converted to defined clickable references. `plan-critique.md` ends in final PASS and requests no additional experiment. `final-adversarial-review.md` passes substantive synthesis, with its one requested authority wording correction visibly present in final OD-003.

The industry coverage in the synthesis is Backstage, VS Code, HashiCorp go-plugin, Vault, NGINX, Envoy, systemd, Kubernetes and Erlang/OTP. The reports retain exact source/release identities or moving-document status and counterexamples. This audit checks preservation and internal consistency; it does not claim fresh independent retrieval of every upstream source.

## Experiment actually executed

Only three new TypeScript consumers exist, totaling 11 lines. They contain ordinary type imports and assignment checks, with no casts, suppressions, copied replacement interface or runtime implementation. Exact source barrels are aliased intentionally. TypeScript 7.0.2 / Node 24.22.1 ran strict `noEmit`, `skipLibCheck:false`, `exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`, with no ambient package types.

| Probe | Retained result | Supported conclusion |
| --- | --- | --- |
| AR contract to itself | Exit 0 | Setup and current contract closure compile |
| Legacy external contract to AR | Exit 1, TS2322 | External returned event union admits `compaction` absent from AR |
| AR contract to legacy external | Exit 1, TS2322 | Legacy denied-question reply does not meet AR parameter contract |

The external source is accessible `old-provider-implementations` PR1 at `7573a50842c3eeacb473f9d97d40f3ddf6ac0cf9`. Its retained PR body explicitly concerns legacy Desktop and excludes future Runtime/Orchestrator. It is **not established as the ADR-0091 implementation**. Thus rejection is exploratory exact-snapshot compatibility evidence, not an intended-integration blocker or supported-release regression. No shim, API repair, merge or contract-owner move follows from it.

The initial packed/Host plan was narrowed before execution because an intended artifact pair was unavailable. Source rejection triggered the reviewed stop. No installed-package qualification, provider SDK compilation, Host execution, provider/account call, update runtime simulation or new capacity run happened. Reusing prior RST experiments is explicitly historical, with the earlier scope intact. The update plan's no-new-execution disposition is justified: a synthetic reversible gate would merely validate an invented interface absent from the real owner.

## Independent verification performed in this audit

- Verified compressed archive bytes and SHA-256: **86,137 bytes**, SHA-256 `4a12d8236bd66cd023a79950c197dff13c4d98597c8ec12866ba8ae5e6928756`.
- Verified **44/44** archive member names, lengths and SHA-256 values; exact member set; **371,670** uncompressed bytes; every member equals its current original task file.
- Verified all **8/8** publication-input entries against current file size, SHA-256 and Git blob identity; all eight equal staged bytes.
- Verified prepared tree `ac66e883d1cf81e8829a3e671792f941256fbfd4` exists locally and matches the tracked worktree and index. Its recorded parent is `99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d`.
- Independently verified all **11/11** original source/signature snapshots against exact Git commits, Git blob hashes and SHA-256 values. The compile closure is six AR files plus three legacy contract files; two additional files prove the public Claude facade/factory annotation.
- Verified all **6/6** retained wrapper/native compiler file hashes still match, including both package versions 7.0.2.
- Verified all six raw stdout/stderr file hashes match `results.json`; result fields point to those filenames. Confirmed exit codes `0,1,1`, one semantic TS2322 in each negative case, and 11 consumer lines.
- Read accepted ADR-0091's authority/packaging/close/restore claims and checked the corresponding shutdown source: the contained owner sets `disposed` on seal; preparation/process creation consult that flag; Host disposal does not reset it; interactive cleanup retains `closing`.
- `git diff --cached --check` passes.

No compiler rerun was needed: all relevant inputs remain unchanged and the prior final reviewer explicitly requested stopping after decisive evidence.

## Gates, preservation gap and remaining work

`docs-protocol-check.log` records successful catalog/adoption validation (85 documents), markdown/spelling quality (91 files, zero issues), and **8/8** contract tests with zero failures/cancellations/skips. The earlier `docs-protocol-check-first.log` preserves the initial spelling failures; they were corrected in final document bytes. These are task-level retained logs, not new audit executions.

The research archive contains briefs, plans, reports, source ledgers, snapshots and raw probe inputs/results. It deliberately does **not** contain the final/initial Docs logs or `publication-inputs.json`, which were produced after archive freeze. Preserve those and exact published commit/hosted checks in a separate publication-evidence packet or receipt rather than implying the existing 44-member archive contains them. Updating the frozen research archive is not needed merely to add later delivery receipts.

There is one untracked Docs Protocol temporary file in the authoring tree. It is not in the eight-file publication inventory. Do not stage it or manually alter tool transaction evidence. If the owner workflow reports recovery, use the documented `pnpm docs:doctor` route before any recovery action; this audit did not open or mutate that temporary file.

The repository requires general `check:changed`, `check:fast` and `check`, but root-dispositions records the known compiler-policy conflict. Read-only package resolution confirms:

`@agent-teams/engineering-foundation@1.7.2` → `@microsoft/api-extractor@7.58.12` → `typescript@5.9.3`.

The retained organization standard forbids initializing an older embedded compiler and requires reporting the exact blocked gate. Consequently the prior root deliberately did not execute Foundation's affected entry routes, detach/assert-registry, or claim local complete gates passed. Do not silently run these now or change pinned dependencies merely to green this documentation delivery. A hosted CI success also does not establish resolution of that compiler-policy gap.

Root-owned completion steps:

1. Read live PR55 head/draft status and compare it to the retained parent/tree. If the tree is already published, reuse the exact commit and inspect its checks. If absent, publish the eight verified files atomically to the continuing branch using the authorized GitHub route, preserving the live head.
2. Preserve exact input tree/parent, final commit, PR state and hosted Docs/general CI results plus both local Docs logs. Report the embedded-compiler gap separately from hosted status.
3. If any publication file changes, update the relevant publication hash record and rerun only required affected documentation gates. With identical bytes, use existing exact-input evidence; do not repeat the probes.
4. Final user answer should explicitly correct the previous `1A + 2A` recommendation, explain why critics missed ADR-0091 at the same pin, state conditional update tradeoffs, distinguish unknown session-delivery cost from hypothetical bounded-turn numbers, link the retained research and state PR remains draft/unmerged.

Useful exact read-only commands from the authoring checkout are `git status --short`, `git diff --cached --check`, `git diff --cached --stat`, `git diff --name-only ac66e883d1cf81e8829a3e671792f941256fbfd4 --`, and `git diff --cached --name-only ac66e883d1cf81e8829a3e671792f941256fbfd4 --`. If docs are changed, the intended standalone route is `pnpm docs:info`, then the applicable Docs Protocol flow, then `pnpm docs:protocol:check`; this avoids the known eager Foundation compiler path but does not substitute for an unpassed general gate.

No outstanding substantive research blocker was found. Product implementation of unselected maintenance behavior, new broad plugin capabilities, hostile isolation or a new Host/runtime would exceed the latest authorized research scope. Identifying the intended provider artifact is a follow-on provenance prerequisite before actual integration, not a reason to repair the unrelated legacy PR or reopen the accepted provider direction.

## Later cross-audit addendum — corrected recovery synthesis

This is a **later evidence review**, after the original-state audit above. It does not retroactively broaden that first audit or rewrite its recorded tree, hashes or publication status. Read the complete new `reviews/spi-audit.md` and `reviews/update-policy-audit.md`, and the revised maintained synthesis and OD-003 under `/workspace/scratch/58e9c088d2ee/extension-foundation`. Also inspected the actual B donor README, entrypoint and draft types, the canonical driver contract, ordinary Host disposal and its ownership fixture. No new compiler, runtime, package, provider or upstream scenario was executed.

**Disposition: pass the revised research content.** The additional reviewers found material refinements beyond the original preservation audit, now reflected in the governed documents:

- The ADR-named B donor is **known source**, not an unknown implementation to search for. I independently counted its six Claude TypeScript files: 63 + 31 + 63 + 75 + 52 + 236 = **520 physical lines**, and checked its TEST-only README. The document distinguishes that existing donor from an unverified external production artifact. Factory shape, `sdk-consumed` versus `client-consumed`, capabilities/checkpoint reference and lost failed-open cleanup result are concrete differences. The proposed single canonical migration preserves existing owner custody; it does not claim a demonstrated deployed leak or authorize implementation in this research task.
- New/changed adaptation ranges remain conditional and separate: P115–255, I80–190 and T280–600. The existing 520 donor lines are excluded from new work; missing owner prerequisites invalidate these bands; actual whole delivery remains unknown. The older P0/I100–250/T200–500 allowance is explicitly narrower and overlapping, not additive. Sizing confidence stays 4/10 for donor adaptation and 3/10 for hypothetical bounded-turn update mechanics. Reliability scores concern named achievable contracts **after qualification**; no current runtime reliability is inferred from compilation.
- The legacy exploratory type probe remains exactly three original invocations/11 lines, with one setup pass and two semantic rejections. Neither new donor inspection nor source reading is presented as a new execution. No fourth check, package qualification, runtime proof or update experiment is invented.
- The revised ordinary-update discussion now distinguishes durable operation uncertainty from physical/authority retirement. I checked `releaseOrdinaryOwnership` and the fixture that permits a later successful disposal while durable status stays `reconcile_required`. The synthesis preserves the contract-violation exception, prohibits unsupported replay and explicitly declines to transplant ordinary Codex rules into interactive sessions. Quiescence no longer means absence of every resource handle or universal terminalization of all historical operations.
- The systemd v258 reload-timeout counterexample and subsequent fix are attributed to the new source audit. The revised synthesis no longer promotes that manual's intended completion behavior into unconditional implementation evidence. I did not independently reretrieve or run systemd; this cross-audit checks the retained review's precise disposition and the synthesis's faithful qualification.
- Durable pending-update crash outcomes and atomic admission remain explicit unqualified prerequisites, outside the local-mechanics estimates. Pre-seal deferral remains a conditional availability/work-preservation recommendation; maintenance/cutoff and reversible pause remain unselected alternatives with separate interruption, starvation and custody consequences.

Historical evidence remains intact: the original `plugin-deepening-20261106.tar.gz` and `.json` in the new checkout are byte-identical to the original packet (archive SHA-256 `4a12d8236bd66cd023a79950c197dff13c4d98597c8ec12866ba8ae5e6928756`; manifest SHA-256 `6595b322fcf4c752ce5086a1712595ea4470abbb27346a8eb56d1b677b62fccb`). Earlier recommendations are still available as history and expressly corrected in maintained navigation. Accepted ADRs and production code are not changed by these corrections.

At this review cut the new recovery tar/JSON links are intentionally **planned**: neither file yet exists. Consequently this pass covers substantive content and preservation of the old packet, not completion of the later archive, updated documentation gates, a new publication tree, pushed commit or hosted CI. Root must finish the planned archive/manifest with these later reviews, source snapshots, correction dispositions and original failed/passing Docs logs, verify its links/hashes, run the changed-document gates and report the actual exact-head publication receipts. No additional research or experiment is requested by this cross-audit.
