# Independent audit of the ordinary update policy

Review date: **2026-11-06 UTC**. Status: **research review; proposals remain unselected**. No production architecture, repository file, dependency, provider execution, runtime experiment or external GitHub state was changed. This review independently read the current update report, sizing supplement, reviewed spike plan, prior critiques, relevant AR authority/source, and selected archived RST results. Primary industry sources were checked again.

**Disposition:** the revised recommendation is substantially better than the original seal/wait/defer wording, and stopping without a new update spike is justified. Preserve its conditional ranking. Two corrections deserve explicit inclusion in synthesis: the exact cited systemd 258 path has a known timeout-liveness counterexample, and durable operation reconciliation must not be collapsed into physical Host custody. Neither correction selects 2A or 2B for the owner.

## 1. Material correction: systemd 258 has a documented reload-timeout loop

The current industry paragraph accurately identifies separate reload and service results, but its statement about reload timeout needs a concrete exception. The systemd 258 manual says a reload timeout fails that reload while the service continues. The inspected timeout branch records `SERVICE_FAILURE_TIMEOUT` and calls `service_enter_running`. That call name does **not** prove the reload attempt reaches a finished state. [S1, S2]

Independent inspection of the same v258 `service.c` blob, `c8cda0609942fcda179a8d62828976d9c3fdd71c`, shows the following path:

1. The timer handles `SERVICE_RELOAD_NOTIFY`, kills any reload control process, records reload timeout, and calls `service_enter_running`.
2. If the main service is good and its notification state remains `NOTIFY_RELOADING`, that helper calls `service_enter_reload_by_notify`.
3. That function rearms the start timeout and enters `SERVICE_RELOAD_NOTIFY` again.

Upstream issue [#37515](https://github.com/systemd/systemd/issues/37515) reports the matching failure when `RELOADING=1` is followed by no `READY=1`; a maintainer identifies that loop. The report is against 257.5, while this review independently confirms the relevant code path is present in the report's exact v258 source. The fix is in merged [PR #39376](https://github.com/systemd/systemd/pull/39376), including commit `5fb8387c671011dd8dec9c897d2707fcb4d74298`. Fresh inspection of v259 `service.c`, blob `dcc4a992ccf4ace78d618d4ecd270132f6d4a3f4`, confirms reload completion resets the stale reload notification before entering the running path. No systemd daemon or upstream test was executed here. [S3, S4]

**Required wording repair:** use systemd as an example of the intended separation between failed reload and service lifetime, together with this actual implementation counterexample. Do not use v258 as proof that a reload attempt always completes at its timeout. The lesson is directly relevant: an attempt deadline needs a terminal disposition and retained ownership; a timeout callback that re-enters the same pending transition can preserve the service while failing to end the attempted update. This supports explicit attempt semantics, not a new manager or a blanket rejection of systemd.

## 2. Material clarification: operation truth and physical retirement have distinct completion conditions

The revised report correctly rejects cancellation acknowledgements, timeouts, process exit and Host disposal as substitutes for typed operation truth. However, a condensed conclusion such as “any unresolved effect prevents restart forever” would go beyond the inspected authority.

ADR-0009 permits disposal to leave an operation nonterminal with `reconcile_required`, provided custody and required containment are not abandoned and durable truth is preserved. Current `agent-runtime-host-disposal.ts` makes this distinction concrete: after the ordinary owner disposal completes, `releaseOrdinaryOwnership()` removes its in-memory Host obligations except contract violations, explicitly without changing durable `reconcile_required`. The exact upstream fixture `ordinary-host-ownership.fixture.ts` expects a first disposal refusal while physical closure is absent, then disposal success after closure receipts appear while the operation remains in reconciliation. This review inspected that fixture; it did not execute it. [A1–A3]

**Suggested sentence:** “Restart eligibility depends on the selected owner's actual physical, authority, compatibility and recovery obligations. Unknown operation truth remains durably owned and forbids unsupported replay or terminalization; it is not automatically equivalent to a live old process. Conversely, recording reconciliation debt does not authorize abandoning unproved physical custody.”

This is a scoped counterexample to a universal rule, not permission to transplant ordinary Codex cleanup semantics into the accepted interactive provider slice. ADR-0091 separately blocks a session's next uncertain handoff, rejects queued undispatched inputs on close, retains unclosed process/stream/grant debt, and requires exact explicit restore. Its own rules still decide whether that session can retire or resume. [A4]

Quiescence likewise should mean that no accepted work or live obligation requires preservation of this old instance before the intended stop, under the selected profile. It cannot mean that an active Host has no resource handles at all: normal idle infrastructure still needs disposal. Inventory must be complete, but “inventory includes reconciliation debt” is not the same predicate as “every historical operation is terminal.” This distinction can materially affect availability and sizing.

## 3. The policy tradeoff survives; ranking must stay conditional

The literal original reading—permanently seal new work, wait for accepted work, and leave the update pending indefinitely—has no finite service-availability guarantee when accepted work can remain unresolved. No runtime experiment is needed to demonstrate that consequence. It is an underspecified proposal, not a newly reproduced AR defect.

Pre-seal deferral preserves healthy ordinary service and avoids inventing a way to reopen irreversible shutdown. It can starve the update under continuous arrivals or an indefinitely retained session. A deliberate new-operation pause can establish a fixed cohort, but adds a real pause owner, exact abort/resume conditions and crash behavior. Authorized cancellation can push toward retirement and can interrupt useful work; it still cannot infer unknown physical or business outcomes. These are different user promises. Permission for downtime alone does not choose between them.

The simplest implementation candidate remains the report's conditional pre-seal approach **if** preserving current work and current service is the objective and an actual owner can establish replaceability atomically. Its ranking is not proven by the industry survey, and it is not automatically the best policy for an owner who requires maintenance progress. “At a natural boundary” is a useful policy only after the profile says whether that boundary is a completed input, a closed session, an explicit checkpoint, or another owned event.

Actual shutdown remains ADR-0009's existing cutoff/containment/disposal procedure. Grace must precede that procedure. Calling `dispose()` to begin a natural grace is incorrect because it sets the permanent disposed state and requests cancellation immediately. Current provider seals also fence delegated creation/preparation, so they are not a gate that merely stops fresh user identities while all already accepted inputs proceed. Current interactive Host closing additionally prevents scheduled reply/control calls; a future graceful ingress pause must preserve the paths needed by accepted work to finish. [A1, A2, A4, A5]

## 4. Preparatory staging is useful within its actual side-effect boundary

The independently checked industry evidence supports early safe checks, separate update/serving status, and honest retirement. It does not establish seamless replacement in AR:

| Source checked | Supported fact | Bound on analogy |
| --- | --- | --- |
| NGINX control guide and `release-1.28.0` process cycle | Failed configuration application keeps the old configuration; replacement workers start before old workers receive graceful shutdown. Source uses a short delay before old shutdown. | This is not a general provider-readiness handshake. Worker overlap, socket inheritance and old-master recovery cannot be assumed for exclusive AR custody. [N1, N2] |
| Envoy 1.36.0 hot restart and draining | New process initialization precedes listener takeover; old connections remain with the old process and eventually complete or are terminated. Graceful draining may continue accepting connections until its timeout. | “Drain” is protocol-specific and is not equivalent to blocking all new operation identities. Existing sessions are not transferred. The documented approach depends on coexistence. [E1, E2] |
| systemd 258/259 | Update attempt state and service state can differ; completion notification matters. | v258 has the counterexample above. A service manager cannot undo arbitrary daemon mutation or establish old provider-effect truth. [S1–S4] |
| Kubernetes release-1.36 docs | Progress deadline reports failure while reconciliation retries; no automatic rollback follows. Force deletion from the API can precede physical termination indefinitely. | Desired/observed state and a registry deletion do not prove custody closure. The evidence does not call for a Kubernetes-style control plane in this product. [K1, K2] |

For the static-restart baseline, preparatory work should be described concretely: validate an inert candidate, artifact identity, compatibility and planned dependencies while the old service runs, insofar as those checks have no conflicting effects. Loading executable plugin code or acquiring an exclusive process/grant/resource is a different boundary. If replacement startup requires old custody to be released, full readiness can only be established after that release, and failed startup can cause an outage. The reviewed report already preserves this limitation; retain it in the final answer instead of shortening “safe preparation” to “start the new version first.”

## 5. Admission atomicity and pending-update crash recovery remain prerequisites

The report correctly rejects polling `activeCount === 0` and disposing later. The missing property is ordering between actual acceptance and the irreversible stop commitment. An accepted command can finish durable acceptance after a wall-clock stop request if it was serialized first; no new identity can be accepted after a completed committed barrier. Pending commits with lost acknowledgements and session-owned queues belong in that inventory. A JavaScript call count is insufficient. [A4, R1]

Existing RST-01 demonstrates this ordering in its own queued receiver. It does not demonstrate an AR durable transaction joining update intent, selected profile/head, session inventory and restart authority. Source searches over the inspected lifecycle/composition and interactive owner paths found no ordinary-update pause/resume or quiescence operation; that bounded absence supports the report's missing-prerequisite claim, not a repository-wide nonexistence assertion.

Durable “update pending” behavior is also not qualified by the existing evidence. Before a product promises that an accepted update survives a crash, its existing authority must distinguish at least these outcomes:

- The candidate was rejected or the pre-stop attempt was deferred; old service authority remains valid.
- Irreversible stop began; loss of the controller cannot reopen the same old instance or reissue uncertain operations.
- Old custody closed but the replacement did not become ready; recovery must use authorized identity/compatibility and retain the actual startup failure.
- A completion or abort arrives from an obsolete update attempt; it cannot publish a stale candidate or clear another barrier.

These are obligations for the same owning operation and boot/recovery path, not a proposed new store or protocol. If “pending” is only a transient best-effort suggestion, say so; if it is accepted durable desired state, losing its Promise cannot erase it. The report and sizing supplement currently exclude missing durable inventory/recovery work, appropriately. No retained RST pass demonstrates these four update-specific crash dispositions.

## 6. What the experiments support, and what they do not

The previous execution archive SHA-256 independently matches `ab8e79dbc2b21a94ea1e6fe550ade5198c4000cec62ed1da1910f3fe35e09ac3`. This review opened the retained RST-01/02/03 TAP logs and selected canonical/custody JSON directly from that archive, without extraction, recompilation or rerun. The logs contain four RST-01 passes, one RST-02 pass, and two RST-03 passes; the live-after-deadline RST-03 record retains one occupied reservation, zero exits and unsettled stop after the success/disconnect messages. This is consistent with the research report's scoped claims. [R1]

| Evidence | Valid use in current argument | Unsupported promotion |
| --- | --- | --- |
| RST-01 queued permanent seal | Acceptance order, post-barrier new-identity rejection, retained explicit recovery disposition | Reversible pause; AR session queue policy; update starvation freedom; crash-safe update intent |
| RST-02 failed readiness/cleanup | Original owner retains real handles and cleanup debt without publishing candidate | Safe arbitrary candidate side effects; startup success after exclusive cutover |
| RST-03 late success and live child | Semantic cancellation, existing external effect and physical exit remain distinct | Production provider receipt qualification; cancellation rollback; finite retirement deadline |
| New source assignability probe | Provider contract shape mismatch at exact inspected snapshots | Update behavior, runtime cleanup, availability or restart qualification |

The no-new-spike decision is therefore correct. A fabricated admission gate could show its own chosen semantics but would not answer whether the product has the needed owner contract or validate the LOC estimate. No additional systemd reproducer is needed: exact source, the upstream issue, fix and v259 source establish the relevant bounded counterexample. If a real update owner is later selected, a minimal witness at its actual admission/stop boundary can be reviewed then. This review does not turn that future possibility into a new test campaign.

## 7. Ratings and LOC disposition

Withdraw the original unconditional-looking `P0` and do not restore it. Current code provides actual disposal; it does not provide the additional pre-disposal update policy assumed by the old residual quote.

The supplemental bounded-turn bands may remain as hypothetical local-mechanics planning aids: quiescent stop P120–300/I100–250/T350–800; reversible pause P220–500/I150–350/T550–1,200; grace then cutoff P160–350/I180–400/T500–1,100. All carry sizing confidence 3/10, substantial shared work, and **unknown whole-delivery cost**. The prerequisites explicitly exclude potentially dominant durable inventory, atomicity and recovery work. They do not price the accepted persistent-session slice. No execution independently validates the amounts, and this review supplies no basis to narrow the ranges or raise confidence.

The reliability scores of 8/10 can remain only as judgments about achievable named safety contracts after qualification. They cannot rank operational availability, update completion time or interruption cost. The systemd correction lowers confidence in that specific supporting example's unconditional timeout behavior, not automatically the proposed AR contract's achievable safety score. A qualitative comparison of service continuity, accepted-work interruption, update starvation and custody uncertainty should remain beside the scores. No winner is selected by this audit.

## Primary source ledger and evidence limits

All fresh retrievals/inspections below occurred **2026-11-06 UTC**. Tags identify the deliberately inspected version, not the current latest version. Mutable documentation branch/page status remains explicit. Source inspection and upstream-test inspection are not new execution.

- **A1:** [AR ADR-0009 at f990acc](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0009-contained-turn-private-access-and-host-shutdown-boundary.md), full local captured authority, blob `2d50e07c40413d7042b4cac906739c53073c61fb`.
- **A2:** [AR Host disposal at f990acc](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/agent-runtime-host-disposal.ts), full local source plus fresh connector verification of release semantics, blob `81a3be33c40987008c334e41aa17b031a37ccb8f`.
- **A3:** [AR ordinary ownership retry fixture](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/tests/package/ordinary-host-ownership.fixture.ts), full local source plus fresh connector verification, blob `1583d20fa88f5ecb138d31a345399d63e105a0b8`; synthetic ports exercising actual feature/Host code, inspected only.
- **A4:** [AR ADR-0091 at f990acc](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0091-interactive-agent-session-synthetic-vertical-slice.md), local authority, blob `d492a490f0c6c04434d4560840802a25eedd5d29`.
- **A5:** [AR interactive Host owner](https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/features/interactive-session-runtime/application/use-cases/create-session-host.ts), full local source, blob `20503591653a9848e3c80e75918e3d7496e8cfe6`.
- **N1:** [NGINX control guide](https://nginx.org/en/docs/control.html), moving unversioned page, fresh web read; [shutdown-timeout directive](https://nginx.org/en/docs/ngx_core_module.html#worker_shutdown_timeout), same status.
- **N2:** [NGINX release-1.28.0 process cycle](https://github.com/nginx/nginx/blob/release-1.28.0/src/os/unix/ngx_process_cycle.c), fresh connector read, blob `5bc5ce9792df0d251b6a9dc943a0f2370335f4ca`.
- **E1:** [Envoy 1.36.0 hot restart](https://www.envoyproxy.io/docs/envoy/v1.36.0/intro/arch_overview/operations/hot_restart), fresh full web read.
- **E2:** [Envoy 1.36.0 draining](https://www.envoyproxy.io/docs/envoy/v1.36.0/intro/arch_overview/operations/draining), fresh full web read.
- **S1:** [systemd v258 manual source](https://github.com/systemd/systemd/blob/v258/man/systemd.service.xml), fresh connector read, blob `68663e9ed81685f15ba5e63dc79123dfc011dd00`; `/man/258/` web retrieval timed out again.
- **S2:** [systemd v258 service source](https://github.com/systemd/systemd/blob/v258/src/core/service.c), fresh full connector retrieval and relevant helper/timer inspection, blob `c8cda0609942fcda179a8d62828976d9c3fdd71c`.
- **S3:** [systemd issue 37515](https://github.com/systemd/systemd/issues/37515) and [merged PR 39376](https://github.com/systemd/systemd/pull/39376), fresh primary issue/maintainer review; reported runtime reproduction belongs to upstream, not this review.
- **S4:** [systemd v259 service source](https://github.com/systemd/systemd/blob/v259/src/core/service.c), fresh connector retrieval and reload reset helper inspection, blob `dcc4a992ccf4ace78d618d4ecd270132f6d4a3f4`.
- **K1:** [Kubernetes release-1.36 Deployment source](https://github.com/kubernetes/website/blob/release-1.36/content/en/docs/concepts/workloads/controllers/deployment.md), mutable version branch, fresh exact blob `2ec9ba7c01996e278991f54886d4f9fd97c2c20b`; [versioned website](https://v1-36.docs.kubernetes.io/docs/concepts/workloads/controllers/deployment/) independently found through web search.
- **K2:** [Kubernetes release-1.36 Pod lifecycle source](https://github.com/kubernetes/website/blob/release-1.36/content/en/docs/concepts/workloads/pods/pod-lifecycle.md), mutable version branch, fresh exact blob `da4d0f437e596a171022f427f0ec9e4696f9eef6`; current moving website also checked without substituting it for the pinned source.
- **R1:** [Retained EF boundary/failure record](https://github.com/agent-teams-ai/extension-foundation/blob/99a5b9157ee5dfdfeb2a14ed99d559fb0135fb7d/docs/research/plugin-boundary-and-failure-experiments.md) and its `plugin-boundary-experiments-20261026-local.tar.gz` archive; local archive digest independently verified and selected raw results inspected as described above. Other prior experimental suites were not revalidated or rerun by this reviewer.

Reviewed proposal files: `reports/update-research.md`, `reports/update-sizing-supplement.md`, `plans/update-spike-plan.md`, `reports/final-adversarial-review.md`, `reports/update-seam-cross-review.md`, `reports/root-dispositions.md`, full common brief, and final user/assistant handoff sections. Governed synthesis edits and publication remain root's responsibility.

## Round 2 disposition — 2026-11-06 UTC

**Pass for the bounded update-policy corrections; no residual substantive correction requested.** Independently read the applied synthesis and OD-003 in `/workspace/scratch/58e9c088d2ee/extension-foundation`. This round checks the changes against the already inspected primary evidence; it does not repeat source research, execute tests, approve a product policy or qualify runtime behavior.

Reviewed file SHA-256 values:

- `docs/research/plugin-choice-deepening-2026-11-06.md`: `24d055e2835464b8cbbb37f737f2bf0dc9c3f3e8307d6604c3129c53d61c2b70`.
- `docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md`: `f1c3adbbed1d344c2e7c2c7f5eec09933ad0d24b4d1214ad18694e13c0664f8a`.

The systemd row now identifies v258's known notification-reload timeout loop, preserves the intended separation between reload result and service health, and labels the later fix/test as upstream evidence. It makes no new local-run claim or guarantee that arbitrary application changes roll back. OD-003 correctly presents that correction as supporting evidence rather than a policy selection.

The ordinary disposal paragraph now distinguishes physical/owner settlement from durable operation reconciliation, preserves contract-violation refusal and excludes replay authority. Both documents explicitly prevent transferring ordinary Codex retirement permission wholesale to interactive sessions. Their adjacent interactive statements preserve irreversible close, queued undispatched-input rejection, custody debt and explicit restore limits. No universal restart prohibition or universal restart permission is inferred from `reconcile_required` alone.

The quiescence wording concerns obligations requiring preservation of the particular instance and explicitly permits idle infrastructure handles awaiting ordinary disposal. It keeps acceptance and committed stopping at the actual owner boundary; it does not turn a zero-call poll into atomicity. The four pending-update crash dispositions remain unqualified requirements of the existing owner, with missing implementation excluded from the hypothetical local-mechanics LOC. No new canonical store or coordinator is selected.

The policy comparison remains conditional: healthy-service/work preservation can postpone updates indefinitely; reversible pause adds a separate contract; maintenance cutoff has interruption consequences and no unconditional completion deadline under unknown closure. Emergency obligations keep their authority. The no-extra-spike disposition, unknown whole-delivery cost, sizing confidence 3/10 and separation from persistent-session estimates remain intact. “Smallest candidate” is presented as a proposal with absent prerequisites, not an accepted or implemented product operation.

This round changed only this review append. No repository file, dependency, test result, primary source record or external state was modified by this reviewer.
