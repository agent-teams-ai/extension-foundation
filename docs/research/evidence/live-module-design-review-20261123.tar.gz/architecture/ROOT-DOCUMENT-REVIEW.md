# Independent review of the proposed operation architecture

Date: 2026-11-23. Reviewer: `/root/architecture_decisions`.

Input: `/workspace/scratch/95e187720be1/live-module-design-20261123/OPERATION-DOCUMENT-BODY.md`.

Input SHA-256: `5d6863462c27990080a9e7a7df9f772b8abb1575792d92fde49319785633120e` (252 lines). The hash was rechecked after the complete read.

Review basis: this lane's `REPORT.md` / `findings.json`, the pinned EF accepted decisions and current blueprint, and current pinned GM Resources/CMS/kernel contracts. No native tests, repository edits, public API selection or owner-policy adoption occurred.

## Disposition

**The architecture is consistent with the accepted direction and current availability, subject to two small but meaningful contract wording corrections.** No architectural redesign is required. The optional points below tighten interpretation rather than introduce new requirements or choices.

## Must fix before treating the text as the current implementation contract

### M1 — Retention predicate is written backwards

Location: semantic-port table, **Evaluate retention**, input line 77.

Current wording: “require every relevant hold before deletion.” The condition should require the relevant holds to be **released**, not present. It also needs the actual owner's eligibility result, because a local count is not authorization to delete an artifact or state.

Suggested replacement: “Expose outstanding holds and budgets; request deletion only after every relevant hold is released and the authoritative owner confirms eligibility.”

Basis: EF blueprint's Reclaim boundary and this document's own retention/old-client rows. This is a precision correction, not a new Q6/Q7 policy.

### M2 — Settled cleanup must not end custody when cleanup debt remains

Location: semantic-port table, **Prepare**, input line 69.

Current wording: “retain failed and late construction until owned cleanup settles.” A settled cleanup can have failed or returned incomplete debt. GM Resources explicitly distinguishes `settled` from `complete`; the surviving dynamic contract releases custody only when the relevant release condition is actually met. Reading the table literally could let an adapter stop retaining the candidate after a settled-but-incomplete close.

Suggested replacement: “Establish custody before imports or acquisition; retain pending construction until it settles, and keep acquired resources/debt owned until the selected mechanism reports their required release.”

The later Close resources/debt rows already express the intended behavior. Align this row with them so an implementer cannot mistake settlement for discharge. Do not add a new counter or stronger physical-stop claim.

Basis: GM ADR-0030 and Resources README; review findings AR02/AR03.

## Optional clarifications

### O1 — Stable plugin identity is broader than installation identity

Location: Identity and compatibility, input lines 47–48.

“A plugin identifier names an installation lineage” is adequate informal shorthand in some hosts, but the portable library also covers eligible built-ins and ordinary modules. EF distinguishes extension identity from artifact/contribution installation identity and runtime instance identity.

A less constraining sentence would be: “A stable plugin or module identifier does not identify the exact installation, generation, old listener or resource that a finalizer may remove.” This preserves the intended exact-instance rule without implying one universal identity model.

### O2 — Clarify the meaning of an update lane

Location: Operation ordering, input lines 101–104.

The prior blueprint already proposes one lane per activation domain, so this is not newly invented policy. However, a reader could infer that preparation must be globally single-flight inside that domain. If that is not intended, describe per-domain coordination while leaving concurrent candidate preparation and its budget to the selected profile. The canonical expected-revision owner still resolves actual publication conflicts. No new Q2/default should be selected through the word “lane.”

### O3 — Eligibility must not imply capture of arbitrary import effects

Location: Eligible module authoring, after input line 167.

A concise clarification would help: the dossier references existing declaration/artifact/state authorities rather than copying their schemas; cooperative TS eligibility requires owned effect paths. Establishing attempt custody around an import does not automatically capture unregistered module-global side effects. This preserves both DRY and the real cooperative-versus-isolated boundary without adding a universal plugin schema.

## Confirmed consistent

- Complete operation and recovery logic remain library responsibilities. Consumers supply narrow canonical authority/state primitives, not another orchestration state machine.
- Product canonical head, grants, state and write authority are not transferred to the library's attempt record or observations.
- Public Resources cleanup and private candidate kernel bookkeeping are clearly separated; withdrawal of ADR-0028 gates is not presented as public release.
- Get Modular remains the graph/binding owner; ordinary external consumers may use fixed typed factories without a dynamic graph.
- Native Effect remains optional, preserves native semantics and can share decision/receipt rules; there is no mandatory Effect core or speculative universal interpreter.
- Feature ownership is cohesive. No package-per-phase layout, empty production scaffold, broad service provider barrel or universal Plugin API is selected.
- Loader, contribution, execution, state/durability and admission dimensions are separated. Supported combinations require qualification; a technology list does not claim implemented adapters.
- Useful UI adoption, selected generation, old work, cleanup and artifact retention are distinct facts. Arbitrary upstream cleanup is not assumed to protect successor registrations; the profile can reject that capability.
- Q1–Q7 and the first actual complete-library consumer/profile remain OPEN. The existing accepted Agent Runtime provider journey is not reopened.
- New-production full FMS v1.1 requirements and source/release/cohort/configuration/hosted-enforcement distinctions are stated accurately.
- Retained mechanism tests are not promoted to full standalone-library or comparative end-to-end evidence.

## Standalone packaging/bootstrap review

**Not yet reviewed:** the packaging/bootstrap artifact was not present in the provided input. Review its actual bytes separately when supplied. This document does not certify a proposed package tree, dependency cohort, repository creation, admission caller, manifest or release workflow by implication.
