# Industry review of proposed operation contract

Date: 2026-11-23. Reviewer: /root/mf_runtime. Scope: profile semantics, source accuracy, completion/identity/retention boundaries and premature guarantees. Read-only; no compiler or native execution.

Input: /workspace/scratch/95e187720be1/live-module-design-20261123/OPERATION-DOCUMENT-BODY.md
SHA-256: 5d6863462c27990080a9e7a7df9f772b8abb1575792d92fde49319785633120e

## Verdict

**No material profile/adoption blocker found. One retention sentence should be clarified before publication.**

- No universal load/unload SPI is adopted. Delivery, contribution, execution, composition and state dimensions remain separate.
- Native lifecycle and original close completion remain authoritative. The wording does not equate idempotent close with joined cleanup or infer physical release from callback completion.
- The late-disposer adverse row explicitly allows rejecting an unsupported capability. It therefore does not claim that raw Piral's route-only disposer already protects the successor.
- Public Resources is distinguished from invocation/custody admission; the private lifecycle kernel is not treated as a supported dependency or silently copied into consumers.
- Complete coordination and supported recovery remain in the standalone library. Consumers supply narrow primitives and policy; native owners retain their actual resources.
- Planned guarantees are distinguished from retained fixture evidence and the future complete-consumer qualification. Q1–Q7 and runtime selection remain OPEN.

## IR-01 — retention eligibility wording

Location: Semantic ports table, Evaluate retention, operation guarantee.

Observed wording: “require every relevant hold before deletion”. This can be read as requiring holds to exist, whereas the intended condition is that relevant owners permit reclamation.

Recommended wording: **“require every applicable owner to confirm deletion eligibility”**. An alternative is “require all relevant holds to be released before deletion”, if the surrounding owner policies use release as their only eligibility operation.

This is a precision correction to an otherwise explicit ownership contract, not a proposal for a new retention policy. No additional runtime test is needed.

## Disposition received from root

Root reported applying IR-01 on 2026-11-23, along with independent architecture-review changes covering custody after settled debt, plugin/installation identity, preparation concurrency and declared acquisition coverage. This review preserves the original input hash above. It does not claim a second review of those revised bytes or of the governed document installed later through the Docs route.

