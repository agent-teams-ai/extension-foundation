# Bounded live module contract probes — actual hosted result

**PASS: native behavior and artifact delivery are both complete** for [run 45208310980](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980), exact execution head `b86e05988334f657d933fa412a02572b455dcd7e`, tree `8033cc38c16032ad5de5624aca842e06fa2e4507`. Both native jobs succeeded. The result applies to the frozen v1 input; it does not qualify a future documentation commit or the whole proposed update library.

## Actual counts, kept separate

| Profile | Declared native tests | Completed named cases | Recorded explicit comparison calls | Native test failures / cancellation / skips |
| --- | --- | --- | --- | --- |
| Piral + Resources | 2 / 2 pass | P1, P2, B1, B2, B3: 5 | 61 | 0 / 0 / 0 |
| Effect | 1 / 1 pass | E1: 1 | 5 | 0 / 0 / 0 |
| Distinct coverage | **3 / 3 pass** | **6** | **66** | **0 / 0 / 0** |

Counts come from actual Node-test logs and delivered observations JSON. Piral has 22 observation rows; these are not 22 cases. The second successful native execution repeats the same cases after repairing evidence delivery and adds no distinct coverage. Effect intentionally skips the two workflow steps that build Piral/install Chromium; it skips no native test.

## What the native observations establish

**P1 — action completion is not readiness.** The real same-name Piral action fulfilled after B setup logged its deliberate rejection. The public registry had no A/B page and no extension; dispatch still invoked failed B's raw listener once. The captured old A callable remained callable (`retainedCalls: 1`). This distinguishes managed registration state, retained reference behavior and acquired resource behavior.

**P2 — delayed disposal needs exact ownership.** Before A's delayed returned disposers ran, real B UI was useful and the public registry contained B's page and distinct B extension reference. Afterwards the page registration was absent while the B extension survived and still rendered. Upstream teardown is void; this demonstrates the limit of an unsupported asynchronous continuation, not a broken promised asynchronous teardown contract.

**B1 — the narrow bridge owns failed-candidate cleanup.** The action fulfilled while the separate readiness result rejected with the original message. The actual Resources candidate-scope report completed with no debt. A second dispatch did not increment B's listener count. A's page was not restored; the adapter has no predecessor-preservation claim.

**B2/B3 — useful B and old cleanup debt stay separate.** B was useful while A's actual first close report was settled but incomplete, with one failed `A/native-listener` debt and the original error identity. Native dispatch incremented both A and B to 1. Explicit retry of the same A scope completed; another dispatch left A at 1 and advanced B to 2. B's page/extension remained registered and its visible action still worked. The retained first report remained incomplete after the retry, preserving the original failure.

**E1 — idempotent close is not the original join.** Actual event order was finalizer entry → second close returned → test released the gate → exact native listener removal. The listener fired before release (`beforeRelease: 1`); after joining the original close, another dispatch did not increment it (`afterJoin: 1`). All five checks passed and JSON failure is null. A lifecycle port must distinguish request/idempotence from joining the original cleanup operation.

All four Piral fixture-cleanup receipts completed without residual debt and independently observed listener absence before fallback removal. Unexpected page errors and infrastructure failures are empty. The tested resource is an exact native listener; this does not generalize to arbitrary retained work, sockets, workers, forced cancellation or sandboxing.

## Exact provenance and delivered artifacts

Frozen input: `live-module-contracts-v1-input-20261123.tar.gz`, **144,946 bytes / 97 members**, SHA-256 `5db80d05009fe298a6cc6d8a1a628a17c80fc8e429beb3dab811ecb5d1db99b1`. It originated at checkpoint `f40968f…` and remained byte-identical through the delivery corrections. Executed workflow SHA-256: `d31e67757c0e1f7a08a135c444de8e94876f92f6b40ed395065f2f87d63c52f6`.

| Profile | Official artifact | Downloaded ZIP | SHA-256 |
| --- | --- | --- | --- |
| Piral | [14835352018](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980/artifacts/14835352018) | 408,261 bytes; 92 regular members | `aa2b566afaebd87eebca733830e58c32ac09ff091e186953913fab0e1e845afe` |
| Effect | [14835745764](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980/artifacts/14835745764) | 308,046 bytes; 81 regular members | `38e92383b7201bd5dec759e67e85f39d34caaaf47679345fd2c228a5e2c13929` |

The official download tool supplied both ZIPs. API digests, downloaded bytes and upload-log digests agree. Every member was read with CRC checking and checked for safe paths/no symlinks. Actual input receipts, checkout SHA, run ID, workflow bytes and frozen archive bytes match. All direct retained fixture/config/lock/audit files match the original input. Temporary signed download URLs are not retained in these receipts.

Actual environment for both profiles is Node **24.22.3**, pnpm **11.25.0**, TypeScript **7.0.2**. The installed native-platform closures were 56 package/version pairs for Piral and 5 for Effect; both compiler-package and native executable identities were verified before tools ran. Strict checking passed with public declarations checked. Piral's genuine official-codegen build transformed 128 modules; its served 221,569-byte JS asset SHA-256 is `42a98a7101204eea3cd67a3e5498f188edf188289037817f24251d14ce66cc4d`, matching the independently reviewed preparation output. Original ZIPs include source, receipts, generated output and dependency license/NOTICE text, without compiler/browser binaries.

## Earlier failures remain part of the record

1. **Static preparation:** public piral-base declarations required missing SystemJS modules/types. The original red input/log is in the frozen archive. Actual exact SystemJS dependencies repaired the gap without shims or weaker checking.
2. **Run [45205566932](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45205566932), f40968f…:** raw logs recorded Piral 2/2 and Effect 1/1 native passes, but both artifact uploads failed because paths contained `../`. The artifact API returned none. Detailed JSON and measured comparison counts from that first run are unavailable and were not reconstructed from expectations.
3. **Run [45207513737](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45207513737), 3b511d2…:** the proposed runner.temp job-env correction failed validation before creating any job. It ran zero native tests. Official context availability excludes runner at job-level env; the CI review had missed that restriction and its earlier approval is explicitly corrected. Exact UI validator text was not retrieved, so no diagnostic quotation is invented.
4. **Run 45208310980, b86e059…:** the first runner step writes absolute paths from RUNNER_TEMP to GITHUB_ENV before checkout/extraction. Both native execution and evidence delivery succeeded with the same frozen cases.

## Ordinary repository gates: snapshot only

At **2026-11-23 15:47:24 UTC**, for execution head `b86e059…`: [CI 45208322661](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208322661) was queued overall with work already running; [Docs 45208323537](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208323537) was in progress at its semantic job. These are not reported as PASS. [Identity 45208444511](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208444511) and [CodeQL 45208314172](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208314172) succeeded; the push-only Docs run 45208311458 was skipped. A later final documentation commit requires its own ordinary gate qualification.

`RESULT.json` retains the exact source and observation mapping, per-profile bindings and terminal metadata links. The sibling independent native-result review is separate; its eventual verdict must be read directly, not assumed from this receipt. These results support a narrow reusable integration and explicit lifecycle contracts. They do not select a production stack, expose a private kernel, qualify universal state preservation/admission, or complete a whole-library E2E campaign.
