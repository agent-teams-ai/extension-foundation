# Independent review of delivered native results

Date: **2026-11-23**, completed after independent GitHub run/job reads at approximately **15:48 UTC**. Reviewer: **/root/mf_runtime**.

## Verdict and scope

**PASS for the exact bounded Piral/Resources and Effect fixtures in corrected run [45208310980](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980), attempt 1, head `b86e05988334f657d933fa412a02572b455dcd7e`.** Native execution and artifact delivery both succeeded. Both official ZIPs have been delivered and independently read; Piral is no longer pending.

Distinct coverage is **3 declared tests, 6 named cases, 66 explicit comparison calls**: Piral **2 / 5 / 61**, Effect **1 / 1 / 5**. Piral's **22 observation rows** are receipts within its cases, not 22 tests. File-integrity checks performed during this review are not additional native tests.

No fixture, frozen report or workflow was changed; no compiler, native Node case or browser was rerun by this reviewer. The review establishes fixture evidence, not a completed library, accepted adapter, general foreign-plugin guarantee, comparative product advantage or choice of Q1–Q7.

## 1. Execution and delivery history remain separate

| Run / exact head | Native result | Workflow / delivery result | Evidence limit |
| --- | --- | --- | --- |
| [45205566932](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45205566932), `f40968f88a1fd29bea3dfcf207bab56e32b90e0d` | Original logs record Piral 2/2 and Effect 1/1, with zero failed/cancelled/skipped tests | FAILURE at upload: absolute patterns retained a `../` segment; artifact list was empty | Original detailed JSON and comparison counts are unavailable. They are not reconstructed from the corrected run. |
| [45207513737](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45207513737), `3b511d2a75829169c011baf3c114ec62c8c254b3` | **Zero jobs, zero native executions** | Workflow validation FAILURE | Invalid job-level `runner.temp` placement is a source/documentation diagnosis. The exact UI validation annotation was not retrieved; do not invent a job log or quoted error. |
| [45208310980](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980), `b86e05988334f657d933fa412a02572b455dcd7e` | Piral 2/2; Effect 1/1; all five Piral cases and E1 completed | SUCCESS, including both upload steps and official artifact delivery | Same frozen fixture input and oracles. The repeat supplies missing evidence; it does not increase distinct coverage. |

This review independently read the original native totals/upload errors, the zero-job receipt and the corrected job statuses. The corrected API reports both jobs completed successfully:

- Effect job [137809978747](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980/job/137809978747).
- Piral job [137809979399](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45208310980/job/137809979399).

The earlier CI path-only review's missed context restriction remains an acknowledged review error. Later success does not rewrite the earlier failures.

## 2. Input, workflow and delivered bytes

### Frozen input

`live-module-contracts-v1-input-20261123.tar.gz`: **144,946 bytes**, **97 regular members**, SHA-256:

`5db80d05009fe298a6cc6d8a1a628a17c80fc8e429beb3dab811ecb5d1db99b1`

The archive carried in each official artifact is identical to the retained local frozen archive. All 97 member lengths/hashes were recomputed against its manifest. Hosted input receipts identify the correct run, attempt, head and profile. All eight inputs in the prior independent code review match the frozen archive.

Actual delivered sidecar inputs also match that archive: **11 Piral files** and **5 Effect files**, including source, configuration, package/lock and dependency audit. This verifies actual delivered bytes rather than only an archive filename.

### Workflow identities

- **Executed corrected workflow:** `d31e67757c0e1f7a08a135c444de8e94876f92f6b40ed395065f2f87d63c52f6`, 9,879 bytes.
- **Historical workflow retained inside the original input:** `8135d6092a78d434fa10172f989bc890429b37ac7c7a5219b13244edd149d1ae`.

The first matches both hosted receipts and the workflow blob read with `git show` at the actual **b86e059…** commit. The second remains the original preparation artifact; it is not mislabeled as the corrected workflow. Fixture hashes did not change with the delivery/context corrections.

### Official artifacts

| Profile | Artifact ID | Bytes / regular members | SHA-256 |
| --- | --- | --- | --- |
| Piral | 14835352018 | 408,261 / 92 | `aa2b566afaebd87eebca733830e58c32ac09ff091e186953913fab0e1e845afe` |
| Effect | 14835745764 | 308,046 / 81 | `38e92383b7201bd5dec759e67e85f39d34caaaf47679345fd2c228a5e2c13929` |

Both independently computed digests and sizes match GitHub artifact metadata. Every ZIP member was read and checked against the retained inventory; no duplicate names, unsafe parent paths or member mismatch was found. Extracted observation copies match their ZIP members. Original input, plan/review material and third-party notices remain in the delivered inventories.

## 3. Semantic observations against the frozen public oracles

| Case | Actual delivered evidence | Supported interpretation and limit |
| --- | --- | --- |
| **P1** | Public B add fulfilled; page generation was null and extensions empty after rejected setup; event counts A=0/B=1. The retained authored A callback incremented independently. Actual setup-error console output was captured. | Action completion is not useful readiness. Failed B still owned its acquired listener until explicit fixture cleanup. The captured callback does not prove restored A UI or drained application work. |
| **P2** | Before opening the old-disposer gate, B page/extension were registered and the reviewed native DOM assertions observed useful B. Afterwards the route registration and B page were absent, while B's distinct extension reference and rendered extension survived. | The specific delayed route-only disposer can affect a successor; reference-specific removal provides the positive control. This is an asynchronous continuation of a **void teardown** contract, not evidence that Piral broke an awaited-Promise guarantee. |
| **B1** | Action fulfilled, bridge readiness rejected with the setup-error message. B's actual scope close completed with no debt. Dispatch count B stayed 1 on the next event. Old page/contributions remained absent. | The bridge retained and cleaned the failed candidate; it did not create nondestructive preparation or restore A automatically. |
| **B2** | B readiness fulfilled and the real page action worked. A's actual first CloseReport was settled but incomplete, with one failed `A/native-listener` debt and `originalCause:true`. Dispatch counted A=1/B=1. | A useful successor and physically live old listener debt can coexist. Settled cleanup is not successful release. |
| **B3** | Explicit retry of the same A scope completed without debt; dispatch became A=1/B=2. B registration and page remained useful, including the second visible action. The retained first report exactly matched B2's original failed report. | Exact old-scope cleanup preserves this successor and its original failure evidence. The fixture chooses an explicit retry; no automatic production policy is selected. |
| **E1** | Events were finalizer-entered → close2-returned → test-release → exact-listener-removed. `beforeRelease=1`, `afterJoin=1`, `firstJoined=true`, failure=null; all five assertions passed. | Repeated close was not a join of the original finalization. Native listener behavior was observed before/after joining the original fiber. This confirms the documented Effect4.1.5 contract in this exact profile. |

Piral recorded **no page errors or infrastructure failures**. Its two deliberate setup-rejection console messages remain present; raw browser stderr also contains host diagnostics. “No page errors” must not be shortened to “no errors anywhere”.

All four separate Piral scenario teardown receipts report listeners absent before the last-resort fallback and no remaining reported debt. In the raw cases this includes the fixture's explicit native cleanup; empty Resources scopes in those cases are not evidence that Resources cleaned raw unregistered resources.

The artifact does not contain DOM screenshots or a browser recording. The useful-UI claim is supported by the passed, previously reviewed DOM action/assertion code bound to the actual source and generated bundle, together with the delivered observations. No stronger visual artifact is inferred.

## 4. Runtime/build/dependency qualification

Both hosted profiles report **Node24.22.3, pnpm11.25.0 and TypeScript7.0.2**. The official jobs passed exact dependency verification and strict source/public-declaration checks.

Independent receipt comparison found:

- Piral: **56** installed package name/version pairs match the frozen native-platform audit.
- Effect: **5** pairs match its audit.
- Both record only TypeScript7.0.2 and its matching native compiler package. Compiler SHA-256 `4f2de678286401759b3fb4475bafe35b8f32b4b3a07d92642bbf37eadc9b34a4` matches the frozen audit.

Piral uses published core1.12.5, Resources0.2.2, React18.3.1, router5.3.4, Vite8.3.8, official codegen plugin2.1.0 and Playwright1.65.1. Effect uses4.1.5. These qualify this exact consumer cohort and do not upgrade another accepted consumer pin.

The generated production JavaScript is **221,569 bytes**, SHA-256 `42a98a7101204eea3cd67a3e5498f188edf188289037817f24251d14ce66cc4d`; generated HTML is **239 bytes**, SHA-256 `c2538169ac8a2bce105dbf6214c2d79a2c19e6e0cc89cdb678fb8814b7d8e772`. Both ZIP members match the build receipt. The JavaScript hash matches the pre-execution production output reviewed for real Piral integration and setup logging.

Browser installation logs identify **Chrome Headless Shell159.0.8154.6, Playwright revision1255**. DEBUG output independently shows launch of `chromium_headless_shell-1255/.../chrome-headless-shell`, successful process start and final exitCode0. This is installation-plus-launch evidence; this fixture did not separately record `browser.version()`. The command is Playwright's ordinary headless launch, including its default flags; no browser sandbox/security qualification is claimed.

Native log totals: Piral2 passed/0 failed/0 cancelled/0 skipped, duration4330.938944ms; Effect1/0/0/0, duration290.322672ms. These fixture durations are receipts, not a comparative performance benchmark.

## 5. Check of proposed published result wording

Read the governed file:

`/workspace/scratch/95e187720be1/live-update-value-validation/docs/research/live-module-update-design-validation-2026-11-23.md`

SHA-256 **`0f7e284e66914d8998960f522995b65ee66af3df1603a866fb684fb1726f86ac`**.

The **“Observed native results”** section's five rows (B2/B3 grouped), 3 tests / 6 cases / 66 comparisons, preserved expected errors, source/cohort scope and non-adoption caveats match the actual evidence. **No must-fix wording issue found.** The planned result packet references still require root's actual final packaging/publication; this review does not substitute for that publication step.

## 6. Key reviewed result identities

Paths below are relative to `spikes/hosted/current/` in the design packet.

| File | SHA-256 |
| --- | --- |
| piral-lifecycle/observations.json | `e4ad7ff3833c8f51a2c9916225a4ee9093ae5014d9144b984ed73d2bd4d6be01` |
| piral-lifecycle/hosted/native.log | `7aaf48db7776f71b2afd2b61203f10ec74918449080af74e190c0aae7d7e9d78` |
| piral-lifecycle/hosted/input-receipt.json | `a42c213db2754d3996db919ea386d5b9d23503c97e4934eef906135b9b82159e` |
| piral-lifecycle/hosted/installed-identities.json | `e97743ed0d720ffeea7b1585d9ea4c0f0cefe4ac809ea4629275faef500dc314` |
| effect-close/observations.json | `8978e053ca2569dc60af0f90182eee7707580ff0d6d219e21608390c2b4f656f` |
| effect-close/hosted/native.log | `ff7f5585689f2cf99f8755db840651751e7ae0e6930a557dca7d28302ea41373` |
| effect-close/hosted/input-receipt.json | `227539c5474f1423b72a9dbb3f270b4e90a6194c415fbdc73d744071ec4fdccb` |
| effect-close/hosted/installed-identities.json | `dde0b04f9f24ef497dda022ab8419b591b086d2baff6b0be376e3478ca401745` |
| workflow-validation-failure-45207513737-receipt.json | `1696bd6eea8023065b571bed499993ba341fd4f5e312290458ae5d4bfaa959e0` |

Earlier log identities remain separate: original Effect job log `4e83c35fc2149b490b84cb86a054316733c5a76c7c013138d7ebe066a77d07d8`; original Piral job log `44c1262321c35d9fcc3d7a1e91782c1434fda58500c135599cc0612de7ae9f4d`.

The results resolve the bounded lifecycle uncertainties. They do not establish arbitrary state/undo preservation, atomic call admission, durable crash recovery, distributed publication, secure execution, physical release of all resource kinds, an adopted runtime or a complete consumer update operation.

