# Repository instructions

Read and follow [AGENTS.md](AGENTS.md). It routes to the current project scope,
organization engineering rules and explicit bootstrap status.
