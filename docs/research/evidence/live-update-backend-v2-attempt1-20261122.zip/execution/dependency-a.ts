export function transform(input: number): number { return input * 2; }
