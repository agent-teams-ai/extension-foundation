import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { Worker } from 'node:worker_threads';
import type { Scope } from '@get-modular/resources';
import { fromWorker } from './protocol.ts';
import type { FromWorker, Identity, ToWorker } from './protocol.ts';

type Waiter = ReturnType<typeof Promise.withResolvers<FromWorker>>;
export type StopReceipt = Readonly<{ generation: string; threadId: number; code: number }>;
export type SourceHash = Readonly<{ name: string; sha256: string }>;
const digest = (value: string | Uint8Array): string => createHash('sha256').update(value).digest('hex');

export class FixtureWorker {
  readonly worker: Worker;
  readonly identity: Identity;
  readonly sources: readonly SourceHash[];
  readonly events: string[] = ['created'];
  readonly #messages: FromWorker[] = [];
  #waiter: Waiter | undefined;
  #failure: unknown;
  #stopReceipt: StopReceipt | undefined;
  get stopReceipt(): StopReceipt | undefined { return this.#stopReceipt; }
  constructor(entry: URL, owned: Identity, sources: readonly SourceHash[]) {
    this.identity = owned;
    this.sources = sources;
    this.worker = new Worker(entry, { workerData: owned, execArgv: ['--unhandled-rejections=strict'] });
    const threadId = this.worker.threadId;
    this.worker.on('message', (raw: unknown) => {
      try {
        const message = fromWorker(raw);
        if (this.#waiter) { this.#waiter.resolve(message); this.#waiter = undefined; }
        else this.#messages.push(message);
      } catch (error) { this.#fail(error); }
    });
    this.worker.once('error', error => this.#fail(error));
    this.worker.once('exit', code => {
      this.events.push('native-exit');
      this.#stopReceipt = { generation: owned.generation, threadId, code };
      this.#fail(new Error('Worker exited before pending response'));
    });
  }
  #fail(error: unknown): void {
    this.#failure = error;
    this.#waiter?.reject(error);
    this.#waiter = undefined;
  }
  send(message: ToWorker): void { this.worker.postMessage(message); }
  async next(): Promise<FromWorker> {
    const queued = this.#messages.shift();
    if (queued) return queued;
    if (this.#failure) throw this.#failure;
    if (this.#waiter) throw new Error('Fixture permits one pending receive');
    const waiter = Promise.withResolvers<FromWorker>();
    this.#waiter = waiter;
    const timer = setTimeout(() => {
      if (this.#waiter === waiter) this.#waiter = undefined;
      waiter.reject(new Error('Timed out waiting for worker message'));
    }, 8000);
    try { return await waiter.promise; } finally { clearTimeout(timer); }
  }
  async terminate(): Promise<void> {
    if (this.stopReceipt) { this.events.push('native-exit-already-observed'); return; }
    this.events.push('terminate-requested');
    const code = await this.worker.terminate();
    this.events.push('terminate-promise-resolved');
    // A spontaneous exit can win before terminate's request reaches Node.
    // Only the native exit event supplies the receipt in either ordering.
    const receipt = this.#stopReceipt; // Native exit callback can run during await.
    if (!receipt || (code !== undefined && receipt.code !== code)) throw new Error('Missing matching native exit receipt');
  }
}

export async function prepareWorker(
  scope: Scope, version: 'a' | 'b', generation: string, beforeTerminate?: () => void | Promise<void>,
): Promise<FixtureWorker> {
  // Literal files only. This is a provenance manifest, not a graph resolver.
  const names = [`worker-${version}.ts`, `dependency-${version}.ts`, 'worker-main.ts', 'protocol.ts'];
  const sources = await Promise.all(names.map(async name => ({ name, sha256: digest(await readFile(new URL(name, import.meta.url))) })));
  const entry = sources[0];
  if (!entry) throw new Error('Missing fixture entry hash');
  const owned: Identity = { generation, artifactDigest: entry.sha256, cohortDigest: digest(JSON.stringify(sources)) };
  const handle = await scope.resources.setup({
    name: 'native-worker',
    // Return ownership immediately; readiness happens only after cleanup custody
    // is registered. A failed ready handshake cannot orphan a started Worker.
    setup: () => new FixtureWorker(new URL(`worker-${version}.ts`, import.meta.url), owned, sources),
    cleanup: async worker => { await beforeTerminate?.(); await worker.terminate(); },
  });
  const ready = await handle.next();
  if (ready.kind !== 'ready' || ready.identity.generation !== owned.generation ||
    ready.identity.cohortDigest !== owned.cohortDigest || ready.identity.artifactDigest !== owned.artifactDigest) {
    throw new Error('Worker did not confirm the selected fixture identity');
  }
  return handle;
}
