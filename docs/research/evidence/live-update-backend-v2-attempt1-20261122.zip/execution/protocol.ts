// Private test messages, not a proposed RPC framework or production plugin SPI.
export type Identity = Readonly<{ generation: string; artifactDigest: string; cohortDigest: string }>;
export type Admission = Identity & Readonly<{ revision: string; effectEpoch: string }>;
export type HostEffect = Readonly<{
  operationId: string; effectId: string; admission: Admission;
  stateSchema: string; value: { count: number };
}>;
export type ToWorker =
  | { kind: 'begin'; operationId: string; input: number; admission: Admission }
  | { kind: 'continue'; operationId: string }
  | { kind: 'host-write'; envelope: HostEffect }
  | { kind: 'ping' };
export type FromWorker =
  | { kind: 'ready' | 'pong'; identity: Identity }
  | { kind: 'first' | 'finished'; operationId: string; value: number;
      implementation: string; dependency: string; identity: Identity }
  | { kind: 'host-effect'; envelope: HostEffect };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function record(value: unknown): Record<string, unknown> {
  if (!isRecord(value)) throw new Error('Expected message object');
  return value;
}
function text(value: unknown): string {
  if (typeof value !== 'string' || value.length === 0) throw new Error('Expected nonempty message text');
  return value;
}
function number(value: unknown): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error('Expected bounded integer');
  return value;
}
function decimal(value: unknown): string {
  const parsed = text(value);
  if (!/^(0|[1-9][0-9]*)$/.test(parsed)) throw new Error('Expected exact decimal token');
  return parsed;
}
export function identity(value: unknown): Identity {
  const v = record(value);
  return { generation: text(v['generation']), artifactDigest: text(v['artifactDigest']), cohortDigest: text(v['cohortDigest']) };
}
export function admission(value: unknown): Admission {
  const v = record(value);
  return { ...identity(v), revision: decimal(v['revision']), effectEpoch: decimal(v['effectEpoch']) };
}
function effect(value: unknown): HostEffect {
  const v = record(value);
  return { operationId: text(v['operationId']), effectId: text(v['effectId']),
    admission: admission(v['admission']), stateSchema: text(v['stateSchema']),
    value: { count: number(record(v['value'])['count']) } };
}
export function toWorker(value: unknown): ToWorker {
  const v = record(value);
  switch (v['kind']) {
    case 'ping': return { kind: 'ping' };
    case 'begin': return { kind: 'begin', operationId: text(v['operationId']), input: number(v['input']), admission: admission(v['admission']) };
    case 'continue': return { kind: 'continue', operationId: text(v['operationId']) };
    case 'host-write': return { kind: 'host-write', envelope: effect(v['envelope']) };
    default: throw new Error('Unknown worker command');
  }
}
export function fromWorker(value: unknown): FromWorker {
  const v = record(value);
  switch (v['kind']) {
    case 'ready': case 'pong': return { kind: v['kind'], identity: identity(v['identity']) };
    case 'first': case 'finished': return { kind: v['kind'], operationId: text(v['operationId']), value: number(v['value']),
      implementation: text(v['implementation']), dependency: text(v['dependency']), identity: identity(v['identity']) };
    case 'host-effect': return { kind: 'host-effect', envelope: effect(v['envelope']) };
    default: throw new Error('Unknown worker response');
  }
}
