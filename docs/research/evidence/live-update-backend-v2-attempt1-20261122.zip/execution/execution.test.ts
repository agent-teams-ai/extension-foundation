import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { after, test } from 'node:test';
import { createScope } from '@get-modular/resources';
import { prepareWorker } from './worker-fixture.ts';
import type { FixtureWorker } from './worker-fixture.ts';

const observations: { scenario: string; status: string; details: unknown }[] = [];
after(async () => { await writeFile(process.env['EXECUTION_RESULTS_PATH'] ?? 'execution-results.json',
  JSON.stringify({ node: process.version, scope: 'native Worker + public Resources, no DB or sandbox claim', scenarios: observations }, null, 2) + '\n'); });
function scenario(name: string, run: () => Promise<unknown>): void {
  test(name, { timeout: 20000 }, async () => {
    try { observations.push({ scenario: name, status: 'passed', details: await run() }); }
    catch (error) { observations.push({ scenario: name, status: 'failed', details: String(error) }); throw error; }
  });
}

scenario('E03 close waiter abandonment does not prove native Worker exit', async () => {
  const scope = createScope({ name: 'pending-native-stop' });
  const entered = Promise.withResolvers<void>();
  const release = Promise.withResolvers<void>();
  try {
    const worker = await prepareWorker(scope, 'a', 'E03-A', async () => { entered.resolve(); await release.promise; });
    const abandonment = new AbortController();
    const observation = scope.control.close({ abandon: abandonment.signal });
    const checkpointTimer = setTimeout(() => entered.reject(new Error('Cleanup checkpoint was not entered')), 8000);
    try { await entered.promise; } finally { clearTimeout(checkpointTimer); }
    abandonment.abort('caller stops observing; native Worker has no AbortSignal API');
    const pending = await observation;
    assert.equal(pending.settled, false);
    assert.equal(pending.complete, false);
    assert.ok(pending.debts.some(debt => debt.state === 'pending'));
    assert.equal(scope.resources.signal.aborted, true);
    assert.equal(worker.stopReceipt, undefined);
    assert.deepEqual(worker.events, ['created']);
    worker.send({ kind: 'ping' });
    assert.equal((await worker.next()).kind, 'pong');
    // The private test receive is settled from native exit, not left hanging.
    const pendingReceive = assert.rejects(worker.next(), /Worker exited before pending response/);
    const joined = scope.control.close();
    release.resolve();
    assert.equal((await joined).complete, true);
    await pendingReceive;
    assert.deepEqual(worker.events, ['created', 'terminate-requested', 'native-exit', 'terminate-promise-resolved']);
    assert.ok(worker.stopReceipt);
    return { pending, events: worker.events, receipt: worker.stopReceipt,
      distinction: 'Resources waiter abandon and acquisition signal do not stop a Worker; cleanup awaited native terminate' };
  } finally { release.resolve(); await scope.control.close(); }
});

scenario('E04 failed cleanup retains a responsive Worker and public close retries it', async () => {
  const scope = createScope({ name: 'failed-native-stop' });
  let attempts = 0;
  try {
    const worker = await prepareWorker(scope, 'a', 'E04-A', () => {
      attempts += 1;
      if (attempts === 1) throw new Error('injected stop failure before native terminate');
    });
    const debt = await scope.control.close();
    assert.equal(debt.complete, false);
    assert.equal(debt.settled, true);
    assert.equal(debt.debts.length, 1);
    assert.equal(debt.debts[0]?.state, 'failed');
    assert.equal(worker.stopReceipt, undefined);
    worker.send({ kind: 'ping' });
    assert.equal((await worker.next()).kind, 'pong');
    const retried = await scope.control.close();
    assert.equal(retried.complete, true);
    assert.equal(attempts, 2);
    assert.equal(worker.events.filter(event => event === 'native-exit').length, 1);
    assert.ok(worker.stopReceipt);
    const firstDebt = debt.debts[0];
    return { debt, retried, attempts, events: worker.events, receipt: worker.stopReceipt,
      injectedBeforePhysicalStop: true, debtCause: firstDebt?.state === 'failed' ? String(firstDebt.cause) : null };
  } finally { await scope.control.close(); }
});

scenario('E05 retention budget counts native exits before acquiring another Worker', async () => {
  const aScope = createScope({ name: 'retained-A' });
  const bScope = createScope({ name: 'selected-B' });
  const cScope = createScope({ name: 'next-C' });
  const inventory: FixtureWorker[] = [];
  const live = (): number => inventory.filter(worker => worker.stopReceipt === undefined).length;
  const maximum = 2;
  let constructions = 0;
  let refused = 0;
  async function acquire(scope: ReturnType<typeof createScope>, version: 'a' | 'b', generation: string): Promise<FixtureWorker> {
    // Explicit single-controller fixture policy, not a production admission kernel.
    if (live() >= maximum) { refused += 1; throw new Error('Native retention budget exhausted'); }
    constructions += 1;
    const worker = await prepareWorker(scope, version, generation);
    inventory.push(worker);
    return worker;
  }
  try {
    const a = await acquire(aScope, 'a', 'E05-A');
    a.send({ kind: 'begin', operationId: 'retained-stream', input: 4,
      admission: { ...a.identity, revision: '0', effectEpoch: '0' } });
    const first = await a.next();
    assert.equal(first.kind, 'first');
    if (first.kind !== 'first') throw new Error('Expected first stream value');
    assert.equal(first.value, 9);
    await acquire(bScope, 'b', 'E05-B');
    assert.equal(live(), 2);
    await assert.rejects(acquire(cScope, 'a', 'E05-C'), /retention budget exhausted/);
    assert.equal(constructions, 2); // C refused before native acquisition.
    a.send({ kind: 'continue', operationId: 'retained-stream' });
    const finished = await a.next();
    assert.equal(finished.kind, 'finished');
    if (finished.kind !== 'finished') throw new Error('Expected final stream value');
    assert.equal(finished.value, 11);
    assert.equal(live(), 2); // Completing work does not claim physical reclamation.
    assert.equal((await aScope.control.close()).complete, true);
    assert.equal(live(), 1);
    await acquire(cScope, 'a', 'E05-C');
    assert.equal(live(), 2);
    await Promise.all([bScope.control.close(), cScope.control.close()]);
    assert.equal(live(), 0);
    assert.equal(constructions, 3);
    assert.equal(refused, 1);
    return { maximum, constructions, refused, physicalExits: inventory.map(worker => worker.stopReceipt),
      limitation: 'single controller, known Workers only; no concurrent admission, process RSS or arbitrary plugin leak bound' };
  } finally { await Promise.all([aScope.control.close(), bScope.control.close(), cScope.control.close()]); }
});
