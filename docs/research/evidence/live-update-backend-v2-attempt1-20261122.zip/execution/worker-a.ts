import { transform } from './dependency-a.ts';
import { start } from './worker-main.ts';
start({ name: 'implementation-A', dependency: 'dependency-A',
  first: input => transform(input) + 1, second: input => transform(input + 1) + 1 });
