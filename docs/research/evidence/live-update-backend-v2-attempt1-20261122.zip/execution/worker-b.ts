import { transform } from './dependency-b.ts';
import { start } from './worker-main.ts';
start({ name: 'implementation-B', dependency: 'dependency-B',
  first: input => transform(input) + 100, second: input => transform(input + 1) + 100 });
