import { parentPort, workerData } from 'node:worker_threads';
import { identity, toWorker } from './protocol.ts';
import type { Admission, FromWorker } from './protocol.ts';

export function start(implementation: {
  name: string; dependency: string; first(input: number): number; second(input: number): number;
}): void {
  const port = parentPort;
  if (!port) throw new Error('Fixture requires a real Worker');
  const owned = identity(workerData);
  let held: { operationId: string; iterator: AsyncGenerator<number, void> } | undefined;
  function send(message: FromWorker): void { port?.postMessage(message); }
  function check(captured: Admission): void {
    if (captured.generation !== owned.generation || captured.cohortDigest !== owned.cohortDigest ||
      captured.artifactDigest !== owned.artifactDigest) throw new Error('Wrong admitted worker cohort');
  }
  async function* values(input: number): AsyncGenerator<number, void> {
    yield implementation.first(input);
    yield implementation.second(input);
  }
  async function receive(raw: unknown): Promise<void> {
    const message = toWorker(raw);
    if (message.kind === 'ping') { send({ kind: 'pong', identity: owned }); return; }
    if (message.kind === 'host-write') {
      check(message.envelope.admission);
      send({ kind: 'host-effect', envelope: message.envelope });
      return;
    }
    if (message.kind === 'begin') {
      check(message.admission);
      if (held) throw new Error('Fixture supports one held iterator per Worker');
      held = { operationId: message.operationId, iterator: values(message.input) };
      const first = await held.iterator.next();
      if (first.done) throw new Error('Missing first value');
      send({ kind: 'first', operationId: message.operationId, value: first.value,
        implementation: implementation.name, dependency: implementation.dependency, identity: owned });
      return;
    }
    if (!held || held.operationId !== message.operationId) throw new Error('No matching held operation');
    const second = await held.iterator.next();
    if (second.done) throw new Error('Missing second value');
    await held.iterator.return();
    held = undefined;
    send({ kind: 'finished', operationId: message.operationId, value: second.value,
      implementation: implementation.name, dependency: implementation.dependency, identity: owned });
  }
  port.on('message', (raw: unknown) => { void receive(raw).catch(error => { throw error; }); });
  send({ kind: 'ready', identity: owned });
}
