import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { after, test } from 'node:test';
import { createScope } from '@get-modular/resources';
import { StateFixture } from '../state-fixture.ts';
import type { EffectInput } from '../state-fixture.ts';
import { prepareWorker } from './worker-fixture.ts';
import type { FixtureWorker } from './worker-fixture.ts';
import type { Admission, HostEffect } from './protocol.ts';

// This source is assembled into the single state/probe/execution package before
// strict typechecking. Its relative state import is for that frozen layout.
const observations: { scenario: string; status: string; details: unknown }[] = [];
after(async () => { await writeFile(process.env['EXECUTION_STATE_RESULTS_PATH'] ?? 'execution-state-results.json',
  JSON.stringify({ node: process.version, scope: 'joint actual Worker/Public Resources/PostgreSQL disposable E2E', scenarios: observations }, null, 2) + '\n'); });
function scenario(name: string, run: (db: StateFixture) => Promise<unknown>): void {
  test(name, { timeout: 35000 }, async () => {
    let db: StateFixture | undefined;
    try {
      db = await StateFixture.create();
      observations.push({ scenario: name, status: 'passed', details: await run(db) });
    } catch (error) { observations.push({ scenario: name, status: 'failed', details: String(error) }); throw error; }
    finally { await db?.destroy(); }
  });
}
async function selectReady(db: StateFixture, worker: FixtureWorker, attemptId: string): Promise<Admission> {
  const previous = await db.readHead();
  await db.admitAttempt({ attemptId, expectedRevision: previous.revision, expectedGeneration: previous.generation,
    targetGeneration: worker.identity.generation, cohortDigest: worker.identity.cohortDigest, baselineId: 'S0' });
  const published = await db.publishAttempt(attemptId);
  assert.equal(published.status, 'committed');
  assert.ok(published.result);
  assert.equal(published.result.cohortDigest, worker.identity.cohortDigest);
  return { ...worker.identity, revision: published.result.revision, effectEpoch: published.result.effectEpoch };
}
function effectInput(envelope: HostEffect, effectId = envelope.effectId): EffectInput {
  return { effectId, generation: envelope.admission.generation, effectEpoch: envelope.admission.effectEpoch,
    stateSchema: envelope.stateSchema, value: envelope.value };
}

scenario('E01 real old and new implementation/dependency cohorts straddle DB publication', async db => {
  const aScope = createScope({ name: 'cohort-A' });
  const bScope = createScope({ name: 'cohort-B' });
  const ownedWorkers: FixtureWorker[] = [];
  try {
    const a = await prepareWorker(aScope, 'a', 'worker-A1');
    ownedWorkers.push(a);
    const oldAdmission = await selectReady(db, a, 'bootstrap-real-A');
    a.send({ kind: 'begin', operationId: 'old-stream', input: 4, admission: oldAdmission });
    const first = await a.next();
    assert.equal(first.kind, 'first');
    if (first.kind !== 'first') throw new Error('Missing first A value');
    assert.equal(first.value, 9);
    const b = await prepareWorker(bScope, 'b', 'worker-B1');
    ownedWorkers.push(b);
    const newAdmission = await selectReady(db, b, 'replace-with-real-B');
    assert.notEqual(oldAdmission.artifactDigest, newAdmission.artifactDigest);
    assert.notEqual(oldAdmission.cohortDigest, newAdmission.cohortDigest);
    assert.equal((await db.readHead()).generation, b.identity.generation);
    b.send({ kind: 'begin', operationId: 'new-stream', input: 4, admission: newAdmission });
    const fresh = await b.next();
    assert.equal(fresh.kind, 'first');
    if (fresh.kind !== 'first') throw new Error('Missing first B value');
    assert.equal(fresh.value, 120);
    a.send({ kind: 'continue', operationId: 'old-stream' });
    const oldFinal = await a.next();
    assert.equal(oldFinal.kind, 'finished');
    if (oldFinal.kind !== 'finished') throw new Error('Missing final A value');
    assert.deepEqual({ value: oldFinal.value, implementation: oldFinal.implementation, dependency: oldFinal.dependency },
      { value: 11, implementation: 'implementation-A', dependency: 'dependency-A' });
    assert.deepEqual(oldFinal.identity, a.identity);
    b.send({ kind: 'continue', operationId: 'new-stream' });
    const newFinal = await b.next();
    assert.equal(newFinal.kind, 'finished');
    if (newFinal.kind !== 'finished') throw new Error('Missing final B value');
    assert.deepEqual({ value: newFinal.value, implementation: newFinal.implementation, dependency: newFinal.dependency },
      { value: 125, implementation: 'implementation-B', dependency: 'dependency-B' });
    assert.deepEqual(newFinal.identity, b.identity);
    assert.equal(a.stopReceipt, undefined);
    return { first, fresh, oldFinal, newFinal, oldAdmission, newAdmission,
      sourceManifests: { a: a.sources, b: b.sources },
      limitation: 'literal immutable fixture cohorts, no generic loader or external dynamic service snapshot' };
  } finally {
    const reports = await Promise.all([aScope.control.close(), bScope.control.close()]);
    assert.ok(reports.every(report => report.complete), 'All acquired native Workers must be physically closed');
    assert.ok(ownedWorkers.every(worker => worker.stopReceipt !== undefined), 'Every prepared Worker needs a native exit receipt');
  }
});

scenario('E02 S09 stale parent-owned effect is fenced after actual Worker exit', async db => {
  const aScope = createScope({ name: 'host-effect-A' });
  const bScope = createScope({ name: 'host-effect-B' });
  const releaseReceiver = Promise.withResolvers<void>();
  const pending: Promise<unknown>[] = [];
  const events: string[] = [];
  const ownedWorkers: FixtureWorker[] = [];
  try {
    const a = await prepareWorker(aScope, 'a', 'effect-A1');
    ownedWorkers.push(a);
    const admitted = await selectReady(db, a, 'select-effect-A');
    a.send({ kind: 'host-write', envelope: { operationId: 'old-operation', effectId: 'guarded-after-exit',
      admission: admitted, stateSchema: 'v1', value: { count: 37 } } });
    const request = await a.next();
    assert.equal(request.kind, 'host-effect');
    if (request.kind !== 'host-effect') throw new Error('Missing native worker host request');
    assert.deepEqual(request.envelope.admission, admitted);
    const guarded = (async () => {
      events.push('guarded-host-request-dispatched');
      await releaseReceiver.promise;
      events.push('guarded-receiver-started');
      return db.guardedWrite(effectInput(request.envelope));
    })();
    const unsafe = (async () => {
      events.push('unsafe-host-request-dispatched');
      await releaseReceiver.promise;
      events.push('unsafe-receiver-started');
      return db.unsafeWriteForNegativeControl(effectInput(request.envelope, 'unsafe-after-exit'));
    })();
    pending.push(guarded, unsafe);
    void guarded.catch(() => {}); void unsafe.catch(() => {});
    const b = await prepareWorker(bScope, 'b', 'effect-B1');
    ownedWorkers.push(b);
    const selected = await selectReady(db, b, 'select-effect-B');
    events.push('B-publication-committed');
    assert.equal((await aScope.control.close()).complete, true);
    assert.ok(a.stopReceipt);
    events.push('A-native-exit-observed');
    assert.notEqual(admitted.effectEpoch, selected.effectEpoch);
    releaseReceiver.resolve();
    const [rejected, accepted] = await Promise.all([guarded, unsafe]);
    assert.equal(rejected.kind, 'stale');
    assert.equal(await db.readEffect('guarded-after-exit'), null);
    assert.equal(accepted.generation, admitted.generation);
    assert.equal(accepted.effectEpoch, admitted.effectEpoch);
    assert.deepEqual(accepted.value, { count: 37 });
    assert.deepEqual(await db.readEffect('unsafe-after-exit'), accepted);
    assert.ok(events.indexOf('guarded-host-request-dispatched') < events.indexOf('A-native-exit-observed'));
    assert.ok(events.indexOf('A-native-exit-observed') < events.indexOf('guarded-receiver-started'));
    return { events, nativeExit: a.stopReceipt, nativeEvents: a.events,
      capturedEnvelope: request.envelope, selected, guarded: rejected, unsafeNegativeControl: accepted,
      limitation: 'test barrier delays parent request before SQL starts; not a lost DB wire request or external network rollback' };
  } finally {
    releaseReceiver.resolve();
    await Promise.allSettled(pending);
    const reports = await Promise.all([aScope.control.close(), bScope.control.close()]);
    assert.ok(reports.every(report => report.complete), 'All acquired native Workers must be physically closed');
    assert.ok(ownedWorkers.every(worker => worker.stopReceipt !== undefined), 'Every prepared Worker needs a native exit receipt');
  }
});
