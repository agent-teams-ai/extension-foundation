import { randomUUID } from 'node:crypto';
import pg from 'pg';
import type { PoolClient } from 'pg';

// Disposable host authority fixture. This is NOT a proposed production store,
// public library SPI, migration framework, or source of plugin graph semantics.
// All transaction bodies below are bounded host SQL. No guest callback is taken.
export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export type Head = Readonly<{
  generation: string; revision: string; effectEpoch: string; cohortDigest: string;
}>;
export type AttemptInput = Readonly<{
  attemptId: string; expectedRevision: string; expectedGeneration: string;
  targetGeneration: string; cohortDigest: string; baselineId: string;
}>;
export type Attempt = AttemptInput & Readonly<{
  status: 'pending' | 'committed' | 'conflict'; result: Head | null;
}>;
export type EffectInput = Readonly<{
  effectId: string; generation: string; effectEpoch: string;
  stateSchema: string; value: Json;
}>;
export type EffectOutcome = Readonly<
  { kind: 'committed' | 'replayed'; receipt: EffectInput } |
  { kind: 'stale'; current: Head }
>;
type Row = Record<string, unknown>;

export function requiredText(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) throw new Error(`Invalid ${label}`);
  return value;
}
function decimal(value: unknown, label: string): string {
  const text = requiredText(value, label);
  if (!/^(0|[1-9][0-9]*)$/.test(text)) throw new Error(`Invalid decimal ${label}`);
  return text;
}
export function isJson(value: unknown): value is Json {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (Array.isArray(value)) return value.every(isJson);
  return typeof value === 'object' && Object.values(value).every(isJson);
}
export function schemaSql(schema: string): string {
  if (!/^state_probe_[a-f0-9]{32}$/.test(schema)) throw new Error('Unexpected fixture schema');
  return `"${schema}"`;
}
function head(row: Row | undefined): Head {
  if (!row) throw new Error('Missing authority head');
  return {
    generation: requiredText(row['generation'], 'generation'),
    revision: decimal(row['revision'], 'revision'),
    effectEpoch: decimal(row['effect_epoch'], 'effect epoch'),
    cohortDigest: requiredText(row['cohort_digest'], 'cohort digest'),
  };
}
function attempt(row: Row | undefined): Attempt {
  if (!row) throw new Error('Missing admitted attempt');
  const status = row['status'];
  if (status !== 'pending' && status !== 'committed' && status !== 'conflict') throw new Error('Bad attempt status');
  const result = row['result_generation'] === null ? null : head({
    generation: row['result_generation'], revision: row['result_revision'],
    effect_epoch: row['result_effect_epoch'], cohort_digest: row['result_cohort_digest'],
  });
  if ((status === 'pending') !== (result === null)) throw new Error('Incoherent receipt');
  return {
    attemptId: requiredText(row['attempt_id'], 'attempt ID'),
    expectedRevision: decimal(row['expected_revision'], 'expected revision'),
    expectedGeneration: requiredText(row['expected_generation'], 'expected generation'),
    targetGeneration: requiredText(row['target_generation'], 'target generation'),
    cohortDigest: requiredText(row['cohort_digest'], 'cohort digest'),
    baselineId: requiredText(row['baseline_id'], 'baseline ID'), status, result,
  };
}
function effect(row: Row | undefined): EffectInput {
  if (!row || !isJson(row['value'])) throw new Error('Invalid effect receipt');
  return {
    effectId: requiredText(row['effect_id'], 'effect ID'),
    generation: requiredText(row['generation'], 'generation'),
    effectEpoch: decimal(row['effect_epoch'], 'effect epoch'),
    stateSchema: requiredText(row['state_schema'], 'state schema'), value: row['value'],
  };
}
function effectValues(input: EffectInput): unknown[] {
  if (!isJson(input.value)) throw new Error('Effect is not JSON');
  decimal(input.effectEpoch, 'effect epoch');
  return [input.effectId, input.generation, input.effectEpoch, input.stateSchema, JSON.stringify(input.value)];
}
function sameAttempt(input: AttemptInput, existing: Attempt): boolean {
  return input.attemptId === existing.attemptId && input.expectedRevision === existing.expectedRevision &&
    input.expectedGeneration === existing.expectedGeneration && input.targetGeneration === existing.targetGeneration &&
    input.cohortDigest === existing.cohortDigest && input.baselineId === existing.baselineId;
}
export function fixtureConnectionString(): string {
  return requiredText(process.env['DATABASE_URL'], 'DATABASE_URL');
}

// Shared host-only SQL routine lets the fault child stop before COMMIT without
// introducing a public transaction callback into the feature seam.
export async function stagePublicationForFaultProbe(client: PoolClient, schema: string, attemptId: string): Promise<Attempt> {
  const s = schemaSql(schema);
  // Lock order is attempt -> head; same attempt cannot independently re-run CAS.
  const recorded = attempt((await client.query<Row>(
    `SELECT * FROM ${s}.attempts WHERE attempt_id = $1 FOR UPDATE`, [attemptId],
  )).rows[0]);
  if (recorded.status !== 'pending') return recorded;
  const changed = await client.query<Row>(
    `UPDATE ${s}.head SET generation=$1, revision=revision+1,
       effect_epoch=effect_epoch+1, cohort_digest=$2
     WHERE singleton AND revision=$3::bigint AND generation=$4 RETURNING *`,
    [recorded.targetGeneration, recorded.cohortDigest, recorded.expectedRevision, recorded.expectedGeneration],
  );
  const selected = changed.rows[0] ?? (await client.query<Row>(`SELECT * FROM ${s}.head WHERE singleton`)).rows[0];
  const outcome = head(selected);
  const status = changed.rowCount === 1 ? 'committed' : 'conflict';
  return attempt((await client.query<Row>(
    `UPDATE ${s}.attempts SET status=$2, result_generation=$3, result_revision=$4::bigint,
      result_effect_epoch=$5::bigint, result_cohort_digest=$6
     WHERE attempt_id=$1 RETURNING *`,
    [attemptId, status, outcome.generation, outcome.revision, outcome.effectEpoch, outcome.cohortDigest],
  )).rows[0]);
}

export class StateFixture {
  readonly schema: string;
  readonly sql: string;
  readonly #pool: pg.Pool;
  constructor(schema: string) {
    this.schema = schema;
    this.sql = schemaSql(schema);
    this.#pool = new pg.Pool({
      connectionString: fixtureConnectionString(), max: 12,
      application_name: schema, connectionTimeoutMillis: 5000,
      options: '-c statement_timeout=15000 -c lock_timeout=12000',
    });
  }
  static async create(): Promise<StateFixture> {
    const db = new StateFixture(`state_probe_${randomUUID().replaceAll('-', '')}`);
    try {
      await db.#pool.query(`CREATE SCHEMA ${db.sql}`);
      await db.#pool.query(`
        CREATE TABLE ${db.sql}.head (
          singleton boolean PRIMARY KEY CHECK (singleton), generation text NOT NULL,
          revision bigint NOT NULL CHECK(revision>=0), effect_epoch bigint NOT NULL CHECK(effect_epoch>=0),
          cohort_digest text NOT NULL);
        INSERT INTO ${db.sql}.head VALUES (true, 'A1', 0, 0, 'artifact-A');
        CREATE TABLE ${db.sql}.snapshots (baseline_id text PRIMARY KEY, value jsonb NOT NULL);
        INSERT INTO ${db.sql}.snapshots VALUES ('S0', '{"count":0}');
        CREATE TABLE ${db.sql}.attempts (
          attempt_id text PRIMARY KEY, expected_revision bigint NOT NULL,
          expected_generation text NOT NULL, target_generation text NOT NULL,
          cohort_digest text NOT NULL, baseline_id text NOT NULL REFERENCES ${db.sql}.snapshots,
          status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','committed','conflict')),
          result_generation text, result_revision bigint, result_effect_epoch bigint, result_cohort_digest text,
          CHECK ((status='pending') = (result_generation IS NULL)),
          CHECK ((status='pending') = (result_revision IS NULL)),
          CHECK ((status='pending') = (result_effect_epoch IS NULL)),
          CHECK ((status='pending') = (result_cohort_digest IS NULL)));
        CREATE TABLE ${db.sql}.effects (
          effect_id text PRIMARY KEY, generation text NOT NULL, effect_epoch bigint NOT NULL,
          state_schema text NOT NULL, value jsonb NOT NULL);
        CREATE TABLE ${db.sql}.business_state (state_key text PRIMARY KEY, value jsonb NOT NULL);
        CREATE TABLE ${db.sql}.artifacts (digest text PRIMARY KEY);
        CREATE TABLE ${db.sql}.holds (hold_id text PRIMARY KEY,
          digest text NOT NULL REFERENCES ${db.sql}.artifacts(digest) ON DELETE RESTRICT);
        CREATE TABLE ${db.sql}.snapshot_gap (id text PRIMARY KEY, value text NOT NULL);
      `);
      return db;
    } catch (error) {
      await db.destroy();
      throw error;
    }
  }
  // Test ownership, outside the feature seam. Every borrowed client is released.
  async client(): Promise<PoolClient> { return this.#pool.connect(); }
  async close(): Promise<void> { await this.#pool.end(); }
  async destroy(): Promise<void> {
    try { await this.#pool.query(`DROP SCHEMA IF EXISTS ${this.sql} CASCADE`); }
    finally { await this.#pool.end(); }
  }
  async readHead(): Promise<Head> {
    return head((await this.#pool.query<Row>(`SELECT * FROM ${this.sql}.head WHERE singleton`)).rows[0]);
  }
  async admitAttempt(input: AttemptInput): Promise<Attempt> {
    decimal(input.expectedRevision, 'expected revision');
    const client = await this.client();
    try {
      // Separate statements intentionally: a conflicting insert can be absent
      // from the INSERT statement snapshot under READ COMMITTED (S12).
      await client.query(`INSERT INTO ${this.sql}.attempts
        (attempt_id,expected_revision,expected_generation,target_generation,cohort_digest,baseline_id)
        VALUES ($1,$2::bigint,$3,$4,$5,$6) ON CONFLICT (attempt_id) DO NOTHING`,
      [input.attemptId, input.expectedRevision, input.expectedGeneration, input.targetGeneration, input.cohortDigest, input.baselineId]);
      const existing = attempt((await client.query<Row>(
        `SELECT * FROM ${this.sql}.attempts WHERE attempt_id=$1`, [input.attemptId],
      )).rows[0]);
      if (!sameAttempt(input, existing)) throw new Error('Attempt input mismatch');
      return existing;
    } finally { client.release(); }
  }
  async observeAttempt(attemptId: string): Promise<Attempt | null> {
    const row = (await this.#pool.query<Row>(`SELECT * FROM ${this.sql}.attempts WHERE attempt_id=$1`, [attemptId])).rows[0];
    return row ? attempt(row) : null;
  }
  async publishAttempt(attemptId: string): Promise<Attempt> {
    const client = await this.client();
    try {
      await client.query('BEGIN ISOLATION LEVEL READ COMMITTED');
      const result = await stagePublicationForFaultProbe(client, this.schema, attemptId);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }
  async guardedWrite(input: EffectInput): Promise<EffectOutcome> {
    const values = effectValues(input);
    const client = await this.client();
    const readReceipt = async (): Promise<EffectInput | null> => {
      const row = (await client.query<Row>(`SELECT *,
        (generation=$2 AND effect_epoch=$3::bigint AND state_schema=$4 AND value=$5::jsonb) AS same
        FROM ${this.sql}.effects WHERE effect_id=$1`, values)).rows[0];
      if (!row) return null;
      if (row['same'] !== true) throw new Error('Effect input mismatch');
      return effect(row);
    };
    try {
      await client.query('BEGIN ISOLATION LEVEL READ COMMITTED');
      // head -> effect order. FOR KEY SHARE would allow a non-key UPDATE.
      const current = head((await client.query<Row>(`SELECT * FROM ${this.sql}.head WHERE singleton FOR SHARE`)).rows[0]);
      const previous = await readReceipt();
      if (previous) {
        await client.query('COMMIT');
        return { kind: 'replayed', receipt: previous };
      }
      if (current.generation !== input.generation || current.effectEpoch !== input.effectEpoch) {
        await client.query('COMMIT');
        return { kind: 'stale', current };
      }
      const inserted = await client.query<Row>(`INSERT INTO ${this.sql}.effects
        (effect_id,generation,effect_epoch,state_schema,value) VALUES ($1,$2,$3::bigint,$4,$5::jsonb)
        ON CONFLICT (effect_id) DO NOTHING RETURNING *`, values);
      // A fresh SELECT after a uniqueness wait validates the actual winner.
      const receipt = inserted.rowCount === 1 ? effect(inserted.rows[0]) : await readReceipt();
      if (!receipt) throw new Error('Missing committed effect after uniqueness reconciliation');
      await client.query('COMMIT');
      return { kind: inserted.rowCount === 1 ? 'committed' : 'replayed', receipt };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }
  // Deliberately unsafe negative-control receiver; never presented as an adapter.
  async unsafeWriteForNegativeControl(input: EffectInput): Promise<EffectInput> {
    return effect((await this.#pool.query<Row>(`INSERT INTO ${this.sql}.effects
      (effect_id,generation,effect_epoch,state_schema,value) VALUES ($1,$2,$3::bigint,$4,$5::jsonb) RETURNING *`,
    effectValues(input))).rows[0]);
  }
  async readEffect(effectId: string): Promise<EffectInput | null> {
    const row = (await this.#pool.query<Row>(`SELECT * FROM ${this.sql}.effects WHERE effect_id=$1`, [effectId])).rows[0];
    return row ? effect(row) : null;
  }
}
