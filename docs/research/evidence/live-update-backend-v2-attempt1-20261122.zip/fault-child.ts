import { StateFixture, requiredText, stagePublicationForFaultProbe } from './state-fixture.ts';

// Disposable controller process. It never instantiates a plugin Worker. Durable
// head recovery here cannot establish restored execution readiness or heap state.
const mode = requiredText(process.argv[2], 'fault mode');
const schema = requiredText(process.argv[3], 'schema');
const attemptId = requiredText(process.argv[4], 'attempt ID');
const db = new StateFixture(schema);
if (mode === 'commit-no-reply') {
  await db.publishAttempt(attemptId);
  // Commit was acknowledged to this child, but no application reply reaches the
  // parent. This intentionally does not claim a lost PostgreSQL COMMIT ACK.
  process.exit(73);
} else if (mode === 'stage-without-commit') {
  const client = await db.client();
  await client.query('BEGIN ISOLATION LEVEL READ COMMITTED');
  const row = (await client.query<{ pid: number }>('SELECT pg_backend_pid() AS pid')).rows[0];
  if (!row || !Number.isInteger(row.pid)) throw new Error('No backend PID');
  await stagePublicationForFaultProbe(client, schema, attemptId);
  if (!process.send) throw new Error('Fault child needs IPC');
  process.send({ kind: 'staged', backendPid: row.pid });
  // IPC/DB handles keep the process alive; parent SIGKILL forces backend rollback.
  await new Promise<never>(() => {});
} else if (mode === 'admit-no-reply') {
  await db.admitAttempt({
    attemptId, expectedRevision: '0', expectedGeneration: 'A1',
    targetGeneration: 'B1', cohortDigest: 'artifact-B', baselineId: 'S0',
  });
  process.exit(74);
} else {
  await db.close();
  throw new Error(`Unknown fault mode: ${mode}`);
}
