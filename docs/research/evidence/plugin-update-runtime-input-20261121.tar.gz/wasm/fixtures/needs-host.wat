;; Exact Component Model syntax fixture: a genuinely required host import.
(component
  (type $audit-type (func (param "amount" u32)))
  (import "audit" (func $audit (type $audit-type)))
  (core func $audit-lowered (canon lower (func $audit)))
  (core module $module
    (import "host" "audit" (func $audit (param i32)))
    (func (export "schema-version") (result i32) i32.const 1)
    (func (export "quote") (param i32) (result i32)
      local.get 0
      call $audit
      local.get 0))
  (core instance $instance (instantiate $module
    (with "host" (instance (export "audit" (func $audit-lowered))))))
  (func (export "schema-version") (result u32)
    (canon lift (core func $instance "schema-version")))
  (func (export "quote") (param "cents" u32) (result u32)
    (canon lift (core func $instance "quote"))))
