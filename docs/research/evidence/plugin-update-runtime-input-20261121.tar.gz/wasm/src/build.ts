import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { basename, dirname, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { guardCompilerLoads } from './compiler-guard.js';

const compilerLoads = guardCompilerLoads();
const output = resolve('artifacts');
await mkdir(output, { recursive: true });
let clearBuildPreopens: (() => void) | undefined;
try {
const directShim = import.meta.resolve('@bytecodealliance/preview2-shim/filesystem');
const splicerShim = pathToFileURL(createRequire(import.meta.resolve('@bytecodealliance/componentize-js')).resolve('@bytecodealliance/preview2-shim/filesystem')).href;
if (directShim !== splicerShim) throw new Error('Build splicer resolves a different filesystem shim');
const shimIdentity: unknown = JSON.parse(await readFile(new URL('../../package.json', directShim), 'utf8'));
if (typeof shimIdentity !== 'object' || shimIdentity === null || !('name' in shimIdentity) ||
  shimIdentity.name !== '@bytecodealliance/preview2-shim' || !('version' in shimIdentity) || shimIdentity.version !== '0.31.1') throw new Error('Unexpected build filesystem shim');
const { _setPreopens, _clearPreopens } = await import('@bytecodealliance/preview2-shim/filesystem');
clearBuildPreopens = _clearPreopens;
// Trusted, serial build input only. This mapping does not claim a read-only sandbox.
_setPreopens({ '/wit': resolve('wit') });
const { componentize } = await import('@bytecodealliance/componentize-js');
const { transpileBytes } = await import('@bytecodealliance/jco-transpile');
const { parse, componentEmbed, componentNew, componentWit } = await import('@bytecodealliance/jco-transpile/wasm-tools');

function rust(args: string[]): string {
  const result = spawnSync('rustc', args, { encoding: 'utf8' });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`rustc failed: ${result.stderr}`);
  return result.stdout;
}
const rustVersion = rust(['--version', '--verbose']);
if (!rustVersion.startsWith('rustc 1.100.0 ')) throw new Error(`Unexpected Rust: ${rustVersion}`);
const receipt: Record<string, unknown> = { node: process.version, rustVersion, compilerLoads,
  buildFilesystem: { version: shimIdentity.version, directShim, splicerShim, mappedDirectory: '/wit' }, artifacts: [] };
const artifacts: unknown[] = [];

async function emit(name: string, bytes: Uint8Array, buildMs: number): Promise<void> {
  const folder = resolve(output, name);
  await mkdir(folder, { recursive: true });
  await writeFile(resolve(folder, `${name}.component.wasm`), bytes);
  const wit = await componentWit(bytes);
  await writeFile(resolve(folder, `${name}.wit`), wit);
  const start = performance.now();
  const generated = await transpileBytes(bytes, {
    name, instantiation: 'async', nodejsCompat: false, base64Cutoff: 0,
    wasiShim: false, emitTypescriptDeclarations: true, strict: true,
  });
  const fileSizes: Array<{ name: string; bytes: number; sha256: string }> = [];
  for (const [name, data] of Object.entries(generated.files)) {
    const path = resolve(folder, name);
    if (!path.startsWith(`${folder}/`)) throw new Error('Generated path outside artifact folder');
    await mkdir(dirname(path), { recursive: true });
    await writeFile(path, data);
    fileSizes.push({ name, bytes: data.byteLength, sha256: createHash('sha256').update(data).digest('hex') });
  }
  artifacts.push({
    name, componentBytes: bytes.byteLength, componentSha256: createHash('sha256').update(bytes).digest('hex'),
    buildMs, transpileMs: performance.now() - start, imports: generated.imports,
    generatedCoreBytes: fileSizes.filter(f => f.name.endsWith('.wasm')).reduce((n, f) => n + f.bytes, 0),
    generatedGlueBytes: fileSizes.filter(f => f.name.endsWith('.js')).reduce((n, f) => n + f.bytes, 0),
    declarationBytes: fileSizes.filter(f => f.name.endsWith('.d.ts')).reduce((n, f) => n + f.bytes, 0),
    externalRuntimeShims: generated.imports, files: fileSizes,
  });
}

const tsStart = performance.now();
const ts = await componentize({
  sourcePath: resolve('dist/guest.js'), witPath: '/wit/quote.wit', worldName: 'quote-plugin',
  disableFeatures: ['stdio', 'random', 'clocks', 'http', 'fetch-event'], enableAot: false,
});
await emit('typescript-v1', ts.component, performance.now() - tsStart);

for (const [name, extraArgs] of [['rust-v2', []], ['rust-schema-two', ['--cfg', 'schema_two']]] as const) {
  const start = performance.now();
  const corePath = resolve(output, `${name}.core.wasm`);
  rust(['--edition=2024', '--crate-type=cdylib', '--target=wasm32-unknown-unknown',
    '--check-cfg', 'cfg(schema_two)', '-C', 'opt-level=z', '-C', 'panic=abort',
    '-C', 'strip=symbols', ...extraArgs, 'rust/quote.rs', '-o', corePath]);
  const typed = await componentEmbed({ binary: await readFile(corePath), witSource: await readFile('wit/quote.wit', 'utf8'), world: 'quote-plugin' });
  await emit(name, await componentNew(typed), performance.now() - start);
}
const missingStart = performance.now();
await emit('needs-host', await parse(await readFile('fixtures/needs-host.wat', 'utf8')), performance.now() - missingStart);
receipt['artifacts'] = artifacts;
receipt['plainEsm'] = { name: basename(resolve('dist/guest.js')), bytes: (await readFile('dist/guest.js')).byteLength };
if (compilerLoads.rejected.length !== 0) throw new Error('Rejected compiler request during build');
await writeFile(resolve(output, 'build-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt));
} finally {
  clearBuildPreopens?.();
  await writeFile(resolve(output, 'build-compiler-loads.json'), JSON.stringify(compilerLoads, null, 2) + '\n');
}
