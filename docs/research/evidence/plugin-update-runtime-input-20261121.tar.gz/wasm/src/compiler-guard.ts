import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { registerHooks } from 'node:module';

// Observe ordinary module loading. Never rewrite a resolution or dependency.
export function guardCompilerLoads(): { loaded: string[]; rejected: string[] } {
  const evidence = { loaded: new Array<string>(), rejected: new Array<string>() };
  const checked = new Map<string, string | null>();
  registerHooks({
    load(url, context, nextLoad) {
      if (url.startsWith('file:') && url.includes('/node_modules/')) {
        const path = fileURLToPath(url);
        let folder = dirname(path);
        let version: string | null = null;
        const visited: string[] = [];
        while (folder.includes('/node_modules')) {
          if (checked.has(folder)) { version = checked.get(folder) ?? null; break; }
          visited.push(folder);
          const manifest = join(folder, 'package.json');
          if (existsSync(manifest)) {
            const data: unknown = JSON.parse(readFileSync(manifest, 'utf8'));
            if (typeof data === 'object' && data !== null && 'name' in data && typeof data.name === 'string') {
              if (data.name === 'typescript') {
                if (!('version' in data) || typeof data.version !== 'string') throw new Error('Missing compiler version');
                version = data.version;
              }
              break;
            }
          }
          folder = dirname(folder);
        }
        for (const item of visited) checked.set(item, version);
        if (version !== null) {
          if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error(`Unrecognized compiler version: ${version}`);
          const [major = 0, minor = 0, patch = 0] = version.split('.').map(Number);
          if (major < 7 || (major === 7 && minor === 0 && patch < 2)) {
            evidence.rejected.push(`${version}: ${path}`);
            throw new Error(`Compiler below 7.0.2 rejected before evaluation: ${version}`);
          }
          evidence.loaded.push(`${version}: ${path}`);
        }
      }
      return nextLoad(url, context);
    },
  });
  return evidence;
}
