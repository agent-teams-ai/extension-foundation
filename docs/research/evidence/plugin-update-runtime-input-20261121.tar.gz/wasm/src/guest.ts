export function schemaVersion(): number {
  return 1;
}

export function quote(cents: number): number {
  return cents + 700;
}
