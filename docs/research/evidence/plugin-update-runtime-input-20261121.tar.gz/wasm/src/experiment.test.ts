import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { basename, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { guardCompilerLoads } from './compiler-guard.js';
import { quote as nativeQuote } from './guest.js';

const compilerLoads = guardCompilerLoads();
const observations: Array<{ name: string; observed: unknown; expected: unknown }> = [];
const rejections: Array<{ name: string; kind: string; message: string }> = [];
function recordRejection(name: string, error: unknown): true {
  rejections.push({ name, kind: error instanceof Error ? error.name : typeof error, message: String(error) });
  return true;
}
function observed(name: string, actual: unknown, expected: unknown): void {
  assert.deepEqual(actual, expected, name);
  observations.push({ name, observed: actual, expected });
}
function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
interface Prepared { name: string; quote: (cents: number) => number; readinessResult: number }
async function prepare(name: string, imports: Record<string, unknown> = {}): Promise<Prepared> {
  const folder = resolve('artifacts', name);
  const mod: unknown = await import(pathToFileURL(resolve(folder, `${name}.js`)).href);
  if (!isObject(mod) || typeof mod['instantiate'] !== 'function') throw new Error('Missing instantiate');
  const guest: unknown = await mod['instantiate'](async (path: string) => {
    if (basename(path) !== path) throw new Error('Unexpected generated core path');
    return WebAssembly.compile(await readFile(resolve(folder, path)));
  }, imports);
  if (!isObject(guest) || typeof guest['schemaVersion'] !== 'function' || typeof guest['quote'] !== 'function') throw new Error('Invalid component exports');
  const schema: unknown = guest['schemaVersion']();
  if (schema !== 1) throw new Error(`Incompatible schema ${String(schema)}`);
  const invoke = guest['quote'];
  const quote = (cents: number): number => {
    if (!Number.isInteger(cents) || cents < 0 || cents > 1_000_000) throw new Error('Fixture input out of bounds');
    const value: unknown = invoke(cents);
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) throw new Error('Invalid quote output');
    return value;
  };
  return { name, quote, readinessResult: quote(10_000) };
}

test('source-built TS and Rust components preserve owner selection and explicit compatibility', async () => {
  try {
  const cart = { schema: 1, cents: 10_000, note: 'Keep this user draft' };
  const originalCart = structuredClone(cart);
  observed('plain emitted TypeScript baseline', nativeQuote(cart.cents), 10_700);
  let selected = await prepare('typescript-v1');
  observed('typescript readiness', selected.readinessResult, 10_700);
  observed('typescript invocation', selected.quote(cart.cents), 10_700);
  const captured = { quote: selected.quote, cents: cart.cents };
  // This admitted host operation invokes guest code after switching; no Wasm stack is suspended.
  const held = () => captured.quote(captured.cents);
  const candidate = await prepare('rust-v2');
  observed('rust readiness', candidate.readinessResult, 9_700);
  selected = candidate;
  cart.cents = 20_000;
  observed('new input and new implementation', selected.quote(cart.cents), 18_700);
  observed('held callable and input', held(), 10_700);
  cart.cents = 10_000;
  observed('selected implementation', selected.name, 'rust-v2');
  observed('host cart preserved', cart, originalCart);

  const auditAmounts: number[] = [];
  const withAudit = await prepare('needs-host', { audit: (amount: number) => { auditAmounts.push(amount); } });
  observed('same import-bearing bytes with real host function', withAudit.readinessResult, 10_000);
  observed('actual host import receives readiness input', auditAmounts, [10_000]);
  observed('positive import control does not select itself', selected.name, 'rust-v2');
  await assert.rejects(prepare('needs-host'), (error: unknown) => {
    assert.match(String(error), /audit|import|function/i);
    return recordRejection('missing required host import', error);
  });
  observed('missing import preserves selection', selected.quote(cart.cents), 9_700);
  observed('missing import preserves cart', cart, originalCart);
  await assert.rejects(prepare('rust-schema-two'), (error: unknown) => {
    assert.match(String(error), /Incompatible schema 2/);
    return recordRejection('same typed ABI incompatible state schema', error);
  });
  observed('typed ABI schema rejection preserves selection', selected.quote(cart.cents), 9_700);
  observed('schema rejection preserves cart', cart, originalCart);

  const { componentEmbed, componentNew } = await import('@bytecodealliance/jco-transpile/wasm-tools');
  await assert.rejects(async () => componentNew(await componentEmbed({
    binary: await readFile('artifacts/rust-v2.core.wasm'),
    witSource: await readFile('wit/mismatch.wit', 'utf8'), world: 'quote-plugin',
  })), (error: unknown) => {
    assert.match(String(error), /quote|type|parameter/i);
    return recordRejection('mismatched WIT and compiled signature', error);
  });
  observed('incompatible WIT preserves active behavior', selected.quote(cart.cents), 9_700);

  const { transpileBytes } = await import('@bytecodealliance/jco-transpile');
  await assert.rejects(transpileBytes(new Uint8Array([0, 97, 115, 109, 1, 0])), (error: unknown) => recordRejection('malformed component bytes', error));
  observed('malformed candidate preserves active behavior', selected.quote(cart.cents), 9_700);
  const component = await readFile('artifacts/typescript-v1/typescript-v1.component.wasm');
  await assert.rejects(WebAssembly.compile(component), (error: unknown) => {
    assert.ok(error instanceof WebAssembly.CompileError);
    return recordRejection('component binary is not directly accepted as core Wasm', error);
  });
  observed('no forbidden compiler requested', compilerLoads.rejected, []);
  observed('inspected runtime path loads no TypeScript compiler', compilerLoads.loaded, []);
  await writeFile('artifacts/runtime-results.json', JSON.stringify({ node: process.version, observations, rejections, compilerLoads,
    boundary: 'Node host, scalar synchronous WIT; held host operation, no executing guest stack migration' }, null, 2) + '\n');
  } finally {
    await writeFile('artifacts/runtime-compiler-loads.json', JSON.stringify(compilerLoads, null, 2) + '\n');
  }
});
