#![no_std]

// Deliberately scalar canonical ABI; this is not a general Rust component SDK.
#[unsafe(export_name = "schema-version")]
pub extern "C" fn schema_version() -> u32 {
    if cfg!(schema_two) { 2 } else { 1 }
}

#[unsafe(export_name = "quote")]
pub extern "C" fn quote(cents: u32) -> u32 {
    cents * 9 / 10 + 700
}

#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! {
    core::arch::wasm32::unreachable()
}
