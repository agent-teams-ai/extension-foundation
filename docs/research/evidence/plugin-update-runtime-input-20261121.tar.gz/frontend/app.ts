type Outcome = { status: "ok"; value: number } | { status: "rejected" | "cancelled" | "interrupted" };
type Packet = { kind: "ready"; version: string; protocol: number; schema: string }
  | { kind: "result"; id: number; value: number }
  | { kind: "held" | "entered" | "cancelled"; id: number };
type Instance = { worker: Worker; version: string; incarnation: number };
type Pending = { instance: Instance; revision: number; inbox: boolean; resolve: (outcome: Outcome) => void };
type Proposal = { id: number; value: number; revision: number; incarnation: number };

function parsePacket(value: unknown): Packet {
  if (typeof value !== "object" || value === null || !("kind" in value)) throw new Error("invalid packet");
  if (value.kind === "ready" && "version" in value && typeof value.version === "string"
    && "protocol" in value && typeof value.protocol === "number" && "schema" in value && typeof value.schema === "string") {
    return { kind: "ready", version: value.version, protocol: value.protocol, schema: value.schema };
  }
  if (!("id" in value) || typeof value.id !== "number" || !Number.isSafeInteger(value.id)) throw new Error("invalid id");
  if (value.kind === "result" && "value" in value && typeof value.value === "number" && Number.isFinite(value.value)) {
    return { kind: "result", id: value.id, value: value.value };
  }
  if (value.kind === "held" || value.kind === "entered" || value.kind === "cancelled") return { kind: value.kind, id: value.id };
  throw new Error("unsupported packet");
}

const draftElement = document.querySelector("#draft");
const inputElement = document.querySelector("#input");
const resultElement = document.querySelector("#result");
const statusElement = document.querySelector("#status");
if (!(draftElement instanceof HTMLTextAreaElement) || !(inputElement instanceof HTMLInputElement) || !resultElement || !statusElement) throw new Error("missing UI");
const draft = draftElement;
const input = inputElement;
const result = resultElement;
const status = statusElement;
const documentToken = crypto.randomUUID();
const pending = new Map<number, Pending>();
const completions = new Map<number, Promise<Outcome>>();
const outcomes = new Map<number, Outcome>();
const inbox: Proposal[] = [];
const events: string[] = [];
const faults: string[] = [];
let selected: Instance | undefined;
let candidate: Instance | undefined;
let admission = true;
let revision = 1;
let nextIncarnation = 0;
let nextRequest = 0;
let forceCalls = 0;
let rejectedCommits = 0;
let committed = 0;
let draining = false;
let drainDone: (() => void) | undefined;

function snapshot() {
  return { documentToken, draft: draft.value, selected: selected?.version ?? null,
    incarnation: selected?.incarnation ?? null, revision, admission, pending: pending.size,
    forceCalls, rejectedCommits, committed, inbox: inbox.length, events: [...events], faults: [...faults], outcomes: Object.fromEntries(outcomes) };
}
function render(): void { status.textContent = JSON.stringify(snapshot(), null, 2); }
function selectPrepared(alreadyTerminated = false): void {
  if (!candidate || !selected) throw new Error("replacement not ready");
  const old = selected;
  selected = candidate;
  candidate = undefined;
  revision += 1;
  if (!alreadyTerminated) old.worker.terminate();
  admission = true;
  events.push(`selected:${selected.version}`);
  render();
}
function maybeDrained(): void {
  if (draining && pending.size === 0) {
    draining = false;
    selectPrepared();
    drainDone?.();
    drainDone = undefined;
  }
}
function settle(id: number, outcome: Outcome): void {
  const operation = pending.get(id);
  if (!operation) return;
  pending.delete(id);
  outcomes.set(id, outcome);
  operation.resolve(outcome);
  maybeDrained();
  render();
}
function commit(proposal: Proposal): void {
  const operation = pending.get(proposal.id);
  if (!operation || proposal.revision !== revision || proposal.incarnation !== selected?.incarnation
    || operation.instance.incarnation !== proposal.incarnation) {
    rejectedCommits += 1;
    events.push(`rejected-commit:${proposal.id}`);
    render();
    return;
  }
  committed += 1;
  result.textContent = String(proposal.value);
  settle(proposal.id, { status: "ok", value: proposal.value });
}
async function prepare(name: string): Promise<void> {
  const response = await fetch(`/artifact/${name}`);
  if (!response.ok) throw new Error(`artifact HTTP ${response.status}`);
  const artifact: unknown = await response.json();
  if (typeof artifact !== "object" || artifact === null || !("code" in artifact) || typeof artifact.code !== "string"
    || !("sha256" in artifact) || typeof artifact.sha256 !== "string") throw new Error("invalid artifact");
  const digest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(artifact.code)))].map(x => x.toString(16).padStart(2, "0")).join("");
  if (digest !== artifact.sha256) throw new Error("artifact digest mismatch");
  const url = URL.createObjectURL(new Blob([artifact.code], { type: "text/javascript" }));
  const worker = new Worker(url);
  const instance = { worker, version: name, incarnation: ++nextIncarnation };
  try {
    await new Promise<void>((resolve, reject) => {
      let ready = false;
      const fault = (error: unknown): void => {
        if (ready) { faults.push(`${name}: ${String(error)}`); render(); }
        else reject(error);
      };
      worker.onerror = event => { event.preventDefault(); fault(new Error(event.message)); };
      worker.onmessage = (event: MessageEvent<unknown>) => {
        try {
          const packet = parsePacket(event.data);
          if (packet.kind === "ready") {
            if (ready) throw new Error("duplicate readiness");
            if (packet.protocol !== 1 || packet.schema !== "quote-input/v1" || packet.version !== name) throw new Error("incompatible candidate");
            ready = true;
            events.push(`ready:${name}`);
            resolve();
            return;
          }
          const operation = pending.get(packet.id);
          if (!operation || operation.instance !== instance) throw new Error("unknown response");
          if (packet.kind === "result") {
            const proposal = { id: packet.id, value: packet.value, revision: operation.revision, incarnation: instance.incarnation };
            if (operation.inbox) { inbox.push(proposal); events.push(`inbox:${packet.id}`); }
            else commit(proposal);
          } else if (packet.kind === "cancelled") settle(packet.id, { status: "cancelled" });
          else events.push(`${packet.kind}:${packet.id}`);
          render();
        } catch (error) { fault(error); }
      };
    });
    candidate?.worker.terminate();
    candidate = instance;
  } catch (error) { worker.terminate(); throw error; }
  finally { URL.revokeObjectURL(url); }
  render();
}
function request(value: number, mode: "normal" | "hold" | "busy" = "normal", holdInbox = false): number {
  const id = ++nextRequest;
  if (!admission || !selected) {
    const outcome: Outcome = { status: "rejected" };
    outcomes.set(id, outcome); completions.set(id, Promise.resolve(outcome)); render(); return id;
  }
  const instance = selected;
  const completion = new Promise<Outcome>(resolve => pending.set(id, { instance, revision, inbox: holdInbox, resolve }));
  completions.set(id, completion);
  instance.worker.postMessage({ kind: "quote", id, input: value, mode });
  render();
  return id;
}
function control(id: number, kind: "release" | "cancel"): void {
  const operation = pending.get(id);
  if (!operation) throw new Error("missing operation");
  operation.instance.worker.postMessage({ kind, id });
}
function drain(): Promise<void> {
  if (!candidate || draining) throw new Error("replacement not ready or already draining");
  admission = false;
  draining = true;
  events.push("admission-closed");
  return new Promise<void>(resolve => { drainDone = resolve; maybeDrained(); render(); });
}
function force(allowed: boolean): "denied" | "selected" {
  if (!allowed) return "denied";
  if (!candidate || !selected || draining) throw new Error("replacement not ready or drain pending");
  admission = false;
  revision += 1;
  selected.worker.terminate();
  forceCalls += 1;
  events.push("terminate-invoked:no-exit-receipt");
  for (const id of [...pending.keys()]) settle(id, { status: "interrupted" });
  selectPrepared(true);
  return "selected";
}
const api = { snapshot, prepare, request, control, drain, force,
  completion(id: number): Promise<Outcome> { const value = completions.get(id); if (!value) throw new Error("unknown request"); return value; },
  flushInbox(): void { for (const proposal of inbox.splice(0)) commit(proposal); render(); } };
declare global { interface Window { spike: typeof api } }
window.spike = api;
document.querySelector("#run")?.addEventListener("click", () => request(Number(input.value)));
await prepare("v1");
selected = candidate;
candidate = undefined;
events.push("selected:v1");
render();

export {};
