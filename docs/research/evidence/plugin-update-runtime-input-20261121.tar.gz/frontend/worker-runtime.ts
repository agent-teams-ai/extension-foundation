function startWorker(version: string, quote: (input: number) => number, protocol = 1): void {
  const held = new Map<number, { input: number; abort: AbortController }>();
  postMessage({ kind: "ready", version, protocol, schema: "quote-input/v1" });
  onmessage = (event: MessageEvent<unknown>): void => {
    const message = event.data;
    if (typeof message !== "object" || message === null || !("kind" in message)
      || !("id" in message) || typeof message.id !== "number" || !Number.isSafeInteger(message.id)) {
      throw new Error("invalid command");
    }
    const id = message.id;
    if (message.kind === "quote" && "input" in message && typeof message.input === "number"
      && Number.isFinite(message.input) && "mode" in message) {
      if (message.mode === "busy") {
        postMessage({ kind: "entered", id });
        for (;;) { /* Intentionally noncooperative, no external effects. */ }
      }
      if (message.mode === "hold") {
        const abort = new AbortController();
        held.set(id, { input: message.input, abort });
        abort.signal.addEventListener("abort", () => {
          if (held.delete(id)) postMessage({ kind: "cancelled", id });
        }, { once: true });
        postMessage({ kind: "held", id });
        return;
      }
      if (message.mode === "normal") {
        postMessage({ kind: "result", id, value: quote(message.input) });
        return;
      }
    }
    const operation = held.get(id);
    if (message.kind === "release" && operation) {
      held.delete(id);
      postMessage({ kind: "result", id, value: quote(operation.input) });
      return;
    }
    if (message.kind === "cancel" && operation) {
      operation.abort.abort("owner-requested");
      return;
    }
    throw new Error("unsupported command or unknown operation");
  };
}
