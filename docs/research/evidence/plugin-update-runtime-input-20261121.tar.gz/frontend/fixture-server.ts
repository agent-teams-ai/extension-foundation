import { createServer } from "node:http";
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";

const execute = promisify(execFile);
export const directory = import.meta.dirname;
export async function compileWorker(name: "v1" | "v2" | "failed" | "incompatible"): Promise<void> {
  await mkdir(resolve(directory, "generated"), { recursive: true });
  const config = `generated/build-${name}.json`;
  await writeFile(resolve(directory, config), JSON.stringify({ extends: "../tsconfig.worker.json",
    compilerOptions: { noEmit: false, noEmitOnError: true, rootDir: "..", outDir: `worker-compiled/${name}` },
    files: ["../worker-runtime.ts", `../entries/${name}.ts`], include: [] }, null, 2));
  await execute(process.execPath, [resolve(directory, "node_modules/typescript/bin/tsc"), "-p", config, "--pretty", "false"], { cwd: directory });
  const emitted = resolve(directory, `generated/worker-compiled/${name}`);
  const runtime = await readFile(resolve(emitted, "worker-runtime.js"), "utf8");
  const entry = await readFile(resolve(emitted, `entries/${name}.js`), "utf8");
  await writeFile(resolve(directory, `generated/worker-${name}.js`), `${runtime}\n${entry}`);
}
export async function startServer() {
  const server = createServer((request, response) => {
    void (async () => {
      const pathname = new URL(request.url ?? "/", "http://127.0.0.1").pathname;
      if (/^\/artifact\/(v1|v2|failed|incompatible)$/.test(pathname)) {
        const name = pathname.slice("/artifact/".length);
        const code = await readFile(resolve(directory, `generated/worker-${name}.js`), "utf8");
        response.setHeader("Content-Type", "application/json");
        response.end(JSON.stringify({ code, sha256: createHash("sha256").update(code).digest("hex") }));
      } else if (pathname === "/" || pathname === "/generated/app.js") {
        response.setHeader("Content-Type", pathname === "/" ? "text/html" : "text/javascript");
        response.end(await readFile(resolve(directory, pathname === "/" ? "index.html" : "generated/app.js")));
      } else { response.statusCode = 404; response.end("not found"); }
    })().catch(() => { response.statusCode = 404; response.end("not found"); });
  });
  await new Promise<void>((resolveListening, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", resolveListening); });
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("missing loopback address");
  return { url: `http://127.0.0.1:${address.port}`, close: () => new Promise<void>((resolveClosed, reject) => {
    server.close(error => error ? reject(error) : resolveClosed()); server.closeAllConnections();
  }) };
}
