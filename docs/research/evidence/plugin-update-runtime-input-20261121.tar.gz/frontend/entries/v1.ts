startWorker("v1", input => input + 10);
