throw new Error("candidate-init-failure");
