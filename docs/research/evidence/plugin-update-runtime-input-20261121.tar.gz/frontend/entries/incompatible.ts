startWorker("incompatible", input => input * 9, 2);
