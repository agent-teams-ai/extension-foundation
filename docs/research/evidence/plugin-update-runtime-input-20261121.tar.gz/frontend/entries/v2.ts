startWorker("v2", input => input * 2 + 5);
