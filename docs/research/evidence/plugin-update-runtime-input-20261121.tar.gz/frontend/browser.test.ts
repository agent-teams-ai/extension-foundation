import assert from "node:assert/strict";
import test from "node:test";
import { mkdir, writeFile, rm, readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { chromium, type Browser } from "playwright";
import { compileWorker, startServer, directory } from "./fixture-server.ts";
import type {} from "./app.ts";

test("real browser builds and replaces workers through explicit update modes", { timeout: 60000 }, async () => {
  await mkdir(resolve(directory, "evidence"), { recursive: true });
  await rm(resolve(directory, "generated/worker-v2.js"), { force: true });
  for (const name of ["v1", "failed", "incompatible"] as const) await compileWorker(name);
  const server = await startServer();
  const observations: { name: string; observed: unknown; expected: unknown }[] = [];
  function check(name: string, observed: unknown, expected: unknown): void {
    observations.push({ name, observed, expected }); assert.deepEqual(observed, expected, name);
  }
  let browser: Browser | undefined;
  try {
    browser = await chromium.launch({ headless: true, ...(process.env.SPIKE_CHROMIUM_PATH ? { executablePath: process.env.SPIKE_CHROMIUM_PATH } : {}) });
    const page = await browser.newPage({ viewport: { width: 1150, height: 1100 } });
    const pageErrors: string[] = [];
    page.on("pageerror", error => pageErrors.push(error.message));
    await page.goto(server.url);
    await page.waitForFunction(() => window.spike?.snapshot().selected === "v1");
    await page.locator("#draft").fill("Keep draft #21 while the running calculation worker changes.");
    const initial = await page.evaluate(() => window.spike.snapshot());
    await page.locator("#run").click();
    await page.waitForFunction(() => document.querySelector("#result")?.textContent === "17");
    check("visible initial v1 result", await page.locator("#result").textContent(), "17");
    check("v2 absent while v1 runs", (await page.request.get(`${server.url}/artifact/v2`)).status(), 404);
    await compileWorker("v2");
    await page.evaluate(() => window.spike.prepare("v2"));
    const held = await page.evaluate(() => [window.spike.request(7, "hold"), window.spike.request(9, "hold")]);
    assert.equal(held.length, 2);
    await page.waitForFunction(ids => ids.every(id => window.spike.snapshot().events.includes(`held:${id}`)), held);
    await page.evaluate(() => { void window.spike.drain(); });
    check("closed admission before drain completion", (await page.evaluate(() => window.spike.snapshot())).admission, false);
    const rejected = await page.evaluate(() => { const id = window.spike.request(99); return window.spike.completion(id); });
    check("new arrival rejected during drain", rejected, { status: "rejected" });
    check("old selected while held", (await page.evaluate(() => window.spike.snapshot())).selected, "v1");
    const first = held[0]; const second = held[1];
    assert.notEqual(first, undefined); assert.notEqual(second, undefined);
    if (first === undefined || second === undefined) throw new Error("missing held request");
    await page.evaluate(id => window.spike.control(id, "release"), first);
    check("first old call result", await page.evaluate(id => window.spike.completion(id), first), { status: "ok", value: 17 });
    check("one pending keeps old selected", (await page.evaluate(() => window.spike.snapshot())).selected, "v1");
    await page.evaluate(id => window.spike.control(id, "release"), second);
    check("second old call result", await page.evaluate(id => window.spike.completion(id), second), { status: "ok", value: 19 });
    await page.waitForFunction(() => window.spike.snapshot().selected === "v2");
    await page.locator("#input").fill("11"); await page.locator("#run").click();
    await page.waitForFunction(() => document.querySelector("#result")?.textContent === "27");
    check("new v2 uses changed input", await page.locator("#result").textContent(), "27");
    const stable = await page.evaluate(() => window.spike.snapshot());
    for (const name of ["failed", "incompatible"]) {
      const error = await page.evaluate(async name => { try { await window.spike.prepare(name); return "unexpected success"; } catch (error) { return String(error); } }, name);
      check(`${name} readiness failure observed`, (name === "failed" ? /candidate-init-failure/ : /incompatible candidate/).test(error), true);
      const now = await page.evaluate(() => window.spike.snapshot());
      check(`${name} preserves selection revision admission and state`, [now.selected, now.incarnation, now.revision, now.admission, now.committed], [stable.selected, stable.incarnation, stable.revision, stable.admission, stable.committed]);
    }
    const cancelled = await page.evaluate(() => window.spike.request(23, "hold"));
    await page.waitForFunction(id => window.spike.snapshot().events.includes(`held:${id}`), cancelled);
    await page.evaluate(id => window.spike.control(id, "cancel"), cancelled);
    check("cooperative task actually settled", await page.evaluate(id => window.spike.completion(id), cancelled), { status: "cancelled" });
    check("cooperative cancellation leaves zero pending", (await page.evaluate(() => window.spike.snapshot())).pending, 0);
    await page.evaluate(() => window.spike.prepare("v1"));
    const inboxId = await page.evaluate(() => window.spike.request(31, "normal", true));
    await page.waitForFunction(id => window.spike.snapshot().events.includes(`inbox:${id}`), inboxId);
    const beforeDenied = await page.evaluate(() => window.spike.snapshot());
    check("force without grant denied", await page.evaluate(() => window.spike.force(false)), "denied");
    check("denial made no state mutation", await page.evaluate(() => window.spike.snapshot()), beforeDenied);
    check("current v2 still executes after denial", await page.evaluate(() => { const id = window.spike.request(12); return window.spike.completion(id); }), { status: "ok", value: 29 });
    const busy = await page.evaluate(() => window.spike.request(45, "busy"));
    await page.waitForFunction(id => window.spike.snapshot().events.includes(`entered:${id}`), busy);
    check("explicit force selects ready replacement", await page.evaluate(() => window.spike.force(true)), "selected");
    check("busy owner promise interrupted", await page.evaluate(id => window.spike.completion(id), busy), { status: "interrupted" });
    check("inbox owner promise interrupted", await page.evaluate(id => window.spike.completion(id), inboxId), { status: "interrupted" });
    const beforeFlush = await page.evaluate(() => window.spike.snapshot());
    await page.evaluate(() => window.spike.flushInbox());
    const afterFlush = await page.evaluate(() => window.spike.snapshot());
    check("real old inbox response rejected", afterFlush.rejectedCommits, 1);
    check("stale inbox does not commit state", afterFlush.committed, beforeFlush.committed);
    check("one explicit force API action", afterFlush.forceCalls, 1);
    check("hard action has named no-exit-receipt outcome", afterFlush.events.includes("terminate-invoked:no-exit-receipt"), true);
    await page.locator("#input").fill("40"); await page.locator("#run").click();
    await page.waitForFunction(() => document.querySelector("#result")?.textContent === "50");
    check("post-force current algorithm responds", await page.locator("#result").textContent(), "50");
    const final = await page.evaluate(() => window.spike.snapshot());
    check("same document through all modes", final.documentToken, initial.documentToken);
    check("application-owned draft preserved", final.draft, initial.draft);
    check("all owned operations settled", final.pending, 0);
    check("no post-ready worker or protocol faults", final.faults, []);
    check("no uncaught page errors", pageErrors, []);
    await page.screenshot({ path: resolve(directory, "evidence/final-browser.png"), fullPage: true });
    const compiler: unknown = JSON.parse(await readFile(resolve(directory, "node_modules/typescript/package.json"), "utf8"));
    await writeFile(resolve(directory, "evidence/result.json"), JSON.stringify({ node: process.version, browser: browser.version(), compiler, observations,
      final, scope: "One trusted dedicated-worker consumer. Terminate invoked; no portable physical exit/finalizer/external rollback receipt." }, null, 2));
  } finally {
    await browser?.close(); await server.close();
    await writeFile(resolve(directory, "evidence/observations.json"), JSON.stringify(observations, null, 2));
  }
});
