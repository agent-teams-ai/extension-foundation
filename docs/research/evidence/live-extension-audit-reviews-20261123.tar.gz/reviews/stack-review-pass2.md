# Stack review — adversarial pass 2

Reviewer: /root/mf_runtime. Read-only pass completed 2026-11-23 UTC.

## Verdict

**PASS with one source-precision correction recommended before publication.** The consolidation fairly credits strong ready stacks, preserves the version/cohort limits, and does not adopt an adapter or one of the seven owner policies. It does not claim a proven comparative win or complete-stack E2E.

SP2-01 concerns the exact lifecycle receipt represented by a verb. SP2-02 is a smaller table-level clarification; the following prose already supplies its required limitation. Neither finding requires another experiment, package installation or broader survey.

## Inputs actually read

Repository HEAD at reading: **e182dc1a3f30f3e86511276a9b327ac476320972**. These hashes describe the read versions, including working-tree content; a later root correction is a new revision.

| File | Bytes | SHA256 |
| --- | --- | --- |
| docs/research/live-update-ready-stack-comparison-2026-11-23.md | 18139 | 207317d0812d42ca993ad083648b26188f47938e51e44ff81d72beca9a0972d4 |
| docs/architecture/live-extension-system-map.md | 22070 | dcfb64c125ca83b51c06083295de1c23bcb84c8c48c12404a445762f7d731b86 |

Primary-source comparisons use the already preserved 40-entry stack ledger and pinned implementations from the current research pass. No package code was executed for this review.

## SP2-01 — state the emitted lifecycle event, not completed predecessor unloading

**Severity:** medium precision issue in the comparison, “Pinned completion boundaries: Piral.”

The phrase “unloads the predecessor before setup finishes” can be read as completed predecessor retirement. The pinned app actions prove a narrower ordering: addPilet calls injectPilet before runPilet; injectPilet updates the same-name module/contribution registrations and emits unload-pilet. The registered cleanup path calls teardown, but does not await arbitrary asynchronous teardown completion.

The next paragraph correctly warns about this completion boundary. The earlier wording should not require readers to reverse a stronger interpretation.

**Suggested replacement:**

> removes the same-name managed registrations and emits unload-pilet before starting the new setup.

This is a source-level wording correction, not a claim of a Piral defect or an inability to build stronger integration.

Sources:

- [Pinned Piral actions](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-core/src/actions/app.ts).
- [Pinned Piral cleanup](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-base/src/lifecycle/cleanup.ts).

## SP2-02 — keep predecessor-preservation conditional in the scenario table

**Severity:** low; the surrounding text is already correct.

The bad-candidate row requires that the promised old action still work. In the intended compatible-overlap profile this is a useful oracle. As a standalone row, however, it can be mistaken for a requirement that every exclusive-resource handover must preserve the old action unchanged.

The later paragraph explicitly distinguishes overlap from defer/handover/restart and leaves the owner choice open. Copy that qualification into the row.

**Suggested wording:**

> Where the selected profile promises predecessor preservation, the old action still works; otherwise the declared defer/handover/restart recovery outcome and actual state/resource result are observed.

No additional owner decision is needed for this clarification; it preserves the existing OPEN status.

## Adversarial checks that passed

1. **Strong baseline selection.** Piral includes Cloud and a ready loader; single-spa includes framework helpers, MF and Zephyr; every baseline may use existing state/resource mechanisms. The text does not compare a bare primitive with an imagined complete future product.
2. **Composite honesty.** The single-spa/framework/MF/Zephyr combination is explicitly a proposed composition of available pieces, not an already qualified vendor bundle.
3. **Direct intersection without format confusion.** Pilet authoring/shell semantics, MF shared loading, NF import-map/build/runtime responsibilities, OC UI rendering, Cloud discovery and Zephyr release flows remain distinct. The existing Piral MF loader demonstrates coexistence.
4. **Piral positive counterevidence.** Shell state, owned registration cleanup and existing lifecycle are credited. Their limitations are specific completion boundaries, not claims of total absence.
5. **Native Federation provenance.** Source commit package.json 4.10.0 and npm core/orchestrator 4.10.1/4.10.2 remain separate. No missing gitHead is invented, and no source finding is silently called a tested tarball property.
6. **Native Federation constraints.** The known-remote/dynamic-init and async map-setter limits are scoped to inspected sources. TS >=5 <7 is correctly a build-core conflict with local policy, not a family-wide runtime veto. Staged cache rollback is credited.
7. **OpenComponents provenance.** Browser 2.1.13 source behavior is separated from Node client 4.0.4, which pins browser 1.5.4. The document does not generalize one custom-element/ESM path to every server/template combination.
8. **Zephyr scope.** Electron OTA remains explicitly Beta and renderer-scoped; actual adoption and release routing remain distinct. Ready client update UX is credited.
9. **No unsupported competitive victory.** The complete comparison is unexecuted on both sides. Consumer glue, newly written adapter code, business logic and fixture code are distinguished. The hypotheses can be falsified by a small successful ready-stack integration.
10. **No adoption by documentation.** The system map distinguishes accepted constraints, owner-confirmed direction, proposals and executed evidence. Optional candidate seams are not advertised as implemented packages.
11. **Complete operation ownership.** The standalone library retains the operation implementation; products supply authority/state primitives and policy, while execution/resource owners retain physical custody. The map does not retreat to consumer-assembled orchestration.
12. **Evidence bounds.** MF 4/4 and SystemJS 2/2 remain prior bounded mechanism results. Source studies, current runtime documentation and a good architecture map do not become a complete production-library claim.

## Review limit and next action

No substantial source-cohort, adoption, comparison-fairness or architecture-ownership blocker was found within this lane. Apply SP2-01, preferably SP2-02, and preserve this report against its recorded input hashes. The root-owned documentation gate and other ownership reviews remain separate; this pass does not approve implementation or select the first real consumer.

Machine-readable inputs and findings are in stack-review-pass2-inputs.json.
