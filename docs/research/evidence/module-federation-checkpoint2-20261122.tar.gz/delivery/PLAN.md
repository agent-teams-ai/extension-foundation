# Web delivery and live module replacement — investigation plan

Observed: 2026-11-22. Research only; no production choice or public API is adopted.
Root owns repository documentation, commits and publication. This lane owns only
the `delivery` scratch directory.

## Questions that can change the architecture

1. Which browser/module-loader operations change future resolution, and which
   preserve existing namespaces, consumers, custom-element definitions or styles?
2. Can one published deployment selector guarantee a coherent graph to an old
   tab that loads a delayed chunk after a rollout? What remains a storage/asset
   retention obligation?
3. What does Service Worker installation, activation, control and `skipWaiting`
   actually guarantee across existing clients?
4. What ready mechanisms provide import-map publication, lifecycle intent,
   caching and update notifications without supplying application authorization,
   state migration or physical reclamation?
5. Which invariant follows from current accepted ownership, and which rollout,
   sharing, isolation, retention or reset policy needs the owner's decision?

## Evidence method

- Use normative HTML/Service Worker specifications, official implementation
  documentation and exact released SystemJS/single-spa source.
- Record retrieval date, exact version/commit where available, source class,
  counterevidence and limits. A reported incident is not a reproduced defect.
- Carry forward the previous single-spa timeout/unload findings, not count them
  as new execution. No previous native E2E is rerun in this lane.
- Review existing import-map-deployer and Workbox mechanisms before suggesting
  a custom deployment selector, service worker or notification subsystem.
- Proposed architecture stays in the decision matrix. No package installation,
  public interface or runtime choice is implied by a source finding.

## Candidate bounded native spike — superseded, NOT executed

One real-browser fixture could distinguish module resolution from current live
objects using the browser's native import maps and dynamic imports. Candidate
cases: merge a nonconflicting late import map; try to remap an already-resolved
specifier; retain an existing export while importing an explicitly new immutable
URL; change only an entry query while a relative dependency retains its URL.
An independent assertion must observe actual values/identities and requests.

This would exercise native browser semantics, not implement a substitute
loader. Maintained source and harness would be `.ts`, strictly checked with
TypeScript >=7.0.2. Any emitted browser JavaScript would be generated. Exact
browser/compiler/runner/lock/source identities and original failures would be
retained. The fixture must not be called Module Federation E2E.

The default recommendation for this lane is source inspection first. Run the
fixture only if an unresolved architecture claim needs empirical discrimination
after review; sibling Federation work may cover the same boundary more directly.
No native run is authorized by this plan alone. Root review prefers the released
SystemJS probe below. Native import-map cases are dropped because the normative
rules answer the question without another browser fixture.

## Plan v2: released SystemJS probe — requires root review before execution

SystemJS 6.15.1 at commit `17c238ec00cf7c4bcabcf3579f876513fcedba30`
returns a callback from successful registry deletion. After reimport, it reconnects
importer setters. Official API prose says Boolean, but DefinitelyTyped documents
`false | UpdateModuleFn`. Upstream PR #2020 intentionally introduced this in 2019.
This changes the reuse assessment enough to justify a narrow native qualification.

Use the actual published SystemJS Node loader; this is neither browser evidence
nor Module Federation/library E2E. Maintained harness, build script and fixtures
are strict `.ts`. TypeScript 7.0.2 emits ESM; Rollup 4.68.8 converts it to generated
System.register output with preserved modules. TS7 removed legacy System output,
so do not use an old compiler or a TypeScript bundler plugin.

Use public import/delete/has APIs, real generated modules and the published
declarations. No instantiate hook, manual registry, ambient module shim or
diagnostic suppression. Validate imported unknown values before use.

Replace the temporary module file A with generated B at the same URL, then
reimport after delete. This is a mechanism fixture, not a production mutable-asset
recommendation. A separate real gate module provides a started promise and release
function for top-level await; no sleep-based success condition.

| Case | Independent observations | Limit |
| --- | --- | --- |
| SYS-01 completed delete/reimport/relink | Delete returns function; new namespace reads B; importer reads A before callback, B after; old namespace and captured function remain A | Not resource cleanup, graph HMR, browser behavior or state preservation |
| SYS-02 callback guard (may fold into SYS-01) | Invocation before replacement returns false; after replacement it rebinds; repeated call reports false | Not safe application rollback |
| SYS-03 pending evaluation | Delete returns false during signalled top-level await; release completes original import; deletion can succeed afterwards | Not cancellation or deadline enforcement |

Published source and historical #2286/#2291 are inspected without counting the
old issue as a newly reproduced defect. Sibling real MF profile keeps separate
counts. No production loader choice is adopted.

### Dependency/compiler preflight

| Package | Exact pin | Audit so far |
| --- | --- | --- |
| systemjs | 6.15.1 | Registry metadata: no runtime dependencies or TypeScript dependency; inspect published bundle, do not rebuild upstream |
| @types/systemjs | 6.15.4 | Published archive verified, dependencies empty; callback return type present |
| typescript | 7.0.2 | Only compiler; exact 7.0.2 platform packages, CLI only |
| rollup | 4.68.8 | GitHub release verified 2026-11-21; exact frozen lock audited; native binary + @types/estree only, no TS plugin |
| @types/node | 24.13.3 | Declaration only; undici-types resolved exactly 7.18.2 |
| node / pnpm | 24.22.3 / 11.25.0 | Observed installed versions |

Registry SRI observations:

- systemjs: `sha512-Nk8c4lXvMB98MtbmjX7JwJRgJOL8fluecYCfCeYBznwmpOs8Bf15hLM6z4z71EDAhQVrQrI+wt1aLWSXZq+hXA==`
- @types/systemjs: `sha512-GUosUMKBP5ZH2xvB6bqSccmjcX0Jz0SMM9i+AjefCucIQQ8Hi0yWIGLLuyuvTF6kgFJkLXxldD31DSu4R5Eq0w==`
- typescript: `sha512-8FYau96o3NKOhbjKi/qNvG/W5jhzxkbdm5sj9AbZ/5T5sWqn3hJgLfGx27sRKZWTvyzCP8dLRBTf5tBTSRVUNA==`

Metadata/archive inspection does not execute compilers or tests. Before execution:
retain exact lock; inspect every executable dependency for embedded TypeScript;
strict check with skipLibCheck false; keep original failures; send any material
dependency/plan change to root. No new test has run at this checkpoint.

Preparation revision 2 completed these preflights: nine installed packages;
only TypeScript 7.0.2 compiler/platform; strict host checks and fixture compilation
passed, real Rollup output generated. Peer review improved started/import/abort
readiness observation before any runtime execution. Exact old/new manifests and
review history are in probe/. Maintained TypeScript: 216 measured LOC. Root must
freeze/push these inputs before the native command runs.

## Cost and confidence estimates

These are scoped engineering estimates, not measured reliability or guarantees.

| Work | Production/integration LOC | Tests/fixtures LOC | Complexity /10 | Achievable reliability within stated scope /10 | Confidence /10 |
| --- | --- | --- | --- | --- | --- |
| Source research and evidence ledger | 0 | 0 | 3 | N/A | 8 |
| Optional native import-map boundary fixture | 0 | 220–380 | 3 | 8 | 8 |
| Proposed replacement SystemJS probe | 0 | 200–340 plus generated output | 4 | 8 | 8 |
| Production delivery integration | Unestimated until host/selector/retention policy is selected | Unestimated | Open | Open | Open |

Costs are incremental to existing research, exclude release/CI maintenance, and
do not estimate the whole live-update library. Avoid inventing production code
merely to make the architecture appear complete.

## Deliverables

`REPORT.md`, `sources.json`, `findings.json`, `OPEN-QUESTIONS.md`, and a matrix of
required native qualification cases. Parent and sibling review should critique
actual mechanisms and failure semantics before any new execution.
