import { Compartment, EditorState, StateEffect, StateField, Transaction, type Extension } from '@codemirror/state';
import { EditorView, ViewPlugin, keymap, type ViewUpdate } from '@codemirror/view';
import { history, historyField, historyKeymap, invertedEffects, isolateHistory, redo, redoDepth, undo, undoDepth } from '@codemirror/commands';
import { forceLinting, forEachDiagnostic, linter, openLintPanel, setDiagnostics, type Diagnostic } from '@codemirror/lint';
import type { CompletionReceipt, EditorProbe, EditorSnapshot } from './probe.ts';

function element(selector: string): HTMLElement {
  const found = document.querySelector(selector);
  if (!(found instanceof HTMLElement)) throw new Error(`Missing fixture element ${selector}`);
  return found;
}

const contribution = new Compartment();
const historyScope = new Compartment();
const nativeLintScope = new Compartment();
const semanticChange = StateEffect.define<number>();
const semanticField = StateField.define<number>({
  create: () => 0,
  update: (value, transaction) => {
    for (const effect of transaction.effects) if (effect.is(semanticChange)) value = effect.value;
    return value;
  },
  toJSON: value => value,
  fromJSON: (value: unknown) => {
    if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('Invalid semantic field');
    return value;
  },
});
const nativeInverse = invertedEffects.of(transaction => transaction.effects.some(effect => effect.is(semanticChange))
  ? [semanticChange.of(transaction.startState.field(semanticField))] : []);

let selected = 'A';
let generation = 1;
let revision = 0;
let trace: string[] = [];
let nativeStarted: string[] = [];
let completions: CompletionReceipt[] = [];
let documentSequence = 0;
const documentIdentities = new WeakMap<object, number>();
function documentId(doc: object): number {
  const existing = documentIdentities.get(doc);
  if (existing !== undefined) return existing;
  const id = ++documentSequence;
  documentIdentities.set(doc, id);
  return id;
}

function contributionExtension(name: string): Extension {
  const plugin = ViewPlugin.fromClass(class {
    readonly onKey = (): void => { trace.push(`${name}:key`); };
    constructor(readonly owner: EditorView) {
      trace.push(`${name}:setup`);
      owner.contentDOM.addEventListener('keydown', this.onKey);
    }
    update(update: ViewUpdate): void {
      if (update.docChanged) trace.push(`${name}:document`);
    }
    destroy(): void {
      this.owner.contentDOM.removeEventListener('keydown', this.onKey);
      trace.push(`${name}:destroy`);
    }
  });
  return [semanticField, nativeInverse, plugin];
}

const historyExtension = (): Extension => history({ newGroupDelay: 0, joinToEvent: () => false });
function extensions(): Extension[] {
  return [
    contribution.of(contributionExtension(selected)),
    historyScope.of(historyExtension()), nativeLintScope.of([]), keymap.of(historyKeymap),
    EditorView.contentAttributes.of({ 'aria-label': 'Live draft', 'data-testid': 'draft' }),
    EditorView.updateListener.of(update => {
      revision += update.transactions.filter(transaction => transaction.docChanged).length;
      render();
    }),
  ];
}

const view = new EditorView({ state: EditorState.create({ doc: 'seed', extensions: extensions() }), parent: element('#editor') });
function snapshot(): EditorSnapshot {
  const diagnostics: string[] = [];
  forEachDiagnostic(view.state, diagnostic => diagnostics.push(diagnostic.message));
  return {
    text: view.state.doc.toString(), revision, documentId: documentId(view.state.doc), selected, generation,
    selection: { anchor: view.state.selection.main.anchor, head: view.state.selection.main.head },
    focused: view.hasFocus, semanticValue: view.state.field(semanticField),
    undoDepth: undoDepth(view.state), redoDepth: redoDepth(view.state), diagnostics,
    trace: [...trace], nativeStarted: [...nativeStarted], completions: [...completions],
  };
}
function render(): void {
  const state = snapshot();
  element('[data-testid="selected"]').textContent = `${selected} / g${generation}`;
  element('[data-testid="revision"]').textContent = String(revision);
  element('[data-testid="diagnostics"]').textContent = state.diagnostics.join(', ') || 'none';
  const last = completions.at(-1);
  element('[data-testid="completion"]').textContent = last ? `${last.label}: ${last.reason}` : 'none';
  element('[data-testid="trace"]').textContent = trace.join('\n');
}

function diagnostics(label: string, length: number): Diagnostic[] {
  return [{ from: 0, to: Math.min(1, length), severity: 'warning', source: label, message: label }];
}

interface NativePending { resolve(value: readonly Diagnostic[]): void; documentLength: number; done: Promise<void>; }
const pendingNative = new Map<string, NativePending>();
function startNative(label: string): void {
  if (nativeStarted.includes(label)) throw new Error(`Duplicate native source ${label}`);
  view.dispatch({ effects: nativeLintScope.reconfigure(linter(editor => {
    nativeStarted.push(label);
    trace.push(`native:${label}:started`);
    const { promise, resolve } = Promise.withResolvers<readonly Diagnostic[]>();
    const done = promise.then(() => { trace.push(`native:${label}:completed`); });
    if (pendingNative.has(label)) throw new Error(`Unexpected extra native invocation ${label}`);
    pendingNative.set(label, { resolve, documentLength: editor.state.doc.length, done });
    return promise;
  }, { delay: 60_000 })) });
  forceLinting(view);
  render();
}
async function completeNative(label: string): Promise<void> {
  const pending = pendingNative.get(label);
  if (!pending) throw new Error(`Native source not started: ${label}`);
  pending.resolve(diagnostics(label, pending.documentLength));
  await pending.done;
  // A task boundary lets the native promise sink and native editor DOM update finish.
  await new Promise<void>(resolve => requestAnimationFrame(() => resolve()));
  pendingNative.delete(label);
  render();
}

interface ManagedPending {
  resolve(value: readonly Diagnostic[]): void;
  documentLength: number;
  done: Promise<CompletionReceipt>;
}
const pendingManaged = new Map<string, ManagedPending>();
function startManaged(label: string): void {
  if (pendingManaged.has(label)) throw new Error(`Duplicate managed task ${label}`);
  const requestedGeneration = generation;
  const requestedRevision = revision;
  const requestedDoc = view.state.doc;
  const requestedText = requestedDoc.toString();
  const { promise, resolve } = Promise.withResolvers<readonly Diagnostic[]>();
  trace.push(`managed:${label}:started`);
  const done = promise.then(result => {
    const reason = generation !== requestedGeneration ? 'generation-changed'
      : revision !== requestedRevision ? 'document-revision-changed' : 'current';
    const receipt: CompletionReceipt = {
      label, accepted: reason === 'current', reason,
      requestedGeneration, currentGeneration: generation, requestedRevision, currentRevision: revision,
      sameText: requestedText === view.state.doc.toString(), sameDocumentObject: requestedDoc === view.state.doc,
    };
    // Freshness at application time; this is not an authorization or cancellation boundary.
    if (receipt.accepted) {
      view.dispatch(setDiagnostics(view.state, result));
    }
    completions.push(receipt);
    trace.push(`managed:${label}:${reason}`);
    render();
    return receipt;
  });
  pendingManaged.set(label, { resolve, documentLength: requestedDoc.length, done });
}

const probe: EditorProbe = {
  snapshot,
  reset(text) {
    if (pendingNative.size || pendingManaged.size) throw new Error('Reset with unresolved controlled tasks');
    trace = []; nativeStarted = []; completions = []; selected = 'A'; generation += 1; revision += 1;
    view.setState(EditorState.create({ doc: text, extensions: extensions() }));
    render();
  },
  select(anchor, head) { view.dispatch({ selection: { anchor, head } }); view.focus(); },
  replaceContribution(name) {
    selected = name; generation += 1;
    view.dispatch({ effects: contribution.reconfigure(contributionExtension(name)) });
    render();
  },
  setSemantic(value) { view.dispatch({ effects: semanticChange.of(value), annotations: Transaction.addToHistory.of(false) }); },
  startNative, completeNative,
  clearNative() { view.dispatch({ effects: nativeLintScope.reconfigure([]) }); },
  showDiagnostics() { openLintPanel(view); view.focus(); },
  startManaged,
  async completeManaged(label) {
    const pending = pendingManaged.get(label);
    if (!pending) throw new Error(`Managed task not started: ${label}`);
    pending.resolve(diagnostics(label, pending.documentLength));
    const receipt = await pending.done;
    pendingManaged.delete(label);
    return receipt;
  },
  undo: () => undo(view), redo: () => redo(view),
  clearHistory() {
    view.dispatch({ effects: historyScope.reconfigure([]) });
    view.dispatch({ effects: historyScope.reconfigure(historyExtension()) });
  },
  editWithSemantic(text, value) {
    view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: text }, effects: semanticChange.of(value),
      annotations: isolateHistory.of('full') });
  },
  roundTripHistory() {
    const json: string = JSON.stringify(view.state.toJSON({ history: historyField, semantic: semanticField }));
    const parsed: unknown = JSON.parse(json);
    revision += 1;
    view.setState(EditorState.fromJSON(parsed, { extensions: extensions() }, { history: historyField, semantic: semanticField }));
    render();
    return json;
  },
};
window.editorProbe = probe;
element('[data-testid="undo"]').addEventListener('click', () => { undo(view); });
element('[data-testid="redo"]').addEventListener('click', () => { redo(view); });
render();
