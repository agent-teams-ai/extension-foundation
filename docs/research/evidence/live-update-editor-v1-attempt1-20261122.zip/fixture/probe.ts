export interface EditorSnapshot {
  text: string;
  revision: number;
  documentId: number;
  selected: string;
  generation: number;
  selection: { anchor: number; head: number };
  focused: boolean;
  semanticValue: number;
  undoDepth: number;
  redoDepth: number;
  diagnostics: string[];
  trace: string[];
  nativeStarted: string[];
  completions: CompletionReceipt[];
}

export interface CompletionReceipt {
  label: string;
  accepted: boolean;
  reason: 'current' | 'generation-changed' | 'document-revision-changed';
  requestedGeneration: number;
  currentGeneration: number;
  requestedRevision: number;
  currentRevision: number;
  sameText: boolean;
  sameDocumentObject: boolean;
}

export interface EditorProbe {
  snapshot(): EditorSnapshot;
  reset(text: string): void;
  select(anchor: number, head: number): void;
  replaceContribution(name: string): void;
  setSemantic(value: number): void;
  startNative(label: string): void;
  completeNative(label: string): Promise<void>;
  clearNative(): void;
  showDiagnostics(): void;
  startManaged(label: string): void;
  completeManaged(label: string): Promise<CompletionReceipt>;
  undo(): boolean;
  redo(): boolean;
  clearHistory(): void;
  editWithSemantic(text: string, value: number): void;
  roundTripHistory(): string;
}

declare global {
  interface Window { editorProbe: EditorProbe; }
}
