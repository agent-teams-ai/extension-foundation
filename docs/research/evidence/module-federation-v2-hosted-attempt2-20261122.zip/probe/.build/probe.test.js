import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFile, writeFile } from "node:fs/promises";
import { resolve, sep } from "node:path";
import { after, before, test } from "node:test";
import { chromium } from "playwright";
const dist = resolve(process.cwd(), "dist");
const browserExecutable = process.env["MF_RESEARCH_CHROMIUM"];
const requests = [];
const receipts = [];
let browser;
let server;
let base;
before(async () => {
    server = createServer((request, response) => {
        void (async () => {
            const pathname = new URL(request.url ?? "/", "http://fixture").pathname;
            if (pathname === "/favicon.ico")
                return response.writeHead(204).end();
            if (pathname === "/") {
                response.writeHead(200, { "Content-Type": "text/html", "Cache-Control": "no-store" });
                response.end('<!doctype html><meta charset="utf-8"><title>Native MF probe</title><script src="/host.js"></script>');
                requests.push({ path: pathname, status: 200 });
                return;
            }
            const filename = resolve(dist, `.${decodeURIComponent(pathname)}`);
            if (!filename.startsWith(`${dist}${sep}`))
                return response.writeHead(403).end();
            try {
                const bytes = await readFile(filename);
                response.writeHead(200, { "Content-Type": "text/javascript", "Cache-Control": "no-store" });
                response.end(bytes);
                requests.push({ path: pathname, status: 200 });
            }
            catch {
                response.writeHead(404).end();
                requests.push({ path: pathname, status: 404 });
            }
        })().catch((error) => response.destroy(error instanceof Error ? error : new Error(String(error))));
    });
    await new Promise((done) => server.listen(0, "127.0.0.1", done));
    const address = server.address();
    assert(address && typeof address !== "string");
    base = `http://127.0.0.1:${address.port}`;
    browser = await chromium.launch({
        headless: true,
        args: ["--no-sandbox"],
        ...(browserExecutable ? { executablePath: browserExecutable } : {}),
    });
}, { timeout: 30_000 });
after(async () => {
    const browserVersion = browser?.version();
    await browser?.close();
    await new Promise((done) => server?.close(() => done()));
    await writeFile(resolve(process.cwd(), "results/native.json"), JSON.stringify({
        recordedAt: new Date().toISOString(),
        profile: "Chromium / webpack 5.113.0 built-in containers / MF runtime 2.9.3",
        node: process.version,
        browser: browserVersion,
        browserExecutable: browserExecutable ?? chromium.executablePath(),
        cases: receipts,
        requests,
        limits: ["Not library E2E", "Not Rspack/enhanced bundler HMR/SSR/Electron", "No GC, security or performance guarantee"],
    }, null, 2) + "\n");
});
async function observe(id) {
    const context = await browser.newContext();
    const page = await context.newPage();
    const consoleMessages = [];
    const pageErrors = [];
    page.on("console", (message) => consoleMessages.push(`${message.type()}: ${message.text()}`));
    page.on("pageerror", (error) => pageErrors.push(error.message));
    const requestStart = requests.length;
    try {
        await page.goto(base);
        const observation = await page.evaluate((caseId) => window.probeAPI.run(caseId), id);
        const caseRequests = requests.slice(requestStart);
        const requestCounts = {};
        for (const { path } of caseRequests)
            requestCounts[path] = (requestCounts[path] ?? 0) + 1;
        receipts.push({ id, observation, consoleMessages, pageErrors, requests: caseRequests, requestCounts });
        assert.deepEqual(pageErrors, [], "No unrelated browser exception may explain an oracle");
        assert(caseRequests.every(({ status }) => status === 200), "No missing fixture asset may masquerade as a runtime rejection");
        return observation;
    }
    catch (error) {
        receipts.push({ id, harnessFailure: error instanceof Error ? error.message : String(error), consoleMessages, pageErrors });
        throw error;
    }
    finally {
        await context.close();
    }
}
function text(value, key) {
    const field = value[key];
    assert.equal(typeof field, "string", `${key} is a native diagnostic string`);
    return String(field);
}
test("MF-N1: replacement, retained resource and public factory deferral", { timeout: 30_000 }, async () => {
    const r = await observe("N1");
    assert.equal(r["retainedA"], "A");
    assert.equal(r["newLookup"], "B");
    assert.equal(r["distinctExports"], true);
    assert.equal(r["publishedAfterLoad"], "A");
    assert.deepEqual(r["evaluations"], ["A:none", "B:A", "C:B"]);
    assert.equal(r["listenerBefore"], 1);
    assert.equal(r["listenerAfterReplacement"], 2);
    assert.equal(r["listenerAfterCleanup"], 2);
    assert.equal(r["deferredFactoryUnexecutedBeforeCall"], true);
    assert.equal(r["deferredInit"], true);
    assert.equal(r["deferredGet"], true);
    assert.equal(r["deferredAfterManualCall"], "C");
});
test("MF-N2: concrete forced alias-validation failure after removal", { timeout: 30_000 }, async () => {
    const r = await observe("N2");
    assert.match(text(r, "registrationError"), /alias occupied.*prefix of occupied\/sub/s);
    assert.match(text(r, "lookupError"), /RUNTIME-004/);
    assert.deepEqual(r["namesAfterFailure"], ["occupied/sub"]);
    assert.equal(r["retainedA"], "A");
    assert.equal(r["listenerAfterFailure"], 2);
    assert.equal(r["listenerAfterCleanup"], 2);
    assert.equal(r["explicitReregistration"], "A");
});
test("MF-N3: real shared token identity and strict incompatible consumer", { timeout: 30_000 }, async () => {
    const r = await observe("N3");
    assert.equal(r["providerSelectedBeforeConsumer"], true);
    assert.equal(r["compatibleTokenIsHost"], true);
    assert.equal(r["compatibleTokenId"], "host-contract-token");
    assert.deepEqual(r["providerVersions"], ["1.0.0"]);
    assert.match(text(r, "incompatibleError"), /Unsatisfied version 1\.0\.0.*shared singleton module service-token.*\^2\.0\.0/s);
    assert.equal(r["compatibleStillWorks"], true);
    assert.equal(r["incompatibleEntryPresent"], true);
});
test("MF-N4: fresh runtime object versus initialized container scope", { timeout: 30_000 }, async () => {
    const r = await observe("N4");
    assert.equal(r["instancesDiffer"], true);
    assert.equal(r["bothScopesExist"], true);
    assert.equal(r["scopesDiffer"], true);
    assert.equal(r["sameContainer"], true);
    assert.equal(r["firstStillWorks"], "A");
    assert.match(text(r, "secondError"), /already been initialized with a different share scope/);
    const control = await observe("control");
    assert.equal(control["firstResult"], "A");
    assert.equal(control["containerPresent"], true);
});
