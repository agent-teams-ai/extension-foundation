// This provides the compile-time package contract. Generated consumers use
// import:false, so this local module is not a runtime fallback.
export const token = { id: "local-fallback-must-not-load" };
