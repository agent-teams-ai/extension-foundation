export const version = __GENERATION__;
window.probeState.evaluations.push({
    generation: version,
    published: window.probeState.published,
});
const listener = () => {
    window.probeState.responses[version] =
        (window.probeState.responses[version] ?? 0) + 1;
};
export function read() {
    return version;
}
export function start() {
    window.addEventListener("fixture-tick", listener);
}
export function stop() {
    window.removeEventListener("fixture-tick", listener);
}
