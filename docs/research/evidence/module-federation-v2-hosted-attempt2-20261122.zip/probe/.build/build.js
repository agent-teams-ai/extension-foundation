import { createHash } from "node:crypto";
import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import webpack from "webpack";
const root = process.cwd();
const dist = resolve(root, "dist");
const variants = [
    { id: "a", generation: "A" },
    { id: "b", generation: "B" },
    { id: "c", generation: "C" },
    { id: "compatible", range: "^1.0.0" },
    { id: "strict", range: "^2.0.0" },
];
const common = {
    mode: "development",
    target: "web",
    devtool: false,
    optimization: { minimize: false, splitChunks: false, runtimeChunk: false },
};
function build(config) {
    return new Promise((resolveBuild, reject) => {
        const compiler = webpack(config);
        compiler.run((error, stats) => {
            compiler.close((closeError) => {
                if (error || closeError)
                    return reject(error ?? closeError);
                if (!stats || stats.hasErrors()) {
                    return reject(new Error(stats?.toString({ all: false, errors: true }) ?? "Missing webpack stats"));
                }
                resolveBuild();
            });
        });
    });
}
for (const variant of variants) {
    const isConsumer = "range" in variant;
    const exposes = isConsumer
        ? { "./token": resolve(root, ".build/fixture/consumer.js") }
        : { "./probe": resolve(root, ".build/fixture/remote.js") };
    await build({
        ...common,
        entry: {},
        output: {
            path: resolve(dist, variant.id),
            publicPath: "auto",
            uniqueName: `fixture_build_${variant.id}`,
            chunkFilename: "[name].[contenthash:8].js",
            clean: true,
        },
        plugins: [
            new webpack.DefinePlugin({ __GENERATION__: JSON.stringify("generation" in variant ? variant.generation : variant.id) }),
            new webpack.container.ModuleFederationPlugin({
                name: `fixture_${variant.id}`,
                filename: "remoteEntry.js",
                library: { type: "var", name: `fixture_${variant.id}` },
                exposes,
                shared: isConsumer ? {
                    "service-token": { import: false, singleton: true, strictVersion: true, requiredVersion: variant.range },
                } : {},
            }),
        ],
    });
}
await build({
    ...common,
    entry: resolve(root, ".build/fixture/host.js"),
    output: { path: dist, filename: "host.js", publicPath: "auto", uniqueName: "fixture_host" },
});
const files = [];
async function hashDirectory(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
        const path = resolve(directory, entry.name);
        if (entry.isDirectory())
            await hashDirectory(path);
        else {
            const bytes = await readFile(path);
            files.push({ path: path.slice(dist.length + 1), sha256: createHash("sha256").update(bytes).digest("hex"), bytes: bytes.length });
        }
    }
}
await hashDirectory(dist);
await mkdir(resolve(root, "results"), { recursive: true });
await writeFile(resolve(root, "results/build.json"), JSON.stringify({
    generatedAt: new Date().toISOString(),
    webpack: webpack.version,
    mode: common.mode,
    variants,
    sharedConsumerOptions: { import: false, singleton: true, strictVersion: true, fallback: "none" },
    files,
}, null, 2) + "\n");
console.log(`Generated ${variants.length} real webpack containers and host; ${files.length} output files.`);
