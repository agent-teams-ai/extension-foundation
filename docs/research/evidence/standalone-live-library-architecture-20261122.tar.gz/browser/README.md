# Disposable live-feedback browser qualification input

Status: source and strict TypeScript check ready; real-browser execution pending
hosted CI. Do not report a browser pass from this packet alone.

One node:test with three named phases: compatible native HMR, plugin remount,
and rejected candidate plus recovery. It adds actual Yjs draft/history and
focused textarea/range checks to the previously successful native React/Vite
fixture. Plugin subscription counts describe only the plugin, not the host's
useSyncExternalStore subscription. Behavioral checks also exercise real current
listeners and document observers.

## Toolchain

Node 24.22.3; pnpm 11.25.0; TypeScript 7.0.2; React/React DOM 19.3.1;
Vite 8.3.8; plugin-react 6.3.0; Playwright 1.65.1; Yjs 13.6.33.
All source variants, including the deliberately throwing valid module, are
checked with skipLibCheck false. Exact dependencies and transitive resolutions
are in probe/package.json and probe/pnpm-lock.yaml.

## Hosted execution

Extract the frozen archive after verifying its manifest. From its root run:

```sh
pnpm install --frozen-lockfile --ignore-scripts --engine-strict --strict-peer-dependencies
pnpm check
pnpm exec playwright install --with-deps chromium
pnpm test
```

Retain evidence even on failure. Native error/fallback behavior is part of the
qualification: do not quietly introduce a custom HMR accept handler or weaken
the usable-v3 expectation to turn a failed run green.

The plugin receives strings and subscribe/unsubscribe functions. A trusted
module could still import the hostActions module by path; this demonstrates API
separation, not a sandbox or universal revocation. The known rejecting candidate
reports its own failure, which must be corroborated by the native import error.
Vite's overlay is disabled so the host status and retained view can be inspected.
The failed attempt remains visible as diagnostic history after v4 recovery.

Local logs are retained separately from the frozen input. The source reuses
plugin-reload-browser-input-20261122-v2.tar.gz; only Yjs is added to its exact
direct toolchain. The frozen input excludes node_modules, local logs and results.
The first browser observation must come from the recorded hosted run.
