# Plugin decision preparation — 2026-11-06
## Owner request
Identify only substantial unresolved technical/product choices. Present concrete options for owner selection. EACH option requires estimated LOC (production/integration/tests separately), reliability, confidence, complexity 1–10. Explain scope and uncertainty. Audit what is accepted, merely research, proposed, and still open. Do not adopt or implement unresolved alternatives.

## Full owner vision and constraints
Hundreds/thousands of modules and user plugins; extensive customization without forking; convenient authoring and operation; reliable, scalable and understandable. Strict Clean Architecture, SOLID, DRY, actual domain-driven design, pluggable/modular. Avoid overengineering and invented infrastructure when existing qualified solutions work. Compare competitors/frameworks critically, use primary sources, preserve research/dates/versions/limits/counterevidence. Research and critic consensus are not owner approval.
User explicitly accepts static composition with controlled restart, optional Temporal adapter to same owned mechanism when infrastructure qualified. TS primary, consider Rust/native only demonstrated concrete benefit, preserve accepted native custody. No all-Rust rewrite. User asks GPT-6.1 Sol xhigh independent critics, including multiple perspectives on the same issue.
Accepted ADRs must not be silently rewritten. If genuinely material doubt remains, offer choices with LOC and ratings; do not ask trivial already-decided questions.
Earlier explicit authorization: commit/push research/docs to EF draft PR55; NO merge authorization in this task.

## Fresh remote state verified 2026-11-06
EF PR55 https://github.com/agent-teams-ai/extension-foundation/pull/55 open DRAFT; head33c50b92b005b6e3da56cc1905aad51ce68352e1 branch docs/plugin-research-hot-reload-20261021; EFmain29ae5b0269d9d83f071344e3e18761ded04ff53d.
GMmain5fb83478dd7b95216be92c4d3077eddf2774eef8.
Orchestrator main CHANGED since previous turn: a34587b313e656eeb43d755b4a4f08c40dff2116, mergedPR90 native Temporal ADR0116. Fetch/read current authority; do not treat engine as undecided. Commit says owner accepted full native Temporal/PostgreSQL FullyLocal onOct23; OD035 resolved, native3engine×3OS evidence, release qualification stillfalse, no automatic engine fallback.

## Authority known from prior audit — verify against current source
GM sole neutral identities/bindings/graph/immutableplan/typedconstruction; no second resolver/container/manager inEF.
EF owns neutral artifact/trust/distribution/protocol/conformance; no automatic operationalHost.
Product owns seams, payloads, grants/profiles/loader/readiness/canonicaldomainstate.
Existing execution owner owns process/worker/resource custody and retirement evidence.
Ordinary extensions cannot replace authorization/invariants/fencing/canonicalstate/enforcement.
EF acceptedADR0011 productionHostfloor admittedprofiles only, excludesordinarylibs/staticPureDI/GMconstruction.
EFADR0014 product-localmoduleauthoring guardrails ≠ runtime orpublicSPIapproval.
EFADR0015 neutralGMextraction, neutralcores do notimporteachother, productadaptercanuseboth.
EFOD003 module-runtime/publicSPI choices remainsopen; readfull.
OrchADR0114 nativePostgreSQL allprofiles; ADR0115 FullyLocalV1 embedded-postgresadapter, exactbundle/platform qualificationstillrequired.
OrchADR0117 Core/Assembly0.5adoption.
OrchOD041 productionEFadoption includingtwoindependentproductintegrations; don'tconflate evidencefixture with them.

## Evidence bounds
Prior packedconsumerE2E (inputs11fa2e2450a8aba62823544fc3129318918e9696, workflow42099097668):4OS/nodeprofiles,10scenarios+parent, realpublic HostDiscoverySource port from unchanged @agent-teams/local-host-control0.0.0; independentlypackedfixtureadapter/helper, externalconsumer, GM0.5. 433newfixtureTSLOC, ZEROproduction/integration. Tests selection/ambiguity/expiry/failure/immutablecapturedcomposition. NOT productionHost/UI/securitycontainment/restart/drain/thousandactiveplugins.
Previous research follow-up14frameworkcases,152sourceIDs+3movingdocs,6researchcritiques/4critics. Read-onlysource/upstreamtestinspection, noframeworkexecuted; noadoption. HostedDocsProtocol8/8 exacthead33/tree6c success; priorlocalfullgate timeout+indeterminateretainedhonestly.
No need rerununchangedsuite or manufacture new experiments for this question. Need realistic scope/bounds, not global estimate of an unspecified platform.

## Local read-only source/evidence
EF preferred checkout /workspace/scratch/f863b9d38368/plugin-modularity-research-2026-11-05/publication (HEAD33).
Original clones /workspace/scratch/f863b9d38368/plugin-industry-2026-11-05/repos/{get-modular,agent-teams-orchestrator}; may be stale.
Do NOT edit original EF clone (failed DocsProtocol transaction) or publication tool-owned temporary artifacts.
Reports /workspace/scratch/f863b9d38368/plugin-modularity-research-2026-11-05/reports
Priorfullcontext /workspace/scratch/f863b9d38368/plugin-modularity-research-2026-11-05/brief.md
Standard snapshot /workspace/scratch/f863b9d38368/plugin-modularity-research-2026-11-05/quality-standard.md (refresh ifeditinggovernedfiles).
KeyEFdocs: docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md; research/plugin-research-synthesis-and-authority-2026-11-05.md; research/plugin-system-research-reference.md; reusable-generation-mechanisms-and-ownership.md; critical-components-and-language-boundaries.md; temporal-and-rollout-orchestration.md; customization-without-forks-and-scale.md; static-composition-and-controlled-restart-validation.md; packed-extension-consumer-e2e-2026-11-05.md.
Currentfacts use GitHubconnector fetch/fetch_file. No assumption of GHCLI (absent).
ReadAGENTS/standardbeforegovernedchanges. Your roleREADONLYsources +writeownreportinscratchonly. Do notcommit/push or modifygovernedfiles.

## Reporting requirements
Give no more than 3–5 owner forks; distinguish immediateblocker vs deferredqualification. Two/three genuinelydifferentoptions per fork. Score complexity(10hard), reliability(10strongerWITHINnamedguarantee), confidence(10confidenceinrecommendation), estimates ranges not falseprecision. GroundreuseandLOC in actualfiles/components; calloutunbounded dependencies, no universalnumericreliability. Include exact citations, what not guaranteed, what evidencecouldchange recommendation.
Don't reopen already accepted authority. Some seemingly open OD topics may now be accepted elsewhere: reconcile before suggestingchoices.

