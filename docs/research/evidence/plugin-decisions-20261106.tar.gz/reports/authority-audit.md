# Independent authority audit — plugin decisions, 2026-11-06

## Conclusion

**The sources do not justify three to five unconditional architecture votes now.** They justify one immediate product-scope decision: choose the first real customization capability and its supported author/audience, trust, deployment, availability and lifetime promise. The repository itself says this is the next actual owner choice. After that decision, at most three substantial dependent forks become concrete: runtime placement, publication scope, and catalog/offline operating profile. Selecting an implementation library or another shared coordinator before that trigger would manufacture a fork.

This is an authority and claim audit, not owner approval. I read the complete shared brief, read the requested EF ADRs/OD, the accepted GM lifecycle successors and resolved ODs, and fetched the current Orchestrator tree and authority files at **a34587b313e656eeb43d755b4a4f08c40dff2116** through the GitHub connector. EF was read at **33c50b92b005b6e3da56cc1905aad51ce68352e1**; GM at **5fb83478dd7b95216be92c4d3077eddf2774eef8**. No governed repository file was changed, no framework experiment was run, and nothing was pushed.

The important distinctions are:

- **Accepted architecture:** GM owns composition; existing execution/product owners retain operational authority; static composition with controlled restart is confirmed; native PostgreSQL and native Temporal for Orchestrator Fully Local V1 are accepted.
- **Accepted mechanism with separate use qualification:** GM Resources and Observation have actual accepted contracts; consumer artifact qualification is still exact and local.
- **Candidate only:** the lifecycle-kernel identity and narrow synchronous admission/retention contract are accepted as a candidate, not generally released or production-adopted.
- **Research only:** a bounded Worker replacement cohort, specific pool/RPC adapters, generalized hot replacement, selective new Rust coordination, and broad Host/SPI proposals.
- **Open but trigger-dependent:** production host placements, private invocation protocol, public extension SPI and state migration.
- **Open production parameters:** catalog signing/custody/freshness/offline policies, whose topology is already accepted.

Sources: [EF OD-003, especially lines 17–65 and 103–153][EOD3]; [EF ADR-0011 applicability, lines 60–95][E11]; [Orchestrator ADR-0116, lines 35–40 and 65–165][O116]; [Orchestrator ADR-0117, lines 45–123][O117].

## 0. Follow-up: concrete AR seam and the minimal owner shortlist

The parent supplied a narrower proposed shortlist while this audit was running. I fetched and inspected current **Agent Runtime f990acc26e1b8071ae22d0b87a2ddd3672be8e2e**, including accepted ADR-0009/0012/0090, proposed ADR-0016, the actual provider-selection/composition sources, provider ports and qualification registry. This resolves some of Card A's uncertainty. **For the actual owner presentation I support only the following two decisions, with the second contingent on shipping the first.** Cards B–D below are deferred issue categories, not additional immediate votes.

### Actual decision 1: which first useful no-fork slice is worth productizing?

- **Existing trusted Codex provider adapter at the existing AR-owned port, independently packaged only within its exact approved envelope.** This is a real user-facing execution capability, unlike discovery-only infrastructure, and reuses an actual port/adapter rather than inventing a universal plugin interface. Packaging and controlled restart do not waive Provider Access, Runtime Security, process custody, current authority or qualification.
- **A genuinely new owner-named provider.** This may deliver greater user value but requires provider-specific contract/custody/route work and its own qualification. Claude is a particularly concrete counterexample to calling this “just admission”: current product composition explicitly refuses it with `claude-broker-seam-absent` before consulting any registry.
- **HostDiscovery infrastructure as the first narrower delivery.** This reuses the measured external package experiment, but must be described as infrastructure customization, not proof that end users can install useful independently authored execution plugins.

Recommendation: the existing Codex adapter is the strongest bounded candidate if the owner wants useful execution customization now. Its exact first delivery must be scoped as **qualifying/productizing independent packaging at an existing owned port**, not proclaiming an already qualified production plugin. The current Linux row is only `qualification: implementation`. It explicitly says **no real kernel route, provider turn, Docker container, operation network, credential rendering or provider-origin contact was executed**, and the IDs/resolver/evidence-broker session ports still lack production owners. Authentic route capability plus the exact registry tuple is necessary and not sufficient. An unchanged adapter body does not make this missing delivery work disappear. [ARREG]; [ARCOMP]

The low-level `ContainedTurnKernelProviderPort.execute` is a concrete consumer-owned execution port, with adapter snapshot, manifest, effect/operation/attempt/custody identities, Provider Access snapshot, delegated start and output callback. It is **not automatically a suitable external public SPI**: it carries private domain/proof-bearing contracts that the owning product would have to curate before a publication promise. ADR-0012 fixes the exact seven-member closed dependency record and preconstruction provider selection; extension packaging cannot smuggle Provider Access or execution custody into a provider god-port. [ARPORT]; [AR12]

Do not use `OrdinaryProviderPort` as a ready generic provider SPI either. Its source hard-codes the ordinary macOS Codex manifest revision; accepted ADR-0090 bounds the exact cooperative macOS arm64 profile. The ordinary profile is not hostile same-user containment and is not a default downgrade from Host Custody. [ARORDPORT]; [AR90]

### Actual decision 2: when should an update interrupt accepted work?

The genuinely open UX policy can be:

- **Wait before shutdown:** seal update admission at the existing owner, allow a bounded completion interval, and defer the update if work remains unresolved.
- **Request authorized cancellation after grace:** after a declared grace interval, request existing operation-owner cancellation and proceed only through the existing custody/receipt protocol; unresolved closure remains an observable pending/deferred update.

This fork is legitimate **only as pre-shutdown update scheduling**. Accepted AR ADR-0009 already fixes actual Host disposal: close new admission, request durable cutoff for *every* in-scope nonterminal operation, execute configured containment, drain observations and release resources only when custody/receipt protocols permit. Once disposal starts, a “wait-only shutdown” would contradict that contract. A pre-disposal waiting phase can preserve accepted work without redefining disposal. [AR9, “Host disposal and shutdown”][AR9]

The owner's tradeoff is work preservation versus update timeliness; neither option can promise a bounded successful update when closure is uncertain. Both use the same operation owner, authorization and durable cancellation meaning. Caller abort, timeout or an updater decision alone is not a cancellation receipt. Both preserve original operation identities, reject automatic replay/new provider attempts, and cannot report cleanup because a wait deadline expired. [AR9]; [AR90]

**Sizing critique:** these two policies share nearly all restart plumbing; estimate the incremental scheduling/status/cancellation integration, not two replacement runtimes. No exact completion budget, existing update orchestration API or complete release dependency inventory was established by this audit, so any final numeric LOC/confidence table must state those assumptions explicitly. Do not attach the 3,000–5,500 LOC optional Worker cohort to this controlled-restart choice. The final product/estimate workstream should expose whether admission sealing is at an existing application port or requires a new narrowly owned update orchestration seam; that concrete dependency can materially alter the range.

### Reviewed planning ranges for the final two-decision packet

After reading the product/mechanism agents' scratch reports, I consider the following ranges permissible **only with their stated exclusions**. These are roughly factor-two engineering hypotheses, not measured delivery totals. Production/integration/tests are disjoint in these rows; alternatives are not additive.

| First useful slice | Production LOC | Integration LOC | Test LOC | Scoped reliability | Estimate confidence | Complexity |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Existing AR provider family: curated trusted static adapter seam and one behavior-bearing independent variation | 900–1,800 | 450–900 | 1,400–2,800 | 8 for preserved trusted substitution/operation semantics after qualification | 6 | 5 |
| Owner-named new provider, only if bounded protocol and existing route/custody infrastructure fit | 2,000–5,000 | 900–1,800 | 3,000–6,000 | 7 for the named supported turn profile | 5 until named | 7 |
| Real protected discovery adapter and caller/handshake slice, one admitted substrate | 700–1,500 | 500–1,100 | 1,200–2,500 | 8 for supported discovery/validation/handshake | 6 | 5 |

The existing-provider row prices a narrow contract/translation, package boundary, explicit startup selection/refusal, one actual consumer and independent behavior. It excludes fresh sandbox/route/native custody, missing production deployment owners, new vendor behavior, OCI lifecycle, installer, broad matrix and qualification campaign execution. The current implementation-only Linux registry makes that exclusion essential. A complete independently packaged *production-qualified* delivery remains unbounded until the missing production input owners and campaign are scoped. The new-provider row includes the seam work; do not add the existing-provider row. If the named vendor is Claude, absent broker work may invalidate the range. The discovery row likewise excludes OD-001/021 resolution and missing operational Local Connector/Supervisor delivery.

| Pre-disposal update policy | Production LOC | Integration LOC | Test LOC | Scoped reliability | Confidence | Complexity |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Wait for bounded accepted work; defer update if unresolved | 0 | 150–350 | 500–1,100 | 8 for no premature retirement after qualification | 7 | 4 |
| Grace, then existing authorized cancellation; require actual closure/reconciliation | 0 | 250–550 | 800–1,600 | 8 for same no-premature-retirement promise | 6 | 5 |

These update rows assume existing owned admission, command identity, cancellation and closure/readback. If those interfaces are absent, they are not delivery totals. They overlap the main slice's ordinary restart/lifecycle integration allowance; do not add another generic trusted-loader/restart or helper-process estimate. Neither row includes a new scheduler/runtime/authority. Emergency revocation remains separate and cannot wait for the selected UX preference.


### Extra authority corrections from current AR

- Accepted ordinary-session code has an actual active GM/resource composition and retained cleanup recovery. It must not be confused with the *legacy contained-turn* proposed ADR-0016, which explicitly classifies that separate seven-port boundary as not-adopted static Pure DI.
- A Codex/Claude tagged source union is not evidence of two qualified production providers. Current composition contains an unconditional Claude broker-seam refusal.
- The registry's exact implementation row must be read with its limitations, not just its qualification label or the composition comment saying the target was promoted.
- A new third-party adapter may not acquire the private Host shutdown capability: ADR-0009 keeps that capability at trusted composition and excludes it from ordinary runtime access and feature/provider APIs.


## 1. Decisions that must not be offered again

| Apparent fork | Actual current authority | Audit finding |
| --- | --- | --- |
| Static restart versus immediate fine-grained overlapping reload | EF OD-003 owner-confirmed baseline, 2026-10-25 | Closed baseline. Overlap needs a new capability-specific reason; do not make the owner reaffirm restart. |
| PostgreSQL versus SQLite/local cache | Orchestrator ADR-0114/0115 as routed by current local Host architecture and ADR-0116 | Closed product direction. A historical EF search projection is not canonical product storage. |
| Temporal versus DBOS/OpenWorkflow/custom local scheduler | Current Orchestrator ADR-0116 and resolved OD-035 | Closed: full native Temporal Service with PostgreSQL for Fully Local V1. Alternative engines remain retained research/reconsideration contingencies. |
| GM versus a new DI/container/module framework | EF ADR-0015; Orchestrator ADR-0117 | Closed for applicable TS composition: Core/Assembly 0.5.0 at the exact adopted standard. No Awilix fallback, second graph, service locator or handwritten competing module framework. |
| Host, Desktop or SDK owning local process restart | Orchestrator ADR-0060 and current local Host matrix | Closed: one per-user Local Supervisor owns local Host/process availability; clients bootstrap/discover. AR provider execution custody remains AR's. |
| Copy a cleanup stack / create ownership tickets / choose another generic cleanup library | GM ADR-0030 | Closed substantive mechanism: Resources is the accepted cooperative cleanup contract. Its old ownership-ticket predecessor is withdrawn. Exact consumer adoption still needs qualification. |
| Hub versus module-owned observation subscriptions | GM ADR-0034 resolves OD-007 | Closed: keyed stores, subscriber-owned scopes, no hub. Old OD option tables are historical. Observation may coalesce and cannot replace durable commands/outbox/revocation. |
| Federated catalog versus a new repository/service/local architecture | EF resolved OD-001 and ADRs 0003–0005 | Foundation topology is already selected: explicit authoritative routes; PostgreSQL per writable source; direct trusted digest-pinned OCI remains possible; no merged authority or silent fallback. Product release sequencing remains distinct. |
| OCI versus custom registry; GHCR versus Harbor as product architecture | Orchestrator ADR-0096 and resolved OD-041 | Closed infrastructure: OCI/ORAS/Cosign, GHCR first hosted, Harbor self-hosted conformance; one adapter plus narrow profiles absent proven incompatibility. |

Sources: [EOD3], [E15], [O117], [O60], [G30], [G34], [EOD1], [O96], [OOD41].

### The most consequential stale-authority trap

GM ADR-0029's text still mentions the older ownership contract and S3 → G1 → K1. **ADR-0030 explicitly supersedes ADR-0028 in full**, withdraws `@get-modular/ownership`, K1, A1 and the two-production-scope gate, and says the corresponding references in ADR-0029/CMS gate nothing. The frozen predecessor remains untouched for evidence integrity. Do not revive its gates because its front matter or a later citation still looks accepted. Resources is now the sole cleanup mechanism; the lifecycle kernel is complementary admission bookkeeping. [G30, lines 151–180][G30]

Equally, Orchestrator OD-043's catalog-options list is not a reason to ignore EF's resolved neutral catalog authority. Read OD-043 as remaining product scope/governance/operating details under the accepted Foundation topology. A local-only first release is a sequencing decision, not permission to adopt incompatible catalog identity or fallback semantics. [EOD1]; [OOD43]

## 2. Genuine decision cards, with their actual triggers

These are ordered dependencies, not four independent votes. Reliability ratings below would be **conditional engineering judgments within a named guarantee**, never uptime measurements. The other workstreams should provide scoped implementation ranges after identifying the actual capability. This audit rejects fabricated whole-platform precision.

### Card A — choose the first real capability and supported customization audience

**Status: immediate product-scope decision; no proven implementation blocker beyond defining this scope.**

The record identifies the next actual owner choice explicitly, but does not yet identify a production capability carrying the requisite promise. The packed HostDiscoverySource fixture is useful public-contract evidence; it has no materialized product application, production source adapter, admitted OCI extension or Host at that seam. It cannot silently become the real first product use. [EOD3, lines 149–153][EOD3]; [EPACK, lines 18–31 and 226–247][EPACK]

Genuinely different candidate outcomes:

| Option | What the owner would commit to | What it unlocks | What remains unselected |
| --- | --- | --- | --- |
| A1. One product-owned, trusted configurable/replacement capability through the accepted static composition path | A named use case and allowed provider variation; controlled restart is acceptable | A real reusable core/product adapter, exact GM composition and a concrete no-fork customization demonstration | Public plugin SPI, hostile-code containment, hot replacement and state migration |
| A2. One independently distributed extension at a narrow product port, initially with controlled restart | A named external/private author audience and actual artifact admission/operation UX | Concrete artifact, capability, grant and invocation requirements under the admitted profiles | Broad marketplace, universal Host, zero-downtime promise, unrelated UI/streaming/state semantics |
| A3. One rich Frontend contribution as the first product outcome | A specific command/view/editor contribution, Web/Desktop capability needs and intended author trust | The real OD-042 rendering/permission/layout contract can be designed and compared | A frontend framework, rendering tier or public contribution category set by implication |

**Recommendation:** choose a capability because it is valuable to users, then take the smallest of these commitments that delivers it. A1 is the lowest-burden first candidate only if it actually meets the customization need. Do not recommend it as a surrogate for a user who needs independent third-party distribution or a rich UI contribution.

**LOC and scores:** no defensible complete P/I/T estimate or reliable 1–10 score exists for these three *different product outcomes* before naming the actual seam and invariants. The implementation estimates in the research explicitly exclude domain behavior, UI/installers, newly required authorization/storage and OS containment. Comparing them as equivalent would conceal those costs. Choosing this scope itself introduces zero production/integration/test LOC; that is not the implementation price. A proper estimate must inventory the actual feature, port, grant owner, profile, loader, existing custody owner and required UI/CLI journey.

**Evidence that changes the recommendation:** a concrete customization that static provider configuration cannot express; independent author/release needs; or a first UI/streaming/exclusive/stateful capability whose promises differ from the bounded trusted request hypothesis.

### Card B — select the actual supported execution trust/placement profile

**Status: dependent owner choice, only after Card A establishes an executable extension need.**

| Option | Honest guarantee | Principal burden | Relevant reuse |
| --- | --- | --- | --- |
| B1. Trusted in-process feature/adapter | Explicit capabilities and cooperative cleanup; no arbitrary JS unload or hostile-code containment | Lower deployment and protocol burden; escaped handles and noncooperation remain trusted-code risks | Exact GM Core/Assembly, Resources, feature-owned typed ports and literal loaders |
| B2. Worker/task execution for trusted fault separation or bounded compute | Separately observed task/worker outcomes within the chosen API; no hostile-code security claim from Worker alone | Framing/limits/cancellation/owner retention and adapter-specific closure; pool models may not fit streams or persistent listeners | Existing fitting Piscina/workerpool/direct Worker capability; accepted product authority remains external |
| B3. A terminable isolated process/realm appropriate to untrusted authors | A named, qualified containment/effect-grant boundary with actual termination evidence | Platform security, descendant custody, IPC, permissions, packaging and release matrix | Existing execution/process owner; OS/browser controls qualified for exact placement |

**Recommendation:** do not call a Worker safer than an in-process adapter on the strength of transport separation alone. B3 is required when the first supported author profile needs actual untrusted-code isolation; it is not a substitute for effect authorization or grants. Resources explicitly limits itself to trusted cooperative code and excludes third-party/untrusted code from `scoped()`. [G30, lines 139–149][G30]

**LOC/confidence limitation:** current source estimates compare **bounded trusted logical replacement**, not hostile containment. They must not be used as the complete price of B3. A process boundary with the *same* logical promise does not intrinsically deserve a higher reliability score; its extra fault/containment claims need separate evidence. No full P/I/T figure or score for production B3 is defensible without the exact platform/adversary/effect profile. [EREUSE, “Alternatives and honest planning estimates”][EREUSE]

One auditable source-backed example is the optional, **unadopted** direct-Worker durable request cohort: worker/request adapter 600–1,000 LOC; preparation/resources 500–900; publication/admission/recovery wiring 900–1,700; retirement/capacity/evidence 1,000–1,900. Classifying the stated wiring as integration yields **2,100–3,800 production plus 900–1,700 integration and 5,000–9,000 tests**, conditional on existing owned durable transactions, authorization and custody. This is a decomposition of the source's component ranges (sum 3,000–5,500), not a new quote for an unspecified platform. Source planning judgments are confidence 7, scoped reliability 8, complexity 6. The accepted restart path does **not** require purchasing this stronger cohort. [EHOT, lines 165–180][EHOT]

**Evidence that changes selection:** measured noncooperating work and actual resource/effect escape at the selected seam; platform-specific termination/custody; a pool API imposing a second lifecycle state machine; or proof that ordinary restart satisfies the user outcome.

### Card C — choose the first external contract commitment

**Status: dependent publication/product choice; no evidence that stable public SPI qualification is currently met.**

| Option | Commitment | Consequence |
| --- | --- | --- |
| C1. Keep the first contract product-private with exact local tests | Product can change the seam without external compatibility promises | Allows real product learning; cannot claim a stable public plugin ecosystem |
| C2. Authorize qualification of one narrow public product SPI | Independently authored implementations, exact behavior/compatibility/negative fixtures, ownership, publication policy | Directly enables independent product plugin authors; only selected contribution kinds and placements become supported |
| C3. Authorize qualification of a shared neutral EF protocol/test-kit surface where multiple real products prove common semantics | Cross-product neutrality and conformance, with product adapters retaining capability/domain ownership | Reuse of a proven intersection; cannot move product payloads, host policy or operational lifecycle into EF |

This is **not** a choice to impose two production users on every ordinary library. EF distinguishes package admission, stable SPI publication and Orchestrator production adoption. A narrow ordinary library may have an independent release/replacement rationale without becoming a public plugin SPI. Likewise GM's unstable 0.x composition authorization is not a waiver of EF SPI evidence. [E13]; [E15]; [EOD3, lines 70–85 and 129–147][EOD3]

**Recommendation:** C1 until the owner actually intends an external compatibility promise; C2 for the first useful external product extension point when its scope is ready. C3 only for the genuine neutral portion. Do not choose a new repository/package in place of defining the common contract. Existing GM mechanism owners and the library-first requirement are already fixed. [O117, lines 100–123][O117]

**LOC and ratings:** no complete numeric estimate is supportable before API/schema count, version-negotiation behavior, independent implementation budget, target matrix and release scope are known. C2/C3 must separately count library production code, each actual product adapter, independent implementations, compatibility fixtures and delivery tooling; tests cannot be priced as just duplicating implementation tests. Historical fixture lines and generic hot-reload estimates do not bound those obligations. Scores should reflect the selected profile after that scope exists.

**Evidence that changes selection:** independently authored implementations revealing a stable intersection; real public author requirements; a compatibility failure that demonstrates the product-private grammar is premature; two product integrations that preserve independent domains.

### Card D — connected/offline catalog security operating profile

**Status: genuine but deferred unless the first release actually serves catalog/snapshot/offline installation.**

| Option | Honest operating promise | Required unresolved policy |
| --- | --- | --- |
| D1. Connected catalog updates plus installed-extension continuity during outage | Fresh authority required for the declared new installs/updates; existing behavior follows explicit product enforcement policy | Key custody/rotation, freshness, revocation, outage and cached-data semantics |
| D2. Intermittently connected signed snapshots | New actions may rely on a bounded validity window explicitly accepted by owner | Clock skew, expiry, rollback/freeze detection, stale state and emergency recovery |
| D3. Air-gapped signed snapshot/import profile | Offline actions use explicitly transported authority state; immediate online revocation is not promised | Offline key custody, transfer ceremony, import/update policy, expiry and recovery procedure |

TUF-compatible metadata is a **proposal**, not an accepted dependency or signing topology. Cosign for artifacts is already selected, but Cosign-only blob signing does not settle catalog root rotation, delegation, freshness or rollback protection. A single online key is listed as an alternative but cannot silently lower the accepted invariant floor. A single global guessed TTL is explicitly prohibited. [EOD2, lines 17–77][EOD2]

**Recommendation:** do not pick a TTL/signing quorum merely to make research feel complete. Choose an actual first operating profile if it belongs in Card A's release scope. Then compare existing qualified libraries and custody adapters against the fixed metadata semantics.

**LOC/scores:** no source-backed full P/I/T estimates for the concrete key topology, service adapters, OS credential custody or recovery/restore procedures were found. Treat them as unbounded dependencies for the final decision cards, not zero-cost requirements. Reliability differs by promise: an air-gapped profile cannot be scored against immediate online revocation, and a connected-only profile cannot be scored as an offline installation solution. Whole-system 1–10 reliability numbers would conceal this distinction.

**Evidence that changes selection:** an actual air-gap customer/release requirement, allowed stale-authority window, acceptable key-compromise recovery time, available KMS/HSM/local custody primitives and qualified existing metadata tooling.

## 3. Qualification obligations are not fresh engine or product forks

Current Orchestrator ADR-0116 is unusually explicit: engine choice is accepted, component E2E does not qualify full product E2E, versions are evidence pins, and release must qualify exact engine/SDK/Node/PostgreSQL/native/OS combinations. Its list includes native install/update, replay/upgrade and restore, disk failure, long timers, measured capacity and redistribution. It says these are implementation/release conditions, **not reasons to leave engine selection unresolved**. DBOS reconsideration needs an explicitly accepted successor ADR and migration if Temporal later fails an agreed resource/installation budget. [O116, lines 89–94, 132–165 and 182–188][O116]

OD-021 and OD-040 remain open. The first specifies actual Supervisor lifecycle/distribution policy; the second authorizes exact package materialization and first-slice contracts. They are real implementation-start gates for Fully Local, but **not plugin-specific reasons to reopen PostgreSQL, Temporal, ownership or V1 scope**, and they do not require final release evidence before code can be created. Conversely, accepted engine selection alone does not authorize those package roots. [OOD21]; [OOD40]

Orchestrator ADR-0117 requires bounded initial adoption evidence for actual nested module assembly. A smaller qualified envelope may start without every 100/500/1,000-entry research row. It does not adopt the lifecycle kernel; Resources/Observation/conformance need their own exact first-use artifacts. Do not inflate a module validation result into nested conformance, dynamic lifecycle, or active-plugin capacity. [O117, lines 77–115][O117]

## 4. Evidence claims that need strict wording

| Evidence | Supported statement | Unsupported promotion |
| --- | --- | --- |
| Packed consumer experiment: 433 new TS lines; 39 fixture, 161 TEST composition/consumer, 233 driver | Real public HostDiscoverySource port exercised through independent packed fixture/helper and external GM 0.5.0 consumer; four OS/Node lanes and ten named scenarios plus parent | Production extension Host; artifact trust/custody; UI; production grants/isolation; drain/restart; thousand active plugins; independent production product integration |
| Current native Temporal matrix | Component E2E on Linux/macOS/Windows with retained assertion counts and explicit skip; accepted engine choice | Comparative numeric reliability, installed/signed product, native resource capacity or complete role-transport E2E |
| GM Resources/Observation | Accepted precise mechanisms with stated limits | Forced disposal, arbitrary callbacks stopping on timeout, hostile containment, durable delivery or event-broker semantics |
| Lifecycle-kernel TEST tarball | Candidate local generation/admission/retention bookkeeping, zero-runtime-dependency leaf | Released product SDK, durable grants, process cleanup, physical termination, a production dynamic Host |
| 14-framework source follow-up | Documented/inspected source and unrun test comparisons, with conditional transfer hypotheses | Executed frameworks, dependency adoption, owner approval or production qualification |
| DocsProtocol hosted gate success | Exact documentation/protocol route at its observed tree | Production runtime readiness or a new technical decision |

The packed report states zero production **and** zero product-integration LOC. Counting its 161 TEST composition lines as a production product integration would erase the central evidence boundary. Its final section explicitly says the product application, admitted plugin/configuration surface and executor custody handoff are absent. [EPACK, lines 117–127 and 226–247][EPACK]

Orchestrator OD-041's **two independent product integrations** are distinct from EF public SPI independently authored implementations and from GM adoption adapters. The packed experiment does not count as satisfying all three just because packages are independently built. [OOD41, lines 77–96][OOD41]; [E15, “Pre-1.0 and stability gates”][E15]

## 5. Requirements for the final owner's option table

1. Present at most the triggered cards, and explicitly label deferred cards. Do not turn every open heading into a separate immediate vote.
2. State the named behavior and availability/trust guarantee before comparing reliability.
3. Count incremental production, integration and tests separately. If a prior source bundles integration in production, preserve that fact or expose an auditable decomposition; never split a total by intuition.
4. List reuse and prerequisite dependencies: exact GM artifacts, existing application receipts/authorization, process custody, release/install matrix, independent implementations, UI/domain work.
5. Quote ranges as planning hypotheses with scope and approximately twofold uncertainty where the source says so. Confidence in authority may be high while confidence in implementation sizing is low.
6. Use **“not bounded until X is selected”** where the scope is absent. A missing estimate is a research gap to close; a confident fabricated number is worse evidence.
7. Do not sum mutually exclusive transport/replacement rows or attach their stronger coordination machinery to the already accepted restart baseline.
8. Record what concrete evidence could reverse the recommendation. Research/critic consensus remains advice, not owner adoption.

## Source references

All references are exact immutable pins read in this audit; headings and line ranges in the report identify the relevant passages.

[EOD3]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md
[E11]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/decisions/0011-extension-admission-custody-and-retirement-closure.md
[E13]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/decisions/0013-first-consumer-module-semantics-before-foundation-extraction.md
[E14]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/decisions/0014-product-local-module-authoring-composition-and-generation-guardrails.md
[E15]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/decisions/0015-authorize-get-modular-semantic-extraction.md
[EOD1]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/open-decisions/OD-001-federated-extension-catalog-topology.md
[EOD2]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/open-decisions/OD-002-catalog-security-and-offline-operational-parameters.md
[EPACK]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/research/packed-extension-consumer-e2e-2026-11-05.md
[EHOT]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/research/hot-reload-and-generation-replacement.md
[EREUSE]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/research/reusable-generation-mechanisms-and-ownership.md
[ESYN]: https://github.com/agent-teams-ai/extension-foundation/blob/33c50b92b005b6e3da56cc1905aad51ce68352e1/docs/research/plugin-research-synthesis-and-authority-2026-11-05.md
[G29]: https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md
[G30]: https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/decisions/0030-admit-the-module-resource-scope-package.md
[G34]: https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/decisions/0034-admit-the-module-change-observation-package.md
[O60]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/decisions/0060-single-local-supervisor-lifecycle-owner.md
[O95]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/decisions/0095-extension-safety-and-ownership-invariants.md
[O96]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/decisions/0096-shared-extension-foundation-and-oci-distribution.md
[O116]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/decisions/0116-native-temporal-for-fully-local-durable-workflows.md
[O117]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/decisions/0117-reconcile-mandatory-module-composition.md
[OLOCAL]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/architecture/local-host-lifecycle.md
[OOD21]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/open-decisions/OD-021-local-supervisor-lifecycle-and-distribution.md
[OOD35]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/open-decisions/OD-035-local-durable-workflow-engine.md
[OOD40]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/open-decisions/OD-040-fully-local-package-materialization.md
[OOD41]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/open-decisions/OD-041-shared-extension-foundation-and-artifact-distribution.md
[OOD42]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/open-decisions/OD-042-frontend-extension-contribution-model.md
[OOD43]: https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/a34587b313e656eeb43d755b4a4f08c40dff2116/docs/open-decisions/OD-043-extension-lifecycle-catalog-and-hot-update.md
[AR9]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0009-contained-turn-private-access-and-host-shutdown-boundary.md
[AR12]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0012-provider-access-authority-in-contained-turn-composition.md
[AR90]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/decisions/0090-ordinary-user-session-codex-execution-profile.md
[ARCOMP]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/apps/embedded-runtime/src/composition/contained-turn-feature-composition.ts
[ARPORT]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/application/ports/outbound/contained-turn-execution-ports.ts
[ARORDPORT]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/packages/contexts/agent-execution/src/features/contained-agent-turn/application/ordinary-ports.ts
[ARREG]: https://github.com/agent-teams-ai/agent-runtime/blob/f990acc26e1b8071ae22d0b87a2ddd3672be8e2e/docs/architecture/qualification-registry.json


## Final authority review of proposed governed delta

**Verdict: PASS for authority and claim boundaries; no substantive blocker found.** Reviewed the actual uncommitted delta under `plugin-decision-brief-2026-11-06/authoring`, including the new “Owner decision brief, 2026-11-06” in OD-003, the maintained research-reference navigation, the review/decision record and all three historical/current Temporal corrections. This is a read-only independent review; I edited only this scratch report.

The new OD-003 section:

- Keeps exactly two product choices, explicitly proposed and awaiting owner choice; makes no alternative, production Host, public SPI, implementation or release accepted.
- Retains the owner-confirmed static/restart direction and separately accepted native Temporal/PostgreSQL choice. The current merged-main correction preserves old execution pins and historical unmerged observations.
- Uses disjoint production/integration/test planning ranges, explains approximately factor-two uncertainty, distinguishes conditional scoped reliability from availability, excludes mechanically moved/generated source, and says missing baseline/deployment/custody owners are outside the increment. It avoids presenting the figures as production-release totals.
- Identifies a useful independent behavior as necessary for 1A; identical repackaging alone does not complete the no-fork outcome. It explicitly describes the Linux route registry as implementation-only and accurately lists its absent real deployment evidence/owners. It does not equate the two-case Codex/Claude union with two qualified implementations.
- Treats Choice 2 as ordinary update timing before actual disposal. Its immediate following text preserves AR ADR-0009's cutoff/containment/drain/receipt rules, makes unresolved work pending or `reconcile_required`, and forbids fake cleanup/update deadlines. Emergency revocation and accepted owner deadlines are not delayed by the ordinary update preference.
- Keeps public SPI, hostile-code isolation, state migration, broader scale, another package/repository, native additions and optional Temporal rollout as independently triggered subjects. It imposes no resurrected ADR-0028 ownership/K1 gate or new blanket approval requirement on ordinary static libraries.
- States that the next owning-product delivery records the selected scope. This is existing product authority discipline, not permission for research to implement the selected production seam now.

The historical/current authority repairs are accurate against freshly fetched Orchestrator `a34587b313e656eeb43d755b4a4f08c40dff2116`: ADR-0116 is accepted on merged main, OD-035 engine selection is resolved, and exact native deployment/release qualification remains separate. Accepted ADR bodies and executed inputs are not modified by the reviewed delta.

**Packaging dependency at review time:** the new OD-003 references `plugin-decisions-20261106.tar.gz` and its JSON member manifest, which the parent said would be added after this report was finalized. The substantive text passes; the parent must supply and verify those exact evidence artifacts before treating the links as delivered. This verdict does not claim to have checked an archive that did not yet exist.

A read-only `git diff --check` on the reviewed working tree returned no whitespace errors. No framework or production tests were rerun or needed for this source/authority review.

Final wording recheck also confirms the “Repository and language” item now names GM composition and optional local-kernel ownership, rather than implying that GM owns all cleanup authority. **This report is frozen for the parent's evidence archive.** Last review covered source text and cited authority; it did not rerun implementation, native deployment or external framework tests.


