# Root dispositions — owner decision brief, 2026-11-06

Status: decision preparation only. No option is accepted by this report. No production, product-integration or test implementation was added; no unchanged E2E or upstream framework was rerun.

## What the owner asked
Identify substantial remaining technical/product forks, explain what is already documented/accepted, and present each option with separate LOC estimates and reliability/confidence/complexity scores. Preserve research without converting it to an adopted design.

## Team and procedure
Three independent GPT-6.1 Sol xhigh agents received the complete common brief and source locations: authority audit, product options, and mechanism/estimate critique. They examined current primary repository source, shared counterevidence and cross-reviewed the same shortlist. Authority and mechanism critics then reviewed the actual governed OD-003 and current-guidance diff. Their agreement establishes review, not owner approval.

## Final two-choice shortlist
1. First useful no-fork customization: existing AR provider-family variation (conditional recommendation), a named new AR provider, or protected discovery when bootstrap is the actual priority. Every path must have a real useful variation and actual consuming-product journey.
2. Ordinary update timing before Host disposal: seal new work and wait/defer (conditional recommendation), or grace then existing authorized cancellation and exact closure. Existing shutdown invariants are fixed.

The authoritative pending option wording, ranges, exclusions and scores are the dated owner brief in EF OD-003. The reports retain wider conditional cards for traceability; those are not extra immediate decisions or an implementation backlog.

## Corrections retained
- Orchestrator ADR-0116 is on merged main a34587b3. Native Temporal with PostgreSQL is selected for Fully Local; production qualification remains separate. Older EF statements that PR90 is unmerged were corrected in current guidance and dated as historical where they record October evidence. Accepted ADR bodies and frozen evidence were not changed.
- Existing AR provider/custody ports are useful reuse, but the private codex/claude selection is not a public user plugin SPI.
- The exact Docker/Linux Codex route registry row is implementation-only, expressly without a live kernel/provider/container/credential/origin journey and with missing production broker-session owners. Initial shorthand saying admitted Linux profile was rejected and corrected before the final brief.
- Claude is refused because its broker seam is absent; a registry row alone cannot admit it.
- Actual Host disposal already requests durable cutoff for nonterminal in-scope work. Wait/defer can precede disposal; it cannot redefine shutdown as wait-only.
- The update preference does not delay mandatory security revocation, failure containment or existing owner deadlines.
- GM Resources owns the cooperative cleanup mechanism; actual cleanup and physical-custody authority remain with the execution owner. OD-003 wording was narrowed to composition and optional local-kernel ownership to avoid implying otherwise. Existing lifecycle-kernel candidate gates remain applicable only as actually superseded/currently owned.
- Public SPI publication, ordinary package admission and product adoption are distinct. No blanket strongest gate is imposed on ordinary source libraries.
- A current catalogue architecture choice was rejected: neutral authority routing and canonical stores are already selected. Exact operating/signing/offline parameters remain dependent open questions.
- Worker/pool/Rust/Temporal timing and private-state cards were kept conditional or deferred. They are not independent votes for a provider adapter that already has execution owners.
- Original small packed discovery E2E is reusable construction evidence; it does not qualify a product Host, a new artifact lifecycle, actual user customization or thousand-active-plugin capacity.

## Estimate review
First capability estimates separate new/changed production, integration and focused test code. Existing generated/moved provider source is excluded and identified. 1B includes the seam work of1A. Scores are scoped engineering judgments, not uptime or probabilities. Confidence for1A sizing is6, not the product researcher's separate8 for scope fit.
Update timing estimates assume usable owned admission, cancellation and readback. They overlap prior restart allowances and potentially capability integration; no sum is a platform total.
Missing real deployment owner work, native releases and qualification campaigns are explicitly outside the bounded customization increments. A complete production delivery total remains unknown until the selected variation/provider and prerequisites are inventoried.

## Disposition of implementation
Only research/navigation and an open decision are changed. No package, runtime, API, dependency, workflow, production source, test source or accepted ADR was modified. No owner answer is inferred. EF PR55 remains a draft; publishing the brief does not merge it or accept its options.

## Evidence handling
The companion manifest identifies the archive, exact regular member set, byte sizes and SHA-256 digests. Source URLs and pinned file paths remain in every critic report. This archive does not redistribute third-party implementations or dependency binaries. Its snapshot is immutable; later decisions must be recorded explicitly and separately.
