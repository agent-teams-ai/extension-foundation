# Plugin/module research expansion and authority clarification

Owner instruction date: 2026-11-05. Research retrieval dates use UTC. This is a new research
and documentation task after completed public-package integration E2E. It does
not authorize implementation of unresolved plugin architecture or a new runtime.

## Full task intent and latest clarification

The owner wants all module/plugin research, implementation ideas, good patterns,
bad patterns, dates, technologies, source versions and details saved so future
agents can find the evidence without repeating the search. Research is retained
information, not an accepted design decision. Decisions are discussed with the
owner and recorded through their owning mechanism. Critic agreement, competitor
adoption, a prototype or a passing test must not silently become that decision.

The owner explicitly asks to inspect more competitors and especially frameworks
whose specialty is modularity. Inspect ideas AND concrete implementations across
agent products and general systems; being a specialist does not make a design
better for this project. Evaluate both benefits and costs against our actual
vision, architecture and technologies. Do not blindly copy competitors, invent
their deficiencies, count stars/popularity as quality, or call a deliberate
tradeoff a defect. Preserve repaired historical incidents with their resolution.

The intended product supports deep useful customization without project forks,
hundreds or thousands of modules and many third-party plugins, including useful
composition between extensions. It must be understandable, reliable, maintainable
and scalable, with explicit responsibilities and easy authoring. Clean
Architecture, SOLID, DRY, DDD, modular and pluggable are concrete ownership rules,
not permission to add universal managers, ceremony or abstractions. No
overengineering. DDD applies to real bounded contexts and invariants, not a
fabricated domain model for a small tool or fixture. No default feature flags.

The owner is concerned that earlier work may have implemented choices not yet
agreed. Audit the actual boundary and wording. Only already confirmed decisions
may drive product implementation. This task's changes are research/navigation
and explicit provenance/authority clarification; no new production runtime,
public SPI, language migration, artifact admission owner or architecture adoption.

Use powerful researchers and independent critics at xhigh. The earlier explicit
model request was GPT-6.1 Sol xhigh; the current request permits the strongest
models at xhigh, including an independent GPT-6 Astra critic. Give every agent
this full brief and the retained current quality standard. If uncertainty remains,
research the disputed mechanism and get overlapping independent criticism first.
Only material genuinely unresolved technical/product choices go to the owner,
with concrete options, confidence/reliability/complexity each /10 and scoped
new production/integration/test LOC, uncertainty and release/maintenance burden.
Higher complexity means more burden. These scores are engineering judgments,
not measured uptime or framework benchmarks. Do not ask the owner to choose a
framework merely because we researched it.

## Existing accepted boundaries and confirmed direction

- GM owns neutral composition: module/capability/implementation/slot identities,
  declarations, bindings, graph compilation, canonical plans/digests and bounded
  composition diagnostics. EF does not duplicate or import that composition core.
- EF owns neutral extension/artifact/trust/protocol/conformance concerns. Products
  own concrete extension points, capability payloads, grants, profiles, loading,
  runtime policy, readiness and domain state. Existing execution owner keeps
  physical custody. No second Host/PluginManager/supervisor/container.
- Ordinary extensions cannot replace authorization, invariants, fencing,
  canonical state or security enforcement. Permission requests are not grants;
  signatures, discovery listings, entitlement, authorization and enforcement
  are separate facts. No global service locator or universal plugin interface.
- Static composition plus controlled restart is owner-confirmed. Temporal may
  be an optional adapter above the same owned operation where its infrastructure
  is already qualified. No generic seamless hot-swap protocol is approved here.
- TypeScript remains the primary application language. Choose a native boundary
  only for concrete measured/semantic benefit and full platform/release cost;
  preserve accepted Rust custody, do not rewrite everything in Rust. New maintained
  JS-runtime code must be strict TS7.0.2+, ordinary .ts; no .mts or initialization
  of an older embedded TS compiler. This research needs no new runtime code.
- Respect immutable accepted ADRs and product adoption pins. Current reference
  links/recipes may track latest; immutable evidence remains pinned and dated.
  MVP breaks can be deliberate, but persisted data/in-flight state need safety.
- Native PostgreSQL local/hosted direction is already recorded in Orchestrator;
  do not reopen SQLite from stale historical docs or adopt a new stack here.

## Repositories, current checkpoint and evidence limits

Shared checkout root:
`/workspace/scratch/f863b9d38368/plugin-industry-2026-11-05/repos`.

EF checkout: `extension-foundation`, branch
`docs/plugin-research-hot-reload-20261021`, PR55 open draft at
`9f5ba60232c19e78022b40dddea71ab3aea1cdea`; main29ae5b0. Root owns repository
edits and publishing. Continue this PR; no new branch/PR, no merge authorization
in this task. `gh` is absent; central standard permits the connected GitHub
route without weakening exact-head or attribution checks. Agents do not push.

GM inspected main5fb83478dd7b95216be92c4d3077eddf2774eef8; Orchestrator
5a8496ce711909e381c5bc817fff5500be9a1761. Recheck moving source before a new
current-state claim. Orchestrator accepted ADR0117 still pins Core/Assembly0.5.0;
that is distinct from newer GM main/npm and frozen0.7.0 scale evidence.

The previous E2E is explicitly public-package integration: unchanged copied
Orchestrator local-host-control A source/private0.0.0 exports, separately packed
fixture B/H, real public GM0.5.0 selection, actual A discovery operation, exact
rejection paths, pending old/new instance binding and fresh consumer removal.
433 maintained TS lines are research fixtures/consumer/driver, zero production
or product integration code. All10named scenarios plus parent passed locally
and on4hosted profiles (LinuxNode24/26, macOSARM64, Windowsx64). Source inputs,
original failures, corrections and nine reports are retained in EF docs/research
evidence. This does not qualify a materialized product plugin Host, user UI,
artifact-to-executor custody, production restart/drain or fleet capacity.

The exact hosted E2E run42099097668 used commit11fa2e2. Final9f5ba60 repository
CI and actual trusted Docs route succeeded. The managed Foundation1.7.2 Cohort
still binds an older embedded compiler; native Foundation releases exist but
the inspected central qualified Cohort has no native successor. Do not run that
legacy CLI or silently repin managed inputs. Independent DocsProtocol works.

Read EF AGENTS.md and `quality-standard.md` in this task root before your work.
Root also read the repo .agents/skills/docs-authoring/SKILL.md; governed new docs
use its info/find/preview/apply/index/context/check route. Do not hand-edit any
tool-owned transaction files or accepted ADRs.

## Prior coverage: avoid pretending repeated systems are new

Read the research reference and relevant source ledgers before choosing claims.
The existing shelf covers: OpenClaw (including later corrections), OpenCodeV2,
ClaudeCode mods, Dify, VSCode, IntelliJ, Theia, OSGi, Vault/go-plugin, Backstage,
JupyterLab/Lumino, Gradle, Jenkins, ChromeMV3, Erlang/OTP, NGINX, Envoy, Vite,
Node ESM/workers, Kubernetes, Wasmtime/Extism, Temporal, Flink, Piscina,
workerpool, PM2, tableflip, Suture, ArcSwap/Tokio/Pingora and native-ABI cautions.
Repeated systems are useful only for a new mechanism/source or a dated repair.
Current N1000 construction and1024live scoped receivers are separate bounded GM
evidence, not third-party plugin fleet throughput or hostile isolation.

## Research lanes

1. Agent ecosystems: Google ADK, Pydantic AI, Microsoft Agent Framework (read
   AutoGen/SemanticKernel lineage only where primary sources require), Mastra,
   ElizaOS, Letta. Six deep cases, not six marketing summaries. If a project has
   no plugin lifecycle, explain its actual extension unit instead of relabeling
   a tool/function registry as a complete plugin system.
2. Specialist module/plugin frameworks: Pluggy, PF4J, Fastify/Avvio, Hapi, NestJS,
   Drupal. Six cases on hook contracts, provider cardinality/order, encapsulation,
   dependency lifecycle, state/cleanup, discoverability and no-fork customization.
   Explicitly contrast the different boundaries, without framework adoption.
3. Root investigates adjacent data-plane/catalog mechanisms (OpenTelemetry
   Collector and Apache APISIX) and synthesizes cross-case ownership questions.
4. Independent critics audit authority/earlier work, evidence quality and fit;
   then challenge the same uncertain transfer hypotheses from different angles.

## Required case record and evidence discipline

For every case preserve:
- stable case ID, question, retrieval date, repo/doc URL, exact code commit and
  release/tag relationship (never call inspected main a released feature);
- technology/runtime and actual unit of extension/composition/execution;
- primary documentation plus inspected concrete implementation path/symbol,
  with specific URL supporting each material claim; existing tests can be
  inspected but are not described as executed;
- conflict/order/cardinality, lifecycle/dependency closure, compatibility and
  trust/authorization boundaries where actually present;
- strengths, counterevidence, deliberate tradeoffs, failure mechanisms and
  historical-fix status; no unsupported competitor defect or sweeping absence;
- a conditional transfer hypothesis mapped to GM/EF/product/execution owner,
  why it might fit and why the analogy may break; status stays unadopted;
- the smallest falsifier or experiment that could change the conclusion,
  described as a proposal only; no new spike/implementation in this task.

Use evidence classes: documented contract, inspected source, inspected unrun
test, historical report/fix, inference, proposed experiment. Keep them explicit.
Primary technical sources only. Prefer immutable source URLs and exact symbols.
No popularity/stars rankings. No fake measurements or total LOC/uptime estimates.
Do not copy whole external docs/code into reports; paraphrase, keep quotations
short, retain exact source identifiers/links and minimal necessary snippets.

Reports go under
`/workspace/scratch/f863b9d38368/plugin-modularity-research-2026-11-05/reports`.
Agents may create only their assigned report/source-ledger files. All source
inspection is read-only; no product code edits, tests, package installs or remote
comments/PR mutations. Root archives the reports and publishes governed summaries.
Only3subagents plus root can be active; no further delegation while slots are full.
