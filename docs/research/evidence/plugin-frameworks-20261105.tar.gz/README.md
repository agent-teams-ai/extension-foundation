# Retained module/plugin framework research — 2026-11-05

This bundle preserves research information, criticism and correction history.
It adopts no design or framework. The current governed synthesis and case reports
in Extension Foundation are the navigation entry; accepted decisions retain their
existing owners. Do not treat an initial report or proposed falsifier as authority.

## Contents

- `reports/agent-frameworks.md`: six agent extension systems and bounded transfer ideas.
- `reports/specialist-frameworks.md`: six specialist framework cases.
- `reports/data-plane-frameworks.md`: OpenTelemetry Collector and APISIX.
- `reports/cross-framework-synthesis.md`: source/decision discipline and conditional fit.
- `reports/*-sources.json`: source dates, commits, symbols, URLs, release relationships and limits.
- `reports/review-dispositions.md`: concrete findings, corrections, uncertainty and authoring history.
- Six research critique reports and separate navigation/gate publication reviews, with actual reviewer overlap recorded.
- Files containing `initial` or `pre-final-critique`: superseded working interpretations retained for provenance, not current findings.
- `brief.md`: owner vision and task boundaries supplied to every agent.
- `quality-standard.md`: historical policy snapshot read for this task; the manifest records its current-source route and blob.
- Root `*.log` files: actual create previews/applies, bounded context, preflight checks, original authoring/recovery failure and first full-gate timeout.
- `publication-tree.json` and `first-full-gate-local-inputs.json`: original failed gate inputs, including separate identity of its preserved untracked tool artifact.
- `verification-tree.json`, `verification-inputs.json`, `verification-session-observation.json` and `verification-*.log`: distinct clean-tree attempt and its indeterminate outcome.

No investigated framework was installed or executed, and no upstream test or
proposed falsifier was run in this follow-up. Exact source inspection is not
published-package qualification. Historical repaired defects remain repaired.
The previous public-package E2E is unchanged and retains its own evidence bundles.

The failed original authoring checkout was preserved; normal recovery refused an
orphan temporary artifact. Successful publication used a separate checkout of
the same exact Git base with the normal sequential Docs Protocol writer and
frozen tooling. Do not confuse that authoring event with a plugin-runtime result.

The adjacent repository manifest records this archive and every regular member's
SHA-256 and byte size. Raw third-party source caches, dependencies, full checkouts,
credentials and tool-owned transaction artifacts are not included. Final full
Docs Protocol and hosted exact-head validation belong to the publication/PR
receipt; this bundle's command logs are explicitly pre-publication observations.

The first full documentation gate passed seven of eight contract tests; its
fixture apply exceeded the unchanged timeout. The cause remains unresolved.
A separate clean-checkout verification reported four contract passes, then its
execution session became unavailable without a terminal summary or exit code.
Its full outcome is indeterminate; the actual inputs, partial log and observation
are retained. No third local rerun is attempted. The already authorized research
draft will use existing hosted full checks at its exact final head; the PR receipt
owns that later observed outcome. No test, timeout, gate or dependency is weakened.
