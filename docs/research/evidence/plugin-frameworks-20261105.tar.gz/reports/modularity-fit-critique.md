# Independent modularity, customization and scale critique

Research cut: **2026-11-05 UTC**. Status: **independent criticism of retained research; no architecture adoption or implementation approval**.

## Disposition

**The current synthesis is useful for this architecture and can be published as research. It does not justify creating a generic plugin platform. No material owner decision blocks this documentation task.** Its strongest conclusion is to make the behavior of a real consumer-owned seam precise while preserving the existing composition, artifact, product and execution owners. Its weakest possible reading would turn every observed hook, lifecycle state, identity, diagnostic and falsifier into a required shared subsystem. The present synthesis explicitly rejects most of that reading; retain those qualifications in any shorter summary.

The owner-confirmed baseline remains static composition with controlled restart and, where qualified infrastructure justifies it, an optional Temporal adapter above the same product-authorized operation. That agreement permits downtime. It does not permit dropping accepted work, confusing an uncertain external effect with cancellation, moving grants into an extension, or treating a callback result as proof of actual cleanup. These are different guarantees with different existing owners. Nothing in these 14 cases selects a public SPI, new Host, manager, supervisor, composition compiler, security profile, programming language or native boundary.

I read the full owner brief, retained Engineering Quality Standard and EF `AGENTS.md`, the documentation-authoring route, the four assigned reports and their three source ledgers. I also read the existing EF architecture overview, extension model, ADR-0014, ADR-0015, relevant ADR-0011 applicability text, OD-003 and the static-restart validation record to check whether a proposed lesson already had an owner or an applicability limit. Those reads were not an audit of every claim in the preceding PR or of the final publication transaction.

For overlapping disputed mechanisms I independently fetched exact primary source for Pydantic ordering, capability normalization and the abstract contract; PF4J's manager; Letta's design README and tool-owner guards; and ADK's close/borrow behavior. I read the pinned APISIX threat-model and OTel component-contract caches with their ledger identities. No upstream code or tests were executed, no package was installed, and no repository, transaction evidence or remote state was changed. This report is the only file created by this review.

## 1. Hook semantics are useful contract questions, not an adopted taxonomy

**Reviewed sections:** synthesis “Conditional lessons” §1; AF-001 and its transfer register; SF-PLG; specialist cross-case table; DP-02-H1.

**Finding: retain, with one interpretive guard.** Collecting contributions, selecting one provider, wrapping an operation, returning the first result, observing an event and transforming a stream involve different promises. The distinction explains why the same word “plugin” hides incompatible behavior. It is useful research. An exhaustive enumeration of public hook kinds is neither established by these cases nor required to make an actual product extensible. The current synthesis already says that it proposes questions rather than six base interfaces; that is an important correction, not incidental wording.

These examples also overlap: a wrapper can transform a stream; a first-result hook can select a cached response without selecting a unique implementation; an all-observer notification can still have sequential order and a deliberate error-continuation policy. Consequently the list is not a clean algebra from which to generate a universal `HookKind`, lifecycle interface or new EF schema. A small ordinary function or narrow product port can express the selected behavior without another public abstraction. Conversely, allowing arbitrary callbacks does not relieve the product of its existing postconditions.

The accepted authoring guardrails already separate explicit `required`, `optional` and ordered `many` bindings from concurrency/retry policy and forbid selection by discovery order. That makes the **difference between composition selection and invocation dispatch** immediately relevant. It does not mean every invocation pipeline needs another GM declaration or runtime graph. ADR-0015 also distinguishes authorized factory construction from admission, readiness and activation. [EF ADR-0014, “One inert declaration authority” and “Two-level composition ownership”; EF ADR-0015, “Separate authorities.”]

**Smallest correction:** preserve the synthesis's existing disclaimer; if shortened, use: “These are overlapping examples of seam semantics, not an exhaustive public taxonomy. Specify the behavior a real seam needs and reuse the existing GM selection facts where applicable.” No owner question or implementation follows.

## 2. Pydantic presence, order, instance binding and readiness must stay separate

**Reviewed section:** AF-002, mechanism 1 and smallest falsifier; ledger PYD-S1–S3; synthesis case table and §3.

**Independent source check.** At `e2332baaba4feb2c92f5ed47b7343374c2ba3546`, `CapabilityOrdering.requires` names capability **types** whose presence is required, without an ordering edge. `_validate_requires` searches the union of leaf types using subclass matching. Relative `wraps`/`wrapped_by` constraints add edges for matching types or exact object identities. Those checks neither bind one unique service instance nor establish a usable resource or semantic-version-compatible artifact. The sorting function returns immediately for zero/one top-level entry before calling requirement validation. `CombinedCapability.__normalize_capabilities` calls that sorter after flattening/dispatch construction when ordering exists. [Pinned `_ordering.py`](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/_ordering.py), blob `ca88485ba2118f57851da9b2280d2eb81e261ef6`; [abstract contract](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/abstract.py), blob `8920d8e9e7853f13b3236ab1152269562a3d00e8`; [normalization](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/combined.py), blob `0929cc06dead816691a08430e64516b2e5ca3ede`.

The report correctly preserves the singleton question as unrun and avoids calling it a demonstrated public defect. I agree with that disposition. Independently seeing the fast path strengthens a scoped control-flow observation; it still does not establish every Agent construction/runtime route. There is no need to install or run Pydantic to publish that bounded observation.

**Smallest correction:** the first paragraph currently says that `requires` “validates” presence before the later paragraph introduces the source exception. For a reader who only retains the summary, change that clause to: “`requires` declares type presence without order; the inspected multi-entry sorting path validates it, with the singleton fast-path caveat below.” Keep the documented promise and inspected exception in the same summary. Also keep missing ordering targets separate from required presence; adding a relative order relation is not itself a required-provider binding.

**Fit:** the useful transfer is the separation of facts. Copying the capability supertype, Python class matching, object-reference identities or another topological sorter would add a competing mechanism and import semantics our serializable identities do not share. GM already owns neutral bindings; products own the meaning and lifetime of the actual port. EF can retain research examples without publishing a new presence/order protocol.

## 3. PF4J's manual and bulk startup paths support a narrow readiness question

**Reviewed section:** SF-PF4J, “Good failure handling and entrypoint-specific counterevidence”; ledger SF-PF4J-I1; synthesis §2.

**Independent source check.** At `6ffa261f0e28f88a9115432482cad64979715a0d`, `startPlugins()` visits `resolvedPlugins` and invokes `doStartPlugin` directly for eligible states. `startPlugin(id)` instead calls `startDependencies` first; that method checks whether required dependencies reached STARTED and records failure before rejecting the dependent. `doStartPlugin` catches an ordinary startup exception or `LinkageError`, records FAILED and returns the state. It does not contain that dependency recheck. Thus descriptor order and the single-start test cannot establish the same required-runtime-success protection for the bulk path. [Pinned manager](https://github.com/pf4j/pf4j/blob/6ffa261f0e28f88a9115432482cad64979715a0d/pf4j/src/main/java/org/pf4j/AbstractPluginManager.java), blob `9a8576427dad50df935c2518da1b65498b69c736`, methods `startPlugins`, `startPlugin`, `startDependencies`, `doStartPlugin`.

The specialist report correctly treats this as an unexecuted inference and retains the successful single-start protection. Do not weaken that qualification into “PF4J ignores dependencies,” and do not erase the bulk-path distinction because there is a passing upstream test for a different entrypoint.

**Smallest correction:** no material factual correction is necessary. In any shortened summary say “descriptor closure versus entrypoint-specific startup success,” rather than “PF4J guarantees dependency readiness.” Lifecycle STARTED is itself narrower than a product-specific readiness predicate, especially for background startup. The useful question for our future selected operation is whether all entrypoints that claim the same usable-dependency guarantee actually enforce it. That is a product/readiness obligation, not a reason for EF to acquire a manager or for GM to start resources.

## 4. Deep no-fork customization needs useful seams and explicit authority

**Reviewed sections:** synthesis §5; AF-006; SF-FST/NEST/DRUPAL transfer paragraphs; DP-02 trust and method-override discussion.

**Finding: the ordinary/privileged distinction is correct and essential.** Letta's pinned design explicitly favors trusted local code, recoverability and agent repair over starting with a strongly versioned semantic SDK. It still reserves host-coordinated calls for real harness invariants. APISIX's pinned threat model treats operator-supplied Lua and the external runner as trusted. These are legitimate product choices, not competitor defects. They also cannot establish the safety of ordinary third-party code changing our authorization or containment implementation. [Letta design README](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/README.md), blob `6d510f8ee3f9148614ee23b48353195a96ef2eef`; [APISIX threat model](https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/security-threat-model.md), §§4.2–4.3, as retained in the data-plane ledger.

Fastify encapsulation, Hapi realms, Nest exports and PF4J class visibility are useful **authoring/resolution** mechanisms. The reports correctly avoid promoting them to hostile-code isolation. TypeScript types, a signed artifact, a catalog listing, an API availability boolean, an external process and a model-visible tool filter also answer different questions from authorization and enforcement. An “ordinary plugin cannot replace authorization” rule is already our constraint, not a new research choice.

However, restricting authority alone does not prove **deep useful customization**. A perfectly isolated extension can still be too narrow to solve a real user's task without internal imports or patching. Relevant future evidence is whether the chosen product slice permits the intended alternative implementation and cooperation between independent extensions through declared contracts while preserving the same invariant. That can include configured policy inputs interpreted by the existing policy owner; it need not grant plugins the authority to replace the policy engine. Broad alteration, universal runtime access and method patching are only some possible ways to make changes, with very different maintenance costs.

**Smallest correction:** add, if a compact product-fit conclusion is desired: “Useful no-fork fit must be shown by a real customization and extension combination at a selected seam; the number or breadth of exposed callbacks is insufficient.” This names an evidence gap, not a new campaign or a public-SPI approval. Keep built-in/external semantic substitutability distinct from identical privileges or placement. The existing Extension Model already makes that distinction under “Extension-Ready, Not Plugin-First.”

## 5. Ownership is more useful than another universal lifecycle

**Reviewed sections:** synthesis §§2–4; AF-001/002/005/006 cleanup; SF-FST/HAPI/NEST; DP-01 component lifecycle.

**Finding: retain the precise identity/lifetime comparisons; do not standardize their union.** An artifact digest, contribution identity, selected implementation, activation owner, object instance, per-run state key and physical resource are distinct. Letta's `unregisterModTool` checks the current entry's owner ID before deletion, and its new-call path checks an activation signal. That protects a successor from a stale disposer; it does not await cancellation of an already running effect. ADK's borrowed-plugin switch prevents a child from closing its parent's objects. These are small concrete obligations that can fit an existing owner without another lifecycle coordinator. [Letta tool registry](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/tool-registry.ts), blob `ddb0d478c88f9facf4962f7d62093b5c5b1f39de`; [ADK plugin manager](https://github.com/google/adk-python/blob/b33b43e5b5388b9454c71f440eb885901075f43a/src/google/adk/plugins/plugin_manager.py), blob `bbb7bdd40b95b27b0d79f0ac252ae2221b94748c`.

A stateless pure contribution may need no lifecycle hook. A scoped in-process value may need a local disposer. A process, socket, remote operation or durable state attachment has a different custodian and evidence requirement. Combining every example into one required activate/start/ready/drain/stop/dispose/retire interface would violate interface segregation and misrepresent cleanup. An ownership record is useful only if it records real acquired contributions/resources and their actual custodian; bookkeeping does not confer custody or independently prove release.

The current reports correctly separate ordinary cleanup continuation, strict retirement, partial initialization and physical closure. The Eliza initial-error/cleanup-error qualification is retained. OTel's component contract really uses stronger language for aborting background work than for flushing buffers; copying all of it as a universally enforced guarantee would be inaccurate. [Pinned OTel component contract](https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/component/component.go), `Component`.

**Smallest correction:** keep “where applicable to the selected profile” beside future cleanup/conformance suggestions. EF may eventually own a demonstrated neutral protocol or test kit; “EF may retain vocabulary” in a research paragraph is not admission of a package, schema or second state machine. ADR-0011 already partitions applicability and explicitly excludes ordinary static composition from the production-host floor. Preserve that distinction without diluting the obligations of a profile that is actually admitted.

## 6. Most proposed falsifiers need a named promise before they can judge fit

**Reviewed sections:** all smallest-falsifier paragraphs; synthesis “Decision and experiment discipline”; DP-01/02 falsifiers.

The current synthesis already says that the proposals do not choose product promises. Keep that wording. There are three different kinds of question in the cases:

| Question type | Example in the reports | What a contrary result can change |
| --- | --- | --- |
| Upstream semantic/source probe | Pydantic singleton requirements; PF4J bulk versus manual start; ADK callback visits | The scoped interpretation of upstream behavior |
| Conformance to a selected product promise | Required bundle member absent; stale disposer removes a successor; cleanup claimed complete while owned work remains | Whether an implementation satisfies that named contract |
| Capacity/usability qualification | Bounded graph, active-state/resource envelope, author comprehension | A stated operating envelope or a specific authoring claim |

A source probe is not by itself a product requirement, and a tiny semantic fixture cannot establish capacity. Several experiments largely demonstrate behavior already visible in source or unrun upstream tests; repeating them has value only if the result could change a real transfer, implementation or compatibility choice. They are retained investigative ideas, not the next backlog in disguise.

In particular:

- A failed reload losing the predecessor is not a failure of our downtime-permitted baseline unless the applicable operation promised preservation at that stage. Future generation-publication profiles remain subject to their existing accepted constraints; do not silently generalize them to every static source import.
- A blocked shared pipeline does not falsify an undeclared independent-progress promise. If an actual product operation needs that promise, the existing execution/scheduling owner must qualify it. The OTel tradeoff does not require one Worker or process per module.
- Missing optional reorder targets can deliberately no-op. Required dependency failure is a different contract. Drupal's permissiveness does not prove either that we need permissive binding or that Drupal is defective.
- Unbuffered chunks already delivered cannot be retracted by a final gate. A pre-release invariant can justify buffering at that seam; it does not create blanket buffering for all streams.
- A plugin-hidden-from-the-model test cannot claim to test revocation unless execution authority was actually supposed to be revoked. Inert discovery is different: our accepted metadata-discovery guardrail already prohibits executable evaluation, so that negative case does have an existing basis.

**Smallest correction:** add one sentence to the experiment discipline: “Identify whether a proposal tests upstream interpretation, an already selected product guarantee or a capacity claim; run it only when a result can change that named conclusion.” No new test, installed framework or production change is needed now.

## 7. Thousands of modules is several scale problems, and authoring is one of them

**Reviewed sections:** synthesis scale table; each case's scale paragraph; prior E2E qualification limits in the brief.

**Finding: the scale separation is accurate; retain it prominently.** Catalog entries, declaration-graph vertices, selected providers, live instances, per-tenant state, model-visible tools, physical execution resources and independently maintained releases must not be counted as one population. A thousand artifacts can select ten implementations; one implementation can own many invocations; many instances can share one engine; hiding descriptions can reduce tokens without reducing loaded code or improving authorization.

The existing N1000 construction and 1,024 scoped live receivers remain useful bounded achievements. They do not establish a third-party plugin fleet, hostile containment, aggregate throughput, resource churn, every graph shape or every independent version combination. Conversely, lack of a benchmark in the newly inspected frameworks is not proof that they cannot scale. The reports correctly avoid that conclusion. Source-visible loops and pairwise matching identify work to investigate, not measured practical limits.

The synthesis's authoring/diagnosis row matters as much as throughput for the owner's stated vision. At large module counts, authors must be able to add a declaration locally, see why a binding failed and understand the effective contribution without editing a second central authority. That is already aligned with ADR-0014's module-local inert authority and generated read-only inventory. “Explain the final customized plan” should reuse bounded GM diagnostics and product-facing explanations where needed, rather than introduce a generic provenance control plane, global ID registry or complete trace of every value.

**Smallest correction:** keep the table as dimensions/questions and avoid turning it into a requirement to run every dimension at all sizes or every package-version combination. When a future claim needs an envelope, name the selected subset and graph shape, sharing, deployment and load assumptions. Existing evidence should be reused for unchanged inputs and claims. No new universal scale benchmark is justified by this publication.

## 8. DDD, SOLID and DRY support these boundaries without inventing a platform

**Reviewed sections:** synthesis ownership discussion; DP-01-H3; SF-DRUPAL/OTel analogies.

The revised synthesis correctly says that a telemetry signal, callback phase or plugin package is not automatically a bounded context. Keep that explicit correction. Different dataflow roles can justify separate interfaces without separate aggregates, repositories, packages or deployment units. OTel connectors demonstrate a correction to an actual component-role boundary; they do not demonstrate that each transformation needs a new domain context. Drupal plugin types demonstrate consumer-defined contracts; they do not make a manager per type appropriate here.

Clean Architecture means the consumer's policy owns its narrow port and framework concerns stay in adapters. SOLID means substitutable postconditions, explicit dependencies and only relevant methods. DRY means one authority for the same knowledge; it does not mean merging unrelated hooks into one reusable runtime. The library-first instruction remains relevant when a real concern is expected to serve several products, but the shared concern still needs a concrete invariant, owner and first useful delivery. Research showing similar syntax in 14 frameworks is not that proof.

**Smallest correction:** none beyond preserving the current qualifications. Do not add a DDD section that assigns new bounded contexts to these case-study categories. Do not treat selecting a shared technical implementation as a transfer of product authority, or assume that shared ownership requires a new repository.

## Decision status and publication recommendation

The highest-value retained ideas are precise seam semantics, separation of selection from invocation, declared sharing/lifetime, ownership-aware cleanup, applicability-aware readiness and failure policy, and clear distinction between model context, discovery and execution grants. Each has an existing owner or a conditional place in a future concrete slice. The evidence does not require framework adoption or a generic Host.

No unresolved **new** owner choice is necessary to finish the authorized research/navigation publication. The future first product capability, supported trust/availability profile, public SPI and production qualification remain in their existing owning records. This review does not resolve them or create a new approval gate. There is therefore no honest reason to invent competing platform options, scores or whole-system LOC estimates. A future material implementation choice must use the requested confidence/reliability/complexity ratings and separate scoped production/integration/test estimates when its actual boundary is known.

Recommended disposition: retain all case information and criticism, make the small Pydantic summary qualification, preserve the current non-taxonomy/ownership/profile disclaimers in shorter summaries, and optionally add the probe-versus-conformance sentence. Continue the already authorized documentation workflow. There are **zero new production, integration or test lines** in this critique, and no runtime qualification is claimed.
