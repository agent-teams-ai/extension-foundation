# Research review dispositions — 2026-11-05

Status: retained research and publication history, not architecture adoption.
Owner clarification: findings are reusable reference information; decisions are
discussed with the owner and recorded in their existing owning records. Implement
only confirmed scope. This follow-up adds no production, integration or test code.

## Review coverage

Two specialist researchers and four independent critics used GPT-6.1 Sol at
xhigh, in successive waves within the available concurrency. Root researched
the two adjacent data-plane cases and assembled the synthesis. All reviewers
received the full task brief, owner vision, current Engineering Quality Standard,
existing authority boundaries and limitations of the previous E2E evidence.

| Retained review | Concrete scope |
| --- | --- |
| research-authority-audit.md | Prior exact Git delta, retained E2E archive/member digests, copied source identity, accepted authority and misleading current navigation |
| data-plane-critique.md | Independent exact-source criticism of OTel/APISIX, lifecycle contract strength, reload behavior, trust and applicability |
| agent-frameworks-critique.md | Independent agent-framework mechanism checks, cleanup error ownership, cancellation, retry scope and unrun hypotheses |
| modularity-fit-critique.md | Fit to GM/EF/product/execution ownership, no-fork authoring, static profiles, DDD and scale without a generic platform |
| framework-evidence-critique.md | Independent exact-source checks of disputed paths, release/tag relationships, counterevidence and ledger fidelity |
| research-reuse-critique.md | Source navigation, structural ledgers, evidence/decision separation, author experience and fair interpretation of intentional tradeoffs |

The first three reports were produced by one authority/mechanism critic across
successive tasks. Report count is not independent reviewer count. The final
publication-navigation-check.md is an assembly check by the reuse critic, not
another independent research vote.

## Findings and final disposition

| Finding | Correction or retained boundary |
| --- | --- |
| Historical research looked like current design authority | Maintained navigation and dated review notes distinguish research recommendations, owner-confirmed restart baseline and accepted ADRs. Accepted ADR bodies remain unchanged. |
| Catalog wording could imply SQLite canonical state or Fully Local outside V1 | OD-002 now scopes catalog/offline qualification and links current Orchestrator ADR-0114/0115. The existing EF ADR-0003 catalog history and optional SQLite FTS5 projection remain intact. |
| First result was described as nonempty | Synthesis now says first non-None for ADK/Pluggy; empty values can be valid interception results. |
| Pydantic requirement summary could lose its singleton caveat | Main sentence distinguishes declared type presence from ordering and scopes inspected validation to the multi-entry path. Singleton behavior remains a source observation plus an unrun public-path question. |
| PF4J manual-start protection could be generalized to bulk start | Preserve both exact entrypoint paths and their counterevidence. No reproduced defect or blanket dependency-failure claim. |
| ADK ordinary observer errors could imply every cancellation is swallowed | Describe ordinary Exception continuation separately from cancellation and ownership-aware close. |
| Microsoft bundle/stream language could overstate guarantees | Required category/member closure is not an arbitrary transaction. Lazy stream creation, consumption and final-result validation remain separate. |
| Mastra recovery cap could imply a total global budget | Name three retries on the inspected path, separately from the initial attempt and aggregate effects. Retain the repaired history. |
| Eliza catch comment could imply unconditional original-error preservation | Actual awaited teardown may throw AggregateError; the original registration error is rethrown only if teardown succeeds. Record correction provenance in report and ledger. |
| OTel startup and shutdown descriptions were too strong | Startup order is not background readiness. Preserve source MUST/SHOULD strength. Partial reload is gated with Alpha/Beta maturity; fallback is an attempted full reload, not guaranteed restoration. |
| Signals or callback phases could become invented DDD contexts | Keep domain contexts tied to actual language/invariants; technical roles alone do not define bounded contexts. |
| Trusted competitor extension power could be mistaken for ordinary third-party authority | Preserve Letta/APISIX deliberate trust profiles and successful owner/generation guards. Visibility, DI and classloading mechanisms alone do not prove containment. |
| Contract examples could become an exhaustive universal API | Explicitly mark overlapping seam examples, not a public taxonomy. A real no-fork customization and combination of independent extensions is needed to demonstrate useful fit. |
| Cleanup conformance could impose Host duties on static modules | Scope physical-resource evidence to a profile that actually claims retirement. No new lifecycle interface, identity registry or process-per-module rule. |
| Scale dimensions/falsifiers could become an automatic test backlog | Distinguish upstream semantic probes, conformance to an agreed promise and capacity qualification. Run only a probe that can change a named conclusion. Reuse unchanged evidence. |
| Specialist reference definitions were duplicated | Remove identical repeated definitions; retain the original pre-final report. Final 72 labels map once to 72 source records. |
| Data-plane provenance needed a clearer recovery route | Retain symbols, bounded supports, per-source dates, exact blob/commit URLs and release metadata. Link the existing feature-gate source at its maturity claim. |
| Agent source IDs were not directly navigable in prose | Governed case document links each ID to its exact primary URL and adds a source appendix. All three companion ledgers have direct repository links. |

No high/medium source-fidelity blocker or new material owner decision remains
after these bounded corrections. Agreement among critics is not design approval,
proof of runtime behavior or evidence of production reliability.

## Retained uncertainty and conditional experiments

No investigated framework was installed or executed; no inspected upstream test
or proposed falsifier was run in this research follow-up. Default/development
source, release tags and published package bytes remain distinct. The actual
independently maintained plugin fleet, useful public product seam, containment
profile and production availability/retirement envelope are not qualified here.

The existing packed-consumer E2E evidence remains unchanged. Its isolated package
and public-export assertions are useful within their recorded scope; they do
not establish a production plugin Host, artifact custody, controlled restart or
thousand-plugin fleet. The preceding authority audit verified retained archive
hashes and copied inputs rather than rerunning unchanged experiments.

When a concrete technical/product choice is actually ready, use the owner's
requested confidence, reliability and complexity scores out of ten, separate
production/integration/test LOC ranges, reuse assumptions, uncertainty and a
result that would change the recommendation. No unsupported whole-platform LOC
estimate or framework ranking was manufactured for this documentation task.

## Authoring workflow incident and publication isolation

The original EF checkout contained a tool-owned orphan temporary artifact before
this follow-up. The first new document was created successfully. During the
second create transaction, root made ordinary index/AGENTS edits before its final
stable verification finished; the transaction reported recovery-required at
document.transaction.final-verification. Writes to that checkout stopped.

The required doctor identified a recoverable transaction. The normal recover
command then refused with document.transaction.orphan-temporary and
"Automatic recovery is unsafe: orphan-temporary". No transaction evidence was
manually changed or deleted, and recovery success is not claimed. Both diagnostic
logs and the failed authoring log are retained as tooling history.

Publication continued in a separate checkout of exact EF base
9f5ba60232c19e78022b40dddea71ab3aea1cdea, using the same frozen lockfile and cached
dependencies. Each normal Docs Protocol create preview/apply completed
sequentially before ordinary edits and navigation updates. Final documentation
checks are attributed to this publication checkout and resulting tree, not to
the original failed transaction. This is an authoring incident, not evidence
about a plugin runtime, and it does not relax the normal writer or validation.

The bundle retains the full Engineering Quality Standard read at source blob
9d4fc54d99249077bf6887be35a59ace1d5547bd and its canonical URL in the manifest.
That snapshot is historical task context, not a competing maintained policy.
The existing legacy Foundation/embedded compiler limitation remains explicitly
outside this documentation-only delta; no dependency or gate was repinned.

Final bounded navigation review passed: all source-ID targets and local routes
resolve. The reserved agent/specialist installation wording is now narrowed to
investigated frameworks. Documentation preflight reports a complete 84-document
catalog and zero Markdown/spelling issues across 90 files. Thirty-nine reviewed
technology names, source-ID fragments and technical terms were added to the
existing spelling dictionary; no check was disabled. Publication doctor reports
idle. Its tool-owned temporary artifact is preserved and excluded from Git.

## First full publication gate and bounded next verification

The first full consumer gate passed catalog, Markdown and spelling checks, then
reported seven of eight contract tests passed. The first fixture ADR apply hit
the unchanged 120,000 ms child-process timeout. No cause is established. The
original log and staged-tree receipt are retained; the test copies the whole
local docs directory, including a preserved untracked tool temporary artifact,
so the Git tree alone is not the complete original runtime input identity.
The separate local-input receipt records that artifact's size and digest.

The authority critic reviewed this failure in publication-gate-failure-critique.md.
The bounded next step is one full verification of the final publication Git tree
in a clean checkout, with the frozen offline install and unchanged command,
tests, timeout and tool pins. Both authoring checkouts and all tool evidence
remain untouched. This verifies the intended published input; it is not an
identical-input reproduction and cannot explain or erase the original timeout.
No third run or weaker gate is proposed. Its actual result belongs to the final
publication receipt rather than being predicted in this retained report.

### Subsequent observation and draft verification scope

The clean-tree command's session became unavailable. Its retained log records
successful documentation/quality checks and four contract passes, followed by no
terminal summary or exit code. Its full result is indeterminate. The read-only
process observation and exact inputs/log hashes are separately retained; neither
an assertion failure nor an environmental cause is established for this run.
The original timeout remains a distinct failed command. No third local rerun
is attempted and no timeout, test, dependency or gate is weakened.

The authority critic's dated addendum permits the explicitly authorized
research-only draft push with local full qualification disclosed as unverified.
The next result must come from the already configured hosted full gate at the
actual final pushed head/tree. A draft push is not a successful qualification,
merge, release or adoption. The PR receipt records that later observed result.
