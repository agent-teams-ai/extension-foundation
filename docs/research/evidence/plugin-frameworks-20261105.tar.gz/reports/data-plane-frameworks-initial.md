# Adjacent data-plane extension mechanisms — 2026-11-05

Author: root researcher. Status: retained research, not adoption.
Scope: read-only primary docs, exact released source, and selected unrun upstream
tests. No external runtime was executed. No package was installed. Confidence
below concerns source support, not reliability or performance of our future system.

## Source identity and release relationship

| Case | Technology and actual unit | Inspected release source | Moving head observed, not substituted |
| --- | --- | --- | --- |
| DP-01 OpenTelemetry Collector | Go; receiver, processor, exporter, connector, extension; compiled distribution plus configured pipeline instances | v0.164.0 / stable module set v1.70.0 at f532e15ef29b6ed7fefad2b23a0fefd27120ef9b; release published 2026-10-26 | main 79bf8a49d2e4556e3aa72ac36e3b1e460a176ac1 on 2026-11-05 |
| DP-02 Apache APISIX | Lua/OpenResty; named plugins whose phase handlers act on configured routes/services/consumers; separate external-runner/Wasm options | 3.19.0 at 473043623c161966f3f6ef4e8f12d2d8667a12d2; release published 2026-09-28 | master 7f7b7a0ba8adadd2e9a937ae8839ad8fa28639e7 on 2026-11-05 |

Sources were retrieved on 2026-11-05 UTC. The companion JSON ledger retains file
blob IDs and immutable source URLs. Public documentation is mutable unless its
repository version is also pinned. Neither inspected release is selected as a
dependency of Agent Teams.

## DP-01: OpenTelemetry Collector

**Question.** What can a typed, large component ecosystem teach us about
composition, shared instances, startup/drain order and bounded reload?

### Documented contract and inspected implementation

1. **Distinct roles and instance identity.** Collector separates receivers,
   processors, exporters, connectors and extensions. A configuration key has a
   component type and optional instance name. The configuration graph is a data
   path, not a universal container. Its builder can assemble a distribution from
   upstream and custom Go modules without forking the Collector source.
   [Architecture][ot-architecture], [Builder guide][ot-builder-guide],
   [pinned builder README][ot-builder].

2. **State sharing is explicit and asymmetric.** Graph creation reuses a
   receiver/exporter node for the same signal and component ID; processor nodes
   incorporate pipeline identity. Thus the same processor configuration used in
   two pipelines creates distinct processor instances, while a shared receiver
   fans out. This is more precise than saying all components are singletons or
   all pipelines are isolated. The factory may itself retain additional shared
   state; this inspection does not prove absence of globals in every component.
   [Graph createReceiver/createProcessor/createExporter][ot-graph],
   [Architecture][ot-architecture].

3. **Readiness and shutdown follow data dependencies.** StartAll traverses in
   reverse topological order and explicitly places receivers after non-receivers
   so shared eager receivers do not send into an unstarted downstream path.
   ShutdownAll uses forward order, retains downstream consumers while upstream
   drains, and accumulates shutdown errors. This supplies ordering, not proof
   that a particular component fulfills its shutdown contract.
   [Graph StartAll/ShutdownAll][ot-graph].

4. **The lifecycle contract names cleanup obligations.** Component.Shutdown must
   tolerate no prior Start and repeated shutdown, stop accepting data, cancel
   background work, and flush buffers before returning. A later lifecycle uses a
   new component. Factory.CreateDefaultConfig must support repeated creation
   without disruptive side effects. These are explicit component obligations;
   a function signature cannot enforce honest completion.
   [Component interface][ot-component].

5. **Dependency ordering and readiness are distinct.** Extensions declare
   dependencies through an optional capability; computeOrder rejects missing
   dependencies and cycles. Start uses that order; shutdown reverses it.
   PipelineWatcher readiness notifications are separate from extension startup.
   This is not evidence that an arbitrary TS callback can safely discover or
   rebind dependencies at runtime.
   [Extension graph][ot-ext-graph], [Extensions][ot-extensions],
   [Service startup/shutdown][ot-service].

6. **A synchronous fan-out shares a blockage boundary.** The architecture
   documentation explicitly warns that a blocking processor can stall its shared
   receiver's other pipelines. The inspected traces fan-out invokes consumers
   synchronously; it separates mutable/readonly consumers and clones only when
   necessary. This is a deliberate throughput/ownership tradeoff, not a newly
   discovered Collector defect. It explains why module count, instance count,
   pipeline count and independently isolated work are different quantities.
   [Architecture][ot-architecture], [Traces fan-out][ot-fanout].

7. **Reload is profile-specific.** Released source includes partial receiver
   reload, gated by service.partialReload (Alpha) and
   service.partialReloadReceivers (Beta). It leaves other graph component kinds
   untouched, shuts down changed receivers, then rebuilds/starts them. The
   collector falls back to a full service reload if an attempted partial reload
   fails, explicitly because the graph may be partially modified. This is
   neither a universal hot-swap guarantee nor old-generation-keeps-serving on
   every failure. Do not describe this release as static-only either.
   [Service gate][ot-service], [UpdateReceivers][ot-graph],
   [reloadConfiguration/tryPartialReceiverReload][ot-collector].

### Inspected unrun tests and historical correction

TestSharedReceiverStartOrder constructs an eager shared receiver and exporters
that reject use before startup; it checks successful startup across ten ID/order
variations. The same pinned test file explicitly asserts removal/rebuild shutdown,
build and start failure paths for UpdateReceivers. These are inspected upstream
assertions, **not test executions by this research** and not our E2E coverage.
[Graph tests][ot-tests].

The official connector tutorial describes the older practice in which processors
directly exported newly generated signals, crossing their intended role. It
records deprecation/replacement by connectors. This is an acknowledged historical
architecture correction, not a claim that the current connector implementation
still has the old defect. [Connector tutorial][ot-connectors].

### Conditional transfer and failure of the analogy

- **Unadopted hypothesis DP-01-H1:** product-owned call/data flow should make
  instance sharing, mutable ownership and downstream readiness explicit.
  GM already owns neutral composition; copy no new graph implementation into EF.
  The Collector's telemetry fan-out is not proof of desired agent tool scheduling.
- **Unadopted hypothesis DP-01-H2:** qualify controlled restart against an actual
  ingress-to-downstream dependency chain, with an eager ingress and failure
  during cleanup. Product/execution owners retain physical custody. The
  component contract may inform test questions, not certify our restart.
- **Unadopted hypothesis DP-01-H3:** use a dedicated boundary for an actual
  cross-domain transformation rather than let a processor reach around its
  contract. DDD does not imply making every transform a package or a module.

**Minimal possible falsifiers, not scheduled/executed:** a blocked downstream
callback delays an unrelated product request despite a claimed isolation
boundary; an eager producer runs before its real consumer is ready; a shutdown
error is reported as successful retirement; a component sharing profile makes an
otherwise local mutation visible to another tenant. Each scenario needs the
real proposed product contract before a useful test can be written. No generic
Collector reimplementation or benchmark is warranted by this evidence.

## DP-02: Apache APISIX

**Question.** What do phase-oriented customization, configuration precedence and
hot loading really promise, especially when transferred to third-party plugins?

### Documented contract and inspected implementation

1. **A plugin has a named schema and phase handlers.** The development guide
   describes unique plugin names, explicit priorities and JSON-schema validation;
   higher priority runs first within a phase. Lifecycle phases have protocol
   meaning. A plugin priority cannot turn arbitrary before/after relations into
   a validated dependency graph. [Plugin development][ap-dev].

2. **Ordering and configuration precedence are separate policies.** Global-rule
   and local instances can both execute. Among local configurations of the same
   plugin, the documented precedence is Consumer, Consumer Group, Route,
   Plugin Config, Service; this selects one local configuration. A per-instance
   _meta.priority overrides execution order with documented phase exceptions.
   The terminology document makes these policies discoverable rather than
   leaving authors to infer object merging. [Plugin terminology][ap-docs].

3. **Loading is executable.** load_plugin calls require before checking exported
   priority, version and schema; it then calls init where applicable. The same
   source explicitly avoids running stream-plugin initialization in the HTTP
   subsystem used for Admin schema validation. This is a concrete protective
   distinction, but require itself is not inert metadata discovery.
   [load_plugin][ap-plugin].

4. **The observed reload is not a prepare-then-publish generation protocol.**
   For the inspected Lua path, load iterates old entries through unload_plugin,
   which calls optional destroy and clears package.loaded, clears plugin tables,
   then loads new modules. A require failure is logged and that plugin is not
   inserted. That local path does not preserve the old initialized plugin until
   the replacement is validated. We did not execute reload, inspect every caller,
   or establish outage/effect behavior for the complete distributed deployment.
   The docs' hot-loading support is real; its guarantee is narrower than
   universal seamless replacement. [Plugin loader][ap-plugin], [Hot reload docs][ap-docs].

5. **Trust is an explicit deployment assumption.** The threat model treats the
   administrator, supplied Lua and external plugin runner as operator-trusted.
   Lua handlers run in a privileged worker context; an external process is not
   automatically a hostile-user sandbox. This is an intentional model suitable
   for operator configuration, not a promise of arbitrary marketplace-code
   containment. [Pinned threat model][ap-threat].

6. **Deep no-fork customization can expose unstable surfaces.** The development
   guide offers lua_module_hook to override a method and extra loading paths.
   Such escape hatches are useful for controlled deployments. Inference: if our
   ordinary plugin authors depend on private method replacement, upgrades and
   authorization invariants become harder to preserve. This does not establish
   that every APISIX use of the hook is unsafe or that its supported plugins
   depend on monkey patching. [Plugin development][ap-dev].

### Benefits, costs and transfer limits

- Explicit phases, schemas, selected local configuration and inspectable
  priorities give users concrete customization handles. The cost is needing to
  understand both scope precedence and phase execution. Arbitrary numbers alone
  do not explain semantic dependencies or authorization.
- The reload path is simple for trusted Lua modules and supports rapid changes.
  Its teardown-before-load behavior cannot be cited as evidence that a failing
  candidate always leaves old service untouched. NGINX worker replacement and
  this Lua package reload are different mechanisms in the same broader stack.
- The API gateway's trusted operator and request-phase model is narrower than
  our intended large third-party ecosystem. No claim about thousand-plugin
  capacity, hostile isolation, or superiority is supported by these files.

**Unadopted hypothesis DP-02-H1:** a product extension point should say whether it
adds contributions, selects one provider, wraps an operation or transforms data.
Its conflict policy should be visible to the author. GM owns neutral binding
semantics; product owners define meaning; EF does not acquire a global priority
registry.

**Unadopted hypothesis DP-02-H2:** ordinary customization should use stable owned
ports/configuration and explain the effective selection, avoiding dependency on
private method patching. The decision about a specific supported seam still
belongs to that product and owner.

**Minimal possible falsifiers, not executed:** permuting equally eligible
providers changes security-sensitive behavior without a declared policy; an
ordinary plugin can bypass the authorization owner through a wrapper; a failed
candidate load destroys an otherwise promised active implementation; a plugin
listed as disabled still runs code during discovery. These are questions for
a concrete proposed profile, not facts about every APISIX configuration.

## Cross-case caution

The word “plugin” describes different boundaries even in these two systems.
Collector compile-time distribution membership, configured component instances,
APISIX phase handlers and external runner placement are not interchangeable.
The transferable unit is a precise contract with preconditions and failure
semantics. Research can narrow future choices; it does not choose the mechanism.

No production/integration/test LOC is committed by these hypotheses. A meaningful
estimate must name a real product seam, owner, required observable behavior and
deployment profile. Do not manufacture a framework implementation estimate from
a read-only source comparison.

[ot-architecture]: https://opentelemetry.io/docs/collector/architecture/
[ot-builder-guide]: https://opentelemetry.io/docs/collector/extend/ocb/
[ot-builder]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/cmd/builder/README.md
[ot-graph]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/internal/graph/graph.go
[ot-component]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/component/component.go
[ot-ext-graph]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/extensions/graph.go
[ot-extensions]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/extensions/extensions.go
[ot-service]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/service.go
[ot-fanout]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/internal/fanoutconsumer/traces.go
[ot-collector]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/otelcol/collector.go
[ot-tests]: https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/internal/graph/graph_test.go
[ot-connectors]: https://opentelemetry.io/docs/collector/extend/custom-component/connector/
[ap-dev]: https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/plugin-develop.md
[ap-docs]: https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/terminology/plugin.md
[ap-plugin]: https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/apisix/plugin.lua
[ap-threat]: https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/security-threat-model.md

