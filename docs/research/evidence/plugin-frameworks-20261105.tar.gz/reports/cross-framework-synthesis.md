# Cross-framework synthesis and research authority

Research cut: **2026-11-05 UTC**. This follow-up preserves information and critique.
It adopts no plugin framework, runtime, public SPI, language boundary or new
product policy. The owner explicitly confirmed that research is reference
material, while design decisions are discussed and recorded separately.

## What was checked and what was changed

The previous packed-consumer continuation was independently audited at
EF9f5ba60, including its exact Git delta, all three archive/member ledgers, all
433 new fixture/consumer/driver TypeScript lines, and the ten copied Orchestrator
source/manifest/configuration files. No new production plugin runtime or accepted
ADR body was found in that continuation. The wider PR also contains existing
Docs Protocol research-type configuration and tests, so it must not be described
as prose-only. See the [packed E2E record](packed-extension-consumer-e2e-2026-11-05.md)
and the retained authority audit in this follow-up's evidence bundle.

This follow-up adds source-backed cases, source ledgers, independent criticisms,
and navigation/authority clarification. Existing accepted ADRs remain unchanged.
The current authoring instructions explicitly separate facts, transfer proposals
and owner-approved decisions. Historical pins and failed experiments remain
available; no later correction rewrites what was actually observed.

| Information | Meaning | Does not mean |
| --- | --- | --- |
| Documented contract | The named upstream documentation states behavior for its version/profile | We executed or qualified it |
| Inspected implementation | The exact source path/symbol implements the described mechanism | Every entrypoint, package artifact or deployment behaves identically |
| Inspected unrun test | An upstream test states an expectation that helps interpret source | Our test passed |
| Historical report/fix | A dated incident/change with separately recorded resolution | The same defect exists in the current pin |
| Inference / transfer hypothesis | A reasoned, conditional idea mapped to an existing owner | The product has selected it |
| Executed evidence | A specific retained run with exact inputs, environment, assertions and receipts | Broader profiles are qualified |
| Owner-confirmed direction / accepted ADR | The recorded owning decision governs its exact scope | Research or another project's implementation can silently amend it |

Research document status remains the existing `active` or `archived`; neither
is an approval status. This adds no competing acceptance registry or process.

## Confirmed direction and ownership

Static composition with controlled restart remains the confirmed baseline.
Downtime can be part of that profile; overlapping generations and seamless
replacement require a separately justified capability. An optional Temporal
adapter can orchestrate the same owned operation where the infrastructure is
already qualified. Neither more competitor evidence nor an attractive reload
API changes that agreement.

| Responsibility | Existing owner | Consequence for this research |
| --- | --- | --- |
| Neutral module/capability/implementation/slot identities, bindings, graph and immutable plan | Get Modular | No second resolver, DI container or composition compiler in EF |
| Neutral artifact/trust/distribution/protocol/conformance concerns | Extension Foundation | Evidence and a real shared neutral boundary; no implicit operational Host |
| Concrete extension point, allowed customization, grants, readiness, profile, canonical state | Consuming product | Narrow contracts and actual domain invariants stay owned there |
| Process/worker/resource custody and retirement evidence | Existing execution owner | A callback result, timeout or registry removal cannot replace its observation |

These boundaries are already grounded in
[ADR-0015](../decisions/0015-authorize-get-modular-semantic-extraction.md),
[ADR-0014](../decisions/0014-product-local-module-authoring-composition-and-generation-guardrails.md)
and the scoped production floor in
[ADR-0011](../decisions/0011-extension-admission-custody-and-retirement-closure.md).
The open Host/SPI/state choices remain in
[OD-003](../open-decisions/OD-003-module-runtime-and-public-spi-choices.md).
A library can be independently useful without creating another repository or
operational authority. This comparison does not select such a library.

Clean Architecture keeps framework/container access outside the product's
domain/application boundary, behind its own ports. SOLID requires a concrete
substitution contract and independently checked behavior. DRY preserves one
owner per invariant; it does not merge unrelated contexts into a generic service
bag. DDD keeps real bounded-context language and invariants with their owner;
a telemetry signal, callback phase or plugin package is not automatically a
bounded context. Pluggability makes selected changes possible through a declared
seam without granting extensions authority over product enforcement.

### Current authority clarifications

- The October overlapping-worker proposal is now explicitly labeled optional
  and unadopted where maintained navigation previously called it the next target.
- The historical research heading “Decision in one paragraph” now identifies a
  conditional research recommendation. Original case evidence remains intact.
- The October review retains original adoption pins and PR analysis, while a
  dated note routes current Orchestrator module adoption to accepted ADR-0117.
- EF OD-002 now limits itself to catalog security/offline parameters. Orchestrator
  ADR-0114 selects native PostgreSQL local/hosted authority and ADR-0115 requires
  Fully Local V1. EF ADR-0003's historical catalog rollout and possible SQLite FTS5
  search projection remain unchanged; they are not product canonical storage.
  See [OD-002](../open-decisions/OD-002-catalog-security-and-offline-operational-parameters.md)
  and the [current authority map](plugin-industry-and-scale-review-2026-11-05.md#research-coverage-and-current-authority).

These are scope and navigation repairs under existing decisions, not a new
storage choice, framework adoption or implicit permission to implement an open
product feature.

## Coverage added in this follow-up

The new comparison includes **14 cases in three lanes**. Prior coverage of
OpenClaw, OpenCode, Claude Code, Dify, IDE platforms, OSGi, Backstage, Vault,
JupyterLab, NGINX/Envoy, Erlang and other systems remains in the
[maintained reference](plugin-system-research-reference.md). Repeating a
framework name is not counted as a new investigation.

| Case | Actual extension unit inspected | Useful mechanism / boundary to examine |
| --- | --- | --- |
| Google ADK Python | Runner-wide callback plugin | First-result interception versus all-observer notification; owned/borrowed cleanup |
| Pydantic AI | Capability, toolset, per-run binding | Presence, order, dispatch provenance and run state are different contracts |
| Microsoft Agent Framework Python | Agent/chat/function middleware and bundle | Required contribution closure; streamed updates versus final result gates |
| Mastra | Phase processor and ID-keyed runner state | Explicit phase/state identity and bounded recovery cost |
| ElizaOS development source | Contribution bundle and owned runtime registrations | Partial setup/teardown bookkeeping; tolerant dependency resolution versus required closure |
| Current Letta Code | Fully trusted local harness mod | Deep customization, exact-owner cleanup and stale activation guards |
| Pluggy | Hookspec/implementation/caller | Result cardinality, wrappers and validated registration; historic replay caveats |
| PF4J | Artifact descriptor, lifecycle, typed extension | Descriptor closure versus actual dependency startup; class identity |
| Fastify/Avvio | Encapsulated registration context and boot tree | Scope/export semantics; observed boot timeout versus cancellation |
| Hapi | Registration realm and named extension phase | Phase order, dependencies and partial executable registration |
| NestJS | DI module/provider and application context | Provider selection, instance lifetime and cleanup-result semantics |
| Drupal | Installed module, hook, plugin type/definition/instance | Deep alterations with explicit discovery/install/data boundaries |
| OpenTelemetry Collector | Compiled component and configured pipeline instance | Sharing/backpressure, startup/drain order and bounded receiver reload |
| Apache APISIX | Named phase handler plus scoped configuration | Priority/precedence and trusted Lua loading semantics |

The first six cases are documented in
[Agent Framework Extension Evidence](agent-framework-extension-evidence-2026-11-05.md);
the next six in
[Specialist Plugin Framework Evidence](specialist-plugin-framework-evidence-2026-11-05.md).
The two data-plane cases appear below with exact source links. These categories
are a comparison aid, not a new product plugin taxonomy or public API.

Every case retains retrieval date, technology, actual extension unit, full source
commit, inspected symbols, primary URLs, release/tag relationship, limitations,
counterevidence, conditional applicability and smallest proposed falsifier.
Agent-framework default-branch observations are explicitly different from
released bytes. Eliza's inspected develop source has no established published-byte
identity in this study. Letta's old server repository explicitly directs current
development to Letta Code; the case follows that successor rather than inferring
a product deficiency from the retired tree.

## Conditional lessons across independently inspected systems

### 1. Define the useful behavior at each seam

A single-provider replacement, list of contributions, around-call wrapper,
first-result hook, notification and streaming transformation have different
cardinality, order, error and mutation semantics. Pluggy, ADK, Pydantic, Microsoft
and Drupal provide concrete examples in the two case studies. Calling everything
a universal plugin interface would conceal these differences.

**Unadopted transfer:** for a real product seam, state what may be added/replaced,
how ties are handled, what can short circuit and which result/postcondition is
required. Reuse existing GM declarations where they already express selection.
A hook's first non-None result (ADK/Pluggy) is not proof that one provider was eligible.
These are overlapping examples of seam behavior, not an exhaustive public
taxonomy or six new base interfaces.

### 2. Separate resolution, executable setup and usable readiness

PF4J makes descriptor resolution distinct from plugin startup; Fastify and Hapi
have executable boot/registration; OTel has startup ordering with separate
readiness notifications. Those mechanisms solve different portions of admission.
A pure validation pass can reject a declaration before mutation; arbitrary user
setup can acquire a handle and then fail.

**Unadopted transfer:** a product's selected candidate should have a precise
failure result and owned partial cleanup. Do not infer transactional rollback
from a rejected setup promise. Do not require old availability to survive an
interrupted controlled restart unless that stronger promise is actually selected.
Existing GM validation and execution custody already have owners.

### 3. Treat sharing and lifecycle identity as part of the contract

Mastra's per-run ID-keyed state, Pydantic's optional fresh run binding, ADK's
borrowed plugins, OTel's shared receivers and Letta's exact owner IDs expose
different identities. A package name, configuration ID, implementation object,
run state and physical resource are not interchangeable.

**Unadopted transfer:** explain the intended lifetime and sharing at a concrete
port. A stale disposer should not remove a successor contribution where
replacement is supported; a borrower should not close the resource owner.
Where the selected profile claims resource retirement, conformance must inspect
the actual owned resource, without inventing a global identity registry or
demanding a separate process for each module.

### 4. Preserve the chosen failure policy

All-observer error notifications may reasonably continue after one observer
fails. A required provider may need to reject the operation. Nest's best-effort
destroy continuation, Eliza's strict/best-effort retirement distinction and
Mastra's scoped retry cap are deliberate examples. The report retains both the
benefit and the limit.

**Unadopted transfer:** a product author should be able to tell whether failure
blocks work, degrades an optional feature, creates tracked cleanup debt, or ends
the selected operation. A logging-only cleanup failure is not physical retirement.
A per-hook retry cap is not an aggregate tenant budget or effect idempotency.

### 5. Keep ordinary customization inside the existing authority boundary

Letta and APISIX deliberately allow trusted code to reshape a local harness or
operator-controlled gateway. Fastify scopes, Hapi realms, Nest exports and PF4J
classloaders manage visibility or resolution. These are useful mechanisms, but
none of those named boundaries alone proves hostile-code containment.

**Existing constraint, not newly adopted research:** ordinary Agent Teams
extensions cannot replace authorization, product invariants, fencing, canonical
state or enforcement. **Unadopted transfer:** choose stable narrow product seams
that offer useful change without private method patching, and explain the selected
provider/adjustment when that information helps the author. No generic diagnostic
control plane or new sandbox is selected here. Useful no-fork fit must be
shown by a real customization and combination of independent extensions at a
selected seam; callback count or breadth alone does not establish it.

### 6. Make streaming promises explicit

Microsoft's inspected Python middleware distinguishes construction of a lazy
response stream from final-result validation; its warning names the case where
unbuffered updates have already been emitted. Mastra exposes separate chunk and
result phases. A final rejection cannot retroactively retract a delivered chunk.

**Unadopted transfer:** if a particular product invariant requires checking before
release, that product chooses the stream policy and accepts its latency/memory
cost. This is not a blanket buffering requirement for every plugin or an
alternative authorization owner.

## Scale: which claim would actually need evidence?

A large catalogue and a large simultaneous execution population are different.
The existing GM N1000 construction and 1,024 live scoped receivers remain useful,
bounded evidence. New source inspection neither invalidates those achievements
nor extends them to a production fleet of hostile third-party plugins.

| Axis | A useful concrete question | Why a source/plugin count is insufficient |
| --- | --- | --- |
| Catalogue and discovery | How many inert descriptors can be searched/validated without executing excluded code? | Loaded modules and active instances may be far fewer |
| Graph shape | How many vertices, edges, dense conflicts, nested scopes and dependency closures? | One thousand independent leaves do not represent one dense graph |
| Active state | How many live instances, tenants and intentionally shared resources? | A descriptor may create many instances or reuse one physical engine |
| Model-visible tools | What shortlist is useful, with what discovery quality and current authorization? | Token reduction alone can hide poor selection or stale permissions |
| Execution and backpressure | Which operations progress independently under a slow/blocked provider? | Many modules can still share one thread, queue or engine |
| Restart/retirement | What happens to accepted work, partial setup, failed cleanup and repeated churn? | Method fulfillment or a one-shot happy path does not bound retained resources |
| Independent releases | Which public package versions, nominal tokens, manifests and migration profiles interoperate? | One monorepo's lockfile may hide independent consumers' conflicts |
| Authoring and diagnosis | Can a user identify the effective provider, state scope and cause of rejection? | Runtime throughput does not establish understandable customization |

These are measurement dimensions, **not a newly mandatory test campaign**.
Reuse existing evidence for unchanged claims. A future minimal experiment should
test a specific remaining uncertainty at an actual selected seam, with an
independent oracle and realistic bounded inputs. No new runtime experiment or
E2E was added in this research follow-up.

## Decision and experiment discipline

The retained small falsifiers are proposals. They do not themselves choose what
the product ought to promise. A framework's tolerated optional target, interruption
during controlled restart, declared shared backpressure or trusted extension code
must not be scored as failure against an invented requirement.

Distinguish an upstream semantic probe (does this path behave as read), product
conformance (does an agreed seam meet its selected promise), and capacity
qualification (does a defined workload stay inside its envelope). One cannot
stand in for another. Run a proposed probe only when its result changes a named
decision or resolves a concrete claim; do not execute the entire research list
as an automatic test plan.

Before a significant unresolved technical/product choice, first inspect the
current implementation/accepted authority and competing explanations, then obtain
independent criticism. Present concrete alternatives with:

- confidence, reliability within the named profile, and complexity, each out of
  ten; higher complexity means more burden;
- production, integration and test LOC ranges separately, including the reuse
  baseline, uncertainty and platform/release/maintenance costs;
- the fact or small experiment that would change the recommendation.

Do not estimate an entire future plugin platform from these case studies.
Scores are engineering judgments, not measured availability or a ranking of
framework quality. This documentation task introduces no production/integration/
test implementation, and it creates no new material owner decision to block it.
The real Host/SPI/trust/availability decisions remain in their existing owning
records, to be discussed when the concrete slice is ready.

## Independent criticism and retained evidence

The evidence bundle keeps the task context, source ledgers, researchers' detailed
reports, pre-correction versions, six research critique reports from four independent
critics, separate publication reviews and explicit review dispositions. Two specialist
researchers and the four critics used GPT-6.1 Sol at xhigh; root supplied the two
data-plane cases and synthesis. Review report count is not independent reviewer
count. Criticism
corrected authority-shaped headings, startup-versus-readiness wording, actual
MUST/SHOULD contract strength, the distinction between signal boundaries and DDD
contexts, and conditional preservation of an initial error when cleanup also
fails. These are corrections to research, not implementation approvals.

Publication validation and exact archive identity are recorded in the delivery
section below after the governed documents are complete. Frozen third-party
source caches are not redistributed; source commits, blob IDs, URLs and findings
are sufficient to locate the inspected evidence.

