# Independent critique: evidence reuse and extension-author experience

Review date: **2026-11-05 UTC**. Scope: the owner brief, complete retained
Engineering Quality Standard, original EF `AGENTS.md`, all four substantive
reports, all three JSON source ledgers, relevant local static-profile/OD-003
authority passages, and three independently fetched primary-source samples.
This is research criticism, not implementation approval. No framework was
installed or executed, no upstream test was run, and no repository or remote
state was changed by this critic. Only this assigned report was written.

## Verdict

**The research is reusable without a new material owner choice.** Its principal
distinctions are sound: observations remain observations, implementation pins
are separate from released artifacts, inspected tests remain unrun, and
conditional transfer ideas do not adopt architecture. The comparisons retain
useful competitor protections and deliberate trust/compatibility tradeoffs.
They support deep no-fork customization through concrete product seams without
requiring a universal plugin framework.

The remaining work is ordinary publication navigation: make each companion
ledger directly reachable and give source IDs a usable primary-source route.
Root has already identified this work and owns the governed publication.
One small additional source-link improvement is to cite the existing OTel
feature-gate declaration source beside the Alpha/Beta claim. This is a document
repair, not a request for another experiment, release gate, registry, or owner
approval.

## Structural, identity and date checks

The final structural scan read and parsed the three JSON documents and checked
source IDs, case ownership, case-to-source lists, full commit syntax, blob-URL
commit equality, retrieval dates, and report reference definitions. These are
document checks, not framework runtime qualification.

| Lane | Stable cases | ID-bearing source records | Additional moving-doc records | Result |
| --- | --- | --- | --- | --- |
| Agent frameworks | AF-001 through AF-006 | 66 | Hosted docs are included among the 66 | Every case/source association and explicit prose ID resolves; all source retrieval dates are 2026-11-05 |
| Specialist frameworks | SF-PLG, SF-PF4J, SF-FST, SF-HAPI, SF-NEST, SF-DRUPAL | 72 | Hosted docs are included among the 72 | All 72 reference definitions now appear once and exactly match ledger URLs; case/source association and dates are consistent |
| Data-plane frameworks | DP-01, DP-02 | 14 | 3 | Source IDs are unique and belong to the correct case; pinned URLs agree with commits; top-level retrieval date supplies 2026-11-05 |

There are **14 substantive cases and 152 uniquely ID-bearing source records**,
plus the three separate moving OTel documentation records. This count describes
the retained records, not 155 independent confirmations or a quality score.
There are no cross-ledger duplicate source IDs. All inspected code URLs checked
by the scan contain the same full 40-character commit recorded in their entry.
No code URL silently substitutes `main`, `master`, or `develop` for its pin.

The first specialist report inspected by this critic repeated the entire
72-definition source index with identical targets. Root removed the second
block while retaining the original in
`specialist-frameworks-pre-final-critique.md`. The subsequent scan confirms
72 unique, nonconflicting definitions. This was a reuse/maintenance defect in
the report, not a defect in any framework.

The initial data-plane ledger lacked named symbols/support mappings and direct
release-date evidence. Root subsequently added symbols and bounded supports
for its source records, and per-case release metadata/page URLs, exact
publication timestamps, retrieval dates and tag/source relationships. Those
additions address the observed provenance gap without introducing a new schema
or approval process. The record formerly under `additionalSources` is now in
the ordinary `sources` list; the count remains 14.

### Publication details to finish

1. **Keep companion ledgers one click away.** The scratch agent report names
   `agent-frameworks-sources.json` as code-form text, and many `[ADK-S2]`-style
   citations resolve semantically through that ledger rather than being
   Markdown links. Root's planned direct evidence paths and per-ID source
   appendix are sufficient. The specialist report already has exact primary
   reference definitions. No new citation registry is necessary.
2. **Link the precise gate declaration.** The data-plane report names both
   partial-reload maturity levels, but its source definitions currently omit
   the ledger's `otel-gates` URL. Add an ordinary reference to
   `service/internal/metadata/generated_feature_gates.go` at the existing pin
   beside that claim. Other data-plane reference aliases (`ot-*`/`ap-*` versus
   ledger `otel-*`/`apisix-*`) map by identical URLs; changing their names or
   standardizing the three ledgers is unnecessary.
3. **Resolve governed-document destinations when publishing.** Synthesis links
   intentionally name the eventual governed agent/specialist reports and
   existing EF decisions, rather than scratch filenames. Verify those exact
   final routes in the publication checkout. Their absence in the scratch
   reports directory is not itself a broken published link.

These are bounded finishing checks under the already authorized documentation
task. They do not require new product tests.

## Can an agent tell a fact from an adopted requirement?

Yes. The reports place research-only status before the cases, define evidence
classes, distinguish documented behavior from source control flow, identify
inference explicitly where a route has not been exercised, and label the small
falsifiers as proposed/unexecuted. The synthesis further distinguishes executed
evidence from both source inspection and owner authority. Its explicit statement
that an `active` research-document status is not approval avoids a subtle future
misreading.

The source/release tables are particularly useful. Agent-framework inspection
is generally default/development-branch source, with independent release/tag
identities; identical manifest version text is explicitly insufficient to prove
publication. Eliza's missing published-byte identity remains unresolved rather
than being filled with an evidence-artifact release. Letta's successor lineage
is stated before discussing its actual current extension unit. Specialist tag
inspection is also explicitly weaker than published package-byte/platform
qualification. Fastify and Avvio are described as separately inspected compatible
release sources, not an installed and tested dependency pair.

The historical examples retain their resolution: ADK cancellation cleanup,
Mastra recovery cap, Eliza connector teardown, Letta V1 transport, Pluggy ordinary
registration/unregister fixes, PF4J inherited metadata, Drupal mixed hook order,
and the Collector connector-role correction. A reader is repeatedly told which
current mechanism supplies counterevidence. None of these repaired incidents
should be promoted into a current competitor defect or a future product
superiority claim.

The most sensitive source hypotheses remain honestly bounded. PF4J's bulk-start
inference is contrasted with its protected single-start route; Pydantic's
singleton `requires` path remains an unrun validation-boundary question;
Hapi/Avvio partial setup and timeout observations do not claim a promise of
transactional rollback or cancellation. An experiment could resolve those
mechanisms, but no production choice depends on resolving every question now.

## No-fork authoring does not require a universal plugin framework

The evidence supports a practical authoring lesson: an author needs to know
the behavior they may contribute, its permitted inputs/results, selection or
ordering, visible dependencies, state lifetime, and the owner to consult when
setup or cleanup fails. Different seams can provide those answers differently.

Pluggy can validate a hook signature; Nest can export a narrow provider;
Fastify can scope a subtree; Drupal can define one plugin type; Mastra can name
a processing phase; a product can select a provider in its static profile.
These mechanisms need not share an activation supertype, lifecycle manager,
dependency bag, or framework base class. The reports preserve this diversity
instead of treating every extension unit as an installable artifact Host.

The useful no-fork goal is meaningful supported change through an owned seam.
It does not guarantee that every private method, invariant, authorization rule,
or canonical record is replaceable. Letta and APISIX intentionally offer more
power to trusted local/operator code. That power is evidence of a coherent
different trust profile; ordinary Agent Teams third-party extensions do not
inherit it. Similarly, compatibility-through-repair can be reasonable for
agent-maintained local mods without establishing the same release contract for
independent third-party package authors.

The synthesis correctly keeps physical cleanup with its execution owner and
does not interpret every registry removal, callback result or timeout as
retirement. It also does not make every module separately process-hosted merely
because the intended ecosystem is large. This preserves authoring simplicity
and the existing custody boundary at the same time.

## Static profiles, dynamic Host duties and test scope

The original EF local profile explicitly adopts no Assembly Host scope, retains
its reviewed pin, and places the optional dynamic Host lifecycle candidate
outside that scope. OD-003 preserves static composition plus controlled restart
and keeps Host/public-SPI choices open; its shared-mechanism discussion is not
a new blocker for existing static modules. The four reports agree with those
boundaries. Their discussion of lifecycle identity, exact-owner cleanup or
late completion does not require adding a dynamic Host to a local static
profile.

The synthesis also avoids creating a mandatory scale campaign. Catalogue size,
graph shape, active instances, tool visibility, backpressure, retirement,
independent releases and diagnosis are **dimensions that distinguish claims**.
The text expressly says they are not a newly mandatory test campaign and tells
future work to reuse unchanged evidence. Its falsifiers apply to selected
promises: interruption during a permitted controlled restart, declared shared
backpressure, trusted-code privilege or an optional missing target cannot be
declared failures against an invented requirement.

The instruction to observe a real resource when claiming retirement is an
evidence-integrity constraint on that particular claim. It does not demand
retirement testing for every ordinary hook or documentation update. Preserve
that reading in publication. The existing bounded public-package E2E likewise
remains useful evidence without being relabeled production Host, artifact
custody, restart/drain or fleet qualification. The synthesis properly preserves
that the wider PR includes Docs Protocol configuration/tests and is not wholly
prose-only.

## Independent primary-source spot checks

These three samples were independently fetched by exact repository commit,
without running code. The checks were selected for authoring/trust/fairness
claims; they do not audit all source entries or replace the other mechanism
critics.

| Source inspected | Observation and disposition |
| --- | --- |
| [Letta mods contributor README](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/README.md), returned blob `6d510f8ee3f9148614ee23b48353195a96ef2eef` | Explicitly treats mods as trusted local code and prioritizes repairability/diagnostics while reserving host coordination for real invariants. The agent report fairly presents a deliberate compatibility/authoring choice, not a missing universal SDK or a general isolation guarantee. |
| [Drupal HookOrderTest](https://github.com/drupal/drupal/blob/76deda03b09b57d76941e2d30e6dade35e92a14a/core/tests/Drupal/KernelTests/Core/Hook/HookOrderTest.php), returned blob `f3109017a47d4799309b471421ae8bb482ca7a69`, selected lines 95–164 | Source comments and assertions explicitly intend missing reorder/remove targets to have no effect or error. The specialist report correctly treats this as optional-composition policy and inspected test intent, not a test run or a required-binding defect. |
| [APISIX threat model](https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/security-threat-model.md), returned blob `d22cf3f549f2d29a7220f3ed734f1bd2764debd7`, selected lines 1–170 | The trust table identifies administrators, operator-supplied Lua and external plugin runners as trusted/operator-trusted. Same-worker custom-code execution is a declared assumption. The data-plane report correctly avoids calling this a broken hostile-code boundary or treating process placement alone as containment. |

## Decision disposition

**No new material owner decision is required to retain or publish this research.**
The small navigation/provenance repairs can be completed by root under the
existing task. No framework adoption, new architecture requirement, new
registry/process, broader test campaign or runtime implementation follows from
this critique.

For a future real unresolved option, retain the owner's rubric: confidence,
achievable reliability within the named profile, and complexity each /10;
production, integration and test LOC ranges separately; current-stack reuse,
uncertainty and platform/release/maintenance burden. Scores would be engineering
judgments about that option. There is no honest whole-framework reliability
score or total implementation LOC to fabricate from this source comparison.
