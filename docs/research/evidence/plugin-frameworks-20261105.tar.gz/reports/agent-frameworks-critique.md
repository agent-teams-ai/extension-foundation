# Independent critique: agent framework extension research

Review cut: **2026-11-05 UTC**. Reviewed artifacts: `agent-frameworks.md` and `agent-frameworks-sources.json`. This is an independent, read-only source and authority review. It creates no product requirement, framework selection or implementation approval.

## Disposition

The report makes a useful, restrained comparison of six different extension units. Its strongest contribution is preserving differences between interception, notification, grouped middleware, processor state, contribution ownership and trusted harness adaptation. It does not collapse them into an invented universal plugin Host. Its current ownership statement, explicit unadopted hypotheses, distinct branch/release identities, repaired historical issues and unrun-test labels should remain.

One source-level overstatement was material enough to correct: Eliza registration cleanup did not unconditionally preserve the original registration error when cleanup itself failed. This was reported to the lead during review. The current report and ledger now state the conditional behavior and retain dated correction provenance. That is a correction to research wording, **not an upstream bug reproduction, an adopted architecture change or proof that Eliza's separate runtime retirement loses every obligation**.

Two smaller qualifications improve precision without expanding scope: ADK's notification continuation is for ordinary caught exceptions, and a middleware bundle's all-or-nothing category acceptance is not a transaction over arbitrary installation effects. Neither observation warrants another experiment in this task. The report already handles most of these limits in substance.

## What I independently checked

I read the report, inspected the ledger structure and the relevant entries, then fetched these files independently through read-only GitHub access at their exact report pins. All eight returned blob identities match the ledger. This establishes that this review read the same code identities; it does not execute them or prove a release contains them.

| Case / inspected file | Independent fetched blob SHA | Reviewed mechanism |
| --- | --- | --- |
| ADK `plugins/plugin_manager.py` | `bbb7bdd40b95b27b0d79f0ac252ae2221b94748c` | First-result dispatch, notification dispatch, borrowed close and cancellation/error handling |
| Pydantic AI `capabilities/_ordering.py` | `ca88485ba2118f57851da9b2280d2eb81e261ef6` | Presence versus order, matching, topological edges, singleton fast path |
| Microsoft `_middleware.py` | `f546cdda43ae82251574b0b22fe806e67ed1f9e2` | Bundle category contract, lazy stream/final-gate warning and explicit failure contract |
| Mastra `processors/retry-budget.ts` | `f83451d48ed986ccd9c946084f55a280e0b8e5c5` | Explicit override, implicit retry cap and warning scope |
| Eliza `plugin.ts` | `9c0c8ea61bf44297ff27b583f40b0fc7ead00962` | Missing/cyclic dependency tolerance and alias lookup |
| Eliza `plugin-lifecycle.ts` | `d1815a248b7966c9fc38b6d1f61df32c254d7b49` | Partial registration capture, cleanup/error path, adapter restriction and replacement sequence |
| Letta Code `mods/mod-engine.ts` | `8980b593fce47a5a8500ab2b0e536e6a7e313afe` | Synchronous disposal, generation checks and progressive publication |
| Letta Code `mods/tool-registry.ts` | `ddb0d478c88f9facf4962f7d62093b5c5b1f39de` | Owner-checked deletion, availability filtering and new-call activation guard |

The review did **not** independently re-fetch every manifest, release/tag object, hosted document, historical commit, test file, Pydantic combined/wrapper implementation, Mastra runner, Eliza runtime retirement implementation or Letta migration README. Those remain evidence retained by the report's author, with their stated inspection classes. I checked the ledger structure and bounded claims, not the complete truth of every source entry. No packages were installed; no source, tests, fixtures or upstream examples were run; no remote state or repository code was changed.

## Findings and qualifications

### AFC-01 — Eliza registration failure preservation was conditional; correction incorporated

**Location:** AF-005, “Mechanism 2: capture owned contributions and unwind partial registration”; ledger `ELI-S3`.

At the pinned source, `registerPlugin` catches the registration error, captures partial ownership, awaits `teardownPluginOwnership`, and only then executes `throw error` (lines 1244–1254). Teardown accumulates errors and throws `AggregateError` (lines 868–872). Therefore a cleanup rejection prevents reaching the original-error rethrow. The earlier unconditional preservation claim exceeded the control flow. The corrected report says cleanup success preserves the registration error, while cleanup failure can propagate its aggregate instead. That is supported.

The same teardown routine deletes the plugin's lookup ownership entry before its aggregate throw when `removeOwnership` is enabled (lines 864–872); the registration wrapper also removes pending ownership in `finally` (1255–1256). These facts mean this local store cannot alone be presented as a durable cleanup-debt ledger. They do **not** establish that every underlying service promise or broader retirement obligation disappears. The report's separate description of `RuntimeRetirement` must retain its own exact evidence and profile limits. Do not replace the report's balanced discussion with “Eliza clears registries and loses custody.”

The source comment says teardown attempts every owned resource, but some removals share one `try` block. If one of those calls throws, later calls inside that block are skipped before the outer catch. The report currently says it attempts the listed removal families, rather than promising every removal independently succeeds or is always attempted; preserve that distinction. No assertion about actual throwing behavior was executed.

Source: [pinned lifecycle implementation](https://github.com/elizaOS/eliza/blob/74b8e6a22ef915680f55dd4018ee118d1018d33d/packages/core/src/plugin-lifecycle.ts), `teardownPluginOwnership` and `installRuntimePluginLifecycle`.

### AFC-02 — ADK's ordinary notification failure differs from cancellation

**Location:** AF-001, “Mechanism 1,” second paragraph and proposed notification falsifier.

The source distinction is real: `_run_callbacks` returns on the first non-`None` result, while `_run_notification_callbacks` ignores callback results and catches ordinary `Exception` values to continue. The false-like `{}` example is accurate. The notification helper does not have the dedicated cancellation branch that `close` has. Its claim to visit every plugin must therefore be understood within the ordinary-exception contract, rather than as guaranteed delivery despite task cancellation or every possible abnormal termination.

A small wording refinement is sufficient: “continues after individual ordinary callback exceptions.” The proposed falsifier should say its injected error is an ordinary exception. It should not force a product notification contract to swallow cancellation or create a second cleanup task owner.

The close analysis is fair. Sequential cleanup preserves same-task context, continuing after caught close errors and cancellation, before re-raising recorded cancellation. It remains cooperative; the five-second timeout is no proof of physical subprocess exit or rollback of effects. Borrowed no-close behavior illustrates allocation of an existing cleanup obligation, not a new EF lifetime manager.

Source: [pinned PluginManager](https://github.com/google/adk-python/blob/b33b43e5b5388b9454c71f440eb885901075f43a/src/google/adk/plugins/plugin_manager.py), `_run_callbacks`, `_run_notification_callbacks` (381–415), `close` (417–471).

### AFC-03 — Pydantic's singleton question is correctly unrun and narrow

**Location:** AF-002, ordering mechanism, test paragraph and proposed falsifier.

`sort_capabilities` returns immediately when the top-level list has at most one element, before collecting leaves or calling `_validate_requires`. For longer input it validates presence separately from topological ordering. The report accurately identifies the function boundary and avoids labeling an end-to-end public defect. Keep that restraint: higher-level normalization, grouping and construction paths were not independently followed here. A reported missing-requirement test involving two children does not resolve the singleton boundary.

Class matching and instance matching are also meaningfully different: `_ref_matches` uses subclass tests for a class reference and identity for an instance reference. Copy/rebinding can therefore matter. The proposed original-instance/reference setup is a useful qualification question, but its result should describe that concrete path and resulting declared identity semantics, rather than imply all copies or wrappers are broken.

The report's insertion-order statement follows the implementation's stated tiebreak rule. It is not evidence that arbitrary package enumeration produces one canonical plan. The consumer must define its input order or reject ambiguity; GM already owns neutral canonical composition. No Pydantic sorting code belongs in EF merely because this case makes order visible.

Source: [pinned ordering implementation](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/_ordering.py), `sort_capabilities`, `_validate_requires`, `_ref_matches`.

### AFC-04 — Microsoft's useful guarantees have precise levels

**Location:** AF-003, both mechanisms and cross-case register.

`MiddlewareBundle` deliberately groups members opaquely, validates categories, rejects nested bundles and rejects a supported-seam/category mismatch. That supports required contribution closure at admission to those middleware seams. It does not establish atomic rollback of arbitrary middleware constructor effects, resources acquired before admission, or downstream effects after execution begins. The report already says bundles are not plugin installation lifecycle or package resolution; summaries should preserve that level.

The stream observation is particularly useful. `_warn_unbuffered_result_gates` explicitly states that final result gates on an unbuffered stream run after updates have been delivered; it points authors to buffering to make those gates hold release. The report gives credit for the mitigation and diagnostic. Buffering is a policy/latency/memory tradeoff, not a universal recommendation to buffer every stream. The product must name which content/effects require a pre-release invariant.

Optional additional counterevidence is available in the same fetched source: `MiddlewareFailure` documents a distinct fatal escape for function enforcement, contrasting recoverable tool-error conversion with fatal propagation and cooperative cancellation. That contract explicitly warns that a synchronous worker-thread tool may still finish its effects. This strengthens the report's insistence on effect ownership. I did not inspect the full invocation loop behind that class contract, so adding it would be a documented source contract rather than independently verified enforcement behavior. It is not necessary to expand the report solely to enumerate another hook.

Source: [pinned Python middleware](https://github.com/microsoft/agent-framework/blob/1c3264b065ef4b2b9b3614b19394bdd49d98334f/python/packages/core/agent_framework/_middleware.py), `MiddlewareBundle` (1104 onward), `_warn_unbuffered_result_gates` (1373–1390), `MiddlewareFailure`.

### AFC-05 — Mastra's retry cap should remain scoped to its actual path

The fetched function returns a caller-supplied retry setting directly, returns no implicit setting without error processors, and otherwise supplies the three-retry backstop. Its warning specifically distinguishes caller-configured error processors from the resolved built-in stability defaults. The report accurately preserves these conditions. A cap of three retries permits the initial call plus retries; it is not necessarily three calls total. The proposed fixture should count the concrete path and state whether the oracle counts attempts or retries.

The historical repaired endless-retry mechanism must not be described as current. Nor should the cap be reused as an Agent Teams retry default: retries of model calls, tools, workflows and externally committed effects have different owners and budgets. This report provides no measured fleet envelope or migration case for TypeScript versus Python.

Source: [pinned retry-budget function](https://github.com/mastra-ai/mastra/blob/0ab5441946936c0c5c02a8f684e74ac4b5df0cfa/packages/core/src/processors/retry-budget.ts), `resolveMaxProcessorRetries` and its comments.

### AFC-06 — Tolerant dependency traversal is a tradeoff, not automatically a security defect

Eliza's resolver logs and returns when a dependency is absent or already in the active DFS visit set, but the enclosing traversal can still append a plugin. It has no `priority` use in this fetched function. The report correctly bounds the discrepancy to this function and the broad hosted documentation claim. It does not falsely infer every Eliza host ignores priority, nor that a returned array certifies complete hard dependencies.

For a host deliberately tolerating optional integrations, logging and partial progress can be useful. Agent Teams should preserve its existing required/optional semantics and GM hard composition closure. The smallest local question is what a concrete caller promises when dependency closure is missing; there is no evidence-based need to invent an EF dependency engine or demand complete closure for every optional observer.

Source: [pinned resolver](https://github.com/elizaOS/eliza/blob/74b8e6a22ef915680f55dd4018ee118d1018d33d/packages/core/src/plugin.ts), `resolvePluginDependencies` (131–205).

### AFC-07 — Letta stale-generation protection is correctly distinguished from atomic rollout

`createModEngine.reload` disposes the current registry, increments generation, publishes an empty registry, and permits the current loading registry to be published progressively. A completion whose generation is stale is disposed. `disposeLocalMods` calls synchronous disposers without awaiting an asynchronous drain. `unregisterModTool` and per-owner unregister delete only matching owner IDs; `runModTool` checks abortion before entering `tool.run`, then delegates to the tool. These support the report's precise distinctions between future availability, stale completion, exact-owner deletion and already-running work.

The report should keep its positive account of repairability and trusted local harness customization. Weak semantic stability is not universally defective when repair/reload is the intended author workflow. It also cannot qualify an independently versioned third-party product fleet. No language or live-reload adoption follows. Full trust in local mods is a documented product scope, rather than proof of an untrusted plugin escape. The migration lineage and V1 resolved transport issue remain separately sourced; I did not independently verify that lineage in this spot review.

Sources: [pinned engine](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/mod-engine.ts), `disposeLocalMods` (1676–1712), `createModEngine` (1714–1805); [pinned tool registry](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/tool-registry.ts), owner deletion (84–98), `runModTool` (137–144).

## Falsifier usefulness and hypothesis ownership

The proposed fixtures are useful only as questions about a named consumer promise. They remain unrun. Some verify upstream semantics, while others reject a proposed Agent Teams analogy; those are different uses. Neither success makes a product architecture adopted.

| Proposed check | Useful scope | Guard against invented requirements |
| --- | --- | --- |
| ADK early result / notification error | Exact hook's result algebra and ordinary failure handling | Do not require every notification to survive task cancellation, or attach mandatory enforcement after a suppressible optional chain |
| Pydantic singleton requirement / rebinding | Locate actual public construction and identity boundary | Do not report a public defect from one helper's fast path alone |
| Middleware bundle / rejecting final gate | Category admission and a specified pre-release stream policy | Do not call bundle admission an arbitrary effect transaction or require universal buffering |
| Mastra same-ID state / retry stub | Explicit state key and specific recovery budget | Document intentional sharing; count retries separately from total calls and effects |
| Eliza missing closure / failed registration | Caller-required closure and owned partial cleanup | Include both registration and cleanup failures if error preservation is the claim; do not infer all physical custody from one registry |
| Letta stale activation / pending old tool | Current generation authority versus old work termination | Do not treat prevented future calls as proof of drain or demand old-active-until-new-ready under the restart baseline |

There is no need to execute all of these merely because they were proposed. Select a bounded case only if an already owned product seam has an unresolved concrete invariant that current retained evidence does not answer. Existing public-consumer, admission and controlled-restart evidence can be reused when qualified inputs and claims remain the same.

The transfer register generally keeps ownership sound: products own hook semantics, response policy, state and grants; the existing execution owner keeps physical custody; GM owns neutral composition identities/bindings/plans; EF can retain neutral vocabulary and conformance evidence. “EF could preserve” remains a hypothesis about existing neutral concerns, not permission to install a new graph, runtime installer or global hook manager. Ordered invocation in a narrow product pipeline is not automatically a new GM public feature either; neutral GM work needs an actual composition contract.

No material new owner decision follows from the eight-file source review. The required correction was documentation-only and is now incorporated. The smaller qualifications also require **zero production, integration or test LOC**. Reliability/confidence/complexity scores for adopting a competitor framework or building a generic Host would invent an unrequested alternative without an integration scope. Preserve the research and critic disposition, keep accepted decisions intact, and discuss any real future disputed slice with its existing owner before implementation.
