# Independent framework evidence critique

Research cut: **2026-11-05 UTC**. Role: independent source-fidelity critic. Status: **research review, not architecture adoption or runtime qualification**.

## Disposition

**No high- or medium-severity source-fidelity blocker was found in the selected mechanisms.** The reports preserve the distinction between documented intent, inspected implementation, unrun tests, historical repairs and conditional transfer. The strongest potentially adverse observations—Pydantic's singleton validation boundary, PF4J's different startup entrypoints, Hapi's partial executable registration and Eliza's cleanup-error propagation—remain bounded source observations or proposed falsifiers. They do not establish a competitor-wide reliability defect or Agent Teams superiority.

One low-severity wording improvement remains useful: make Pydantic's presence-only `requires` sentence explicitly subject to the already-retained singleton caveat. Two editorial problems observed during this review, identical duplicated specialist reference definitions and synthesis wording about a first “nonempty” result, were corrected by the root researcher. Their correction provenance is retained below.

This review creates **no material owner decision**. The task is to retain research. Neither selecting a framework nor implementing a generic loader, cleanup ledger, ordering language, sandbox or Host is necessary to finish it. Confidence/reliability/complexity scores and production/integration/test LOC ranges would invent a concrete implementation choice that the task has not made; none is estimated here.

## Scope and method

The complete task brief, retained Engineering Quality Standard and original EF checkout's `AGENTS.md` were read. The review read `agent-frameworks.md`, `agent-frameworks-sources.json`, `specialist-frameworks.md`, `specialist-frameworks-sources.json` and `cross-framework-synthesis.md`. It independently re-fetched **18 exact source files** and selected historical commit, release and tag metadata through read-only primary GitHub access. The source table below identifies the checked files; it is intentionally a sample of the strongest claims, not a repeated investigation of all fourteen cases.

No upstream/runtime tests, package installs, benchmarks, spikes, product edits or remote mutations were performed. Upstream test files were read as independent stated expectations. This critic wrote only this report and did not edit either repository, a Docs Protocol transaction or the researchers' reports.

Severity means risk to the research's interpretation: high would materially falsify its central conclusion or authority boundary; medium would require correcting a material claim before publication; low concerns a local wording, citation or navigation issue. A source-supported limitation is not automatically a defect finding.

## Findings and counterevidence

### F-01 — Pydantic presence, order and the singleton boundary

**Severity: low wording robustness; no blocking falsehood.** Location: AF-002, “order constraints are distinct from type-presence requirements”; source IDs `PYD-S1`, `PYD-S2`, `PYD-S3`, `PYD-T1`.

`CapabilityOrdering.requires` is documented in the pinned abstract contract as type presence with no implied ordering. The inspected `_validate_requires` checks matching leaf types using subclass matching. It does not add graph edges; the separate position and relative-edge functions implement ordering. Type references and object-identity references remain different. The report's distinction between presence, ordering, provider binding and semantic-version solving is therefore supported.

The caveat is also real local control flow. In `sort_capabilities`, the `n <= 1` return at lines 24–26 precedes `_validate_requires`. `CombinedCapability.__normalize_capabilities` calls that sorter when a leaf has ordering metadata, at lines 199–200. The existing missing-requirement test uses two children, and its positive counterpart also uses two. This inspection does not supply a singleton missing-requirement execution result. The base `_validate_runtime_capabilities` method inspected in `AbstractCapability` contains no general requirement validator, but that is still insufficient to claim that every whole-Agent path accepts the unsupported composition.

**Smallest wording correction:** replace “`requires` validates that matching capability types are present” with “`requires` is specified as presence-only; the inspected validation pass checks matching types without adding order edges, subject to the singleton fast-path caveat below.” Keep the next paragraph's explicit `n <= 1` caveat and its unrun status. The current paragraph already has that caveat nearby, so this is precision against excerpting, not a request to recast the case as a newly proven defect.

**Smallest falsifier, proposed only:** compare one capability requiring an absent type with the same capability plus an unrelated sibling at the actual public construction/run seam being considered. Record whether and when rejection occurs. A higher-level rejection would limit the local bypass observation; it would not erase the source fact that this sorter skips its validator for a singleton.

**Residual uncertainty:** end-to-end normalization and runtime-generated capability paths, other versions, published wheel bytes and actual execution. None is required to preserve this research observation.

### F-02 — PF4J manual and bulk startup genuinely follow different paths

**Severity: no correction required; retain the inference label.** Location: SF-PF4J, “Good failure handling and entrypoint-specific counterevidence”; source IDs `PF4J-MGR`, `PF4J-TEST` and auxiliary inspection of `DefaultPluginManager`.

At the exact pinned manager, `startPlugin(id)` calls `startDependencies` and only calls `doStartPlugin` when it succeeds. `startDependencies` recursively starts dependencies, marks the dependent FAILED when a required dependency does not become STARTED, and allows a failed optional dependency with a warning. The inspected test explicitly invokes the single-plugin entrypoint and expects the required-dependent failure. Optional and cascading cases in the same test file reinforce that this protection is deliberate.

By contrast, `startPlugins()` loops resolved wrappers and directly calls the private `doStartPlugin`. That private method invokes the plugin's start, records STARTED or a caught failure and emits the state event. It contains no equivalent required-dependency runtime-success check. The checked `DefaultPluginManager` does not override either startup entrypoint. Descriptor ordering cannot by itself establish startup success.

The report is right to describe a bulk-path concern as **source inference, not an executed failure**. It should not be shortened elsewhere to “PF4J starts broken dependencies,” “PF4J has no dependency validation,” or a whole-framework reliability judgment. The first assertion is underspecified; the latter assertions contradict successful protections in the same pin.

**Smallest wording correction:** none to the current case. If a summary needs fewer words, retain “manual-start protection differs from the inspected bulk-start path; unrun failure scenario.”

**Smallest falsifier, proposed only:** in a fresh disposable manager for each entrypoint, A.start throws and B requires A; independently count B.start calls and record state transitions. Use fresh managers so state left by the first route cannot contaminate the comparison. A host-level admission rule or listener that prevents B starting in its actual qualified profile would narrow the transfer concern, even though it would not change these base entrypoint paths.

**Residual uncertainty:** runtime/plugin callback behavior, listeners, custom managers and host policies. The read code gives a strong bounded hypothesis, not a reproduced incident or a universal PF4J promise.

### F-03 — Visibility, DI lifetime and class identity are not hostile-code containment

**Severity: no correction required.** Locations: SF-FST encapsulation, SF-HAPI realms, SF-NEST compatibility/trust, SF-PF4J classloading and synthesis lesson 5. Checked IDs: `FST-OVERRIDE`, `HAPI-SERVER`, `NEST-MODULE`, with existing exact source citations retained for the broader classloading discussion.

Fastify's override creates a prototype child and selected fresh framework state, with a deliberate path that returns the parent instead. Hapi's `_clone` reuses the core while creating a registration-specific server/realm; the plugin's registration function receives that application object. Nest's export validation controls provider visibility within the injector and rejects invalid exports. These are concrete, useful authoring protections. They do not claim separate address spaces or a privilege boundary for executable plugin code.

The reports correctly keep “this named mechanism alone does not prove containment” separate from “the entire framework has no security facility.” The latter would require a different audit and would ignore product-level authentication/authorization facilities outside the inspected unit. The same caution applies to Pydantic typed dependencies, Letta host-capability booleans and PF4J loaders. This is an analogy boundary, not a competitor defect list.

**Smallest wording correction:** none. Preserve “alone,” “inspected mechanism” and the scope limitations when extracting summaries.

**Residual uncertainty:** no hostile-code execution audit or complete framework security assessment was performed. No new sandbox choice follows from this observation.

### F-04 — Partial executable setup and error ownership are accurately bounded

**Severity: no correction required after the retained Eliza clarification.** Locations: SF-PLG repaired history, SF-HAPI partial registration, AF-005 partial registration. Checked IDs: `PLG-MGR`, `PLG-REL`, `HAPI-SERVER`, `ELI-S3`.

Pluggy's ordinary registration pass first discovers and validates implementations, then mutates membership. Its current source explicitly retains a narrower historic-replay reentrancy case in which a newly added spec causes later validation to fail after partial registration. The ordinary repair and that exceptional path can both be true. Treating the latter as proof that the 1.7 ordinary validation repair failed would inflate the finding.

Hapi records registration metadata before awaiting user setup. Its inspected `finally` decrements the registration counter; it does not roll back all earlier route/exposure/resource changes. Thus the report's statement that a rejected setup promise does not establish an untouched candidate is sound. It deliberately avoids asserting that Hapi promised transactional registration. An owning product's disposal/recovery responsibility is a conditional transfer question, not evidence of an upstream broken transaction contract.

Eliza's pinned registration catch awaits `teardownPluginOwnership` and throws the original registration error afterward. Teardown itself can throw an `AggregateError`. The report now says precisely that successful cleanup permits rethrow of the original error, whereas a cleanup failure can become the propagated error. This independently verified control flow supports the correction. The source comment's aspiration to preserve the original error must not replace the actual awaited control flow as evidence.

**Smallest wording correction:** none to the revised prose. Keep the original-error statement conditional in the ledger, detailed case and any summary. If both registration and cleanup errors should be preserved in an Agent Teams product, that is a future owned contract question; it is not already implemented or adopted by this study.

**Residual uncertainty:** actual failure traces and whether individual acquiring code compensates its own changes. No runtime rollback guarantee or reproduced leak is claimed.

### F-05 — Exact-owner stale cleanup is useful protection, with narrow completion semantics

**Severity: no correction required.** Location: AF-006 mechanisms 1–2 and AF-005 repaired connector history. Checked IDs: `LET-S1`, `LET-S5`, `ELI-S3`, `ELI-H1`.

Letta's tool removal compares the stored owner ID with the disposing owner. `runModTool` checks the activation signal before invoking a tool. The engine aborts old activation signals, runs synchronous disposers, publishes a new empty/loading registry, and disposes a stale completed load rather than publishing it as current. These mechanisms support the report's stale-owner and stale-completion claims. They also substantiate its refusal to describe the sequence as old-active-until-new-ready atomic publication. A pre-invocation abort check is not physical cancellation of work that was already running.

Eliza's historical connector repair supplies additional **positive counterevidence**. The retrieved commit describes ownership transfer for overlapping connector keys, account-exact removal, legacy/default-route ownership and claims belonging to registrations still in progress. The current lifecycle file contains corresponding ownership bookkeeping. This history must remain a fixed incident, not become a claim that the development pin still unconditionally removes a successor's connector.

**Smallest wording correction:** none. Avoid generalizing a checked tool/connector ownership rule to every arbitrary import side effect, subprocess or external handle.

**Smallest falsifier, proposed only:** resume an obsolete activation after its successor registers the same tool key, then invoke old-owner cleanup and inspect the surviving owner and dispatch target. Keep a prior invocation pending to separately observe whether work ends. These are separate oracles; a surviving registry entry alone does not prove retirement of old work.

**Residual uncertainty:** plugin cooperation, asynchronous effects and resources outside the tracked contribution surfaces. No production reload, drain or fleet qualification was executed.

### F-06 — Default branches, release tags and historical repairs remain distinct

**Severity: no correction required.** Locations: both identity tables and the synthesis coverage section.

Independent metadata reads confirmed Pydantic `v2.66.0` points to `7d1d3f0191fd5d500b02e58dee2bf6d7adc1b967`, while the inspected implementation is `e2332baaba4feb2c92f5ed47b7343374c2ba3546`. Letta Code `v0.34.41` points to `233c0034492b9782c9bec01002226b891e514745`, distinct from inspected `8ec417abb05a0d7f4c2b7be3968345fbc48da294`. PF4J's annotated `release-3.16.1` tag object `1bfd6ca7279918b13b45d977c3153ea7c478e607` peels to the reported `6ffa261f0e28f88a9115432482cad64979715a0d`. Release publication metadata agrees with the dates retained for those three examples.

These checks support source/tag relationships. They do not prove npm/PyPI/Maven package bytes, installed transitive dependency versions or platform builds. The reports already make that limit explicit, including the separately inspected compatible Avvio release and Eliza develop's unestablished published-byte identity. Equal manifest version text is correctly treated as insufficient release identity.

Historical handling is also appropriate in the selected examples. ADK's 2026-10-07 cancellation fix metadata and current dedicated cancellation branch agree. Pluggy's 1.7 changelog identifies ordinary validation and unregister repairs while current source retains the narrow replay caveat. PF4J 3.16.1's release notes and superclass-walking implementation support the inherited extension-metadata repair. Eliza's connector change is preserved as repaired development-source history. None should be used as an unrepaired competitor defect.

**Smallest wording correction:** none. When a future consumer needs a released guarantee, inspect that release's exact relevant bytes; this research need not turn into an installation campaign now.

**Residual uncertainty:** this critic did not independently re-resolve every release/tag in the two ledgers, and no publication artifact was downloaded or qualified. The selected identity checks do not certify the remainder by analogy.

### F-07 — Source ledgers are structurally coherent; duplicate reference navigation was corrected

**Severity: low, resolved editorial issue.** Locations: both JSON ledgers and SF source index.

The agent lane contains **6 cases and 66 sources**, with per-case source counts 8, 13, 6, 11, 12 and 16. The specialist lane contains **6 cases and 72 sources**, with counts 9, 14, 14, 6, 15 and 14. Both ledgers parse; source IDs are unique; every per-case source ID resolves; every source belongs to a case; every entry has a URL and retrieval date. The checked exact-source blobs for Pydantic, Letta and Eliza agree with the blob IDs retained in the agent ledger. Ledger integrity is a navigation check, not proof that every substantive claim was independently reverified.

At initial review the specialist Markdown had 144 reference-definition lines for 72 unique labels. All duplicate targets were identical, so this did not create conflicting evidence identity. The root researcher removed the repeated block and retained the original report separately. Recheck confirmed **72 definitions for 72 unique labels**. The Pluggy release-table upload-date clause now also names `PLG-PYPI`, the directly relevant source ID.

**Smallest wording correction:** completed: one definition per unique source label, no source removal. No source count should be doubled because a Markdown block appeared twice.

**Residual uncertainty:** structural parsing does not validate every external URL's future availability or all claim-to-source relationships. Exact commits and symbols remain the recovery route.

### F-08 — First-result semantics were corrected in the synthesis

**Severity: low, resolved semantic wording issue.** Location: synthesis lesson 1.

The initial phrase “first nonempty result” was too broad for ADK/Pluggy. The inspected ADK implementation stops on any result that is not `None`; an empty mapping still counts. The detailed agent case already made that distinction. The root changed the synthesis to “first non-None result (ADK/Pluggy),” preserving the counterexample and preventing accidental truthiness semantics from being inferred.

**Smallest wording correction:** completed. This is a report precision repair, not an upstream behavior change.

## Independently checked primary source paths

All implementation links below contain the exact inspected commit. Test rows are **read, not run**. IDs match the researchers' ledgers except `C-PF4J-DEFAULT`, an auxiliary critic check used only to look for an entrypoint override.

| Source ID | Exact primary source and checked responsibility |
| --- | --- |
| `PYD-S1` | [AbstractCapability / CapabilityOrdering](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/abstract.py): presence-only contract, identity references and runtime-validation base seam |
| `PYD-S2` | [sort_capabilities and validators](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/_ordering.py): singleton return, presence validation and separate graph edges |
| `PYD-S3` | [CombinedCapability](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/pydantic_ai_slim/pydantic_ai/capabilities/combined.py): normalizer call into sorter and rebinding |
| `PYD-T1` | [Existing capability tests](https://github.com/pydantic/pydantic-ai/blob/e2332baaba4feb2c92f5ed47b7343374c2ba3546/tests/test_capabilities.py): two-child missing/present requirement assertions |
| `PF4J-MGR` | [AbstractPluginManager](https://github.com/pf4j/pf4j/blob/6ffa261f0e28f88a9115432482cad64979715a0d/pf4j/src/main/java/org/pf4j/AbstractPluginManager.java): manual/bulk startup, dependency gating, failure recording and unload |
| `C-PF4J-DEFAULT` | [DefaultPluginManager](https://github.com/pf4j/pf4j/blob/6ffa261f0e28f88a9115432482cad64979715a0d/pf4j/src/main/java/org/pf4j/DefaultPluginManager.java): no overriding startup route in the inspected default subclass |
| `PF4J-TEST` | [Existing manager tests](https://github.com/pf4j/pf4j/blob/6ffa261f0e28f88a9115432482cad64979715a0d/pf4j/src/test/java/org/pf4j/DefaultPluginManagerTest.java): required, optional and cascading single-start expectations |
| `PF4J-ASM` | [ExtensionInfo](https://github.com/pf4j/pf4j/blob/6ffa261f0e28f88a9115432482cad64979715a0d/pf4j/src/main/java/org/pf4j/asm/ExtensionInfo.java): inherited annotation lookup repair |
| `FST-OVERRIDE` | [Fastify plugin override](https://github.com/fastify/fastify/blob/0c7413a8332a7892e12dcc351c27a190fefc0053/lib/plugin-override.js): prototype scopes, selected child state and skip override |
| `HAPI-SERVER` | [Hapi Server](https://github.com/hapijs/hapi/blob/f2837a006535a6fbbcf33692067c1bd497ba8124/lib/server.js): shared-core clone, metadata-before-register and registration finally block |
| `NEST-MODULE` | [Nest Module](https://github.com/nestjs/nest/blob/59f33793c616eaf9669e8b81a35aa5f31accc5b4/packages/core/injector/module.ts): provider tokens and export eligibility |
| `NEST-DESTROY` | [Nest module destroy hook](https://github.com/nestjs/nest/blob/59f33793c616eaf9669e8b81a35aa5f31accc5b4/packages/core/hooks/on-module-destroy.hook.ts): reverse hierarchy, all-settled continuation and error logging |
| `PLG-MGR` | [Pluggy PluginManager](https://github.com/pytest-dev/pluggy/blob/4c7f6365f2dde09c11e72db67d0f615231d64c19/src/pluggy/_manager.py): prevalidation, historic replay caveat and exact unregister identities |
| `PLG-REL` | [Pluggy changelog](https://github.com/pytest-dev/pluggy/blob/4c7f6365f2dde09c11e72db67d0f615231d64c19/CHANGELOG.rst): dated ordinary validation and unregister repairs |
| `ELI-S3` | [Eliza plugin lifecycle](https://github.com/elizaOS/eliza/blob/74b8e6a22ef915680f55dd4018ee118d1018d33d/packages/core/src/plugin-lifecycle.ts): contribution capture, cleanup aggregate and registration catch |
| `LET-S1` | [Letta mod engine](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/mod-engine.ts): owner-specific cleanup, synchronous disposal and generation publication |
| `LET-S5` | [Letta tool registry](https://github.com/letta-ai/letta-code/blob/8ec417abb05a0d7f4c2b7be3968345fbc48da294/src/mods/tool-registry.ts): owner-checked removal and pre-invocation abort guard |
| `ADK-S2` | [ADK PluginManager](https://github.com/google/adk-python/blob/b33b43e5b5388b9454c71f440eb885901075f43a/src/google/adk/plugins/plugin_manager.py): non-None interception, notification exception scope and cancellation-aware close |

Additional primary metadata independently read: [ADK cancellation repair](https://github.com/google/adk-python/commit/f9558b36e8d70cb69978cd96b7abcd310691d125), [Eliza connector ownership repair](https://github.com/elizaOS/eliza/commit/7cbb4327b4d09cd7b7a358997841e84995b5ff33), [PF4J 3.16.1 release](https://github.com/pf4j/pf4j/releases/tag/release-3.16.1), [Pydantic 2.66.0 release](https://github.com/pydantic/pydantic-ai/releases/tag/v2.66.0), [Letta Code 0.34.41 release](https://github.com/letta-ai/letta-code/releases/tag/v0.34.41), their relevant Git ref endpoints, and PF4J's annotated tag object. The reports' existing ledgers remain the complete discovery/retrieval record; this table does not replace them.

## Publication boundary and retained uncertainty

The reusable result is the set of distinct questions: presence versus order, descriptor closure versus runtime readiness, namespace versus containment, exact owner versus bare name, and callback completion versus actual effects. Each has source-backed successful protections and limits. Their relevance to GM, EF, a product and the existing execution owner is conditional on the concrete selected seam.

The proposed minimal falsifiers would improve particular future decisions. They need not be executed to finish an honest source research report, and none qualifies thousands of third-party extensions, controlled restart, hostile isolation or production resource retirement. This critic recommends retaining the reports with the corrections and limits above, without asking the owner to approve an architecture on the basis of critic agreement.
