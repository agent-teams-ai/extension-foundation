# Research authority and prior-action audit

**Audit date:** 2026-11-05 UTC. **Status:** independent criticism and documentation recommendations; no architecture adoption, production implementation authorization, or qualification claim.

**Audited EF checkpoint:** `9f5ba60232c19e78022b40dddea71ab3aea1cdea`, draft PR55. The latest E2E continuation is the exact delta `2b10732..9f5ba60`; the wider research-PR comparison is main `29ae5b0269d9d83f071344e3e18761ded04ff53d` to that checkpoint. Findings below refer to those committed bytes, not subsequent in-progress edits by the parent agent.

## Conclusion

I found **no unapproved production plugin implementation in the latest E2E continuation**, and no accepted EF ADR body changed in either inspected delta. The latest delta contains nine documentation/index/evidence files only. Its executable additions are frozen research inputs inside evidence archives, not active product packages or an admitted runtime. I inspected all five new TypeScript files in the input archive, counted their 433 lines, and independently compared all ten retained A package files against the exact Orchestrator source tree. The original source, manifest and configuration match byte-for-byte.

The research generally preserves the required authority separation. The review record expressly defines its “Adopt” dispositions as corrections to research and future qualification, and the E2E record repeatedly distinguishes public-package invocation from production plugin Host, custody, restart and retirement qualification. Critic agreement and passing fixtures have not been presented there as permission to publish a new Host or SPI.

There are still **small but meaningful navigation and wording risks**: a research heading calls a recommendation a “Decision”; maintained navigation still foregrounds the earlier overlapping-worker target after controlled restart became the owner-confirmed baseline; an older review section gives now-superseded Orchestrator adoption instructions without a local historical label; and an active catalog open-decision retains a broad historical Fully Local/SQLite sentence that can misdirect product work. These can be corrected without rewriting accepted ADRs, asking the owner to select a framework, or creating another approval process.

## Method and evidence boundaries

Read inputs included the full task brief, retained Engineering Quality Standard, EF `AGENTS.md`, and its documentation-authoring skill. I read the research hub, review record, production-reload evidence, latest E2E record, controlled-restart authority section, hot-reload proposal, relevant boundary-experiment conclusions, current industry authority table, and relevant headings/claims in the other research memos. I also read EF's architecture overview, extension model, local FMS profile, decision/open-decision indexes, ADR-0011 applicability, ADR-0014, ADR-0015, inherited ADR-0013 package/extraction clauses, and OD-001/002/003. I checked the local Orchestrator ADR-0117 body, relevant ADR-0114/0115 clauses and OD-041.

Read-only verification comprised Git path/diff inspection, SHA-256 and member-ledger checks, archive source inspection, and comparison with the pinned Orchestrator Git tree. No packages were installed, compilers initialized, tests or research programs executed, or remote branches/comments/PRs changed. No archive was extracted onto a product checkout. The only created file is this assigned report.

Evidence classes in this report are **inspected source/document**, **verified retained bytes**, **retained execution report**, and **audit inference/recommendation**. Hosted execution counts below remain retained evidence; I did not rerun or freshly authenticate GitHub's run status. I did not exhaustively audit all historical research archive programs, every inherited safety-floor clause, whole repositories, or competitor implementations. This is an authority/provenance audit, not a new security or runtime correctness audit.

## What the prior E2E actually changed

### Latest continuation: `2b10732..9f5ba60`

The complete Git delta comprises:

- `docs/README.md` and `docs/research/plugin-system-research-reference.md` navigation;
- `docs/research/packed-extension-consumer-e2e-2026-11-05.md`;
- three `.tar.gz` evidence archives and their three JSON ledgers.

There are no active `packages/**`, application source, runtime dependencies, public exports, admission-policy implementation, accepted-ADR, or active workflow changes in that final delta. The report says the finite temporary hosted workflow was removed; this observation agrees with the final tree comparison. Its executed bytes remain archival evidence.

The frozen input archive has 29 regular members. Its new maintained source is exactly:

| Role | Archived path | Lines |
| --- | --- | ---: |
| Fixture B | `fixtures/extension/src/index.ts` | 32 |
| Fixture helper H | `fixtures/helper/src/index.ts` | 7 |
| TEST GM composition | `consumer/composition.ts` | 67 |
| TEST consumer | `consumer/consumer.ts` | 94 |
| Experiment driver | `src/e2e.test.ts` | 233 |
| **Total** | | **433** |

B implements the existing A source port with a fixture observation and fallback; H supplies fixture identity values. The TEST composition uses existing GM preparation/construction and explicitly selects B for the ambiguous consumer. The consumer invokes actual A discovery and compares independent instance bindings. The driver owns finite builds, packing, installs, child executions and literal result assertions. These programs do not implement product authorization, artifact custody, a production reload coordinator, process retirement or a new public SPI. Their global symbols are TEST evaluation markers, not an application service locator.

All ten `inputs/a/**` records in `inputs/provenance.json` match `git show 5a8496ce711909e381c5bc817fff5500be9a1761:<source path>` and the recorded SHA-256. Thus “unchanged copied A” is independently verified for the retained package source/manifest/configuration, not inferred from its filename.

### Wider PR55 is not prose-only

The full `29ae5b0..9f5ba60` comparison also changes Docs Protocol authoring configuration, metadata schema, qualification data, a research template, spelling/navigation and three existing `.mjs` test files. I inspected those non-prose diffs: they add the non-normative research document type and verify its supported create/index route. They do not implement a plugin runtime. Do not claim the entire PR changes documentation text only, or extend the E2E's “all new maintained code is strict TypeScript” statement to every pre-existing documentation-tooling test in the wider PR. The E2E statement is scoped to its own sources.

No `docs/decisions/**` or `docs/architecture/**` body is changed in that full comparison. OD-003 gains the explicitly owner-confirmed restart baseline, research links and clarified shared-code versus shared-authority wording; it remains `status: open` and says research cannot authorize a production Host.

### Retained evidence byte checks

The following archive hashes, exact regular-member sets, every member byte count and every member SHA-256 match their adjacent ledgers:

| Archive suffix | Regular members | Archive SHA-256 |
| --- | ---: | --- |
| `packed-consumer-e2e-20261105-inputs.tar.gz` | 29 | `61fc7aa6b921ce9e68ea8c52165aa08ca6f0f06efdae114e3a23bf779cbbd500` |
| `packed-consumer-e2e-20261105-local.tar.gz` | 316 | `2d3e72a2d4fed1eca193e2365078ea564416ea341ad74bd59d3b7716f0d5522f` |
| `packed-consumer-e2e-20261105-hosted.tar.gz` | 33 | `0e83c4739a323619212b892ff0190bffb4daee737602a9d589d3ddba4250bdc3` |

The hosted ledger and retained `HOSTED-EVIDENCE.md` identify run `42099097668` at `11fa2e2450a8aba62823544fc3129318918e9696`, with the same ten named scenarios on four profiles and eleven passes including the enclosing test per profile. This is forty scenario executions of ten definitions. It is not a measurement of production reliability. My outer-member checks include the original ZIP bytes, but do not constitute a fresh inspection of remote dependency stores or a repeat of every nested hosted artifact review.

Primary source: [E2E record at the audited EF checkpoint](https://github.com/agent-teams-ai/extension-foundation/blob/9f5ba60232c19e78022b40dddea71ab3aea1cdea/docs/research/packed-extension-consumer-e2e-2026-11-05.md), especially “Scope and authority,” “Executed local result,” “Completed hosted validation,” and “Remaining product boundary.”

## Existing authority, rather than new research decisions

| Concern | Actual owner/source | Audit disposition |
| --- | --- | --- |
| Neutral composition identities, bindings, immutable plans and construction | EF ADR-0015, especially “Independent Get Modular ownership” and “Separate authorities” | Already accepted. A product adapter may use both cores; neither core imports the other. Research cannot grant new product activation authority. |
| Product authoring and future generation constraints | EF ADR-0014, “Decision” and “Future enable, disable, and replacement” | Already accepted constraints. The ADR expressly does not authorize a production runtime, graph Host, package or public SPI. |
| Production extension safety floor | EF ADR-0011, “Cumulative floor, applicability, and non-authorization” | Conditional on a separately admitted product capability/profile. Ordinary libraries, static Pure DI and GM construction are expressly outside it. Do not charge its complete durability machinery to every extension point. |
| Static composition with controlled restart; optional Temporal rollout adapter | Supplied owner instruction, dated 2026-10-25; retained in EF OD-003 and `static-composition-and-controlled-restart-validation.md` | Confirmed direction, not an inference from a critic or test. Does not select an overlap-safe worker runtime, public SPI, exact production distribution or state migration. I verified the retained recording, not the original private conversation independently. |
| Current Orchestrator module baseline | Accepted Orchestrator ADR-0117/0113 at the retained `5a8496ce...` snapshot | Core/Assembly 0.5.0 and CMS `a3a079...`; ADR-0117 explicitly supersedes ADR-0110's other pin. Current GM main/npm and research 0.7.0 fixtures cannot silently migrate it. |
| Native PostgreSQL and Fully Local V1 | Accepted Orchestrator ADR-0114/0115 | Product direction is settled. Catalog/offline-search research does not reopen SQLite as canonical product storage. |
| EF production adoption | Orchestrator OD-041, “Required proof before production adoption,” resolved architecturally by ADR-0096 | Two independent product integrations and its other actual production proofs remain required. A private ordinary package, GM adoption fixture or this packed experiment does not satisfy all of them. |
| Public EF SPI/Host/state choices | EF OD-003, still open; architecture overview “Package Admission” | Exact capability, contract/profile and publication remain owned choices. Existing package admission, stable SPI publication and product production adoption are distinct gates. |

Sources: [EF ADR-0011](https://github.com/agent-teams-ai/extension-foundation/blob/9f5ba60232c19e78022b40dddea71ab3aea1cdea/docs/decisions/0011-extension-admission-custody-and-retirement-closure.md), [ADR-0014](https://github.com/agent-teams-ai/extension-foundation/blob/9f5ba60232c19e78022b40dddea71ab3aea1cdea/docs/decisions/0014-product-local-module-authoring-composition-and-generation-guardrails.md), [ADR-0015](https://github.com/agent-teams-ai/extension-foundation/blob/9f5ba60232c19e78022b40dddea71ab3aea1cdea/docs/decisions/0015-authorize-get-modular-semantic-extraction.md), [EF OD-003](https://github.com/agent-teams-ai/extension-foundation/blob/9f5ba60232c19e78022b40dddea71ab3aea1cdea/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md), [Orchestrator ADR-0117](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/docs/decisions/0117-reconcile-mandatory-module-composition.md), [Orchestrator OD-041](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/docs/open-decisions/OD-041-shared-extension-foundation-and-artifact-distribution.md).

## Targeted findings and smallest corrections

### RA-01 — A research recommendation has a decision-shaped heading

**Location:** `production-reload-system-evidence.md`, lines 13–15, “Decision in one paragraph.” The paragraph opens “Use independently constructed generations…” and later explicitly calls these recommendations. Lines 11 and 15 deny architecture approval; “Cross-system obligations” also labels its checklist inference/recommendation at lines 130–132.

**Finding:** No actual accepted decision changes here, but the heading and opening imperative can be copied out of context as a current selected runtime. This is a terminology hazard, not proof of unauthorized adoption.

**Smallest correction:** Rename the heading to “Research recommendation for an admitted replacement profile.” Open with a conditional formulation: “If an owning product later admits executable replacement, evaluate independently constructed generations…” Preserve the source analysis and the existing distinction between ordinary static composition and a selected production replacement profile. Do not turn the suggested checklist into a mandatory gate for routine modules.

### RA-02 — Maintained navigation foregrounds an older stronger target

**Location:** `plugin-system-research-reference.md`, lines 69–72 (“The first hot-replacement target remains…”), and lines 159–165 (“concrete next research and qualification target” recommending a Node worker). Compare its own owner-confirmed restart statement at lines 37–40, OD-003 “Owner-confirmed baseline, 2026-10-25,” and restart validation “Confirmed direction,” which explicitly permits downtime and promises no overlapping generations.

**Finding:** An optional hot-replacement research hypothesis can coexist with the approved restart baseline. The current “first/next target” navigation nevertheless risks making the older stronger worker scope seem the required next task. This is a priority/authority ambiguity; no contradiction requires replacing the accepted baseline.

**Smallest correction:** Add a short dated note immediately above the qualification target: controlled restart is the confirmed baseline; the 2026-10-21 overlap-safe worker proposal remains unadopted comparative research and is pursued only if an actual capability's needs justify it. Replace “next” with “optional.” Keep its exact numeric proposed envelope labeled unmeasured and unapproved; no new experiment is required for this wording repair.

### RA-03 — Historical adoption instructions need a local current-authority route

**Location:** `plugin-research-review-and-decision-record.md`, lines 23–37: “Recommendation and authority,” “Verified baseline and adoption provenance,” “mandatory GM/static FMS…under ADR-0110,” “Stack the research patch on PR86,” and the `ddf1e0b` adopted pin. Its “Current disposition” is dated 2026-10-25 and does not locally mention the later ADR-0117. The hub and November industry review already supply the correct later map.

**Finding:** Those sentences are sound historical evidence for the October cut, but their section titles and imperative integration instruction can mislead readers who enter directly from a link/search. Accepted ADR-0117 explicitly supersedes ADR-0110, preserving the old bodies and installing no upgraded package. This is a stale local adoption-map gap, not permission to edit either accepted ADR.

**Smallest correction:** Add a dated 2026-11-05 current-authority note linking ADR-0117/current industry authority before the historical section. Mark the October recommendation/baseline sections explicitly historical; preserve their pins, hashes and original integration analysis. Do not “fix” those hashes to new values or convert the old PR instructions into current commands.

### RA-04 — Active catalog wording can be mistaken for product V1/storage authority

**Location:** EF `docs/open-decisions/OD-002-catalog-security-and-offline-operational-parameters.md`, “Constraints,” lines 32–33: “Fully Local Desktop is outside V1. Its future SQLite and offline snapshot adapters…” Compare accepted Orchestrator ADR-0115 “Required V1 profiles and bounded supersession” and ADR-0114's native PostgreSQL adoption.

**Finding:** This active wording is at least ambiguous about its owner/scope and becomes false if read as current Orchestrator release scope or canonical storage. It is not evidence that the current product uses SQLite. EF accepted ADR-0003 separately retains its original catalog rollout scope and a possible later SQLite FTS5 catalog-search adapter (lines 44–56). Optional catalog search/snapshot use is not canonical product persistence, and Orchestrator's broader Fully Local release direction does not automatically deliver every catalog offline feature.

**Smallest correction:** Narrow the active OD-002 clause to unresolved catalog snapshot/offline operating profiles and their common conformance; say product V1 scope and canonical storage remain with each consuming product's accepted decisions, pointing to Orchestrator ADR-0114/0115 for that product. Preserve accepted ADR-0003 unchanged. If a future task actually changes EF's accepted catalog search/deployment choice, use its scoped successor process then; this research task needs no storage choice or new implementation.

### RA-05 — “Adopt” is already defined correctly; optional local clarity is sufficient

**Location:** review record, “Dispositions,” line 55: “Adopt” means incorporate research/qualification correction, not accept a new architecture decision. Its follow-up at lines 164–166 similarly defines “Incorporated.” The reusable-mechanisms memo uses “Adopt when” in its Piscina/workerpool sections and “Adopt” for tableflip, while its “Review outcome” says Piscina is not selected. Boundary experiments has “Decisions supported by this round,” lines 445–459, followed by zero production/product integration at lines 461–465.

**Finding:** The review dispositions do not create architecture authority and should not be reported as an adopted runtime. Conditional library-fit advice is also not an actual dependency selection. The labels remain easy to overread when excerpts are detached.

**Smallest correction, advisory:** Preserve the historical disposition table; either keep its existing explicit definition or label future dispositions “Incorporated into research.” Change conditional library labels to “Consider only when” and the experiment heading to “Conclusions supported by this round” when those exact sections are next edited. No global search-and-replace, retroactive decision lifecycle, or new approval ritual is needed.

## Remaining gaps that should stay explicit

The packed E2E record correctly leaves the actual materialized plugin consumer/configuration surface, artifact-to-executor custody, restart/drain, long-running resource envelope and hostile isolation unqualified. Passing independent instance binding does not settle any of those. The prior PB-02 verified-path replacement counterexample stays relevant until the real custody owner enforces its actual contract.

A separate existing tooling conflict remains: `plugin-industry-and-scale-review-2026-11-05.md`, “Retained review and reproduction material,” lines 392–398 records managed Foundation 1.7.2 initializing API Extractor 7.58.12/TypeScript 5.9.3 against the current organization requirement for TS 7.0.2+, including embedded copies. The E2E “Toolchain audit” records the managed Cohort and separate owning upgrade/qualification route. Hosted green results and the independent native E2E compiler do not resolve that policy/adoption gap. I verified these recorded claims and scopes; I did not initialize the blocked CLI or freshly inspect every resolved installed dependency. Do not weaken the gate or repin one managed component to make the research appear complete.

Research preservation is in good shape for this slice: dated pins, original failures, corrections, explicit test limits and digest-bearing archives remain available. The hub already instructs future agents to retain repaired incidents, avoid equating closed issues with fixes, and compare measured envelopes rather than plugin count or popularity. Keep that discipline in the new framework cases; a framework specializing in modularity supplies mechanisms to evaluate, not authority to adopt its manager, lifecycle, global state or stack.

## Owner input and scope

**No new material owner decision is required to finish the documentation/research task or apply RA-01–04.** The confirmed baseline and accepted ownership are already supplied. These findings propose no production code, integration or test implementation, so their incremental production/integration/test LOC are all zero; numerical reliability scores would imply a technical alternative that this audit has not proposed.

Before a later production extension slice, the existing OD-003 still needs the actual capability and its availability/trust/deployment/lifetime scope. That is not a newly discovered question and should not be put to the owner merely because twelve more frameworks were studied. Once there is a concrete unresolved alternative, present scoped options with confidence/reliability/complexity `/10`, production versus integration versus test LOC, assumptions and release cost. Until then, keep transfer hypotheses explicitly unadopted and do no implementation.
