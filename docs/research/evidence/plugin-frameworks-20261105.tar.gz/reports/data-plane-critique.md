# Independent critique: Collector and APISIX research

**Date:** 2026-11-05 UTC. **Reviewed inputs:** `data-plane-frameworks.md` and `data-plane-frameworks-sources.json` as first supplied by root, plus their exact pinned source. **Status:** research criticism, not adoption or implementation authorization. No tests, compilers, component runtimes or plugin reload operations were executed.

## Disposition

The two cases are useful and substantially source-faithful. In particular, the report correctly avoids two tempting errors: calling this Collector release static-only, and interpreting APISIX's Lua hot-loading path as an atomic rollout/custody guarantee. Both comparisons preserve deliberate tradeoffs and keep transfer hypotheses unadopted. No framework selection or new owner decision follows from them.

Before publication, make three small semantic corrections: distinguish Collector startup order from application readiness; retain the source's actual MUST/SHOULD strength for shutdown; and describe the connector analogy as cross-signal/pipeline role separation rather than an automatically discovered DDD boundary. Tighten the proposed falsifiers' preconditions so a permitted controlled-restart interruption, APISIX request-level disabling, or intentional shared backpressure is not counted as a defect. These are documentation refinements, with zero production/integration/test implementation authorized.

## Independent verification and limits

All 13 cached files reproduce the Git blob hashes recorded in the ledger. I independently fetched Collector `graph.go`, `collector.go`, `service.go`, `component.go` and APISIX `plugin.lua`, plugin terminology, development guide and threat model at the report's exact commits; their returned blob identities match the ledger. I additionally inspected the extension-order, extensions, traces fan-out, builder and selected graph-test source in the verified cache. No external source cache is added to this report or proposed for redistribution.

The release identity claims also check out:

- Collector's release metadata names `v1.70.0/v0.164.0`, published 2026-10-26. Its annotated `v0.164.0` tag object `6806e4e62374e5ef5acaeac64e46c090778b77a4` peels to `f532e15ef29b6ed7fefad2b23a0fefd27120ef9b`.
- APISIX release `3.19.0` was published 2026-09-28; its tag directly resolves to `473043623c161966f3f6ef4e8f12d2d8667a12d2`.

I opened the three moving OpenTelemetry documentation pages in the ledger. Their custom-distribution, shared-flow and historical connector explanations support the report. Their current examples are not release pins. I did not independently recheck the report's observed moving main/master SHAs, authenticate release binaries, run upstream tests, inspect every APISIX reload caller, or audit every Collector component's implementation. The review supports the named mechanisms, not fleet capacity, hostile isolation or whole-system availability claims.

Release sources: [Collector release metadata](https://api.github.com/repos/open-telemetry/opentelemetry-collector/releases/tags/v0.164.0), [Collector annotated tag](https://api.github.com/repos/open-telemetry/opentelemetry-collector/git/tags/6806e4e62374e5ef5acaeac64e46c090778b77a4), [APISIX release metadata](https://api.github.com/repos/apache/apisix/releases/tags/3.19.0), [APISIX tag ref](https://api.github.com/repos/apache/apisix/git/ref/tags/3.19.0).

## DP-01: source-supported findings and necessary precision

### DPC-01 — Keep the actual receiver partial-reload mechanism

**Disposition: supported; retain the correction against a static-only characterization.**

`service.ReceiverPartialReloadEnabled` requires both `service.partialReload` and `service.partialReloadReceivers`. The additional generated registry source identifies them as Alpha and Beta respectively; the report's service-source citation already documents those stages, and adding the registry URL to the ledger would make the mechanical declaration directly discoverable.

`Graph.UpdateReceivers` partitions unchanged, removed, rebuilt and added receivers. It closes affected existing receivers before replacement construction/start. `Collector.reloadConfiguration` explicitly handles a partial reload failure by falling through to full service shutdown/reconstruction because the graph may already be modified. Thus the report is right to deny both a universal hot-swap protocol and an unconditional old-generation-keeps-serving promise. Fallback itself can fail; it is a recovery attempt, not guaranteed restoration of the previous graph.

Do not transfer the presence of upstream feature gates into a proposed default product flag. This case supplies a bounded mechanism and its stage, while our task still authorizes research only.

Sources: [service.go, ReceiverPartialReloadEnabled/UpdateReceivers](https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/service.go), [generated_feature_gates.go](https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/internal/metadata/generated_feature_gates.go), blob `55d289632adf3bac28f591381cdfa8f3d8c2854c`; [collector.go, reloadConfiguration/tryPartialReceiverReload](https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/otelcol/collector.go), lines 289–363.

### DPC-02 — Startup ordering is not an arbitrary component readiness proof

**Location:** DP-01 numbered finding 3, titled “Readiness and shutdown follow data dependencies.”

**Correction:** Call it “Startup and shutdown ordering follow data dependencies.” The source intentionally permits a component's long-running startup activity to proceed in the background after `Start` returns. Reversing graph order can therefore establish startup-call ordering and protect an eager producer in the tested contract; it cannot by itself establish a ready remote dependency, completed background handshake, or business readiness.

Finding 5 correctly separates `PipelineWatcher` notifications from extension startup. Preserve that distinction and also state that returning from an arbitrary start callback is not a universal product readiness receipt. This improves the analogy without alleging an upstream bug or requiring an extra generic readiness manager.

Source: [component.go, Component.Start](https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/component/component.go), lines 26–43.

### DPC-03 — Preserve normative strength and failure semantics

**Location:** DP-01 numbered finding 4, “Component.Shutdown must … stop accepting data … flush buffers before returning.”

The source uses mandatory wording for safe invocation in the named states and terminating background operations; stop-accepting and buffer-flushing clauses use advisory wording. Summarize this as “documents safe repeat/no-start shutdown, cessation of ingress, background cancellation and buffer flushing,” or explicitly preserve the respective strength. Avoid promoting every comment to a MUST.

The report already says a signature cannot enforce completion. Retain that limit. Nor does a buffer flush necessarily prove remote durable acknowledgement or physical absence. Those stronger product assertions require their actual owner and evidence.

### DPC-04 — The eager shared-receiver test has a useful, narrower lesson

**Disposition: the inspected-test description is accurate.** `TestSharedReceiverStartOrder` uses ten alternate names/orders and fails startup if an eager receiver reaches an exporter before startup. The receiver factory intentionally returns one shared physical receiver across otherwise distinct configured receiver IDs. This explains why the global receiver-after-non-receiver ordering matters beyond one obvious graph edge.

This is a strong counterexample to “distinct descriptors always mean isolated implementation state.” It is not a reason to add hidden alias detection or another composition graph to EF. If a real product adapter wraps a shared underlying engine, its instance/resource owner must declare the actual sharing and startup promise. The report's factory-state caveat is therefore valuable and should remain.

The four named `TestUpdateReceivers...Error...` cases inspect shutdown-on-remove, shutdown-on-rebuild, construction and startup error returns. They do not alone prove full Collector fallback, successful rollback or old-service availability. The report does not claim that they do; keep that restraint.

Source: [graph_test.go](https://github.com/open-telemetry/opentelemetry-collector/blob/f532e15ef29b6ed7fefad2b23a0fefd27120ef9b/service/internal/graph/graph_test.go), `TestSharedReceiverStartOrder` at lines 3638–3713 and failure cases at lines 3515–3590. These tests were read, not executed.

### DPC-05 — Connector roles do not automatically identify bounded contexts

**Location:** DP-01-H3, “dedicated boundary for an actual cross-domain transformation.”

The concrete precedent is a component acting at the join between telemetry pipelines/signals, replacing processor behavior that directly exported another signal. That supports explicit role/translation ownership. It does not establish that traces and metrics are separate DDD bounded contexts, or that every product transformation needs a connector package.

**Smallest correction:** Say “cross-signal or pipeline transformation” for the source; keep the product transfer conditional on a real contract boundary. When an actual product context boundary exists, the consuming context owns its translation port/anti-corruption mapping under existing architecture. No new universal connector interface or EF domain model follows.

Source: [official connector tutorial](https://opentelemetry.io/docs/collector/extend/custom-component/connector/), “Why use a Connector?”, retrieved 2026-11-05; this is moving documented history, not a fix reproduced by this research.

## DP-02: source-supported findings and useful guardrails

### DPC-06 — The Lua loader observation is sound and intentionally bounded

**Disposition: supported.** `unload_plugin` invokes the old optional destroy hook and removes the Lua package cache entry; the HTTP list loader clears the previous tables and then loads selected modules. `load_plugin` uses executable `require` before its field checks, and inserts an accepted plugin before calling optional initialization hooks. The source also skips stream initialization in the HTTP schema-validation subsystem.

That supports the report's teardown-before-reload observation for the inspected Lua branch. It does not prove a fleet outage or the fate of already captured request references. A require failure is handled locally; an initialization/destroy hook's wider failure behavior is not established by the report's limited caller inspection. The code has a distinct Wasm branch, and external runners are separate mechanisms. Keep all three distinctions explicit.

The appropriate lesson is accurate phase/resource promises under a stated trust/deployment profile. Do not call `destroy`, cache removal or initialization an artifact-custody, drain or process-exit receipt. A deliberate trusted-worker loader should not be judged against an unadvertised hostile-code or zero-downtime contract.

Source: [plugin.lua](https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/apisix/plugin.lua), `unload_plugin`, `load_plugin`, `load`, `load_stream`, lines 179–378.

### DPC-07 — Ordering is a declared customization tradeoff, not a missing universal DAG

The report correctly distinguishes phase ordering, numeric priority and same-plugin local configuration precedence. A local scope selects one configuration; it is not arbitrary deep merging. Global/local instances can both run, with documented policies such as `prefer_route` providing exceptions. The existing cautious “can” wording is appropriate.

Do not turn the lack of a general dependency DAG into a claimed APISIX defect: its request phases and trusted operator are the intended boundary. The useful transfer to GM/product extension points is to state each contract's cardinality, conflict policy and operation semantics. GM neutral binding ownership remains intact; product execution order does not move into an EF global priority table.

Sources: [plugin terminology](https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/terminology/plugin.md), “Plugins merging precedence” and “Custom plugin priority”; [development guide](https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/plugin-develop.md), “Others.”

### DPC-08 — Trusted operator scope is positive counterevidence

The pinned threat model expressly places operator-supplied Lua and external runners inside the operator trust assumption. The report fairly preserves this intentional scope and does not equate an external process with hostile-user containment. Its private-method-hook caveat is also conditional rather than an accusation that supported APISIX plugins depend on monkey patching.

For our product, authorization/invariants remain outside ordinary plugins. That is an existing accepted requirement; APISIX's operator-controlled extensibility cannot override it. A proposed ordinary wrapper needs to pass the owned policy/effect boundary rather than carry the authority to bypass it. The hypotheses already say this in substance; no new platform component is necessary.

Source: [security threat model](https://github.com/apache/apisix/blob/473043623c161966f3f6ef4e8f12d2d8667a12d2/docs/en/latest/security-threat-model.md), caller roles and operator-supplied-code scope.

## Falsifier quality: useful after naming the promised contract

The report correctly labels all scenarios unexecuted and says a real product contract is necessary. Strengthen that condition in any summary so these examples do not silently define a stronger target than the accepted controlled-restart baseline.

| Proposed observation | What must be specified first | Smallest useful outcome / interpretation |
| --- | --- | --- |
| Blocked downstream delays another request | Whether independent progress is promised; actual shared thread/queue/engine boundary | Hold one owned callback and observe a specifically promised independent operation. Shared backpressure is an expected tradeoff when declared, not automatically a failure. |
| Eager producer runs before consumer readiness | Exact readiness criterion, not just start callback return | Hold the consumer's readiness proof and confirm ingress has no authority to deliver ordinary work. This tests an owner promise without reimplementing Collector. |
| Shutdown error becomes successful retirement | Actual report type and custody owner | Cause one known owned cleanup obligation to fail and inspect whether the result falsely asserts completion. Preserve independent physical-exit evidence. |
| Shared mutation crosses tenants | Whether sharing is intended and exact data/grant scope | Mutate one explicit instance/state cell and inspect only the other tenant's forbidden view. Do not infer tenant isolation from descriptor count. |
| Enumeration changes effective provider behavior | Whether ties are rejected, ordered explicitly or intentionally unspecified | Require identical output for equivalent declared inputs, or a deterministic refusal. Do not use an undeclared tie expectation as the oracle. |
| Failed candidate removes active implementation | Whether the actual profile promises preservation of old availability | A documented controlled restart can have interruption. Only test old-continues-serving if separately selected; otherwise test the declared failure/recovery result and absence of false readiness. |
| Disabled plugin executes during discovery | Whether disabled means absent executable selection, or merely skipped request invocation | Use an explicit unselected/inert-admission promise and top-level marker. APISIX `_meta.disable` concerns request execution and does not by itself promise the Lua module was never loaded. |

These are not seven newly required experiments. The most immediately relevant transfer is one eager ingress/consumer/cleanup join at an already selected product seam, if it exposes uncertainty not covered by retained restart/admission evidence. Existing GM/public-consumer and PB-01 evidence should be reused when inputs and claims are unchanged. There is no justification to build a generic manager, hot-reload prototype or broad load suite merely to make this research concrete.

## Ownership and decision impact

DP-01-H1/H2 map to product runtime/resource semantics and existing execution custody; neutral graph construction stays in GM. DP-01-H3 maps to an actual consuming contract if one is demonstrated. DP-02-H1/H2 map to each product's narrow extension point and author diagnostics. EF keeps neutral artifact/trust/protocol/conformance vocabulary without acquiring scheduling, grants, state or a priority registry.

There is no new material alternative requiring owner input in this read-only comparison. Making the source and hypothesis wording precise adds no production, integration or test code. Estimates or `/10` reliability scores for adopting either framework would be fabricated without a real intended integration. Preserve the report's refusal to invent them, retain the cases with dates/pins, and leave implementation behind the already owning accepted decision.
