# Bounded publication-gate failure review

Review date: **2026-11-05 UTC**. Scope: retained gate log, the failing existing test and helper, package script, publication doctor log, tree receipt and read-only Git status. No repository/tool-state edits or test execution were performed. This report is the only artifact written by this review.

## Verdict

**One full `pnpm docs:protocol:check` verification of the final publication tree, with unchanged scripts, test/tool/dependency identities and the existing 120,000 ms timeout, is a reasonable bounded next step after other filesystem work ends.** Retain the original failure and original tree receipt. The first run remains failed; neither a transient/environment explanation nor a passing publication gate has been established. A later pass would establish that later run's result, without erasing the timeout or proving its cause.

The proposed **separate clean verification checkout** is a sound bounded option: incorporate the failure receipt into the final reviewed documentation/archive, record its resulting Git tree, materialize that exact tree, perform the normal frozen offline install without changing pins, then run the complete consumer command once. Preserve both authoring checkouts and all tool evidence untouched. This tests the actual intended published checkout without inherited untracked authoring artifacts. It does not bypass recovery, weaken a gate or repair/delete transaction evidence in the original checkout.

That option is a final-tree verification, **not an identical-local-input reproduction**: checkout paths, final evidence bytes and inherited untracked inputs differ intentionally. A targeted-only rerun would not replace the required full consumer gate. Repeated reruns until green would exceed this bounded plan. If this single full verification also fails, retain both results and report publication blocked by that gate; do not weaken it or launch an unrelated investigation under this task. No third reproduction is proposed.

## What the evidence supports

The [retained log](../publication-full-docs-gate.log) shows `docs.check` success with a complete 84-document catalog and valid adoption; Markdown lint and spelling both report zero issues across 90 files. The contract phase reports **7 passed, 1 failed, no skipped/cancelled tests**, total 290,870.648427 ms.

The failure is the existing test at `tests/document-authoring.test.mjs:156`, at its first successful-apply expectation on line 199. `run` asserts the spawned command's successful status; its diagnostic is `spawnSync .../agent-teams-docs ETIMEDOUT`. The helper's unchanged timeout is 120,000 ms. The test's reported 179,307.1906 ms includes earlier fixture/preview/stale-plan work, so it must not be reported as the duration of one child invocation.

The helper constructs a temporary consumer by copying `architecture`, `docs`, `.agents`, `AGENTS.md` and `package.json`, then linking the installed packages. The failing apply targets fixture `ADR-0099`, not a publication-repository ADR. A `finally` block removes the fixture. This confirms the intended isolation/cleanup path; I did not observe the deleted fixture or independently establish whether the timed-out child had partially written inside it.

The staged paths contain documentation, evidence and spelling/navigation changes. Neither staged nor unstaged tracked changes include maintained tests, package scripts, lockfile, architecture/tool configuration or `.agents`; the unstaged tracked diff is empty. The [tree receipt](../publication-tree.json) identifies parent `9f5ba60232c19e78022b40dddea71ab3aea1cdea` and staged tree **`c6dd27e9057bd3ef055f1820fdbc1d76edfb7da0`**. I read the receipt; I did not reconstruct its tree object in this review.

The [doctor log](../publication-doctor.log) reports successful doctor inspection and transaction `idle`. That is not a passing authoring contract test, a recovery result, proof that no temporary file exists, or evidence of the timeout's cause.

## Precise rerun input qualification

`disposableRepository` copies the **whole `docs` directory**, so the preserved untracked tool-owned temporary file is an input to the original fixture even though it is correctly excluded from the staged publication tree. Preserve that file unchanged in its original checkout. If verifying there, preserve it as a rerun input too; if using the proposed clean checkout, its absence is an explicitly different verification context. Do not delete, repair or rename it to obtain a pass. A Git tree identity alone does not capture the original local inputs or the installed tool/runtime context.

Read-only identities recorded during this review:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| Original `publication-full-docs-gate.log` | 2,569 | `5222124187c927109fbb408a5ac2c9d8d72ca3cbc97c44b3f4a12922d9ce207e` |
| Original `publication-tree.json` | 3,424 | `e93790482e380056099b7a74e5edf987180a5e9865e367a3fdf6fb924d923d5e` |
| `docs/research/.foundation-document-39a0ab8e275d6291a1d43795a1db7a4301dd7416464038127d0c8a0ecdddb336.tmp` | 926 | `d7d6511325477e2cb6f5e4e2a940bbd4186a99dd881fa343f94c07c6751552ce` |

The temporary-file fact is an input qualification, **not a finding that it caused the timeout**. Retain the same dependency/runtime identities already selected; the unchanged command and timeout should be explicit in the second log. Keep new gate-generated logs/receipts outside the tested tree during verification. The final published tree will differ from the initial receipt if failure evidence is incorporated before verification; record that final tree rather than attributing its result to `c6dd27e...`. Record the clean checkout's actual tool/runtime context and any tool-generated state instead of describing it as the original environment.

## Publication claim boundary

A defensible result would state both attempts and their exact outcomes, attribute a later complete pass only to its actual tested input/tree, and preserve the unresolved cause. Until such a result exists, the consumer gate is failed and no branch publication has been verified by this review. This documentation-only timeout does not establish a production plugin implementation defect, architecture adoption, or a reason to revise accepted authority.
