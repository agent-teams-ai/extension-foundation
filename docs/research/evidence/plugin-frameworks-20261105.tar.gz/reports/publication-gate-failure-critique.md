# Bounded publication-gate failure review

Review date: **2026-11-05 UTC**. Scope: retained gate log, the failing existing test and helper, package script, publication doctor log, tree receipt and read-only Git status. No repository/tool-state edits or test execution were performed. This report is the only artifact written by this review.

## Verdict

**One full `pnpm docs:protocol:check` verification of the final publication tree, with unchanged scripts, test/tool/dependency identities and the existing 120,000 ms timeout, is a reasonable bounded next step after other filesystem work ends.** Retain the original failure and original tree receipt. The first run remains failed; neither a transient/environment explanation nor a passing publication gate has been established. A later pass would establish that later run's result, without erasing the timeout or proving its cause.

The proposed **separate clean verification checkout** is a sound bounded option: incorporate the failure receipt into the final reviewed documentation/archive, record its resulting Git tree, materialize that exact tree, perform the normal frozen offline install without changing pins, then run the complete consumer command once. Preserve both authoring checkouts and all tool evidence untouched. This tests the actual intended published checkout without inherited untracked authoring artifacts. It does not bypass recovery, weaken a gate or repair/delete transaction evidence in the original checkout.

That option is a final-tree verification, **not an identical-local-input reproduction**: checkout paths, final evidence bytes and inherited untracked inputs differ intentionally. A targeted-only rerun would not replace the required full consumer gate. Repeated reruns until green would exceed this bounded plan. If this single full verification also fails, retain both results and report publication blocked by that gate; do not weaken it or launch an unrelated investigation under this task. No third reproduction is proposed.

## What the evidence supports

The [retained log](../publication-full-docs-gate.log) shows `docs.check` success with a complete 84-document catalog and valid adoption; Markdown lint and spelling both report zero issues across 90 files. The contract phase reports **7 passed, 1 failed, no skipped/cancelled tests**, total 290,870.648427 ms.

The failure is the existing test at `tests/document-authoring.test.mjs:156`, at its first successful-apply expectation on line 199. `run` asserts the spawned command's successful status; its diagnostic is `spawnSync .../agent-teams-docs ETIMEDOUT`. The helper's unchanged timeout is 120,000 ms. The test's reported 179,307.1906 ms includes earlier fixture/preview/stale-plan work, so it must not be reported as the duration of one child invocation.

The helper constructs a temporary consumer by copying `architecture`, `docs`, `.agents`, `AGENTS.md` and `package.json`, then linking the installed packages. The failing apply targets fixture `ADR-0099`, not a publication-repository ADR. A `finally` block removes the fixture. This confirms the intended isolation/cleanup path; I did not observe the deleted fixture or independently establish whether the timed-out child had partially written inside it.

The staged paths contain documentation, evidence and spelling/navigation changes. Neither staged nor unstaged tracked changes include maintained tests, package scripts, lockfile, architecture/tool configuration or `.agents`; the unstaged tracked diff is empty. The [tree receipt](../publication-tree.json) identifies parent `9f5ba60232c19e78022b40dddea71ab3aea1cdea` and staged tree **`c6dd27e9057bd3ef055f1820fdbc1d76edfb7da0`**. I read the receipt; I did not reconstruct its tree object in this review.

The [doctor log](../publication-doctor.log) reports successful doctor inspection and transaction `idle`. That is not a passing authoring contract test, a recovery result, proof that no temporary file exists, or evidence of the timeout's cause.

## Precise rerun input qualification

`disposableRepository` copies the **whole `docs` directory**, so the preserved untracked tool-owned temporary file is an input to the original fixture even though it is correctly excluded from the staged publication tree. Preserve that file unchanged in its original checkout. If verifying there, preserve it as a rerun input too; if using the proposed clean checkout, its absence is an explicitly different verification context. Do not delete, repair or rename it to obtain a pass. A Git tree identity alone does not capture the original local inputs or the installed tool/runtime context.

Read-only identities recorded during this review:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| Original `publication-full-docs-gate.log` | 2,569 | `5222124187c927109fbb408a5ac2c9d8d72ca3cbc97c44b3f4a12922d9ce207e` |
| Original `publication-tree.json` | 3,424 | `e93790482e380056099b7a74e5edf987180a5e9865e367a3fdf6fb924d923d5e` |
| `docs/research/.foundation-document-39a0ab8e275d6291a1d43795a1db7a4301dd7416464038127d0c8a0ecdddb336.tmp` | 926 | `d7d6511325477e2cb6f5e4e2a940bbd4186a99dd881fa343f94c07c6751552ce` |

The temporary-file fact is an input qualification, **not a finding that it caused the timeout**. Retain the same dependency/runtime identities already selected; the unchanged command and timeout should be explicit in the second log. Keep new gate-generated logs/receipts outside the tested tree during verification. The final published tree will differ from the initial receipt if failure evidence is incorporated before verification; record that final tree rather than attributing its result to `c6dd27e...`. Record the clean checkout's actual tool/runtime context and any tool-generated state instead of describing it as the original environment.

## Publication claim boundary

A defensible result would state both attempts and their exact outcomes, attribute a later complete pass only to its actual tested input/tree, and preserve the unresolved cause. Until such a result exists, the consumer gate is failed and no branch publication has been verified by this review. This documentation-only timeout does not establish a production plugin implementation defect, architecture adoption, or a reason to revise accepted authority.

## Dated scope clarification and clean verification observation — 2026-11-05 UTC

This addendum preserves the preceding verdict and original observations. It distinguishes **qualified publication/merge** from an explicitly authorized **research-only draft PR push for hosted verification**. The lead confirms that the user authorized ongoing commits and pushes to draft PR55. On that stated authorization, I find no concrete policy or task-scope objection to pushing the reviewed exact research-only head while clearly recording that the local full consumer gate is unverified. That does not declare qualification, merge the PR, release/promote an artifact, change dispatch policy or weaken tests, timeouts or dependency pins. The earlier caution against declaring a passing publication remains in force.

I independently read [verification-inputs.json](../verification-inputs.json) and [verification-full-docs-gate.log](../verification-full-docs-gate.log). The receipt identifies clean tree **`8c6ee173bc10ade8f842177332cb33c6d9723621`**, Node `v24.22.1`, pnpm `11.25.0`, docs-protocol `0.6.2`, docs-protocol-agent-teams `0.3.2` and Engineering Foundation `1.7.2`, with lockfile/package-manifest hashes. It records no untracked inputs before the gate and no test/timeout changes. I did not reconstruct that tree or independently re-audit all installed package bytes.

The second log shows catalog/adoption validation, Markdown lint and spelling passing, followed by **four reported contract-test passes**. It has **no terminal test summary or exit code**. The lead reports that the last output was at 22:34:40 UTC; at 22:41, polling session `3088` returned `Unknown process id`, and a read-only `/proc` inspection found no matching Node test/CLI process. I did not repeat those process/session observations or execute any additional command/test. They do not recover the missing terminal result or identify its cause.

The two local outcomes must remain separate:

| Attempt | Supported result | Unsupported conclusion |
| --- | --- | --- |
| Original publication checkout | Full command reported 7/8 contract tests passed and one fixture apply timed out; command failed | Proven temporary-file/environment cause, production defect, or passing gate |
| Clean final-tree verification | Docs validation/quality passed; four contract passes were logged; terminal outcome unavailable | Full gate passed, remaining assertions failed, timed-out again, or proven environmental termination |

Hashes independently calculated for the new retained artifacts:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `verification-inputs.json` | 941 | `4d07b773f3c96d52dae98e88aeb1cd2e80a32c8b00069f98e1b64f55260921b6` |
| `verification-full-docs-gate.log` | 1,032 | `10e27a2ee0643c38574590ce91190a88e6e9ab1c231cc90c6ae9bd0a239a7fa2` |

**Bounded continuation:** retain both local records, make no third local rerun, push only the authorized reviewed research changes into the draft PR with the local full-gate status disclosed as unverified, then observe the already configured hosted full CI/DocsProtocol gate. Tie any hosted result to the actual pushed commit/tree and that existing gate's complete result. A run for an earlier head, a partial log or a successful narrower check cannot supply the missing qualification. If recording this new evidence changes the final pushed tree, identify that new tree rather than attributing its result to `8c6ee173...`. Any later hosted pass is evidence for that exact hosted context; it does not explain or erase either local outcome.

I have not independently inspected the hosted workflow definition or observed a hosted run in this bounded addendum. No remote push, dispatch, workflow change, merge or release was performed by this reviewer. There is no basis here for another framework investigation or a weakened gate.
