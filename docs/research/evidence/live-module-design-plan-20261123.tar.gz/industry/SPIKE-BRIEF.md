# Prioritized industry spike brief

Status: source-reviewed proposal for root and ci_verification. Not a frozen executable plan, adapter adoption or policy selection. Baseline f285333c5869b1f69070efee29b205da8fd19e49; 2026-11-23 UTC.

## P1: actual Piral completion and ownership boundary

Use published piral-core/base 1.12.5 through root public entrypoints in one browser fixture. Existing public createInstance returns instance.context, with addPilet, removePilet and readState. config.loadPilet is a public hook. A pilet registers a real page through api.registerPage; observe the resulting registry through context.readState, without private-map mutation or a fake shell/event bus.

Source cohort: https://github.com/smapiot/piral/tree/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework . Current npm metadata for piral/core/base/debug-utils remains 1.12.5 at this gitHead.

Discriminating observations:

1. Old managed registration removal, candidate setup rejection and fulfilled addPilet can be distinct observations. Use actual async setup with a deterministic deferred rejection, and inspect public state/readiness independently.
2. Teardown has declared return type void, whereas setup allows Promise. A scheduled cleanup/resource can therefore outlive removePilet completion without violating an upstream Promise contract. Demonstrate a real listener/timer lifetime, not a synthetic disposal flag.
3. The page-registration disposer captures only a route; delayed old disposal after same-route v2 registration may remove the replacement. Extension disposal carries a reference identity. Qualify the page race specifically; do not label every Piral disposer unsafe.

These source predictions are not native results. Do not claim UI rollback, arbitrary old-work draining or all resource cleanup from this fixture.

## P1B: conditional cooperative resource bridge in the same campaign

Only if the public Resources 0.2.2 and Piral profiles pass the dependency/type audit, compare a narrow explicit bridge with the raw boundary. The bridge owns its readiness/cleanup acknowledgment extension, retains exact instance/resource identity, and delegates actual cleanup/debt to public Resources. It must not invent a scheduler, selection kernel, resolver or rollback engine.

The useful discriminator is whether old delayed cleanup can be observed and kept from destroying v2's resource/registration through the selected public contract. If the contract cannot express that without reimplementing Piral internals, preserve the unsupported result. Do not hide it behind private imports, skipping cleanup, or a synthetic receipt.

## P2: native Effect repeated close versus observed cleanup

Subsequent source inspection found a smaller second discriminator. Published effect 4.1.5 corresponds to release tag effect@4.1.5, source commit e3aca1f1484e623cee09b7f3fa18d6ff5d66c0e8. Public Scope.ts documents that closing an already-closed scope returns immediately even while an earlier close is still running finalizers. This is specified behavior, not a defect claim.

One Node case can hold a genuine finalizer on a Deferred, start close1 and wait until finalizer entry, then observe close2 completing before releasing the finalizer. A real owned listener or handle should still be live at that point. Release it, join close1 and observe actual cleanup. This discriminates an idempotent request from a joined completion receipt.

Root and ci_verification agreed to include this as the bounded second discriminator if its exact dependency/compiler profile is valid. It does not upgrade Get Modular's existing Effect peer profile or select native Effect for ordinary consumers. Source proposal is not executed evidence; the concrete plan and frozen input remain ci_verification/root-owned.

## Execution and fairness bounds

- Target one Piral browser campaign with two contract tests and at most six explicitly named ordered cases, plus the one bounded Node Effect case; ci_verification owns the concrete frozen plan and classification.
- Zero production LOC. Proposed fixture/bridge budget should be recorded before implementation, with bridge code counted rather than hidden as consumer glue.
- Compile maintained TS/TSX with TS >=7.0.2. Audit every installed compiler/parser dependency before execution; consume published JS rather than running upstream build scripts.
- Public Piral aggregate declares React/react-dom ^18 and router packages ^5.2; piral-core itself has no declared peerDependencies. Freeze a concrete React18/router5 cohort rather than inventing a peer guarantee.
- Preserve raw compiler/build/browser attempts, observations, assertions and exit receipts separately. Do not count observation rows as independent tests.
- Use the admitted hosted Chromium route; do not work around the earlier local socket-launch block.
- Root/independent review and frozen input push precede native execution. No rerun of MF4/4, SystemJS2/2 or previous editor/DB campaigns is proposed.
- Q1–Q7 remain OPEN. This is a specific contract comparison, not a complete plugin update E2E.

## Public source paths

- piral-core/src/index.tsx; createInstance.tsx; types/instance.ts; types/config.ts; types/state.ts.
- piral-core/src/actions/app.ts; actions/components.ts; modules/core.ts.
- piral-base/src/types/runtime.ts; lifecycle/setup.ts; lifecycle/cleanup.ts.

All paths above are below src/framework at the immutable commit stated above.
