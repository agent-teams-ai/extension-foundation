# Live Module Updates: detailed design delivery

Status: research and proposed specification. Owner request: 2026-11-23.
Starting Extension Foundation revision:
`f285333c5869b1f69070efee29b205da8fd19e49`.

## Intended result

Prepare the reusable project **live-module-updates** around one complete update
operation, ordinary TypeScript implementations first, with optional execution,
delivery, composition and UI integrations. Detail actual responsibilities,
invariants and failure outcomes before choosing implementation technologies.
The name describes the capability; repository creation and package-name
availability are separate observations.

External projects must be able to consume the library without Agent Teams
catalog credentials, an organization database schema or mandatory Effect.
Organization projects must still satisfy their accepted authorization,
artifact, generation, state and physical-custody contracts. A generic reusable
implementation does not become an additional authority.

The scope includes reusable/shareable plugin artifacts and eligible built-in
features. It does not imply that every helper, invariant or arbitrary dependency
can be replaced independently. Record an explicit replacement boundary,
dependency closure, continuity contract and supported fallback for each feature.

## Work lanes

| Lane | Question | Expected output |
| --- | --- | --- |
| Architecture | Which current public mechanism owns each responsibility, and what is missing? | Source-pinned Get Modular/Extension Foundation/Engineering Foundation map; proposed contracts and upstream deltas |
| Industry | What concrete implementation details transfer, and where do guarantees stop? | Source register, good patterns, counterexamples, tradeoffs and adapter conformance cases |
| Spikes | Which unresolved mechanism can a small native experiment discriminate? | Independently reviewed plan, frozen inputs, strict compiler evidence and raw execution results |
| Assembly | How does this become one discoverable standalone project? | Current specification, decision and technology registers, migration/provenance packet, repository bootstrap status |

Every lane writes its findings before final synthesis. Root reviews cross-lane
conflicts. Useful checkpoints are committed and immediately pushed; final
conclusions are reviewed again against exact published inputs and results.

## Specification requirements

1. Separate feature, module adapter, release package, plugin artifact,
   execution generation, dependency cohort and update attempt identities.
2. Model planning, candidate preparation, authoritative publication,
   reconciliation, useful adoption and retirement as separate responsibilities.
   Keep unknown publication outcomes distinct from rejection or failure.
3. Define narrow consumer primitives with semantic obligations and test oracles.
   Consumers must not reconstruct the orchestration from lifecycle callbacks.
4. Reuse the actual graph, resource scope, executor, state and durable workflow
   owner. A port may expose a capability; it cannot fabricate an unavailable
   public implementation or copy an upstream private kernel.
5. Distinguish registration ownership, running work, write authorization,
   resource cleanup, history, artifact retention and physical executor exit.
6. Keep native Effect semantics in an optional profile. Keep Wasm Component
   Model and Extism as different execution contracts. Module Federation,
   Native Federation, Piral and OpenComponents belong at their actual loading,
   delivery or contribution boundary rather than one universal runtime port.
7. Detail module-authoring seams needed now, and implementation that should wait
   for a selected consumer and evidence. No speculative public package skeleton.
8. Translate every proposed pattern into an owned responsibility and at least
   one adverse conformance case; a design-pattern name alone proves nothing.

## Decisions that remain open

The existing Q1-Q7 matrix remains authoritative for trust, dependency sharing
and update units, state continuity, visible adoption, admitted work, rollback
meaning and old-client support. Conditional scenario choices are not defaults.
This delivery can propose alternatives and expose incompatible combinations;
it must not silently resolve those owner choices.

The first complete-library consumer, its admitted profile, the package/public
API boundary, publication of missing lifecycle primitives and standalone
repository admission remain explicit work. An accepted Agent Runtime provider
journey is not reopened merely because this new library still lacks its first
qualified whole-operation consumer.

## Native experiment gate

Before running new code, retain the question, exact public APIs and dependency
cohort, independent positive/negative oracles, source/build identities and code
budget. Independently review the plan and implementation; push the frozen inputs
before execution. Inspect embedded compiler/parser versions as well as the
workspace compiler. New maintained JavaScript-runtime code is strict TypeScript
7.0.2 or newer; upstream published JavaScript is an artifact, not new authored
implementation. Do not execute an older embedded compiler to make a gate pass.

Prefer one bounded public Piral lifecycle/registration campaign and, if the
exact qualified dependencies permit it, one narrow native resource-completion
comparison. Do not rerun old MF, SystemJS, editor or database campaigns as new
coverage. Source predictions, test observations, asserted cases and test-file
counts are different evidence. Preserve failed attempts and limitations.

## Standalone bootstrap

The organization standard requires new production libraries to adopt full FMS
v1.1 and Foundation coverage through the first reviewed bootstrap. A transferred
research packet, installed dependency or passing configuration check is not
that adoption. Current source, registry availability, qualified package cohort,
consumer checks and enforced remote checks are separate facts.

Use the official repository-admission and registration routes. Route AGENTS and
CLAUDE to the central rules; do not copy a competing policy. Foundation remains
development-only. Keep evidence archives and source pins immutable. Do not copy
another repository's managed Docs projection or select a package from an old
catalog instead of an eligible qualified cohort.

Creation capability observation: the connected GitHub API currently has no
repository-creation operation; `gh` is unauthenticated; the browser extension
requires the originating connected browser context. Continue preparing and
publishing the concrete project material in the existing research branch.
Never claim that a remote exists before independent repository readback.

## Completion review

- Current architecture and technology status are discoverable without reading
  every historical report; sources and historical failures remain reachable.
- Every implemented spike is bound to exact inputs, dependencies, meaningful
  oracles and a real result; blocked or deferred cases remain so.
- Public API availability is checked, including withdrawn/superseded decisions.
- Proposed upstream changes are separate from accepted contracts and defaults.
- Retained source and review files have a content manifest; links and governed
  documentation gates pass on the final source.
- Every commit is published immediately, and final hosted checks are observed.
- Repository creation, admission, runtime qualification and product acceptance
  are reported at their actual state, without treating one as proof of another.
