# Cross-lane review — source claims and native-oracle boundaries

Reviewer: `/root/desktop_update`, 2026-11-22. Read root report/findings/source ledger; federation report/findings/source ledger and plan; delivery report/findings/source ledger, plan and current SystemJS fixtures/build script. No files owned by another lane changed, no fixture executed.

## Verdict

The current reports largely preserve the requested distinction between verified source facts, historical incidents, transfer inferences and owner choices. No native Envoy/Angular/Unreal or desktop execution is implied. No production framework/runtime, state store, restart deadline or trust profile is silently adopted. The issues below are concrete qualifications to carry into the synthesis and fixture freeze; they do not justify expanding the research into a new loader/coordinator.

## Corrections / qualifications

| Item | Location | Review finding | Required handling |
|---|---|---|---|
| X01 | Federation MF-F08 and REPORT §5 | “loaded-first defers entry work until demand” is broader than the inspected source branch. `initializeSharing` omits eager per-remote initialization unless version-first applies; explicit preload, bootstrap or an independent request can still load entries during startup. | Scope the sentence to the sharing-init path. Keep outage/error-hook qualification; do not claim a startup availability guarantee. |
| X02 | Delivery module identity paragraph / D-F02 | URL + module type is the key within a specific module map/settings environment. It is not a global object identity shared across realms, documents or processes. | Add the realm/module-map scope when synthesizing this with MF runtime instances and Electron document identity. |
| X03 | Delivery SYS-03 fixture | It waits only for `gate.started` after starting `pendingImport`. If linking/evaluation rejects before `markStarted`, the first failure can be obscured by timeout; node:test timeout does not inject an exception into the pending async function and guarantee its finally cleanup runs. | Race readiness with early import rejection/unexpected completion and the test abort/deadline, or an equivalent narrow fail-fast mechanism. Keep the primary failure in the receipt. No sleep-based success or generic retry coordinator needed. |
| X04 | Root final synthesis of cleanup / physical executor exit | Desktop evidence shows utility `exit(0)` during app shutdown can mean wrapper teardown while launch/process is pending. A generic “exit observed” result is too strong unless the adapter says which path generated it. | Keep physical termination, logical retirement and durable-state acknowledgement distinct. Do not infer the strongest receipt from event names. Root report already asks the right question; preserve it in the final matrix. |
| X05 | Aggregate qualification summary | Source findings, MF browser spike, SystemJS Node fixture, historical upstream fixes and older library E2E are distinct evidence sets. | Report separate counts/profile limits. Do not call successful upstream-loader fixtures completion of the library's production E2E. |
| X06 | Delivery retirement row / root architecture table | “Owned resources and references released” is meaningful only for a declared ownership boundary; arbitrary escaped references or external writes may remain. | Bound cleanup claims by owner/profile evidence. This is already reflected in retained-reference and effect-fencing discussions; avoid shortening it away. |

The lane owners received X01–X03 directly while their work was active. They retain ownership of the amendments.

## Positive controls and counterevidence that should remain

- **Envoy:** valid ACK can precede application failure, and NACK may coexist with accepted resources. Independent pinned xDS documentation review confirms both; the make-before-break dependency sequence and differing route warming are also supported. The report correctly avoids a generic atomic transaction or a replacement graph planner.
- **Angular:** independent pinned source review confirms serial asset-group initialization, per-client assignment, worker-client affinity, navigation handling and the BFCache caveat in cleanup. The statement that lazy/unhashed resources have separate limits is essential. Multiple simultaneously cached versions are a positive mechanism, not proof that every offline tab can recover indefinitely.
- **Angular worker headers:** pinned devops docs explicitly distinguish byte-identical installed worker from changed response headers and recommend a changed registration URL. Keep this as documented behavior, not a browser matrix or policy-manager recommendation.
- **Unreal:** its living documentation/version drift is openly recorded; reflected replacement, existing object defaults and retained-pointer cleanup stay scoped to the documented development workflow. No binary version is claimed tested.
- **Federation:** compatible singleton token identity is as important as strict mismatch; factory deferral is positive counterevidence to “loading always executes the exposed module.” Entry/init/get still run. Retained listener behavior should be called retained ownership, not a demonstrated memory leak or failed cleanup promise.
- **SystemJS:** actual published registry code intentionally returns a reconnect callback. Existing importer rebinding, escaped old values, absent/repeated callback guards and successful completion after a pending-delete denial are useful independent observations. The probe uses generated modules, not a handwritten replacement registry.
- **Storage/deployment:** S3 conditional updates and existing publisher/Workbox lifecycle mechanisms are kept as reuse candidates with concurrency/platform limits; no distributed lock or service-worker replacement is proposed without a consumer.

## Exact implementation checks performed for this review

- Envoy `b2d89e0ae53916f28770771fbdd49c5c99c5c5a2`, `docs/root/api-docs/xds_protocol.rst`: ACK/NACK, nonce scope, dependency sequence and warming.
- Angular `53ef99a543e037b64c596e9c3e147cb365062cea`, `driver.ts`, `app-version.ts`, pinned devops documentation: client/worker assignment, cache cleanup, initialization and header-update behavior.
- MF `40688424f13ea9d4338b9a0cf230e8f1ac4d3835`, `remote/index.ts`, `module/index.ts`, `shared/index.ts`: destructive validation order, factory deferral, sharing entry/error paths.
- SystemJS `17c238ec00cf7c4bcabcf3579f876513fcedba30`, `src/features/registry.js`: delete guards and setter reconnection.

These checks reuse the URLs already recorded by each lane. The review did not independently reproduce deployed behavior, Vercel routing, AWS races, Unreal, browser Service Workers or native desktop lifecycle.

## Owner choices still open

Stable shared contracts versus independent dependency generations; same-realm authority; explicit update/restart scope; state custodian/durability; compatibility window; interruption deadline; artifact/support retention; UI adoption policy; SSR and desktop/native breadth. A recommendation should retain its alternatives and the concrete first consumer that would decide it. Zero future refactoring is not an evidence-backed guarantee.

## MF fixture follow-up

At this review checkpoint no federation TypeScript fixture existed on disk. Its plan review is in `REVIEW-federation-plan.md`. Inspect the actual files and evidence preconditions before freeze when available; do not infer implementation correctness from the plan.
