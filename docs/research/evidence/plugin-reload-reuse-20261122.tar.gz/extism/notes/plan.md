# Bounded Extism reuse experiment

Research date: 2026-11-22 (Europe/Kiev). Disposable local research, not a production runtime, SDK or migration.

Question: can one consumer-owned text analysis port be served by ordinary TypeScript and an actual official Rust-authored Extism guest, while host state and update authority stay outside the execution instance? What exact disposal, concurrency, timeout and import guarantees does the existing JS SDK supply?

Profiles: the repository's existing @extism/extism 1.0.3 pin and separately installed npm latest-channel 2.0.0-rc13. The latter is a prerelease, even though it is tagged latest. No production dependency is changed. Source git heads: 1.0.3 e0c1672e7469e7fd9d253d43f55c0c488e08aae1; 2.0.0-rc13 bec25c60d0ad32ce06d3934563fd8560f486f323. TypeScript checker exactly 7.0.2. Upstream SDK distributed JavaScript is executed; its old development compiler is not installed or initialized.

Reuse official extism/plugins v1.1.1 count_vowels_kvstore.wasm (Rust PDK-generated ABI) and js-sdk pinned loop fixtures. Do not write a Wasm engine, manually implement its ABI, compile arbitrary user code, or invent a production lifecycle manager.

Positive and rejecting cases: narrow input/output validation; ordinary TS and Extism results; host state across fresh plugin instances; real delayed host import across active-selection change; rejected stale write; missing imports; hash mismatch; malformed binary; active reset refusal; reentrant call rejection; foreground close semantics; worker close with an outstanding actual call; latest-channel CPU timeout/restart and hanging initializer rejection. SDK calls bounded by disposable process/test watchdogs; timeout observation is not evidence that external effects stopped. Compare independently stated results, not expectations generated from adapters. Preserve unsuccessful attempts and raw logs.

Limits: local Node profile only; no browser qualification, network/file sandbox security, general strings/resources Component Model bindings, physical exit receipt unless public API actually exposes it, distributed publication or external-effect rollback.
