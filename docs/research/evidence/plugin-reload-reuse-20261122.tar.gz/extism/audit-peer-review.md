# Independent peer review of resource replacement experiment

Reviewer: Extism/runtime workstream. Reviewed 2026-11-22, Europe/Kiev.

Scope: ../audit/runtime/resource-replacement.test.ts, package/lock/compiler profile, PLAN.md, results.json and ../audit/REPORT.md. Source review, not a new execution. No files in the audited workstream were edited.

Outcome: no blocking ownership or oracle defect found in the bounded claims. Six cases use the public Resources API and actual file handles/EventEmitter registrations. Expected outcomes are stated independently. The report explicitly distinguishes application selection policy, retained-operation ownership, resource cleanup and physical release. It does not claim a generic lifecycle manager, distributed CAS, automatic borrow retention, quiescence fencing, general memory bounds or production adoption.

One reporting correction was sent to the author: versions 1..250 create 250 generations and perform 249 replacements, because the first iteration has no predecessor. Preserve 250 acquisitions and 250 releases, but label the churn count consistently in test title, results and prose. No test broadening is required.

Disposition: the author applied the count correction consistently and reports the updated strict check and six native cases passing. Final source/result readback confirms 250 generation cycles and 249 replacements. Review passes for the stated bounded scope.

Additional scope clarification: the deliberately failing cleanup throws before releasing its listener. Retrying this owned cleanup is meaningful evidence for the fixture's idempotent case, not evidence of arbitrary partial-effect cleanup rollback. The report already qualifies listener delivery only after old cleanup, finite stream consumption, exclusive-file scope and in-memory revision comparison; those limitations correctly match the source.

Checks examined: explicit v1/v2 expected file contents and captured dependency; actual EBADF early-close rejection; exact callback identity after delayed cleanup with broad-removal negative control; actual EEXIST overlap denial; isolated losing-candidate cleanup; pending acquisition debt after abandoned close waiter, eventual exactly-one file close; bounded listener counts with one failed cleanup and successful retry.
