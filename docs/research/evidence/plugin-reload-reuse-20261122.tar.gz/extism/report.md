# Extism and optional Wasm execution: reuse investigation

Research date: **2026-11-22 (Europe/Kiev)**. Repository context: Extension Foundation research PR 55, starting commit 534fa8469681df447732d9c7f8c916c6f14968e2. This directory contains disposable research only. No repository dependencies, product runtime, public SDK or accepted decision were changed by this workstream.

## Decision-relevant result

An ordinary TypeScript capability and an actual official Rust-PDK Extism guest can implement the same narrow consumer contract. The host keeps its draft, canonical state and update authority; an Extism adapter handles bytes, imports and validation. That direction is useful and does not require a compulsory Wasm boundary around normal TypeScript modules.

Extism already supplies real loading, ABI plumbing, imports, execution, reset and selected worker controls. Reimplementing those would be unnecessary. However, neither the library name nor native Extism documentation establishes the guarantees of a specific JavaScript SDK release. The experiment found concrete limits relevant to retirement, type compatibility and memory budgets.

The strongest new findings are:

1. The repository pin is JS SDK **1.0.3**. npm's current latest channel resolves to **2.0.0-rc13**, a prerelease. Its APIs differ substantially. Both were installed separately in this disposable directory and actually exercised. [E01–E05; npm metadata]
2. **14/14 local Node cases pass**, with no failed, cancelled or skipped tests. They prove the bounded behaviors and counterexamples below, not general production readiness.
3. Both SDK versions' published declarations fail strict TypeScript 7.0.2 on `PluginOutput extends DataView` (TS2508). The retained direct-import fixture reproduces exactly two dependency diagnostics. The checked behavior harness therefore uses an explicit unknown-at-runtime validation boundary; upstream declaration qualification remains failed. No dependency was patched, no compiler downgraded and no library checking suppressed.
4. Foreground `close()` does not revoke invocation: the guest remains callable afterward in both tested versions. Worker `close()` leaves an outstanding call pending in the observed 100 ms window in both. rc13 awaits Worker termination in source; 1.0.3 does not. Neither observed close operation settled the pending call. [E01–E03]
5. rc13's configured worker timeout rejects the tested CPU-loop call and then answers a later export-existence control query. A second guest invocation after timeout was not tested. It also rejects a hanging initializer. This improvement is real; criticizing only 1.0.3 would miss it. [E02; executed results]
6. rc13 `memory.maxPages:1` does **not** cap the official guest's exported linear memory to 64 KiB. The guest starts at 1,114,112 bytes and reaches 1,179,648 bytes after the successful call. Source applies this budget to SDK allocation blocks. Do not describe it as universal guest/process containment. [E05; executed counterexample]
7. wasmCloud's current **v2.12.3** source includes useful workload and component-host lifecycle machinery, but `wash-runtime` is explicitly marked **`publish = false`, internal runtime crate**. The public guide's `wash-runtime = "*"` example is not a qualified installation recipe for that release. Embeddability and a released library contract are different facts. [E12–E16]

## Actual executed profile

| Item | Exact identity |
| --- | --- |
| Host | Node 24.22.3, Linux, local container |
| Package manager | pnpm 11.25.0 |
| Own source checker | TypeScript 7.0.2, strict, noUncheckedIndexedAccess, exactOptionalPropertyTypes, noImplicitOverride; no skipLibCheck |
| Existing SDK pin | @extism/extism 1.0.3, npm gitHead e0c1672e7469e7fd9d253d43f55c0c488e08aae1 |
| Comparative SDK | @extism/extism 2.0.0-rc13 via package alias extism-candidate, npm gitHead bec25c60d0ad32ce06d3934563fd8560f486f323 |
| Guest | Official extism/plugins v1.1.1 count_vowels_kvstore.wasm, 74,029 bytes |
| Guest SHA256 | 6360898f83288ae74fe51776863376060fa725c7a4c2581ed93204bc6e661954 |
| CPU and startup loops | Official js-sdk fixtures at bec25c60d0ad32ce06d3934563fd8560f486f323; hashes in sources.json |
| Source authored here | extism.test.ts 213 lines; runtime-boundary.ts 71 lines; direct compiler-negative fixture 5 lines |
| Production integration | Zero |

The Rust guest source uses Extism's PDK macros and JSON helper. Its existing compiled release artifact was executed; Rust was not installed or compiled locally, and no ABI was written by hand. The license accompanying upstream fixtures is retained. Installed node_modules are reproducible dependencies, not intended archive contents. [E06–E09]

### Consumer boundary and oracle

The disposable consumer operation is text analysis:

- Input: request identifier plus bounded printable ASCII text.
- Output: request identifier, count and accumulated total.
- Host state: accumulated total, user draft and a single local active epoch.
- Guest capabilities: precisely named read/write callbacks for the one count key. The draft is never exposed.

The TypeScript implementation is a normal function. The Extism adapter serializes text, invokes the existing SDK and validates returned JSON. SDK-specific objects remain outside the consumer port. The fixture deliberately does not create a universal plugin interface, plugin registry, supervisor or lifecycle state machine.

Independent expectations are written explicitly: “Yellow” has 2 basic vowels and 3 when Y is configured as a vowel. Starting with a TS result of 2, the first Rust guest raises the host total to 4; a newly constructed configured Rust instance raises it to 7. Reset does not erase this host-owned total, and the draft survives.

**Scope of replacement:** native TypeScript is replaced by a real Rust-authored Wasm implementation. The subsequent Rust-instance change uses the same immutable Wasm bytes with different configuration. This is not a newly compiled Rust-v1→Rust-v2 code-update test, nor a stack/memory migration. Existing November 21 Component Model evidence separately owns the actual different-component-bytes comparison.

### Test outcomes

| Case | Profiles | Observed result |
| --- | --- | --- |
| Ordinary TypeScript contract and rejected invalid input | Native TS | 2 vowels, bounded input check and unchanged state on rejection |
| TS→Rust instance selection, reset and fresh configured instance | Both SDKs | Exact results 2→4→7; host draft retained |
| Delayed real host import during selection change | Both SDKs | Old guest was active inside an async host import; active reset returned false; reentrant call rejected |
| Old guest resumes after new instance accepts work | Both SDKs | New instance commits total 3; old write receives STALE_AUTHORITY; total remains 3 |
| Invalid candidates | Both SDKs | Missing host imports, bad artifact hash and malformed Wasm reject; selected TS operation still works |
| Foreground close | Both SDKs | Guest call after close still returns count 2/total 2 |
| Worker close during dispatched CPU-loop call | Both SDKs | close resolves; call remains pending and isActive remains true 100 ms later |
| 150 ms built-in worker timeout | rc13 | CPU-loop call rejects with timeout; subsequent functionExists request succeeds |
| 150 ms built-in instantiation timeout | rc13 | Guest with a looping start section rejects instantiation |
| Configured maxPages 1 | rc13 | 17 guest pages initially; 18 after call; successful count 2 proves SDK budget is not a general guest-linear-memory ceiling |

There are 14 native test cases; the table groups related assertions and is not a claim that every cell is an independent test. CPU-loop termination tests dispatch the official looping export; they do not instrument an explicit guest “entered loop” marker. The final reviewed runtime report lasts 1,139.368277 ms and is **not a benchmark**.

The epoch guard is a test-local single-owner policy. It demonstrates why the real state/import owner must check authority. It does not qualify distributed fencing, a database protocol, cancellation of arbitrary remote effects or recovery after a process crash.

### Compiler limitation and retained failures

The first direct typed harness revealed TS2508 in both upstream `interfaces.d.ts` files. A minimal compiler-negative fixture now isolates this independent of the behavior harness:

`pnpm exec tsc --project tsconfig.direct.json --pretty false`

Its expected current result is failure with the two retained TS2508 diagnostics. The runtime boundary is checked strictly and validates unknown SDK values at use: exported factory, required methods, boolean responses, native DataView output, text, offsets and WebAssembly.Instance. This is research isolation around a dependency declaration incompatibility; it is not a production facade recommendation or evidence that SDK types are qualified.

The first runtime pass was 10/13. Stable SDK normalization of a reused mutable unnamed manifest left a name unsuitable for the new major prerelease. Fresh manifest objects with an explicit main name fixed the fixture's cross-profile reuse. The final missing-import assertion checks the actual host namespace or import name, not a generic “module” error that could mask a different failure. Earlier failed outputs are retained. No upstream implementation or expected semantic outcome was changed.

## Exact reuse boundaries

### Extism: useful application plugin machinery, a distinct ABI

Extism's SDK/PDK stack avoids an application-specific Wasm ABI. The guest exports bytes-in/bytes-out functions and imports explicit host functions. JSON in this example is a choice at the consumer/adapter boundary. Language support means a suitable PDK/toolchain for each selected language/profile, not arbitrary source code magically compiled without constraints. [E06,E22]

The JS SDK executes through the Wasm engine already available in its JavaScript runtime. It is not a binding to libextism, so native Extism/Wasmtime fuel, cancellation or resource semantics cannot be imported into its guarantee table. Both 1.0.3 and rc13 lack a public per-call cancel operation in the inspected Plugin API. rc13 supplies a worker timeout/reconstruction mechanism instead. [E01–E05,E10]

A production adapter must truthfully expose its selected profile:

- Calls admitted in one instance are serialized by the worker profile; reentrant calls reject. Decide bounded scheduling at the existing owner instead of assuming the SDK creates a fair task queue.
- Fresh instance creation is the replacement mechanism; old instance private memory is not automatically transferred.
- Copy results into owned consumer values before exposing them beyond the SDK memory lifetime. Do not retain raw SDK memory views as domain state.
- User manifests request capabilities. The host must select actual imports, allowed paths and hosts; do not pass user-controlled grant-like options straight through.
- Revoking host write authority is separate from closing an engine. A late host callback is outside an inference that stopping guest Wasm undoes its effects.
- Match budgets to actual resources. This experiment directly falsifies a blanket maxPages claim for the JS profile; native-runtime limits require their own qualification.
- Browser worker mode requires SharedArrayBuffer and cross-origin isolation. Browser deployment and cancellation semantics were not tested here. [E04,E10]

The worker option remains annotated experimental. Its linked historical issue 46 is closed as completed; that old issue is **not** evidence of a currently unfixed race. Recheck maintained source/tests for the selected deployment instead of converting old warnings into unsupported accusations. [E11]

### WIT/Component Model toolchain: avoid implementing bindings

jco already generates JavaScript hosting artifacts for components; ComponentizeJS creates components from JavaScript with an embedded engine; wit-bindgen generates guest bindings from WIT. Rust host binding generation belongs to Wasmtime's component APIs. These are separate responsibilities, so do not create a second marshaller, handwritten generalized ABI or runtime under the label “our flexible architecture.” [E17–E20]

Extism's ABI and WIT's Component Model are alternative interoperability choices. It may be useful to support an adapter for either over time, but selecting both for version 1 multiplies packaging, conformance and failure semantics. A narrow consumer contract can remain stable while its one selected boundary representation changes through explicit compatibility work. Do not route ordinary TS-to-TS module calls through bytes solely to reserve a future option.

Current jco/ComponentizeJS documentation marks stability limitations and includes multiple backend choices. The earlier experiment's exact versions and binary hashes remain historical evidence; they do not automatically qualify every current backend. ComponentizeJS includes a JS engine and evaluates top-level source during pre-initialization. Component packaging is not intrinsically a performance win or a safe authoring/build sandbox. [E17,E18]

### wasmCloud: reuse workload lifecycle where its unit fits

Current v2.12.3 release source is 8358f1f56a66c43aedc49f30e2c5d4fa2b4f7ca1, published 2026-11-21T22:01:38Z (November 22 in Kyiv). Engine/Host/Workload abstractions, host component plugins and their lifecycle machinery are real. The runtime has source for revoking a generation, deferring unbind after a still-running bind times out, replaying idempotent binds into a recreated store and isolating repeatedly failing bound workloads. These are strong existing mechanisms to study before writing a supervisor. They were source-inspected here, not executed. [E12–E16]

Do not turn that into an ordinary-library adoption claim: the current crate says publish=false. A real integration proposal must select the supported host distribution or exact source dependency, determine release/support expectations and measure build/packaging cost. Public docs' wildcard Cargo snippet is insufficient.

Native host plugins are linked into the host binary; Wasm host component plugins are the distinct opt-in runtime-loaded path. Product TS plugins, UI widgets and Wasm workloads are not automatically the same replaceable unit. A runtime cannot choose our application state ownership, grants or allowed update scope merely because its lifecycle APIs exist.

### Spin and Wasmtime: choose according to the execution unit

Spin's watch command rebuilds/restarts an application and keeps the previous app after build failure. This is a valuable ready development loop if a Spin application is the actual unit. It does not by itself preserve arbitrary UI state, transfer live stacks or provide our product's fine-grained update control. [E21]

Wasmtime's fuel and epoch mechanisms interrupt guest computation; choose the cost/semantics intentionally and separately bound host operations. If direct Wasmtime is selected, reuse its bindings, engine and resource APIs rather than implementing them. Moving the existing TS application into Rust is not required merely to have a qualified native executor. [E20]

## Warnings to preserve in owning architecture records

| Accidental reinvention or overclaim | Existing reuse route | Residual application responsibility |
| --- | --- | --- |
| Own Wasm engine or generalized ABI | Extism SDK/PDK; or Component Model tooling and Wasmtime | Select concrete profile and verify supported features |
| Manual Rust/general string/resource bindings | wit-bindgen and Wasmtime component bindgen | Consumer-owned operation/data semantics and versioning |
| New universal plugin manager | Existing GM composition/lifecycle owner; selected SDK/runtime executor | Product-selected authority, update scope and compatibility |
| Treat SDK close as application retirement | Exact SDK shutdown plus existing resource owner | Reject new calls, settle owned requests, account for host effects and cleanup |
| Rebuild a workload supervisor unnecessarily | wasmCloud supported host or qualified source embedding | Avoid duplicate supervision; respect existing physical-custody owner |
| Mandatory serialization for all TS plugins | Ordinary TS ports and existing composition | Add a boundary only where language, isolation or deployment requires it |
| Treat same shape/hash as compatibility | Existing serializer/bindings/schema tools | State schema, effects, operation behavior and capability grants |
| DIY plugin package watcher as production updater | Existing Vite/Spin/build tooling for development | Verified artifact selection, readiness and business-safe update policy |
| Claim maxPages or worker equals sandbox | Selected runtime's actual limits; qualified process/OS containment if needed | Explicit supported threat profile, platform and resource budgets |
| Assume newest documentation equals installed API | Exact package/lock/source identities | Upgrade qualification, compiler support and release channel selection |

These warnings route responsibility; they do not authorize new packages or another policy registry. Current accepted owners remain unchanged.

## Proposed qualification before production selection

The strongest next question is the first real capability and deployment profile, not “which universal plugin interface.” For one selected operation, compare native TS with the strongest matching existing executor and require the same input/output/errors plus truthful differences in cancellation, shutdown and resources.

Extism JS remains a useful candidate after this experiment, but production adoption must resolve direct TS 7 declaration compatibility, pending-call settlement during close, supported resource limits and required browser/native profiles. The rc13 improvements should be assessed deliberately; npm latest is not a stability guarantee. If required CPU/memory isolation exceeds the JS profile, compare a native Wasmtime-backed boundary or an existing workload host before implementing custom controls.

The minimum architecture to preserve now is a consumer-owned port, explicit instance/state/resource ownership, immutable artifact/configuration identity at activation, scoped host grants and observable update outcomes. A future Wasm adapter must attach there. It need not force WIT, Extism or a wire protocol into ordinary TS internals today.

No production runtime, public SDK, cross-language package, complete dynamic authoring loop or fleet rollout was implemented or selected by these results.

## Reproduction and custody

From this directory:

1. `pnpm install --frozen-lockfile --ignore-scripts`
2. `pnpm typecheck` — strict own harness, expected pass.
3. `pnpm test` — 14 cases, expected pass under the recorded Node profile.
4. `pnpm exec tsc --project tsconfig.direct.json --pretty false` — retained upstream compatibility probe, expected TS2508 failure for both SDK declarations.

Read evidence/test-final.log and evidence/results.json for observations. evidence/direct-sdk-import.log is the isolated compiler failure; earlier attempt logs remain separate. sources.json contains primary URLs, pins, blob identities and evidence classes. fixtures/UPSTREAM-LICENSE.txt covers retained upstream fixtures. No native Node/browser physical-exit instrumentation or remote effect occurred.

Scores and production LOC estimates are intentionally left to the parent synthesis, which must compare the same actual product scope. This workstream's 284 lines of behavior harness plus 5-line negative fixture are measured research cost, not a platform implementation quote.

