import assert from 'node:assert/strict';

// Research-only runtime validation boundary. Direct imports remain separately
// blocked by TS2508 in BOTH upstream declaration sets; see retained failed log.
// This does not patch, certify, or replace those SDK declarations.
export type OutputView = { text(): string; getUint32(offset: number, littleEndian: boolean): number; byteLength: number };
export type HostMemory = { read(offset: bigint): OutputView | null; store(bytes: Uint8Array): bigint };
export type PluginProbe = {
  call(name: string, input?: string): Promise<OutputView | null>;
  close(): Promise<void>;
  reset(): Promise<boolean>;
  isActive(): boolean;
  functionExists(name: string): Promise<boolean>;
  getInstance(): Promise<WebAssembly.Instance>;
};
export type HostFunctions = {
  'extism:host/user': {
    kv_read(memory: HostMemory, keyOffset: bigint): bigint | Promise<bigint>;
    kv_write(memory: HostMemory, keyOffset: bigint, valueOffset: bigint): void;
  };
};
export type FixtureOptions = {
  runInWorker?: boolean; config?: Record<string, string>; functions?: HostFunctions; timeoutMs?: number;
  memory?: { maxPages?: number };
};
export type FixtureManifest = { wasm: { name?: string; data: Uint8Array; hash?: string }[] };
export type Profile = { name: string; create(manifest: FixtureManifest, options?: FixtureOptions): Promise<PluginProbe> };

function invoke(target: unknown, name: string, arguments_: unknown[]): unknown {
  assert.ok(typeof target === 'object' && target !== null, 'SDK object expected');
  const method: unknown = Reflect.get(target, name);
  assert.equal(typeof method, 'function', `SDK method ${name} expected`);
  if (typeof method !== 'function') throw new Error('SDK_FUNCTION_MISSING');
  return Reflect.apply(method, target, arguments_);
}
function output(value: unknown): OutputView | null {
  if (value === null) return null;
  assert.ok(value instanceof DataView, 'SDK output must expose a native DataView');
  return {
    text() { const text = invoke(value, 'text', []); assert.equal(typeof text, 'string'); if (typeof text !== 'string') throw new Error('SDK_TEXT_INVALID'); return text; },
    getUint32: (offset, littleEndian) => value.getUint32(offset, littleEndian),
    byteLength: value.byteLength,
  };
}
function memory(value: unknown): HostMemory {
  return {
    read: offset => output(invoke(value, 'read', [offset])),
    store: bytes => { const offset = invoke(value, 'store', [bytes]); assert.equal(typeof offset, 'bigint'); if (typeof offset !== 'bigint') throw new Error('SDK_OFFSET_INVALID'); return offset; },
  };
}
function boolean(value: unknown): boolean { assert.equal(typeof value, 'boolean'); if (typeof value !== 'boolean') throw new Error('SDK_BOOLEAN_INVALID'); return value; }
function offset(value: unknown): bigint { assert.equal(typeof value, 'bigint'); if (typeof value !== 'bigint') throw new Error('SDK_OFFSET_INVALID'); return value; }
export async function loadProfile(specifier: string, name: string): Promise<Profile> {
  const sdk: unknown = await import(specifier);
  return { name, async create(manifest, options = {}) {
    const functions = options.functions?.['extism:host/user'];
    const mapped = functions ? { 'extism:host/user': {
      kv_read: (context: unknown, key: unknown) => functions.kv_read(memory(context), offset(key)),
      kv_write: (context: unknown, key: unknown, value: unknown) => functions.kv_write(memory(context), offset(key), offset(value)),
    } } : undefined;
    const plugin = await invoke(sdk, 'createPlugin', [manifest, { ...options, ...(mapped ? { functions: mapped } : {}) }]);
    return {
      async call(functionName, input) { return output(await invoke(plugin, 'call', [functionName, input])); },
      async close() { await invoke(plugin, 'close', []); },
      async reset() { return boolean(await invoke(plugin, 'reset', [])); },
      isActive() { return boolean(invoke(plugin, 'isActive', [])); },
      async functionExists(functionName) { return boolean(await invoke(plugin, 'functionExists', [functionName])); },
      async getInstance() { const instance = await invoke(plugin, 'getInstance', []); assert.ok(instance instanceof WebAssembly.Instance); return instance; },
    };
  } };
}
