import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { after, test } from 'node:test';
import { loadProfile } from './runtime-boundary.ts';
import type { OutputView, HostMemory, PluginProbe, HostFunctions, FixtureManifest } from './runtime-boundary.ts';

// Disposable consumer fixture, deliberately not a universal plugin interface.
type Request = { requestId: string; text: string };
type Result = { requestId: string; vowels: number; total: number };
type Analyze = (request: Request) => Promise<Result>;
type State = { total: number; draft: string; activeEpoch: number };
const profiles = [await loadProfile('@extism/extism', '1.0.3'), await loadProfile('extism-candidate', '2.0.0-rc13')];
const candidate = await loadProfile('extism-candidate', '2.0.0-rc13');
const guest = new Uint8Array(await readFile(new URL('./fixtures/count_vowels_kvstore.wasm', import.meta.url)));
const loop = new Uint8Array(await readFile(new URL('./fixtures/loop-forever.wasm', import.meta.url)));
const loopInit = new Uint8Array(await readFile(new URL('./fixtures/loop-forever-init.wasm', import.meta.url)));
const digest = '6360898f83288ae74fe51776863376060fa725c7a4c2581ed93204bc6e661954';
function manifest(): FixtureManifest { return { wasm: [{ name: 'main', data: guest, hash: digest }] }; }
const observations: { name: string; value: unknown }[] = [];
function record(name: string, value: unknown): void {
  observations.push({ name, value });
  process.stdout.write(`OBSERVATION ${JSON.stringify({ name, value })}\n`);
}
after(async () => {
  await writeFile(new URL('./evidence/results.json', import.meta.url), JSON.stringify({
    researchDate: '2026-11-22', node: process.version, profiles: profiles.map(p => p.name), observations,
  }, null, 2) + '\n');
});

function validateRequest(value: unknown): Request {
  if (typeof value !== 'object' || value === null || !('requestId' in value) || !('text' in value) ||
      typeof value.requestId !== 'string' || value.requestId.length < 1 || value.requestId.length > 64 ||
      typeof value.text !== 'string' || value.text.length > 256 || !/^[\x20-\x7E]*$/.test(value.text)) {
    throw new Error('INPUT_REJECTED');
  }
  return { requestId: value.requestId, text: value.text };
}
function parseReport(output: OutputView | null): { count: number; total: number } {
  assert.ok(output, 'guest must return output');
  const value: unknown = JSON.parse(output.text());
  if (typeof value !== 'object' || value === null || !('count' in value) || !('total' in value) ||
      !Number.isSafeInteger(value.count) || !Number.isSafeInteger(value.total) ||
      typeof value.count !== 'number' || typeof value.total !== 'number' || value.count < 0 || value.total < 0) {
    throw new Error('OUTPUT_REJECTED');
  }
  return { count: value.count, total: value.total };
}
function ordinaryTypeScript(state: State, epoch: number, vowels: string): Analyze {
  return async value => {
    const input = validateRequest(value);
    if (state.activeEpoch !== epoch) throw new Error('STALE_AUTHORITY');
    const count = [...input.text].filter(character => vowels.includes(character)).length;
    state.total += count;
    return { requestId: input.requestId, vowels: count, total: state.total };
  };
}
function extismAdapter(plugin: PluginProbe): Analyze {
  return async value => {
    const input = validateRequest(value);
    const report = parseReport(await plugin.call('count_vowels', input.text));
    return { requestId: input.requestId, vowels: report.count, total: report.total };
  };
}
function hostFunctions(state: State, epoch: number, held?: { entered(): void; wait: Promise<void> }): HostFunctions {
  function read(memory: HostMemory, keyOffset: bigint): bigint {
    if (memory.read(keyOffset)?.text() !== 'count-vowels') throw new Error('HOST_KEY_DENIED');
    const bytes = new Uint8Array(4);
    new DataView(bytes.buffer).setUint32(0, state.total, true);
    return memory.store(bytes);
  }
  return {
    'extism:host/user': {
      kv_read: held ? async (memory, keyOffset) => {
        held.entered();
        await held.wait;
        return read(memory, keyOffset);
      } : read,
      kv_write(memory, keyOffset, valueOffset) {
        if (memory.read(keyOffset)?.text() !== 'count-vowels') throw new Error('HOST_KEY_DENIED');
        if (state.activeEpoch !== epoch) throw new Error('STALE_AUTHORITY');
        const value = memory.read(valueOffset);
        if (!value || value.byteLength !== 4) throw new Error('HOST_VALUE_REJECTED');
        state.total = value.getUint32(0, true);
      },
    },
  };
}
function nextState(epoch = 1): State { return { total: 0, draft: 'host-owned draft survives', activeEpoch: epoch }; }

test('ordinary TypeScript keeps the consumer contract and validates input', async () => {
  const state = nextState();
  const analyze = ordinaryTypeScript(state, 1, 'aeiouAEIOU');
  assert.deepEqual(await analyze({ requestId: 'native-1', text: 'Yellow' }), { requestId: 'native-1', vowels: 2, total: 2 });
  assert.throws(() => validateRequest({ requestId: 'x', text: 42 }), /INPUT_REJECTED/);
  await assert.rejects(analyze({ requestId: 'large', text: 'x'.repeat(257) }), /INPUT_REJECTED/);
  assert.equal(state.total, 2);
  record('native-contract', { total: state.total, draft: state.draft });
});

for (const profile of profiles) {
  test(`${profile.name}: native TS and Rust Extism serve one contract; host state survives reset and replacement`, { timeout: 10_000 }, async () => {
    const state = nextState();
    let analyze = ordinaryTypeScript(state, 1, 'aeiouAEIOU');
    assert.deepEqual(await analyze({ requestId: 'ts', text: 'Yellow' }), { requestId: 'ts', vowels: 2, total: 2 });
    const first = await profile.create(manifest(), { functions: hostFunctions(state, 2) });
    const second = await profile.create(manifest(), { functions: hostFunctions(state, 3), config: { vowels: 'aeiouyAEIOUY' } });
    try {
      state.activeEpoch = 2;
      analyze = extismAdapter(first);
      assert.deepEqual(await analyze({ requestId: 'wasm-1', text: 'Yellow' }), { requestId: 'wasm-1', vowels: 2, total: 4 });
      assert.equal(await first.reset(), true);
      assert.equal(state.total, 4);
      await assert.rejects(analyze({ requestId: '', text: 'Yellow' }), /INPUT_REJECTED/);
      assert.equal(state.total, 4);
      state.activeEpoch = 3;
      analyze = extismAdapter(second);
      assert.deepEqual(await analyze({ requestId: 'wasm-2', text: 'Yellow' }), { requestId: 'wasm-2', vowels: 3, total: 7 });
      assert.equal(state.draft, 'host-owned draft survives');
      record(`${profile.name}:replacement`, { total: state.total, draft: state.draft, activeEpoch: state.activeEpoch });
    } finally { await first.close(); await second.close(); }
  });

  test(`${profile.name}: real delayed host import, active reset/reentrancy rejection and stale write denial`, { timeout: 10_000 }, async () => {
    const state = nextState();
    const entered = Promise.withResolvers<void>();
    const release = Promise.withResolvers<void>();
    const old = await profile.create(manifest(), {
      runInWorker: true,
      functions: hostFunctions(state, 1, { entered: () => entered.resolve(), wait: release.promise }),
    });
    const current = await profile.create(manifest(), { functions: hostFunctions(state, 2), config: { vowels: 'aeiouyAEIOUY' } });
    try {
      const oldCall = extismAdapter(old)({ requestId: 'old', text: 'Yellow' });
      const oldOutcome = oldCall.then(value => ({ ok: true as const, value }), error => ({ ok: false as const, message: String(error) }));
      await entered.promise;
      assert.equal(old.isActive(), true);
      assert.equal(await old.reset(), false);
      await assert.rejects(old.call('count_vowels', 'other'), /not reentrant/);
      // Only this fixture's existing host authority changes; no SDK grants migration or rollback.
      state.activeEpoch = 2;
      assert.deepEqual(await extismAdapter(current)({ requestId: 'new', text: 'Yellow' }), { requestId: 'new', vowels: 3, total: 3 });
      release.resolve();
      const outcome = await oldOutcome;
      assert.equal(outcome.ok, false);
      if (!outcome.ok) assert.match(outcome.message, /STALE_AUTHORITY/);
      assert.equal(state.total, 3);
      assert.equal(state.draft, 'host-owned draft survives');
      record(`${profile.name}:held-import`, { oldOutcome: outcome, total: state.total, activeEpoch: state.activeEpoch });
    } finally { release.resolve(); await old.close(); await current.close(); }
  });

  test(`${profile.name}: SDK rejects absent imports, mismatched hash and malformed bytes before selection`, { timeout: 10_000 }, async () => {
    const state = nextState();
    const active: Analyze = ordinaryTypeScript(state, 1, 'aeiouAEIOU');
    await assert.rejects(profile.create(manifest()), /kv_read|extism:host\/user/);
    await assert.rejects(profile.create({ wasm: [{ data: guest, hash: '0'.repeat(64) }] }), /hash|Hash/);
    await assert.rejects(profile.create({ wasm: [{ data: new Uint8Array([0, 1, 2, 3]) }] }), /magic|WebAssembly|Compile/);
    assert.deepEqual(await active({ requestId: 'still-active', text: 'Yellow' }), { requestId: 'still-active', vowels: 2, total: 2 });
    record(`${profile.name}:candidate-rejections`, { missingImports: true, wrongHash: true, malformedBinary: true, activeUnchanged: true });
  });

  test(`${profile.name}: foreground close is not an invocation authority fence`, { timeout: 10_000 }, async () => {
    const state = nextState();
    const plugin = await profile.create(manifest(), { functions: hostFunctions(state, 1) });
    await plugin.close();
    const afterClose = parseReport(await plugin.call('count_vowels', 'Yellow'));
    assert.deepEqual(afterClose, { count: 2, total: 2 });
    record(`${profile.name}:foreground-after-close`, afterClose);
  });

  test(`${profile.name}: worker close leaves an outstanding CPU-loop call unsettled in the observed window`, { timeout: 10_000 }, async () => {
    const plugin = await profile.create({ wasm: [{ data: loop }] }, { runInWorker: true });
    let status: 'pending' | 'fulfilled' | 'rejected' = 'pending';
    void plugin.call('loop').then(() => { status = 'fulfilled'; }, () => { status = 'rejected'; });
    assert.equal(plugin.isActive(), true);
    await delay(30);
    await plugin.close();
    await delay(100);
    assert.equal(status, 'pending');
    assert.equal(plugin.isActive(), true);
    record(`${profile.name}:worker-close`, { closeResolved: true, callAfter100ms: status, isActiveAfterClose: plugin.isActive(), publicPhysicalExitReceipt: false });
  });
}

test('2.0.0-rc13: built-in timeout rejects a CPU-loop call and answers a later export query', { timeout: 10_000 }, async () => {
  const plugin = await candidate.create({ wasm: [{ data: loop }] }, { runInWorker: true, timeoutMs: 150 });
  try {
    await assert.rejects(plugin.call('loop'), /canceled due to timeout/);
    assert.equal(plugin.isActive(), false);
    assert.equal(await plugin.functionExists('loop'), true);
    record('2.0.0-rc13:cpu-timeout', { timedOut: true, nextControlQueryAccepted: true, supportsPerCallCancel: false });
  } finally { await plugin.close(); }
});

test('2.0.0-rc13: built-in timeout rejects a hanging Wasm initializer', { timeout: 10_000 }, async () => {
  await assert.rejects(candidate.create({ wasm: [{ data: loopInit }] }, { runInWorker: true, timeoutMs: 150 }), /timed out.*instantiate/);
  record('2.0.0-rc13:init-timeout', { rejected: true });
});

test('2.0.0-rc13: maxPages does not bound this guest-owned exported linear memory', { timeout: 10_000 }, async () => {
  const state = nextState();
  const plugin = await candidate.create(manifest(), { functions: hostFunctions(state, 1), memory: { maxPages: 1 } });
  try {
    const instance = await plugin.getInstance();
    const memory = instance.exports.memory;
    assert.ok(memory instanceof WebAssembly.Memory);
    const initialGuestLinearMemoryBytes = memory.buffer.byteLength;
    assert.ok(memory.buffer.byteLength > 65_536, 'this fixture distinguishes guest memory from the SDK allocation budget');
    assert.deepEqual(await extismAdapter(plugin)({ requestId: 'memory', text: 'Yellow' }), { requestId: 'memory', vowels: 2, total: 2 });
    record('2.0.0-rc13:memory-scope', { configuredSdkMaxPages: 1, pageBytes: 65_536, initialGuestLinearMemoryBytes, afterCallGuestLinearMemoryBytes: memory.buffer.byteLength });
  } finally { await plugin.close(); }
});
