// Intentional compiler-negative fixture for published SDK declaration support.
import { createPlugin as stable } from '@extism/extism';
import { createPlugin as candidate } from 'extism-candidate';
void stable;
void candidate;
