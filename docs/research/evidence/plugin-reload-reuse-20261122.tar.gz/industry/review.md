# Independent browser spike source review

Reviewer: industry_hot_reload. User date: 2026-11-22 Europe/Kiev.
Disposition: **Native attempt 1 failed; source findings below remain bounded.**
Initial source approval missed two workflow concerns subsequently found by root
and by the hosted run. Root corrected the context error before publication;
the published attempt still failed artifact retention and the v3 browser wait.
This is a source and execution-evidence review, not production adoption.

## Reviewed identities

| Input | SHA-256 |
| --- | --- |
| browser/browser.test.ts | 2b8612962b2d0987a3a1993d2256aef65dc716e11eeb90306b7a96ba317cfe4c |
| browser/plan.md | edc222ae20f1fcaf90650fd8a874dafd69cda009c2945ee703847e4de3832344 |
| browser/tsconfig.json | a6dd912ba4ca00935629e593a33ba3908a3c6fb0d4c9086c12767f841b993f76 |
| browser/package.json | 27ddbf31db0e3ff09d699460106314b172b11dff0829f6843855f4404b4e70ca |
| browser/pnpm-lock.yaml | a54aa653a90119f8cca9d8da6c7507de17e43e27f46f2ce1c10647fd5ea450e3 |
| .github/workflows/plugin-reload-reuse-spikes.yml (published attempt 1) | d461b43eee0769e75838d5d717d7d177a85cce4bb492350c6d52519dea4e4259 |
| plugin-reload-browser-input-20261122.tar.gz (published attempt 1) | 8e6170d5470857c2d5ed9302d2aabbc81fc71db6fd905fc2ee4e82dd92962d9c |

Also inspected the four component variants, host, probe, raw-module variants,
and main entry. Independently extracted all 18 regular members with the standard
tar data filter; archive length/hash, exact unique member set, every member's
length/hash and byte equality to the reviewed browser directory all passed.
Archive length: 14,976 bytes. Receipt: archive-verification.json.

## Findings and dispositions

1. **Material plan correction: initializer edits are not necessarily state-preserving.**
   Initial draft assumed same Hook ordering would retain state even with a changed
   initializer. Independent inspection first found contrary React integration
   assertions, then traced the actual selected default transform:
   plugin-react6.3.0 → Vite8.3.8 → Rolldown1.2.19 → Oxc0.156.0.
   Oxc includes the complete useState first-argument source in the Hook signature.
   Corrected before execution: v2 keeps initializer11 for positive preservation;
   v3 adds a Hook with initializer11; v4 changes initializer to99 with an explicit
   remount/reset expectation. The report preserves this correction as evidence.

2. **Cleanup-order false-positive possibility.**
   An index comparison alone allowed a missing cleanup index(-1) to compare less
   than a setup index. Fixed: a separate assertion requires observed cleanup
   before ordering is tested.

3. **Real boundary identity.**
   Initial fixture entry placeholders re-export variants. The harness correctly
   copies authoritative v1 contents into the actual watched entry before server
   startup, so subsequent edits replace the same module boundary. This is
   essential for the raw disposal/import-order experiment.

4. **Acceptance is not successful replacement.**
   Strengthened: the raw module records undefined versus present replacement.
   Failed candidate evaluation is expected to produce accept-undefined after
   observed old disposal. The independent native event oracle checks that the old
   listener really stopped responding. Recovery must acquire a new resource.

5. **User-action description.**
   Two intended independent clicks originally used a double-click count. Fixed
   to two awaited native click operations, matching the reported scenario.

6. **Old callback semantics remain truthful.**
   A held Promise callback deliberately survives effect cleanup. Its old-version
   result is observed after new setup. This demonstrates the limit of framework
   cleanup; it does not pretend HMR revokes arbitrary asynchronous continuations.

7. **Root-found GitHub context error, corrected before publication.**
   Initial workflow hash d87a7664035f9f8a89d559d3717d797486f7f939f104ab30742e07a4444088ed
   used runner context at jobs.browser.env. This reviewer missed that error.
   Root independently checked the official GitHub context availability table,
   which permits github/needs/strategy/matrix/vars/secrets/inputs at job env,
   excluding runner. Corrected published workflow uses
   github.workspace/../plugin-reload-browser and a later step.with reads
   env.RELOAD_RESEARCH_DIRECTORY. Independently verified the correction against
   https://docs.github.com/en/actions/reference/workflows-and-actions/contexts
   (web source turn651208444view1) and the final workflow digest above.

8. **Hosted artifact path rejected; observed evidence was not uploaded.**
   The corrected job env is syntactically valid, but upload-artifact v7 rejects
   literal '..' path components even in absolute patterns. Attempt 1 failed
   the final always() upload step for that reason, and the artifacts API returned
   an empty list. Normalize the dedicated directory before passing it to the
   action, or use a dedicated directory without dot components. The original
   claim that failure artifacts are retained is therefore withdrawn for this
   attempt. Complete decoded job logs remain available and were saved exactly.

9. **First native attempt timed out waiting for v3, after compatible v2 passed.**
   Job 137021368787 reached browser.test.ts:107 and timed out after 15 seconds.
   Therefore assertions through line104 passed, including v2 state/element/draft
   retention, actual cleanup order/listener and the old captured completion.
   Only one Vite HMR-update log was emitted. We cannot infer the v3 remount
   behavior from this timeout or inspect the lost browser observations.
   Source-supported hypothesis: successive fs.cp replacements can interact
   with watcher event throttling. Node v24.22.3 cp force mode unlinks the target
   before copying; exact Vite8.3.8 bundles Chokidar3.6.0, whose _emit suppresses
   same-path change events for 50 milliseconds. This is an explanation to test,
   not an established cause. Use an in-place file edit and documented edit
   spacing beyond that throttle, log watcher events, and retain the unchanged
   browser assertions. No manual HMR event injection or weakened oracle.

## What the source actually tests

The test launches real Vite with the released React plugin and drives native
Chromium. It changes source files rather than mocking reload messages. It uses
independent values and actual DOM identity/real event listeners to distinguish
preservation, remount, resource cleanup, and failed activation. The host draft
and the module-generated document marker are checked across each change.
Full page reload resets in-memory host state and uses the new initializer.

The raw failure is intentional and its console/page evidence is retained.
Unexpected page exceptions fail the test. Console messages are retained for
review; the fixture does not claim every possible console error class is
automatically rejected.

The state examples do not transfer suspended JS stacks, migrate arbitrary
schemas, revoke remote effects, or test hostile code. A single listener and one
sequence do not establish memory-leak freedom or churn capacity.

## Workflow review

The source executes on the existing research branch in a fresh hosted Ubuntu
runner and dedicated sibling-of-workspace directory. Checkout is exact-source and
does not retain credentials. Repository permissions are read-only. Actions,
Node, pnpm and direct package versions are pinned; dependency installation uses
the frozen lock, disables lifecycle scripts, and asserts actual direct versions,
including TypeScript7.0.2. All maintained TS/test/variant files are included in
the strict checker before the native browser test.

Archive length/digest and exact regular-member names are verified; duplicate
members are rejected by count/set comparison. Standard tar data filtering is
used for extraction and every extracted file is checked against its manifest.
A receipt binds commit, run/attempt, archive, and workflow digest. Artifacts
are intended to retain source, logs, comparisons, observed errors and screenshots
even after failure, but the path problem above prevented this in attempt 1.
Native browser installation comes from the pinned Playwright package.

## Observed hosted attempt 1

Commit: 30b9823aacecc0728ebf72c2e450e7c8c06b93e2.
Run: https://github.com/agent-teams-ai/extension-foundation/actions/runs/44961594670
Job: 137021368787. Conclusion: failure. Native test: 0 passed, 1 failed.
Archive verification, exact dependency install and strict TypeScript checks
passed. Playwright installed Chromium 159.0.8154.6, browser build1255. The native
test then failed at the v3 wait; the later upload step also failed.

Saved under hosted/run-44961594670/: complete decoded job log, its full tool
response, job/step JSON and empty artifact list. Decoded UTF-8 job log has
55,820 bytes and SHA-256
ce5274b6f8174590576287f92ac052d50ea9f36ef996a0981e92b5219570bf9b.
No downloadable artifact exists for this attempt. No native E2E success is claimed.

Relevant failure-analysis primary source:

- https://github.com/nodejs/node/blob/v24.22.3/lib/internal/fs/cp/cp.js
- https://github.com/vitejs/vite/blob/b39e6e63dcbfc3cf4be871acf3554efbd6d0e268/packages/vite/package.json
- https://github.com/vitejs/vite/blob/b39e6e63dcbfc3cf4be871acf3554efbd6d0e268/pnpm-lock.yaml
- https://github.com/paulmillr/chokidar/blob/3.6.0/index.js

## Second frozen input: pre-publication source and binding review

Disposition: **PASS for the revised independent-edit research profile.** Native
execution of the second input remains pending. This section supplements, and
does not replace, the failed first-attempt record above.

| Input | SHA-256 |
| --- | --- |
| plugin-reload-browser-input-20261122-v2.tar.gz | 430b3c063c920e0a5e1153d2ed1beca7ebbb65d0e658e7ad54f941169d31b1a5 |
| browser.test.ts in v2 | 7bcd47c5898bc4f20cfd911084c4a7f0f9a74526fa813521cd75efd2c4fa5bb9 |
| plan.md in v2 | 9d463b54c4eb9be4a5af0286b9eb8ed7926f1fc4d7a46da639c96815a46c0648 |
| .github/workflows/plugin-reload-reuse-spikes.yml for v2 | 396f5277f6c91b9ba22421d0ecbe073f04a8d6b7ad8f6372472304e76e2eb8cd |

Independently extracted and verified all 18 regular members of the 15,911-byte
archive. Unique exact names, sizes, SHA-256 and reviewed-working-source equality
passed. Original v1 archive and manifest independently byte-compared against
published commit30b9823aacecc0728ebf72c2e450e7c8c06b93e2 and remain unchanged.
Receipt: archive-verification-v2.json.

An exact archive-to-archive diff shows that only browser.test.ts and plan.md
changed. Every fixture, dependency identity and strict configuration is unchanged.
Every original browser comparison and assertion remains unchanged. The changes
are an in-place edit helper with 100 ms separation, watcher diagnostics, stdout
result fallback, and an explicit plan describing the new profile and previous
failure. Initial pre-server fixture materialization still uses cp; watched
edits use writeFile with the original target path. Native filesystem delivery
and Vite/React behavior remain the subjects of the experiment; no synthetic HMR
message or manual refresh was introduced. The experiment does not establish
reliability for edits within the watcher's throttle interval.

The workflow selects the distinct v2 archive/manifest. It resolves the dedicated
destination with Path.resolve(), then publishes the normalized absolute path
through GITHUB_ENV before setup, working-directory and upload inputs use it.
This addresses the observed artifact-pattern rejection without weakening tar
verification or changing permissions. Push path filters include both original
and v2 evidence names. A new hosted run is still needed to establish execution
and actual artifact availability; this review alone establishes neither.

## Observed hosted second input: native pass and artifact binding verified

Disposition: **PASS for one native independent-edit sequence, with the stated
development-HMR scope.** This succeeds the failed first input without erasing it.

Commit: c1653881b574b4258fb16a2d44b93a1004c06a94.
Run: https://github.com/agent-teams-ai/extension-foundation/actions/runs/44962153869
Job: 137023114339. Attempt: 1. Every job step concluded success, including the
strict checker, native browser test and artifact upload. Native runner reported
one test passed, zero failed. The parsed result contains 32 unique comparisons;
all actual values equal their independently specified expected values.

The actual browser was Chromium159.0.8154.6 under Node24.22.3. The watcher
observed three Plugin.tsx changes and two volatile.ts changes. Compatible v2
retained state13, real button identity and host draft; old effect cleanup
preceded new setup; the only event listener was current, while a captured v1
Promise callback still completed afterward. Added-hook v3 remounted with11;
changed-initializer v4 remounted with99. Both retained the parent draft and
document. Failed raw import disposed the previous listener before acceptance
received undefined, while recovery constructed a new listener. Full reload
created a new document, kept the current initializer99, and reset the draft.
No unexpected page exceptions occurred.

Downloaded artifact14730306077:
https://github.com/agent-teams-ai/extension-foundation/actions/runs/44962153869/artifacts/14730306077
The exact ZIP has39,290bytes,28members and SHA-256
c15ba9412478a3a1fe2f68ba8e41253f5529e1fc8278d0c5f9c86eff176b0a28,
matching both GitHub artifact metadata and the upload log. Archive CRC checks,
unique safe paths and extraction passed. All18 retained source files match the
v2 input manifest. The hosted receipt binds the exact commit, run, attempt,
input digest and reviewed workflow digest. Installed direct package versions
match the original package manifest. Artifact observations.json equals the
stdout result, including all32 comparisons. The screenshot was visually
inspected: host draft is present, pluginv4 displays99, and no error overlay hides
the recovered page. This is observation, not a production UI design review.

All bytes are retained under hosted/run-44962153869/, including artifact.zip,
its extracted files, complete decoded job log, metadata and verification.json.
The decoded UTF-8 job log has62,409bytes and SHA-256
1716de24a12ffd454e041fd9a6dd03ea4e46460668edd8bd4236ba5931652317.

### Additional observed limitation: a disposer can run again after failure

The actual pre-reload trace contains volatile:v1:dispose twice: before the
intentional failed import and again before recoveryv3 setup. This is consistent
with exact Vite8.3.8 HMRClient.fetchUpdate: it retrieves and invokes the disposer
without deleting the map entry. The broken candidate calls accept but registers
no replacement disposer, so the old one remains until the next successful
module registers its own. The HMRContext constructor clears accept callbacks
and custom listeners, but does not clear the old disposal entry.

Source: https://github.com/vitejs/vite/blob/b39e6e63dcbfc3cf4be871acf3554efbd6d0e268/packages/vite/src/shared/hmr.ts

This observation is not an assertion failure: repeated removeEventListener of
the captured old listener is safe in this fixture. It is a reason to require
idempotent, owner-specific cleanup, and to avoid assuming framework disposal
means exactly one finalizer execution. The source also logs 'hot updated' after
the failed import callback; that log is not a semantic activation receipt.

The change from first input to second changed both edit method and spacing;
successful second execution does not isolate which caused the first timeout.
Rapid-write reliability, broad browser compatibility, sustained churn, leak
freedom, production cutover, and arbitrary state migration remain unqualified.

