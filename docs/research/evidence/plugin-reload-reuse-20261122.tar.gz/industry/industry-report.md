# Industry reload mechanisms: new findings and critical transfer analysis

Research date for the user: **2026-11-22, Europe/Kiev**.
Source retrieval and follow-up review: **2026-11-21 23:12–23:23 UTC**.
Repository baseline: `534fa8469681df447732d9c7f8c916c6f14968e2`.

This is research source material for the existing Extension Foundation research
family. No upstream applications, their tests, or production plugin systems
were executed in this lane. Source inspection, inspected-but-unrun assertions,
documented contracts, and our design inferences are distinguished below.
Twenty-eight primary source records, including immutable blob identities, are
in `sources.json`.

## Main conclusion

The strongest transferable approach is **explicit eligibility plus a controlled
fallback**, with ownership of state and resources established before updates are
enabled. “Preserve everything while changing arbitrary code” is not the common
industrial guarantee. Good systems preserve what their runtime can identify,
reconstruct what their framework owns, and explicitly widen the restart scope
when a change crosses that boundary.

For this project, the user experience goal is valuable: change a plugin without
losing the surrounding application, draft, navigation, or unrelated work. That
does not require keeping the plugin's entire implementation instance alive.
A new TypeScript provider, remounted UI region, fresh Worker, and fresh Wasm
instance can all support this experience when stable application state and
resource ownership live at the appropriate boundary.

Our older generation-pinned research is one legitimate policy, not a universal
definition of hot reload. Flutter/Dart deliberately permits a different kind of
mixed execution history. We should expose the supported change semantics before
claiming that a reload “worked.”

## What is new relative to the repository's existing research

The October and November records already cover OSGi wiring/dependency closure,
OTP two-version code loading, NGINX/Envoy workers, Vite dispose-before-import,
VS Code activation boundaries, durable workflow affinity, and external-effect
uncertainty. This investigation does not present these as new discoveries or
replace their frozen evidence.

The useful additions are:

1. **Flutter/Dart semantic precision:** preserved state can produce a program
   behavior different from both clean old and clean new execution. Captured
   closures/frames and subsequent method lookups have different update behavior.
2. **Flutter's reassembly callback is not a safe-point barrier:** a timer can
   cause new-code rendering before reassembly.
3. **React's concrete preservation decision:** current code checks component kind
   and Hook signatures; inspected tests differentiate preserved state,
   restarted effects, and remounting after initializer/shape changes.
4. **IntelliJ intersection lifetimes:** project-owned work is still too long-lived
   for a plugin. Project × plugin lifetime is the relevant constraint.
5. **IntelliJ plan verification:** current implementation calculates prospective
   state, verifies desired inclusion/exclusion, and serializes reconfiguration.
6. **Readiness limits in production references:** NGINX's worker transition is
   not an arbitrary application health protocol; Envoy intentionally uses
   bounded best-effort discovery during initialization.
7. **Preflight is not automatically inert:** OTP's installation check can
   evaluate instructions before the release script's irreversible point.
8. **Granularity needs multiple graphs:** dependency wiring, state ownership,
   physical execution, and authority scope can force different update closures.

## Eight mechanisms and their limits

### 1. Flutter and Dart: excellent continuity, specific VM semantics

**Documented behavior.** Flutter reload is a development feature. It retains
application state, rebuilds widgets, and does not rerun `main` or `initState`.
Some type changes and native changes require a broader restart. A clean restart
can consequently behave differently from a retained-state reload. [FL-DOC]

**Pinned runtime description.** Dart 3.14.1 describes new method lookup against
updated method dictionaries while closures and existing stack frames keep their
captured function. Existing fields retain values; a not-yet-initialized lazy
static can use its new initializer. Unsupported VM changes can be rejected
atomically. A field rename has no automatic semantic value transfer.
The same file documents pending-stack limitations; those are inspected
documentation, not newly reproduced defects. [DART-SRC]

**Pinned framework/API behavior.** Reassembly marks affected element trees dirty,
but new-code build can happen before `reassemble`; no source-update/reassembly/
build ordering barrier is promised. The hook is absent in release mode.
[FL-SRC, FL-API]

**Transfer inference.** Preserve stable user state and explicitly describe which
code will next execute. Do not promise that an existing operation now belongs
wholly to v2. For our plugin profile, an operation-pinned closed provider set is
more predictable for business work than trying to reproduce a VM's pervasive
late binding. UI preview can deliberately choose a looser development policy.

**Failure trace.** A retained v1 object holds `currency = USD`; v2 changes the
initializer and pricing assumptions to EUR. Updating a method alone changes
calculation without reconstructing the old field. Calling this “state preserved”
does not show the application invariant survived.

**Rejecting scenario.** Change an initializer or state interpretation while
keeping the same structural interface. The host must either accept an explicitly
compatible preservation rule, migrate a validated snapshot, reset the exact
owned state, or select restart/refusal. Include an old closure and an old
operation spanning the update; assert the declared semantics for each.

**Do not build.** A custom TypeScript object-graph rewriter, closure patcher, or
“Dart-like” VM. Existing UI refresh tooling can remain a development adapter.

### 2. React Fast Refresh: reuse, reset, and fallback are separate choices

**Documentation.** React Native's refresh boundary depends on module exports and
importers. A component-only module can update locally; non-component consumers
can widen the change to module reexecution or full reload. Hook state retention
is conditional and dependency-based effects are rerun during refresh. [RN-DOC]

**Pinned implementation.** React main `33e52451` checks component kind and Hook
signatures. A signature lookup failure can select a reset. Updated families
preserve state; stale families remount. This is inspected development source,
not a claim about the project's currently installed React version. [REACT-SRC]

**Inspected tests, not executed.** Upstream tests cover function/memo/forwardRef
shape transitions. Integration assertions show the same component state
surviving while the old effect is cleaned up and the new effect starts. A changed
literal `useState` initializer remounts in the inspected transform; the broader
initializer analysis is explicitly best effort. [REACT-TEST, REACT-INTEGRATION]

**Transfer inference.** An update should report at least three distinct outcomes:
implementation preserved with state, component recreated with stable external
state restored, or a broader execution boundary restarted. The author should
not have to recreate this classifier for every component, but a UI renderer's
classifier cannot certify arbitrary plugin state.

**Failure trace.** A payment or subscription action placed in a UI effect fires
again during refresh. Retained `useState` gives the impression of continuity,
but the external effect may have duplicated. That is why lifecycle setup should
register reversible owned resources; domain actions need their existing
idempotency/effect owner.

**Rejecting scenario.** Retain a host-owned draft outside an update region, then
force that region to remount. Verify the draft survives, exactly one listener
remains, the old listener cannot remove the new registration, and the chosen
external-effect policy is enforced independently.

**Do not build.** Another React reconciler, refresh transform, Hook-shape
inference engine, or generic DOM state serializer.

### 3. Vite: acceptance boundaries and cleanup, not an application transaction

**Documented contract.** An accepted boundary does not automatically rewire all
previous imports. The boundary can forward new exports, invalidate importers,
dispose owned side effects, and preserve bounded module data. [VITE-API]

**Pinned implementation.** At `3567471998e3da315675086f44368e266c9c0e33`,
`HMRClient.fetchUpdate` awaits disposal before importing the new module.
Import failure is logged and the acceptance callback can receive no replacement.
Pruning invokes lifecycle callbacks and clears its data in a `finally` block.
These findings agree with the earlier stable-source investigation. [VITE-SRC]

**Transfer inference.** Use the actual bundler/HMR plugin for development rebuild,
module invalidation, and renderer integration. If production updates promise
“old implementation stays healthy until candidate readiness,” the application
handoff must use a different qualified resource ordering. A successful HMR
transport event does not establish restored resources after a bad import.

**Failure trace.** v1's disposer removes a subscription. Importing v2 throws.
The page remains open and the old module reference exists, but its subscription
is gone. “Old code still selected” is insufficient evidence of availability.

**Rejecting scenario.** Fail candidate evaluation after an actual v1 resource has
been acquired. Verify the supported profile either preserved v1 resources,
reconstructed them with an observed receipt, or reports its interrupted/restart
outcome. Do not only compare a router pointer.

**Do not build.** A file watcher/compiler dependency scanner, own cache-busting
module loader, or proxy-import system to obtain commodity development HMR.

### 4. IntelliJ: eligibility, intersection scopes, and honest restart fallback

**Documentation.** Production dynamic plugin updates are supported subject to
eligibility restrictions. Failure to unload can require IDE restart, and
retained classloaders can be diagnosed. This is positive production evidence for
bounded live replacement, not evidence of arbitrary native/JVM unloading.
[IJ-DOC]

**Resource lifetimes.** Current coroutine guidance binds plugin service work to
application/project and plugin intersection lifetimes. Cancellation is followed
by awaiting scope completion. Attaching plugin work only to a longer-lived
project can retain plugin classes; attaching it to another plugin's scope is
also wrong. [IJ-SCOPE]

**Pinned source.** Current `DynamicPlugins.kt` calculates a prospective state,
checks expected included/excluded plugins, asks the dynamic support layer to
validate the transition, and rejects overlapping reconfiguration under a lock.
The mutation path verifies expectations again. These inspected internal APIs
are not recommended as an extractable TypeScript library. [IJ-SRC]

**Transfer inference.** The smallest correct lifetime can be the intersection
of session, plugin generation, and capability owner. Reuse the existing scope
mechanism; do not attach everything to a global application scope just because
that object is conveniently reachable. Preflight should explain the affected
units and fallback before disturbing the active application.

**Failure trace.** Plugin v1 starts a task in a project-wide scope. Plugin v2
loads successfully and v1's own scope is closed. The old task still accesses a
captured v1 object and prevents reclamation.

**Rejecting scenario.** Stop the plugin while leaving the project/session
active, and then close the session while leaving another plugin instance active.
Each should stop only its owned work. A late cleanup from v1 must not erase v2's
registration. A plugin requesting an unsupported native/exclusive resource must
produce an explicit restart plan before partial teardown.

**Do not build.** A second structured-concurrency tree, another disposer
registry, or arbitrary reference interception. Use the existing responsible
lifecycle owner and expose its real limits.

### 5. OSGi: explicit rebinding policy and executable dependency closure

**Versioned contracts.** Declarative Services distinguishes static/dynamic
binding and reluctant/greedy selection. Unary dynamic replacement binds the new
service before old unbind; old cleanup must not overwrite the replacement.
Loss of minimum cardinality still forces deactivation. [OSGI-DS]

Bundle Wiring separately retains old revisions while dependencies use them.
Refreshing computes dependent closure and restarts active bundles in that
closure. Updating an artifact does not automatically replace its consumers'
existing wiring. [OSGI-WIRING]

**Transfer inference.** Build the affected set from the real dependency/
retention model already owned by Get Modular and the product. “Plugin A changed”
is a request, not proof the minimum safe operation affects only A. Prefer
explicitly selected replacement over automatic greedy rebinding where repeated
change causes surprising restart cascades.

**Failure trace.** A and B share C. C's registry entry switches to v2, A resolves
the entry anew while B retains C-v1. One business operation now mixes C versions.
The update's selection map looks correct while the execution closure is wrong.

**Rejecting scenario.** Change the provider under a dependency diamond and
hold an operation across the publication point. Assert either immutable old/new
operation closures or a clearly documented dynamic-rebinding contract. Test a
late old unbind after the new bind.

**Do not build.** Another graph solver, dependency registry, or universal service
locator inside the plugin-update layer. The already owned composition mechanism
must remain authoritative.

### 6. Erlang/OTP: explicit safe points and rejection with finite coexistence

**Pinned APIs.** OTP 29.1.2's group load can apply all modules or reject, with
preparation separated from finishing. Old-code references can prevent a soft
purge; forced purge can terminate their processes. An atomic code-load claim
therefore does not imply atomic process-state conversion. [OTP-CODE]

The release handler's check can evaluate instructions before the script's
`point_of_no_return`. Recoverable installation errors restore application
specifications; nonrecoverable errors can restart the node. Making the installed
release the reboot default is a separate action. [OTP-RELEASE]

**Transfer inference.** Name the actual safe point and irreversible boundary.
Keep “candidate can load,” “current work transferred,” and “restart will choose
this version” as separate facts. Call a preview read-only only when its selected
actions really are inert; a method called `check` is not evidence.

**Failure trace.** A preflight invokes a plugin's initialization callback that
starts a timer or contacts a remote service. A subsequent compatibility check
rejects the plugin. Calling this a dry run hid a real effect.

**Rejecting scenario.** Admission/compatibility preview must not execute plugin
code unless an explicitly disposable preparation profile owns the effects.
Hold old work so soft retirement cannot complete, request a third generation at
the configured bound, and verify truthful deferral instead of unbounded growth
or silent forced termination.

**Do not build.** A BEAM-style code loader or release-handler emulator in
TypeScript. Reuse executor isolation and application-controlled checkpoints.

### 7. NGINX: independent generations and scoped resource ownership

**Documentation.** Configuration reload validates a new cycle while the old one
remains available on preparation failure. New workers take new work while old
workers finish existing clients. The developer guide discourages unnecessary
custom modules and ties reload-sensitive state to configuration pools, including
attention to library globals. [NGINX-DOC, NGINX-DEV]

**Pinned implementation nuance.** In the inspected master loop, successful cycle
creation is followed by starting workers, a 100 ms delay, and predecessor
shutdown signaling. This is not an arbitrary plugin application's semantic
readiness acknowledgment. [NGINX-SRC]

**Transfer inference.** Own generation resources explicitly and retain old
operations without pretending to move their stacks. Copy the architectural
pattern, not the readiness assumption. A plugin that must connect to a model,
database, browser, or remote integration needs that capability's actual readiness
contract.

**Failure trace.** Candidate worker starts but a required connection cannot
authenticate. A fixed startup delay expires; old work is retired. The new
process is alive and still unable to provide the feature.

**Rejecting scenario.** Delay or fail a required capability after process creation.
The update remains unready and retains the old feature under the selected
overlap-safe profile. Also inspect shared SDK global caches: two generations
must not overwrite each other's supposedly private configuration.

**Do not build.** An additional OS supervisor, socket inheritance system, or
connection pool when the existing executor/server already owns those mechanisms.

### 8. Envoy: readiness and publication are layered, not one “updated” flag

**Versioned documentation.** Envoy 1.40.2 initializes the new process before
listener handoff and predecessor drain; existing connections stay in the old
process and eventually complete or terminate. Drain and parent shutdown have
independent deadlines; platform and socket-option limits remain. [ENVOY-HOT]

Initialization deliberately waits a bounded time for discovery response or
failure, with best effort within `initial_fetch_timeout`. [ENVOY-INIT]
An xDS ACK establishes resource validity and intent, not successful application;
dependency ordering still matters. [ENVOY-XDS]

**Transfer inference.** Show separate states for validated, prepared, ready,
published for new work, old work pending, and retired. A capability's readiness
predicate needs an application meaning. Do not infer a fleet transaction from a
stream acknowledgment or report a generic SDK close as physical exit.

**Failure trace.** Metadata is valid and worker construction succeeds; required
provider warming times out. The controller reports “updated” and users see
errors. Alternatively the new path works, but a predecessor stream remains
indefinitely live while the controller reports retirement.

**Rejecting scenario.** Independently delay readiness, acknowledgment, old work,
and cleanup. Verify each status names the observed fact. A lost acknowledgment
must reconcile the same operation identity, not execute another update blindly.

**Do not build.** A miniature xDS control plane or full fleet controller merely
to replace one local feature. Use the product's existing scheduling,
configuration, and executor ownership.

## A useful replacement classification for our design

The following is a **research proposal**, not a universal interface, schema, or
accepted runtime. It helps decide the supported operation for a real feature.

| Change | Smallest plausible unit | State policy | Fallback |
| --- | --- | --- | --- |
| Pure formatting/presentation logic | Existing renderer boundary | Preserve stable host-owned draft; framework owns transient UI state | Remount the region |
| Read-only stateless provider logic | Provider instance or closed cohort | Keep immutable input; no private durable state transfer | Recreate the cohort |
| Listener/timer/subscription setup | Owning resource scope | Release/reacquire exactly owned resources | Restart owning executor when reliable close is unavailable |
| Shared dependency behavior/ABI | Existing dependency closure | Preserve state only under declared compatibility | Recreate dependent cohort |
| Private state representation | State-owning feature | Explicit preserve, directional migrate, reset, or reject | Controlled restart with retained/compatible state |
| Exclusive OS/device/session resource | Existing physical-custody owner | Fenced handoff or deliberate service gap | Stop/reconstruct with recovery plan |
| Long durable workflow | Existing workflow/version boundary | Pin, checkpoint-transfer, or reconcile | Keep old capacity or recover explicitly |
| Host/runtime/security invariant | Protected application/process boundary | Existing deployment/migration contract | Full controlled restart |

A granular change does not imply a granular physical stop. Several logical
components in one Worker share its kill boundary. A Wasm instance can be a
narrower execution object, but shared host callbacks, stores, and external
services still have independent lifetimes. Avoid a capability method named
`forceStop` if the adapter can only request cooperative cancellation.

## Preflight information worth showing before the user applies an update

This is a proposed product interaction informed by the evidence, not another
management subsystem:

- Which exact artifact/implementation is replacing which one.
- The affected components and why dependencies or shared execution widen them.
- Whether current operations finish on the old code, cancel cooperatively,
  transfer at an explicit checkpoint, or are interrupted under prior authority.
- What state survives, what resets, what migrates, and which direction is
  compatible.
- Expected availability/service gap and exclusive resources involved.
- What rollback can actually restore; external effects remain separate.
- Why live replacement is supported or why a particular restart is needed.
- Which facts remain uncertain and what evidence the operation will produce.

The planner should consume the existing composition, artifact, and execution
facts. It should not create a competing registry or make users approve opaque
plans containing dozens of generic phases.

## Best next rejecting experiments

These are ordered by **new decision value**, not by arbitrary coverage count:

1. **Intersection resource lifetime and stale disposer.** Real subscription/task,
   two plugin generations, session retained. Verify owner-exact cleanup and no
   newer registration erased. This tests the proposed TS adapter seam directly.
2. **State preservation versus remount.** A tiny real renderer component update
   keeps a host draft, recreates the plugin region when necessary, and disposes
   subscriptions. Distinguish real renderer behavior from a plain Worker demo.
3. **Dependency closure with held work.** A/B→C diamond and a change in C. Verify
   the selected operation policy; a single dispatch-result check is insufficient.
4. **Failed candidate after resource acquisition.** Candidate init failure must
   preserve or honestly reconstruct old resources, not just an old pointer.
5. **Readiness and cleanup independently delayed.** A process-ready event is not
   feature-ready; timeout is not cleanup completion.
6. **Unknown state interpretation.** Same TS/WIT shape, incompatible semantics.
   Reject preservation before publication and show the restart/migration reason.
7. **Bounded churn.** Repeated valid and failed updates with retained old work
   must reach a configured capacity outcome; record resources, not only callbacks.

The existing November 21 backend/browser/Wasm experiments already qualify
specific drain/cancel/force/stale-result and scalar adapter paths. Do not repeat
them without a changed input or concrete uncovered risk. The experiments above
should use the current lifecycle/composition owners and a disposable feature,
rather than being a pretext to implement a new platform.

## Remaining uncertainty and falsification criteria

**Runtime-specific classification.** We have source evidence for renderer/VM
heuristics, not evidence that a universal classifier can determine compatibility
from types alone. A real feature requiring opaque retained objects can falsify
the minimal value-boundary proposal.

**Actual consumer resource graph.** Existing docs identify owners, but measuring
a real consumer may reveal hidden listeners, native handles, globals, and
cross-feature caches. That evidence should determine the minimum restart closure.

**Old-version retention.** Finite local updates are easier than durable work
that sleeps for days. Neither a fast local spike nor a bounded module count
establishes a production retention/memory budget.

**Readiness.** The exact first extension point must name what a useful warm-up
proves and what side effects it is allowed to perform. A successful constructor
alone may be too weak; an invasive live operation may be too strong.

**Language neutrality.** State and resource boundaries should be portable where
needed, but ordinary in-process TypeScript must not pay for a universal wire
protocol. The Wasm adapter must prove the actual contract, not force every
extension into serializable bytes or identical kill semantics.

**Production advantage.** A credible advantage is predictable supported updates,
clear impact/state outcomes, and recovery evidence under tested failures.
“Better than Flutter/OTP/Envoy” or “bug-free hot reload” is not justified by this
research. Those systems deliberately optimize different boundaries.

## Source navigation

All source IDs below map to the detailed provenance ledger.

## Browser probe follow-up: initializer hypothesis corrected

The first root draft proposed preserving state while changing the initializer.
This was challenged before execution: the inspected React Babel-based tests
already expect simple initializer changes to reset state. The actual fixture uses
a different default transform, so transferring that test expectation without
checking its selected toolchain would also be insufficient.

The exact proposed fixture chain is Vite8.3.8, plugin-react6.3.0,
Rolldown1.2.19, and Oxc transformer0.156.0. The released plugin enables Oxc
refresh by default; Vite delegates native transforms to Rolldown. Rolldown's
Cargo lock identifies the selected transformer. Its source incorporates the
first `useState` argument's source text into the Hook signature. The arrow
initializer `() => 11` changing to `() => 99` therefore changes the signature.
[VITE-REACT-PKG, VITE-REACT-SRC, VITE-OXC, ROLLDOWN-CARGO, OXC-REFRESH]

**Correct independent prediction:** use identical initializer source for the
state-preserving positive control; separately expect remount and99 for the
changed-arrow-initializer case. Record the actual native result. A test failure
must trigger investigation or a documented contrary observation, not a silent
weakening to accepting any output. This is a useful example of why “same Hook
order” is not enough to claim semantic compatibility.

The prediction above was made before execution. Native-attempt evidence is
recorded separately below and in review.md. No installed dependency was modified.

- **VITE-REACT-PKG:** [@vitejs/plugin-react6.3.0](https://github.com/vitejs/vite-plugin-react/blob/0e95069a8f90489da74371c9ad35dfc619c1b72e/packages/plugin-react/package.json); blob `d89611f2f084b2c61105c42b204265bc01dab788`.
- **VITE-REACT-SRC:** [@vitejs/plugin-react6.3.0](https://github.com/vitejs/vite-plugin-react/blob/0e95069a8f90489da74371c9ad35dfc619c1b72e/packages/plugin-react/src/index.ts); blob `102ae2db51b7d296afc85ee914c1fc11cdcb6aad`.
- **VITE-OXC:** [Vite8.3.8](https://github.com/vitejs/vite/blob/b39e6e63dcbfc3cf4be871acf3554efbd6d0e268/packages/vite/src/node/plugins/oxc.ts); blob `c28af099d9278f101ca260182573c1c84848d969`.
- **ROLLDOWN-CARGO:** [Rolldown1.2.19](https://github.com/rolldown/rolldown/blob/b9c75ddc8bd50f2c1a4c7be0b548bdab5cba85ab/Cargo.lock); blob `60aac3edc8ba2597a4a52b37a652b2ce8f811d60`.
- **OXC-REFRESH:** [oxc_transformer0.156.0](https://github.com/oxc-project/oxc/blob/75efdca4747c4ad9b252542743098d4894f8005b/crates/oxc_transformer/src/jsx/refresh.rs); blob `bd12beb1cdbc22c9173018f598dcde2e1e8894ff`.


- **FL-DOC:** [Flutter documentation current 2026-11-22](https://docs.flutter.dev/tools/hot-reload).
- **FL-SRC:** [Flutter 3.50.1 stable](https://github.com/flutter/flutter/blob/ae9b586f34a8443573f82ef57c3bf914a908cbf7/packages/flutter/lib/src/widgets/framework.dart); blob `0242e1dd9704f5b236d6d177498af65003725675`.
- **FL-API:** [official moving API documentation](https://api.flutter.dev/flutter/widgets/State/reassemble.html).
- **DART-SRC:** [Dart 3.14.1 stable](https://github.com/dart-lang/sdk/blob/c8a0db5978a68d4037f7e5294ffc79867935c8c2/runtime/docs/hot-reload.md); blob `2e46e1fe6176cbd1793a6d7e1db46b9330aae33e`.
- **RN-DOC:** [React Native 0.88; page updated2026-10-27](https://reactnative.dev/docs/fast-refresh).
- **REACT-SRC:** [React main inspection, not release qualification](https://github.com/react/react/blob/33e52451f2ab39e0a4d186256b2b4d55277e6041/packages/react-refresh/src/ReactFreshRuntime.js); blob `5448d23f22e8986da47f51ecda7b305bfb36a564`.
- **REACT-TEST:** [React main tests inspected only](https://github.com/react/react/blob/33e52451f2ab39e0a4d186256b2b4d55277e6041/packages/react-refresh/src/__tests__/ReactFresh-test.js); blob `663643a0095108ac431b3fc6787f99a7fdd386ce`.
- **REACT-INTEGRATION:** [React main integration tests inspected only](https://github.com/react/react/blob/33e52451f2ab39e0a4d186256b2b4d55277e6041/packages/react-refresh/src/__tests__/ReactFreshIntegration-test.js); blob `cbadf5ec79e4d9e665806f29792e1d1bcbfa7922`.
- **VITE-API:** [official moving documentation](https://vite.dev/guide/api-hmr).
- **VITE-SRC:** [Vite main3567471; relevant ordering matches prior stable research](https://github.com/vitejs/vite/blob/3567471998e3da315675086f44368e266c9c0e33/packages/vite/src/shared/hmr.ts); blob `6e2ef7de0de852aec6417e9d91b60556cc2f834b`.
- **IJ-DOC:** [official moving documentation](https://plugins.jetbrains.com/docs/intellij/dynamic-plugins.html).
- **IJ-SCOPE:** [page dated2026-11-10](https://plugins.jetbrains.com/docs/intellij/coroutine-scopes.html).
- **IJ-SRC:** [IntelliJ master inspection, not exact shipped release](https://github.com/JetBrains/intellij-community/blob/aac269f41b10472bda9c45d90d87ea9e3bdb87a7/platform/platform-impl/src/com/intellij/ide/plugins/DynamicPlugins.kt); blob `5c9d95c2c41d2733e75c8daf42c793847f04468c`.
- **OSGI-DS:** [OSGi Compendium8.1 Declarative Services1.5](https://docs.osgi.org/specification/osgi.cmpn/8.1.0/service.component.html).
- **OSGI-WIRING:** [OSGi Core8 Bundle Wiring1.2](https://docs.osgi.org/specification/osgi.core/8.0.0/framework.wiring.html).
- **OTP-CODE:** [OTP29.1.2](https://github.com/erlang/otp/blob/OTP-29.1.2/lib/kernel/src/code.erl); blob `30f4d06a07982ac0967fe0f105ef849158f48d5f`.
- **OTP-RELEASE:** [OTP29.1.2](https://github.com/erlang/otp/blob/OTP-29.1.2/lib/sasl/src/release_handler.erl); blob `cdb2409630a29e6e42aeaaf30a9750a4e49b1f71`.
- **NGINX-DOC:** [official moving documentation](https://nginx.org/en/docs/control.html).
- **NGINX-DEV:** [official moving documentation](https://nginx.org/en/docs/dev/development_guide.html).
- **NGINX-SRC:** [NGINX master inspection](https://github.com/nginx/nginx/blob/2e8440bcdc438f0f1cd03da778a3843ddb3c86d9/src/os/unix/ngx_process_cycle.c); blob `c6338305cfac114711d9634e91367e30e3669a12`.
- **ENVOY-HOT:** [Envoy1.40.2](https://www.envoyproxy.io/docs/envoy/v1.40.2/intro/arch_overview/operations/hot_restart).
- **ENVOY-INIT:** [Envoy1.40.2](https://www.envoyproxy.io/docs/envoy/v1.40.2/intro/arch_overview/operations/init).
- **ENVOY-XDS:** [Envoy1.40.2](https://www.envoyproxy.io/docs/envoy/v1.40.2/api-docs/xds_protocol).



## Hosted browser follow-up: first attempt rejected, evidence limit retained

Run [44961594670](https://github.com/agent-teams-ai/extension-foundation/actions/runs/44961594670)
at commit 30b9823aacecc0728ebf72c2e450e7c8c06b93e2 passed archive/dependency
verification and strict TypeScript checks, installed native Chromium, and failed
the v3 wait. Reaching that statement implies the preceding v2 assertions passed,
including state/DOM retention, listener cleanup and the late old callback. It
does not establish remount or later raw-module behavior. The final artifact
upload also failed because its path contained a literal '..' component; no
browser artifact survived. Complete decoded job logs and the empty artifact
response are saved with independent review notes. [BROWSER-ATTEMPT1]

The harness used fs.cp to replace a watched path. Node's implementation unlinks
the existing target, while Vite's selected Chokidar implementation suppresses
same-path change events for 50 milliseconds. The exact Vite patch does not
change that throttle. This provides a plausible instrumentation explanation
for only one HMR update appearing before the v3 timeout, not a demonstrated
root cause. Root was advised to use ordinary in-place editing, document edit
spacing beyond the source-defined throttle, record watcher events, and preserve
every original browser oracle. [NODE-CP, VITE-WATCH-LOCK, VITE-WATCH-PATCH, CHOKIDAR-THROTTLE]

This failure is useful counterevidence to treating a plausible source review or
strict typecheck as native execution success. The implementation hypothesis and
the business observation must remain separately rejectable.


## Hosted browser follow-up: revised input passes with bounded evidence

The distinct second input was published at c1653881b574b4258fb16a2d44b93a1004c06a94.
[Run44962153869](https://github.com/agent-teams-ai/extension-foundation/actions/runs/44962153869)
passed all workflow steps, including strict checks, one actual Chromium test
and artifact retention. All32 unique comparison results match their expected
values; the downloaded artifact, all18 input files and hosted receipt were
independently bound to the reviewed source and workflow. Detailed hashes, raw
logs, exact observations and limitations are in review.md and hosted/ evidence.
[BROWSER-INPUT2]

The observed compatible update retained state and real element identity; Hook
and initializer edits remounted with their expected initial values; host draft
survived both component remounts. Effect cleanup did not revoke the held old
Promise continuation. The broken raw-module import left its old resource
disposed, and recovery constructed a new one. Full reload reset the host draft.
This validates the narrow predicted distinction between development refresh,
component remount and restart, using the released renderer/toolchain rather
than a handwritten runtime. [BROWSER-INPUT2]

An additional failure-path detail matters for resource ownership: the original
raw disposer ran twice, once before the failed import and once before recovery.
Vite's exact implementation retains the disposal map entry until a replacement
registers another; the broken fixture registered accept but no new disposer.
The existing callback therefore ran again. The native trace corroborates this
source path. Cleanup must be idempotent and refer to the resource it acquired;
framework HMR is not an exactly-once finalizer protocol. Vite also logs a hot
update after the failed-import acceptance callback, so that log must not become
a product's semantic activation receipt. [VITE-HMR-EXACT, BROWSER-INPUT2]

The second input intentionally changes both file-edit method and100ms spacing.
Its success does not prove which condition caused the original timeout, nor
qualify rapid writes, repeated churn, arbitrary state migration or production
replacement. The first failed run and both immutable input archives remain part
of the evidence.
