# Reuse and architecture audit: controllable plugin replacement

Observed **2026-11-22, Europe/Kiev**. This is an independently researched,
non-normative report and a disposable experiment. The user confirmed Extism as
the remembered library and requested explicit warnings wherever we might build
an existing mechanism again. The inspected Extension Foundation baseline is
`534fa8469681df447732d9c7f8c916c6f14968e2`.

## Executive finding

The largest current risk is **promoting research machinery into another generic
runtime**, not an already shipped proprietary Wasm engine. EF's package catalog
contains zero production packages. Its substantial implementations are
qualification fixtures: graph-spike 520 lines, lifecycle-spike 1,439, recovery
424, dogfooding protocol reducer 3,141, and portable protocol 493. These line
counts identify inspected research code; they are **not a measurement of
duplicated production code**. No claim about all organization source follows.
The 17-line manually connected Rust scalar guest from the prior experiment is
also a bounded fixture, not a general SDK. [E1, E2, E3, E4]

The new resource experiment demonstrates useful reuse directly: the released
`@get-modular/resources@0.2.2` handles acquisition, late completion, ordered
cleanup, unresolved debt and retry. Six strictly checked native tests pass,
including 250 generation cycles and 249 replacements with exact registration accounting. The fixture's
small application selection comparison, operation lifetime, and exact resource
identity remain necessary; Resources deliberately cannot infer these facts.
There is no second manager, lifecycle kernel or plugin package in the experiment.

**Recommended direction:** native TypeScript first, consumer-owned semantic
ports, optional Wasm execution profile. Qualify generated bindings or Extism
behind a particular suitable port. Do not convert every local TypeScript API to
a serialization protocol, and do not use a generic `Plugin` interface to erase
real differences among pure calculations, UI contributions and stateful workers.
This is a recommendation, not a selected runtime or public SPI. [E2, E4, G1]

## Verified ownership and availability

| Source inspected | Actual status | Consequence |
| --- | --- | --- |
| EF AGENTS, architecture overview, ADR-0014 and ADR-0015 | GM owns neutral declaration/graph/plan semantics; consumer owns concrete ports and loader/runtime authority; EF has no production package | Do not add a graph compiler, service locator or new runtime package merely to host Wasm. |
| GM current main `33c032f829028967825428bc6b049ed6db1c56b2` | Core/Assembly source 0.8.0, Resources 0.2.2, Observation 0.2.1, Effect integration 0.1.1 | Source availability is separate from the consuming product's adopted pin. Resources 0.2.2 was additionally installed and executed from npm here. |
| GM Effect integration README/practices | Published native integration; qualified Effect peer 4.1.4 and Core/Assembly 0.8.0; native resources remain Effect-owned | Do not wrap native Layers in a second generic disposer or assume bare Promise wrappers preserve fibers, errors and cancellation. |
| GM lifecycle-kernel README/manifest | Private, unreleased synchronous candidate; no loading, permissions, async supervision or physical cleanup | Do not deep-import it, copy it, rename it, or describe it as an available production plugin runtime. |
| Orchestrator current main `a34587b313e656eeb43d755b4a4f08c40dff2116`, ADR-0117 | Retains exact Core/Assembly 0.5.0 and CMS pin `a3a079baca2c6af48c9d45bc08992825be1c2bbd`; production materialization remains gated | This research does not upgrade that consumer to current GM or adopt Effect there. Additional libraries require an exact compatible profile at first use. |
| EF ADR-0002 and Orchestrator OD-041 | OCI Distribution, ORAS and Cosign already selected for artifacts; product adoption still needs integration evidence | A custom registry or signing protocol would conflict with an existing reuse decision. |
| Backend reference plus its local adoption | Fastify/Connect/Protobuf at relevant process boundaries, NATS for durable delivery, Temporal for durable workflow, PostgreSQL for canonical persistence | These are owners to reuse where adopted; they are not dependencies of every browser module or ordinary local call. |

These observations are based on current source inspection, not claims that the
entire products already implement their selected architecture. [E1–E5, G1–G8,
O1–O3, P1]

## Warning register

The following 24 surfaces cover the credible duplication risks found in the
examined scope. They are actionable review warnings, not a new approval process,
a ban on small adapters, or a claim that every listed mistake exists today.
Each warning names what should trigger investigation and what remains unknown.

| ID / surface and owner | Reuse before writing | Warning and exact follow-up |
| --- | --- | --- |
| W01 Metadata discovery and inventory — consumer loader, GM declaration owner | Existing inert declarations, generated read-only inventories and literal target-local import tables; EF ADR-0014 | **Warn if discovery imports all installed plugins or adds a hand-maintained global registry.** Verify zero top-level evaluation of unselected/invalid sentinels. Automatic import-table generation needs measured wiring complexity; inert catalog discovery never grants execution. |
| W02 Executable loading and cache invalidation — target loader/build adapter | Runtime module loader and selected bundler; Vite HMR in development; isolated execution instance where reset is required | **Warn if `?version=` or deleting a cache is described as complete reload.** Node loads query-distinct ESM URLs, but a new entry URL does not version relative imports or release retained exports. Qualify the full import closure, lazy imports, cleanup and churn on each target. [N1] |
| W03 Composition, DI, dependency ordering — Get Modular | Core/Assembly and the consumer's exact accepted profile | **Warn on another resolver, topological compiler, priority-by-registration convention, universal service bag, or production import of EF graph/lifecycle fixtures.** Missing graph capability belongs to GM's owner; do not repair it with a shadow compiler. [G1, O1] |
| W04 Affected component closure — GM topology plus consumer lifetime/import evidence | Existing immutable composition plan and generated reverse dependency information; platform-native HMR graph only for its own role | **Warn when replacing a single provider while live consumers retain it, or creating a second authoritative dependency graph.** Check construction, code-import and operational retention edges. A changed source file, plugin artifact, contribution, generation and worker are different units. Unknown retained edges require expanding the supported restart boundary or declining the update. [E4] |
| W05 Commands, hooks and registrations — capability and registration owners | Narrow declared ordered capabilities; Node/framework event APIs for local notifications; exact disposable registrations | **Warn on a new global event bus or cleanup by logical name alone.** Test late old cleanup after v2 registers the same logical hook. Remove the exact owned callback/token; `removeAllListeners` can delete the successor. State notifications are not durable commands. [O2, new case2] |
| W06 Resource acquisition and cleanup — resource owner | `@get-modular/resources` in its qualified ordinary profile, or native Effect Scope/Layer in an Effect profile; appropriate standard disposal APIs | **Warn on a second cleanup stack, refcount, retry journal or ownership of the same resource by both GM Resources and Effect.** Qualify close during acquisition, late settlement, cleanup failure, reentrancy and borrowed ownership. `complete` reports callback completion, not universal physical release. [G2, G3, G4] |
| W07 Work retention, cancellation and streams — owning operation | Native structured concurrency/fibers where adopted; AbortSignal at foreign IO; resource scope around actual stream consumption | **Warn when returning a stream/promise is counted as work finished, a new root runner loses the caller's context, or abort is reported as stopped.** Test a delayed stream after selection changes and a foreign call that ignores abort. Never restore a closed construction Scope through captured context. [G3, G4, new cases1/5] |
| W08 Execution pools and supervision — actual execution/custody owner | Existing Node Workers/process platform; qualified Piscina/workerpool profile only if fitting; existing local supervisor/hosted platform | **Warn if every plugin adds a process manager, a second keeper, or a pool is treated as one stable worker incarnation.** Qualify kill scope, worker respawn, pending task disposition, descendants and exact exit observation. Prior multiworker pool counterexamples remain relevant; don't erase them by calling `close()` a drain. [E4, O2, N2] |
| W09 Sandboxing, CPU/memory and hard interruption — security/runtime profile | Extism/Wasmtime/WASI or an existing process containment owner, with SDK-specific qualification | **Warn if Worker, signature, WIT or a generic `cancel()` boolean is advertised as a sandbox or universal hard stop.** Qualify CPU loop, stalled host import, external memory, shared executor collateral interruption, malicious imports and actual termination receipt on the selected OS/runtime. Native/JS SDK parity is open until tested. |
| W10 Wasm engine, ABI and code generation — execution adapter/toolchain | Extism SDK/PDK for its ABI; jco/ComponentizeJS for JS component tooling; wit-bindgen for guest bindings; Wasmtime host bindings; evaluate wasmCloud's supported host or exact source embedding before building a backend workload host | **Warn on handwritten general Canonical ABI code or treating Extism ABI and WIT components as interchangeable.** Current wasmCloud v2.12.3 marks wash-runtime internal and publish=false: source embeddability is not a released library contract. The scalar Rust fixture is not SDK code to grow. Choose a real structured interface, generate bindings and qualify results/errors/imports/ownership. Runtime selection remains open; see the companion Extism report's pinned E13 source. |
| W11 RPC and worker messaging — transport adapter | Existing Comlink/workerpool where appropriate; adopted Connect/gRPC/Protobuf at real service boundaries | **Warn on a universal RPC proxy, handwritten promise-correlation framework or hand-framing protocol promoted from qualification code.** Determine the residual need after existing transport. Request IDs are not operation identity or authorization; releasing a proxy does not prove drain or process exit. No serialization layer is needed for ordinary same-process TS calls. [P1, N3, E3] |
| W12 Data codecs and compatibility — owning semantic/wire contract | Existing schema tooling, generated Protobuf or WIT codecs for the boundary actually selected | **Warn if SDK DTOs enter domain code, several handwritten decoders drift, or matching types/ABI are treated as behavioral compatibility.** Independently exercise inputs, outputs, errors, version rejection, ownership, limits and capability requirements. A future portable subset can coexist with richer native-only ports. [E2, E4, P1] |
| W13 State storage, migration and resume — feature/domain owner | Existing canonical state store and its migration machinery; Temporal or another explicitly selected checkpoint/history runtime where suitable | **Warn on universal heap/closure serialization, copying mutable plugin state at an arbitrary instant, or claiming rollback undoes new writes.** Specify what survives: host draft, durable record, plugin-private cache, checkpoint or nothing. Test mixed-version read/write and recovery after partial migration. Arbitrary suspended-stack transfer remains unsupported. [E4, P1] |
| W14 Reactive state and cache ownership — state owner | Existing GM Observation for coalescible latest state, native Effect state/stream primitives in their profile, existing application caches | **Warn if Observation becomes an event broker, duplicate state authority, or replacement fencing mechanism.** Can intermediate changes be dropped? If not, use the durable event owner. Test listeners and stale loaders across retirement; coalescing/data revision checks don't revoke executable authority. [G5, O2] |
| W15 Durable update orchestration and crash recovery — existing lifecycle operation | Existing product operation/reconciliation records and adopted Temporal scheduling | **Warn on another generic update database, saga engine, outbox, periodic reconciliation loop or independently advancing coordinator.** Prove a residual shared mechanism before extraction. Stable operation identity and receiver-enforced authority survive lost acknowledgments; a workflow Activity calling a mutable endpoint does not pin the plugin by itself. [E4, P1] |
| W16 Admission queues, retries and backpressure — admission/executor owner | Runtime/pool limits, existing queue primitives and adopted durable broker | **Warn on an unbounded pending-call Map, automatic retry after force, or a new queue implementation inside each plugin adapter.** Qualify overload, fairness, cancellation removal and unknown-effect reconciliation. Limits must cover tenant/host totals, overlapping failed candidates and retained generations, not just one pool. [E4, P1] |
| W17 Selection, publication and rollback — canonical active-head owner | Existing compare-and-set/revision transaction, immutable plan/artifact, existing recovery operation | **Warn on mutable global `enabled`, last-completing-candidate-wins, or resetting the head counter during rollback.** Revalidate expected revision and grants before selecting. Restoring old bytes is a fresh forward generation; post-publication cleanup debt does not automatically mean v2 failed. Small fixture CAS is policy demonstration, not a new durable library. [E2, new case4] |
| W18 Capability grants and revocation — product authorization and effect recipient | Existing authorization adapter and receiver-side epoch/revision checks; narrow host functions for guest effects | **Warn if manifest requests, signed packages, successful import, language choice or agent authorship grants authority.** Test revoked host calls and stale callbacks at the actual recipient. A preflight permission check followed by awaited IO leaves a race unless the chosen promise accounts for it. Direct credentials can bypass a host fence. [E1, E2] |
| W19 Artifact registry, hashing and signing — EF distribution/trust adapter | Already selected OCI Distribution, ORAS, Cosign; immutable digest identity | **Warn on a custom artifact protocol or signature verifier, a registry per runtime language, or mutable tags as active identity.** Qualify one same artifact through approved registries/auth profiles. Signature validation proves the selected trust claim, not permission or safe behavior. [E5, O3, N4] |
| W20 Catalog and federation — catalog authority | Existing PostgreSQL-backed canonical source, deterministic authority route, signed immutable snapshots | **Warn on using Git/search/OCI as a second writer, merged mutable names, or runtime fallback to a different authority after failure.** Keep installed bytes, current active selection and catalog availability distinct. This research must not grow another marketplace service. [E1, E5] |
| W21 UI lifecycle and state retention — renderer/contribution owner | Selected renderer mount/unmount, framework resource hooks; single-spa only if its application unit fits; Vite/React refresh for developer workflow | **Warn on custom virtual DOM reconciliation or claiming dev state preservation for production plugins.** Qualify stable shell state, component local reset, stale event handlers, hooks changes, styles/listeners and re-mount failures. Preserve draft outside the replaceable owner when its continuity is required. [E4] |
| W22 Observability and operator controls — application operations plus existing telemetry adapter | Existing traces/logging/metrics SDKs, e.g. OpenTelemetry where adopted; existing diagnostics surfaces | **Warn on another tracing/metrics database or one green `reloaded` flag that hides retirement debt.** Report requested policy, observed selection, old work and cleanup independently. Keep per-operation/candidate IDs in suitable traces/logs; bound metric cardinality. Exact dashboards/SDK adoption still need consumer choice. [N5] |
| W23 Conformance, test generators and evidence — contract owners and existing development tooling | Existing GM conformance, node:test, fast-check, Playwright and repository evidence/Docs Protocol routes | **Warn on a new test framework, oracle generated from the implementation, or treating fixture passes as product adoption.** Extend a concrete uncovered boundary rather than building another reducer. Retain negative controls, exact artifacts and failures; separate source inspection, local execution, hosted results and production evidence. [E3, E4, G1] |
| W24 Packaging and cross-platform release — selected adapter/toolchain maintainer | Standard package/bundler and ABI tooling, approved lockfiles, existing CI/release system | **Warn when a small adapter estimate excludes native binaries, target matrices, signing, licenses, symbols, cold start or compiler compatibility.** Compare total and incremental cost on the same guarantee. Current upstream versions do not automatically upgrade accepted consumer pins. Browser success, Node success and native Wasmtime success are different profiles. [G1, O1, P1] |

## Architecture to preserve now, without a speculative platform

### 1. Keep a subject-specific semantic seam

A contribution implements the consuming feature's capability. Its caller needs
neither an Extism object nor a GM descriptor. A native TypeScript implementation
uses direct typed calls. A particular language-neutral adapter can map a data
contract to Extism bytes/host functions or generated component bindings.

Do not demand that every existing TS port be serializable. JS callbacks,
iterators, classes, native handles and arbitrary object identity do not move to
another language automatically. A port that needs those semantics remains a
native profile unless the owner deliberately defines a different exchange.
Portability is best proved with two independent implementations of one useful
contract; a generic type parameter over a runtime facade proves little.

### 2. Separate implementation selection from execution placement

The same semantic implementation choice may be constructed in-process, in a
dedicated worker, or through a Wasm host. Placement determines import surface,
serialization, isolation, cancellation and stop observations. It should live in
an outer adapter/profile; it does not justify an application-wide switch on
`runtime === wasm` or forcing all plugins to ship Wasm.

Supported update choices are the intersection of the feature's state/lifetime
contract, actor grants, deployment/resource constraints, and the exact adapter's
qualified capabilities. Unsupported operations should be unavailable with a
reason. A default no-op `terminate()` method would violate substitutability.

### 3. Capture a coherent operation, not every helper independently

The operation chooses its implementation and required collaborator set once at
its actual admission boundary. Its reads after `await` retain that meaning.
Re-querying a global current provider midway may mix revisions. A stream or
callback can outlive the initial method return; its owner must keep the needed
resources until consumption/finalization or explicitly revoke it.

Admission and resource retention must form a safe acquisition before disposal
can pass between them. If acquiring a borrow can suspend, another owner needs a
reservation/revalidation mechanism. Native resource scopes help with release;
they do not invent the semantic root-operation boundary. The new stream test
demonstrates this using actual file handles and a deliberately failing control.

### 4. Classify resource and state ownership

| Kind | Suitable update treatment | What must not be implied |
| --- | --- | --- |
| Pure calculation and immutable configuration | Construct replacement; each call captures a version | Same ABI proves correct behavior |
| Generation-owned connection, listener, cache | Candidate owns its scope; settle retained work before release | Successful promise or cache deletion means resource release |
| Stable host-owned shared capability | Borrow it explicitly; its owner outlives both generations and their work | Old generation may dispose the borrowed resource |
| Exclusive file/device/port/session | Use existing stable owner, a qualified transfer, or explicit stop/reacquire gap | Two fully live instances can always be prepared concurrently |
| User draft or canonical domain state | Keep with the stable domain/UI owner, expose a versioned semantic API | Serializing a random object is a complete migration |
| Durable workflow/checkpoint | Existing workflow/state owner defines resume and compatibility | Arbitrary JavaScript or Wasm stack can move |

These categories justify specific metadata or receipts only at actual selected
boundaries. They do not require new generic interfaces for every helper.

### 5. Make component granularity an evidence-backed boundary

Start from the changed contribution, then determine affected constructed
dependents, imports and retained callbacks/state. Stop expansion at an explicitly
compatible stable boundary whose owner supports overlap; otherwise include the
dependent or restart the owning execution unit. The answer can be smaller than
a whole plugin artifact, but cannot be smaller merely because a file changed.

Show the user the affected set, state retained/reset, selected mode, potential
shared-worker interruption and deferred cleanup. This is how the requested
control becomes concrete. An arbitrary "update one internal method in place"
promise would need VM/compiler support and compatible live state; wrappers
cannot supply it.

## New executed experiment

Location: `runtime/`; source `resource-replacement.test.ts` has 378 lines,
all disposable test/integration code. New production code: **zero**. The
experiment uses the package's public root and Node APIs; no source deep import,
GM kernel, Effect, custom supervisor or library extraction is included.

| Case | Actual observation | Architectural implication |
| --- | --- | --- |
| Retained stream, dependency and shared Host file | Old results `v1,v1`, new result `v2`; private v1 file closes after consumed stream; stable Host file remains readable; closes once at Host shutdown | Operation retention and shared ownership are concrete contracts; a swap alone is insufficient. |
| Early-close negative control | Escaped read rejects with actual `EBADF` | Returning a capability/stream does not extend its resource Scope. |
| Delayed old listener cleanup | After v2 registers, old exact-listener cleanup leaves only v2; broad `removeAllListeners` negative control deletes both | Disposal identity belongs to the registration adapter, not its logical name. |
| Exclusive file | Concurrent candidate gets actual `EEXIST`; old file remains usable; explicit release/reacquire succeeds in that order | Ready-before-stop is conditional on coexistence. |
| Concurrent prepared candidates | B ready first is selected at revision2; late A is rejected and cleaned; old and B untouched by A cleanup | Scope ownership does not replace consuming-owner publication comparison. |
| Late acquisition and abandoned close wait | Report is incomplete/unsettled with pending acquisition; late handle is eventually closed once; setup rejects because scope closed | Stopping the wait is not ending acquisition or release; reuse the package's retained custody. |
| 250 generation cycles / 249 replacements | 250 listener acquisitions/releases, at most 2 during overlap, 1 selected each iteration, 0 at end; one injected failed cleanup reported and retried | Bounded actual registration accounting; not an RSS, ESM unloading or product-scale guarantee. |

Final native runner: **6 tests passed; 0 failed/cancelled/skipped/todo**.
The table has more rows because it separates one negative control from its test.
Node 24.22.3, pnpm 11.25.0, Resources 0.2.2, TypeScript 7.0.2,
`@types/node@24.13.3`. Strict check includes
`exactOptionalPropertyTypes`, `noUncheckedIndexedAccess` and **skipLibCheck: false**.
The package has no runtime dependencies; native compiler platform dependency and
type dependencies are recorded in the lockfile.

Peer review corrected the original label "250 replacements": iteration 1 is
initial construction, so the actual sequence has 250 generation cycles and 249
replacement transitions. The original log/result are retained; final gates
use the corrected source and labels. No runtime behavior changed.

The initial metadata command tried resolving an unexported package.json subpath
and failed before checking sources. It was corrected to inspect the installed
manifest by filesystem path. The first strict check and first runtime test
execution both passed; the metadata failure is retained separately rather than
relabeled as a test failure. The npm integrity and installed package bytes are
independently checked in `dependency-byte-verification.json`.

### Limits and review targets

The candidate race uses finite deterministic barriers in one JavaScript agent.
Its revision comparison is an illustrative consuming-owner policy, not durable
CAS implementation. The negative control without the check is demonstrative;
the important observed isolation is that late candidate cleanup does not close
the selected or predecessor scope. No permission/revocation claim is tested.

The listener scenario delays cleanup until v2 registers and emits only after
cleanup. It establishes identity-safe removal; it does not independently prove
that an old subscribed callback cannot be delivered while closing. The consumer
must define quiescence/admission separately if that stronger promise is needed.

The stream test has a manually controlled finite consumption boundary. It does
not implement an automatic borrow protocol, bound an infinite stream, migrate
its stack, or establish force semantics. The exclusive file is a disposable
single-process fixture, not a distributed lease or safe lockfile protocol. The
churn test counts actual registered callbacks and releases; it does not prove
GC, heap/RSS bounds or import-cache reclamation. Its injected cleanup error
occurs before removing the listener. The successful retry proves that specific
safe-to-repeat failure case, not arbitrary recovery after partially completed
external cleanup effects.

## Questions that remain open and should be studied deeper

1. **Exact first consumer and replaceable unit:** which real feature needs live
   replacement now, and what old work/state must survive? A quote calculation,
   tool invocation, renderer or durable provider produces different contracts.
2. **Portable contract:** does the selected port fit Extism's data/host-function
   ABI or WIT generated types better? Require records, strings, errors and real
   authorized host imports, not just scalar arithmetic.
3. **Execution profile:** what SDK/OS can actually interrupt a CPU loop and a
   stalled host call, with what receipt? SDK parity and browser/native support
   must be proven separately, including shared-worker collateral scope.
4. **Partial update closure:** can the product prove no escaped references or
   incompatible state cross the proposed boundary? If not, enlarge the unit to
   a controlled restart. We should not write a second graph engine to guess it.
5. **State evolution:** which changes are backward/forward compatible during
   overlap? Which require migration, a checkpoint, a reset, or refusal? Rollback
   after v2 writes needs the state owner's explicit contract.
6. **Ordinary policy/defaults:** old-work retention, drain, cooperative cancel,
   force and checkpoint are separately selectable where allowed. Deadlines
   cannot silently invent force authorization; prior approval may explicitly
   authorize escalation. This report chooses no universal default.
7. **Capacity envelope:** measure retained generations, closures, bytes, worker
   count, heap/RSS and load under churn after selecting the real profile. Do not
   infer a thousand active plugins from descriptor counts or six tests.
8. **Residual library:** after subtracting GM, resource runtime, executor,
   transport, state and operation owners, is a reusable algorithm left? If yes,
   validate one purpose-neutral contract with the real consumer and independent
   external fixture in the same delivery. Otherwise a qualified integration
   recipe is sufficient.

## Conditional implementation comparison

These planning judgments compare one trusted in-process request-oriented cohort,
an already owned state store and existing application lifecycle. They are not
measured availability or estimates for a complete plugin platform. Higher
complexity means more burden; P=new production mechanism,I=one integration,
T=new tests/fixtures. Modified existing LOC and release work are separate and
unmeasured. Alternatives are not additive.

| Option | Confidence /10 | Achievable reliability in stated scope /10 | Complexity /10 | P / I / T LOC | Decision implication |
| --- | ---: | ---: | ---: | --- | --- |
| Native TS plus qualified existing composition/resources recipe | 8 | 8 | 3 | 0 /150–350 /350–750 | Preferred bounded next slice when no new shared invariant is demonstrated. |
| Add one optional Extism/component adapter for a narrow port | 6 | 7 | 5 | 0–250 /150–400 /500–1,000 incremental | Requires data/binding/profile qualification; SDK and platform release work are not included in LOC. |
| Broad universal loader/lifecycle/state-migration platform | 2 | Unrated | 10 | Not responsibly estimated | Scope is not selected; duplicates known owners and pretends incomparable guarantees align. |

The first band is retained from existing qualified-recipe planning, not measured
from this 378-line test file. The second is a fresh uncertain planning band for a
single port, not a Wasm host/kernel implementation. Unknowns above can increase
it materially. The report supports implementing a useful TS boundary first and
keeping optional Wasm integration cheap through ownership and contracts, not
publishing speculative layers in advance.

## Primary sources and evidence navigation

`sources.json` records the exact read identities, evidence class and relevant
limitations. Local EF authorities are linked at the inspected baseline; current
upstream/product sources are pinned independently. Web documentation observations
are dated and are not stable adoption pins. Source/test assertions inspected
without execution remain source evidence. The new executed evidence exists only
under `runtime/`.
