import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { mkdtemp, open, rm, unlink, writeFile } from "node:fs/promises";
import type { FileHandle } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { after, test } from "node:test";
import { createScope } from "@get-modular/resources";

type Scope = ReturnType<typeof createScope>;
const results: Record<string, unknown> = {
  profile: { node: process.version, resources: "0.2.2", typescript: "7.0.2" },
  claim: "Disposable public-API resource integration; no production runtime qualification",
};

async function textAtStart(handle: FileHandle): Promise<string> {
  const bytes = Buffer.alloc(64);
  const result = await handle.read(bytes, 0, bytes.length, 0);
  return bytes.toString("utf8", 0, result.bytesRead);
}

async function closeComplete(scope: Scope): Promise<void> {
  const report = await scope.control.close();
  assert.equal(report.complete, true);
  assert.equal(report.settled, true);
  assert.deepEqual(report.debts, []);
}

function errorHasCode(code: string): (error: unknown) => boolean {
  return error => error !== null && typeof error === "object" &&
    "code" in error && error.code === code;
}

after(async () => {
  await writeFile(new URL("./results.json", import.meta.url), `${JSON.stringify(results, null, 2)}\n`);
});

test("captured stream and dependency retain v1 while v2 shares the stable Host resource", { timeout: 10_000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "resource-retained-stream-"));
  const host = createScope({ name: "host" });
  const proceed = Promise.withResolvers<void>();
  let hostReleases = 0;
  const releases: string[] = [];
  try {
    await Promise.all(["shared", "v1", "v2", "early"].map(name => writeFile(join(directory, name), name)));
    const shared = await host.resources.setup({
      name: "shared-file",
      setup: () => open(join(directory, "shared"), "r"),
      cleanup: async handle => { await handle.close(); hostReleases += 1; },
    });
    const makeGeneration = async (label: string) => {
      const scope = host.resources.child({ name: label });
      const file = await scope.resources.setup({
        name: "private-file",
        setup: () => open(join(directory, label), "r"),
        cleanup: async handle => { await handle.close(); releases.push(label); },
      });
      const dependency = Object.freeze({ label: `dependency-${label}` });
      const read = async () => ({
        implementation: await textAtStart(file),
        dependency: dependency.label,
        shared: await textAtStart(shared),
      });
      return { label, scope, read };
    };
    const old = await makeGeneration("v1");
    let selected = old;
    const captured = selected;
    const stream = (async function* () {
      yield await captured.read();
      await proceed.promise;
      yield await captured.read();
    })();
    assert.deepEqual((await stream.next()).value, {
      implementation: "v1", dependency: "dependency-v1", shared: "shared",
    });
    const next = await makeGeneration("v2");
    selected = next;
    assert.deepEqual(await selected.read(), {
      implementation: "v2", dependency: "dependency-v2", shared: "shared",
    });
    proceed.resolve();
    assert.deepEqual((await stream.next()).value, {
      implementation: "v1", dependency: "dependency-v1", shared: "shared",
    });
    assert.equal((await stream.next()).done, true);
    await closeComplete(old.scope);
    assert.deepEqual(releases, ["v1"]);
    assert.equal(await textAtStart(shared), "shared");
    assert.equal(hostReleases, 0);
    const early = await makeGeneration("early");
    const escaped = early.read;
    await closeComplete(early.scope);
    await assert.rejects(escaped(), errorHasCode("EBADF"));
    await closeComplete(next.scope);
    assert.equal(await textAtStart(shared), "shared");
    await closeComplete(host);
    assert.equal(hostReleases, 1);
    await assert.rejects(textAtStart(shared), errorHasCode("EBADF"));
    results["retained-stream"] = {
      status: "passed", oldStream: ["v1", "v1"], newCall: "v2",
      capturedDependency: "dependency-v1", hostReleases,
      privateReleases: releases, negativeControl: "escaped service read rejected EBADF after early close",
      limitation: "Host fixture explicitly joins consumption; Resources does not infer operation borrowing",
    };
  } finally {
    proceed.resolve();
    await host.control.close();
    await rm(directory, { recursive: true, force: true });
  }
});

test("delayed old cleanup removes exact listener without deleting its replacement", { timeout: 10_000 }, async () => {
  const emitter = new EventEmitter();
  const old = createScope({ name: "listener-v1" });
  const next = createScope({ name: "listener-v2" });
  const cleanupEntered = Promise.withResolvers<void>();
  const finishCleanup = Promise.withResolvers<void>();
  const delivered: string[] = [];
  try {
    const oldListener = () => { delivered.push("v1"); };
    await old.resources.setup({
      name: "event-listener",
      setup: () => { emitter.on("change", oldListener); return oldListener; },
      cleanup: async listener => {
        cleanupEntered.resolve();
        await finishCleanup.promise;
        emitter.removeListener("change", listener);
      },
    });
    const closing = old.control.close();
    await cleanupEntered.promise;
    const newListener = () => { delivered.push("v2"); };
    await next.resources.setup({
      name: "event-listener",
      setup: () => { emitter.on("change", newListener); return newListener; },
      cleanup: listener => { emitter.removeListener("change", listener); },
    });
    assert.equal(emitter.listenerCount("change"), 2);
    finishCleanup.resolve();
    assert.equal((await closing).complete, true);
    emitter.emit("change");
    assert.deepEqual(delivered, ["v2"]);
    assert.deepEqual(emitter.listeners("change"), [newListener]);
    const bad = new EventEmitter();
    bad.on("change", oldListener);
    bad.on("change", newListener);
    bad.removeAllListeners("change");
    assert.equal(bad.listenerCount("change"), 0);
    await closeComplete(next);
    assert.equal(emitter.listenerCount("change"), 0);
    results["exact-registration-cleanup"] = {
      status: "passed", finalDelivery: delivered, remainingListeners: 0,
      negativeControl: "removeAllListeners deleted the replacement too",
      limitation: "Cleanup callback must capture the exact resource; the library cannot discover identity",
    };
  } finally {
    finishCleanup.resolve();
    await Promise.all([old.control.close(), next.control.close()]);
  }
});

test("exclusive acquisition rejects overlap and requires an explicit stop/reacquire gap", { timeout: 10_000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "resource-exclusive-"));
  const target = join(directory, "exclusive.claim");
  const old = createScope({ name: "exclusive-v1" });
  const rejected = createScope({ name: "exclusive-candidate" });
  const next = createScope({ name: "exclusive-v2" });
  const events: string[] = [];
  const acquire = (scope: Scope, label: string) => scope.resources.setup({
    name: "exclusive-file",
    setup: async () => { const handle = await open(target, "wx+"); events.push(`acquired-${label}`); return handle; },
    cleanup: async handle => { await handle.close(); await unlink(target); events.push(`released-${label}`); },
  });
  try {
    const oldHandle = await acquire(old, "v1");
    await oldHandle.writeFile("v1");
    await assert.rejects(acquire(rejected, "rejected"), errorHasCode("EEXIST"));
    await closeComplete(rejected);
    assert.equal(await textAtStart(oldHandle), "v1");
    assert.deepEqual(events, ["acquired-v1"]);
    await closeComplete(old);
    assert.deepEqual(events, ["acquired-v1", "released-v1"]);
    const nextHandle = await acquire(next, "v2");
    await nextHandle.writeFile("v2");
    assert.equal(await textAtStart(nextHandle), "v2");
    await closeComplete(next);
    assert.deepEqual(events, ["acquired-v1", "released-v1", "acquired-v2", "released-v2"]);
    results["exclusive-handoff"] = {
      status: "passed", overlappingCandidate: "EEXIST", events,
      limitation: "Single-process exclusive file fixture, no distributed fencing or zero-gap handoff claim",
    };
  } finally {
    await Promise.all([old.control.close(), rejected.control.close(), next.control.close()]);
    await rm(directory, { recursive: true, force: true });
  }
});

test("racing prepared candidates require owner revision comparison and isolated cleanup", { timeout: 10_000 }, async () => {
  const old = createScope({ name: "selected-original" });
  const a = createScope({ name: "candidate-a" });
  const b = createScope({ name: "candidate-b" });
  const readyA = Promise.withResolvers<void>();
  const readyB = Promise.withResolvers<void>();
  const acquired: string[] = [];
  const released: string[] = [];
  const prepare = (scope: Scope, name: string, ready: Promise<void>) => scope.resources.setup({
    name: "owned-provider",
    setup: async () => { await ready; acquired.push(name); return Object.freeze({ name }); },
    cleanup: value => { released.push(value.name); },
  });
  let head = { revision: 1, provider: "original" };
  const observedByBoth = head.revision;
  // Explicit fixture-owner policy, not functionality supplied by Resources.
  const trySelect = (expected: number, provider: string): boolean => {
    if (head.revision !== expected) return false;
    head = { revision: head.revision + 1, provider };
    return true;
  };
  try {
    await prepare(old, "original", Promise.resolve());
    const candidateA = prepare(a, "a", readyA.promise);
    const candidateB = prepare(b, "b", readyB.promise);
    readyB.resolve();
    const preparedB = await candidateB;
    assert.equal(trySelect(observedByBoth, preparedB.name), true);
    readyA.resolve();
    const preparedA = await candidateA;
    assert.equal(trySelect(observedByBoth, preparedA.name), false);
    await closeComplete(a);
    assert.deepEqual(head, { revision: 2, provider: "b" });
    assert.deepEqual(released, ["a"]);
    assert.deepEqual(acquired, ["original", "b", "a"]);
    let unguardedSelection = preparedB.name;
    unguardedSelection = preparedA.name;
    assert.equal(unguardedSelection, "a");
    await closeComplete(old);
    assert.deepEqual(released, ["a", "original"]);
    assert.deepEqual(head, { revision: 2, provider: "b" });
    await closeComplete(b);
    assert.deepEqual(released, ["a", "original", "b"]);
    results["concurrent-candidates"] = {
      status: "passed", acquired, released, head,
      negativeControl: "unguarded late A overwrites selected B",
      limitation: "In-memory same-agent comparison only; no durable or distributed publication claim",
    };
  } finally {
    readyA.resolve();
    readyB.resolve();
    await Promise.all([old.control.close(), a.control.close(), b.control.close()]);
  }
});

test("late candidate acquisition stays owned after a close waiter abandons", { timeout: 10_000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "resource-late-candidate-"));
  const target = join(directory, "candidate");
  const candidate = createScope({ name: "late-candidate" });
  const acquireMayFinish = Promise.withResolvers<void>();
  const acquisitionStarted = Promise.withResolvers<void>();
  const cleanupStarted = Promise.withResolvers<void>();
  const cleanupMayFinish = Promise.withResolvers<void>();
  let released = 0;
  let acquiredHandle: FileHandle | undefined;
  try {
    await writeFile(target, "late");
    const acquiring = candidate.resources.setup({
      name: "foreign-acquisition",
      setup: async () => {
        acquisitionStarted.resolve();
        await acquireMayFinish.promise;
        const handle = await open(target, "r");
        acquiredHandle = handle;
        return handle;
      },
      cleanup: async handle => {
        cleanupStarted.resolve();
        await cleanupMayFinish.promise;
        await handle.close();
        released += 1;
      },
    });
    const acquisitionOutcome = acquiring.then(
      () => ({ status: "unexpected-fulfillment" }),
      (error: unknown) => ({ status: "rejected", expected: errorHasCode("resources.scope.closed")(error) }),
    );
    await acquisitionStarted.promise;
    const abandoned = new AbortController();
    const observation = candidate.control.close({ abandon: abandoned.signal });
    abandoned.abort("caller-stops-waiting");
    const pending = await observation;
    assert.equal(pending.complete, false);
    assert.equal(pending.settled, false);
    assert.ok(pending.debts.some(debt => debt.state === "pending"));
    assert.equal(released, 0);
    acquireMayFinish.resolve();
    await cleanupStarted.promise;
    assert.equal(released, 0);
    assert.ok(acquiredHandle);
    assert.equal(await textAtStart(acquiredHandle), "late");
    const joined = candidate.control.close();
    cleanupMayFinish.resolve();
    assert.equal((await joined).complete, true);
    assert.deepEqual(await acquisitionOutcome, { status: "rejected", expected: true });
    assert.equal(released, 1);
    await assert.rejects(textAtStart(acquiredHandle), errorHasCode("EBADF"));
    results["late-acquisition"] = {
      status: "passed", abandonedReport: pending, finalReleases: released,
      limitation: "Finite test-controlled foreign acquisition; not forced cancellation of an infinite operation",
    };
  } finally {
    acquireMayFinish.resolve();
    cleanupMayFinish.resolve();
    await candidate.control.close();
    await rm(directory, { recursive: true, force: true });
  }
});

test("250 generation cycles with 249 replacements retain one listener and retry one cleanup debt", { timeout: 10_000 }, async () => {
  const host = createScope({ name: "churn-host" });
  const emitter = new EventEmitter();
  const observed: number[] = [];
  const acquired = new Set<number>();
  const released = new Set<number>();
  let selected: Scope | undefined;
  let debtReports = 0;
  let maximumListeners = 0;
  let injected = false;
  try {
    for (let version = 1; version <= 250; version += 1) {
      const candidate = host.resources.child({ name: `version-${version}` });
      const listener = () => { observed.push(version); };
      await candidate.resources.setup({
        name: "change-registration",
        setup: () => { emitter.on("change", listener); acquired.add(version); return listener; },
        cleanup: owned => {
          if (version === 37 && !injected) { injected = true; throw new Error("injected-cleanup-failure"); }
          assert.equal(released.has(version), false);
          emitter.removeListener("change", owned);
          released.add(version);
        },
      });
      maximumListeners = Math.max(maximumListeners, emitter.listenerCount("change"));
      const predecessor = selected;
      selected = candidate;
      if (predecessor) {
        const report = await predecessor.control.close();
        if (!report.complete) {
          debtReports += 1;
          assert.equal(report.settled, true);
          assert.equal(report.debts.length, 1);
          assert.equal(report.debts[0]?.state, "failed");
          assert.equal(emitter.listenerCount("change"), 2);
          await closeComplete(predecessor);
        }
      }
      assert.equal(emitter.listenerCount("change"), 1);
      emitter.emit("change");
      assert.equal(observed.at(-1), version);
      assert.equal(acquired.size - released.size, 1);
    }
    assert.equal(debtReports, 1);
    assert.equal(maximumListeners, 2);
    assert.deepEqual(observed, Array.from({ length: 250 }, (_, index) => index + 1));
    assert.ok(selected);
    await closeComplete(selected);
    await closeComplete(host);
    assert.equal(emitter.listenerCount("change"), 0);
    assert.equal(acquired.size, 250);
    assert.equal(released.size, 250);
    results["bounded-churn"] = {
      status: "passed", generationCycles: 250, replacements: 249, acquired: acquired.size, released: released.size,
      debtReports, maximumListeners, finalListeners: emitter.listenerCount("change"),
      limitation: "Actual listener/resource accounting only; no process RSS, GC, import-cache or arbitrary-plugin scale claim",
    };
  } finally {
    await host.control.close();
  }
});
