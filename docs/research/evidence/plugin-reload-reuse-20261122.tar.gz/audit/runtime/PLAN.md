# Real resource-scope replacement experiment

Date: 2026-11-22, Europe/Kiev. Disposable research, not a product runtime or
Orchestrator adoption. Owner request: prove a useful update boundary using
existing mechanisms rather than adding another plugin manager.

## Dependency/profile

Use the current published `@get-modular/resources@0.2.2`, discovered from the
official npm registry. Its source is inspected at Get Modular commit
`33c032f829028967825428bc6b049ed6db1c56b2`. Exact package integrity, the lockfile,
Node/pnpm versions, TypeScript >=7.0.2 resolution and raw logs will be retained.
Only the package's public root and Node APIs are used. No private lifecycle
kernel imports, no production package, no framework or manager reimplementation.

## Independent expected observations

1. A retained operation sees its originally captured implementation and keeps
   its generation resource usable until consumption completes. New work sees
   the selected implementation. A stable Host-owned file remains usable across
   the replacement and is closed once at Host shutdown. A negative control
   closes the generation early and observes a real `EBADF` on its file handle.
2. Old cleanup removes only the exact old event listener after v2 registered
   its own listener. A negative control using `removeAllListeners` removes v2
   and demonstrates why a resource scope cannot infer registration identity.
3. A real exclusive file claim denies overlapping acquisition with `EEXIST`.
   Candidate cleanup leaves the predecessor usable. A declared stop/reacquire
   sequence works; no zero-gap transfer or distributed-lock claim follows.
4. Two concurrently prepared candidates retain distinct scopes. A small
   fixture-owned expected-revision comparison selects only one. The loser is
   cleaned without closing the winner or its predecessor. Omitting that check
   is an explicit negative control that lets the stale candidate overwrite.
5. An uncooperative asynchronous acquisition completing after close is retained
   and finalized by the real scope. An abandoned waiter reports unsettled debt;
   it does not imply release. No sleeps or fake timeout receipts select success.
6. Repeated replacement leaves one live selected listener and zero retired
   listeners. One injected cleanup failure is visible as debt and a retry closes
   it. This counts actual registrations/releases; it is not a heap/RSS leak
   theorem, arbitrary code unload, or product scale qualification.

The fixture owns the selection pointer and test barriers only. Resources owns
acquisition and cleanup; native Node objects own their actual release. There is
no attempt to infer business-state migration, authorization, durable publication,
exclusive ownership across processes or physical termination from these tests.

## Validation

Author all maintained fixture/test code in `.ts`, effective strict check with
`exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`, and no `skipLibCheck`.
Run six native `node:test` cases, retain meaningful negative controls, fail on
unhandled rejections and leaked fixture resources. Preserve initial failed
attempts separately if correction is necessary.
