# Public resource-scope integration experiment

Disposable research for controlled plugin replacement. No production runtime
or selected consumer adoption is contained here. Read PLAN.md for independent
expectations and ../REPORT.md for conclusions and limits.

## Reproduce

Recorded execution profile: Node24.22.3 on Linux, pnpm11.25.0,
TypeScript7.0.2, `@get-modular/resources@0.2.2`, `@types/node@24.13.3`.

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm typecheck
pnpm test
```

Strict checking includes dependency declarations; `skipLibCheck` is false.
The installed package root supplies all resource-scope behavior. Tests use
native file handles, event registrations and finite deterministic barriers.

## Evidence

- runtime-final.log and results.json: six passing native tests; 250 generation
  cycles with249 replacement transitions,250 registrations/releases and zero
  final listeners; one cleanup failure before release is reported and retried.
- typecheck-final.log and compiler-resolution.log: effective supported compiler
  identity and final strict pass.
- resources-0.2.2.tgz, resources-registry.json and
  dependency-byte-verification.json: exact npm artifact/integrity and all16
  installed package files match the downloaded tarball.
- pnpm-lock.yaml and registry metadata: exact dependency identities.
- runtime-initial.log and results-initial-mislabel.json: retained first passing
  run with the original imprecise250 replacements label; peer review corrected
  it to249 transitions plus initial construction. No behavior change.
- compiler-resolution-initial.log: a metadata lookup failed on an unexported
  package.json subpath before source checking; corrected by reading the installed
  manifest path. This is not a runtime or compiler source-check failure.

Tests prove this bounded integration, not automatic operation borrowing,
arbitrary callback quiescence, distributed publication/fencing, hostile-code
isolation, ESM unloading, heap/RSS bounds or complete production hot reload.
Node_modules is an installable dependency directory and is excluded from the
evidence archive; the small exact Resources tarball is deliberately retained.
