# Independent review of the Extism research lane

Reviewer: reuse/architecture workstream. Date: 2026-11-22, Europe/Kiev.
Reviewed source: `../extism/extism.test.ts` (213 lines),
`../extism/runtime-boundary.ts` (71 lines), both compiler profiles and the
5-line direct-import negative fixture, final runtime/typecheck logs, results,
report, source ledger and retained upstream fixtures. Source inspection only;
no additional Extism executions were necessary.

## Disposition

**No blocking correctness or false-pass issue found for the stated bounded
research claims.** This is not production approval or qualification of the
published SDK declarations. The review distinguishes a passing research
runtime harness from the failed direct TypeScript 7 SDK import.

- The dynamic import result begins as unknown. The research boundary validates
  actual factory/method access and expected booleans, DataView output, text,
  offsets and WebAssembly.Instance. No unchecked any, blanket assertion,
  dependency edit, compiler downgrade or skipLibCheck was found. This boundary
  is explicitly not proposed as a production replacement for the SDK types.
- The direct-import fixture includes both real SDK declaration sets. The
  retained failure contains TS2508 at PluginOutput/DataView for both versions.
  That failure remains separate from the strict own-harness pass.
- The consumer oracle fixes the expected results independently. The host owns
  state and the configuration change is explicitly the same Wasm bytes with a
  fresh instance. No newly compiled v1/v2 or heap migration is claimed.
- The stale write case holds a real asynchronous host import, selects the new
  epoch, commits through the new instance, then resumes the old invocation.
  The old actual write callback checks authority and rejects. This is useful
  single-owner evidence, not distributed/database fencing.
- Missing import/hash/malformed byte rejection asserts real SDK errors and
  independently calls the retained native TS selection afterward.
- Foreground close remaining callable and worker-close pending calls are
  reported as counterexamples. The worker observation is exactly a 100 ms window;
  the report discloses the lack of an instrumented guest entered-loop marker
  and makes no browser or public physical-exit receipt claim.
- The memory probe reads the actual guest-exported WebAssembly.Memory, observes
  a successful guest invocation, and limits the conclusion to that JS profile.
  It does not infer native Wasmtime limits or universal containment.
- Final evidence records 14 passed native cases, no failures/cancellations/skips.
  Earlier failing attempts remain retained and described.

## Minor reporting refinement

After rc13 times out the loop, the succeeding operation is
`functionExists('loop')`. Review requested explicit **control query** wording,
because this does not demonstrate a second successful guest invocation. The
owning agent corrected the test title and result key to
`nextControlQueryAccepted` and added the explicit limit in the executive report.
The corrected sources passed strict checking and all 14 runtime cases; readback
confirmed these changes. The original logs remain preserved. Finding resolved.

## Fixture custody and license

Independent GitHub file reads at
`bec25c60d0ad32ce06d3934563fd8560f486f323` returned these source blob IDs, which
match `git hash-object` over the retained local bytes exactly:

| Fixture | Git blob | SHA-256 |
| --- | --- | --- |
| wasm/loop-forever.wasm | 46ccf85028660804285f740bfcea1b56bf1624a3 | ca126d183636b076b27c01b47fba4a471c4211ed570d30a7b773c2fa66637d24 |
| wasm/loop-forever-init.wasm | 483b56f5cced33d9e1fdcce9b790a0008c2d85be | be411197fb88674fe7d0ce955adb4cb1d8ed9f1bfe26e277a2428698f7d8e144 |

The official js-sdk LICENSE at that commit and extism/plugins LICENSE at
v1.1.1 both resolve to blob `c6c70b4dba6c619e127c9f5ce69a826ead24af9b` and contain
the same three-clause redistribution terms. The retained license preserves the
copyright, conditions and disclaimer; a trailing newline affects its Git blob
but not its text. The Rust release artifact local SHA-256 matches the recorded
`6360898f83288ae74fe51776863376060fa725c7a4c2581ed93204bc6e661954`.
This review independently verifies local binary identities and upstream loop
source blobs; it does not claim reproducible compilation of the released guest.

## Remaining limits to retain

SDK close, caller settlement, host callback completion and actual execution exit
remain different facts. Non-idempotent external effects and general state
migration are unqualified. The worker timeout profile is a prerelease candidate;
latest npm channel is not stable API adoption. A production choice must resolve
the real consumer's compiler, cancellation, pending calls, resource bounds,
packaging and deployment requirements.
