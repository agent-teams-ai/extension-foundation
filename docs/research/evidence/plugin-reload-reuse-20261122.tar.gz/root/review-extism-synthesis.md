# Extism and optional-runtime synthesis review

Reviewer: Extism/runtime workstream. Date: 2026-11-22, Europe/Kiev.

## Scope and outcome

Reviewed the complete tracked `docs/research/reuse-first-live-plugin-updates-2026-11-22.md` and its `evidence/plugin-reload-reuse-20261122.sources.json`, with detailed checking of Extism, optional-runtime boundaries, availability and numerical claims. Cross-checked the Extism namespace against the workstream's retained source ledger and final executed results; they match. This is a document/evidence review, not a new runtime execution or production adoption.

**PASS for the stated research scope; no blocking findings.** Three small wording improvements were sent to root and are listed below. They do not change the evidence, introduce new tests or alter a runtime decision.

## Checks completed

- All 22 Extism source IDs E01–E22 are present, unique and in the intended namespace. The combined Extism namespace equals the retained original ledger; exact SDK revisions, Wasm hashes and wasmCloud source/blob identities match.
- The claim of 14 passing behavior cases agrees with the final native runner and 14 retained observations. Node 24.22.3 and strict TypeScript 7.0.2 are accurate. The independent direct-import probe retains two TS2508 errors; the research reflection/validation boundary is explicitly not a production typing fix or proof of upstream declaration qualification.
- The official Rust-PDK guest is 74,029 bytes with the recorded SHA-256. It was executed, not compiled locally. Native TS to Rust selection is distinguished from the subsequent same-bytes/configuration-only instance replacement.
- Totals 2, 4 and 7, preserved draft, held old import and rejected stale write match the actual assertions. The local epoch is not represented as distributed fencing or arbitrary effect cancellation.
- Foreground close remains callable in both profiles. Worker-close observations are bounded to the measured 100 ms, with no forever-pending or guest-entry/physical-exit claim. The rc13 source's awaited worker termination is distinguished from caller-promise settlement.
- Post-timeout success is explicitly an export-existence control query, not a second guest invocation or full workload recovery. CPU-loop and initializer timeout results are not expanded to universal cancellation of host IO.
- Memory arithmetic is exact: 17 × 65,536 = 1,114,112 bytes initially; 18 × 65,536 = 1,179,648 bytes after the call. The counterexample is scoped to this JS SDK guest-owned linear memory and is not attributed to native Wasmtime-backed Extism.
- wasmCloud v2.12.3 revision 8358f1f56a66c43aedc49f30e2c5d4fa2b4f7ca1 and `publish = false` are preserved. Source embeddability, supported host distribution and an ordinarily published library contract are distinguished. Its lifecycle source is not labeled executed here.
- TypeScript-first and optional adapter recommendations preserve consumer-owned ports, resource/state/authority owners and actual target capability differences. No general plugin interface, simultaneous mandatory Extism/WIT implementation, production runtime selection or accepted-consumer upgrade is implied.
- Existing source-bound November 21 evidence is not relabeled as a newly executed Extism/browser qualification. Browser HMR and resources experiments retain distinct scope and corrected counts.

## Non-blocking wording refinements sent to root

1. In the Extism observation table, specify **worker profile** for active reset refusal and reentrant-call rejection. The actual experiment exercises that path; foreground behavior should not inherit it by implication.
2. Replace “An adapter cannot strengthen this receipt” with “An adapter cannot infer stronger guarantees from this receipt alone.” An adapter can add independently observed owner-level settlement/retirement behavior; the problem is overstating the SDK receipt.
3. In the “Does not establish” cell after `functionExists('loop')`, use “Successful second guest invocation or full workload recovery.” This avoids putting “was not tested” under a negative column heading while preserving the same substantive limit.

## Limits of this review

No tracked files or frozen Extism packet were edited. No tests were rerun because source/evidence inputs were unchanged. The reviewer did not independently repeat browser execution, requalify SDK internals, or select a production runtime. Remaining typing, retirement, resource-enforcement and first-real-consumer questions are correctly retained as open work in the synthesis.

## Final disposition and reviewed identities

Root applied all three wording refinements. Readback confirms that reset/reentrant rejection is explicitly limited to the tested worker profile, stronger guarantees cannot be inferred from the SDK receipt alone, and the recovery limitation names successful second guest invocation or full workload recovery without a double negative. **All review comments are resolved; final outcome remains PASS with no blockers.**

- Final reviewed main report SHA-256: `6f0fc15dd354a725db347b63688d7d29f96b2c560a088aee57b9e21ccb616c5c`.
- Unchanged reviewed source ledger SHA-256: `8497be6f95d7499d91b129870ef2052c97a3e4619f8ee66b6a823a541ce6ae94`.
- Only this review record was appended by the reviewer. No tracked file, frozen workstream packet or experimental input was changed.
