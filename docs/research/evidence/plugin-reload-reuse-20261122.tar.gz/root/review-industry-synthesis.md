# Independent industry and browser synthesis review

Reviewer: industry_hot_reload. Research date: 2026-11-22 Europe/Kiev.
Disposition: **PASS for the reviewed industry/browser narrative and attribution.**
Final packet assembly and final-head CI are separate, still pending at this
review; this disposition does not claim that those delivery checks already ran.

## Reviewed scope and identities

- Main synthesis: docs/research/reuse-first-live-plugin-updates-2026-11-22.md,
  SHA-256 6f0fc15dd354a725db347b63688d7d29f96b2c560a088aee57b9e21ccb616c5c.
  Final industry/browser sections were re-read after root's Extism-only wording
  corrections; reviewed findings did not change.
- Combined sources: industry namespace is exactly equal to the independently
  maintained sources.json, including all 37 entries and both hosted attempts.
- Warning register: inspected all 24 surfaces for relevant industry-transfer
  claims and the native follow-up to W05/W06/W22.
- Source report and detailed reviews in industry/; exact native run evidence in
  industry/hosted/run-44962153869/; preserved failed run 44961594670.
- This review does not independently re-execute or requalify the other agents'
  Extism and Get Modular Resources lanes. Their dedicated reviews govern them.

No tracked file or GitHub state was modified by this reviewer. No additional
runtime tests were executed during synthesis review.

## Attribution and evidence separation

The eight-system comparison agrees with the inspected primary sources. Flutter
and Dart's VM/closure semantics are presented as platform-specific, while the
operation-pinned dependency closure is clearly a proposal. React's transform
signature detail is attributed to the actual Oxc source and then checked in the
actual released browser toolchain. IntelliJ intersection lifetimes, OSGi retained
wiring, OTP release-check execution, NGINX worker-generation handoff and Envoy's
separate initialization/drain phases are not relabeled as newly executed tests.

The navigation links are explicitly separated from exact pinned source
identities in the ledger. Upstream source/test inspection remains distinct from
new native execution. The report does not infer a production update policy from
development refresh or claim the eight projects provide the same guarantees.

The examples about field meaning, resource exclusivity and affected dependency
closure are identified as examples/proposals. The recommendation to reuse an
existing owner, retain ordinary TypeScript and qualify one optional Wasm adapter
is an engineering conclusion, not an upstream library promise. Estimate bands
are explicitly described as judgments with omitted deployment/maintenance work;
the report does not pretend they are measured reliability or benchmark results.

## Native browser claims match exact retained evidence

The synthesis's successful run ID, source commit, 18-file input and 39,290-byte
artifact digest match independent verification. The artifact receipt binds
commit c1653881b574b4258fb16a2d44b93a1004c06a94, run 44962153869, attempt 1,
input 430b3c063c920e0a5e1153d2ed1beca7ebbb65d0e658e7ad54f941169d31b1a5,
and workflow 396f5277f6c91b9ba22421d0ecbe073f04a8d6b7ad8f6372472304e76e2eb8cd.

All 32 unique actual/expected comparisons in the downloaded artifact match;
artifact JSON equals the stdout diagnostic result. One native test passed with
zero failures, and all job steps including upload passed. Versions and actual
five watcher changes are correctly reported. State13 preservation, Hook remount
to 11, initializer remount to 99, unchanged parent draft/document across component
updates, effect cleanup order, current listener, late v1 Promise completion,
failed raw import and later recovery all agree with the trace and oracles.

The real element-identity assertion checks a DOM element, not React's conceptual
instance internals; the synthesis correctly calls it the actual button object.
The stable document marker belongs to the fixture instrumentation; the full
reload changes it. The report does not convert this observation into durable
state retention or physical-module reclamation.

The first failed run remains visible. Its v3 timeout and missing artifact are
described accurately. The second input changes both file replacement and edit
spacing; the report correctly refuses to isolate a cause from that result.
The 100 ms independent-edit profile and unqualified rapid-write behavior are
explicit. No browser state/resource assertion was weakened between inputs.

## Repeated disposal and activation wording

The synthesis's new warning matches both the observed trace and exact Vite 8.3.8
source. The old raw disposer runs before failed import and again before recovery;
the faulty candidate installs acceptance but no replacement disposer. The map
entry persists. The callback's captured old listener can be removed repeatedly
in this fixture. The report requires repeat-safe, owner-specific release and
explicitly does not qualify arbitrary retry after partial external cleanup.

The warning about a 'hot updated' framework log also matches source and actual
console output after import failure. The report correctly distinguishes that
log from the product's semantic activation receipt. No new universal disposal
or transaction framework is proposed as the response.

## Delivery observations and small metadata follow-up

At this review, the combined packet tarball and member manifest were not yet
present. Therefore the packet's final members/digest cannot be independently
approved here. Root should freeze the packet after all lane reviews and retain
the reports, both browser attempts, source ledgers, original/corrected inputs,
native artifact ZIP and extracted receipts. This is an assembly check, not a
request to repeat the unchanged native run.

One small navigation issue was sent to root and corrected: warning-map
pathRoots now includes industry/ for the followupObservations evidenceMember
industry/hosted/run-44962153869/verification.json. The updated description was
independently read; the referenced file exists and its content was verified.
The industry ledger review timestamp was also advanced to 2026-11-21T23:43:18Z
after the final evidence additions; refresh its combined namespace before
freezing the packet. Neither metadata correction changes behavioral findings.

Final-head hosted gate monitoring will be performed against the commit supplied
by root. Prose-only changes should not relabel the earlier native run as if it
executed at that later head; retain exact source/input/workflow identity.
