# Independent audit review of the final reuse-first synthesis

Reviewer: reuse/architecture workstream. Date: 2026-11-22, Europe/Kiev.

## Verdict

**PASS for the inspected research synthesis. No blocking ownership, adoption,
warning-map or resource-evidence issue remains.** This review is not approval
of a production runtime, public SPI, consumer upgrade, merge or release.

Read the complete main research record, both loose evidence JSON files, the
dated follow-ups in the three existing research records, and the November22
owner clarification in OD-003. Compared the resource statements with the actual
final fixture, logs/results, package byte verification and preserved initial
evidence from this workstream. Inspected links/identities without rerunning
runtime or broad repository tests.

## Reviewed identities

Paths below are relative to Extension Foundation. Hashes bind the inspected
content before final packet assembly and publication.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| docs/research/reuse-first-live-plugin-updates-2026-11-22.md | 58,098 | 6f0fc15dd354a725db347b63688d7d29f96b2c560a088aee57b9e21ccb616c5c |
| docs/research/evidence/plugin-reload-reuse-20261122.sources.json | 56,629 | 8497be6f95d7499d91b129870ef2052c97a3e4619f8ee66b6a823a541ce6ae94 |
| docs/research/evidence/plugin-reload-reuse-20261122.warnings.json | 23,765 | fc3748a3d9349365a3060eba36770fb3249e8fa93d50f16f09f70c93d255625c |

## Ownership and adoption

- The record accurately distinguishes empty EF production package scope from
  substantial research fixtures. It does not claim that a proprietary Wasm
  engine has been shipped, nor claim to audit every organization repository.
- GM retains declarations/graph/construction semantics; the consumer retains
  feature contracts, runtime authority and state meaning. The private kernel
  remains unreleased. No second manager, service locator, graph compiler or
  canonical state authority is selected by the proposal.
- Current GM source availability is separated from actual Orchestrator
  Core/Assembly0.5.0 adoption. Native Effect is conditional on its own consumer
  profile and is not made a second disposer or mandatory runtime everywhere.
- Existing OCI/ORAS/Cosign adoption and catalog authority are retained; the
  runtime discussion does not reopen them or grant execution from signatures.
- Native TS first and optional Wasm through a narrow feature seam are presented
  as the requested direction and research recommendation. Ordinary policy,
  force grants, state migration and exact production runtime remain open.
- The wasmCloud internal/unpublished-crate qualification is present in both
  the runtime comparison and W10, avoiding the earlier overbroad implication
  that source embeddability establishes a released library contract.

## Warning and path integrity

- Exactly24 IDs, W01 through W24, appear once and in the same order in Markdown
  and warnings JSON. Surface/owner, reuse route and warning text match exactly.
- Every warning's EF path exists at baseline
  `534fa8469681df447732d9c7f8c916c6f14968e2`; every sibling experiment path exists.
  The additional browser follow-up member exists at
  `industry/hosted/run-44962153869/verification.json`.
- The warnings JSON now includes the industry path root. The browser follow-up
  maps specifically to W05/W06/W22 and keeps repeat-safe local cleanup distinct
  from retrying partially completed external effects.
- All bracketed audit source IDs in the warnings resolve. The source namespaces
  contain25 audit,22 Extism and37 industry entries, with unique IDs within each
  namespace. Namespace separation avoids collisions such as E1 versus E01.
- GM and Orchestrator source paths/revisions/blob identities agree with the
  primary repository content read in this workstream. Moving documentation and
  current reference policy are explicitly different from accepted adoption pins.

## Granular replacement and resource evidence

- The proposed affected set includes construction, import, retained work/state
  and physical executor constraints. It does not promise arbitrary file/method
  replacement or manufacture safety from a second graph.
- Stable host/feature-owned state and borrowed capabilities remain distinct
  from generation-owned resources. Same ABI/type does not imply state or
  behavioral compatibility. Exclusive resources can require a handoff gap.
- Request capture and lifetime acquisition are treated as one safe admission
  obligation; suspended acquisition requires its owner's reservation or
  revalidation. The record does not pretend the Resources package supplies an
  automatic operation borrowing protocol.
- Six resource tests are reported as six tests. The table's extra row is
  explicitly a negative control, not an additional independent test.
- The corrected count is250 generation cycles and249 replacement transitions.
  Actual acquisitions/releases, overlap and final listener count are retained.
  No heap/RSS, arbitrary ESM unload or thousand-plugin capacity claim is made.
- Early close exposes actual EBADF; exclusive overlap exposes EEXIST. Both are
  bounded native observations. The one-process exclusive file is not described
  as a distributed lock or zero-gap transfer mechanism.
- Delayed listener cleanup proves identity-safe removal, not suppression of
  every callback before cleanup completes. Stream lifetime is manually joined
  by the fixture. Local candidate comparison is not durable CAS.
- Abandoned waiting remains unsettled debt. Cleanup retry is qualified only
  for the injected failure before release, not partial external effects.

## Receipt wording refinement, resolved

Requested changing the sentence that an adapter cannot strengthen a receipt to
the more precise statement that it cannot **infer stronger guarantees from that
receipt alone**. An adapter may independently settle its own pending requests,
but cannot fabricate executor exit or effect completion. Root applied the
change and readback confirmed it.

Root also scoped active-reset/reentrancy observations to the tested worker
profile and clarified that a successful post-timeout export query does not
establish a second guest invocation. Both refinements are present in the
reviewed content.

## Preservation and final delivery boundary

Read-only validation of every member in the frozen audit file-manifest found
no changed bytes or sizes. This review writes only its new file under root/;
it does not modify tracked files or the frozen audit packet.

At review time the combined tarball/member manifest had not yet been assembled.
Their existence, complete member/receipt verification, final documentation
gates, published head and hosted CI remain the root delivery operation's work.
The document correctly keeps those delivery receipts separate from the executed
experiment claims. This PASS covers the reviewed synthesis and mappings, not
an unobserved final package or later commit.
