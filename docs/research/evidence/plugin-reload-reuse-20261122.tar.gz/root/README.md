# Reuse-first plugin research evidence, 2026-11-22

This packet supports the research document
`docs/research/reuse-first-live-plugin-updates-2026-11-22.md` in Extension
Foundation. It retains disposable experiments and reviews, not a production
runtime or adopted public plugin interface. Dates use Europe/Kiev; execution
logs preserve their original clocks.

## Navigation

- `audit/REPORT.md`: 24 prospective reuse warnings and existing ownership.
- `audit/runtime/`: actual published Resources 0.2.2 qualification, six cases,
  strict sources, package bytes, lockfile, dependency proof and original logs.
- `extism/report.md`: two exact Extism JS SDK profiles, 14 behavior cases,
  SDK declaration incompatibility, official Rust guest and upstream license.
- `industry/industry-report.md`: primary-source comparison of eight systems.
- `industry/hosted/run-44961594670/`: original failed native browser attempt;
  no uploaded observation artifact was available for that attempt.
- `industry/hosted/run-44962153869/`: successful native Chromium run, original
  artifact ZIP, extracted 28 members, job log and source-bound verification.
- `browser/`: exact v2 input sources and retained local/pre-publication failures.
  Its local observations do not supersede the successful hosted observations.
- `root/`: independent synthesis reviews, package metadata-only compiler
  resolution, live run retrieval and independent custody verification.

The repository's two browser input archives remain immutable at their respective
commits. The original input is not overwritten by the corrected v2 input. The
final packet member manifest is alongside the archive, outside this packet.
The directly readable source ledger uses separate audit, Extism and industry
namespaces; source IDs are interpreted in their lane.

## Reproduction

Use the package manager, compiler, package versions and lockfiles in each lane;
the executed local environment was Node 24.22.3 and pnpm 11.25.0. In each source
directory install with `pnpm install --frozen-lockfile --ignore-scripts`.

- In `audit/runtime/`, run `pnpm typecheck` and `pnpm test`.
- In `extism/`, run `pnpm typecheck` and `pnpm test`. The separate
  `pnpm exec tsc --project tsconfig.direct.json --pretty false` is expected to
  fail with the two retained TS2508 diagnostics. That failure remains a
  production integration question; the runtime boundary is research-only.
- In `browser/`, run `pnpm check`, install the pinned Playwright browser with
  `pnpm exec playwright install chromium` (and required platform dependencies),
  then run `pnpm test`. The hosted workflow is retained in the repository at
  commit c1653881b574b4258fb16a2d44b93a1004c06a94. Its source/input/workflow
  receipts bind the actual successful run, not a later prose-only publication.

Retain original logs when reproduction differs. These commands do not make
different OS, architecture, Node, browser or SDK versions equivalent profiles.
The native browser input covers independently spaced edits, not rapid-write
churn. New test runs are new evidence and cannot rewrite the historical receipt.

## Limits and review dispositions

The 14 Extism behavior cases, six resource cases and one browser E2E with 32
comparisons are different evidence units. Do not sum them into a purported
uniform test count. A passing resource fixture does not qualify a distributed
update, memory reclamation or arbitrary cleanup retry. SDK close, invocation
settlement, physical stop and external effect completion remain distinct facts.

Final synthesis review resolved the explicit worker-profile reset/reentrancy
scope, the control-query recovery limitation, and wording that an adapter cannot
infer stronger completion from one SDK receipt alone. The industry path root
was added to the warning map. Its source ledger review timestamp was refreshed
after native verification; the inspected source entries themselves did not
change. Retained earlier review hashes identify the exact versions reviewed.

Root independently verified all 34 Extism and 25 audit manifest entries, all
18 browser input files against the hosted artifact, all 28 ZIP members and CRC,
the workflow and input receipts, all 32 named comparisons and equality with the
job-log observation JSON. The native screenshot was visually inspected. This
verification is inspection of an existing execution, not a new execution.

Broad local Foundation gates were not run: metadata resolution still finds
API Extractor's embedded TypeScript 5.9.3 alongside repository TypeScript 7.0.2.
The package resolution did not initialize a compiler. New experiments and
documentation checks have their own retained results. Final source-bound CI
and Docs gate receipts belong to the PR delivery summary.
