# Packed public-package consumer E2E

This frozen research experiment invokes the unchanged Orchestrator
`@agent-teams/local-host-control@0.0.0` discovery use case from an external
consumer, using public Core/Assembly 0.5.0 composition and independently packed
fixture extension B plus helper H. It does not qualify a product plugin Host,
UI, signed artifact admission, physical byte custody, controlled restart or
retirement. The baseline source and composition profile are explicitly TEST
fixtures. A candidate still requires an authenticated handshake.

## Reproduce

Use Node 24.21+ in the 24 line or Node 26.11.1+ in the 26 line and pnpm 11.25.0.
Extract this input archive into a fresh directory outside another checkout or
workspace. Internet access to the package registry is needed for the pinned
TypeScript 7.0.2 native compiler and Node declarations; the tested GM pair and
A source are retained locally.

```sh
pnpm install --frozen-lockfile --ignore-scripts --engine-strict --strict-peer-dependencies
pnpm e2e
```

The command performs a strict driver check, strict isolated builds of A, B, H
and the external consumer, tarball installation, then actual discovery calls.
It keeps `.runs/run-*/receipt.json`, every child command log, effective build
configurations, generated output, package archives and install locks. A passing
run has ten named checks plus the outer Node test: eleven passes and zero
failures, cancellations or skips. The final receipt is written as passed only
after all scenario and evidence collection work completes.

Each new consumer gets a separate install and fresh process. All consumer
installs share the same compiled consumer/composition bytes and the same packed
A bytes. Baseline and restored consumers do not install B. The extended
consumer installs B and its H dependency from tarballs; no workspace source
alias or private product import is used. The test intentionally inherits the
trusted parent environment, clearing `NODE_TEST_CONTEXT`; it is not a hostile
plugin sandbox or a hermetic process-custody proof.

## Inputs and build ownership

`inputs/provenance.json` identifies Orchestrator commit
`5a8496ce711909e381c5bc817fff5500be9a1761` and the unchanged source/manifest
files. The original root and Foundation 1.7.2 compiler preset JSON files are
read as data and flattened into explicit build settings. The legacy Foundation
CLI and its embedded older compiler are not initialized. Compiler 7.0.2 is
checked both by package identity and actual executable output.

The original A package includes a prepack script. The driver explicitly passes
pnpm `--config.ignore-scripts=true` while packing and asserts its already-built
`dist` bytes are unchanged. This is intentionally an isolated strict build of
unchanged A, not the entire product's standard build pipeline. B/H are research
fixtures, not registry releases. Both retained GM archive hashes are asserted;
this is not a fresh registry signature/provenance qualification.

pnpm 11 overrides belong in `pnpm-workspace.yaml`. Every generated consumer
workspace contains only itself. Local tarball overrides keep the unpublished H
fixture and the accepted GM pair exact. Consumer lock generation is followed by
frozen reinstall and an unchanged-lock assertion. The root compiler lock is
committed with this archive.

## What the finite scenarios establish

1. Strict isolated builds and identical installed A/package identities.
2. Baseline not-found plus an exact delegated candidate.
3. B/H change a real A result while preserving baseline delegation.
4. One reversal of module enumeration preserves selected plan, digest and result.
5. Real GM ambiguity rejects before any factory or executable B/H evaluation.
6. A redacts a source exception after the selected B is invoked.
7. A rejects a selected B observation for the wrong target.
8. A rejects at the exact fixed-clock expiry boundary without timing sleeps.
9. A held old source and a fresh B-bound instance retain independent bindings.
10. A fresh consumer without B restores literal baseline outcomes.

The independent literal result oracle is in `src/e2e.test.ts`; it imports no
fixture implementation or profile constants. B/H and the consumer are separate
author-owned sources. Fixture global markers observe module evaluation only;
they do not implement an application service registry.

The final repository report links planning, two independent result reviews,
the initial failed install, the earlier unintended prepack execution, corrected
local execution and any completed hosted results. Reviews are not extra test
runs. These finite calls do not establish fleet scale, sandbox safety, arbitrary
dependency closure admission, controlled restart or production reliability.
