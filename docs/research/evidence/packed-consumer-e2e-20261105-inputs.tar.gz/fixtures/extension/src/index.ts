import {
  componentVersion, epochMicroseconds, hostBootGeneration, hostCapabilityId,
  hostFreshnessEvidenceRef, hostInstanceId, hostProtocolRange, hostProtocolVersion,
  supervisorInstanceId, type HostDiscoverySource,
} from "@agent-teams/local-host-control";
import { extensionIdentity } from "@plugin-e2e/discovery-helper";

// TEST-only evaluation observation, unrelated to composition or service lookup.
Reflect.set(globalThis, Symbol.for("plugin-e2e/extension-evaluated"), true);

export function createCandidateSource(fallback: HostDiscoverySource): HostDiscoverySource {
  return {
    async read(target) {
      if (target.value !== "fixture-extension") return fallback.read(target);
      return {
        kind: "observed",
        observation: {
          capabilities: [hostCapabilityId("host.control.v1")],
          componentVersion: componentVersion(extensionIdentity.componentVersion),
          freshness: {
            evidenceRef: hostFreshnessEvidenceRef("fixture-evidence-b"), kind: "expiry",
            observedAt: epochMicroseconds(1_000_000n), validUntil: epochMicroseconds(2_000_000n),
          },
          hostBootGeneration: hostBootGeneration(7n),
          hostInstanceId: hostInstanceId(extensionIdentity.hostInstanceId),
          protocolRange: hostProtocolRange(hostProtocolVersion(1n), hostProtocolVersion(3n)),
          supervisorInstanceId: supervisorInstanceId("fixture-supervisor"), targetId: target,
        },
      };
    },
  };
}
