// TEST-only evaluation observation; this symbol carries no service or authority.
Reflect.set(globalThis, Symbol.for("plugin-e2e/helper-evaluated"), true);

export const extensionIdentity = Object.freeze({
  hostInstanceId: "fixture-host-b",
  componentVersion: "2.0.0-b",
});
