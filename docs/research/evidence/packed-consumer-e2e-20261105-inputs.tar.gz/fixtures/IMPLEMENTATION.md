# Independent adapter fixture implementation

Authoring checkpoint: 2026-11-05. No installation, compilation, package execution,
tests or repository mutations were performed by this implementation task before
the root-owned artifact staging/verification step. The parent task owns the
strict build, independent expected-value oracles, exact package installation,
runner, retained results and final publication.

## Files and ownership

- `helper/package.json`, `helper/src/index.ts`: independently built package
  `@plugin-e2e/discovery-helper@0.0.0`, public `.` export.
- `extension/package.json`, `extension/src/index.ts`: independently built package
  `@plugin-e2e/discovery-extension@0.0.0`, public `.` export, exact helper
  dependency and exact A peer dependency.
- `../consumer/composition.ts`: TEST-only real GM0.5 composition, no public SPI.
- `../consumer/consumer.ts`: child workflow receipt and controlled async fixture.

The four TypeScript sources total 200 physical lines at authoring. All new
maintained logic is `.ts`; emitted JavaScript and declarations belong to the
root-owned build, not additional authored implementations.

## B public API and identities

```ts
createCandidateSource(fallback: HostDiscoverySource): HostDiscoverySource
```

B imports the source contract and validated observation constructors only from
the installed public `@agent-teams/local-host-control` root. H contributes the
candidate `hostInstanceId` value `fixture-host-b` and `componentVersion` value
`2.0.0-b`. B handles only `fixture-extension`; every other target delegates to
the supplied fixture fallback source. The delegated test target is
`fixture-delegated`. Neither package supplies trusted authorization, locator
connection material, readiness, process custody or a service registry.

Top-level `Symbol.for("plugin-e2e/helper-evaluated")` and
`Symbol.for("plugin-e2e/extension-evaluated")` flags are finite TEST observation
instrumentation. They store no services or authority. The consumer never imports
B until GM runs the extension factory. Helper evaluation therefore cannot occur
through the authored consumer before successful preparation and construction.

## Applied GM graph

One contract `plugin-e2e/discovery/source`, revision1, is provided by baseline.
Extension B requires and provides that same source. GM's existing self-exclusion
leaves baseline as B's unique source. Actual A discovery requires that source.

Baseline selects baseline + actual discovery. Extended selects baseline + B +
discovery and explicitly binds discovery.source to B. Ambiguous selects those
same entries without the discovery binding; public GM preparation must refuse
the two candidates before factories execute. Reversed modes reverse the module
tuple, retaining the same profile ID and semantic bindings. No C package or
second artificial capability was authored.

## Child receipt

The child accepts exactly one of `baseline`, `extended`, `extended-reversed`,
`ambiguous`, `ambiguous-reversed`, `source-failure`, `target-mismatch`, `expiry`,
or `async-binding` as `process.argv[2]`. It emits one JSON line with:

- `mode`, `pid`;
- `preparation`: success status plus actual GM plan/digest, or failed status,
  actual code/cause/diagnostics;
- `factories`: actual factory invocation order;
- `evaluations.b`, `evaluations.h`: top-level evaluation flags;
- `results`: primary/delegated for ordinary modes, primary for negative modes,
  or fresh/old/oldAgain for the controlled async join;
- `observations`: baselineReads/bReads, plus async oldPendingBeforeRelease and
  B call counts before/after the old instance's second call.

Bigints serialize as `{ "type": "bigint", "value": "<decimal>" }` rather than
lossy JSON numbers. Candidate outcomes come from actual unchanged A
`createHostDiscovery(...).discover(...)`, never a parallel direct B call.

The async row first waits until the old source has entered its unresolved
promise, constructs a fresh B-bound A instance, obtains its candidate while the
old query remains pending, then releases old and calls that old instance again.
It proves per-instance captured dependencies and finite independent progress;
it does not implement or qualify retirement, drain, admission sealing, physical
cleanup or product restart.

## Verification handoff

Root must compile H, then B against installed A/H declarations, then the consumer
against the installed exact archives with effective strict TS7.0.2 checking.
The valid consumer has no source path aliases/deep imports/workspace shortcuts.
Pin root-only overrides of the unpublished exact helper package to its actual
archive and retain the resulting lock. No package source/exports need alteration.

Runtime-negative source wrappers are consumer-owned controls. They inject a
well-formed foreign target, a source exception or a fixed exact expiry clock;
they do not add policy switches to B. Root owns independent expectations and
must not import H/B's identity constants to generate its oracle.
