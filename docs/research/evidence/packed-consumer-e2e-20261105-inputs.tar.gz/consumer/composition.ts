import {
  createHostDiscovery, epochMicroseconds, microseconds,
  type HostDiscoverySource,
} from "@agent-teams/local-host-control";
import { required } from "@get-modular/core";
import { assemblyFor, declareModule, defineContract, implement, type CapabilitiesOf } from "@get-modular/assembly";

const Source = defineContract<HostDiscoverySource>()({ id: "plugin-e2e/discovery/source", revision: 1 });
interface Capabilities extends CapabilitiesOf<typeof Source> {}
const owner = { authority: "plugin-e2e", path: ["discovery"] } as const;
const baselineDeclaration = declareModule({
  moduleId: "plugin-e2e/discovery/baseline", implementationId: "plugin-e2e/discovery/baseline/default",
  owner, provides: [Source.provide()], slots: [],
});
const extensionDeclaration = declareModule({
  moduleId: "plugin-e2e/discovery/extension", implementationId: "plugin-e2e/discovery/extension/b",
  owner, provides: [Source.provide()], slots: [Source.slot("source", required())],
});
const discoveryDeclaration = declareModule({
  moduleId: "plugin-e2e/discovery/consumer", implementationId: "plugin-e2e/discovery/consumer/default",
  owner, provides: [], slots: [Source.slot("source", required())],
});

export interface Observations {
  readonly factories: string[];
  baselineReads: number;
  bReads: number;
}
export interface CompositionOptions {
  readonly extended: boolean;
  readonly reversed?: boolean;
  readonly ambiguous?: boolean;
  readonly now?: bigint;
  readonly wrap?: (source: HostDiscoverySource) => HostDiscoverySource;
}

export async function composeDiscovery(source: HostDiscoverySource, observed: Observations, options: CompositionOptions) {
  const baseline = implement<Capabilities>()(baselineDeclaration, async () => {
    observed.factories.push("baseline");
    return { instance: source, capabilities: { [Source.id]: source } };
  });
  const extension = implement<Capabilities>()(extensionDeclaration, async dependencies => {
    observed.factories.push("extension");
    const { createCandidateSource } = await import("@plugin-e2e/discovery-extension");
    const candidate = createCandidateSource(dependencies.source);
    const counted: HostDiscoverySource = { read: target => { observed.bReads += 1; return candidate.read(target); } };
    const selected = options.wrap === undefined ? counted : options.wrap(counted);
    return { instance: selected, capabilities: { [Source.id]: selected } };
  });
  const discovery = implement<Capabilities>()(discoveryDeclaration, async dependencies => {
    observed.factories.push("discovery");
    const instance = createHostDiscovery({
      source: dependencies.source,
      clock: { now: () => epochMicroseconds(options.now ?? 1_500_000n) },
      freshnessPolicy: { maximumFutureSkew: microseconds(100_000n), maximumObservationAge: microseconds(1_000_000n) },
    });
    return { instance, capabilities: {} };
  });
  const bindings = options.extended && options.ambiguous !== true ? [{
    consumerImplementationId: discoveryDeclaration.implementationId, slotId: "source",
    providerImplementationIds: [extensionDeclaration.implementationId],
  }] : [];
  const modules = options.extended
    ? options.reversed === true ? [discovery, extension, baseline] as const : [baseline, extension, discovery] as const
    : [baseline, discovery] as const;
  return assemblyFor<Capabilities>().prepare({ profileId: "plugin-e2e/discovery", modules, roots: { discovery }, bindings });
}
