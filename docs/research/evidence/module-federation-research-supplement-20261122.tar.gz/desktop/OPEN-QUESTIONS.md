# Owner questions — desktop profile

No option below is adopted. Recommendations are for discussion after the source review; each question changes a concrete boundary.

## Q1. Which code may share the desktop renderer?

**A — trusted application-owned UI extensions in the existing renderer.** Smallest UI integration cost; shared DOM/styles/globals and exposed bridge capabilities must be accepted.

**B — independently supplied UI in separately constrained web contents/realm.** Clearer authority/lifetime boundaries, but host UI integration and cross-boundary communication cost more; a separate realm alone is not a complete permission model.

**C — both, as explicit separate profiles.** More qualification surface; avoids treating same-realm loading as isolation.

**Recommendation to discuss:** A for the initial first-party consumer if that matches the product; add B only with an actual independent-code use case and tested authority boundary. Do not label utilityProcess a sandbox merely because the process-model docs mention “untrusted services.” [D08]

## Q2. How does renderer code evolve against the installed preload?

**A — stable bridge with an explicit compatibility window/capability negotiation.** Allows compatible UI revisions without packaged host update; requires contract maintenance and receiver-side checks.

**B — renderer and bridge treated as a coupled update unit.** Simpler compatibility promise; more renderer/app restarts.

**C — mix by feature.** Stable narrow base plus explicitly coupled capabilities; more planning cases.

**Recommendation to discuss:** evaluate A with a deliberately small base and explicit restart requirement for incompatible features. Do not choose the number of supported versions or automatically recreate contexts before seeing the real consumer. [D01, D02, D03]

## Q3. Which state must survive a renderer/process replacement?

**A — main/application custodian owns durable drafts and operation outcomes.** Renderer refresh becomes a reconnect/restore; main must not become an unstructured service container.

**B — each plugin owns state with explicit checkpoint/recovery.** More autonomy; more per-plugin migration and failure obligations.

**C — external durable service owns selected state, with local transient UI state.** Suitable when a service already exists; adds offline/conflict questions.

**Recommendation to discuss:** classify state first. User-authored drafts and irreversible operation outcomes need a meaningful acknowledged durability level; transient view state may use reset/restore. Transport acknowledgement alone is insufficient. Storage backend and persistence cadence remain open. [D04, D05, D06]

## Q4. What is the native-service update boundary?

**A — application lifetime.** Fewest process/IPC boundaries; native changes generally require an app restart.

**B — suitable native work in a utility process.** Independent replacement/crash containment; requires handover or interruption policy for jobs and device handles.

**C — mixed by capability.** Native modules that cannot tolerate process migration remain app-bound.

**Recommendation to discuss:** C only as a capability distinction initially; implement B when an actual native workload justifies it. Do not promise zero interruption for exclusive devices or preserve arbitrary native memory. [D07, D09]

## Q5. What may update independently of the signed application?

**A — only packaged application updates initially.** Simple deployment identity, fewer live code surfaces.

**B — authorized renderer/plugin artifacts independently, privileged main/preload/native changes through packaged updates.** More live flexibility; explicit host compatibility and artifact retention required.

**C — independently delivered privileged modules too.** Largest authority/qualification/distribution surface.

**Recommendation to discuss:** evaluate B against the actual distribution channel and trust requirements. Do not assume an ASAR fuse validates external plugin code or unpacked native assets. No platform-store policy was researched or accepted here. [D10, D11]

## Q6. What should happen when clean retirement cannot be proved?

**A — retain old work, block incompatible activation and expose the reason.**
**B — permitted bounded interruption/restart after a policy deadline.**
**C — choose by resource class, with explicit user-visible data-loss/availability consequences.**

**Recommendation to discuss:** C as a policy question, not a global default. The library should be able to report supported scope, remaining work and checkpoint status; the product owns acceptable interruption. No timeout value or automatic kill policy is selected. [D04–D07]

## Questions resolved by evidence rather than preference

- A new renderer MF revision does not itself install a new preload or main/native binary.
- A repeated contextBridge binding is not a supported overwrite mechanism.
- Removing an IPC handler does not revoke already dispatched side effects.
- A utility-process display name is not a unique physical attempt.
- Zero exit status and message transport flush do not certify durable state.
- Node-API ABI stability and native module unloadability are different properties.

Detailed evidence and limitations: `REPORT.md`, `findings.json`, `sources.json`.
