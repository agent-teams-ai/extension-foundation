# Peer review — federation native plan

Reviewer: `/root/desktop_update`, 2026-11-22. Reviewed `/federation/PLAN.md` checkpoint before implementation. No native execution. Decision: **suitable bounded spike after the following oracle clarifications**; this is not production runtime adoption.

## Ready mechanisms and scope

The plan uses released `@module-federation/runtime` and actual webpack-generated containers, sharing and consume runtime. It does not reimplement federation, a container, HMR or a production lifecycle. A small explicit listener and cleanup function are legitimate probes of retained side effects, provided the result is phrased as lack of automatic ownership rather than failure to honor a cleanup contract MF never accepted. Source-only HMR/Rspack/Electron/SSR findings must remain outside the executed profile.

## Required oracle clarifications

1. **N1 old references:** assert the old listener reacts once before replacement, still reacts once after B is selected, and stops only after the fixture's explicit cleanup. Retained A reference and new B lookup are separate assertions. A/B need distinct entry URLs, entry globals and webpack unique names; this does not qualify same-global overwrites or existing long-running async work. Use a fresh browser context per independent case so process-global MF state cannot leak across tests.
2. **N1 evaluation:** record entry/init/get/factory markers only where the public API and generated code genuinely expose them. The ordinary exposed-module marker occurring before fixture publication proves that `loadRemote` executed that module; it does not prove every earlier stage is pure. `loadFactory:false` is a useful positive control only if the exact public typings admit it. Do not create a custom preflight loader.
3. **N2 destructive validation:** source order was independently inspected in `packages/runtime-core/src/remote/index.ts` at commit `40688424f13ea9d4338b9a0cf230e8f1ac4d3835`: force removes the registered remote, then normalization validates aliases. Freeze the concrete input: peer `occupied/sub`, target `replaceTarget`, replacement alias `occupied`. Assert native registration throws and await subsequent public `loadRemote('replaceTarget/probe')`; distinguish missing registration from arbitrary network failure. Registry-array inspection is diagnostic, not the sole oracle. Keep A's retained callable/resource observable. This qualifies one validation path, not all forced-update failures. A public re-registration recovery control is useful if it fits the existing budget, not a reason to add another coordinator.
4. **N3 singleton strictness:** make the compatible provider selected and loaded before testing incompatibility. The strict incompatible consumer must have no matching second provider or usable local fallback; explicitly set/record webpack sharing options, including `import:false` where appropriate. Assert actual token reference identity in the compatible case. Error text alone is insufficient unless the error is identified as native shared-version rejection and no remote network/build failure occurred. Read-only selected-provider diagnostics are fine; no custom shared registry.
5. **N4 actual boundary:** assert runtime instances differ, target entry/global is physically the same generated container, and the two actual `default` share-scope objects differ before attributing rejection to object identity. Record entry request count and the captured global reference. If the released runtime coalesces/reuses a scope or creates a new container, record that observation; do not force unsupported internals to manufacture the planned rejection. Fresh context success controls realm-local contamination, not native-addon or IPC compatibility.

The owner confirmed these source paths and intended public lookup oracles in a peer discussion and will amend the plan before execution. Existing compile/dependency gates and explicit profile limits are appropriate. The 450–700 LOC estimate is plausible but near the point where build/server helpers dominate; keep fixtures small and do not add snapshot persistence, retries or generic lifecycle services to satisfy this spike.

## Non-blocking limitations to preserve

- Positive singleton sharing is a dependency identity result, not proof of state migration compatibility.
- Missing old listener cleanup is expected in a same-realm loader without resource ownership; the report should not call it an MF leak without demonstrating unreachable retained resources.
- Native source/runtime errors need exact version, stage and minimal cause, including what is still usable afterward.
- Neither frame reload nor a second runtime instance demonstrates preload/IPC/native-host replacement. Desktop research separately covers those lifetimes.

Primary reviewed source: https://github.com/module-federation/core/blob/40688424f13ea9d4338b9a0cf230e8f1ac4d3835/packages/runtime-core/src/remote/index.ts . No repository changes, package installation or execution were performed by this review.
