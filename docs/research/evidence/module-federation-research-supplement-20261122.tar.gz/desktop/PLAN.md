# Desktop update boundary research

Status: source investigation complete, 2026-11-22 UTC. No runtime adoption or native Electron execution. Peer review of the adjacent federation plan was also delivered; that review did not execute a fixture.

## Scope and evidence

Investigate Electron renderer, preload/contextBridge, IPC, utilityProcess, native add-ons and packaged application update boundaries. Integrate with the existing library blueprint; do not repeat prior Worker/CodeMirror experiments. Inspect official current docs and exact released source; distinguish source conclusions from executed observations. Owner decides trust profiles, restart policies and supported host contracts.

Baseline: extension-foundation `7d9c6ab06b296feb286dcf0c6edb510be8ac4105`; org quality standard `0b44c64c824f536bd1b085341e7669bcc64ef124`. Current Electron release discovered 2026-11-22: `v45.4.1`, published 2026-11-19, commit `deaded07eebdfe9a3737884933b1acbe65971f64`, with Chromium `156.0.8078.100` and Node `v24.22.3` in DEPS. These pins scope conclusions; future upgrades need renewed verification.

## Work packages

1. Check renderer/preload contract and physical realm identities; record public APIs and invalid assumptions.
2. Trace IPC dispatch/removal and process lifecycle through released implementation; qualify cancellation, ownership and cleanup evidence.
3. Separate native ABI, binary replacement, ASAR integrity and application updater responsibilities; review specific upstream incidents and counterevidence.
4. Publish capability/update-scope table, architecture constraints, open owner questions, source ledger and evidence gaps.

## Change envelope and estimates

This pass: production LOC **0**, integration LOC **0**, executed test LOC **0**. Research artifacts approximately **850–1,100** lines including structured source/finding ledgers; these are planning estimates, not feature delivery metrics.

Optional later native probe, only after concrete bounded plan review: 2–3 Electron scenarios covering an existing preload contract after renderer code replacement, frame reload while IPC work continues, and parent-owned utility process survival/reconnect. Estimated harness/integration **180–300** TypeScript LOC, assertions/tests **100–180** LOC, production **0** LOC. Does not benchmark or certify production. Review API/version, installation provenance, cleanup and terminal evidence before execution.

Subjective scope ratings (estimates, not measurements): source research confidence **8/10**; production runtime reliability **unrated** because no native run; source-to-contract reliability **7/10**; source research complexity **5/10**; prospective native probe complexity **6/10**. IPC and process source can expose semantics but cannot establish platform behavior or race freedom alone.

## Stop conditions

No new public abstractions, dependencies, package split, production Electron adapter, security policy, native execution, or main/preload update policy are adopted here. A proposal is labelled as such. Preserve counterevidence and unresolved version/platform details; do not inflate source findings into E2E results.
