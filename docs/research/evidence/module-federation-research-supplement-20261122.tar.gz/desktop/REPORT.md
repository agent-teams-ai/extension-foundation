# Electron: what a live update can actually replace

Status: **source investigation complete**, 2026-11-22. No Electron installation or execution; no production adapter or public API adopted. Existing Worker/CodeMirror/native evidence is reused as background and counted zero times in this pass. Findings below distinguish released source, upstream incident history and architectural inference.

## 1. Result

Desktop readiness requires explicit boundaries between **renderer code, the installed preload contract, main-process authority, native process lifetime and the packaged application**. Loading a new renderer remote changes only the first of these unless the host deliberately coordinates others. The existing blueprint can keep these differences inside runtime/host adapters; treating every change as one generic module reload would hide materially different restart and state risks.

The strongest new evidence is an Electron fix/counterexample chain: flushing messages already received by the parent did not make `postMessage(); process.exit()` reliable. The upstream tests restored a parent acknowledgement. In the same released source, application shutdown deliberately drops child messages and emits utility-process `exit(0)` even for wrappers whose process is still launching. **A transport event or zero exit code cannot be the durable-state receipt.** [E-utility-source, E-message-fix, E-ack-fix, E-launch-fix]

This is a necessary consequence of the user's requested reliable state handover. Which state owner, acknowledgement format, compatibility window and restart policy to implement remain questions, not decisions.

## 2. Evidence boundary and current pins

| Component | Exact version / commit | What was inspected |
|---|---|---|
| Electron | 45.4.1; `deaded07eebdfe9a3737884933b1acbe65971f64`; released 2026-11-19 | Public docs, native bridge/IPC/process/ASAR source, released tests and fix history |
| Embedded Node dependency | v24.22.3; `e63cab040c09d43ceef8cb35508c40044614e906` | Node-API, add-ons and CommonJS documentation |
| Chromium dependency | 156.0.8078.100; `46876a0c2df3492ed67a8846950ba6d37170b58c` | Upstream process termination implementations; Electron applies patches, so these are implementation context, not a separately tested runtime |
| Existing project | `7d9c6ab06b296feb286dcf0c6edb510be8ac4105` | Library blueprint and prior reliability evidence; no repository edits |

Official pins: [Electron release](https://github.com/electron/electron/releases/tag/v45.4.1), [Electron DEPS](https://github.com/electron/electron/blob/deaded07eebdfe9a3737884933b1acbe65971f64/DEPS). Full source identifiers and URLs are in `sources.json`; `findings.json` records the class and limits of every finding. Source inspection is not a native race reproduction.

## 3. Renderer replacement and preload are different contracts

**Released behavior.** `contextBridge` proxies functions and copies/freezes other supported values by default. `ExposeAPI` refuses an already existing global property; its mutability feature is disabled by default and does not bypass that existing-property check. A second `exposeInMainWorld('api', ...)` is therefore not a supported way to overwrite the installed contract. [E-bridge-doc, E-bridge-source]

**Counterevidence to an overbroad conclusion.** A proxied function can delegate to mutable internal implementation or data. The default frozen API surface does not freeze all behavior. A deliberately stable wrapper can support evolving implementations, but this research does not select that design or its compatibility window.

`session.registerPreloadScript` adds to session preferences. `unregisterPreloadScript` erases the record; it does not run inverse operations in existing contexts. Docs explicitly say in-page navigation does not rerun preloads. New service-worker starts rebuild their startup data from current preferences; this is not an update of an already executing worker. [E-session-doc, E-session-source]

**Architecture implication.** Before admitting a renderer revision, its required host capabilities must be compatible with the actual installed bridge. A remote declaring a newer API does not create it. Possible responses include keeping the old UI, selecting a compatible remote, recreating an appropriate renderer context, or requiring a packaged application restart. The supported responses are profile/owner choices.

Do not equate `webContents` or a module registration with a document generation. `frameTreeNodeId` lives for the frame's lifetime; navigation can replace the document. The native IPC event resolves `senderFrame` again on each access and explicitly warns when it has navigated or disappeared before an asynchronous read. [E-frame-doc, E-ipc-event]

**Proposed guard, not adopted API:** identify the active client connection/document separately from the plugin revision and main host build. Capture validated sender facts before asynchronous work and check current authority when committing an effect. A renderer-supplied generation field alone is not an authority boundary.

## 4. IPC handler replacement does not cancel work already admitted

Released `ipcMain.handle` rejects duplicate registration; `removeHandler` only deletes a channel entry. Native dispatch finds the current function, calls it, and attaches promise continuations for its eventual reply. Subsequent registry deletion does not erase that invocation or its side effects. [E-ipc-main, E-ipc-dispatch]

**Consequences for update planning:**

- A disconnected/reloaded renderer may no longer receive its reply while the main operation continues.
- An IPC callback, subscription and resource lease need explicit ownership; removing one channel is not evidence that all old work retired.
- A stable channel can route to different plugin generations only if the application's admission and effect-authority checks preserve the intended semantics.
- Bridge/IPC serialization is a protocol boundary: custom prototypes and some Error properties do not survive as live objects. Do not expose internal domain objects and assume identity or custom error classes survive. [E-bridge-doc]

**What to reuse:** `ipcMain` handlers, frame-scoped IPC where appropriate, `MessageChannelMain`, transferable ports and native close events. The official MessagePorts example reconnects clients to a separately owned worker after window reload; its example worker is a hidden BrowserWindow. Electron's process-model and utility API separately support main-owned Node utility processes and renderer communication via MessagePorts. Do not cite the hidden-window example as a native utility-process test. [E-messageports, E-process-model, E-utility-doc]

A port close is a transport observation. It does not tell the application whether the last operation committed or whether a remote resource can safely be reassigned. That is an inference from the distinct ownership and invocation lifetimes, not a new claim about message ordering.

## 5. Utility process: useful existing host, precise termination evidence

A utility process is main-owned, runs Node APIs, supports transferable MessagePorts, and can be restarted independently of a renderer. The released source explicitly treats it as unsandboxed for termination/zygote handling. Process separation supplies a lifetime/crash boundary; it does not by itself make arbitrary code unprivileged. [E-process-model, E-utility-doc, E-utility-source]

The public process-model page lists “untrusted services” as a possible use case. Its same paragraph gives the process all Node APIs, and the source marks this utility process unsandboxed. Therefore that phrase is not evidence of a permission sandbox. Remote renderer code likewise inherits the capabilities available to its renderer and bridge; trust and distribution policy remain separate choices. Electron's security documentation specifically rejects remote code with Node integration enabled. [E-security]

### Why kill/exit needs careful interpretation

`UtilityProcessWrapper::Kill` calls `Process::Terminate(..., false)`, then `EnsureProcessTerminated`, and returns the first call's boolean. On upstream non-Apple POSIX, the latter schedules a background wait then SIGKILL; on macOS it invokes a two-second child wait/kill path. Windows `Process::Terminate` uses `TerminateProcess`, with pending I/O explicitly acknowledged by the source. Electron's patch manifest and the process-launch/exit patches were inspected, but a full applied Chromium tree was not built or diffed. **Do not make cross-platform timing promises from these upstream details.** [E-utility-source, C-kill-posix, C-kill-mac, C-process-win, E-patch-list]

The useful released-source conclusions are narrower:

1. The boolean is not an awaited observation of guest cleanup.
2. Expected POSIX SIGTERM/SIGKILL results are normalized to exit code zero.
3. Browser shutdown takes a distinct path: `ShutdownAll()` invokes `Shutdown(0)`; that closes the connector before `HandleTermination`, while the child may still be running.
4. Thus `exit(0)` is not a universal physical-termination certificate and is never proof that a state snapshot was received or persisted.

Normal process exit and application teardown must remain distinguishable in any adapter evidence. Durable state needs its own acknowledged checkpoint before teardown begins; abrupt exit is a separate recovery case.

### Historical incident chain, checked against released source

| Upstream change | Actual scope / counterevidence | Practice to retain |
|---|---|---|
| Original [#54924](https://github.com/electron/electron/pull/54924), backported to 45-x-y by [#54956](https://github.com/electron/electron/pull/54956), merged 2026-10-15; released-line commit `53d6d27...` | Closed parent connector dropped queued messages. Fix drains already readable messages before normal exit. Browser shutdown still drops them. | Record when messages reached the receiver; do not infer durability from process exit. |
| Original [#55082](https://github.com/electron/electron/pull/55082), backported to 45-x-y by [#55123](https://github.com/electron/electron/pull/55123), merged 2026-10-20; released-line commit `0f79472...` | Restores acknowledgement removed by original #54924 (the commit text names that original, not #54956): `process.exit()` does not wait for pending `postMessage` writes. Current test uses an ordered-channel barrier and parent reply before exit. | An upstream transport fix does not remove the need for an application acknowledgement. Receipt of bytes is still weaker than persisted state. |
| [#55274](https://github.com/electron/electron/pull/55274), merged 2026-10-23; `0b6c60b...` | Tracks wrappers from construction, not only PID assignment; pending launches now receive shutdown handling/exit. Original [#55233](https://github.com/electron/electron/pull/55233) describes heap-teardown/port lifetime failure. | Register resources before asynchronous launch can fail; terminal cleanup must include pending creation. An exit callback may represent wrapper teardown. |
| [#55277](https://github.com/electron/electron/commit/14bdd527a8f36ee7657b8804de7d05971fc4f517) | A prior test's child-process-gone event could satisfy the next test because utility processes shared a display name. Matching only exit code remained insufficient; test moved to its own app. | Correlate observations to a physical attempt, not a service label. Do not use retries as evidence that a race is fixed. |

These are **historical upstream fixes plus current source/test inspection**. No local reproduction or claim about upstream CI completion is made. The last three details are easy to miss when reading release-note titles alone.

## 6. Native add-ons: ABI stability is not reloadability

Electron documents ABI differences from a standalone Node binary and provides `@electron/rebuild`; Forge integrates the rebuild tooling. Node-API is a useful counterexample to “every native add-on always needs rebuilding”: exclusive use of its stable C API can preserve ABI across Node versions, but direct V8/Node C++/libuv calls and external native dependencies have separate compatibility requirements. This does not establish portability across OS/CPU or prove that an arbitrary package supports this Electron build. [E-native-doc, N-napi]

Node's CommonJS docs explicitly exclude native add-ons from the ordinary “delete require.cache then reload” behavior. Node's add-on docs require per-environment handling for context-aware add-ons, avoid persistent JS references in global static data, and provide cleanup hooks. Node-API documents environment teardown with JS execution disabled and ordering constraints for native cleanup. [N-modules, N-addons, N-napi]

**Architecture consequence:** a native binding cannot be treated as a replaceable JS module merely because its ABI is stable. A separately owned utility process can provide a restart boundary for suitable trusted native work; using it, choosing device custody and accepting an interruption are owner decisions. Main-bound native work may require an application restart. External effects already committed by a native operation require product-specific recovery.

Do not invent another native loader, ABI resolver, process supervisor or auto-updater when Electron/Node's supported mechanisms can perform the task. Our distinctive code is the compatibility/ownership/update orchestration around those mechanisms.

## 7. Packaged update and plugin artifact update are separate

Electron's built-in updater supports macOS and Windows; the pinned docs now distinguish Windows MSIX from Squirrel.Windows. macOS automatic updates require application signing. Download completion does not change the running host: `quitAndInstall` or next launch applies the application update. The `before-quit-for-update` event exists because ordinary `before-quit` occurs only after windows have closed on this path. Required state should already be checkpointed before calling the updater; an event listener is not automatically an awaited persistence transaction. [E-updater]

ASAR integrity is an optional fuse, disabled by default, supported on macOS/Windows. It binds archive contents to a packaged header hash; the docs recommend combining it with `OnlyLoadAppFromAsar`. It is not an authorization scheme for arbitrary external plugin revisions. In the released archive implementation, an `unpacked` file returns before per-file integrity payload parsing and extraction returns the companion filesystem path; the ASAR check therefore does not establish integrity of all unpacked native assets. Platform signing or a separately designed artifact policy may provide other coverage, which was not audited here. [E-asar-integrity, E-asar-source, E-asar-doc]

Do not patch a running packaged `app.asar` as a generic plugin-update strategy. A host can deliberately load authorized external artifacts, but their storage, retention and compatibility are separate from signed app deployment. Choose that distribution policy explicitly.

## 8. Readiness now, choices later

The complete scope table is in `CAPABILITY-UPDATE-SCOPE.md`. The following preserve already requested guarantees without deciding a desktop implementation:

| Keep explicit now | Why it is necessary | Do not adopt silently |
|---|---|---|
| Requested update scope and actual affected scope | Renderer replacement can leave bridge/main/native generations unchanged | A universal same-realm reload API or automatic escalation to full app restart |
| Actual host contract/capability requirements | New UI can require APIs unavailable in the installed preload | Version scheme and number of compatible generations |
| Physical owner and creation/termination phase | Pending launch, live process, disconnected client and app teardown differ | One utility process per plugin or a shared host |
| State receipt level | Sent, received, application-accepted and durably persisted differ | Storage backend, checkpoint frequency, migration authority |
| Logical retirement versus known remaining work | Deleted IPC registration does not stop admitted work | Automatic kill/timeout or rollback policy |
| Observable recovery/restart requirement | User needs to know what changed and which unsaved work is safe | Product UI wording, mandatory reload, loss acceptance |

**Proposed user-facing result, not an API:** an update can report “renderer revision available; current host contract incompatible; restart required; draft checkpoint confirmed” instead of a generic success flag. A compatible renderer update can publish after its actual preparation/state handoff and show old work still draining separately. Exact outcome names and UI are owner choices.

Avoid creating cross-runtime abstractions beyond these concrete needs. Electron details stay at the host adapter; the core update operation consumes precise capabilities and evidence rather than imports Electron APIs.

## 9. Remaining verification and deferred work

- No new desktop E2E claim. A native probe would need actual Electron/platform receipts for bridge lifetime, IPC work after frame replacement and utility shutdown/reconnection; `PLAN.md` gives scope estimates, not execution approval.
- A full Electron-patched Chromium tree was not built. Upstream timeout values are implementation context only, excluded from proposed public guarantees.
- Package signing/notarization/distribution rules and actual application channel are unspecified; no policy was selected.
- CSS/custom-element/framework registry ownership belongs to the renderer/framework study. MF's documented lack of automatic CSS isolation is consistent with this report, but no desktop CSS cleanup test ran.
- Options requiring user choice are in `OPEN-QUESTIONS.md`. No claim that this architecture prevents every future refactor.

## Key direct sources

- [Pinned contextBridge implementation](https://github.com/electron/electron/blob/deaded07eebdfe9a3737884933b1acbe65971f64/shell/renderer/api/electron_api_context_bridge.cc).
- [Pinned utility-process implementation](https://github.com/electron/electron/blob/deaded07eebdfe9a3737884933b1acbe65971f64/shell/browser/api/electron_api_utility_process.cc) and [current released utility tests](https://github.com/electron/electron/blob/deaded07eebdfe9a3737884933b1acbe65971f64/spec/api-utility-process.spec.ts).
- [Restored acknowledgement commit](https://github.com/electron/electron/commit/0f79472f0bdf27e4977e5c89f5bacb2957650f7e).
- [Pinned Node-API docs](https://github.com/nodejs/node/blob/e63cab040c09d43ceef8cb35508c40044614e906/doc/api/n-api.md).
- [Pinned updater docs](https://github.com/electron/electron/blob/deaded07eebdfe9a3737884933b1acbe65971f64/docs/api/auto-updater.md).
