# Desktop capability and update-scope table

Source-inspected Electron 45.4.1. This describes boundaries, **not an adopted runtime profile**. “Can” means a mechanism exists; actual safety requires the stated compatibility/ownership checks. No native desktop scenario was executed.

| Changed unit | When a running instance sees new code | State / resource boundary | Ready mechanism | Required evidence or unsupported case |
|---|---|---|---|---|
| Renderer MF remote | When the runtime loads/evaluates that revision and application selects it; old export references may still exist | Same document/global scope unless a separate realm is used; DOM/listeners/styles need actual ownership | Existing MF runtime; UI framework mount/unmount/update APIs | Correct selected revision, compatible host contract, retired side effects; not proof of unloading old references |
| Renderer document | After reload/navigation creates the relevant new document/context | In-memory renderer state and client ports recreated; main-owned resources may remain | BrowserWindow/webContents navigation; MessagePorts reconnect | Checkpoint/restore result, new client identity, old admitted work disposition; renderer reload does not update main binary |
| Installed preload API | Existing API remains for its context; future contexts execute configured preload | Isolated-world lifetime and exposed API contract | contextBridge; session preload registration/unregistration | New preload registration is not an inverse operation on existing effects; duplicate global binding is rejected |
| IPC main handler | New registration affects later dispatch; previously invoked handler/promise continues | Main-process invocation and effect owner | ipcMain handle/removeHandler; frame-scoped IPC and message channels | Duplicate registration error handled; no claim removeHandler cancels prior effects |
| Main JS module | Only through a deliberately designed host-level replacement or application restart | Existing main globals, subscriptions, windows and native references persist otherwise | Node module mechanisms where suitable; packaged app updater | Renderer MF does not perform this update; exact main hot-replacement support remains unselected |
| Utility-process module | New process executes selected artifact; changing the file does not replace already executing JS | New Node environment; old jobs/handles/state need handover or recovery | utilityProcess.fork/kill, MessageChannelMain, native close/exit observation | Kill boolean and exit0 are not durable-state receipts; app shutdown has different exit semantics |
| Native add-on | A compatible load in an appropriate new environment/process or app build; no generic cache-delete reload | ABI/platform and native resources; environment cleanup may disallow JS | Node-API/context-aware hooks, @electron/rebuild/Forge; utility process where suitable | Validate actual package support; ABI stability does not guarantee unload/reload; exclusive device handover is owner policy |
| Packaged app / Electron / native host | At supported updater application/relaunch or installation boundary | Host ABI, packaged preload/main, executable signing and migration compatibility | Electron autoUpdater and platform distribution tooling | Supported package/channel; saved state before windows close; downloaded does not mean running |
| External plugin artifact | When explicitly admitted by the application's loader | Artifact authority, revision retention and compatibility separate from host package | Existing authorized artifact loader/distribution mechanisms, if selected | ASAR integrity is not plugin trust; app.asar.unpacked bytes need separate coverage |

## Identities to keep distinct

Plugin artifact revision; loaded module/export reference; renderer document/client connection; installed bridge protocol/capabilities; main host build; utility-process attempt; native ABI/platform. Some can share values in a chosen profile, but no evidence permits collapsing them universally.

## Evidence map

Renderer MF specifics are owned by the federation study. Other rows map to findings D01–D14 and source identifiers in `sources.json`. An application may deliberately offer narrower capabilities; unsupported actions should be observable rather than silently treated as completed.
