# Peer review — actual Module Federation fixture inputs

Reviewer: `/root/desktop_update`, 2026-11-22. Reviewed `federation/probe/build.ts`, `probe.test.ts`, `fixture/{host,remote,consumer,token,types}.ts`, `package.json`, `tsconfig.json`. No compilation, build, installation or native run by this reviewer.

**Verdict:** suitable for the bounded reviewed profile after the scope clarification below and the lane's dependency/strict-check gate. No custom loader, registry, shared resolver or lifecycle coordinator is present. Generated webpack containers and published MF runtime perform the behavior under test.

## One profile clarification before freeze

N3 registers the host provider through the runtime's public `shared.lib` API. The consumers are actual webpack-generated shared consumers with `import:false`, strict singleton configuration and distinct required ranges. `fixture/token.ts` provides TypeScript contract resolution and is explicitly not bundled as a fallback.

This is a useful **runtime-registered host provider + generated webpack consumers** profile. Amend the original plan wording that implied a generated provider/real bundled fixture package. Do not add a package or synthetic container merely to satisfy the wording. The result will qualify this public interoperation profile, not webpack-generated provider registration or arbitrary npm package duplication.

## Oracles checked

| Case | Independent observations present | Remaining scope limit |
|---|---|---|
| N1 | Initial A listener reacts; after selecting B, A still reacts; explicit A cleanup stops it. Old A and new B exports differ. Module-evaluation records observe the fixture's publication marker. Public hooks report init/get before deferred exposed factory is invoked. | The marker is an observation of application selection order, not proof of a production transaction. No unreachability/GC or arbitrary async-work claim. |
| N2 | Exact alias conflict; native error checked; subsequent public lookup must fail with RUNTIME-004; old callable/listener remain; explicit cleanup; public re-registration restores A lookup. | One concrete validation failure path. Read-only options array is secondary evidence, not sole oracle. |
| N3 | Public `loadShare` selects the host provider before compatible consumer; exact token reference identity; one provider version; strict ^2 mismatch; compatible token remains usable; incompatible container entry exists. Build config excludes fallback. | See provider-profile clarification. No automatic state/protocol compatibility inference from token identity or semver. |
| N4 | Distinct runtime instances, actual default scope objects exist/differ, same captured container global remains, exact native different-scope init error, retained A still works. Separate browser-context control loads A successfully. | Entry requests are retained in the receipt rather than asserted as exactly one; sufficient when combined with the container identity/error observations. This is a realm/container test, not a sandbox test. |

Each independent observation uses a fresh browser context. Missing assets and unrelated page exceptions are rejected so a 404 or broken harness cannot masquerade as a semantic runtime error. Expected runtime warnings/errors remain in console diagnostics. Scope maps and globals are inspected without mutation.

## Receipt handling before claiming success

`native.json` contains observations and browser/network diagnostics; most decisive assertions run outside `observe()`. Therefore a recorded observation is **not** itself a passed test. Retain the complete node:test terminal result and command exit status. If `observe()` records an observation and later detects a page/network problem, its catch may append another record for the same ID; aggregate by scenario outcome and test status, never by array length.

Record exact reviewed inputs/lock hash, generated asset hashes, compiler/browser/Node/runtime versions and the completed dependency audit. If strict compilation exposes a public-typing mismatch or the runtime gives a different result, preserve the original failure and revise the classification rather than altering internal maps to force the expected outcome.

The dedicated positive controls are enough for this question set. No further tests, fallback variant, SSR integration or desktop execution are requested by this review.
