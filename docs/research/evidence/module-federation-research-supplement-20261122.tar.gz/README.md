# Живые обновления модулей — дополнение к переносимому исследованию

Срез: **2026-11-22**. Здесь сохранены четыре новых направления исследования,
два завершённых нативных спайка и семь вопросов владельцу. Все варианты решений
остаются **OPEN**. Production-библиотека, новый публичный SPI и отдельный remote
репозиторий этим пакетом не объявляются готовыми.

## С чего начать

| Что нужно | Файл |
| --- | --- |
| Итоговая архитектурная аргументация, границы и предупреждения о дублировании | [Основной документ](reading-copies/docs/research/module-federation-update-boundaries-and-architecture-options-2026-11-22.md) |
| Семь вопросов, варианты, условные предпочтения — по-русски | [Вопросы владельцу](architecture-review/OWNER-QUESTIONS.md) |
| Module Federation, webpack, JupyterLab, shared identity | [Federation](federation/REPORT.md) |
| SystemJS, import maps, Worker/CDN/client adoption | [Доставка](delivery/REPORT.md) |
| Electron, bridge/IPC, native lifecycle и обновление host | [Desktop](desktop/REPORT.md) |
| Envoy, Angular и Unreal | [Другой отраслевой опыт](root/REPORT.md) |
| Проверка распределения ответственности | [Архитектурный review](architecture-review/REPORT.md) |
| Реальный браузерный результат и независимая проверка | [Hosted audit](ci/HOSTED-AUDIT.md), [semantic review](federation/NATIVE-SEMANTIC-REVIEW.md) |
| Переносимость и происхождение каждого файла | [PROVENANCE.json](PROVENANCE.json), [MANIFEST.json](MANIFEST.json) |

Принятое направление: одна standalone TypeScript-библиотека реализует полную
операцию обновления. Потребитель подключает узкие authoritative state/grant
примитивы. Обычные TS-плагины идут первыми; Wasm/Extism и native Effect — отдельные
опциональные профили. Get Modular сохраняет composition/plan authority; данные,
авторизация и получатели эффектов остаются у продукта. Подходящий публичный
Resources/lifecycle контракт переиспользуется; private kernel не копируется.

## Проверенные результаты

| Профиль | Результат | Граница доказательства |
| --- | --- | --- |
| SystemJS 6.15.1, Node 24.22.3, TS 7.0.2, Rollup 4.68.8 | Одна попытка; **2/2**, без failures/skips | Реальное reconnect importer bindings, сохранённые старые функции/namespace, отказ удаления во время pending evaluation |
| webpack 5.113.0 containers + MF runtime 2.9.3, Chromium Headless Shell 159.0.8154.6 | **4/4**, без failures/skips; 27 запросов HTTP 200; без page errors | Новый lookup и старые ссылки, реальные ресурсы, конкретный failed-registration path, shared token/strict mismatch, повторный container init и fresh-context control |

SystemJS input был опубликован в `4a95ba3` до единственного native запуска.
Для MF сохранены локальная остановка browser setup до сценариев и первый hosted
run с успешными тестами, но неудачной отправкой артефакта. Исправленный workflow
на `44bf9c2` сохранил ZIP; frozen executable inputs и assertions не менялись.
Пять observation rows включают N4 control и означают **четыре теста**.
Поле JSON `browserExecutable` содержит API default path; фактически запущенный
headless-shell установлен из сохранённого DEBUG launch log.

Это проверка механизмов. Более широкие source-only выводы, текущие документы
поставщиков и исторические исправления отдельно обозначены в `sources.json` и
`findings.json` каждого направления. F05 о новой регистрации поверх уже loaded
singleton остаётся source-only; N3 проверяет identity и strict mismatch.
SSR/Rspack/Electron, arbitrary state migration, performance/GC, security и E2E
полной production-библиотеки не добавляются к этим результатам.

## Как соединить с предыдущим проектом

Сначала возьмите предыдущий пакет из [BASE-PACKET.json](BASE-PACKET.json).
Его точный SHA-256 —
`30ac307e967b28c341ae9d04d9863442d9aa6ea69921001f07dfb47f1483f9a7`;
он содержит 532 файла, включая architecture blueprint, seed, правила проекта,
источники и прежние native receipts. Его содержимое не изменено.

Распакуйте оба архива **в разные соседние каталоги**. Это дополнение не является
overlay: его README/MANIFEST не должны заменить одноимённые файлы предыдущего
пакета. При создании отдельного проекта перенесите новый каталог исследования
целиком, сохраните provenance и свяжите его с прежним blueprint/decision record.
Принятый FMS v1 в исходном репозитории не менялся; находящийся в прежнем пакете
FMS v1.1 bootstrap не становится принятой миграцией.

`reading-copies/` содержит тексты из коммита `52810c4`; относительные Markdown
ссылки раскрыты в ссылки на тот же immutable commit. Lane reports сохраняют
исторические paths/статусы: абсолютные scratch paths — provenance, не требование
иметь такой каталог. Статус native результата определяют terminal receipts и
финальные qualification/semantic reviews. Старые PLAN/PREPARATION намеренно
сохраняют формулировку «до запуска».

## Воспроизведение

Сначала сверяйте внешний SHA-256 архива, затем `MANIFEST.json` и hashes нужного
frozen input archive. Исходные checkpoint/input/result архивы лежат в `evidence/`.
Они не изменены при сборке дополнения. Symlink, активные workflows и node_modules
в пакет не включены.

- **SystemJS:** `delivery/probe/` содержит exact maintained inputs, lock,
  generated own fixtures, preparation logs и native receipt. Профиль использует
  Node 24.22.3 / pnpm 11.25.0 / TS 7.0.2. После frozen-lock установки с
  `--ignore-scripts` сначала сверяется dependency/compiler identity; затем
  `pnpm check`, `pnpm build`, `pnpm test`. Повторный запуск пишет новый receipt,
  прежние результаты сохраняются отдельно.
- **MF:** `federation/probe/` воспроизводит frozen v2 source; исходные input
  archive/manifest остаются authority. Точная последовательность и проверка всех
  70 installed package identities/compiler binary перед `tsc` сохранены в
  `workflow-sources/module-federation-research.yml`. Workflow находится вне
  `.github/workflows` и служит источником процедуры. Профиль использует pinned
  Playwright Chromium; установка/проверки/сборка/тесты и upload scope показаны там.
  `ci/native-hosted-v2/observations/` — exact reading copies из исходного ZIP.

Здесь нет необходимости повторять тесты для чтения результатов. При изменении
входов сначала нужен новый frozen checkpoint; новый профиль не наследует
квалификацию старого автоматически. Встроенный TS 5.9 из прежней Foundation
tooling не запускается для обхода требования TS >=7.0.2.

## Статус публикации и лицензии

Основной документ и retained native ZIP опубликованы в `52810c4`. Этот пакет
будет сохранён следующим коммитом; его собственный commit/hash не включается
рекурсивно в содержимое. Финальная проверка CI относится к отдельному точному
publication HEAD и публикуется в итоговом delivery report/PR.

Полный локальный docs protocol перед сборкой прошёл: 94 governed documents,
100 проверенных Markdown files, **8/8** contract tests, без skips. Дальнейшая
добавленная ссылка на этот пакет проверяется отдельно на publication HEAD.
Прежние native workflows/inputs сохранены по `ci/final-preparation.json`;
это carry evidence, а не повторный запуск.

Авторские материалы следуют [LICENSE](LICENSE) исходного репозитория. Лицензии
пяти retained MF/webpack packages находятся в `federation/third-party-licenses/`
и в оригинальных artifacts. SystemJS и остальные установленные зависимости
не vendored; происхождение/лицензии записаны в
`delivery/probe/THIRD-PARTY-NOTICES.json`. Generated JavaScript — выход точных
TS7/webpack/Rollup builds, не новый вручную поддерживаемый JS runtime code.
