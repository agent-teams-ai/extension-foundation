# Final synthesis draft — independent review

Observed 2026-11-22. Reviewed `root/FINAL-SYNTHESIS.md` in full, plus the current
delivery source scope and artifact-upload workflow stanza. No native tests,
repository edits or new architecture decisions were made.

## Verdict

**Confirmed: no remaining architecture or owner-choice blocker.** The single
wording correction below is resolved in the reread draft. Root subsequently
confirmed the final native receipts; the evidence addendum below records that
completion without changing any owner question or recommendation.

The draft accurately preserves the accepted complete library operation while
keeping authority, canonical state, composition and physical lifecycle ownership
with their existing owners. It does not return orchestration to every consumer,
copy a private kernel or introduce a speculative public SPI. The seams describe
concrete variations without requiring a universal adapter, new service bag or
one package per analytical stage. Reuse warnings leave a real residual application
responsibility for the new library.

All seven questions remain explicitly unadopted. Q1–Q3 concern the first
trust/update/state boundary; Q4–Q7 concern product promises. The recommendations
do not reopen canonical-state custody or accepted emergency revocation. Ordinary
interruption, runtime choice, state compatibility, retention and automatic update
eligibility remain owner choices.

## Wording correction — resolved

In the closing workflow paragraph, replace **“an always-retained artifact.”**
The workflow's `if: always()` requests upload even when preceding steps fail; it
cannot guarantee successful artifact delivery. The separately preserved first
hosted run already demonstrates that distinction.

Suggested wording: **“an artifact-upload step configured to run even after test
failure; actual delivery is verified separately.”** Keep the final successful
receipt, if obtained, as evidence for that exact run rather than a general promise.

Disposition: root changed the paragraph to state that the upload step runs even
after earlier failure and that delivery/ZIP contents require independent checks.
The reviewer reread that exact final paragraph and confirmed the correction.
The pending hosted row also distinguishes unchanged inputs/assertions from the
workflow path and browser-diagnostic changes. No additional decision was added.

## Confirmed qualifications

- SystemJS 2/2, MF local setup failure, first hosted 4/4 with failed upload, and
  corrected workflow pending are separately labelled. None is promoted into
  whole-library, desktop, SSR, containment or physical-unload E2E.
- Native observations, source findings, historical incidents and recommendations
  remain distinct. The preserved original failures are visible.
- MF factory deferral, compatible token sharing and SystemJS public rebinding
  remain useful positive mechanisms; their limits are not presented as reasons
  to replace them with custom implementations.
- The Vercel row was directly checked against current official documentation:
  top-level document navigation uses the current production deployment even with
  deployment ID/query/header/cookie. This dated living-source statement is now
  correctly scoped; no provider runtime test is claimed. Source:
  <https://vercel.com/docs/skew-protection>, browser retrieval
  `turn695408418view0`, document-navigation and request-tagging sections.

Root already plans to replace the corrected-workflow pending row with its actual
receipt and seal/link the supplement. Do not finalize the draft with a pending
row rewritten to success before that evidence exists. No further research topic,
optional native run or new abstraction is needed for this review.

## Final evidence addendum before sealing

The preceding pending-run language records the original review checkpoint.
Root has now verified the separate final receipts: Module Federation **4/4** in
run `45054452281`, source `44bf9c2`, with all 11 frozen inputs matching, and
SystemJS **2/2**. Semantic review is separately retained by root. This reviewer
did not rerun the native suites or broaden their qualified scope.

The owner-question prologue now distinguishes when the questions were formed
from when the bounded mechanisms were confirmed. All seven questions, their
alternatives and recommendations remain unchanged and **OPEN**. No additional
research, implementation choice or approval is implied by these passing receipts.
