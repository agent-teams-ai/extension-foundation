# Independent architecture synthesis and decision boundary

Observed 2026-11-22. Reviewer: `/root/architecture_decisions`. This is an independent
review of the four source lanes and accepted repository direction, **not runtime
execution, production adoption or approval of an owner choice**. Reviewed source
snapshots are recorded in `INPUTS.json`. The sibling native probes were pending
at this review's start; their later results must retain their own profiles and
receipts rather than being inferred here.

## 1. Recommendation for discussion

Keep **one complete reusable update operation** and qualify concrete execution,
presentation and delivery profiles around it. Choose those profiles from the
promised behavior and first consumer, not from a technology popularity ranking.
Module Federation, SystemJS, Wasm/Extism and native Effect are not one list of
interchangeable replacements: they cover partly different responsibilities.

The library's value is coordinating truthful application transitions across
existing mechanisms. It should not own another module resolver, shared dependency
solver, virtual DOM, state authority, resource supervisor or distributed lock.
The four lanes provide enough evidence to identify those responsibility seams,
but not to freeze their final public TypeScript interfaces or guarantee that no
future refactoring will be needed.

This distinction also resolves a wording risk in the Federation report. A single
semantic owner does **not** mean that every consumer rebuilds orchestration.
The accepted direction puts reusable operation implementation in the standalone
library. The product supplies operational authority, grants and canonical-state
primitives. Existing lifecycle mechanisms keep their transitions and physical
custody responsibilities. A private, unavailable kernel must not be copied or
deep-imported; its publication/availability is an explicit integration gate, not
permission for another hidden coordinator. [A1, A2, A3]

## 2. What is fixed, what is evidence, what is still a decision

| Category | Current scope | Consequence |
| --- | --- | --- |
| Owner-confirmed direction | Standalone purpose-neutral TS-first library; ordinary TS plugins; optional Wasm/Extism and native Effect profiles; complete update operation | Do not reopen this as a choice between a small product-local script and a library. |
| Accepted ownership | Get Modular neutral composition; product authorization/state/effect authority; applicable existing lifecycle/resource owners | Reuse through their supported boundary. A new loader must not become a second active-head or permission authority. |
| Existing safety requirements | No extension callbacks inside product transactions; grants are not manifest requests; resource cleanup releases only owned resources; user-data deletion is distinct from plugin removal | These are not owner-preference questions for this research to relax. |
| Source facts | Registry, export, shared instance, document, physical executor and durable state have different lifetimes | Architecture must preserve relevant distinctions, without creating one interface/package for each noun. |
| Open product policy | Trust profile, replaceable unit, state continuity, ordinary interruption, UI adoption, rollback meaning and supported old-client window | Present alternatives. A preferred option remains unadopted. |
| Future implementation choice | Which exact runtime/bundler/provider/adapters implement a selected profile | Qualify after the requirement is concrete. Current-source inspection and an upstream-loader probe are insufficient production evidence. |

For this repository, the accepted FMS profile is still v1 and pre-production.
The organization's maintained quality standard is guidance, not authority to
silently migrate that pin. A future standalone repository needs its own recorded
adoption scope. Do not create empty packages to make the proposed architecture
look implemented. [A2, A4]

The stronger independent-implementation floor for publishing an Extension
Foundation public extension SPI must not be indiscriminately imposed on every
ordinary library experiment. Conversely, ordinary-package qualification is not
evidence that the public extension SPI or every production host is approved.
These gates have different owners and claims. [A1]

## 3. Seams with a concrete reason to exist

These are responsibility boundaries and acceptance questions, not API names.

| Boundary | Concrete alternative that justifies it | Fitness question for the first real consumer |
| --- | --- | --- |
| Inert declaration/plan vs executable preparation | Static TS import table, Federation entry, SystemJS module or Wasm artifact | Can preview/rejection inspect the candidate without executing unselected code? If preparation executes it, which effects are actually permitted? |
| Composition vs runtime compatibility evidence | The existing Get Modular plan plus actual shared provider/token, state and physical-executor constraints | Does changing one provider expand the affected group when a consumer retains incompatible identity, without creating a second graph authority? |
| Loader identity vs selected application generation | MF forced registration, native URL/module-map identity and SystemJS importer rebinding differ | Can adapter failure change its registry while the operation still reports the exact old selection, retained work and recovery requirement? |
| Operation admission vs later invocation/continuation | Direct TS call, stream, callback, worker request or UI command | Does one operation retain a compatible provider/dependency set when selection changes midway? |
| Durable feature data vs replaceable view/runtime state | Stable draft/state owner, framework state retention, explicit checkpoint or reset | Can a panel remount without losing the promised draft, and can unsupported Undo/effect history be identified before claiming preservation? |
| New admission vs old-generation retirement | Parallel compatible work, exclusive resource handover, cooperative cancellation or isolated termination | Can the report distinguish a cancellation request, bounded remaining work, exact physical exit path and persisted state? |
| Application adoption vs delivery convergence | Per-tab release, service-worker controller, CDN assets and desktop host bridge | Can a delayed old lazy load and an unresponsive tab still be handled within the declared support window? |
| User outcome vs loader/framework success | Loaded, mounted, useful changed behavior, fallback and cleanup debt | Does the selected user task work under the intended revision while its focus/draft/accessibility promise remains true? |

The new research supports these questions through specific mechanisms: MF's
destructive alias-validation path and factory deferral; useful JupyterLab token
sharing; public SystemJS rebinding; Electron's shutdown/message receipt distinction;
Angular's per-client asset version and recovery limits; and Envoy's acknowledgement
versus readiness. Each fact retains the lane's source classification. [F, D, E, R]

### A stable facade needs an operation boundary

Electron function delegation and shared service contracts make a stable facade a
credible option. But a facade that resolves `current` independently on every
internal call can split one business operation across A and B. Where the operation
requires consistency, admission and lifetime acquisition must preserve the same
compatible implementation context through callbacks and stream consumption.
This is already covered by the reuse-first operation/lifetime guidance; a new
ambient global registry would duplicate and weaken that ownership. It is a
qualification scenario, not a newly selected universal invocation protocol.
[E §3–4; A3 W07/W17 and immutable operation context]

### Preparation is not always side-effect-free or parallel

MF can defer an exposed factory, but entry/init/get can still execute. Same-realm
TS preparation therefore needs a truthful cooperative contract or a stronger
qualified boundary; a method named `prepare` provides neither. Some exclusive
resources also prevent two fully ready generations from coexisting. The operation
must be able to describe the required handover/interruption rather than always
pretending to offer a two-phase transaction. Do not infer this from the loader's
promise resolution. [F §3; E §5–6; A3 state/resource table]

### State survival is a compatibility promise

Keep canonical data with its existing owner. A feature-owned long-lived state
component is possible; this does not require a single global Host store. The
open question is what transient state survives, through which supported adapter,
and what an incompatible change does. Copying a snapshot at an arbitrary instant,
reusing an old object or serializing a history is insufficient without its
semantics. Prior editor evidence already distinguishes text Undo from custom
effect history. A deployment-generation rollback also cannot roll back arbitrary
external effects or silently discard later user changes. [A1 state custody;
A3 W13/W17/W21; prior reliability study]

### Coexistence has a resource budget

Retained generations, failed candidates, pending creation and delayed cleanup
all consume capacity. A design that safely retains A while B serves is incomplete
if repeated updates can accumulate unbounded executors/assets/subscriptions.
Use existing admission/retention owners to expose actual remaining holds and
the chosen limits. Unknown escaped references are not solved by a library
reference counter: narrow the guaranteed scope, expand the restart unit or
report unsupported replacement. The values and escalation policy remain open.
[A3 W04/W06/W08/W16/W17; E pending-launch findings; D/R retention]

## 4. Concrete Clean Architecture, SOLID and DRY consequences

**Application responsibility.** The library coordinates the complete update
operation once. Product callbacks supply narrow decisions or state primitives,
not an undocumented sequence the consumer must assemble correctly. Runtime and
delivery SDK types remain in adapters. Composition selects implementations;
it does not become a large manager that owns every feature's state and policy.

**Substitution.** A same-realm loader, process host and Wasm SDK cannot silently
implement an identical “stop/unload” promise with different meanings. Qualify
the operation's required guarantee and represent unsupported behavior explicitly.
Prefer the concrete capability boundary demonstrated by a real profile over a
large bag of Boolean flags or a universal interface with no-op methods.

**Feature ownership.** Group code by a cohesive changed responsibility: executing
the update use case, adapting a real runtime, translating a selected artifact
contract, or supporting a framework's state lifecycle. Do not make packages
solely because the analytical model lists several stages. Public boundaries
need real consumers and appropriate conformance before they become stable APIs.

**One source of rules.** Do not duplicate semver resolution, Get Modular identities,
plan digests, lifecycle transitions, canonical head advancement, schema authority
or resource ownership. Runtime observations may enrich a product's compatibility
decision; they must not quietly become a second mutable composition graph.
Avoid forcing serialized messages between ordinary direct TS providers merely
to anticipate Wasm. A language-neutral contract is justified at an actual
selected cross-language boundary. [A2; A3 W03/W06/W10/W11/W12/W15/W17]

**External consumers.** A portable operation must be usable without Agent Teams
catalog credentials or a mandatory organization's deployment stack. Applicable
Extension Foundation profiles retain their OCI/grant/custody rules; that does
not mean the neutral library must implement another marketplace or require the
same backend from every external consumer. Keep optional policy/admission
integration separate from the portable mechanism. [A1; A2 universal tooling]

## 5. Where to reject accidental duplicate mechanisms

| Proposed custom work | Existing owner/mechanism to inspect first | Demonstrated residual responsibility |
| --- | --- | --- |
| Dynamic imports, shared ranges and chunk cache | Native loader, exact MF profile or SystemJS | Translate truthful loading/evaluation evidence into the operation. |
| Compute restart group | Get Modular topology plus product lifecycle/import/state constraints | Decide compatibility at declared boundaries; record unknown edges. |
| Cleanup stack or concurrent generation counter | Qualified Resources or native Effect scope; existing executor owner | Coordinate one owner's receipts; preserve borrowed ownership. |
| Durable update/saga database | Product operation and canonical-state owner, existing selected workflow mechanism | Portable driver that advances only through the owner's primitives. |
| Deployment selector lock | Canonical authority/provider conditional write; fitting publisher | Bind the selected artifact closure and report conflicts/adoption. |
| Framework or style reset | Framework lifecycle, scoped registry, stylesheet/subtree ownership | State/visibility qualification for that concrete host. |
| Service-worker update notifier | Existing Workbox/host service-worker integration | Explain actual per-client adoption and expiration policy. |
| Desktop/native updater | Electron/Node/platform mechanisms and qualified artifact path | Bridge/native compatibility and observed state/exit requirements. |
| Generic protocol and serializer | Existing transport/codecs chosen for a real boundary | Map consumer-owned semantic ports and validate limits. |

Each new production mechanism should answer “which existing owner lacks what
specific guarantee?” This is a review question, not another mandatory workflow
or approval system. [A2; A3; four lane reports]

## 6. Decisions and evidence sequence

`OWNER-QUESTIONS.md` offers seven unadopted questions. Q1–Q3 determine the initial
trust/update/state boundary. Q4–Q7 determine product promises about adoption,
active work, recovery and old clients. Technology selection comes afterward.

Do not try to qualify browser, SSR, Electron, native devices, offline updates and
hostile UI all in the first slice. Pick the real consumer that demonstrates the
library's complete operation and one independently authored consumer/conformance
path appropriate to the boundary being published. Additional profiles have named
qualification gaps rather than placeholder implementations.

The native MF and SystemJS probes can settle specific mechanism uncertainty.
They cannot settle user policy, prove UI usefulness, full resource reclamation,
cross-tab delivery, privileged-code containment or whole-library E2E. Their
passing status is not assumed here. [F native plan; D QUALIFICATION; A2 evidence]

No reliable total production LOC estimate follows from these source boundaries:
the consumer, promised state, delivery topology and supported runtimes remain
open. The measured probe LOC belong to disposable fixtures, not the complete
library. Likewise there is no defensible universal reliability score for an
unspecified profile. Confidence is **high (8/10)** in the responsibility separation,
**medium (6/10)** in the conditional first-profile recommendations, and **unrated**
for production reliability. These are engineering judgments, not availability
measurements. Concrete implementation estimates belong to the chosen first slice.

## References and authority

- **A1:** `extension-foundation/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md`, fixed constraints and November 18/21/22 owner records; the latest research explicitly leaves contested choices open.
- **A2:** [organization Engineering Quality Standard at reviewed pin](https://github.com/agent-teams-ai/.github/blob/0b44c64c824f536bd1b085341e7669bcc64ef124/docs/engineering-quality-standard.md), especially library-first design, language/runtime boundaries, Clean Architecture, SOLID, DRY and evidence. Read in full for this review.
- **A3:** `extension-foundation/docs/research/reuse-first-live-plugin-updates-2026-11-22.md`, W01–W24, operation context and state/resource ownership.
- **A4:** `extension-foundation/docs/architecture/feature-module-standard-profile.md`, accepted FMS v1 identity and pre-production/no-conformance state.
- **F:** `../federation/REPORT.md`, `findings.json`, `sources.json`, including MF 2.9.3 / webpack 5.113.0 and JupyterLab source classes.
- **D:** `../delivery/REPORT.md`, `findings.json`, `sources.json`, `QUALIFICATION.md`, including actual SystemJS primitive, delivery affinities and browser lifecycle scope.
- **E:** `../desktop/REPORT.md`, `findings.json`, `sources.json`, including exact Electron 45.4.1 source and original/backport lineage.
- **R:** `../root/REPORT.md`, `findings.json`, `sources.json`, including Envoy 1.40.2, Angular 22.3.0 and living Unreal documentation.

Existing sources were reviewed as supplied source evidence; this review did not
independently reproduce their deployed runtime behavior or add new native results.
