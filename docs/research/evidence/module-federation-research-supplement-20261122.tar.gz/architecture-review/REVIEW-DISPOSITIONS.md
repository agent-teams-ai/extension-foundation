# Architecture review dispositions

2026-11-22. Proposed corrections for root synthesis; no files owned by another
lane were edited. None of these dispositions resolves an owner choice or changes
accepted authority. Source input hashes are in `INPUTS.json`.

| ID | Finding | Suggested disposition | Why it matters |
| --- | --- | --- | --- |
| AR-01 | “Existing kernel/coordinator remains the single semantic owner” can be read as keeping the full algorithm in each product. | Clarify one library implementation of the complete operation, product authority/state, and reused lifecycle ownership. Private kernel availability stays explicit; no copying/deep import. | Preserves accepted standalone/library-first direction without a second coordinator. |
| AR-02 | A list containing MF, SystemJS, Extism and Effect looks like a runtime bake-off. | Explain which responsibility/profile each addresses; ask for required guarantees before selecting a concrete implementation. | Prevents choosing complementary technologies as if they were interchangeable. |
| AR-03 | “Stable bridge/shared contract” can hide mixed-generation calls within one operation. | Preserve qualified operation context across dependent calls, callbacks and stream consumption; do not add ambient per-call `getCurrent()`. | Stable API shape alone does not establish consistent execution or resource lifetime. |
| AR-04 | Per-component replacement can quietly ignore imported/shared/retained identity. | Name a minimum compatible group using existing composition plus actual runtime/state/resource constraints; broaden or reject unknown scopes. | Avoids a second graph compiler and unsupported fine-grained promises. |
| AR-05 | A generic prepare method can imply pure loading and parallel readiness. | State evaluation/authority effects and exclusive-resource restrictions per profile; preserve positive factory deferral without calling earlier stages inert. | Real ready mechanisms have narrower promises than a universal two-phase transaction. |
| AR-06 | State-custody alternatives could reopen already fixed canonical product-state ownership. | Ask what transient continuity is promised, with feature-owned stable state and explicit codecs/checkpoints; do not ask to move canonical product state into the library. | Keeps owner questions within actual unresolved scope. |
| AR-07 | A broad cleanup/exit status can overstate physical termination or final-state persistence. | Keep exact adapter path and receipt level; retained resources, pending creation, browser-shutdown wrapper exit and acknowledged state remain distinct. | Source review demonstrates event-name ambiguity. |
| AR-08 | Preserving every predecessor can look safe while creating unbounded accumulation. | Include actual retained holds/capacity and an explicit policy boundary in the first selected profile. Do not invent a new counter/journal. | Update correctness needs bounded admission and an honest blocked/degraded result. |
| AR-09 | “Per-session pinning” and successful selector publication can imply coherent adoption across tabs. | Distinguish per-tab, shared-cookie, document and fleet guarantees; a cache is not a retention promise. | Keeps older clients and delayed dependencies within a real support contract. |
| AR-10 | Reuse of published framework code can be mistaken for architectural acceptance. | Separate source fact, exact native probe, first-consumer E2E and public/production qualification. | A successful loader probe cannot choose interruption, state migration or runtime policy. |
| AR-11 | Forward readiness can be interpreted as creating all adapter interfaces/packages now. | Keep a responsibility/qualification matrix; materialize the first cohesive features only after a consumer proves the boundary. | Avoids speculative abstractions and preserves FMS/DRY. |
| AR-12 | Applying the strongest public-SPI floor to every experiment can stall authorized work; applying a weaker package gate to the SPI can overclaim. | Name the exact gate and surface. Do not conflate ordinary library, production host and public extension SPI. | Maintains proportional work and truthful adoption. |

## Positive evidence to preserve

- Federation is useful for actual dependency identity and independently built delivery; its limits do not justify replacing its resolver.
- SystemJS supplies an intentional public rebinding primitive; retained old values do not invalidate that positive result.
- Angular offers application-version coherence and client assignments; its recovery limits refine the retention promise rather than discrediting the mechanism.
- Envoy's readiness and process-handover machinery is reusable experience even though ACK and physical connection migration have different scopes.
- Electron function delegation, process/port primitives and supported updater are credible reuse options. Their lifecycle distinctions argue for precise adapters, not another host platform.

## Parent integration guidance

The final user response should prioritize the surprising verified findings and
seven or fewer owner questions. Put detailed per-platform subquestions and raw
sources in the preserved report. Keep proposals explicitly unadopted. Avoid a
generic “everything is possible behind an adapter” conclusion: each supported
profile needs a concrete guarantee, an implementation and its own evidence.

No new permission request is necessary to preserve this research. Root owns
checkpoint commits/pushes and the final synthesis. This reviewer ran no tests,
changed no repository state and selected no production mechanism.
