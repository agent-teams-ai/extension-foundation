# V2 portability-only amendment

Root approved preparing this change after v1's browser bootstrap was denied by
the local OS. V1 compiler/check/build succeeded; no scenario ran. No local
Chromium retry is authorized or attempted.

The only executable input change is `probe/probe.test.ts`: read optional
`MF_RESEARCH_CHROMIUM`; pass `executablePath` only when provided; otherwise use
the browser installed by pinned `playwright@1.65.1`. Record the selected path in
the existing native receipt. Tests, oracles, fixture modules, generated bundler
configuration, dependencies, compiler options and lock are unchanged.

Root owns the separate scoped hosted workflow, frozen archive, push and exact
workflow/run provenance. Intended environment: Node24.22.3, pnpm11.25.0,
TypeScript7.0.2, Playwright-managed Chromium; check -> build -> pinned browser
installation -> tests. Preserve terminal logs, statuses and observations even
on failure. V2 requires a new pushed input checkpoint before execution.

The change does not establish cross-browser support or add an execution
profile to the production library. `frozen-inputs-v2.json` records exact input
hashes and the diff from v1. A version/check/build or hosted attempt that changes
inputs must be retained and reviewed before any further rerun.
