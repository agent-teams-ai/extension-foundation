# Independent semantic review of retained browser evidence

Reviewer: `/root/mf_runtime`, 2026-11-22. This review reads the real retained
artifact and the frozen sources; it runs no additional browser or test matrix.

**PASS: four declared native tests, zero failures, zero skips.** Run
[45054452281](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45054452281),
job 137306490663, pushed head `44bf9c21fe55a048d6f942411695a4fd74dede67`.
All eleven frozen executable/configuration/audit input hashes matched v2.
There are five observation records because the fresh-context positive control
belongs to N4; it is not a fifth test. Every recorded HTTP request returned 200
and no unhandled page error occurred.

## What was actually observed

| Case | Observed result | Stronger claim this does not establish |
|---|---|---|
| N1: force A→B, retained A, deferral | New lookup returned B while retained A still returned A. B's module body recorded the application publication marker as A. A's listener count moved 1→2 after replacement and stayed 2 after explicit cleanup. Deferred C had completed init/get observation without evaluating its exposed body; invoking its returned factory then evaluated C. | Automatic cleanup, reference rewriting, arbitrary side-effect-free preparation, or physical memory reclamation. |
| N2: one invalid-alias force path | Registration failed on the conflicting alias; subsequent public lookup reported RUNTIME-004 and diagnostics retained only the unrelated peer. A's escaped callable/listener still worked. Explicit cleanup stopped the listener; public re-registration restored A lookup. | A guarantee about every error path, automatic rollback, or restored external application state. |
| N3: shared token and strict mismatch | The host provider was selected first; the generated compatible consumer received the exact host token object. Only 1.0.0 was registered. The generated no-fallback consumer requiring ^2.0.0 failed with the native singleton version error; the compatible consumer remained usable. Both remote entries and expose chunks were fetched successfully. | JupyterLab/Lumino integration, application protocol/state compatibility, or the behavior of non-strict/non-singleton fallbacks. |
| N4: two runtime objects, one actual container | Runtime objects and real default scope objects differed. The captured container object stayed identical and its entry was requested once. The second initialization failed with RUNTIME-015 whose cause was the generated different-share-scope guard. The first reference still worked. A fresh browser context loaded A successfully. | General realm isolation by `createInstance`, a defect in the guard, or replacement of native/desktop host contracts. |

N2 additionally recorded two A entry requests but only one A expose-chunk
request during explicit recovery. This is a useful diagnostic showing that
the tested registration/entry and chunk layers did not have identical network
lifetimes. It is not a reproduced version of the historical cached-chunk issue
or a proof that all loader caches were or were not cleared.

## Actual execution profile

Node 24.22.3; pnpm 11.25.0; actual compiler 7.0.2; strict checking with
`skipLibCheck:false`; webpack 5.113.0 built-in generated containers; published
MF runtime 2.9.3; Playwright 1.65.1. N3's provider uses the released runtime's
public `shared.lib`; its consumers use actual generated webpack shared
consumption with `import:false`, singleton and strictVersion enabled.

Live `browser.version()` returned 159.0.8154.6. DEBUG launch evidence names
`chromium_headless_shell-1255/chrome-headless-shell-linux64/chrome-headless-shell`.
The native JSON's `browserExecutable` instead contains the full-Chromium
default returned by `chromium.executablePath()`. It is an API default path,
not the observed launched binary; the separate launch log resolves that
distinction. The JSON is retained unchanged, with this explicit qualification.

## Attempt integrity

V1's local strict check/build passed, but its browser setup failed before any
semantic case. The first hosted v2 run passed four tests but failed artifact
upload; it does not supply the detailed JSON reviewed here. The corrected
workflow changed artifact path normalization and launch logging, leaving the
frozen native inputs and assertions unchanged. Its retained JSON, request and
console traces, terminal assertion status and provenance are the evidence for
this review. No earlier failures are erased and the second hosted run does not
double the coverage count.

This is a successful browser mechanism spike, not the standalone library's
production end-to-end qualification. Rspack, enhanced bundler integration,
SSR, Electron, security, time-bounded stop, state migration, GC and performance
remain outside its evidence. Detailed hashes and observer counts are recorded
in `NATIVE-SEMANTIC-REVIEW.json`.
