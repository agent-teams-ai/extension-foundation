import {
  createInstance,
  type ModuleFederationRuntimePlugin,
} from "@module-federation/runtime";
import type {
  CaseId,
  Observation,
  RemoteProbe,
  ServiceToken,
  TokenModule,
} from "./types.js";

window.probeState = {
  published: null,
  evaluations: [],
  responses: {},
  stages: [],
};

function remote(name: string, variant: string) {
  return {
    name,
    entry: new URL(`/${variant}/remoteEntry.js`, window.location.href).href,
    entryGlobalName: `fixture_${variant}`,
  };
}

const observer: ModuleFederationRuntimePlugin = {
  name: "fixture-read-only-observer",
  afterInitRemote({ remoteInfo, error }) {
    window.probeState.stages.push(`init:${remoteInfo.name}:${Boolean(error)}`);
  },
  afterGetExpose({ moduleInfo, error }) {
    window.probeState.stages.push(`get:${moduleInfo.name}:${Boolean(error)}`);
  },
};

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

async function captureError(operation: () => unknown): Promise<string> {
  try {
    await operation();
    return "NO_ERROR";
  } catch (error) {
    return errorText(error);
  }
}

function requireProbe(value: RemoteProbe | null): RemoteProbe {
  if (value === null || typeof value.read !== "function") {
    throw new Error("Generated fixture probe was not returned");
  }
  return value;
}

function tick(): void {
  window.dispatchEvent(new Event("fixture-tick"));
}

async function retainedAndDeferred(): Promise<Observation> {
  const mf = createInstance({
    name: "host_N1",
    shareStrategy: "loaded-first",
    plugins: [observer],
    remotes: [remote("target", "a"), remote("deferred", "c")],
  });
  const old = requireProbe(await mf.loadRemote<RemoteProbe>("target/probe"));
  old.start();
  tick();
  const listenerBefore = window.probeState.responses["A"] ?? 0;
  window.probeState.published = "A";
  mf.registerRemotes([remote("target", "b")], { force: true });
  const next = requireProbe(await mf.loadRemote<RemoteProbe>("target/probe"));
  const publishedAfterLoad = window.probeState.published;
  window.probeState.published = "B";
  tick();
  const listenerAfterReplacement = window.probeState.responses["A"] ?? 0;
  old.stop();
  tick();
  const listenerAfterCleanup = window.probeState.responses["A"] ?? 0;

  const deferredFactory = await mf.loadRemote<() => RemoteProbe>(
    "deferred/probe",
    { loadFactory: false, from: "runtime" },
  );
  if (typeof deferredFactory !== "function") {
    throw new Error("Public factory-deferral call did not return a function");
  }
  const cBeforeCall = window.probeState.evaluations.some(
    ({ generation }) => generation === "C",
  );
  const deferredInit = window.probeState.stages.includes("init:deferred:false");
  const deferredGet = window.probeState.stages.includes("get:deferred:false");
  const deferred = deferredFactory();
  return {
    retainedA: old.read(),
    newLookup: next.read(),
    distinctExports: old !== next,
    publishedAfterLoad: publishedAfterLoad ?? "none",
    evaluations: window.probeState.evaluations.map(
      ({ generation, published }) => `${generation}:${published ?? "none"}`,
    ),
    listenerBefore,
    listenerAfterReplacement,
    listenerAfterCleanup,
    deferredFactoryUnexecutedBeforeCall: !cBeforeCall,
    deferredInit,
    deferredGet,
    deferredAfterManualCall: deferred.read(),
  };
}

async function destructiveValidation(): Promise<Observation> {
  const mf = createInstance({
    name: "host_N2",
    shareStrategy: "loaded-first",
    remotes: [remote("replaceTarget", "a"), remote("occupied/sub", "c")],
  });
  const old = requireProbe(await mf.loadRemote<RemoteProbe>("replaceTarget/probe"));
  old.start();
  tick();
  const registrationError = await captureError(() =>
    mf.registerRemotes(
      [{ ...remote("replaceTarget", "b"), alias: "occupied" }],
      { force: true },
    ),
  );
  const lookupError = await captureError(() => mf.loadRemote("replaceTarget/probe"));
  tick();
  const namesAfterFailure = mf.options.remotes.map(({ name }) => name);
  const listenerAfterFailure = window.probeState.responses["A"] ?? 0;
  old.stop();
  tick();
  const listenerAfterCleanup = window.probeState.responses["A"] ?? 0;
  mf.registerRemotes([remote("replaceTarget", "a")]);
  const restored = requireProbe(await mf.loadRemote<RemoteProbe>("replaceTarget/probe"));
  return {
    registrationError,
    lookupError,
    retainedA: old.read(),
    namesAfterFailure,
    listenerAfterFailure,
    listenerAfterCleanup,
    explicitReregistration: restored.read(),
  };
}

async function singletonIdentity(): Promise<Observation> {
  const hostToken: ServiceToken = { id: "host-contract-token" };
  const mf = createInstance({
    name: "host_N3",
    shareStrategy: "loaded-first",
    remotes: [remote("compatible", "compatible"), remote("strict", "strict")],
    shared: {
      "service-token": {
        version: "1.0.0",
        lib: () => ({ token: hostToken }),
        shareConfig: { singleton: true, strictVersion: true, requiredVersion: "^1.0.0" },
      },
    },
  });
  const selected = await mf.loadShare<TokenModule>("service-token");
  if (!selected) throw new Error("Host shared provider was not selected");
  const selectedValue = selected();
  const compatible = await mf.loadRemote<TokenModule>("compatible/token");
  if (compatible === null) throw new Error("Compatible generated consumer missing");
  const incompatibleError = await captureError(() => mf.loadRemote("strict/token"));
  return {
    providerSelectedBeforeConsumer: selectedValue?.token === hostToken,
    compatibleTokenIsHost: compatible.token === hostToken,
    compatibleTokenId: compatible.token.id,
    providerVersions: Object.keys(mf.shareScopeMap["default"]?.["service-token"] ?? {}),
    incompatibleError,
    compatibleStillWorks: compatible.token === hostToken,
    incompatibleEntryPresent: Reflect.get(window, "fixture_strict") !== undefined,
  };
}

async function scopeIdentity(controlOnly = false): Promise<Observation> {
  const first = createInstance({
    name: "host_N4_first",
    shareStrategy: "loaded-first",
    remotes: [remote("same", "a")],
  });
  const old = requireProbe(await first.loadRemote<RemoteProbe>("same/probe"));
  const firstContainer: unknown = Reflect.get(window, "fixture_a");
  if (controlOnly) return { firstResult: old.read(), containerPresent: Boolean(firstContainer) };
  const second = createInstance({
    name: "host_N4_second",
    shareStrategy: "loaded-first",
    remotes: [remote("same", "a")],
  });
  const secondError = await captureError(() => second.loadRemote("same/probe"));
  const firstScope = first.shareScopeMap["default"];
  const secondScope = second.shareScopeMap["default"];
  return {
    instancesDiffer: first !== second,
    bothScopesExist: firstScope !== undefined && secondScope !== undefined,
    scopesDiffer: firstScope !== secondScope,
    sameContainer: firstContainer === Reflect.get(window, "fixture_a"),
    firstStillWorks: old.read(),
    secondError,
  };
}

const cases: Record<CaseId, () => Promise<Observation>> = {
  N1: retainedAndDeferred,
  N2: destructiveValidation,
  N3: singletonIdentity,
  N4: () => scopeIdentity(),
  control: () => scopeIdentity(true),
};
window.probeAPI = { run: (id) => cases[id]() };
