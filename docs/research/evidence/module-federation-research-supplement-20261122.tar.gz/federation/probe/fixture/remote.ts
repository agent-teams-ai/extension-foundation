import type {} from "./types.js";

declare const __GENERATION__: string;

export const version = __GENERATION__;
window.probeState.evaluations.push({
  generation: version,
  published: window.probeState.published,
});

const listener = (): void => {
  window.probeState.responses[version] =
    (window.probeState.responses[version] ?? 0) + 1;
};

export function read(): string {
  return version;
}

export function start(): void {
  window.addEventListener("fixture-tick", listener);
}

export function stop(): void {
  window.removeEventListener("fixture-tick", listener);
}
