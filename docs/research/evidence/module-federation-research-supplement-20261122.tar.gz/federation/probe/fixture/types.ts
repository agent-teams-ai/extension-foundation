export interface RemoteProbe {
  version: string;
  read(): string;
  start(): void;
  stop(): void;
}

export interface ServiceToken {
  id: string;
}

export interface TokenModule {
  token: ServiceToken;
}

export type Observation = Record<string, string | boolean | number | string[]>;
export type CaseId = "N1" | "N2" | "N3" | "N4" | "control";

declare global {
  interface Window {
    probeState: {
      published: string | null;
      evaluations: Array<{ generation: string; published: string | null }>;
      responses: Record<string, number>;
      stages: string[];
    };
    probeAPI: { run(id: CaseId): Promise<Observation> };
  }
}
