# Disposable native Module Federation qualification

This is a research fixture, **not the production library or its end-to-end suite**.
It qualifies one browser interoperability profile: webpack 5.113.0 built-in
generated script containers, `@module-federation/runtime` 2.9.3, a host provider
registered through public `shared.lib`, and Chromium.

Maintained source is 520 lines of strict TypeScript. TypeScript 7.0.2 emits it;
webpack consumes generated JavaScript and produces genuine remote containers and
shared-consumption runtimes. No handwritten container, custom loader, HMR service,
private shared-registry mutation or generic lifecycle coordinator is present.

The parent research `PLAN.md` contains reviewed questions, positive controls and
scope limits. `dependency-audit.json` records the lock and static compiler audit.
The parent must push the applicable frozen input manifest and its inputs before execution.

After that checkpoint, the intended commands are:

```sh
pnpm exec tsc --version
pnpm run check
pnpm run build
pnpm run test
```

Installation uses `pnpm install --ignore-scripts --frozen-lockfile`. V2 uses the
Chromium managed by the pinned Playwright package unless `MF_RESEARCH_CHROMIUM`
explicitly selects an executable. The local v1 attempt at `/usr/bin/chromium`
was blocked before scenarios; it is retained and is not retried locally. The
selected path and observed browser version are recorded by the actual run.
Generated output lives in `.build/` and `dist/`.
`results/build.json` records output hashes; `results/native.json` records native
observations, errors, requests and browser identity. Original failed attempts
must be retained before fixing/retrying. A changed input set needs another
frozen checkpoint before the new run.

Cases: A/B replacement with retained A and explicit resource cleanup; factory
deferral as a positive control; the exact invalid-alias forced replacement path;
compatible token identity and strict incompatible consumer; separate runtime
objects targeting an already-initialized container, with fresh-context control.
Results do not qualify Rspack, enhanced bundler integration, SSR, Electron,
security isolation, GC, state migration, production availability or performance.
