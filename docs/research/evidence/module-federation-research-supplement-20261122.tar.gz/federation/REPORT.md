# Module Federation: what can be reused, and what the application still owns

2026-11-22. **Retained hosted native qualification: 4/4 passed, zero failures/skips.** Source research and the reviewed browser fixture remain distinct evidence classes. The original local browser setup failure and first hosted artifact-delivery failure are preserved. Production code and public API changes: **0**. No runtime or contested policy is adopted. Source IDs refer to `sources.json`; per-finding status is in `findings.json`, and receipts/review are in `QUALIFICATION.md` and `NATIVE-SEMANTIC-REVIEW.md`.

## Main result

Module Federation is a substantial ready-made mechanism for independent builds, module delivery and shared dependency negotiation. Its sharing semantics also solve real correctness problems: JupyterLab providers and consumers must import the same service-token object. Reimplementing this machinery would add avoidable work. Controlled application replacement still needs a distinct owner for selected generation, execution authority, resource retirement, state compatibility and user-visible completion. The inspected runtime APIs do not combine those responsibilities into the accepted library's full update operation. [MF-S03–S10, MF-S17–S20]

The new architectural issue is not merely that caches exist. **A candidate can execute before publication; a failed forced registration can already have removed the old lookup; an existing shared singleton can constrain which dependency generation is usable; and a new runtime object can still target a container initialized against another scope object.** Each changes what a truthful prepare/publish/retire operation can promise. Native qualification below is deliberately bounded to those uncertainties.

## 1. Name the exact family and profile

| Mechanism | Verified baseline | What it supplies | Qualification limit |
|---|---|---|---|
| webpack built-in ModuleFederationPlugin | webpack 5.113.0, commit `e9f0c9b25456ae5d80739ba7f498ae5b623ca194` | Generated container `get/init`, shared provider/consumer runtime, chunk graph | Its generated runtime is not the MF2 runtime-core implementation. |
| MF enhanced/runtime family | 2.9.3, commit `40688424f13ea9d4338b9a0cf230e8f1ac4d3835` | Runtime instances, dynamic registration, manifest handling, hooks, sharing strategies; enhanced adds build/declaration integrations | A successful browser profile does not qualify Node, all bundlers, or framework bridges. |
| Rspack built-in plugin | npm `@rspack/core` 2.3.3; current official plugin guide | Documented MF1.5 integration with runtime-tools; its peer range also permits runtime-tools2.x. Separate V1 and enhanced integrations exist. | “MF1.5” is an integration-family label, not the installed runtime-tools package version. |
| JupyterLab consumer | 4.6.6, commit `8d57791d0254820dfa4a540e010105803e128bcd` | Prebuilt extensions, shared service contracts, plugin activation | Current release documents Rspack; startup extension loading does not demonstrate live retirement. |

Registry metadata and release identities were checked on 2026-11-22 and retained locally. Search-index release snippets lagged the live release/registry checks, so they were not used as the version authority. The old MF verdict remains historical and non-operative. [MF-S01, S02, S09, S14, S16; `registry-latest.json`]

**An important real-consumer qualification:** JupyterLab4.6.6's own lock pins `@jupyter/builder1.0.0-beta.1`, Rspack2.0.2 and runtime-tools2.4.0. The published beta builder uses the default Rspack MF plugin. Separately, the current builder1.3.0 source and published distribution deliberately select `ModuleFederationPluginV1`; its maintainers explain that warning and using the host's version preserves their desired extension compatibility when a non-singleton dependency has no bundled fallback and no satisfying version. That rationale is upstream evidence, not a native reproduction here. It demonstrates why the exact producer profile and fallback policy matter; “JupyterLab uses federation” does not qualify our chosen fixture or justify automatically adopting MF2 or V1. [MF-S27–S30; builder distribution provenance files]

## 2. Separate six identities

| Identity | Evidence | Why it affects replacement |
|---|---|---|
| Remote registration/alias | MF runtime maps request prefixes to remote metadata. | Repointing affects later resolution, not every retained export. |
| Entry global/container object | A script container exposes `get/init`. | A new URL or runtime instance can still encounter the same global container. |
| webpack `output.uniqueName` / chunk global | Build runtimes use it for chunk identity and provider tie-breaking. | Entry name alone cannot prevent chunk/runtime collisions. |
| Shared scope object | Generated `init` adopts the actual object and rejects a different object after initialization. | Equal-looking contents are not the same initialized scope. |
| Selected shared provider | Loaded singleton selection can retain an older provider. | “Newest registered” is not necessarily “actually used.” |
| Export/resource reference | Consumers retain ordinary JS values and installed resources. | Cache deletion is not a reference rewrite or application cleanup. |

These are source-backed distinctions, not six proposed public interfaces. The standalone library owns the complete update operation once; the product supplies narrow authoritative authorization/grant and canonical-state primitives. A runtime adapter reports truthful identity/capability evidence to that operation, without exposing a broad MF object graph as the generic library contract. [MF-S03–S10, S15; accepted product/library ownership]

Architectural inference: delivery/negotiation, execution isolation and application lifecycle are separate dimensions. MF-delivered JavaScript can still run in an existing renderer realm; a Wasm engine supplies different execution semantics; Effect scopes or framework unmount APIs address resource lifetimes. Treating their names as mutually exclusive values of one runtime switch would hide those combinations and boundaries. This is a separation of responsibilities to discuss, not a new public API proposal.

## 3. A concrete failure before publication

In MF2.9.3 `registerRemote` takes the force branch, removes the registered remote, then normalizes the replacement. Alias validation happens inside that later normalization. A replacement alias that conflicts with another registered remote can therefore throw **after the old registry entry was removed**. This is one precise validation path, not a claim that every registration error mutates state. [MF-S03]

Proposed transfer: retain a distinction between the application's selected generation and an adapter's lookup registry. A destructive runtime mutation must not itself be treated as the application's commit point. Whether candidate loading uses distinct identities, a disposable realm, a constrained same-realm contract, or another mechanism is an owner decision; this report does not choose it.

The same separation matters on success. Ordinary `loadRemote` initializes the container, obtains the expose factory and executes it. `loadFactory:false` can defer the exposed factory, which is useful positive counterevidence against the claim that loading and evaluation are inseparable. It still performs entry loading, initialization and `get`; those are not automatically inert. “Prepared” requires a declared capability/side-effect boundary. [MF-S06, S11]

## 4. Sharing: useful identity, constrained upgrades

The released MF and webpack resolvers both preserve an already loaded singleton in situations where a newer version is registered. With an unsatisfied range, strict singleton consumption rejects; a non-strict consumer can warn and continue with the selected singleton. The exact source qualifies the simplified documentation phrase that the highest version wins. A semver match also does not establish application state or protocol compatibility. [MF-S04, S10, S13]

JupyterLab is a strong counterexample to “avoid all singletons.” Its services are identified by concrete Lumino token objects. Providers and consumers need the same imported token, so the token package must be deduplicated. The guide separates a token/contract package from the replaceable implementation package. A required consumer may set `bundled:false` because the provider supplies the token package. An optional consumer should keep a bundled fallback because the provider may be absent. [MF-S17, S18]

Proposed transfer: distinguish stable platform/contracts from replaceable implementations and their private dependencies. Use upstream scopes, semver negotiation and bundling rather than a parallel resolver. The unresolved choice is which contracts actually need shared JS identity versus messages/serialized values, and when a shared dependency change requires replacing a dependent group or realm. Multiple share scopes are supported dependency namespaces; they do not by themselves isolate DOM effects, global state or privileges. [MF-S21]

## 5. A real consumer's startup discipline, and its limits

JupyterLab's pinned bootstrap initializes all listed federated containers against the common scope before importing the main application. `Promise.allSettled` lets it collect extension failures. The main code then calls container factories, obtains plugin collections and loads style exports separately. This demonstrates useful staging: discover/register providers before consuming services. It also demonstrates that artifact package, federated container, registered plugin and CSS unit can differ. It does not supply evidence of transactional hot replacement of already active services. [MF-S19, S20]

MF's version-first strategy similarly initializes remote entries during sharing resolution; loaded-first avoids initializing all remotes through that particular branch. Explicit preloading, bootstrap code or another demand can still load entries during startup. This is an availability/selection tradeoff. Current documentation discusses offline startup failures, but the pinned implementation's entry-error path can emit a recovery hook and return without initialization. Consequently “any offline remote always fails startup” is too broad without an exact profile and hook configuration. A later capability load may still fail. No outage native probe is claimed here. [MF-S05, S12]

The user-facing operation should distinguish candidate unavailable, fallback selected and candidate successfully selected. The ready runtime hooks help observe those outcomes; a generic “load promise resolved” label is insufficient to describe the whole update.

JupyterLab's own activation observer supplies another useful distinction: its default five-second timer warns about slow activation while the underlying activation continues. Later it records duration or rethrows an actual activation failure. The timer is neither cancellation nor a rejection deadline. This is a good pattern for informative progress, provided the UI does not call a warning a completed stop. [MF-S31]

## 6. Development, browser presentation and SSR

Webpack explicitly scopes its HMR plugin to development. HMR's acceptance/disposal machinery is relevant experience, but its documented contract should not be relabeled a production update transaction. This research's actual-container spike deliberately uses neither HMR nor a custom hot-update loader. [MF-S22]

Same-page MF has no built-in CSS isolation. CSS Modules, BEM, Shadow DOM and framework scoping are available mechanisms, each with its own boundary. JupyterLab separately manages theme CSS loading/unloading and warns against also placing those styles in automatically loaded top-level style exports. Replacing a registry entry does not establish ownership of CSS, listeners or view resources. Desktop preload/IPC/native-host compatibility is an additional lifetime covered by the sibling desktop report. [MF-S17, S20, S25]

SSR adds two separate questions: which code generation serves an in-flight request, and which data/authority belongs only to that request. MF Node documentation shows process-level runtime use, but does not establish a request-isolation guarantee. Its Next.js guide describes warm-server cache revalidation and hydration risks, while also marking that integration as ending support. The guide's blocking-revalidation example is therefore experience to examine, not a production recommendation for this library. [MF-S08, S23, S24]

Inference to test if SSR is adopted: bind the server render and client asset/dependency closure to compatible generation evidence, and keep request-owned user state out of process-shared module singletons. Merely checking for updates before rendering does not itself bind a later browser fetch to the same deployment. No SSR leak or hydration defect was reproduced in this lane.

## 7. Ready mechanisms and warnings against duplicate work

| Need | Existing mechanism worth qualifying | Application-specific work that remains |
|---|---|---|
| Remote code/chunk loading | Published runtime and generated bundler containers | Artifact authorization/selection and supported profile declaration |
| Shared dependency negotiation | Existing shared scopes, range resolver, strict singleton options | Contract compatibility and permitted dependent restart group |
| Loading/evaluation distinction | Container `get`/factory and runtime factory deferral | Candidate execution authority and readiness definition |
| Runtime observation | Existing load/share hooks and selected-provider diagnostics | One coherent update outcome, fallback/degraded status and cleanup evidence |
| Styling | CSS Modules/framework scoping/Shadow DOM and host-owned theme lifecycle | Ownership, removal and visible view replacement policy |
| Framework presentation | Existing framework mount/unmount/bridge mechanisms, when qualified | State handover and accepted visual/disruption policy |

Do not add a second shared resolver, manual container, broad fake loader, or “unload all JS” wrapper. Conversely, do not rely on a runtime's cache eviction as evidence that application resources are reclaimed. The standalone library implements the complete update operation once; consumers should not assemble planning, cutover and cleanup coordination again. Runtime scopes, host resource owners and canonical state retain their own custody and state semantics behind narrow ports. Existing kernel mechanisms can be reused through suitable public contracts; copying a private kernel or deep-importing unavailable internals is not an accepted integration path. A missing public contract remains an explicit integration gate. This research adds no production engine. [MF-S03–S11, S21, S25; accepted product/library ownership]

## 8. Native qualification completed within one profile

The root- and peer-reviewed profile used real webpack 5.113.0 containers, published MF runtime 2.9.3, Node 24.22.3, strict TS 7.0.2 and Playwright 1.65.1. The retained hosted run passed all four declared cases: retained A versus new B; candidate evaluation/factory deferral; the exact alias-validation failure; compatible token identity versus strict mismatch; and a second runtime targeting the same initialized container. The first case contains both replacement and deferral observations, so these are four tests, not five. N4 includes an additional fresh-context control. [MF-S32]

The decisive observations matched the scoped hypotheses. B evaluated while the publication marker still selected A. A's listener survived replacement and stopped after its explicit cleanup. After the invalid alias, public lookup failed with RUNTIME-004 while retained A remained usable; public re-registration restored lookup. The compatible generated consumer received the exact host token, while the strict incompatible no-fallback consumer rejected without breaking that compatible reference. A second runtime's different actual scope hit the same container's init guard with RUNTIME-015; the first reference and fresh-context control worked. All 27 recorded HTTP requests succeeded, so missing assets did not explain the rejections. [MF-S32]

N3 specifically qualifies a provider registered through public runtime `shared.lib` and actual webpack-generated consumers; it does not execute JupyterLab. Higher-new-provider selection, style cleanup, sharing-strategy outages and SSR remain source-only. DEBUG logs establish Chromium Headless Shell 159.0.8154.6/revision 1255. The native JSON's default `browserExecutable` API path names full Chromium instead; that field is explicitly qualified rather than silently treated as the observed process path. [MF-S32]

Inputs were audited, frozen and pushed before execution. Local browser setup was blocked before any semantic case; the first hosted run passed the same four tests but failed artifact upload. Correcting workflow artifact paths and adding launch logging preserved the test inputs and produced the independently reviewed artifact. Those attempts remain visible and do not multiply coverage. The frozen plan/manifest documents retain their pre-execution state; completion belongs to the subsequent qualification receipts.

No latency, memory reclamation, security isolation, cross-browser, Rspack, SSR, Electron or production reliability advantage has been measured. `OPEN-QUESTIONS.md` records the owner decisions rather than silently resolving them.
