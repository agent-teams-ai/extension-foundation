# Module Federation: research and bounded native qualification plan

Status: **Root and desktop peer reviewed; fixture inputs authorized. Native execution still requires a pushed frozen-input checkpoint and compiler audit.** No native fixture executed at this checkpoint.
Date: 2026-11-22. Owner: `/root/mf_runtime`. This directory is research evidence; root owns repository integration, commits and pushes. It does not select a production runtime, public API, isolation or migration policy.

## Questions that can change architecture

1. Which identities are actually distinct: remote registration name, entry global, webpack `output.uniqueName`, module factory/export reference, share-scope object and selected shared singleton? Which survive a forced registration?
2. Does loading a candidate already execute plugin code before an application publishes it? Which lower-level factory deferral is available, and what remains executable before that boundary?
3. Can a failed forced replacement destroy the old registration while existing old references still work? This separates runtime lookup from application selection and resources.
4. When is a shared singleton an identity requirement (JupyterLab service tokens), and what does an incompatible version do under strict and non-strict policies?
5. Does a fresh runtime instance isolate a previously initialized webpack container? The generated init guard compares share-scope object identity.
6. What do real consumers, HMR and SSR establish, and what do they leave to the application?

## Source plan

- Pin released implementations: MF runtime/core 2.9.3 / `40688424f13ea9d4338b9a0cf230e8f1ac4d3835`; webpack 5.113.0 / `e9f0c9b25456ae5d80739ba7f498ae5b623ca194`; compare the documented Rspack 2.3.3 family without pretending it is the same implementation.
- Inspect JupyterLab 4.6.6 / `8d57791d0254820dfa4a540e010105803e128bcd` as an operational consumer: prebuilt package versus plugin unit, token identity, dependency sharing and loading.
- Separate current source observations, documentation promises, historical issue reports and native reproductions. The prior F01/F10 investigation and historical MF verdict are context, not fresh native evidence.
- Check positive guarantees: working compatible singleton sharing, supported factory deferral, genuine generated-container initialization, and versioned artifact coexistence where observed. Do not label all sharing or all caching a failure.

## Proposed one native spike: actual generated containers + published runtime

**Profile:** Chromium browser, a same-origin disposable HTTP fixture, webpack's actual `container.ModuleFederationPlugin` 5.113.0 generating script containers, and published `@module-federation/runtime` 2.9.3 in a generated host bundle. No enhanced bundler plugin, Rspack native binding, HMR server, React, synthetic container, custom MF loader or production library changes. This is a narrow interoperability profile, not proof for MF-enhanced/Rspack/Electron/SSR.

Maintained inputs are `.ts`. `typescript@7.0.2` checks/emits them with `strict`, `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`, `useUnknownInCatchVariables`, `noFallthroughCasesInSwitch`, `skipLibCheck:false`. Webpack consumes the emitted JavaScript as build output; emitted container/runtime JS is an upstream/generated artifact, not maintained application code. `node:test` and `playwright@1.65.1` exercise the actual browser. Node types pinned at `@types/node@24.13.3`.

### Compiler/dependency gate before any native execution

The proposed direct pins are webpack 5.113.0, MF runtime 2.9.3, TypeScript 7.0.2, Playwright 1.65.1 and Node types 24.13.3. Registry manifests already show that runtime -> runtime-core/sdk/error-codes 2.9.3 has no TypeScript compiler dependency. Webpack direct dependencies have none; transitive resolution is **not yet audited**. The enhanced package is deliberately outside this fixture because its declaration tooling is irrelevant to these questions.

After plan approval, resolve an isolated lockfile with install scripts disabled; inspect every resolved package for TypeScript/compiler dependencies and embedded compiler files before `tsc`, webpack or the browser runs. Record exact lock hash and packages. Stop if any compiler below 7.0.2 would execute. Verify compiler version from the selected executable and use existing installed browser binaries where available. A dependency problem causes a plan amendment, never a silent compiler downgrade.

### Frozen proposed test matrix

| ID | Native operation | Decisive observable assertions | Positive control / limit |
|---|---|---|---|
| MF-N1 | Load A, retain its exported object and explicitly installed listener; force same registration to a distinct generated B entry/global/uniqueName; load B | New lookup returns B; retained A object still returns A; A listener remains until its explicit cleanup. Candidate B top-level marker appears during `loadRemote`, before fixture publication. | B is genuinely generated and executes; explicit cleanup removes A listener. This is not a GC/unload or security test. |
| MF-N2 | Load A; keep an unrelated registered remote with an alias prefix that conflicts with the proposed forced replacement; force replacement of A with that invalid alias | Native `registerRemotes(...,{force:true})` throws after its removal branch; inspect registered names and subsequent lookup; retained A callable and already-installed A resource remain observable. | Use source-confirmed alias validation, not a fabricated runtime exception. Do not conclude every failure has this order. |
| MF-N3 | Register the host service-token provider through the published runtime's `shared.lib`; load it, then use actual webpack-generated compatible and incompatible consumers with `import:false` | Compatible consumer receives identical token reference; strict incompatible consumer rejects. Record selected provider/version and error. | Public runtime-registered provider plus actual webpack-generated consume runtime. The minimal token is an object, not a JupyterLab/Lumino integration test. Semver compatibility does not prove business protocol/state compatibility. |
| MF-N4 | Two MF runtime instances target the same already-initialized generated container in the same browser realm, each with its own share-scope map; compare fresh browser context | Same-realm container rejects a different scope object through native generated init guard; fresh context succeeds. | New MF instance is not a realm. Do not assert that independent MF instances always share every map. |

N1 can additionally obtain `loadRemote(...,{loadFactory:false})` on a fresh remote if supported by the exact public typings: distinguish entry/get/init effects from exposed factory execution. It must not become a fabricated side-effect-free transaction. This control is bounded to a single extra assertion and is omitted with an explicit reason if it requires unsupported internals.

N2 precondition: register `replaceTarget` and an untouched peer named `occupied/sub`. Force a replacement for `replaceTarget` with alias `occupied`. Released `packages/runtime-core/src/remote/index.ts` validates that alias after `removeRemote` (lines 640–701 at the pinned commit). The primary oracle is a rejected subsequent public `loadRemote('replaceTarget/probe')` plus a successful retained A call; instance options are diagnostic only. The replacement is not allowed to install an ad hoc throwing runtime plugin to manufacture the outcome.

N4 precondition: distinct host names and returned runtime objects, identical remote registration/global/entry URL, and already-loaded first container. Read-only diagnostics record distinct default scope objects, the same entry-global object before/after, and entry request counts. No runtime internals are mutated. If the loader actually creates a new container, that falsifies the expected guard path and is reported; the fixture must not force the intended result. The positive control uses a fresh browser context and the identical first-load operation.

Peer disposition (desktop review): N1 records A's listener before replacement, after B, and after explicit cleanup, with a fresh context per case. N3 first loads the compatible provider and verifies token identity, then uses an incompatible consuming container with `import:false`, no alternate matching provider, and explicit strict singleton settings. Network/build success is checked separately so a failed request cannot masquerade as version rejection. N2 and N4 use the preconditions and public oracles above. No lifecycle coordinator or internal share-map mutation is added.

Concrete-input review clarified N3's narrower profile: the provider is registered through released runtime `shared.lib`, not itself emitted by a webpack provider build. The generated consumers still execute webpack's genuine shared consumption runtime, with no local fallback. This change reduces fixture machinery and remains a real interoperability/identity observation; it does not qualify provider bundling.

Lazy-chunk/CDN retention and startup strategy outage remain source-backed questions here; the delivery research owns the broader asset-closure probes. No existing project E2E suite is rerun.

## Implementation/review budgets

- Production code: **0 LOC**. Public API changes: **0**. Repository/workflow changes by this agent: **0**.
- Maintained disposable TypeScript: target 450–700 LOC; hard review trigger above 850 LOC. Count build/server/browser runner separately from remote/host fixture inputs.
- Complexity estimate: **5/10**; mostly generated-bundle setup and exact scope semantics. Reliability of the bounded test design: **8/10** once positive controls pass. Current confidence before native execution: **7/10**. These are engineering judgments, not measured availability.
- Freeze the matrix after root and peer critique. A source observation alone must not be relabeled native evidence. If one case cannot be built using released APIs, report the limitation rather than emulate MF semantics.
- Native receipts must include commands, Node/browser/compiler versions, dependency audit, output/artifact hashes, assertions, and explicit applicability limits.

## Open decisions are outputs, not defaults

Surface to the owner: shared platform identity versus dependency-per-generation isolation; allowed update unit when shared singletons change; same-realm execution versus replaceable realm; startup availability tradeoff of share strategy; candidate evaluation authority; development HMR versus controlled production replacement; version/support/asset retention. No branch is adopted in this research.
