# Qualification receipt and remaining boundary

## Frozen v1 / local attempt

Input checkpoint committed and pushed by root before execution:
`4a95ba3026ad4721ed6585a38fbd192e5aba133d`.
All 11 executable/configuration/audit inputs matched `frozen-inputs-v1.json`;
aggregate SHA256 `ab08d51b4182b3cfc15e648b4951afbd0209d42f5d21af86acdff9d122df6493`.
Source: 515 maintained TS LOC, zero production LOC.

| Stage | Result | Evidence |
|---|---|---|
| Dependency/compiler static audit | PASS: 70 distinct installed packages, 2,599 JavaScript files scanned; identified compiler and platform package exactly7.0.2; Acorn substring false positive classified | `probe/dependency-audit.json` |
| Actual compiler version | PASS: `Version 7.0.2` | `probe/results/v1/01-version.{json,log}` |
| Strict TypeScript check, skipLibCheck:false | Exit 0 | `probe/results/v1/02-check.{json,log}` |
| TS emit + webpack generation | Exit 0: five real containers and one host, eleven output files | `probe/results/v1/03-build.{json,log}`; `build-manifest.json` |
| Browser native attempt | BLOCKED in shared before-hook; Chromium process singleton socket denied by operating environment | `probe/results/v1/04-native.{json,log}` |
| Semantic MF cases | **0 executed, 0 passed, 0 semantic failures established** | `native-observations.json`: empty cases and requests |

`node:test` reports four failed tests because the browser setup hook failed.
Those are not four independently executed MF assertion failures. Chromium's
fatal message names `socket() failed: Operation not permitted`; a later crash
diagnostic also reports denied ptrace. No attempt was made to weaken the local
environment restriction, mutate browser guards or use a fake DOM/container.

The actual generated artifacts and hashes remain available in `probe/dist/`
and the build manifest. Necessary upstream MIT licenses for webpack and the
four bundled MF packages are retained in `third-party-licenses/`; no dependency
directory is redistributed.

## V2 hosted qualification completed

Root pushed the portable v2 inputs and dedicated workflow at
`4dd605c757ff8e06e131f906511119827c4a42f6`. The first hosted run 45053736889
passed 4/4 native tests but failed artifact upload because paths contained a
literal parent-directory component. Its terminal results remain separate from
detailed observations that were not retained by that run.

Root pushed artifact path normalization and DEBUG launch logging at
`44bf9c21fe55a048d6f942411695a4fd74dede67`, leaving frozen test inputs and
oracles unchanged. Corrected hosted run 45054452281/job 137306490663 succeeded
and retained the artifact. **Four declared tests passed, zero failures/skips.**
Five observation records include one N4 positive control, not a fifth test.
All eleven frozen input hashes matched and all 27 recorded requests returned 200.
The independent semantic review is `NATIVE-SEMANTIC-REVIEW.md` with precise
hashes and limits in its JSON companion; CI integrity/ZIP review is retained
by the sibling audit lane.

N1–N4 now have native evidence for their specified claims. Other source findings
are not promoted merely because the browser profile passed. Two hosted executions
of the same matrix do not double its coverage. Original v1 attempts and the first
hosted artifact-delivery failure remain part of the final evidence.

## Browser receipt field qualifier

The v2 `browserExecutable` field records an explicitly configured executable,
or `chromium.executablePath()` when no override is set. The latter is the API's
default full-Chromium path, **not an observed process executable**. Static
inspection of locked Playwright 1.65.1 shows its no-channel headless launch
selects `chromium-headless-shell`; `browsers.json` identifies both managed
variants as revision 1255/version 159.0.8154.6. The separately recorded
`browser.version()` is a live browser result. Treat any actual launched path
as verified only if launch logs establish it; do not silently substitute the
API default path. This qualification needs no oracle change or extra test run.
