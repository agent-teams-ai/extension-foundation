# Peer review: released SystemJS replacement probe

Reviewer: `/root/mf_runtime`, 2026-11-22. Reviewed `delivery/PLAN.md` v2 and independently inspected released registry implementation at `17c238ec00cf7c4bcabcf3579f876513fcedba30`. **The plan is suitable after the oracle clarifications below.** No native execution by this review; no production loader selected.

Primary source: <https://github.com/systemjs/systemjs/blob/17c238ec00cf7c4bcabcf3579f876513fcedba30/src/features/registry.js>.

## Mechanism and successful counterevidence

The implementation genuinely returns a closure after successful deletion. After a replacement has completed, that closure appends saved importer setters to the replacement and invokes them with its namespace. A generated importer can therefore observe B while an independently retained A namespace/function continues to denote A. This is a useful positive result beyond the weaker statement that deletion merely changes later imports. Rollup-generated `System.register`, public import/delete/has calls and signal-based TLA are appropriate; no substitute loader or private setter manipulation is needed.

## Required assertion details

1. A successful callback does **not return true** in this source: it falls through with `undefined`. Guard failures return `false`. Assert the observable importer binding change, and record the return without converting it to a Boolean success requirement. Before replacement returns false without consuming the saved setter list; after a successful relink the list becomes null, so the next call returns false.
2. Resolve and retain the same canonical module URL for import/delete/has. Assert original import completion and importer evaluation before deletion. The test's temporary overwrite is a replacement probe; keep the explicit warning that it is not immutable production asset delivery.
3. Pending-TLA rejection must be observed after the gate has signaled evaluation started and before release. After release, await the exact original import promise, verify its value, then retry deletion. Do not infer cancellation from the failed delete or from a test timeout.
4. Separate the old namespace, a captured old exported function, and the importer's live read function. All three references answer different lifetime questions; avoid a custom variable relay that merely reassigns them in the harness.

## Callback failure semantics — source finding only

The closure invokes setters in a `forEach` without a rollback/catch, and clears the saved list only after the entire loop. If a setter throws, earlier setters may already have been appended/invoked while later ones have not; retrying is not established as safe. This is **not** a reproduced failure of ordinary Rollup-generated setters. Do not add fabricated private registry hooks or a hand-authored container to force it. The report should say that this public mechanism is not evidence of atomic application graph cutover or all-or-nothing listener/state migration. If natural generated ESM fixtures cannot expose the exceptional path inside the existing budget, leaving it source-classified is correct.

## Execution boundary

Keep resolved dependency/compiler audit and strict TS7 checks before the native run; no old TypeScript System emitter. Root's pushed frozen input checkpoint must precede execution. Node published-loader behavior remains separate from browser import maps, browser cache, Module Federation and the production library. The three bounded cases are sufficient to assess the stated reuse question; no broader HMR coordinator is warranted by this plan.
