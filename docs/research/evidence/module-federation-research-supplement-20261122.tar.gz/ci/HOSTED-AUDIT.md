# Native Module Federation hosted evidence audit

The corrected hosted profile completed successfully on
`44bf9c21fe55a048d6f942411695a4fd74dede67`, tree
`098044add55de4811ec8df7505a13410621d79f6`.
[Run 45054452281](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45054452281),
job 137306490663, attempt 1: **4 tests passed, 0 failed, 0 skipped**.
This is four distinct research cases; N4 also records a fresh-context control,
making five observation rows. The preceding hosted run exercised the same four
cases and does not add scenario coverage.

## Independent verification

| Evidence | Observed result |
| --- | --- |
| Raw artifact | ID 14766687520; 120,101 bytes; 47 regular files |
| ZIP SHA256 | `c3fa91cbaee87d44b7ee9e91205232e733805ae0fdc8a29b16b15fc9ea75d19c`; matches API digest |
| Executed workflow | `e4e550260f511f0fae9c6bb3c90ac51ae00e9ff7428c2699e1c6ea879d33b2c5`; exact remote and receipt match |
| Frozen inputs | All 11 executable/configuration inputs match; aggregate `8299e58dd668163cb75d0adf2b124c2fce6c0f6c6d452fcb7e08fbfd22db3fbb` |
| Dependency closure | All 70 package/version pairs match; only TypeScript compiler/platform 7.0.2 |
| Actual tools | Node 24.22.3, pnpm 11.25.0, TypeScript 7.0.2, webpack 5.113.0, MF runtime 2.9.3, Playwright 1.65.1 |
| Generated output | Five real containers and host; all 11 dist files match build-receipt hashes; seven emitted harness files retained |
| Browser | `browser.version()` reports 159.0.8154.6; DEBUG shows actual headless-shell revision 1255 launch and clean exit |
| Native observations | Five rows; all 27 recorded requests HTTP 200; all pageErrors arrays empty |
| Duration | Native suite 2514.376766 ms; no performance conclusion |

The artifact retains and matches 19 of the 21 original archive members. PLAN.md
and portability-v2.diff were not upload paths; they remain in the immutable input
archive. All maintained executable sources, lock/configuration, dependency audit,
frozen manifest and license notices are retained. The first comparison initially
expected all 21 members and stopped at PLAN.md; the corrected scope comparison
above changes no input or runtime result.

The compiler executable was hash-checked by the successful workflow before any
compiler invocation. That binary was not uploaded, so this audit does not claim
an independent local rehash of the hosted binary. `browserExecutable` in
native.json is the API default full-Chromium path; the actual process path comes
from the separate launch diagnostic. Browser stderr contains D-Bus diagnostics;
the process exited 0 and captured pageErrors stayed empty.

## Failure history and scope

Earlier run 45053736889 on 4dd605c passed four native tests but failed artifact
upload because the pinned upload action rejected literal parent-path segments.
It produced no artifact. Its full decoded log, metadata and original preflight
are retained. The fix normalized the two paths through GITHUB_ENV and added
browser-launch diagnostics to the already required replacement run. The frozen
input and assertions did not change.

Detailed byte identities, actual counts and input/workflow receipts are in
native-hosted-v2/HOSTED-AUDIT.json and corrected-artifact/. The raw downloaded ZIP
is retained; ephemeral signed download credentials are absent from audit files.
The MF lane independently reviewed the scenario semantics and returned PASS in
federation/NATIVE-SEMANTIC-REVIEW.json, with the same native JSON hash. This qualifies the
bounded webpack/Chromium fixture, not a library E2E, enhanced bundler HMR, Rspack,
SSR, Electron, GC, security or performance guarantee. Local SystemJS 2/2 and prior
unchanged native profiles remain separate.

Final exact-head repository CI is a subsequent audit after root publication.
No repository edit, native execution, workflow dispatch or rerun was performed
by this audit lane.
