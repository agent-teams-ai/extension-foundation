# Evidence upload correction — independent review

The first preflight approval missed the pinned upload action's rejection of
literal `..` path segments. Keep that preflight and the failed hosted run as
history; neither an `always()` upload nor passing native assertions proves that
the evidence was retained. Run 45053736889 has four passing native tests but
overall failure and zero artifacts.

The correction adds three Python lines to the existing extraction step. It writes
the already resolved absolute root and probe directory to `GITHUB_ENV`, so later
steps and upload inputs use canonical paths. This matches the established editor
workflow's approach. Two YAML lines add `DEBUG: pw:browser` to the existing native
test step, so the already required run records the actual browser launch command.
It does not change the frozen probe, its oracles, dependencies or browser selection.

Reviewed workflow SHA256:
`e4e550260f511f0fae9c6bb3c90ac51ae00e9ff7428c2699e1c6ea879d33b2c5`.
The archive, manifest and internal aggregate remain identical to the first run;
their exact hashes are in `workflow-correction-review.json`. This is a bounded
source review, pending actual upload and independent artifact verification.

## Receipt interpretation

After upload succeeds, independently verify the API ZIP digest, all frozen source
bytes, generated-file hashes, input/workflow receipt, closure identity, actual
runtime versions and terminal test summary. Give the native observations to the
MF lane for separate semantic review. Four tests can produce five observation
rows; repeated hosted runs do not create additional distinct scenarios.

`native.json.browserExecutable` is the configured path or Playwright API default
path. The default full Chromium path does not establish the actual headless
process executable. `browser.version()` is the runtime-reported browser version;
the download log and Playwright browser revision are separate evidence. Do not
rerun solely to strengthen executable-path attribution. The diagnostic environment
is part of the already necessary evidence-delivery fix.

No repository edits, job dispatches, reruns or native executions were performed
by this audit lane.
