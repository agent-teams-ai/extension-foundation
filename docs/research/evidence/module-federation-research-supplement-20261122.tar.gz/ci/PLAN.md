# Independent workflow and CI audit

Owner: web_delivery CI lane, 2026-11-22. Read-only access to repository/GitHub;
write audit artifacts only under this ci directory. Root owns workflow edits,
commits, pushes and all test/job dispatch. No rerun is authorized here.

## Sequence

1. Review new module-federation-research.yml against existing pinned-action
   native-editor pattern and the exact v2 frozen archive/manifest.
2. Check extraction/file identity, exact compiler/dependency identity, maintained
   TypeScript coverage, real build, managed Playwright browser, execution failure
   propagation and unconditional evidence retention. Verify no skip/fallback can
   create a false pass.
3. After root push, inspect actual hosted run metadata, latest-attempt jobs,
   decoded full job logs and the downloaded artifact. Reconcile input/workflow
   receipt, package/runtime/browser/build identities, test counts and observations.
4. After final commit, inspect exact-head required CI/doc/identity/CodeQL states.
   Record actual checked-out source and PR synthetic-merge tree versus head tree.
   Linux job names do not establish different Node versions; preserve real counts
   and the named Windows symlink skip if present.
5. Compare previous immutable native workflow inputs with their retained pins.
   Carry earlier evidence unchanged, do not add it to the new profile's counts.

## Claim boundaries

- SystemJS 2/2 is a separate local native probe, not hosted MF evidence.
- Four MF hook failures from unavailable local browser are setup outcomes, not
  four tested semantic failures.
- A hosted pass qualifies only the fixture's actual runtime boundaries.
- Documentation/identity jobs may run on a synthetic merge/base event identity;
  verify what was actually validated before attributing it to the delivery head.
- Workflow path filters mean later prose commits may not rerun native tests;
  exact unchanged inputs support carry-forward, not a fabricated fresh run.
- Prior unresolved shared Foundation/FMS/embedded-compiler constraints are not
  erased by successful existing gates.

## Deliverables

Workflow preflight review, hosted-run/artifact audit, raw metadata/log hashes,
final exact-head CI audit JSON and concise report. No optional redundant matrix.
