# Hosted MF v2: assertions passed, artifact delivery failed

Run 45053736889 / job 137304298907 on exact
4dd605c757ff8e06e131f906511119827c4a42f6 completed with overall failure.
Install/closure check, strict TypeScript, real webpack build, managed Chromium
installation and all four native tests succeeded. Upload-artifact rejected the
literal parent-path component in MF_RESEARCH_ROOT/DIRECTORY. No artifact exists;
native.json and generated-byte observations cannot be independently inspected.

The prior preflight result is retained as its original observation. It missed the
pinned upload action's dot-path restriction. The established editor workflow
normalizes its directory through GITHUB_ENV; this new workflow had not copied
that normalization. This is an evidence-delivery failure, not a failing MF case.

Root was notified to write both resolved directory values to GITHUB_ENV after
safe extraction. The input archive, assertion scope and dependency identities
need no change. A subsequent root-triggered run is needed to recover complete
artifacts from an actual browser execution. The audit lane triggers nothing.

Exact decoded original logs, failed jobs/run/artifact metadata and length/hash
provenance are preserved under native-hosted-v2/. Do not combine repeated native
runs into additional distinct semantic scenarios.
