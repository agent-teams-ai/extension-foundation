# Native Module Federation workflow — independent preflight

Reviewed 2026-11-22, before root commit/push. Result: **PASS for this bounded
research execution route**. No repository edit, test execution or workflow rerun
was performed by this audit lane.

Workflow SHA256: cd1a4af3b7712e63bad198fc318091cc1be7d9a0f917375268f7903cb0a49e90.
Frozen v2 archive: 27,743 bytes / 21 regular members; SHA256
a2e6bfb6bb715c563026f72dc64a7c7460971d4a46d3eb711e8d0b5395cbefc6.
Manifest SHA256: 29427dff539b38e85afe55b4632acec923893b68cedb1dfbdd557a4c6b5efb91.

## Checked

- Action revisions equal the existing qualified editor workflow pins. Permissions
  are contents:read; credentials are not retained by checkout.
- Push/path triggers cover only the workflow and frozen input archives/manifests.
  Output publication paths do not retrigger this profile.
- Archive bytes/hash, member set, uniqueness, regular-file requirement and each
  extracted byte count/hash are verified before execution. Python's standard
  data extraction filter is used. The actual archive contains no absolute/parent
  paths and no old results/native.json capable of masquerading as a new result.
- All 70 audited installed package identities must equal the frozen closure;
  direct pins and lock hash must match. TypeScript compiler/platform must be
  7.0.2; exact Linux compiler executable hash is checked before tsc runs.
- Strict check covers build, tests and all fixture TS; real webpack generation
  precedes managed Playwright Chromium installation and native tests.
- Pipeline failures propagate through pipefail. No skip, fallback browser,
  continue-on-error or synthetic passing result was added.
- Always-upload includes exact maintained sources, generated containers, emitted
  .build harness/build files, input/workflow receipt, logs/results and license
  provenance. Scoped hidden-file inclusion retains emitted .build only among
  the named paths; no repository root or environment directory is uploaded.
- The sole common executable input change from v1 is probe/probe.test.ts browser
  executable selection. Dependency pins and assertions are unchanged.
- Existing CI/docs/identity/native-editor workflow bytes remain unchanged. The
  current organization quality baseline is still 0b44c64c824f536bd1b085341e7669bcc64ef124.

## Limits to preserve after execution

Preflight success is not a native test result. The original local unavailable
browser caused four hook failures, not four independently executed semantic
failures. Hosted run and artifact must establish the actual Node/browser/compiler,
commit, input and counts. Earlier native profiles and local SystemJS2/2 remain
separate. Final exact-head repository CI will be audited after publication.
