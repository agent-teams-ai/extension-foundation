# SystemJS native probe preparation

Prepared 2026-11-22; runtime execution has not occurred. Root must freeze/push
the inputs before authorizing the native test. Peer plan review lives in the
sibling federation/REVIEW-systemjs-plan.md.

Exact pins: SystemJS 6.15.1, @types/systemjs 6.15.4, TypeScript 7.0.2, Rollup
4.68.8, @types/node 24.13.3. Resolved extra declarations: @types/estree 1.0.10,
undici-types 7.18.2. Node 24.22.3 / pnpm 11.25.0.

The frozen-lock installation used --ignore-scripts. dependency-audit.json lists
the actual installed closure. No executable TypeScript import was found in
Rollup/SystemJS readable runtime code. The only compiler is the pinned TS7 CLI;
Rollup's native parser is not a TypeScript compiler. No upstream build ran.

First attempts succeeded: strict host type check, strict fixture ESM compilation,
then real Rollup System.register generation. A peer review improved readiness
failure propagation before any runtime run; strict host attempt2 also succeeded.
The corresponding logs are empty success outputs and are preserved. These are
preparation, not runtime evidence. See REVIEW-HISTORY.md for the input change.
inputs.json records exact maintained source, generated module and lock hashes.

The fixture uses public System APIs and real generated dependencies. The completed
case measures live binding vs old namespace/function, including missing/repeated
callback guards; the pending case uses a real TLA module and deterministic gate.
The mutable file URL is controlled laboratory input, not a deployment proposal.

After root authorization, the native command is:

```sh
node --test --test-concurrency=1 systemjs.test.ts
```

Expected scope: 2 native Node tests covering SYS-01/02 and SYS-03. No browser,
Federation, resource cleanup, migration, transaction or full-library E2E claim.

No production runtime/API/rollout decision is adopted. All failure logs, should
they occur, must remain alongside any later revision and rerun.
