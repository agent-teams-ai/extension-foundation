import "systemjs";
import assert from "node:assert/strict";
import { test } from "node:test";
import { cp, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

type ModuleRecord = Record<string, unknown>;
type Observation = Readonly<Record<string, string | boolean | number>>;
const observations: Observation[] = [];
const generated = new URL("./generated/system/", import.meta.url);

function isRecord(value: unknown): value is ModuleRecord {
  return typeof value === "object" && value !== null;
}
function record(value: unknown): ModuleRecord {
  assert.equal(typeof value, "object");
  assert.notEqual(value, null);
  if (!isRecord(value)) throw new Error("Expected module namespace");
  return value;
}
function callable(value: unknown): (...args: unknown[]) => unknown {
  assert.equal(typeof value, "function");
  if (typeof value !== "function") throw new Error("Expected callable export");
  return (...args: unknown[]): unknown => Reflect.apply(value, undefined, args);
}
function stringValue(value: unknown): string {
  assert.equal(typeof value, "string");
  if (typeof value !== "string") throw new Error("Expected string");
  return value;
}
function promiseValue(value: unknown): Promise<unknown> {
  assert.ok(value instanceof Promise);
  if (!(value instanceof Promise)) throw new Error("Expected native Promise");
  return value;
}
async function load(url: string): Promise<ModuleRecord> {
  const imported: unknown = await System.import(url);
  return record(imported);
}
async function fixture(): Promise<string> {
  const directory = await mkdtemp(join(tmpdir(), "released-systemjs-"));
  await cp(generated, directory, { recursive: true });
  return directory;
}
function moduleUrl(directory: string, name: string): string {
  return pathToFileURL(join(directory, name + ".js")).href;
}
async function persist(): Promise<void> {
  await writeFile(new URL("./observations.json", import.meta.url),
    JSON.stringify({
      profile: "published-systemjs-node-6.15.1",
      runtime: process.version,
      scope: "module binding mechanics only; not browser or library E2E",
      observations,
    }, null, 2) + "\n");
}

test("SYS-01/02: replacement relinks live importer but retains escaped values", async () => {
  const directory = await fixture();
  const dependencyUrl = moduleUrl(directory, "dependency");
  const consumerUrl = moduleUrl(directory, "consumer");
  try {
    const oldNamespace = await load(dependencyUrl);
    const consumer = await load(consumerUrl);
    const oldFunction = callable(oldNamespace.describe);
    const readBinding = callable(consumer.readBinding);
    const captured = callable(consumer.capturedAtEvaluation);
    assert.equal(stringValue(readBinding()), "A:dependency-A");
    const restore = System.delete(dependencyUrl);
    assert.equal(typeof restore, "function");
    assert.equal(System.has(dependencyUrl), false);
    if (restore === false) throw new Error("Completed module deletion unexpectedly denied");

    const absentRestore: unknown = restore();
    assert.equal(absentRestore, false);
    await cp(join(directory, "dependency-b.js"), join(directory, "dependency.js"));
    const replacement = await load(dependencyUrl);
    assert.notEqual(replacement, oldNamespace);
    assert.equal(replacement.version, "B");
    assert.equal(stringValue(callable(replacement.describe)()), "dependency-B");
    const beforeRestore = stringValue(readBinding());
    assert.equal(beforeRestore, "A:dependency-A");

    const successfulRestore: unknown = restore();
    assert.equal(successfulRestore, undefined);
    assert.equal(stringValue(readBinding()), "B:dependency-B");
    assert.equal(oldNamespace.version, "A");
    assert.equal(stringValue(oldFunction()), "dependency-A");
    assert.equal(stringValue(captured()), "dependency-A");

    const duplicateRestore: unknown = restore();
    assert.equal(duplicateRestore, false);
    observations.push({
      case: "SYS-01/02",
      deleteReturn: typeof restore,
      namespaceIdentityChanged: replacement !== oldNamespace,
      replacement: stringValue(replacement.version),
      importerBeforeRestore: beforeRestore,
      importerAfterRestore: stringValue(readBinding()),
      retainedNamespace: stringValue(oldNamespace.version),
      escapedFunction: stringValue(oldFunction()),
      importerCapturedFunction: stringValue(captured()),
      absentRestoreReturnedFalse: absentRestore === false,
      successfulRestoreReturnedUndefined: successfulRestore === undefined,
      repeatedRestoreReturnedFalse: duplicateRestore === false,
    });
  } finally {
    System.delete(consumerUrl);
    System.delete(dependencyUrl);
    await rm(directory, { recursive: true, force: true });
    await persist();
  }
});

test("SYS-03: pending evaluation denies delete without cancelling original work", { timeout: 5000 }, async context => {
  const directory = await fixture();
  const gateUrl = moduleUrl(directory, "gate");
  const pendingUrl = moduleUrl(directory, "pending");
  let release: (() => unknown) | undefined;
  let pendingImport: Promise<ModuleRecord> | undefined;
  const aborted = Promise.withResolvers<never>();
  const onAbort = (): void => {
    const reason: unknown = context.signal.reason;
    aborted.reject(reason instanceof Error ? reason : new Error("Readiness wait aborted"));
  };
  context.signal.addEventListener("abort", onAbort, { once: true });
  try {
    const gate = await load(gateUrl);
    release = callable(gate.release);
    const started = promiseValue(gate.started);
    pendingImport = load(pendingUrl);
    const endedBeforeRelease = pendingImport.then(() => {
      throw new Error("Pending module completed before the release gate opened");
    });
    await Promise.race([started, endedBeforeRelease, aborted.promise]);
    const denied = System.delete(pendingUrl);
    assert.equal(denied, false);
    assert.equal(System.has(pendingUrl), true);
    release();
    const completed = await pendingImport;
    assert.equal(completed.completed, "original-pending-module-completed");
    const afterCompletion = System.delete(pendingUrl);
    assert.equal(typeof afterCompletion, "function");
    observations.push({
      case: "SYS-03",
      deleteWhilePendingReturnedFalse: denied === false,
      originalImportCompleted: stringValue(completed.completed),
      deleteAfterCompletionReturn: typeof afterCompletion,
      cancellationClaim: false,
    });
  } finally {
    release?.();
    await Promise.race([
      pendingImport?.catch(() => undefined),
      aborted.promise.catch(() => undefined),
    ]);
    context.signal.removeEventListener("abort", onAbort);
    System.delete(pendingUrl);
    System.delete(gateUrl);
    await rm(directory, { recursive: true, force: true });
    await persist();
  }
});

