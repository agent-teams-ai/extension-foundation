# Released SystemJS native result

Observed 2026-11-22, one native attempt. **2 tests passed, 0 failed, 0 skipped**.
Node's standard test-runner output is preserved unchanged in native-attempt1.log.
No runtime input changed after the pushed freeze.

Frozen commit: 4a95ba3026ad4721ed6585a38fbd192e5aba133d.
Input manifest SHA256: 7a006b61c25facb93692664cefca34f1c9a1c9cd226deeebe9b592c91a2f26c8.
Root input archive SHA256: acba330f1385b03ef3cbe501fc9b5a640637398289e190d783fefafd6a36325b.
The archive contains 39 members / 23,675 bytes. Exact run facts and output hashes
are in RUN.json.

| Observable | Native result |
| --- | --- |
| Successful completed-module delete | Returns a function |
| Replacement namespace identity/value | New identity; B |
| Existing importer's live read before callback | A:dependency-A |
| Existing importer's live read after callback | B:dependency-B |
| Retained old namespace | A |
| Escaped original function | dependency-A |
| Function captured by importer at initial evaluation | dependency-A |
| Callback before replacement / repeated callback | false / false |
| Successful callback result | undefined |
| Delete during signalled pending top-level await | false |
| Original suspended import after gate release | Completes normally |
| Delete after that completion | Returns a function |

Runtime: Node v24.22.3, SystemJS 6.15.1, @types/systemjs 6.15.4. TypeScript 7.0.2
emitted own ESM fixtures; Rollup 4.68.8 emitted actual System.register modules.
The harness never accessed a private registry or changed instantiate hooks.

This establishes a real reusable loader primitive and its reference boundary.
It does **not** establish browser behavior, Module Federation, graph transaction
rollback, plugin state migration, resource reclamation, UI readiness, fleet
adoption or complete plugin-library E2E. No architecture option is adopted.

## Provenance and notices

Generated ESM/System modules and sourcemap source content derive only from the
own fixture TypeScript under fixtures/. The upstream loader and compiler are
installed dependencies and are not vendored into the frozen artifact.
THIRD-PARTY-NOTICES.json records the exact nine installed packages, SPDX package
license metadata and license/notice file hashes. There are no copied upstream
fixture implementations or substitute loader/container implementations.

