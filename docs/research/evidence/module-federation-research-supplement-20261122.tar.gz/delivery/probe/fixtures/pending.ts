import { markStarted, wait } from "./gate.js";
markStarted();
await wait;
export const completed = "original-pending-module-completed";

