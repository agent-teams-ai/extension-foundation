import { describe, version } from "./dependency.js";
export const capturedAtEvaluation = describe;
export function readBinding(): string { return `${version}:${describe()}`; }

