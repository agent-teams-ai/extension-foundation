export const version = "A";
export function describe(): string { return `dependency-${version}`; }

