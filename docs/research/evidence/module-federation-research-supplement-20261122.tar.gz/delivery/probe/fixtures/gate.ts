const startedSignal = Promise.withResolvers<void>();
const releaseSignal = Promise.withResolvers<void>();
export const started = startedSignal.promise;
export const wait = releaseSignal.promise;
export function markStarted(): void { startedSignal.resolve(); }
export function release(): void { releaseSignal.resolve(); }

