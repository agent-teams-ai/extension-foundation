export const version = "B";
export function describe(): string { return `dependency-${version}`; }

