System.register([], (function (exports) {
	'use strict';
	return {
		execute: (function () {

			exports("describe", describe);

			const version = exports("version", "A");
			function describe() { return `dependency-${version}`; }

		})
	};
}));
//# sourceMappingURL=dependency.js.map
