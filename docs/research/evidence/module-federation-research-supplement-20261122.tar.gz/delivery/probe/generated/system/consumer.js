System.register(['./dependency.js'], (function (exports) {
	'use strict';
	var describe, version;
	return {
		setters: [function (module) {
			describe = module.describe;
			version = module.version;
		}],
		execute: (function () {

			exports("readBinding", readBinding);

			const capturedAtEvaluation = exports("capturedAtEvaluation", describe);
			function readBinding() { return `${version}:${describe()}`; }

		})
	};
}));
//# sourceMappingURL=consumer.js.map
