System.register(['./gate.js'], (function (exports) {
	'use strict';
	var markStarted, wait;
	return {
		setters: [function (module) {
			markStarted = module.markStarted;
			wait = module.wait;
		}],
		execute: (async function () {

			markStarted();
			await wait;
			const completed = exports("completed", "original-pending-module-completed");

		})
	};
}));
//# sourceMappingURL=pending.js.map
