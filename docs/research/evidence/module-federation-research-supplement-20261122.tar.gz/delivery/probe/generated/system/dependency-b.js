System.register([], (function (exports) {
	'use strict';
	return {
		execute: (function () {

			exports("describe", describe);

			const version = exports("version", "B");
			function describe() { return `dependency-${version}`; }

		})
	};
}));
//# sourceMappingURL=dependency-b.js.map
