System.register([], (function (exports) {
	'use strict';
	return {
		execute: (function () {

			exports({
				markStarted: markStarted,
				release: release
			});

			const startedSignal = Promise.withResolvers();
			const releaseSignal = Promise.withResolvers();
			const started = exports("started", startedSignal.promise);
			const wait = exports("wait", releaseSignal.promise);
			function markStarted() { startedSignal.resolve(); }
			function release() { releaseSignal.resolve(); }

		})
	};
}));
//# sourceMappingURL=gate.js.map
