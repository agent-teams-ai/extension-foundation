import { rollup } from "rollup";
import { mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const esm = fileURLToPath(new URL("./generated/esm/", import.meta.url));
const output = fileURLToPath(new URL("./generated/system/", import.meta.url));
await mkdir(output, { recursive: true });
const build = await rollup({
  input: ["dependency", "dependency-b", "consumer", "gate", "pending"].map(
    name => `${esm}${name}.js`,
  ),
  treeshake: false,
  preserveEntrySignatures: "strict",
});
try {
  await build.write({
    dir: output,
    format: "system",
    preserveModules: true,
    preserveModulesRoot: esm,
    entryFileNames: "[name].js",
    chunkFileNames: "[name].js",
    sourcemap: true,
  });
} finally {
  await build.close();
}

