# Tests needed to qualify the web delivery promises

Status: two SystemJS native tests passed once on the frozen input. All other rows
remain source-only qualification requirements for owner-selected capabilities.

| ID | Native scenario | Independent oracle | Evidence now | What a pass would qualify |
| --- | --- | --- | --- | --- |
| SYS-01/02 | Released SystemJS + real generated A/B dependency, importer, retained function; delete/reimport/relink and guard calls | Actual namespace identity, live/captured values, callback return values | Native attempt1 PASS, one test | This loader/version's binding mechanics only |
| SYS-03 | Released SystemJS module suspended in real TLA with explicit started gate | delete returns false while pending; original import completes after release | Native attempt1 PASS, one test | Deletion denial without cancellation |
| PUB-01 | Two real deployment writers concurrently update selected authority and storage | One valid selector generation; conflict identified; unrelated mapping retained | Source-only; no race reproduced | Publication algorithm in chosen topology |
| PUB-02 | Publish graph B while an A tab requests previously-unfetched transitive chunk/CSS/worker/Wasm asset | Response generation/digest belongs to A closure or explicit expiry recovery | Normative/docs transfer | Retention/closure policy under selected CDN and host |
| PUB-03 | Old selector at edge, new selector at origin, browser HTTP cache and SW cache contain different generations | Every observed resource belongs to selected supported closure | Source-only | Chosen stale-selector/cache policy, not simultaneous fleet adoption |
| PUB-04 | Missing/altered transitive artifact during stage | Selector stays unchanged or client reports exact safe failure; no silent partial activation | Integrity mechanism documented | Candidate artifact validation before actual adoption |
| SW-01 | Two real tabs on A; B installed and waits; initiating tab accepts skipWaiting; second remains open | Actual controller, page generation, useful UI and lazy-asset requests per tab | Spec + Workbox source only | Selected mixed-version/reload policy |
| SW-02 | Install failure and activation interruption while old page exists | Install leaves prior active worker; state restoration/cleanup outcome recorded separately | Normative draft only | Browser-specific lifecycle handling |
| SW-03 | Another tab registers worker; observe external controlling event and own controlling promise | Read actual navigator.serviceWorker.controller, event isExternal, own promise settlement | Workbox 7.4.1 source only | Correct observer semantics for external updates |
| AFF-01 | New tab changes shared deployment cookie while old tab sends delayed/custom requests | Per-request deployment ID and bytes compared with originating tab identity | Vercel docs only | Exact framework/provider affinity mode, not generic session pinning |
| UI-01 | Two scoped custom registries with same tag, then generation update/remount | Actual constructors/instances, focus/selection and lifecycle events | HTML spec + vendor shipping claim | Target browser/embedded-host coexistence and controlled migration |
| UI-02 | Shared and owned stylesheet variants across two roots during update/disposal | Computed styles and live style owners before/after; unowned root unchanged | CSSOM draft + transfer reasoning | Actual style ownership boundary |
| UI-03 | Selected iframe/realm host closes while retained references/external operations exist | Owned host resources close; canonical receiver rejects retired generation writes | Origin/agent constraints only | Concrete host reclaim and authority boundary |

No row claims production e2e until it runs against the chosen actual host, runtime,
artifact service and state/effect receivers. Existing previous-phase tests and the
sibling Federation profile are independent evidence, never added to these counts.

