# Owner questions — web delivery lane

All choices OPEN. These are candidate answers and their tradeoffs, not decisions.
Existing canonical-state/grant ownership remains unchanged.

| Question | Best current candidate to discuss | Alternative and tradeoff | What would change the answer |
| --- | --- | --- | --- |
| DQ1 What may update in place? | Lifecycle-aware instance/remount or realm replacement, with SystemJS relink an optional adapter capability | General binding relink for trusted cooperative modules preserves more callers but needs graph/application constraints | Actual native host slice, shared framework requirements and failed-setter policy |
| DQ2 Which delivery runtime? | Keep MF, SystemJS and native ESM as separately qualified options behind existing narrow execution boundaries | Choose one first host profile to reduce initial surface; defer others without pretending one loader API has equivalent guarantees | Sibling MF real-build results; packaging, sharing and UI requirements |
| DQ3 Who owns graph publication? | Existing canonical authority publishes immutable artifact closure and selector projection; reuse publisher/storage CAS | Single-writer import-map-deployer fits simple deployments but its mutex does not establish multi-instance ownership | Actual deployment topology and authoritative store selected by owner |
| DQ4 What is a tab allowed to retain? | Explicit per-tab generation identity and bounded compatibility/retention contract | Session-cookie affinity is easier, but shared across tabs; reload-only simplifies old-version support | Independent-tab requirement; long-lived jobs, offline duration, storage budget |
| DQ5 How should a Service Worker update be adopted? | Workbox waiting notification followed by product-owned safe reload/save checkpoint if SW is needed | Natural waiting until clients leave; or compatible mixed page/worker operation at higher qualification cost | Must preserve draft, call, upload or other in-flight user work; required update deadline |
| DQ6 How long do old assets remain? | Owner-defined supported session horizon plus explicit expiry/recovery behavior | Indefinite retention supports unbounded old tabs at greater cost; best-effort cache cannot guarantee cold lazy assets | Maximum old-client/offline age and emergency revoke requirements |
| DQ7 How are custom elements/styles isolated? | Per-generation owned subtree/stylesheet plus scoped registry where target hosts support it | Fresh document/iframe for stronger namespace reset; global definitions require stable identity or remount strategy | Browser/Electron minimums, third-party UI framework compatibility |
| DQ8 What counts as visible success? | Host-supplied useful-view assertion after framework mount, then retire generation | Loaded/evaluated/mounted-only telemetry is cheaper but does not establish usable changed UI | Product first task, accessibility/focus/selection and visual acceptance |
| DQ9 What happens to failure after partial adoption? | Expose exact completed stages and use explicit remount/restart fallback when supported | Attempt graph rollback only after independent evidence of reversibility | Side effects, setters that throw, schema migration and receiver authority |

## Costs are for qualification, not a hidden implementation commitment

| Candidate effort | Integration/production LOC estimate | Test/fixture LOC estimate | Complexity /10 | Expected reliability in the stated scope /10 | Confidence /10 |
| --- | --- | --- | --- | --- | --- |
| Released-SystemJS binding probe | 0 | 216 maintained TS measured; generated output separate | 4 | 8 | 9 after native 2/2 within narrow scope |
| Two-tab real-host SW adoption and delayed-asset probe | 0 if existing host fixture reusable; otherwise do not build yet | 250–450 estimate | 5 | 7 | 6 |
| Scoped-registry/style ownership browser matrix | 0 | 150–300 estimate | 4 | 7 | 7 |
| Production publication/retention service | OPEN | OPEN | OPEN | OPEN | 3 until owner constraints |

Scores are engineering judgments, not measured failure rates. The future probes
are qualification requirements, not new work already authorized or reported run.

