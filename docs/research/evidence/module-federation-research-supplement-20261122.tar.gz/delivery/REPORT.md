# Web delivery, module rebinding and deployment consistency

Status: completed research and bounded native probe, 2026-11-22. Nonnormative;
owner choices remain OPEN. SystemJS native profile: 2 tests passed in one attempt.
Parent owns repository commits/publication.

## What changed the reuse assessment

**SystemJS includes a deliberate rebinding primitive.** Successful `delete(url)`
returns a function; after reimport it reattaches existing importer setters. It
does not alter an escaped old namespace or arbitrary captured function. The
callback success result is undefined; its guards return false. The released source
has no catch/rollback around the setter loop, so all-or-nothing graph replacement
is not established. Official API prose still says Boolean, while published
@types/systemjs 6.15.4 describes the callback. Upstream PR #2020 confirms intent,
and the published 6.15.1 Node bundle matches the source. [D02–D05, D18]

This is a useful reusable primitive, not grounds to adopt SystemJS or promise
general hot replacement. The native probe with real Rollup output confirmed the
live-importer/retained-reference boundary and pending-evaluation guard. [D26]
The old failed-link deletion issue #2286 was fixed by #2291 in 2020; it is
historical evidence, not a new defect. [D06]

**Native and SystemJS import maps are not interchangeable update mechanisms.**
Current HTML permits multiple maps but preserves conflicting prior mappings and
drops additions affecting already-resolved specifiers. Native module identity is
URL plus type within the relevant document/worker module map; changing an entry
query creates another module identity, not an
automatic rewrite of its dependency URLs. SystemJS composition can overwrite
mapping entries, while evaluated records/bindings remain separate. [D01, D07]

Current HTML also supplies per-URL import-map integrity metadata, including
descendant fetches. Entry identity alone does not cover the transitive graph;
the selected host's integrity/manifest support needs its own qualification. [D01]

## Keep the observable stages distinct

| Stage | What evidence establishes | What it does not establish |
| --- | --- | --- |
| Artifact published | Chosen bytes are addressable with recorded identity | Every client sees the selector or can fetch every delayed asset |
| Name registered/resolved | A future request chooses a URL/container | Existing evaluated exports change |
| Module loaded/evaluated | Executable namespace or module instance exists | Plugin prepared or UI useful |
| Importer rebound | Existing loader-managed setter receives replacement | Escaped references or physical resources reclaimed |
| Plugin mounted | Lifecycle integration reported success | Correct user-visible behavior or migration completion |
| Host adoption observed | A consumer-specific readiness assertion passes | Fleet convergence |
| Retired generation reclaimed | Owned resources and references are released by the relevant owner | Old external writes are impossible without receiver fencing |

These are analytical boundaries, not proposed public interfaces. Product evidence
must name which stage succeeded. Source pointers do not replace native host tests.

## Deployment publication: reuse the publisher, verify its concurrency boundary

import-map-deployer 7.0.0 provides existing publication/IO machinery. Its modify
path holds an in-process rwlock while reading, changing and writing the map.
The default S3 adapter performs getObject/putObject without deriving an If-Match
precondition from the fetched ETag; optional JSON and JS outputs use separate puts.
Therefore multi-instance publication and two-representation atomicity are not
established by the source. A custom IO adapter may supply stronger guarantees.
No race has been executed or claimed as a current production incident. [D12–D13]

S3 single-key updates are atomic and strongly read-after-write consistent, but
there is no cross-key transaction. Ready conditional-write primitives already
exist: If-Match and If-None-Match. Use the selected storage/authority mechanism
rather than creating a new distributed lock protocol. [D14–D15]

Transfer recommendation, still OPEN: publish an immutable release closure,
validate its reachability/integrity, then update a selector through existing
canonical authority. A selector commit, client adoption and old-asset retention
are three different obligations. Don't route delayed A dependencies through a
mutable B-only selector. Retention horizon, offline allowance and forced-reset
policy require owner decisions.

## Service Workers: activation is not application adoption

The specification separates installation, waiting, activation and per-client
controller change. Failed installation does not replace the active worker.
skipWaiting bypasses waiting for old clients; it is not a global page transaction.
Its promise is not proof of all pages remounting. Controller change is queued for
each client; old page objects remain until their own lifecycle changes. Activation
cleanup must tolerate interruption; the draft explicitly warns it may not finish.
[D09; draft behavior is not a tested browser compatibility claim]

Workbox already exposes waiting/controlling and update messaging. Its official
recipe includes a user prompt, messageSkipWaiting and reload after control change,
with transient-state persistence left to the app. Reuse this capability if the
chosen host needs Service Workers; do not build another update notification/state
watcher merely for plugin reloading. An externally triggered update can arrive
from another tab, so observation cannot be limited to the initiating action.
[D10–D11]

Open policy: keep the waiting worker until clients leave, accept coordinated
reload, or support explicitly compatible mixed page/worker versions. None is
selected by this report.

## Deployment affinity: positive reuse, with a cross-tab limit

Vercel Skew Protection routes eligible tagged requests to a deployment. Its shared
cookie can move an old tab when another opens; full-page navigation uses latest
even with a deployment ID. Cross-origin IDs are ignored unless Allowed Domains
permits the origin. Missing/expired deployments fall back to the domain's current
deployment. Framework request tagging matters. These are directly opened living
documentation claims observed 2026-11-22, not a deployed-provider test. [D16]

The transferable idea is to carry artifact generation identity across relevant
requests and retain the referenced generation. Shared cookies are not sufficient
for independent per-tab adoption. This is an inference, not an implemented adapter.

## Existing DOM and styles need their own ownership boundary

Scoped custom-element registries shipped in Chrome/Edge 146 and are present in
the HTML standard. Different registries can hold implementations under the same
tag. One registry rejects duplicate definitions, however, and an initialized
node's registry cannot be changed. Upgrade does not replace an already-custom
element. Scoped coexistence therefore supports a new owned subtree/instance;
it does not migrate the old instance. [D19–D20]

The CSSOM draft restricts constructed stylesheet adoption to the constructor
document. Inference: a shared mutable stylesheet is shared state, so changing it
can affect multiple adopting roots. Generation cleanup must distinguish owned
sheets/links from host/shared ones. Shadow styling is not script isolation. [D21]

An iframe supplies a fresh document/global registry boundary. Origin, realm,
agent and process are distinct; same-origin actors share trust authority. Do not
upgrade “fresh iframe” into “separate killable process,” or count closing it as
revoking already-sent external effects. [D25; effect-fencing is a transfer inference]

## Cache and rollout limits worth testing together

CloudFront recommends versioned filenames for frequent changes and notes that
edge invalidation cannot force browser/intermediary-cache expiry. Immutable URLs
should identify the supported release closure; selector freshness is separate.
[D24]

Workbox 7.4.1 supplies useful mechanisms with precise limits:

- messageSkipWaiting returns void. A controlling event can describe an external
  controller change; the instance's own controlling promise resolves separately.
  The external path's event carries the instance's tracked worker, so identify the
  actual controller through navigator.serviceWorker.controller.
- PrecacheController.activate removes keys outside its expected set. This is
  intentional cleanup, not per-client old-generation retention. [D22–D23]

Derived scenario, **not reproduced here**: an A tab retains old evaluated code;
another tab triggers B activation; B removes A precache assets; origin retention
has also removed A's unfetched lazy chunk. A's next import can fail. Activation
does not prove all old tabs adopted B. Supported-generation retention, compatible
routing and explicit reset/recovery are owner alternatives.

| Layer | Ready mechanism | Local success does not imply |
| --- | --- | --- |
| Deployment selector | Existing authority, publisher, storage conditional write | All tabs observed the release |
| CDN/HTTP artifacts | Versioned filenames and cache semantics | Old lazy assets remain forever |
| SW precache | Workbox revisioning and activation cleanup | Per-tab generation retention |
| Browser module map | Native identity/cache | Old exported objects retired |
| SystemJS registry | Public delete/rebind callback | Atomic graph/UI/state replacement |
| Custom elements/styles | Scoped registry, owned subtree/sheets | Existing instances migrate |

## Where to prevent accidental reinvention

| Proposed work | Reuse to evaluate first | Preserve this boundary |
| --- | --- | --- |
| Fetch, instantiate, cache, rebind | Native ESM, SystemJS, sibling MF profile | Runtime capabilities differ |
| Mount/unmount and route lifecycle | single-spa, existing framework integration | Unload/remount and module records differ; prior research covers timeout noncancellation [D08] |
| SW observer/update messaging | Workbox window | External changes and own promise settlement differ |
| Manifest publisher/provider IO | import-map-deployer | Process mutex, provider CAS and authority differ |
| Publication conditional write | Existing canonical DB/provider primitive | Do not create a second authorization system |
| Generation affinity | Hosting skew protection | Tagged requests, cookies and navigation differ |
| UI namespace coexistence | Native scoped registry/framework scopes | Does not replace current instances |
| CSS disposal | Framework style ownership and scopes | Shared sheets need shared ownership |

## Qualification and owner choices

The native input uses SystemJS 6.15.1 and published declarations, TypeScript 7.0.2
ESM output, then Rollup 4.68.8 System.register generation. TS7 removed legacy
module:System output; no old compiler/plugin was run. Exact lock/compiler audit,
strict checks, generated hashes and peer readiness correction live in probe/.
Root froze and pushed inputs at 4a95ba3026ad4721ed6585a38fbd192e5aba133d before
authorizing execution. One native attempt passed 2/2 on Node 24.22.3; RUN.json,
RESULTS.md and unchanged raw output retain the receipt. [D26]

OPEN-QUESTIONS.md contains owner options; QUALIFICATION.md separates the two
completed SystemJS tests from future real-host/deployment/browser gates. Single-tab
adoption, per-session/per-tab affinity and fleet convergence are distinct promises.
No loader, provider, SW strategy, UI isolation, retention horizon or public API
is selected here.

Source IDs resolve through sources.json. Every source was retrieved 2026-11-22.

