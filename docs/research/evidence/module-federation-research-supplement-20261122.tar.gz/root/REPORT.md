# Additional industry mechanisms: readiness, object replacement and delivery

Observed 2026-11-22. Source research only; **no native Envoy, Unreal or Angular
execution**. Recommendations below do not settle owner choices or introduce a
public API. Sources are indexed in `sources.json` and findings in `findings.json`.

## Envoy: separate resource acknowledgement from readiness

Envoy stable **1.40.2**, commit
`b2d89e0ae53916f28770771fbdd49c5c99c5c5a2`, documents an ACK as resource validity
plus intent to apply; application may still fail. A NACK can coexist with some
accepted resources. Response nonce is scoped to one stream and resource type;
it is not a durable application epoch. Independent xDS resource updates are
eventually consistent. The documented dependency rollout adds the new cluster
and endpoints, switches dependent routing, then removes the old cluster. Listener
and cluster warming provide useful readiness machinery, while routes are not
warmed in the same way. [R01]

**Transferable consequence:** a reusable update result should distinguish the
owner's accepted request, prepared dependencies, routing publication and observed
service. Reuse Get Modular plans and adapter readiness; do not infer a global
transaction or create another graph compiler. A durable generation/fencing token
cannot be replaced with a transport correlation nonce. The exact status vocabulary
and public contract remain an owner decision.

### Positive process handover and its limits

Envoy's new process initializes before accepting sockets and instructing the old
process to drain. Existing connections stay with the predecessor; they complete
or are closed, rather than being transferred to the new process. Parent shutdown
and drain deadlines are separate. This mechanism is not supported on Windows,
and reducing concurrency can drop requests queued on old worker accept sockets.
[R02]

**Transferable consequence:** process replacement can preserve service without
pretending to migrate every live execution. An adapter must state which unit
retains affinity and what its actual shutdown observation proves. Which updates
may wait, interrupt or restart remains open.

### Source-version trap corrected during investigation

The current development documentation describes `wait_for_warm_on_init` using
broader CDS ACK gating language. The released 1.40.2 protobuf describes its use
for DNS/Redis initialization. We did not transplant development-head semantics
into the stable release claim. The stable xDS acknowledgement and dependency
ordering statements above stand independently. [R01, R03, R04]

## Unreal: binary patching and live-object replacement are distinct

Epic documents Live++ integration for editing, Play In Editor and desktop builds
attached for debugging. It separately describes reflected-object replacement.
Constructor defaults in `.cpp` do not update existing instances. Retained pointers
and caches need update/invalidation hooks, and lingering old instances can cause
destructor conflicts during shutdown. This is a useful working implementation of
state-aware development updates with explicit boundaries, not evidence for
arbitrary production plugin transactions. [R05]

The unversioned page displayed Unreal 5.8 in search, then 5.9 on direct opening.
Record it as living documentation observed on this date; do not label a particular
engine binary as tested or pin it by the page title alone.

**Transferable consequence:** let a framework adapter describe which instance
state it can preserve and which caches/references need replacement. Retaining a
component identifier is not a migration proof. Preserve previous editor evidence
about history effects and codecs; no universal object migration engine is proposed.

## Angular: a positive application-version mechanism, with explicit exceptions

Stable **22.3.0**, commit `53ef99a543e037b64c596e9c3e147cb365062cea`, provides a
manifest-defined asset version and client-to-version assignments. Multiple tabs
can use different cached versions. Required asset groups are initialized before
the version is ready; optional/lazy resources are not thereby guaranteed present.
Only resources covered by the manifest hashes receive that integrity guarantee.
External or unhashed data follows a different caching policy. [R06, R07, R09]

The driver selects the client's assigned version, treats navigation/resulting
client identity separately, and associates a worker-script request with its
requesting client. Cleanup computes versions still used by live clients and
retains the latest version. Its own comment notes that clients in the browser
back-forward cache may be missing from the active-client query. This is a
source-level limit, not a newly reproduced Angular defect. [R08]

The communication API separates detection, readiness, installation failure and
unrecoverable client state. Activating a new version without reloading can mix an
old executing shell with new lazy resources. The official failure example is
cache eviction of an old lazy chunk after its server copy has been removed;
reload is then required. [R10]

**Transferable consequence:** reuse an existing service-worker/version mechanism
where the host already owns one; otherwise qualify a narrow delivery adapter.
Artifact availability, application data retention and live client references are
different holds. A cache is evictable, so server retention and a visible recovery
path must match the promised support window. Do not adopt Angular or invent a
universal offline mode merely because the algorithm is useful.

### Security-response headers have a separate update boundary

Released Angular documentation explains that changing only the service-worker
response headers does not replace a byte-identical installed worker. It recommends
changing the registered script URL when those headers change. Thus a manifest or
asset rollout cannot be assumed to refresh the worker's execution policy. [R09]

This is source evidence for one delivery boundary, not a reason to implement
custom service-worker registration or a new security policy manager.

## Candidate architecture seams justified by this evidence

These are **design recommendations**, not accepted interfaces or package names.

| Separation | Concrete alternative it preserves | Existing owner to reuse |
| --- | --- | --- |
| Artifact/version selection vs evaluated module | Native immutable import, Federation entry or SystemJS registry; different cache and side-effect boundaries | Chosen loader and artifact/admission mechanism |
| Compatibility group vs loader registration | Shared service identity, standalone dependency island or replaceable realm | Get Modular composition plus product compatibility declarations |
| Readiness vs publication | Loader ACK, warmed executor and useful UI/service become separate observations | Runtime/framework adapter and complete library operation |
| Live invocation vs generation selection | Old streams or callbacks can retain their original owner after new routing is selected | Executor/resource scope and product effect receiver |
| Canonical state vs view/runtime state | Durable product data versus editor history, selection, caches and transient instances | Product state ports and supported framework codecs |
| Artifact availability vs physical cleanup | Open tabs, lazy imports, recovery and unsupported expired clients have explicit bounds | Storage/deployment adapter and observable retention holds |
| Application update vs host update | Renderer changes, bridge/IPC changes, process restart and signed application update | Electron or other platform mechanism |

The library still supplies one complete operation that coordinates these facts.
Consumers should not reconstruct orchestration from a pile of low-level hooks.
Avoid a generic transaction promise across all these owners: the source mechanisms
do not supply it. Failure results need to report what actually changed and what
remains live, with compensation/recovery options constrained by state and authority.

## Questions to cross-review

1. Could preparation run candidate code with externally effective authority?
   Which existing realm/receiver boundary prevents premature effects, and what
   useful same-realm profile is still possible?
2. Does the proposed update group include consumers that depend on one shared
   token or runtime instance, even when semantic versions appear compatible?
3. Does the UI report desired version, currently selected version and the actual
   displayed version separately when tabs/regions are intentionally deferred?
4. What can rollback truthfully mean after durable schema changes or external
   effects? Which narrow reversible case can the first profile actually promise?
5. Which owner bounds artifact/state/version retention, and how does an expired,
   suspended or offline client re-enter safely?
6. Are status names backed by receipts from the relevant owner, including useful
   UI activation, physical executor exit and persisted final state?

No contested answer is selected. The final owner matrix should prioritize the
choices needed for the first vertical slice and defer speculative integration.
