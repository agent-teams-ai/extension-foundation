# Module delivery and live update boundaries — research plan

Observed: 2026-11-22, Europe/Kiev. Parent repository source starts at
`7d9c6ab06b296feb286dcf0c6edb510be8ac4105`; current organization guidance is
`0b44c64c824f536bd1b085341e7669bcc64ef124`.

## Authorized scope and decision discipline

The owner requests deeper Module Federation and adjacent industry research,
architecture preparation and verified findings. Contested runtime, sharing,
restart, delivery and state policies remain open. Recommendations must name
alternatives and the evidence that favors them; no recommendation becomes an
accepted public contract. Previously accepted TS-first library direction,
existing mechanism owners and canonical state authority remain in force.

## Parallel investigations

| Lane | Questions | Owned mechanism boundary |
| --- | --- | --- |
| Federation | Actual shared-instance selection, forced registration, cache/reference behavior, generated remote identity, failure during preparation | Existing webpack/Rspack/Module Federation loader and runtime; no substitute loader |
| Desktop | Renderer, preload bridge, main, utility process, native addon and packaged application update scopes | Electron/Node lifecycle, IPC and updater; actual resource and authority owners |
| Web delivery | Import-map resolution, SystemJS relinking, lifecycle helpers, service-worker takeover, old lazy assets and document/realm state | Browser, existing module loaders, Workbox/deployer mechanisms |
| Root synthesis | Dependency-ordered rollout, readiness/acknowledgement semantics, object replacement, invariant/choice split and owner questions | Existing Get Modular plans, Resources, product grants/state and narrow adapters |

## Work and review sequence

1. Read existing authority and prior evidence; preserve its original identities.
2. Record primary sources, current release versus development-head differences,
   exact source pins, positive guarantees and specific limitations.
3. Commit and immediately push an initial research checkpoint.
4. Review any bounded native experiment before implementation and again before
   execution; use strict TypeScript >=7.0.2 and real published mechanisms.
5. Retain original failures separately. Do not rerun unchanged older E2E or
   count source inspection as executed behavior.
6. Critique the combined architecture from dependency, failure, state, trust,
   delivery and user-control perspectives. Turn unsupported claims into open
   qualification cases, not additional speculative subsystems.
7. Present a small prioritized set of owner questions with 2–3 alternatives,
   the preferred option and remaining uncertainty. Preserve these in OD-003.
8. Run the repository documentation gate; audit actual final-head checks and
   carry forward only byte-identical qualified native inputs.

## Proportional estimates

These are planning judgments, not measured reliability. This investigation
introduces **zero production/library LOC** and no public API.

| Work | Integration/production LOC | Fixture/test LOC | Complexity /10 | Reliability in bounded scope /10 | Confidence /10 |
| --- | --- | --- | --- | --- | --- |
| Source-backed reports and decision alternatives | 0 | 0 | 4 | N/A | 8 |
| Potential generated-remote Federation experiment | 0 | 450–850 | 5 | 8 | 7 |
| Potential released SystemJS semantics experiment | 0 | 220–380 | 3 | 8 | 7 |
| New Electron/Envoy/Unreal runtime execution | 0 | 0 planned | N/A | Unqualified | N/A |

Fixture bounds are incremental, conditional on a question that can change the
choice, and exclude CI/release maintenance. These are not estimates of the
complete standalone library. A public architecture cannot guarantee that all
future refactoring disappears; the target is explicit variation points backed
by concrete alternatives and avoided coupling.

## Expected outputs

Governed research synthesis, exact source/findings ledgers, named reuse warnings,
review dispositions, optional frozen native inputs/results, owner alternatives
and a portable supplement to the prior standalone packet. Root alone changes
the repository, commits and pushes. Native production adoption and merge remain
outside this research checkpoint.
