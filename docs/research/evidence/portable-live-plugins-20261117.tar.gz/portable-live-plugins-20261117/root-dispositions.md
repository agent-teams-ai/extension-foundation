# Root review dispositions

Date: 2026-11-17. Root investigator reviewed all lane conclusions and six
round-one/round-two critique artifacts. All material findings were accepted
or narrowed explicitly; no research-blocking objection remains.

| Finding | Disposition and final location |
| --- | --- |
| Selection and asynchronous borrow can race retirement | Accepted. Concrete update step4 now requires protected selection/admission/retention or owner-managed reservation/revalidation. |
| Streams outlive the call that returns their handle | Accepted. Required retention spans consumption/finalization under the configured policy. |
| Coordinator's current binding can sound like a competing active head | Accepted. Ownership report now says delegated implementation of one consumer selection binding; synthesis prohibits a second authority. |
| Shared driver could be designed before subtracting existing mechanics | Accepted. Application and root reports subtract GM kernel, Host, native scopes and fitting loaders/executors; no-new-package is a valid result. |
| Ordinary library conformance was conflated with stable public SPI | Accepted. Root/browser use independently authored external fixtures for ordinary boundary; stronger SPI gates remain distinct. |
| Internal seam allowed postponing portability | Accepted. Same-delivery real consumer and external conformance, without copied product-local incubation. |
| Durable receipt is not universal | Accepted. Ownership report makes durability dependent on recovery-across-failure contract; root stays neutral. |
| Cordis preserves Fiber, not old Component binding | Accepted. Corrected in synthesis; current/source filesystem dependency and prerelease pins kept separate. |
| Retained module records need the precise primary source | Accepted. Added maintainer issue243, inspected by root, rather than attributing this fact solely to current README. |
| go-plugin historical TODO overstated general current failure | Accepted. Source conclusion relies on actual controller Stop path; TODO is historical context. |
| All categories could be forced into activation hooks | Accepted. Runtime and root reports retain category-appropriate lifetime/evolution contracts, including pure descriptors. |
| P/I/T rows could imply measured total delivery | Accepted. All bands are new non-overlapping LOC; modified existing LOC, docs/release and named broader features are unmeasured/excluded. Scores are planning judgment. |
| Effect source candidate statement became stale | Updated only in the new dated record: registry latest0.1.1, qualified peer4.1.4; kernel remains private. Original Nov14 archive untouched. |

The application and ownership round-two reviews inspected root SHA256
917a2ddde5eca883f1ec0494da4d9acad37ead0acd4c18071783946b65c1a51f.
The runtime reviewer additionally checked source/spelling corrections and
inspected e5235777e909c7cdb4bee63dd90c219673650f5032724ada21657512c34b50cb.
Later root edits add the already proposed external document-server fixture,
review/validation navigation and this disposition record. Final file identities
are separately bound by the validation receipt; these review hashes are not
misrepresented as hashes of later presentation changes.

The external renderer example is a proposed acceptance fixture, not a real
adopter. No plugin runtime was implemented or executed in this follow-up.
The ordinary-update interruption TODO and all existing authority boundaries
remain intact. Research completion is not production adoption or merge approval.
