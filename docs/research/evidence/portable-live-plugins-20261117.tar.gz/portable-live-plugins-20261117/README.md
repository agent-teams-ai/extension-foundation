# Portable live plugin research evidence — 2026-11-17

Client date: 2026-11-17, Europe/Kiev. Source retrieval began 2026-11-16 UTC.

This packet supports Extension Foundation Draft PR55's new portable-library
research. It is source/document inspection, architectural inference and
independent review, not a new runtime qualification or package release.

## Contents

- application-mechanisms: OpenCode, Letta Code and Pi implementation traces,
  exact source ledger, two independent review rounds.
- runtime-mechanisms: Cordis, HashiCorp go-plugin, Extism JavaScript SDK and
  VS Code; published/source distinction, source identities, two review rounds.
- ownership-and-library: current Get Modular, Effect and EF ownership,
  registry observation, incremental cost alternatives, two review rounds.
- browser-mechanisms: single-spa, Vite and Module Federation source traces,
  release metadata and explicit lifecycle limitations.
- root-dispositions.md: reconciliation of reviewers' substantive findings.
- validation: original documentation spelling failure and validation scope.
  The full protocol result and raw log are retained in the adjacent validation
  JSON after completion to avoid a self-referential archive.

Only selected reports, ledgers, reviews and receipts are included. Temporary
third-party inspection downloads, node_modules, credentials and workspace data
are excluded. Source locators and hashes permit independent retrieval; source
inspection is not falsely labelled as test execution. Existing tests cited in
reports were read, not rerun. Source package versions do not establish release
publication or distribution/source byte equality.

The new root synthesis is governed in the repository's docs/research directory.
Its exact reviewed hashes appear in the review files. Later root changes only
clarify already accepted findings, add a proposed external-consumer example,
repair spelling/source navigation and record validation. The final repository
validation receipt binds the final governed Markdown hashes.

The original live-plugin-evolution-20261114.tar.gz remains unchanged, SHA256
0469a42a636150beaedde54969359cd1d342b728fe2bdd717db5d75c58cf1d29.

## Authority

The owner requested portability outside Agent Teams and live evolution across
plugin categories. Ordinary-update interruption remains explicitly open.
Research does not select a runtime, duplicate a kernel/Host, publish a public
SPI, migrate production, merge the draft or create a new repository.
