# Browser lifecycles and development HMR: reusable mechanisms and hard limits

Observation: 2026-11-17, Europe/Kiev. Root investigator. This is pinned source
inspection and official documentation, not newly executed runtime evidence.
The adjacent source-identities.json records release/source separation and Git
blob identities. The report proposes transfers; it does not select an update
policy or approve a package.

## Why these cases change the library design

The browser makes several kinds of ownership visible that a server-only plugin
example can hide: rendered DOM, framework roots, timers, subscriptions, loader
caches, singleton dependencies and user state. A useful reusable library must
name which of these it owns. A generic update callback cannot infer all of them.
Three projects provide complementary reusable mechanisms: single-spa coordinates
application lifecycles, Vite propagates source updates to accepting boundaries,
and Module Federation loads remote code with shared dependency resolution.
None of the inspected mechanisms alone is a transaction that transfers an
arbitrary running application to new code.

## 1. single-spa: a small lifecycle protocol with framework adapters

### Current identity

The npm latest tag is 6.0.3, published on 2024-09-29; beta is separately
7.0.0-beta.13. The latest non-prerelease GitHub release is v6.0.3. Its annotated
tag resolves to b619c26f0a39bbc8f175805a361a88a22fbd6d9b. Current main is
297483c11265050542d7ef107d14c44936c51883. The four lifecycle files inspected
below have the same Git blob identities at the release and main; this is a
bounded source comparison, not a published distribution execution. License MIT.

### Exact mechanism

Registration stores a named application and a caller-supplied loading function.
The caller determines when the application should be active. The lifecycle
sequence separates loading, bootstrapping, mounting, unmounting and unloading.
Framework helpers can implement those boundaries for different UI frameworks.
That is useful portability through a coherent domain contract: UI mounting is
a real shared concern. It does not require the framework to own every business
extension point. [S1, S2]

`unloadApplication(name, { waitForUnmount: true })` records an unload request
and returns its promise. The runtime waits for a later eligible unmounted
state. Without that option, `immediatelyUnloadApp` waits for an active mounting
cycle, invokes unmount, then unload, and schedules routing again. Unregistering
uses the immediate path and removes the application registration. This is an
explicit timing choice, not an automatic inference from a changed file. [S3]

`toUnmountPromise` asks child parcels to unmount and still attempts the parent
cleanup if child cleanup fails. `toUnloadPromise` accepts NOT_MOUNTED or
LOAD_ERROR, coordinates repeated unload requests, and calls the unload
lifecycle. Successful completion deletes the stored lifecycle functions and
sets NOT_LOADED. An unload error records a broken status and rejects the
request. Thus code-loading state and application activation state remain
distinct facts. [S4, S5]

The timeout implementation supplies an especially useful negative example.
`reasonableTime` invokes the original lifecycle promise and attaches timers.
By default, expiration logs and continues waiting. With `dieOnTimeout`, it
rejects the wrapper promise; the inspected code supplies no cancellation or
termination primitive for the original lifecycle. A failed or timed-out
unmount cannot therefore certify that user callbacks or external effects have
ceased. [S6]

### What transfers, what does not

Reuse the separation of framework-neutral lifecycle intent from narrow
framework adapters, explicit asynchronous completion, and independent
registration/loading state. For a UI consumer, first use an existing renderer
or single-spa adapter instead of inventing another renderer lifecycle.

Do not generalize unmount into physical unload. Official documentation states
that unregistering neither removes SystemJS registry entries nor erases code
and frameworks from browser memory. It is the application lifecycle's job to
dispose its DOM, listeners and subscriptions. Loader-cache eviction, framework
root cleanup and application-state transfer require different owners. [S1, S2]

For the proposed library, a UI adapter may truthfully report that a component
root was unmounted while retaining a diagnostic that code remains cached.
There is no reason to give pure data contributions bootstrap and unmount hooks
merely because UI extensions need them. This is interface segregation based
on actual capability requirements.

## 2. Vite: module acceptance is not an upgrade transaction

### Current identity

The stable GitHub release and npm latest are v8.3.8, with release target
b39e6e63dcbfc3cf4be871acf3554efbd6d0e268. Main is
9a8d1a98922c5e445e8a618b8c27f84c63b9fbff, v8.4.0-beta.1. The inspected
`packages/vite/src/shared/hmr.ts` is the same blob
6e2ef7de0de852aec6417e9d91b60556cc2f834b in both. License MIT. No Vite
application, plugin or test suite was executed in this research.

### Exact mechanism

`HMRContext` registers accepted dependencies, cleanup functions and listeners.
When a module acquires a new context, stale callbacks and its old custom event
listeners are replaced. A data object survives updates for the same module
path. This supplies explicit local continuity, not an automatic serializer of
arbitrary state. [V1, V2]

`HMRClient.queueUpdate` starts fetches and applies their callbacks in the
received order. `fetchUpdate` first captures the qualified acceptance callbacks.
For an accepted update it then awaits the old disposer **before** importing the
updated module. If import fails, the error is logged; the later acceptance
callbacks receive an undefined value for that update. The source contains no
reconstruction of the effects that the old disposer already removed. A throwing
disposer is also outside that import catch. Thus a single failed source change
does not carry a general last-known-good-resource guarantee. This is a source
trace, not a reproduced application failure. [V2]

`prunePaths` invokes dispose and prune handlers and deletes retained data in a
finally block. `clear()` clears the client maps; it does not invoke the stored
resource disposers. Those methods therefore have different lifetime semantics
despite both making bookkeeping smaller. [V2]

The official API explains that acceptance does not rewire the originally
imported module. A boundary re-exporting a dependency must update its own
bindings, and importers beyond that boundary are not automatically notified.
`invalidate` propagates an update when a boundary cannot accept it. The HMR API
is designed for development tooling and can be removed from production builds.
These are useful explicit limits, not shortcomings relative to its purpose.
[V1]

### What transfers, what does not

A stable boundary must select a revision for a defined operation. Long-lived
raw references handed directly to consumers cannot be silently rebound just
because the module registry now names a new object. A consumer can acquire a
generation-bound capability for one operation, or use a stable facade whose
operation admission deliberately chooses the generation. Which boundary is a
turn, request, workflow or render is consumer policy.

Vite should remain the development file-change and module-loading integration
where already adopted. A production replacement mechanism should consume its
own admitted candidate and declared lifetime semantics; it should not expose
`import.meta.hot` as the universal production plugin contract. Likewise,
adopting a bundler-neutral plugin format would solve build integration, not
the live resource or state handoff problem.

## 3. Module Federation: remote loading and shared identity

### Current identity

Current main remains d4a31960d20a717626af43be59aab0881c7b6cc0, the same pin
used in the earlier research. `@module-federation/runtime-core` source and npm
latest both say 2.9.3. Registry metadata and source were inspected separately;
their matching versions do not prove byte equality. The next npm tag is an
unreleased-development-labelled build, not the stable version. License MIT.

### Exact mechanism

The runtime can create an independent host instance, register remotes, load
exposed modules and coordinate shared dependencies. This is a reusable library
surface available without a particular product's business model. [M1]

In `RemoteHandler.registerRemote`, an already registered remote with
`force: true` is removed before the new remote is normalized and appended.
The removal updates the host's registration, manifest/snapshot/loading caches,
remote globals, module cache, shared-use records and relevant runtime instance
records. Loaded shared dependencies with other recorded users are treated
differently from unused shares. Errors inside removal are caught and logged.
This is important real cleanup logic, but it does not constitute an atomic
candidate-readiness/publication transaction. [M2]

No inspected path unmounts a React root, closes an application socket, settles
an arbitrary Promise, transfers form state or makes escaped exported objects
disappear. Those are outside the loader's authority. Replacing React itself as
a shared singleton would additionally require respecting the owning renderer's
identity constraints; generic cache replacement cannot establish that. This
last statement is an architectural consequence, not a new test result. [M2]

### What transfers, what does not

Use its existing remote loading and dependency-sharing mechanism when that is
the selected consumer integration. Keep the generation's declared dependency
contract coherent: a remote manifest revision alone is not proof that every
shared module, dynamically imported descendant or external service is frozen.
An adapter must state the exact closure it controls and which collaborators are
stable host services.

Do not combine Module Federation, Cordis and Get Modular as co-equal resolvers
of the same graph. They can own distinct layers only if one resolves remote
code availability and another composes a closed declaration graph, with an
explicit boundary and no competing binding decisions. If the boundary cannot
be made clear, select one mechanism rather than accumulate containers.

## 4. A portable contract should expose truthful facts

These cases support an architectural inference: the shared boundary should
describe an update operation and its observables, while adapters implement
runtime-specific loading and cleanup. It should not promise a universal plugin
object with every possible hook.

| Fact | Why it needs a distinct observation |
| --- | --- |
| Candidate obtained and composition checked | Loading and graph validity do not prove resources are ready. |
| Candidate ready for the named role | UI, tools and exclusive connections have different readiness predicates. |
| Future work selects a generation | This says nothing about already admitted work. |
| New work admission is closed | Existing callbacks and effects may continue. |
| Previously admitted work is settled | Timed-out promises and cooperative cancellation need evidence. |
| Resources are released | Bookkeeping deletion is insufficient. |
| Execution container has exited | A process/worker fact; unavailable for an arbitrary in-process module. |
| Module code is reclaimable | Separate cache/reference/VM question; often cannot be promised. |

Those are contract obligations to qualify, not a requirement for eight new
interfaces or eight separately persisted state machines. Existing product
authority remains the sole operation owner. The private GM lifecycle kernel
and a native Effect scope can supply different non-competing facts under that
owner; a wrapper must not duplicate their refcounts or invent a second active
head. Plain TypeScript consumers should not need Effect types in their domain
ports, while an Effect-native adapter must retain its error/cancellation
semantics rather than flatten them through an unqualified Promise boundary.

## 5. Design implications for SOLID, DRY and Clean Architecture

- Single responsibility: composition, executable loading, resource lifetime,
  selection policy and artifact admission change for different reasons.
  Give each one existing owner; do not build a universal manager to hide them.
- Open extension: support another runtime through a narrow execution adapter
  only when a consumer needs it. Keep product tool schemas and UI contracts
  outside the shared mechanism.
- Substitutability: an adapter whose close merely requests cancellation cannot
  satisfy a contract requiring observed physical termination. Qualify adapters
  by behavior, not by matching method names.
- Interface segregation: a read-only descriptor has no reason to implement
  migrations, process termination or UI mounting. Model optional operational
  abilities only when their use cases exist.
- Dependency inversion: update coordination consumes owner-supplied operations;
  Node loaders, browser renderers, native scopes and subprocess managers live
  outside the policy-free mechanism. Do not introduce a port for every function
  merely to make the directory tree look architectural.
- DRY: reuse the existing composition graph, admission owner and refcount.
  Repeated syntax does not justify merging semantically different operations.
  A small Node adapter and a small browser adapter can legitimately differ.

## 6. Decision-changing qualification questions

Before extracting an ordinary public library, prove one useful real consumer
and an independently authored external conformance fixture in that delivery.
The stronger independent implementations required for a stable extension SPI
are a separate gate. For a second, deliberately
different consumer, test whether the shared coordination actually survives
without Agent Teams types, catalog access, organization credentials or its
database schema. This is a portability proof, not a request to create a new
repository or a new runtime in this research.

The highest-value failures are: candidate import after old cleanup; disposer
failure; stale candidate completion after a newer selection; a delayed call
holding an old exported object; removal during an active UI mount; a timeout
that rejects while effects continue; and repeated reloads retaining cached
module code. Test expectations must state the selected adapter/profile.
Ordinary-update interruption remains open: both explicit deferral and explicit
interruption are possible consumer policies. A conformance suite can prove
that a configured policy is respected without choosing one for the owner.

## Primary sources

- S1: https://single-spa.js.org/docs/api/
- S2: https://single-spa.js.org/docs/building-applications/
- S3: https://github.com/single-spa/single-spa/blob/b619c26f0a39bbc8f175805a361a88a22fbd6d9b/src/applications/apps.js
- S4: https://github.com/single-spa/single-spa/blob/b619c26f0a39bbc8f175805a361a88a22fbd6d9b/src/lifecycles/unmount.js
- S5: https://github.com/single-spa/single-spa/blob/b619c26f0a39bbc8f175805a361a88a22fbd6d9b/src/lifecycles/unload.js
- S6: https://github.com/single-spa/single-spa/blob/b619c26f0a39bbc8f175805a361a88a22fbd6d9b/src/applications/timeouts.js
- V1: https://vite.dev/guide/api-hmr
- V2: https://github.com/vitejs/vite/blob/b39e6e63dcbfc3cf4be871acf3554efbd6d0e268/packages/vite/src/shared/hmr.ts
- M1: https://module-federation.io/guide/runtime/runtime-api.html
- M2: https://github.com/module-federation/core/blob/d4a31960d20a717626af43be59aab0881c7b6cc0/packages/runtime-core/src/remote/index.ts

Registry metadata was retrieved read-only from the npm registry for single-spa,
vite and @module-federation/runtime-core. No dependency was installed or executed
for these cases. Release identities and blob comparisons are retained in the
adjacent source ledger.
