# Round 1 independent review — runtime lane

Reviewer: live_runtime_patterns. Date: client 2026-11-17. Scope: the governed root synthesis, application-mechanisms/report.md and browser-mechanisms/report.md. Read-only review; no new broad research, dependency installation or code execution. Root's provisional runtime source links and cost table were known work in progress, not findings.

## Verdict

The synthesis preserves the user's all-category live vision while leaving ordinary-update interruption open. It makes the important distinctions between code identity, descriptor/executor coherence, resource retention, authorization, state migration and observed physical shutdown. Reusing existing components before introducing residual coordination is the correct direction. No architecture blocker was found; the following bounded wording corrections improve precision and keep the lane reports consistent with that direction.

## Concrete findings

1. **Cordis preserves fiber identity, not the old component binding.** In the synthesis's runtime-library section, change “registry preserves component identity” to “replacement preserves fiber identity and configuration.” `RegistryService.replace` changes the component-key forwarding/runtime mapping, and `Fiber._replace` changes the runtime while retaining the fiber. Preserving a component/export reference would be a different and stronger property; escaped old exports are explicitly a limitation. Verified against this lane's C2/C3 pinned source.

2. **Do not imply that extracting a new coordinator is already necessary.** The application report says the smallest coordinator should own transition records, candidate/active identities, publication and retirement bookkeeping, then favors extracting that coordinator with lower-level libraries underneath. It later says there must be one owner, but does not subtract the existing Host/kernel strongly enough. These are logical responsibilities to implement under the existing authority, reusing its records and transitions. The remaining reusable algorithm can be small or absent. Root's corresponding recommendation already handles this well. Requested the application lane qualify its wording rather than introduce another manager or new API.

3. **The go-plugin decisive fact is the invoked shutdown operation.** The synthesis accurately states that the gRPC controller calls `Stop`, which does not establish graceful inflight RPC completion. Phrase the nearby TODO as a source comment, not a generally verified claim that `GracefulStop` is currently broken. `Client.Kill`'s two-second wait occurs after protocol `Close`; the total shutdown path is not certified as two-second bounded. This lane's G1–G4 source pins support both points.

4. **Apply the ordinary-library conformance wording consistently.** The browser report asks for an independently authored “conformance implementation.” Narrow this along with root's already planned correction to an ordinary external consumer/conformance fixture unless a stable independent SPI is actually being proposed. A second production runtime or a new public-SPI gate should not become an accidental prerequisite for a modest reusable library. Independence should test the behavioral boundary, not duplicate a lifecycle authority.

## Checks that passed

- The application report distinguishes current main/dev implementation from unverified publication, and separates schema/executor snapshots from closure sealing, resource retention and cancellation. The Letta overlap concern is correctly marked unconfirmed, with a useful falsifier rather than an invented result.
- OpenCode fallback is described as constructing a new activation from previous code after teardown, rather than rollback to the exact previous live state. The ordered suffix policy is not promoted into a universal requirement.
- Pi self-update illustrates avoiding self-drain deadlock without forcing its agent-specific settled-turn policy onto ordinary projects.
- The browser report's release/main comparisons are bounded to inspected files/blobs. Vite is treated as development HMR; dispose-before-import and undefined replacement on failed import are distinguished from application rollback. single-spa timeout rejection is not mistaken for stopping original lifecycle code.
- Module Federation is positioned as loading/shared dependency machinery; renderer resources and escaped exports remain outside its authority. Composition and remote-loading layers are allowed only with explicit ownership, not co-equal graph resolution.
- The root operation sequence distinguishes preparation, selection, coherent admission and policy-dependent retirement. Its exclusive-resource and migration examples explicitly prevent overlap or pointer rollback from becoming universal promises.
- Effect/GM composition and native resource reuse remain distinct from artifact admission and product authority. No new global supervisor or duplicate reference counter is prescribed.

## Limits of this review

This is a source-semantics and architecture review, not an independent run of upstream tests or a license determination. This lane directly rechecked the Cordis/go-plugin/Extism/VS Code claims against its pinned inspected sources; the application and browser reports were cross-reviewed for their evidence boundaries and internal consistency. Missing provisional runtime links and the pending cost table should be checked in round 2 after root's final edits.
