# Round 2 final review — runtime lane

Reviewer: live_runtime_patterns. Date: client 2026-11-17. Bounded follow-up to round 1. No additional broad research, upstream execution, dependency installation or repeated runtime experiments.

## Exact inspected identities

- `extension-foundation/docs/research/portable-live-plugin-mechanisms-and-library-design-2026-11-17.md`
  SHA-256: `e5235777e909c7cdb4bee63dd90c219673650f5032724ada21657512c34b50cb`
- `portable-live-plugins-20261117/browser-mechanisms/report.md`
  SHA-256: `c5ff67b104d967d65dfc36958cdde377176a342315fdb2f9596e1afbe023036c`
- `portable-live-plugins-20261117/application-mechanisms/report.md`
  SHA-256: `45a6cc2010471bc567f541a9cb774f6d468d4453dbe20c723d2dd9fcc0f444f9`

The hashes identify the semantic snapshot checked here. Root may subsequently add review/validation navigation or documentation-format corrections; this review does not imply those later bytes were already inspected.

## Verdict

**Pass for this research/documentation scope; no remaining concrete blocker.** The report does not authorize an implementation, choose package ownership or select ordinary-update interruption. It preserves the user’s broad live-plugin vision while qualifying runtime/category contracts.

Round 1’s substantive wording concerns are resolved:

- Cordis now preserves **fiber identity/configuration**, while replacing the component/runtime binding. Both published and current HMR pins are explicit, including the newly required filesystem service in main. The compared fiber files are identical, so the published fiber citation supports the described lifecycle.
- go-plugin’s controller **calls `Stop`**; the source TODO is correctly treated as historical context. No inflight-drain or total two-second shutdown guarantee is introduced.
- Extism claims are attached to the published JS SDK’s exact source and are marked source observations, not reproduced incidents or transferred Rust guarantees.
- VS Code’s activation-started removal boundary and host termination are not described as uninterrupted active-extension replacement.
- The application lane now subtracts existing Host/kernel/native bookkeeping before extracting a residual coordinator; a qualified recipe with no new package is explicitly acceptable.
- Browser/root qualification asks for an independent external fixture for an ordinary library. Stronger independent implementation requirements are reserved for the separate stable-SPI gate.

## Resource, state and authority check

The final update sequence protects selection, admission and retention as one acquisition, including reservation/revalidation when borrowing suspends. It does not leave an asynchronous gap in which the selected resource can retire before a caller obtains its lifetime. Streams and long-lived handles retain through consumption/finalization under the chosen policy, rather than merely until the function returns. Authorization remains distinct from custody, and these in-process facts are not promoted into a distributed transaction.

Exclusive resources, incompatible state, failed cleanup and stale candidate completion have explicit limits. The same existing owner remains authoritative for selection and the same executor remains responsible for physical resources. No new global supervisor, duplicate active-head store or implicit forced cancellation is prescribed. An emergency/deadline policy is not smuggled into the open ordinary-update decision.

The new cost table labels mutually exclusive alternatives, separately counts new mechanism/integration/tests, excludes reused code, calls modified LOC unmeasured, and limits estimates to one trusted in-process cohort and one JavaScript execution agent. Loading, admission, state migration, hostile-code isolation, distributed publication, UI, release delivery and migration costs remain outside the estimate. Reliability numbers are expressly planning judgments for bounded conformance, not measured production probabilities. This review does not independently validate their numerical accuracy.

## Final citation refinement verified

The retained-old-module-record limitation in the Cordis paragraph is explicitly a maintainer-discussion observation in this lane’s C8 (`https://github.com/cordiverse/cordis/issues/243`). The current README directly supports stale references and environment limits, but does not itself establish a bounded-GC claim. Root added the direct maintainer-discussion citation during this check; the exact final hash above includes that correction and was rechecked after it. No citation issue remains from this note.

## Review limits

The runtime source pins were checked against this lane’s primary-source ledger. Changed application/browser wording was cross-reviewed; no upstream tests were rerun. Documentation/CI success will validate the submitted documentation, not prove a universal live-update runtime. This closes the two requested review rounds for the runtime lane.
