# Round 1 independent application-mechanism review

Reviewed: root governed synthesis and ownership-and-library/report.md as read on 17 November client date / 16 November UTC. Scope: decision-changing guarantee, portability, ownership and citation issues. No runtime tests or broad new research. One bounded source read verified the root's Pi example URL.

## Material correction: protected selection and retention

Root synthesis, “A concrete update operation”, step 4 (approximately line 293), captures descriptor/executor/generation and checks admission separately from retaining custody. The text should explicitly require selection and the needed lifetime admission/retention to have one protected acquisition boundary. Otherwise a caller can read generation A, suspend to acquire a lease, and resume after A's resources were retired.

The ownership lane already states the correct distinction: a synchronous linearization point in one JavaScript execution agent, or protected reservation/revalidation when retention suspends. Add approximately:

> Selection and any required lifetime admission/retention must be coordinated before an asynchronous gap can retire the selected resource. If acquisition suspends, reserve and revalidate under the existing owner. A registry snapshot alone is not a lease.

This does not choose uninterrupted operation. A revocable profile may reject a captured call; the invariant prevents accidental use of a resource whose eligibility was never established. Reported to root immediately.

## Material portability clarification: self-update durability

Ownership report, “What a residual mechanism could own”, says self-update should create a “durable request/receipt”. Durability is not a demonstrated universal prerequisite. The verified Pi example holds its request in an in-memory boolean and dispatches the command after agent_settled. A normal external in-process application may legitimately offer no restart-survival guarantee.

Use “request/receipt; durability where the consumer's recovery contract requires it”. This retains the essential prohibition on waiting for one's own drain without importing storage and recovery infrastructure into every consumer. Root synthesis already uses the more appropriate receipt/scheduling wording. Sent to ownership lane.

## Material ownership clarification: one current binding

Ownership report says the reusable coordinator “could own ... its per-instance current binding”; root says it must not advance a second active head. These can agree only if that binding is the delegated implementation of the consumer's single canonical selection operation. A mechanically convenient local pointer must not become an independently authoritative mirror of another Host route.

Add that qualification in the ownership paragraph. The root source already repeatedly insists on one owner and stale-candidate checks. No second state machine should be introduced merely to satisfy the coordinator API. Sent to ownership lane.

## Citation and inference checks passed

- Letta root execution link to src/tools/manager.ts at a472af0d66b42d5d9d6f13e1b8d2602eb33026c9 is correct. capturePreparedToolExecutionContext captures schemas and tool objects; executeTool rejects a supplied unknown context ID. Activation cancellation is additionally supported by the mod engine/tool registry, not assumed from snapshot membership.
- Pi root example link to packages/coding-agent/examples/extensions/reload-runtime.ts at 5a2febe5d7638ab05540b44a60518b41201be170 was fetched in this review. It exists and uses a flag, terminate: true, agent_settled and command dispatch. The direct example locator has been added to PI5 in the application ledger.
- Root's OpenCode claims match the pinned application evidence: dependency-aware local refresh but no sealed full executable closure; close changed suffix before replacement; old-code reactivation does not restore old scope; Tool.snapshot preserves descriptor/executor identity without retaining closed resources.
- Root correctly describes LayerNode as pre-acquisition composition. Explicit export does not justify calling it a live graph replacement primitive or stacking it beside another graph authority.
- Exact source publication remains unverified for the three application commits. Root correctly labels dev/main implementation rather than newly released packages.
- The Letta unexecuted multi-file stale-loader concern is not promoted into a confirmed upstream defect in root synthesis. That restraint is correct.

## Scope and policy checks passed

The all-category vision remains preserved while first-profile qualification is bounded. Ordinary-update interruption is explicitly open. Existing primitive reuse is separated from public release/production qualification. Process exit, cancellation, cache removal, descriptor consistency and physical resource lifetime are not collapsed into one guarantee. New broader runtime experiments are not claimed.

No additional source-path blocker or decision-changing contradiction found. The three corrections above are sufficient for this review; costs/runtime references were still being completed by root and were not treated as missing final deliverables.

