# Round 2 final bounded application-mechanism review

Verdict: **no remaining blocker in this lane's scope**. The three round-1 corrections are resolved. No new broad research or runtime test was performed.

## Exact inspected files

- /workspace/scratch/58e9c088d2ee/extension-foundation/docs/research/portable-live-plugin-mechanisms-and-library-design-2026-11-17.md  
  SHA-256: 917a2ddde5eca883f1ec0494da4d9acad37ead0acd4c18071783946b65c1a51f
- /workspace/scratch/58e9c088d2ee/portable-live-plugins-20261117/ownership-and-library/report.md  
  SHA-256: 6fd1dee5a735a0feb21d98e8b4bc4c9e528bba9995205ade50cd40589182f273
- /workspace/scratch/58e9c088d2ee/portable-live-plugins-20261117/application-mechanisms/report.md  
  SHA-256: 45a6cc2010471bc567f541a9cb774f6d468d4453dbe20c723d2dd9fcc0f444f9

The verdict applies to these exact bytes, before any subsequent documentation formatting or evidence-archive changes.

## Dispositions

1. **Protected acquisition: resolved.** Root step 4 now binds selection, admission and required retention before an asynchronous retirement gap, and requires reservation/revalidation when borrowing suspends. It does not claim that a snapshot is a lease. The following paragraph gives streams/subscriptions/handles their real consumption/finalization interval and expressly permits a different declared revocation policy.
2. **Universal durability: resolved.** Ownership report now permits a request/receipt or owner scheduling and requires durability only for a recovery profile promising survival across process failure. Root remains consistent with the verified in-memory Pi example.
3. **Two active bindings: resolved.** Ownership report now says the coordinator implements the consumer's single canonical selection binding and explicitly excludes a mirror/rival head. Root continues to forbid a second independently advancing owner.
4. **Own-report coordinator wording: retained.** Application report explicitly treats coordination as logical responsibilities under one existing authority, subtracts GM kernel/Host/native accounting first and permits a zero-residual/no-new-package outcome.
5. **Portability and gates: coherent.** Root requires purpose-neutral design and real consumer plus external conformance in the same delivery. It separates independently authored external fixtures for an ordinary library from stronger independent-implementation gates for stable extension SPI. It does not infer implementation, migration, publication or interruption authority from this research.
6. **Estimates: bounded.** Root now identifies P/I/T as non-overlapping new LOC, leaves modifications unmeasured, subtracts reused primitives, excludes broader platform delivery and labels numeric confidence/reliability as investigator judgment rather than measured evidence. This review does not independently validate those estimates.

## Agent source paths and guarantees

The root OpenCode source/Node/Bun/activation/tool/LayerNode/export-map links match the exact fd9137efec534fafb60102787022a782140365a4 files inspected in the application ledger. Letta engine and execution links match a472af0d66b42d5d9d6f13e1b8d2602eb33026c9. Pi session and reload example match 5a2febe5d7638ab05540b44a60518b41201be170; the example itself was directly fetched in round 1 and added to PI5.

No new contradictory claim was found about sealed import closures, rollback of old resources, stable descriptor/executor pairing, revocation, or LayerNode live graph behavior. Development/main source remains distinguished from release publication. All-category vision remains broad while qualification is per profile and ordinary-update interruption remains open.

New runtime-library references were not re-researched by this lane; their specialist review remains the evidence for those paths. No additional issue warrants broadening this bounded pass.

