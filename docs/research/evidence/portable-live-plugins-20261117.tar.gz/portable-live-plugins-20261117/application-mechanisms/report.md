# Portable live plugins: three application mechanisms and extraction boundaries

Research date: 17 November 2026 (client); source heads observed 16 November UTC. This is a focused follow-up to the earlier broad catalogue. It examines OpenCode, Letta Code and Pi as implementation donors for ordinary applications. It proposes architecture choices; it does not authorize implementation, select the ordinary-update interruption policy, or establish a universally safe migration mechanism.

The decisive reusable idea is a **generation-owned contribution registry with coherent consumer acquisition and explicit retirement policy**. The three hosts demonstrate different parts of that design. None supplies, by itself, a generally portable solution for module closure capture, arbitrary application state migration, resource retention and authorization. “All plugin categories” remains a product goal achievable through suitable adapters and category contracts; it is not evidence that one JavaScript loader can safely replace every category in every application.

## Source maturity and method

| Case | Exact inspected commit | Source version; declared license | Evidence classification |
|---|---|---|---|
| OpenCode, development branch | fd9137efec534fafb60102787022a782140365a4; 16 Nov 22:53 UTC | core/plugin/util 2.3.0; MIT | Implemented development source plus upstream documentation; publication of this exact source revision unverified |
| Letta Code, main | a472af0d66b42d5d9d6f13e1b8d2602eb33026c9; 16 Nov 19:22 UTC | 0.34.63; Apache-2.0 | Implemented main source and built-in mod-authoring skill; exact package publication unverified |
| Pi, main | 5a2febe5d7638ab05540b44a60518b41201be170; 16 Nov 22:37 UTC | coding-agent 1.5.2; MIT | Implemented main source and upstream extension documentation; exact package publication unverified |

Fresh web discovery was followed by exact-commit GitHub reads. References such as OC4 resolve to full pinned URLs, symbols and ranges in [source-ledger.json](source-ledger.json). Existing tests were read where identified; none was run. No live provider, agent, untrusted plugin, dependency installation, or runtime experiment was used. Package metadata is not release evidence, and declared licenses are provenance rather than a conclusion about the suitability of a future derivative.

## 1. OpenCode: executable snapshots, ordered activation and separate composition

### Detection is meaningfully dependency-aware, but imports are not a sealed artifact

OpenCode's local loader is more substantial than appending a timestamp to the entry module. createPluginSources fingerprints tracked file bytes and directory listings. It waits for watcher setup before evaluating the module, and caches the attempted import before evaluation, including failures. Repeated unchanged filesystem notifications therefore do not repeatedly execute a failing module's top-level code. PluginModule separately resolves local and installed package sources and derives revisions; a local source update and a package-manager update are different operations. [OC1]

The Node adapter uses generation-specific module URLs and a resolve hook to freshen local descendant imports. Bare imports and node_modules are deliberately excluded. The Bun adapter scans local imports, clears relevant cache entries and tracks files or missing dependency directories. These mechanisms make ordinary helper-file edits discoverable; inspected supervisor tests cover helper-defined RPC reloads and serialized periodic refresh. [OC2, OC10]

**A fresh import graph is still not an immutable executable closure.** The loader does not seal entry and dependency bytes into one content-addressed artifact. Excluded installed dependencies, lazy imports performed after activation, and mutable files outside the traced graph remain outside that guarantee. A revision counter answers which attempt produced an activation; it does not prove exactly which bytes every future import will execute. A neutral coordinator should consume a loader-provided revision and declared closure guarantee. Node/Bun cache manipulation belongs in a runtime adapter, not in the lifecycle kernel.

### Activation has order-dependent teardown and real failure boundaries

The supervisor serializes changes through a coalescing queue and holds readiness before debouncing, so a caller cannot equate “watch event received” with “new registry ready.” Source resolution failures retain the previous running definition; duplicate IDs are diagnosed and filtered. This is a useful preparation-stage protection, but is distinct from setup failure after teardown. [OC3]

Plugin.activate preserves only the unchanged ordered prefix. It closes the changed suffix in reverse order before setting up replacements, because registration order determines composition. Cleanup failure is logged so remaining plugins are not stranded merely because an earlier finalizer threw. A hung finalizer remains a different problem: catching an eventual error does not impose a timeout or force termination. [OC4]

If candidate setup fails, a previously healthy implementation may be loaded again in a **new activation scope**. That is recovery by reactivation, not rollback of the old scope, mutable state or external effects. There is a teardown/setup interval. Reordering does not automatically retry a revision already marked failed. The reusable concepts are explicit stage outcomes, exact-generation cleanup, a serialized transition and a recorded fallback result; suffix-wide restart is OpenCode's ordered-transform policy and must not become a universal host requirement.

A subtler protection appears in State.group and the activation failure worker. Contributions from one activation are grouped; a transform exception synchronously disables that group's contributions across domains. A queued failure belongs to the exact activation record, preventing an old failure from disabling a replacement. Cleanup is scheduled outside the readiness lock because a finalizer can itself await readiness. State.batch, however, coalesces notifications: its source explicitly does not make reads stale or roll back changes. Calling it a transaction would overstate the implementation. [OC5]

### A model request captures executable definitions, not the lifetime of their resources

Tool.snapshot reads one registry value, derives the exposed definitions, captures direct tool objects and CodeMode inventory, and returns an executor that selects from those captured objects. It does not later look up the same name in the newest tool registry. This provides a concrete schema/executor consistency mechanism: a request generated against tool version A does not silently dispatch to version B merely because the registry changed. The snapshot also preserves request-specific removal and alias handling around the execution hook. [OC6]

This does **not** prove that A's resource scope remains usable. Plugin.activate can already have closed the old scope; a retained function reference can close over mutable data or an already-disposed resource. Code identity, definition coherence, authorization, resource availability and invocation lifetime are separate properties. OpenCode's promise adapter tracks streams, connects explicit/fiber cancellation to tool signals and awaits returned setup cleanup, but arbitrary JavaScript effects still require a responsible plugin or an isolation boundary. [OC7]

For reuse, the useful consumer interface is acquisition of a descriptor/executor pair plus an explicit generation/liveness handle. Whether that handle grants a retention lease, can be revoked, or is usable only after quiescence is an application policy still open here.

### LayerNode replacement is a composition mechanism

LayerNode is explicitly exported through @opencode/util. Its NodeValue.replace creates a checked declaration override; compile resolves the override map, checks cycles and unresolved requirements, and builds memoization behavior before acquiring the resulting Effect graph. Local/shared MemoMaps and tracked release are relevant to dependency ownership. None of this evidence establishes arbitrary live rewiring of an already-acquired graph. The separate plugin activation code performs the runtime close/setup work. [OC8]

Public importability is stronger evidence than a private helper, but does not establish API stability or package publication of this development revision. LayerNode could be evaluated as an Effect composition choice for an application adopting its semantics. Adding it beside an existing GM composition resolver would risk two authorities for override precedence, graph identity and acquisition sharing. An adapter should translate one composition plan, or the host should select one resolver. “Use LayerNode for hot plugins” is not a sufficient architecture.

OpenCode's complete PluginHost imports concrete application services such as sessions, agents, models, commands and artifacts. Extracting that host wholesale would export product policy. The smallest promising donor is closer to State's grouped contributions plus activation-generation coordination, with Effect Scope as an optional resource adapter. Even that would need an explicit public contract and independent verification. [OC5, OC9]

## 2. Letta Code: generation checks with revocable captured tool contexts

### Agent-written source is transformed, not made immutable

Letta's built-in creating-mods skill directs an agent to author trusted local mod code and tell the user to run /reload. This is real support for agent-authored extensions. It is not evidence of a universal agent-autonomous installation/approval system. The mod design deliberately favors repair by the coding agent over a frozen backwards-compatible SDK; that may suit the product, but is a poor default compatibility promise for a reusable public library. [LE8]

createImportableModPath hashes the entry text, transpiles TypeScript to an importable module and removes older generated cache files for that mod. TypeScript transpileModule is not a whole-program typecheck or dependency-closure validator. A hashed entry filename does not freeze relative imports, shared packages, credentials or external state. Deleting old cache files also deserves scrutiny if a future reuse contract promises lazy access to old artifacts. Such a promise is absent from the inspected implementation. [LE2]

Each owner has a stable source-derived ID and a generation. Reader snapshots copy maps and arrays but retain tool functions, signals and other object references; they are snapshots of membership, not deep-frozen execution worlds. Local factory loading is awaited, stale API writes are guarded and failed factories have their contributions removed. Top-level code and external side effects still cannot be undone by deleting registrations. [LE1, LE3]

### Reload explicitly revokes before rebuilding

createModEngine.reload disposes the old registry, advances generation and publishes an empty replacement before loading. It permits guarded publication of the current loading registry, ignores stale generation publication, then disposes a stale completed load. The adapter suppresses best-effort event hooks during its loading interval rather than proving that those events will be replayed. This is an observable availability policy, not an atomic replacement transaction. [LE4]

Disposal aborts owner signals, invokes disposer functions in reverse order and unregisters contributions. The inspected dispose path is synchronous: promised asynchronous cleanup is not awaited there, and catching synchronous exceptions does not supervise later promise rejection. This distinction matters for reuse in hosts that need a resource to be fully released before acquiring its replacement.

Letta's prepared tool context is a particularly useful positive example. capturePreparedToolExecutionContext derives clientTools and the retained mod-tool map from the same execution snapshot, stores the context under an ID, and rejects a supplied missing context ID instead of silently falling through to the newest registry. Schema identity and executable identity are therefore connected. [LE5]

At execution, runModTool checks the captured activation signal, and executeModTool links caller cancellation with activation cancellation. An old definition may remain correctly paired with its old executable while that executable is no longer authorized by the host's activation lifetime to start. Active JavaScript must still cooperate with cancellation. This is coherent **revocation**, not guaranteed old-generation completion. It is a direct counterexample to treating schema/executor consistency as synonymous with keeping old sessions alive. [LE6]

### A narrow generation-race concern should become a falsifier

The implementation protects ordinary late writes from a stale factory, and its test covers a delayed single-mod setup. A narrower source-derived concern remains: global unregister helpers compare owner ID without generation, while the old multi-file load loop can continue to later files after a newer reload. An old loader creating another owner and touching the global registry could interact with cleanup of the newer owner under the same stable ID. [LE7]

This was **not reproduced** and is not a confirmed upstream defect. It is a useful extraction test target: overlap two reloads, pause the older loader in its first file, let the newer generation finish, resume the older loader into a second file, and assert that registration and cleanup cannot affect the newer generation. Testing only stale calls through an already-created owner does not cover that whole sequence.

For a neutral design, generation identity must accompany every externally shared registration and removal, or registration stores must be private to each candidate until publication. The contract should cover cleanup identity as carefully as setup identity.

Letta's mod engine is application-internal rather than an exported neutral mod-engine package. Backend access, permission overlays, global tool/provider registries, UI loading behavior and model context IDs belong to the Letta host. Its strongest reusable patterns are explicit owner generations, captured executable contexts, stale-context failure and activation-linked cancellation. Its compatibility and revocation policies must remain selectable. [LE4–LE8]

## 3. Pi: staged registration and an explicit settled reload boundary

### A useful staged setup contract, with limited rollback

Pi's extension loader constructs an API whose load-time state can commit after a successful awaited factory or discard after failure. It queues runtime/flag changes and tracks subscriptions. Runtime invalidation rejects stale API activity and removes tracked event-bus subscriptions. This is more precise than relying on extension authors to remember every deregistration, while still stopping short of undoing arbitrary files, sockets, timers or top-level imports. [PI1]

The loader creates fresh Jiti imports with module caching disabled and supplies shared virtual host modules. ResourceLoader.reload clears extension factory cache and re-resolves resources under the current project-trust state. These are deliberate cache/trust choices, not a content-addressed dependency artifact or a sandbox. A neutral runtime adapter should report those guarantees accurately rather than label every reload “immutable.” [PI2]

### Full reload waits for application quiescence

AgentSession.reload rejects while streaming or compacting, emits shutdown, invalidates the old runner, reloads settings/resources, rebuilds the runtime and emits startup/discovery. Its source does not show a prepare-everything-then-publish transaction or automatic restoration of the old runner if an intermediate step fails. Individual extension load failures are reported and skipped. [PI1, PI3]

Pi can refresh its tool registry during normal operation, but that narrower registry mutation must not be conflated with full extension code reload. The agent loop carries the current executable tool context through a model response and its tool calls; prepareToolCall selects and validates the tool from that context. Tool-change notices describe changed capabilities to subsequent turns. These are useful model-adapter behaviors, without proving deep immutability of tool objects or arbitrary closed-over data. [PI4]

The current upstream example allows an LLM to request reload through a tool that records intent and terminates the turn. An agent_settled handler then dispatches a registered reload command. A tool does not directly invoke reload while it is itself part of the active response. The documentation also states that code after await ctx.reload still runs in the old call frame, and recommends returning immediately. [PI5]

That pattern answers a general self-update hazard: an updater must not synchronously wait for a drain condition that includes its own invocation. The portable operation is “request transition and return an operation handle”; the host decides when and how to execute it. Pi's exact agent_settled event and streaming/compaction checks remain application-specific. The user's ordinary-update interruption choice is not decided by this example.

### Pi is reusable as an agent host, not automatically as a neutral plugin kernel

Pi exports AgentSession, resource-loading and extension-facing SDK types. If an outside application wants an embedded coding-agent session with Pi semantics, adapting its public SDK can avoid rebuilding a host. If the application is a desktop editor, backend processor or ordinary service with no model turn, importing the whole coding-agent lifecycle exports the wrong abstractions. The smaller reusable donors are staged registration, runtime invalidation and safe self-update initiation; the session boundary, prompt notices and active-tool settings belong in an agent adapter. [PI6]

## 4. What to reuse, what to extract, and what to keep open

| Concern | Evidence-backed reusable mechanism | Host/runtime-specific responsibility |
|---|---|---|
| Detect changed code | Candidate revision and dependency observations | Watchers, package resolution, Node/Bun/Jiti caches, artifact sealing |
| Register contributions | Owner/generation token; staged or grouped contributions; exact-owner cleanup | Tool/command/view/service semantics and ordering |
| Activate | Serialized transition; generation-checked publication; stage-specific outcomes | Prefix/suffix restart, dependency closure and readiness behavior |
| Acquire capabilities | Matching descriptor and executor with generation identity | Model schemas, RPC formats, UI handlers and call permissions |
| Retire | Explicit liveness state, cleanup observation and cancellation signal | Drain/revoke/quiesce/isolate, deadlines, user interruption |
| Recover | Distinguish retained old activation, recreated old code and failed restoration | State migration, external compensation, persistence and compatibility |
| Self-update | Request transition without waiting on its own drain | Author authority, validation/promotion rules and permitted categories |

The smallest plausible coordination boundary connects transition records, candidate/active generation identities, publication and retirement bookkeeping under one existing authority. These are logical responsibilities, not permission to recreate Get Modular's existing lifecycle kernel, duplicate a Host's active binding or mirror native lifetime accounting. First subtract existing primitives; the remaining shared mechanism may be zero, in which case a qualified composition recipe is preferable to a new coordinator package. Contribution adapters should return explicit handles; loaders should declare closure properties; resource adapters should expose cleanup and cancellation honestly. Consumer adapters should acquire coherent executable views. An Effect adapter can use Scope and fibers, but the neutral contract need not expose Effect service tags, agent sessions or package-manager details.

This separation is a concrete Clean Architecture boundary: host policy depends on a small lifecycle interface; the coordinator does not import tools, prompts, UI or repositories. Single responsibility keeps artifact construction, activation and invocation admission separate. Interface segregation lets a data-only extension avoid fake resource hooks and lets an isolated runtime supply stronger cancellation. Substitution requires declared guarantees: an entry-hash loader must not impersonate a sealed artifact loader; a revocable snapshot must not impersonate a retention lease. DRY means one owner of generation transitions and one authority for dependency resolution, rather than duplicating the same lifecycle in every plugin category or adding LayerNode beside GM without deciding which graph is authoritative.

Three adoption choices remain credible:

1. **Adapt a complete existing host** when its product semantics are wanted. Pi's public agent SDK is the clearest fit among these cases. OpenCode/Letta internal host extraction carries substantially more application coupling. This choice can accelerate an agent product but does not satisfy ordinary-project portability by itself.
2. **Extract a small neutral coordinator with runtime and host adapters.** The source supports the need and supplies donor patterns, but does not establish a ready-made package implementing the proposed contract. It requires independent conformance tests and a deliberately small API.
3. **Reuse a mature lower-level runtime/library under that coordinator.** Effect is relevant for scoped resource management; isolated process/Wasm/browser mechanisms may supply other category guarantees. The coordinator must not duplicate their module/dependency machinery. Their comparative fit is covered in the other research lanes.

The evidence favors evaluating whether any residual shared coordination remains after reusing existing owners and suitable primitives (option 3), then extracting only that demonstrated remainder (option 2). A no-new-package outcome remains valid. Preserve option 1 for applications that genuinely want the existing agent host. This is an architectural recommendation, not a decision to implement it. Generality should be demonstrated by at least one ordinary non-agent host adapter and one agent host adapter using the same generation protocol.

## Bounded checks required before implementation claims

The inspected sources suggest valuable falsifiers: helper edit versus late dynamic import; failed setup after old teardown; old schema invocation after resource disposal; stale generation registration and removal; concurrent update coalescing; non-cooperative cleanup; and self-update waiting on its own invocation. Descriptor/executor consistency must be checked independently from retention or revocation. State migration needs separate category evidence.

Those checks were **not executed** in this research. We established source mechanisms and limits, not performance, leak freedom, compatibility across releases, security confinement or uninterrupted updates. Ordinary-update interruption, retention lifetime, rollback policy and implementation selection remain open product/architecture choices.

