# Round2 final bounded ownership review

Reviewer: effect_live_fit. Research date2026-11-17; review performed2026-11-16 UTC. This round checks accepted round1 corrections and scope consistency only. No new external research, production change, dependency installation or runtime/probe rerun was performed.

## Reviewed identities

| Artifact | SHA-256 |
| --- | --- |
| Governed root synthesis `extension-foundation/docs/research/portable-live-plugin-mechanisms-and-library-design-2026-11-17.md` | `917a2ddde5eca883f1ec0494da4d9acad37ead0acd4c18071783946b65c1a51f` |
| Browser report | `c5ff67b104d967d65dfc36958cdde377176a342315fdb2f9596e1afbe023036c` |
| Runtime report | `7ced56a233e5315c94a358686a366e2522d7474a3404ac1a7c30dfef1fe73bb3` |
| Ownership/library report | `6fd1dee5a735a0feb21d98e8b4bc4c9e528bba9995205ade50cd40589182f273` |

Root may subsequently add an ordinary external-renderer example and exact review/validation links. Those later bytes are outside this hash; they should not be described as independently rereviewed unless separately checked. Such documentation-only additions do not themselves change the conclusions below.

## Correction verification

| Round1 concern | Observed final wording | Result |
| --- | --- | --- |
| Same-delivery portability | Package placement requires purpose-neutral design from first real consumer plus external conformance in the same delivery. Internal seams may stage packaging, not defer portability through copied semantics. | Resolved |
| Selection/admission/retention race | Operation step4 requires one protected acquisition before an asynchronous gap; suspending borrowing requires reservation/revalidation. | Resolved |
| Stream and long-lived resources | Retention extends through consumption/finalization; earlier revocation is explicit policy. Local protection is not a distributed publication transaction. | Resolved |
| Ordinary-library versus stable-SPI gate | Root step4 and browser §6 name an independently authored external conformance fixture and explicitly separate stronger stable-SPI implementation gates. | Resolved |
| P/I/T interpretation | All are newly added, nonoverlapping LOC; changed existing LOC unmeasured. Reused code is subtracted. Loader/admission/durable publication/state/hostile isolation/full UI/docs/release/non-Effect migration excluded. | Resolved |
| Numerical judgments | Confidence/complexity and8/10 achievable reliability are explicitly bounded expert judgments, not measured failure probability, availability, security or whole-platform scores. | Adequately qualified |
| Universal activation hooks | Runtime report now uses a qualified evolution/lifetime contract per category and excludes mandatory executable hooks for pure descriptors. | Resolved |
| Reviewer's duplicate binding risk | Own report explicitly delegates the consumer's single canonical selection binding; no mirrored/rival active head. | Resolved |
| Reviewer's universal durability requirement | Own report requires durable self-update receipt only for a recovery contract promising survival across process failure. | Resolved |

## Retained truth and scope checks

The synthesis continues to distinguish Effect adapter0.1.1 registry availability, README publication beginning0.1.0, exact qualified Effect4.1.4, and the private lifecycle-kernel candidate. No current public release is claimed for the kernel, no product adoption follows from registry publication, and historical November14 evidence remains temporal evidence.

Kernel accounting, native resource lifetimes and product permission/selection retain their respective owners. The Effect leaf is optional and keeps native errors, interruption and finalizers; neither the neutral mechanism nor its adapters introduce a second graph owner, refcounter or active head. The earlier ScopedRef/RcRef evidence is not expanded into a universal hot-swap claim.

Ordinary-update interruption, exact package location, supported profile and broader adoption remain open. The proposed sequence preserves failure distinctions and coherent cohort selection without claiming arbitrary escaped-reference revocation, migration or physical rollback. The estimates describe incremental bounded coordination and qualification, not the total cost of shipping a universal plugin platform.

## Verdict

**Pass for this research and discussion scope; no unresolved ownership/native-semantics blocker found in the reviewed snapshot.** This is not package admission, acceptance of a public API, selection of an interruption policy or production qualification. No additional experiment is needed to finalize this research.

The existing six-file owned hash inventory was checked successfully before writing this review; it is refreshed to include this seventh artifact afterward. The inventory deliberately excludes its own checksum and contains no third-party full-source snapshots.
