# Portable live-plugin mechanisms: ownership and minimum library boundary

Research date: 2026-11-17. Retrievals: 2026-11-16 UTC. This is a source-based architectural assessment, not an implementation or production qualification. Source IDs refer to `source-ledger.json`; registry observations are separately retained. Proposed mechanisms and estimates below are judgments, explicitly distinguished from implemented behavior. Ordinary-update interruption policy remains open.

## Research conclusion

A reusable library is compatible with the existing architecture. The useful commonality is **coordinating replacement of an owned, typed instance or coherent composition**, not defining every application's plugin interface. Product ownership does not require products to copy mechanical implementation. Conversely, shared implementation does not acquire permission to choose product policy or become a second operational authority.

Most difficult primitives already have owners: GM selects and constructs a closed graph; its optional lifecycle kernel records generation admission and leases; native Effect owns native acquisition, scopes and fibers; Resources supports cooperative cleanup for ordinary construction. The residual candidate is a small coordination boundary connecting **selection, admission, lifetime retention, publication and retirement observation**. It must reuse those primitives, and may prove too small to warrant a new package. It is not already implemented by `@get-modular/effect`.

Design this boundary for external use from its first delivery. Validate it with a real consumer and an ordinary external project, rather than first accumulating product-specific copies. A published library, a stable public extension SPI and production adoption remain different claims with different gates. OD-003 already states this distinction; the user's portable-library goal does not require weakening EF's prohibition on a universal plugin interface. [S03, S21, S27]

## Current identities and availability

| Subject | Exact inspected identity | What the evidence establishes |
| --- | --- | --- |
| Get Modular main | `33c032f829028967825428bc6b049ed6db1c56b2` | Current source and accepted GM contracts; not an application adoption claim. |
| EF main / draft PR55 | Main `29ae5b0269d9d83f071344e3e18761ded04ff53d`; draft head `4285fc983a954390d81d19ade861acb2c0a4177a` | The working proposal is on the draft head. Do not present all draft additions as merged main decisions. |
| `@get-modular/effect` | Source and registry latest **0.1.1**; README says publication began at **0.1.0** | Public package now exists. Registry requires Effect **4.1.4**, Core/Assembly `^0.8.0`; README qualification is matching 0.8.0. |
| `@get-modular/lifecycle-kernel` | Source **0.1.0**, `private: true`; registry latest returned 404 | Implemented, source-admitted candidate with packed tests; no public release or production-adoption claim. |
| Native Effect | Qualified 4.1.4 source pin `289a53f7b1fc40049219c6e69022db2fb859c356` | Version-specific API inspection; not an assertion that 4.1.4 is the latest Effect. |
| Organization standard | `.github` `0b44c64c824f536bd1b085341e7669bcc64ef124` | Library-first, external usability, explicit ownership and incremental P/I/T estimation requirements. |

Registry metadata was retrieved at approximately `2026-11-16T23:13:45Z`. Effect 0.1.1's recorded tarball SHA-1 is `805d9819d7c03153463fecdd246c040f2145252b`; complete integrity and response hashes are retained. This lane did not download the tarball or validate its provenance attestation. Current README/manifest/registry supersede the historical statement that Effect was merely a candidate; the November 14 archive must retain its original temporal claim. The Effect changelog/practices still contain candidate wording, so those sentences alone are insufficient availability evidence. [S02, S10–S11, S14, S20]

## Existing owners: subtract these before designing a library

| Concern | Existing implementation or accepted owner | Boundary to preserve |
| --- | --- | --- |
| Declarations, provider selection, binding, graph validation | GM Core/Assembly and Consumer Module Standard | No second DI graph or runtime resolver. |
| Executing already selected factories | Ordinary Assembly or optional native Effect adapter | Construction does not authorize, activate or publish a plugin. |
| Local generation phases, call/custody accounting | `createLifecycleKernel()` candidate | Reuse its phases, tokens and counts; do not recreate a competing registry. |
| Native resources and work | Effect `Scope`, Layer, fibers, native resource primitives | Preserve typed errors/environment and actual interruption/finalization. |
| Cooperative ordinary cleanup | Resources or the caller's existing explicit owner | One disposer; cleanup completion is not universal proof of physical release. |
| Active route, readiness, authorization, deployment and recovery policy | Product Host | Shared code may execute a product-authorized operation; canonical authority stays singular. |
| Neutral artifact/admission/isolation/custody contracts | Extension Foundation, where applicable | Neither EF nor GM core imports the other; outer product adapters may use both. |

The kernel is concrete, not an imagined future component. `stage`, `activate`, `quiesce`, `resume`, `retire`, `beginCall`, `retainCustody`, `checkCall`, `release`, `finishRetirement` and `snapshot` use per-instance WeakMaps and opaque tokens. New calls require active state; quiescing preserves existing call validity; retiring revokes it; release is idempotent. `finishRetirement` requires zero held counts. There are no callbacks, promises, timers, I/O or global registry. It does **not** select a current generation, wait for work or close resources. A zero count does not prove physical cleanup. [S09, S16–S18]

CMS already describes dynamic instances as new construction, owner-controlled pointer change and old-instance closure, rather than mutation of a live dependency graph. Its narrow call-boundary pattern and kernel handoff recipe are substantial prior design, so billing a new full lifecycle state machine would double-count existing work. The kernel deliberately excludes retained consumers initiating new calls during retirement; adopting that stronger guarantee needs a successor contract and evidence. [S13, S18]

## What a residual mechanism could own

The smallest credible subject is one replaceable **cohort**: a typed root plus the resources and exact dependency closure whose lifetime must agree. A cohort can be smaller than an application. Choosing its boundary is a product/composition decision; choosing each dependency independently midway through one operation can create a mixed generation that was never validated.

A candidate reusable coordinator could implement the consumer's single canonical selection binding, candidate-attempt bookkeeping, expected-current comparison and the sequencing that connects existing admission/resource owners. This is delegated implementation of that one binding, never a mirrored or rival active head. It would prepare outside the publication step, install ownership before any asynchronous handoff, publish only a ready candidate against the expected revision, and retain failed/uncertain cleanup obligations for the existing recovery owner. Product authorization, route authority and policy are inputs, not facts independently invented by the coordinator.

Admission must bind selection and lifetime retention before any asynchronous gap in which replacement can retire the selected resource. In one JavaScript execution agent this can have a synchronous linearization point. If retention requires suspension, the protocol needs protected reservation/revalidation; “read current, await borrow, invoke” is not a guarantee. A stale candidate finishing after a newer one must not overwrite it. Neither a mutex nor an in-process pointer establishes ADR-0011's durable, multi-process publication transaction.

Under a chosen continuity policy, admitted work retains its cohort through completion. Under a chosen interruption policy, the Host revokes admission and requests cancellation, but cancellation still does not prove resource release. The API must distinguish accepted replacement, publication, cancellation requested, work settled and cleanup completed. It must not promise that cleanup failure restores a previously closed generation. Exclusive resources and incompatible state transitions may require serial handoff or restart; continuity is not universally achievable.

Keeping a resource alive does not keep permission alive. Old callbacks, closures and object references remain callable JavaScript; Scope closure cannot revoke arbitrary escaped methods. Host-mediated effects must use the product's current authorization/fencing checks. Streams retain the owner through consumption and finalization, not merely through returning a Stream object. The same principle applies to subscriptions, UI sessions and long-lived handles. Self-update should return a request/receipt or schedule work at the product boundary and avoid waiting for its own drain. Durability is required only when the consumer's recovery profile promises survival across process failure. These are distinct lifetime profiles, not mandatory methods on every plugin.

## Three implementation directions

### A. Existing kernel plus a small carrier-specific coordinator

This is the strongest portable baseline when consumers already use ordinary TypeScript/Promise execution. Keep the kernel synchronous and policy-free. Use the caller's existing scope/disposal owner for actual cleanup; a narrow Promise leaf can coordinate waiting and propagate original failure/cleanup evidence. Do not enlarge the kernel into the asynchronous Host manager forbidden by its accepted scope.

Portability does not mean inventing `UniversalTask`, `UniversalScope` or an executor interface containing every runtime operation. A small shared synchronous rule may be useful across carriers; orchestration that materially depends on native cancellation should stay in a native leaf. The first delivery can be one carrier plus explicit limitations. A second execution adapter is justified by an actual consumer, not by a requirement that every future runtime be designed now.

There is also a legitimate **no-new-package** outcome: publish a tested composition recipe and reuse the current kernel if common coordinator state is trivial or if two consumers need incompatible semantics. Library-first forbids deliberate copy-based incubation; it does not require a speculative framework when no additional invariant has been demonstrated.

### B. Native Effect combinations for Effect-native consumers

The published GM adapter lowers a verified graph into native Layers. In `lower.ts`, `graph` captures exact provider nodes; each returned `.layer()` call creates fresh mapper identities. Already captured dependencies do not update when a different Layer is later supplied elsewhere. Layer/MemoMap sharing is about acquisition identity and ownership, not current-generation routing. Borrowed inputs and private Layers still retain their own semantics. [S14–S15]

Effect can reduce new asynchronous machinery, but the exact primitive matters:

| Native primitive | Useful guarantee at the qualified pin | Missing replacement guarantee |
| --- | --- | --- |
| `ScopedRef.set` | Acquire candidate in a new scope; on acquisition failure close that scope; serialize setter work | `get` is not a borrower lease. Setter closes old scope before publishing the new pointer. |
| `RcRef.get` / `invalidate` | Scoped borrowers retain the acquired resource; invalidation detaches current value and existing references delay its close | Fixed acquisition effect; invalidation does not prepare/readiness-check a new arbitrary candidate before publication. |
| Layer and Scope | Native construction, memoization and finalization | No product admission, cohort routing, permission grant or state migration. |

`ScopedRef.set` lines192–204 close the old scope before pointer assignment and close the candidate if that finalization fails. Therefore an old-finalizer defect is not a typed acquisition failure or guaranteed rollback to usable old resources. `RcRef` internally counts real scoped borrowers and records their finalizers; adding a second generic reference counter around it duplicates lifetime machinery. Its owning scope must outlive the required borrowing interval. The upstream package manifest independently verifies version4.1.4 at this source pin. [S23–S25, S32]

The prior four-case FileHandle experiment is retained in the dated EF research, not rerun here: it observed old retained-handle failure after bare ScopedRef replacement, failed-acquisition cleanup preserving old use, a finalizer defect with exact Cause, and old RcRef borrower retention through invalidation. Those observations establish useful primitive limits, not a complete portable coordinator or production hot-swap guarantee. [S22]

An Effect-native leaf can combine native scopes/borrowers with a bounded publication rule and, where required, the existing kernel's invocation-authority facts. Native lifetime reference counts and kernel call-authority accounting are different facts; add both only if the contract actually needs both, and never mirror either independently. Keep `E`, `R`, interruption and full Cause native. A Promise facade at an external boundary can be legitimate, but wrapping a Promise factory does not reconstruct native acquisition semantics. A ManagedRuntime per plugin is not required. [S14, S19]

### C. A larger plugin platform

A platform would additionally own artifact loading, trust policy, capabilities, transport, durable publication, state migration, multi-process recovery, UI lifecycle and compatibility negotiation. This may be a valid separate product, but it is not a thin reusable library or an incremental consequence of Effect adoption. Cordis or another existing runtime can replace some mechanics **only after its exact pinned contract and consumer requirements match**; this lane does not certify a Cordis version or reimplement it.

A product using a commodity runtime should have one translated operational lifecycle, not a runtime lifecycle plus an independently advancing generic coordinator. Some systems can use the existing runtime's phases directly and need only conformance/translation. Forcing every plugin category through one platform ABI risks irrelevant hooks, implicit global dependencies and false substitutability. Process/worker isolation remains an optional deployment adapter with a stronger failure boundary, not a property supplied by any in-process TypeScript library.

## Location and dependency direction remain decisions

| Possible home | Plausible fit | Required limitation or decision |
| --- | --- | --- |
| Existing GM lifecycle-kernel owner, separate coordination leaf if admitted | Closest existing generation/lease semantics and conformance | Preserve kernel identity and synchronous contract. Additional scope/package needs explicit admission; ADR-0015 does not already grant GM runtime authority. |
| EF neutral protocol or conformance kit | Portable evidence vocabulary and tests for admission/retirement profiles | EF is not the universal runtime. Do not make GM import EF or ordinary callers install EF catalog/storage governance. |
| Existing runtime integration / product-owned outer adapter | Concrete policy translation and reuse of commodity mechanics | The reusable portion can be purpose-neutral; product-specific policy remains outer. Avoid copied coordinators and rival state machines. |

Repository placement is secondary to contract ownership and dependency direction. Package independence does not require a new repository. No source ownership transfer is authorized by this report. [S08, S18, S21]

## An ordinary external consumer must be credible

An external document server should be able to replace its application-defined `Renderer` implementation without Agent Teams credentials, an EF catalog, PostgreSQL, an agent runtime, GM declarations or an organization governance service. It supplies an already selected factory/instance, its actual resource owner, readiness evidence and update policy. If it wants graph validation it can add GM; if native Effect is its execution model it can select the native leaf. The library does not define `Renderer`, discover plugins or decide who may update it.

That is a **proposed acceptance fixture**, not a claimed adopter. A materially different real use—such as a trusted background transformation cohort—must test whether the shared mechanism actually survives different lifetime and invocation choices. One request fixture cannot qualify arbitrary UI sessions, streams, hostile plugins or state migration.

Existing GM already demonstrates the viable public-consumer shape. Its quickstart uses published Core/Assembly0.8.0 with ordinary explicit factories. Effect's complete README example uses public package roots and native provision. The packed test constructs an isolated consumer, checks ordinary imports without Effect, then checks native execution and public typing; it specifies 23 runtime cases. The kernel's packed test explicitly asserts `private: true`. Reading those tests establishes current intended conformance scope, not a new successful execution in this lane. [S02, S28–S31]

For a future public library, accept ordinary ESM imports and declarations, package-only fixtures, no deep imports, exact supported runtimes/TypeScript7.0.2+, and documented failure/lifetime semantics. External fixtures must verify observed resource behavior and race boundaries, rather than only callback order or phase snapshots. Include stale candidate rejection, acquisition failure, interrupted handoff, retained work, cleanup failure and authority checks. No new tests were run for this research.

## Clean Architecture, SOLID and evolution

Dependency inversion means the consumer owns its narrow capability contract and the outer integration depends on both it and the reusable mechanism. It does not require erasing Effect behind Promise. Native Effect can be the deliberate execution technology within a bounded context while pure domain rules remain ordinary code. Interface segregation favors distinct request, stream, state and isolation profiles over a giant `Plugin` interface. Substitution requires the promised failure/lifetime behavior, not merely identical method names.

Single responsibility gives construction, admission authority, resource lifetime and publication their existing owners. Open/closed extensibility uses explicit carrier/platform adapters without adding an adapter for every hypothetical environment. DRY means one owner of each invariant; a generic registry, mirrored phase enum or parallel counter is duplication even if it reduces visible call-site lines. Conversely, different carrier implementations are acceptable where their semantics differ.

EF ADR-0011 applies cumulatively only to supported production profiles; ordinary imports, static DI and inert construction are expressly outside its runtime-publication scope. ADR-0014's immutable plans and distinct candidate/head identities remain useful guardrails. ADR-0015 authorizes GM semantic extraction, not generations/routing/recovery ownership. ADR-0013 is superseded by15; its preserved feature/library/adapter/package distinctions must not be mistaken for an active ban on library-first design. [S04, S06–S08]

Portable design is possible now; a new public package is not already admitted. Preserve the lifecycle-kernel's existing release gates. Identify the real shared need, owner and ordinary external evidence for an additional library; separately qualify any stable public extension SPI and production integration. Broader ownership or interface changes require a scoped successor decision, not silently editing accepted ADRs. Contract evolution should state supported behavioral profiles and migrations; avoid permanent parallel compatibility managers that create two authorities. [S18, S21, S27]

## Conditional incremental estimates

These are design bands, not measured delivery forecasts. All rows assume trusted in-process code, one JavaScript execution agent, one coherent cohort, already selected executable bytes, existing permission/readiness/recovery owners, and no durable/distributed publication or state migration. **P** is new reusable production mechanism; **I** is one real consumer's integration; **T** is tests/external fixtures. All three bands count newly added LOC in non-overlapping categories; modifications to existing lines are unmeasured, not included or assumed zero. Existing kernel, Resources, Effect and GM code are subtracted. Documentation/release work is additional and unestimated. Rows are alternatives, not additive.

| Alternative | P, new LOC | I, one consumer LOC | T, conformance LOC | Scope and limits |
| --- | ---: | ---: | ---: | --- |
| Reuse existing primitives with a governed recipe | 0 | 150–350 | 350–750 | No new mechanism or public package; does not solve kernel publication. |
| Neutral coordination plus one ordinary execution leaf | 400–900 | 150–350 | 900–1,800 | External-library boundary and two fixtures; only one carrier implemented. |
| Effect-native coordination | 200–500 | 120–300 | 700–1,400 | Native consumers; reuse lifetime primitives and preserve typed errors/Cause. |
| Add the second genuine execution leaf later | +200–500 | +120–300 | +500–1,000 | Conditional increment after distinct consumer need; no fake universal executor. |
| Larger plugin platform | Not responsibly bounded | Not responsibly bounded | Not responsibly bounded | Missing trust, deployment, state and operational contracts dominate; a precise total would be misleading. |

For the same bounded guarantee, achievable reliability after conformance is judged **8/10** for either small coordination route, not a measured failure rate; native Effect supplies stronger machinery for native work but cannot repair missing policy. Implementation complexity is **5/10** for Effect-native and **6/10** for ordinary coordination; confidence in these estimates is **6/10** and **5/10**, respectively. Introducing Effect into a non-Effect consumer has unestimated migration/training cost. Whole-platform reliability has no honest global score until profiles are fixed. These bands exceed the older one-consumer experiment because public portability adds independent packaging, typing and behavioral obligations.

The next bounded decision is whether one demonstrated common operation needs shared coordination beyond the kernel and existing carrier. Choose that operation, its continuity/interruption policy and release promise, then deliver one neutral library boundary with a real integration and external conformance—or retain the proven recipe if no additional invariant justifies a package. This first scope should preserve future adapters for all plugin categories without pretending to qualify them simultaneously.

## Краткие выводы

Универсальная библиотека возможна: универсальными должны быть механизмы владения и согласованной смены экземпляра, а не обязательный интерфейс всех плагинов. Основа уже существует; нельзя заново писать kernel, DI, счётчик ссылок Effect или второго владельца lifecycle. `@get-modular/effect` уже опубликован как0.1.1, но hot-swap сам по себе не реализует; lifecycle-kernel пока private-кандидат. Effect-native путь полезен для Effect-приложений, обычный путь остаётся самостоятельным. Публичный пакет требует отдельной доказанной границы и внешнего потребителя; политика прерывания обычного update остаётся открытой.
