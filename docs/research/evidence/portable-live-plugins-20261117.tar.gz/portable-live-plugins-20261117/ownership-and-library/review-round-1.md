# Round1 cross-review: ownership and portable library boundary

Reviewer: effect_live_fit. Research date2026-11-17; review performed2026-11-16 UTC. Scope: governed root synthesis, runtime report and browser report against this lane's independently inspected GM/EF/Effect contracts. This is not a fresh complete audit of each external implementation. No runtime or previous four-case probe was rerun. Only this review and authorized corrections to the reviewer's own report were written.

## Inputs and snapshot identities

| Input | SHA-256 captured during review |
| --- | --- |
| `extension-foundation/docs/research/portable-live-plugin-mechanisms-and-library-design-2026-11-17.md` | `74722c41f32a7b98df6fe33c3fd8b29f83980de1d4c4d1d9c4fe0eb0e2cad4b0` |
| `runtime-mechanisms/runtime-mechanisms-report.en.md` | `bb0914537ba6cc150ab74c86678822f328f199d7296e4a7ff1b2c4ce2b3445a0` |
| `browser-mechanisms/report.md` | `9a52514c59bb620488361c9602c02f066046d1c57da6499853ff73287b331ad1` |

These are working snapshots. Root was simultaneously adding the bounded cost table and accepted corrections; round2 must check final dispositions rather than assume the snapshot is final.

## Findings and disposition

### R1. Preserve same-delivery portable design, not indefinite internal incubation

Root package-placement wording allowed an internal seam provided portability was tested rather than postponed indefinitely. That is weaker than the organization library-first standard and OD003 lines285–292: the demonstrated shared concern should be a purpose-neutral ordinary library from its first real consumer plus external conformance delivery. Internal packaging can be provisional; the semantic boundary should not be incubated as product-local copies awaiting future extraction.

Suggested correction: design the common concern for external use in that first delivery; an internal seam may stage package publication, not defer independent contract design. This changes neither existing kernel release gates nor stable public SPI/production-adoption gates. **Root accepted; verify applied in round2.**

### R2. State the admission/retention race boundary

Root's proposed operation captures descriptors/executables coherently, but should also state that selection, admission and actual lifetime retention must bind before an asynchronous gap in which promotion can retire the selected resource. If retention suspends, the owning protocol needs protected reservation or revalidation. A captured object plus a later awaited borrow is not automatically a lease. This is the critical native-primitive lesson and should not be hidden in the lane report.

The claim remains local to the stated execution agent and owner; it does not supply distributed atomic publication or product permission retention. **Root accepted; verify applied in round2.**

### R3. External conformance is not automatically independent public-SPI implementation

Browser §6 and root qualification step4 used “independently authored conformance implementation”/“independently implement conformance.” These can accidentally import the stronger independent-public-SPI-implementation requirement into every ordinary library. Use an independently authored external conformance fixture and concrete observed behavior. Apply stronger stable-SPI gates only when proposing that surface. The root already distinguishes the gates elsewhere, so this is consistency repair rather than a new exception. **Root accepted; verify both locations in round2.**

### R4. Keep estimate units and reliability judgments bounded

The inspected root snapshot did not yet contain the forthcoming cost table. The owning lane now expressly defines P/I/T as **newly added LOC** in mutually exclusive reusable-production/integration/test categories. Changed existing LOC are unmeasured, not included or assumed zero. Existing GM/kernel/Effect/Resources code is subtracted; documentation/release work is additional and unestimated. The larger platform remains unbounded without its missing profiles.

The 8/10 achievable-reliability judgment is an expert assessment of bounded invariants after conformance under explicit assumptions, not an observed failure rate, product availability or hostile-plugin security score. Its precision is inherently weak until the consumer/profile is fixed. Root agrees to retain only this qualified interpretation and no whole-platform score. **Final root cost wording deferred to round2.**

### R5. Category evolution contract, not obligatory activation hooks

Runtime conclusion says every supported plugin has a standard activation/replacement lifecycle. The report's detailed sections and explicit limits are careful, but this summary could imply all pure contributions must implement the same operational hooks. Prefer “each supported category has a qualified evolution/lifetime contract.” Runtime adapters may share observations while exposing distinct capabilities. **Sent to runtime author and root; nonblocking wording correction.**

## Checks that found no material contradiction

- Current publication facts are correct: Effect adapter0.1.1 published; README publication began0.1.0; exact peer4.1.4; kernel remains private candidate. Historical Nov14 candidate claims are not rewritten.
- Root preserves one operational owner and excludes duplicate active heads, grant stores, lifecycle ledgers and supervisors. It does not stack GM, Cordis and Module Federation as competing graph resolvers.
- Native Effect is optional and its opted-in leaf keeps Cause/interruption/finalizer semantics. No universal Promise executor is imposed on native construction.
- Source observations, npm metadata and execution evidence are distinguished. Runtime/browser reports do not claim they reran their upstream systems.
- Ordinary-update interruption remains explicitly open. Exclusive resource and state-migration limits do not silently choose restart or cancellation.
- Root self-update receipt/scheduling language is appropriately conditional; it does not require every ordinary external library to own durable workflow infrastructure.
- Cordis standalone core and Node-specific HMR, go-plugin process custody, Extism SDK/backend variation and browser loader/lifetime boundaries are treated as fitting alternatives or adapters, not universal guarantees.

## Accepted corrections to the reviewer's own report

Application-lane peer review identified two useful narrowings, authorized by root and applied during this round:

| Before | After | Why |
| --- | --- | --- |
| Coordinator “owns its per-instance current binding” | Coordinator is delegated implementation of the consumer's **single canonical selection binding**, never a mirrored/rival active head | Align implementation ownership with one operational authority. |
| Self-update creates a “durable request/receipt” | Return a request/receipt or schedule work; durability applies only when the consumer's recovery contract requires survival across process failure | Ordinary external projects and in-memory self-reload mechanisms do not inherently need durable infrastructure. |
| P/I/T scope left new-versus-changed implicit | All three bands count newly added LOC; changed LOC and documentation/release effort unmeasured | Prevent false precision or reuse of the old one-consumer experiment as full public-library delivery cost. |

No new primitive, scope or public API was introduced by these corrections. The agent-owned hash inventory is refreshed after this artifact and report changes. The only remaining round1 follow-up is verification that accepted changes reached the final synthesis; no additional runtime experiment is justified.
