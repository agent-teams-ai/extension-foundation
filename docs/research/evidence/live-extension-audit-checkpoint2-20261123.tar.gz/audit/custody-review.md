# Documentation custody review — 2026-11-23

## Result and exact boundary

**One concrete preservation action is recommended:** retain the three complete Nov22 value/competition review reports and their actual source/registry records in a small new evidence supplement. The main conclusions, estimates and the three earlier Theia/Extism/wasmCloud details are already maintained. A hash of a report, or a URL to its sources, is not the report text; this audit checked actual bytes inside tracked files, archives and inline JSON payloads before crediting preservation.

No additional useful unique research conclusion was identified in the reviewed differences of the other unmatched Markdown files. Detailed deepening/desktop/MF/delivery reports do exist as actual archived text. Their discoverability should improve in the maintained register. This is a conclusion about the finite corpus below, **not** a claim that nothing anywhere was missed.

Baseline: `agent-teams-ai/extension-foundation`, commit `7611e1a44542204d77e489a166f92a2e31b0020a`, tree `58ec9126f5156e9cc917e07e4d018ffee4c64e98`, Draft PR55. Parent publication `e182dc1a3f30f3e86511276a9b327ac476320972` happened during this review; the comparison remains pinned to the requested prior baseline. No repository file, original authoring lock, workflow, test, CI state or PR comment was mutated by this lane.

## Method and bounded inventory

AGENTS and the local docs-authoring skill were read before the audit. Repository reads used `git show <pinned-commit>:<path>`. Tar/ZIP members were inspected in memory without extraction to the filesystem. Only regular members were read. The split Nov21 packet was joined in memory in its declared part order. The inventory records every scoped tracked file, every regular archive member, every inspected embedded multiline string, every local candidate path and each disposition.

| Inventory dimension | Observed count |
| --- | ---: |
| Tracked files in `docs/research/` plus OD-003 | 163 |
| Maintained research Markdown files, including indexes | 31 |
| Additional tracked open-decision document | 1 |
| Archive containers, including one reconstructed split container | 52 |
| Regular archive members | 3,781 |
| Markdown archive members, including intentional repeats | 536 |
| Embedded multiline JSON strings indexed | 316 |
| Current local candidate `.md/.txt/.json/.log` files | 1,320 |
| Exact local content matches to actual persisted bytes | 1,035 |
| Local Markdown files / distinct contents | 304 / 133 |
| Local Markdown files with exact persisted text / distinct matched contents | 285 / 114 |
| Unmatched Markdown files individually dispositioned | 19 |
| Outer `.manifest.json` files reconciled to actual archives | 29 |
| Declared member entries reconciled | 2,095 |
| Archive read errors or manifest/member mismatches | 0 |

Counts include duplicate handoff copies and repeated evidence packets; they are not counts of unique findings, tests or independent experiments. The 29 manifest comparisons cover the manifests using the inspected outer archive schema, not a claim that every internal receipt implements the same schema. Their listed member sets exactly matched the actual regular-member sets. Both split part SHA/length pairs and the reconstructed archive SHA/length match.

| Available working report root | Candidate files | Exact matches | Markdown files | Exact Markdown matches |
| --- | ---: | ---: | ---: | ---: |
| `live-library-research-20261122` | 432 | 328 | 111 | 107 |
| `live-library-deepening-20261122` | 548 | 469 | 107 | 102 |
| `live-module-federation-research-20261122` | 315 | 238 | 78 | 76 |
| `live-update-value-assessment-20261122` | 17 | 0 | 7 | 0 |
| `live-update-competition-followup-20261123` | 8 | 0 | 1 | 0 |

Excluded directory names: `node_modules`, `.git`, `target`, `.pnpm-store`, `.cache`, `playwright-report`, `test-results`, `coverage`. Root dependency lockfiles and unrelated workspaces were not treated as authored reports. Selected original failed-runtime artifacts remain included through their tracked archives even when generated local report folders were excluded.

Previously cited roots `/workspace/scratch/58e9c088d2ee`, `/workspace/scratch/6b51c86fe5f1`, `/workspace/scratch/d62f92d8f405` and `/workspace/scratch/f863b9d38368` were unavailable. Historical Nov17/18/21 conclusions were inspected through actual retained packets, not a claimed reinspection of vanished working reports. This is a scope limit, not a blocker. The current five working roots and all retained research packets are sufficient to make the rescue decision above concrete.

## Reports to preserve now

Absolute source directory: `/workspace/scratch/95e187720be1/live-update-value-assessment-20261122/`.

| File | Bytes | SHA-256 of actual source bytes |
| --- | ---: | --- |
| `competition-runtime-sources.json` | 12,406 | `c660afc430b575a8b7736f337d68e1e8b126f1dd63748b8e2a286fafde39abb7` |
| `competition-js-sources.json` | 17,273 | `7f150e2cdc9179bcd43bf1dd888b2a4b6767c61e71cadb41a93811e09a58df65` |
| `competition-js.md` | 16,908 | `45a1e6bee5fed208a541334f3adea1ed11f2ca9586d2554a06f0b932b98ab570` |
| `sizing-and-critique.md` | 33,211 | `137de3f1fad4f6c3e56c1ba6a6fc71b8595fcaccd6e1ee53965e72a24e926c02` |
| `competition-runtime.md` | 20,127 | `cbb026d7f44df58598c075834d538355848d3373bb5b507996ed641b6b3748d1` |
| `competition-js-registry.json` | 8,155 | `ebeb28b9085d28a45ceb9ec685a76e5c567278221b56ef9be06163362d58e45a` |

Why preserve complete text:

- `competition-js.md` retains the detailed ready-stack comparison, implementation distinctions and fair-consumer qualification reasoning.
- `competition-runtime.md` retains an assembled nine-row consumer-E2E comparison matrix, exact runtime distinctions and the limitations that accompany them. Most underlying lessons already appear across maintained studies; the complete reusable analysis is still only a working report at this baseline.
- `sizing-and-critique.md` retains the full scenario/ownership rationale, two criticism rounds, counterexamples and the explanation of what is counted. The maintained budget and accepted narrowing are already saved.
- The two source ledgers and npm registry receipt retain the actual source records that explain these reports; simply copying their URLs/hashes is insufficient original-record custody.

The sizing report's intermediate complexity/reliability/relative-value scores remain **unadopted review judgments**. Adding a frozen original report must not silently replace the maintained assessment, turn those scores into availability probabilities, or adopt any of the seven OPEN owner choices. No new native qualification is claimed.

## Historical and current report custody map

All paths in this table are under `docs/research/evidence/`. `archive!member` means actual member text was read; JSON `#/...` denotes an actual embedded string, not a hash-only reference. Full names, lengths and hashes are in the JSON inventory.

| Study / lane | Actual preserved report examples | Maintained owning synthesis and important boundaries |
| --- | --- | --- |
| Nov17 portable mechanisms | `portable-live-plugins-20261117.tar.gz!portable-live-plugins-20261117/application-mechanisms/report.md`, `browser-mechanisms/report.md`, `ownership-and-library/report.md`, `runtime-mechanisms/runtime-mechanisms-report.en.md`; independent review rounds and root dispositions | `portable-live-plugin-mechanisms-and-library-design-2026-11-17.md`: consumer walkthroughs, replacement closure, operation/recovery boundaries and conditional estimates |
| Nov17 final architecture | `live-plugin-final-study-20261117.tar.gz!durable-rollout/report.md`, `mature-runtimes/report.md`, `emerging-runtimes/report.md`, `portable-boundary/report.md` plus review rounds | `live-plugin-evolution-final-research-and-architecture-2026-11-17.md`: one owner per invariant, OTP/OSGi/durable execution limits, state directionality and qualification slice |
| Nov18 live application | `live-application-evolution-20261118.tar.gz!backend-spike/report.md`, `frontend-spike/report.md`, `live-logic-industry/report.md`, `persistent-industry/report.md`, review and initial failure text | `live-application-evolution-vision-and-executed-spikes-2026-11-18.md`: useful behavior versus persistence, live code versus readiness, native experiment limits |
| Nov21 portable policies/Wasm | Split `plugin-update-runtimes-20261121.tar.gz` contains `backend-policy/report.md`, `frontend/report.md`, `wasm/report.md`, both hosted failure explanations, preparation attempts and review dispositions | `live-update-policies-and-portable-runtimes-2026-11-21.md`: selectable guarantees, ready runtimes/bindings, retained references and host authority; bounded mechanism runs |
| Nov22 reuse investigation | `plugin-reload-reuse-20261122.tar.gz!audit/REPORT.md`, `extism/report.md`, `industry/industry-report.md`, root reviews and browser evidence | `reuse-first-live-plugin-updates-2026-11-22.md`: existing ownership and warnings; published Resources versus private lifecycle kernel; SDK/typecheck and browser failure limits |
| Nov22 standalone initial lanes | `standalone-live-library-architecture-20261122.tar.gz!boundaries/REPORT.md`; `standalone-live-library-native-20261122.tar.gz!versions/REPORT.md`, `feedback/REPORT.md`; exact variants also in transfer/deepening packets | `standalone-live-plugin-library-blueprint-2026-11-22.md`: complete library operation, narrow authority/state primitives, version retention and visible feedback; no provisioned standalone remote |
| Nov22 deep control/state/execution/experience | `standalone-live-library-deepening-20261122.tar.gz!research/deepening/control/REPORT.md`, `state/REPORT.md`, `execution/REPORT.md`, `experience/REPORT.md`; full text also in checkpoint JSON | `live-update-reliability-and-industry-evidence-2026-11-22.md`: publication ambiguity, receiver fencing, durable receipt versus heap, retention, source-generation races and semantic Undo |
| Nov22 desktop and MF | `module-federation-research-supplement-20261122.tar.gz!desktop/REPORT.md`, `desktop/CAPABILITY-UPDATE-SCOPE.md`, `federation/REPORT.md`, `delivery/REPORT.md`, `root/REPORT.md` | `module-federation-update-boundaries-and-architecture-options-2026-11-22.md`: actual registration/evaluation/share scopes, native/UI restart scope, delivery/adoption and source-only limits |
| OPEN owner questions | Same MF supplement contains `architecture-review/OWNER-QUESTIONS.md`, `REVIEW-DISPOSITIONS.md`, desktop/delivery/federation `OPEN-QUESTIONS.md` | OD-003 and the MF study retain all seven choices as OPEN; lane preferences are recommendations, not owner adoption |
| Nov22 value and Nov23 competitive follow-up | Maintained assessment and `live-update-value-assessment-20261122.json`; the three original report texts need the supplement identified above | `live-update-value-competition-and-implementation-size-2026-11-22.md`: ready competitors, conditional value, complete-operation ownership, scoped estimates, no market census/uniqueness proof |

The structured reports include **18 execution, 13 state, 11 experience, 14 desktop, 13 MF and 15 delivery findings**. Their complete JSON entries and prose reports are present, with source-only, inferred, executed and unqualified distinctions. Names such as `/root/deep_state_protocol` and `/root/deep_experience_protocol` occur inside preserved reviews; they are reviewer lane identifiers, not evidence that a missing file named `deep_*` exists. The actual report paths are `state/`, `execution/`, `experience/` and `control/`.

Examples of retained useful detail: Argo successful-without-measurements semantics; OpenFeature observer continuity without activation authority; Comlink release versus physical stop; PostgreSQL same-statement uniqueness visibility; native resource cleanup debt; CodeMirror semantic Undo versus text Undo; Electron IPC-handler removal versus already dispatched effects; utility-process exit receipt limitations; ASAR/external-code boundary; SystemJS rebinding versus escaped references; loaded singleton selection; per-tab adoption versus shared delivery cookies. Archiving preserves these details. The final maintained register should make their exact report/member locations discoverable rather than imply every detail is restated in one summary page.

## Negative experiments and corrections were preserved

| Original observation | Actual preserved explanatory text | Correct interpretation retained |
| --- | --- | --- |
| Nov18 backend fixture failed before intended observations | `live-application-evolution-20261118.tar.gz!backend-spike/initial-harness-failure.md` | Activation UUID violated portable identity grammar; fixed immutable implementation identity. Not an Effect/Get Modular lifetime failure. |
| Nov21 Wasm hosted attempt 1 | Split runtime packet `wasm/hosted-attempt1.md` | WIT file existed; tool preopen capability was missing. No replacement scenario ran. |
| Nov21 Wasm hosted attempt 2 | Split runtime packet `wasm/hosted-attempt2.md` | Generated import object shape differed; suite remained 0 passed/1 failed despite earlier reached assertions. Later corrected input is separate. |
| Nov22 direct browser repair | Transfer/deepening packet `research/browser/hosted-attempt1/ANALYSIS.md` and dedicated failed ZIP | Hot-updated log did not imply useful repaired UI. Distinct v2 used one explicit public reload request; not proof of automatic repair. |
| Nov22 editor v1 | Deepening packet `research/deepening/experience/failure-analysis-v1.md`, original editor ZIP | Two of seven scenarios completed; 27/28 comparisons matched before wrong empty-panel oracle. Native empty-state and presentation placeholder remained separate assertions in v2. |
| Nov22 PostgreSQL v1 | Deepening packet `research/deepening/state/failure-analysis-v1.md`, original backend ZIP | 16/17 passed. RESTRICT returned 23001; original S13 stayed failed and reverse schedule was unreached. Corrected v2 17/17 is distinct evidence. |
| MF local browser preparation | MF supplement `federation/QUALIFICATION.md`, v1 attempt packet | Shared setup hook failed; zero semantic MF cases executed. Four failed test wrappers do not mean four proven MF behavior failures. |
| MF first hosted v2 delivery | `module-federation-v2-hosted-attempt1-20261122.tar.gz!HOSTED-ATTEMPT1-FAILURE.md` | Four native tests passed but upload failed and no artifact existed; corrected delivery run preserves observations, without doubling distinct coverage. |
| Local current-docs gate history | `live-update-value-validation-20261122.txt` | Original 6/8 failure with child-process status null remains; later hosted pass does not establish the unknown local cause. |

Deliberate unsafe controls (late source, wrong lock, stale effect, missing guard) are scientific counterexamples inside bounded experiments. They are not additional failed CI attempts. Source-only incident reports and new PostgreSQL19 mechanisms are not counted as newly executed evidence.

## Every unmatched Markdown file has a disposition

The inventory's exact-match result is stricter than semantic preservation: 19 unmatched files do **not** mean 19 lost conclusions.

| Local path relative to current scratch root | Disposition | Reason |
| --- | --- | --- |
| `live-library-research-20261122/root/transfer-assembly-audit.md` | assembly-review-superseded | Assembly instructions are implemented in the final transfer/deepening packet: frozen seed, workflow source, notices, failed attempt and successful v2 remain. It adds no unretained mechanism finding. The early 186-file count is not the final packet count. |
| `live-library-research-20261122/root/ci-4912aee/REPORT.md` | historical-ci-receipt | Read-only historical source-bound qualification report. Useful runtime/skip/merge-tree limits are not new library research; retain fresh final qualification separately instead of republishing all raw CI history. |
| `live-library-research-20261122/root/ci-6735ac8/REPORT.md` | historical-ci-receipt | Superseded checkpoint qualification report, including cancelled jobs; not a new native result or active qualification for the delivery head. |
| `live-library-research-20261122/root/ci-6735ac8/FINAL-HEAD-ROUTE.md` | historical-verification-procedure | Internal read-only source-binding procedure. The relevant rules already govern final qualification; not a missing design conclusion or executed result. |
| `live-library-deepening-20261122/root/study-draft.md` | superseded-draft | Compared with maintained reliability study. Pending rows were replaced by bounded actual results and expanded recovery semantics; no useful unique conclusion identified in removed draft lines. |
| `live-library-deepening-20261122/root/source/openfeature-events.md` | upstream-reference-copy | External specification snapshot, not a unique authored report. Exact source identity and findings survive in control/experience reports and source ledgers. |
| `live-library-deepening-20261122/root/source/argo-analysis-doc.md` | upstream-reference-copy | External documentation snapshot, not a unique authored report. Pinned termination/dry-run analysis and rollback-window findings survive in control/REPORT.md and the maintained reliability study. |
| `live-library-deepening-20261122/state/gitlab-migrations-source.md` | upstream-reference-copy | Unmodified GitLab migration documentation. State report, source ledger and maintained reliability study retain the application compatibility finding and its incident/root-cause limits. |
| `live-library-deepening-20261122/experience/SOURCE-REVIEW-v2.md` | postrun-addendum-already-preserved-semantically | Frozen pre-run review is archived; the later paragraph adds run 45042722838 success already retained by NATIVE-RESULT.md, checkpoint3 and the deepening packet. No new scenario/oracle was added. |
| `live-module-federation-research-20261122/root/FINAL-SYNTHESIS.md` | superseded-synthesis | Compared with maintained MF study. Final document retains ABI/unload distinction, all seven OPEN choices, same boundaries and actual corrected-hosted result instead of the draft receipt-pending row. |
| `live-module-federation-research-20261122/ci/final-7a45769/FINAL-AUDIT.md` | historical-ci-receipt | Historical source-bound gate receipt. Native MF/SystemJS results and prior failed attempts remain in maintained studies and their actual packets; no new native results originated in this CI audit. |
| `live-update-value-assessment-20261122/competition-js.md` | retain-full-authored-report | Main conclusions are synthesized, but the complete report is not present in the pinned tracked corpus. Preserve full text with its source ledger and label intermediate/unadopted ratings separately from maintained conclusions. |
| `live-update-value-assessment-20261122/sizing-and-critique.md` | retain-full-authored-report | Main conclusions are synthesized, but the complete report is not present in the pinned tracked corpus. Preserve full text with its source ledger and label intermediate/unadopted ratings separately from maintained conclusions. |
| `live-update-value-assessment-20261122/competition-runtime.md` | retain-full-authored-report | Main conclusions are synthesized, but the complete report is not present in the pinned tracked corpus. Preserve full text with its source ledger and label intermediate/unadopted ratings separately from maintained conclusions. |
| `live-update-value-assessment-20261122/PLAN.md` | administrative-plan | Work allocation and scope only; completed public assessment owns conclusions. |
| `live-update-value-assessment-20261122/recovery-backup/docs/README.md` | superseded-recovery-copy | Historical documentation index backup; current index is the maintained owner. |
| `live-update-value-assessment-20261122/recovery-backup/docs/research/plugin-system-research-reference.md` | superseded-recovery-copy | Historical index backup; current research reference contains the subsequent assessment and preserved detailed findings. |
| `live-update-value-assessment-20261122/recovery-backup/docs/research/live-update-value-competition-and-implementation-size-2026-11-22.md` | superseded-recovery-copy | Earlier assessment before final wording, validation and follow-up. Current assessment supersedes it; no unique approved conclusion identified. |
| `live-update-competition-followup-20261123/PLAN.md` | administrative-plan | Follow-up work allocation only; completed competitive-pressure judgments and source-backed additions are in head 7611e1a4. |

Unmatched structured files are separately classified in `custody-findings.json`. A supplementary scan found 136 unmatched multiline JSON payload occurrences, 130 distinct contents; 25 non-CI occurrences are earlier maintained-document/ledger publication snapshots. Other unmatched occurrences are historical CI metadata/log/body material. They were not counted as missing authored report texts. Source snapshots, temporary publication payloads, command logs and copied recovery drafts are not automatically useful new conclusions.

## Qualification and publication limits

The prior baseline CI [45082709665](https://github.com/agent-teams-ai/extension-foundation/actions/runs/45082709665) was observed read-only in terminal success, **5/5 jobs**. No rerun or new campaign was triggered. This observation belongs to `7611e1a44542204d77e489a166f92a2e31b0020a` and does not qualify the parent's later audit-document commits. The task's fresh documentation gates belong to their own final source.

This lane does not claim a new native execution, fresh competitor benchmark, shipped production library, merged main branch, or provisioned standalone repository. The branch/PR preserve research and prepared transfer material. Before closing the new custody action, inspect the final supplement bytes against the six exact originals, inspect its honest authority/rating labels, then verify the final maintained links and source-bound documentation qualification. Re-executing historical native probes is not necessary for a documentation-only custody update.

## Deliverables and next review

`custody-findings.json` contains the full finite inventory, all exact-text destinations, archive members, inline text pointers, manifest checks, 19 per-file prose dispositions, recommendations and explicit semantic-scope limits. This report describes why those mappings matter. A second pass should inspect the parent's saved final docs and supplement against these recommendations, without reopening unchanged archives wholesale.
