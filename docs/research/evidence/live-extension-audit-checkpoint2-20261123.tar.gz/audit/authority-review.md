# Authority, architecture and planning audit

Audit date: 2026-11-23. Investigator: `/root/architecture_decisions`.

Baseline: `/workspace/scratch/95e187720be1/live-update-value-validation`, commit `7611e1a44542204d77e489a166f92a2e31b0020a`, Draft PR55. Parent started a new documentation checkpoint during this audit; findings below refer to the baseline, not unfinished hub files. No repository edits, runtime tests, native experiments or policy adoption were performed in this lane.

## Conclusion

The architecture direction is substantially understood. Its durable core is: ordinary TS first; a separately reusable library implements the **complete** update operation; product authority, canonical state and feature semantics remain product-owned; composition, resources, loaders and runtimes are reused at their existing boundaries. Seven consequential product choices remain OPEN. The current material is much closer to a well-researched design brief than to an implementation-ready specification of one selected production profile.

The major documentation defect is **projection of current authority**, rather than an incorrect accepted ADR. The navigation still presents three historical owners, and several active historical research pages recommend a recipe/small adapter or leave repository independence open. Later owner records explicitly require a standalone library and complete operation. Those records are present, but a reader must reconstruct chronology to obtain the current answer.

Readiness judgment before the hub repair: **VISION approximately 85–90%; DOC approximately 65–75%; PLAN for a first bounded TS production slice approximately 50–60%**. These are coarse expert intervals about recorded clarity and specification completeness, not implementation progress, empirical probabilities or a promise that the remaining work is small. The rubric and concrete deductions are below. No percentage is assigned to production readiness.

## Audit method and scope

1. Read repository `AGENTS.md`, `.agents/skills/docs-authoring/SKILL.md`, README and indexes, accepted/superseded decision chain, architecture and OD-003. Used read-only `pnpm docs:info` and `pnpm docs:find -- --text 'hot replacement'` to verify catalog authority and discovery.
2. Cross-read the current standalone, reliability, reuse, Federation, research reference and value assessments against their governing records; reviewed authority, ownership, architecture, policy and qualification sections of preceding synthesis documents.
3. Rechecked apparent conflicts against dates, supersession and exact scope. Historical hypotheses were not treated as newly adopted defaults. Native receipts were read as bounded evidence; no experiments were rerun.

The organizational Engineering Quality Standard was available from the prior inspected exact source `0b44c64c824f536bd1b085341e7669bcc64ef124`; this audit does not claim a fresh check of moving organizational main. The existing EF FMS v1 adoption remains distinct from the prospective standalone seed's FMS v1.1 source. Raw vendor archives and every archived third-party source were not re-audited by this authority lane; a separate evidence lane can establish their integrity. The coverage inventory is explicit in `authority-findings.json`.

## 1. Authority ledger: what is fixed and what is not

| Topic | Authority / present status | Consequence for the current hub |
| --- | --- | --- |
| EF scope | Accepted ADR-0001; `docs/architecture/overview.md#ownership` | Artifact/trust/distribution/protocol/conformance neutrality; EF is not a product runtime or business platform. |
| Catalog and artifact profile | Accepted ADR-0002–0005; OD-001 resolved; OD-002 OPEN for operating parameters | OCI/ORAS/Cosign and PostgreSQL catalog authority apply within that profile. They do not become mandatory infrastructure for every ordinary library consumer. |
| Feature, library core, module adapter, package, plugin artifact | Role discipline in ADR-0013 retained by ADR-0015; `docs/architecture/extension-model.md` | These are different roles and lifecycle/release boundaries. An adapter or built-in module is not automatically a distributable plugin. |
| Neutral composition | Accepted ADR-0015, §§Independent Get Modular ownership / Separate attempt-scoped construction | Get Modular owns neutral identities, declarations, bindings, graph, plans/digests and diagnostics. Optional construction does not activate or authorize code. |
| Older module authorities | ADR-0012 superseded by ADR-0013; ADR-0013 superseded by ADR-0015 | Do not recover obsolete Foundation-owned graph semantics or block independent GM0.x behind old two-consumer extraction language. Preserve accepted history. |
| Product authoring | Accepted ADR-0014 | Inert colocated declarations, explicit bindings, target-local literal loaders and product-owned concrete payloads. No executable discovery or global registry. |
| Identity and replacement invariants | ADR-0014 plus conditionally applicable ADR-0011 | Content digest, candidate generation and monotonic head revision differ. Affected closure and authority must remain coherent. Same-realm JS replacement does not imply physical unloading. |
| Production host safety | Accepted cumulative ADR-0011, explicit applicability scope | Admitted production host profiles retain admission, custody, state and effect safety. Do not impose the whole production-host floor on static composition or every ordinary library experiment. |
| Delivery baseline | OD-003, owner-confirmed 2026-10-25 | Static composition/controlled restart remains the delivery baseline; later live vision expands the goal without silently selecting every stronger availability policy. |
| Product vision | OD-003, owner records 2026-11-14 and 2026-11-18 | Substantive frontend/backend live evolution, durable/shareable/manageable plugins and eligible built-ins. This is not restricted to a trivial calculator plugin. |
| Library/repository and language | OD-003, owner-confirmed 2026-11-22 §§Standalone library / Architecture | Separate purpose-neutral library/repository; TS control and ordinary TS plugins first; optional Wasm/Extism and native Effect profiles. Exact public API, adapter implementation and release adoption remain separate. |
| Complete operation | OD-003 2026-11-22; current blueprint/reliability/Federation syntheses | The library supplies planning, switching, recovery/cleanup coordination and observable results. Consumers provide narrow authority/state primitives; they do not reconstruct the coordinator. |
| First profile policies | OD-003 2026-11-22; Federation §Owner decision matrix | Q1 trust, Q2 sharing/update unit, Q3 state continuity, Q4 visible adoption, Q5 admitted work, Q6 return to old version, Q7 old clients: all OPEN. Preferred options are recommendations, not defaults. |
| Existing provider direction | OD-003 §Owner decision brief 2026-11-06; `plugin-choice-deepening-2026-11-06.md` | AR ADR-0091's interactive provider direction is already accepted at its recorded source. A new library slice does not reopen contained-vs-interactive selection or transfer its contract ownership. |
| Evidence status | Individual research reports and exact receipts | Compiler/native/source inspection and documentation delivery each have their own scope. Passing MF/SystemJS/Resources/editor probes is not complete library or actual product E2E. |

The words “accepted direction” in research should be read as an owner-confirmed scope statement where they cite OD-003, not as a newly accepted architecture ADR. `active` research metadata is a catalog status, not adoption.

## 2. Current ownership should expose both authority and implementation

| Responsibility | Authoritative owner | Implementation/reuse responsibility |
| --- | --- | --- |
| Capability meaning, grants, intended selection, canonical data | Consuming product/domain | Supplies narrow operations and truthful evidence; retains business policy. |
| Complete update use case | Runs for that product authority | Standalone library coordinates the selected operation, recovery and retirement once. It must not offload races, retries, candidate bookkeeping or cleanup recovery to every consumer. |
| Neutral composition | Get Modular | Reuse its plan, bindings and diagnostics; no second graph compiler or alternate digest. |
| Resource scope and actual executor life | Existing Resources/native Effect/executor owner | Reuse real acquisition/cleanup/exit observations. A coordinator is not another resource counter or supervisor. |
| Artifact trust and distribution where EF is adopted | Existing EF/product admission and deployment owners | Reuse artifact admission and immutable identity; no second catalog/head or new permission authority. |
| Framework/client adoption and delivery | Existing renderer, loader, deployment/platform owner | Adapters map actual guarantees and observed state to the library result. Unsupported guarantees remain explicit. |

This resolves the apparent “product owns lifecycle, therefore product must write orchestration” conflict without changing the accepted authority boundary. It also avoids the reverse error of giving the new library independent canonical authority.

Sources: `docs/README.md:83–96`; `docs/research/plugin-system-research-reference.md:237–267`; OD-003:83–109; `standalone-live-plugin-library-blueprint-2026-11-22.md:268–345`; `module-federation-update-boundaries-and-architecture-options-2026-11-22.md:223–280`.

## 3. Findings requiring a current-state repair

These are documentation/specification findings, not newly selected policies. The machine-readable inventory records severity, class, sources, stage and suggested disposition.

| ID | Finding and risk | Concrete disposition |
| --- | --- | --- |
| A01 | The entry index and research reference retain a three-owner implementation table without the owner-confirmed complete-operation library. A reader can incorrectly make every consumer assemble the update algorithm. | Add a current responsibility map separating authority from reusable implementation; link the Nov22 owner record. |
| A02 | Historical active reports still call themselves current and recommend recipe/small residual/no required separate repository. Examples: Nov17 final-study opening and §§Options/Final position, Nov18 architecture, Nov21 architecture, Nov22 reuse §Architecture/Cost. Dates make them history, but direct search does not make their replacement obvious. | One current hub, with dated successor notes on entry points. Preserve original observations/estimates and immutable packets. Current library scope and 3–6k MVP estimate must not be replaced by a historical 150–350-line integration band. |
| A03 | OD-003 lower Shared Host Mechanics TODO still says a residual package/independent repository remains open; its Nov22 owner records resolve the separate-project and complete-operation direction. The remaining contract/runtime questions are still open. | Add an explicit partial-resolution cross-reference; do not close the whole TODO or ask the owner to reapprove the repository. |
| A04 | No named first actual library consumer/feature, acceptance workload and independent second integration are committed as the first delivery. Candidate renderer/provider/editor examples are research. | Record a first-slice specification with actual actors, useful behavior, state/resource owners, supported profile, exclusions and an independent integration. Preserve the existing accepted provider journey. |
| A05 | Seven questions are prepared, not answered; they are not the entire release backlog. Exact public compatibility/versioning, artifact closure, adapter availability and qualified packaging remain separate work. | Link each selected-scope specification item to Q1–Q7 or its existing accepted owner; separate “needs owner answer” from engineering specification that can proceed after that answer. |
| A06 | Runtime/format/profile knowledge is scattered. “Adapter” can be misread as interchangeable JS loader, security boundary, language ABI and lifecycle implementation. | Publish a capability matrix with current/proposed/unsupported/qualified scope, exact promise and limitation. Ordinary TS, native Effect, MF/SystemJS, Worker/process, Extism and Component Model must remain distinct. |
| A07 | Complete operation is well explained but its first production contract is not selected: authority primitive preconditions, attempt identity, authoritative read/reconcile, unknown publication, restart recovery and cleanup debt are not one implementable specification for a named profile. | Specify the smallest complete use case and transition/outcome table for the selected host. Consumer ports remain primitives; library owns their sequencing and recovery model. Do not make persistence mandatory for hosts without that requirement. |
| A08 | “Smallest component update” still depends on sharing policy, actual captured references, realm and state compatibility. A file/module diff alone cannot determine the unit. | For Q2, specify shared platform/contracts, affected dependency closure and runtime constraints; use Get Modular topology and explicit compatibility evidence rather than a parallel graph authority. |
| A09 | Data, editor/view state, Undo/IME/collaboration, plugin-private schema and external effects have different continuity contracts. Rich probe evidence does not choose which promise the first product makes. | Q3/Q6 map each promised state class to owner, baseline/version, reset/migration/recovery and test oracle. Distinguish compatible overlap from strict old-writer fencing. |
| A10 | Old-generation execution, source assets, offline clients, code/schema decoders, user drafts and durable data have different retention reasons. Q7 still lacks a supported window and budgets. | Specify actual old-client/adoption contract and retention holds for the selected product; show desired/selected/displayed versions and cleanup debt. Do not infer adoption from deployment or erase data on plugin removal. |
| A11 | Release availability and bootstrap remain separate dependencies: private lifecycle kernel, Extism TS declarations, unpublished wash-runtime source, and standalone tooling cohort are not all ready public dependencies. | Carry an availability/qualification ledger; pick a supported reuse path for the selected slice without copying private code or silently weakening compiler/tooling pins. Historical access failures are not new permission requirements. |
| A12 | Current evidence does not exercise one packaged complete-library operation with an actual consumer and independent external integration. | Put this gap in the plan as an explicit acceptance chain. Reuse bounded probes at unchanged inputs; only add tests for remaining profile risks. A green docs gate is not closure of this gap. |
| A13 | Package admission, ordinary-library qualification, stable public SPI, GM1.0 and production-host adoption can be conflated. They have distinct accepted gates. | Keep a short gate map. Do not require all future SPI/production-host obligations before a private library slice; do not promote a fixture pass into public-SPI adoption. |
| A14 | There is no compact canonical mapping from module roles to authoring language, executable format, trust/placement and distribution. | Add the dimensional explanation below; avoid one public “plugin descriptor” that erases unrelated domains. |
| A15 | Structural documentation tooling verifies catalog metadata, not semantic freshness. Chronological research has repeatedly accumulated corrected estimates/owners/source statuses. | Maintain a hub as a derived current view, with source authority, observation date, open decisions, evidence limits and explicit historical supersession links. Keep one unresolved-decision authority, OD-003. |

### Concrete source anchors for the findings

- A01: `docs/README.md#ownership-at-a-glance`; `plugin-system-research-reference.md#keep-the-three-implementation-boundaries`; OD-003 §§Owner-confirmed architecture / Standalone library.
- A02: `live-plugin-evolution-final-research-and-architecture-2026-11-17.md:15–19,535–568,606–624`; `live-application-evolution-vision-and-executed-spikes-2026-11-18.md:225–268`; `live-update-policies-and-portable-runtimes-2026-11-21.md:99–139`; `reuse-first-live-plugin-updates-2026-11-22.md:291–336,530–565`; current scoped totals in `live-update-value-competition-and-implementation-size-2026-11-22.md#production-code-estimates`.
- A03: OD-003:111–143 compared with 537–589, especially the dated October22 bullet at570–573.
- A04–A07: `standalone-live-plugin-library-blueprint-2026-11-22.md:439–524`; `live-update-reliability-and-industry-evidence-2026-11-22.md:71–111,263–286`; `module-federation-update-boundaries-and-architecture-options-2026-11-22.md:282–335`; OD-003:502–627.
- A08–A10: ADR-0014; `module-federation-update-boundaries-and-architecture-options-2026-11-22.md:67–200,223–260`; `standalone-live-plugin-library-blueprint-2026-11-22.md:346–437`; `live-update-reliability-and-industry-evidence-2026-11-22.md:112–210`.
- A11–A12: `reuse-first-live-plugin-updates-2026-11-22.md:124–183,513–528`; `standalone-live-plugin-library-blueprint-2026-11-22.md:465–524`; `live-update-reliability-and-industry-evidence-2026-11-22.md:246–286,395–415`.
- A13–A15: `docs/architecture/overview.md#package-admission`; ADR-0011 applicability; ADR-0015; `docs/architecture/extension-model.md`; `plugin-system-research-reference.md:297–401`; `architecture/foundation/document-authoring.yaml` and installed `docs:info` output.

## 4. Module/adapter scope without a universal format

| Dimension | Examples already discussed | What remains separate |
| --- | --- | --- |
| Architectural role | Feature, ordinary library core, module adapter, package, independent plugin artifact | Release or installation boundary is not a domain/module boundary. |
| Authoring language | Ordinary TypeScript first; other languages through selected adapters | TS authoring does not require Wasm; Rust guest does not require a Rust host. |
| Composition model | Get Modular declarations, bindings and immutable plans | Not the package loader, native executable format or security principal. |
| Executable delivery/loading | Target-local imports; MF remotes/shared scope; SystemJS registry; host artifacts | Registry replacement does not select the product generation or revoke retained references. |
| Language/transport contract | Native narrow TS ports; Extism ABI; generated WIT/Component Model; selected RPC | Extism and Component Model are different contracts. Rich native APIs need not be serialized just to anticipate a future guest. |
| Placement and lifetime | Same realm, worker, process, Wasm engine, framework mount | Stop, cleanup, authority and memory guarantees differ; matching method names are insufficient substitution. |
| Optional native integration | Effect environment, causes, scopes and interruption | Effect is an execution/resource profile, not a plugin file format or mandatory neutral public dependency. |
| Distribution/trust | npm/package, immutable URL/CDN, explicitly adopted EF OCI trust profile | Installed bytes, admitted code and permission to act are distinct. No universal marketplace is required by the ordinary library. |

The current architecture should preserve those seams, not freeze every package, format or transport now. A concrete profile needs compatibility fixtures and truthful unsupported results. The evidence does not justify automatic conversion of arbitrary existing modules into live, state-compatible plugins.

## 5. Decision staging and missing specification

**Before selecting the first production vertical slice:** name the real consumer/use case; resolve its Q1 trust, Q2 shared/update unit and Q3 state continuity; identify current authority, actual resource owner and supported dependency packages. This is not permission to reopen an already accepted provider contract.

**Before promising user behavior:** resolve applicable Q4–Q7 for that product/profile. The required specification includes how changes become useful/visible, retained operations, state-compatible return to an old revision, old-client windows and pressure/cleanup outcomes. Research can use explicit temporary policies without turning them into product defaults.

**Before implementation can be reviewed end to end:** define the complete operation's identities, observations, legal transitions, authority primitives and unknown outcomes; exact contract/compatibility rules; a bounded recovery profile; target scope and package entrypoints; actual consumer wiring and independent conformance. An implementation plan must say what “done” proves and what remains unsupported.

**Can wait for demonstrated need:** a second guest language, full Extism/WIT choice for unrelated features, every desktop/SSR transport, fleet-wide rollout and marketplace, a universal migration protocol, all future package names, and stable public SPI breadth. Preserve seams without assigning their full implementation cost or making them first-slice blockers.

## 6. Readiness rubric

Readiness means **how completely the document set answers the questions needed for its stated next action**. It does not count pages, source citations, passing probes or already written production LOC. A mature unresolved decision can improve decision preparation while still preventing a product promise from being considered specified.

Each weighted criterion is judged on five ordinal levels: absent; named; alternatives/limits documented; coherent for a named applicable scope; traced/reviewed with an acceptance plan. Approximate percentage bands summarize that qualitative judgment; changing one reviewer judgment should not imply a one-point scientific measurement.

| Axis | Weighted criteria | Current estimate | Specific remaining work |
| --- | --- | --- | --- |
| VISION | Owner outcomes25%; audience/non-goals20%; semantic boundaries20%; user promises20%; scope priorities15% | **85–90%** | Prioritize the actual first user journey and distinguish durable competitive hypothesis from a demonstrated consumer benefit. The desired broad outcome, TS-first scope and ownership are clear. |
| DOC | Authority traceability25%; discoverability/current projection20%; bounded evidence20%; contract/profile completeness20%; maintenance/dispositions15% | **65–75%** | Current hub and fourth implementation role; partial-resolution map; typed profile/capability matrix; linking each gap to source and stage. Rich evidence is already a strength. |
| PLAN | Named first consumer/scope20%; required policy closure20%; implementable complete-operation contract20%; ordered acceptance sequence20%; reuse/release/bootstrap prerequisites20% | **50–60%** | First consumer not fixed; Q1–Q7 OPEN; first contract/recovery profile not selected; one complete packaged operation plus independent integration still unplanned at exact interfaces; tooling/private dependency path unresolved. Existing staged proposals and failure cases prevent a lower score. |

If one aggregate is unavoidable, use **VISION25% + DOC35% + PLAN40%**. The above bands yield 64–72.75 before rounding, so communicate **roughly 65–75% of the planning/documentation package**, not 69% precision. The unrounded arithmetic is only to make the weighting reviewable. It is not a measurement.

The denominator is the design/planning package for the proposed bounded TS-first library and its first real delivery. It is **not** every future runtime/platform in the broad vision. A complete hub alone could raise DOC; it cannot raise PLAN to 90% without the unresolved scope and behavior decisions. A larger all-runtime product needs a separate scope and would have lower specification completeness.

## 7. Suggested current-state hub

Use one discoverable proposed architecture map plus one detailed current audit/research record, linked from README, docs index and research reference. It should be a derived map of accepted sources and owner directions, not a new competing decision registry.

1. Current purpose, owner-confirmed direction and implementation status.
2. Glossary separating module/library/plugin/adapter and the format dimensions.
3. Ownership map separating canonical authority from the complete library implementation.
4. Fixed invariants, supported/proposed profile matrix and concrete seams.
5. Lifecycle of an update, separately identified desired/selected/useful/retired outcomes, state and retention owners.
6. Current evidence coverage and exact limits, linked to preserved receipts.
7. Seven OPEN choices, preferred alternatives, triggers and staged prerequisites; other public compatibility work remains visible without generating thirty new owner questions.
8. First-slice plan, dependencies, acceptance outcomes and deferred breadth.
9. Readiness rubric and maintenance rules, with a dated source head.

Avoid copying every vendor case or chronological experiment log into the hub. Link detailed research. Retain warnings where decisions are made: selection, invocation, resource owner, state, delivery, client adoption and recovery. The hub should answer a new contributor's “what do I implement, whose authority do I use, and what must I not assume?” in one reading.

## 8. Architecture fitness questions for the next review

- Can an independent consumer call one operation without rebuilding candidate race handling, state-baseline validation, recovery and retirement accounting?
- Does any library object introduce a second head, graph digest, grant, resource counter or independently advancing supervisor?
- Can a second real execution profile be added without changing feature semantics or pretending a weaker stop receipt satisfies a stronger one?
- Does an admitted call/stream keep the required generation through continuations while current authorization remains separately enforceable?
- Does a dependency/realm/shared-token change expand or reject the update coherently, including references captured outside the changed file?
- Can the UI distinguish deployed, desired, selected and useful versions, and explain deferred/reconstructed/restart-required behavior with the promised state continuity?
- Can removal of code leave explicit state/artifact/history holds without silently deleting user data or claiming physical cleanup from timeout?
- Do private dependency availability and failure recovery remain inside the complete-library integration contract rather than becoming undocumented consumer work?

These are focused review questions, not a new universal certification suite. They reduce foreseeable coupling; they cannot promise zero future refactoring.

## Preservation confirmations

- No accepted ADR needs rewriting to implement this current-state repair.
- The three identities in ADR-0014 and the independent GM ownership in ADR-0015 remain compatible with the proposed library.
- Clean Architecture/SOLID/DRY have concrete meanings here: one owner per invariant, explicit dependency direction, narrow behavioral ports, supported substitution, no ceremonial package/layer inventory.
- Existing source/probe evidence must remain scoped; current MF4/4, SystemJS2/2 and earlier native runs do not replace a complete library or real-product acceptance test.
- The seven options remain OPEN. This audit selects none, creates no new runtime/API and authorizes no production migration.
