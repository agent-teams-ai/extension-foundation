# Готовые стеки, форматы плагинов и полная операция обновления

Дата: 23 ноября 2026. Источники проверены 22–23 ноября UTC. Репозиторий: live-update-value-validation, HEAD **7611e1a44542204d77e489a166f92a2e31b0020a**.

**Статус:** исследование и предложения для сравнения. Новых решений, production API, адаптеров, установки пакетов и нативных прогонов в этой работе нет. Семь вопросов владельца остаются OPEN. Ссылки [R…/P…/N…] раскрыты в конце; точные ревизии и ограничения — в stack-sources.json.

## 1. Прямой ответ на вопрос о нашей документации

**Все названные направления уже записаны, но это не обязательство поддерживать их.** На проверенном HEAD поиск Piral/pilet/Native Federation/OpenComponents по docs находит competition research, его evidence ledger и validation log. Отдельного принятого контракта адаптера или квалификации полного пользовательского сценария для этих форматов этот поиск не обнаружил. У Module Federation гораздо более глубокая отдельная работа: source review и четыре настоящих браузерных случая. Она также не означает принятие production runtime. [R02, R04, R05]

В OD-003 принята более высокая архитектурная граница: управляющая библиотека на TS, обычные TS-плагины, возможные отдельные Wasm/Extism/native Effect профили. **Вся операция обновления реализуется один раз в самостоятельной библиотеке.** Продукт предоставляет узкие механизмы полномочий и канонического состояния; ему не передаётся набор hooks, из которых надо собрать эту операцию заново. Выбор конкретного загрузчика, форматов и семи продуктовых политик не сделан. [R03]

| Направление | Зафиксировано для нашего проекта | Что пока не установлено |
| --- | --- | --- |
| Module Federation | Отдельный source review, точные версии, ограниченный browser spike 4/4 | Production adoption, весь редакторский сценарий, все framework/host profiles |
| Piral/pilets + Piral Cloud | Конкурентный baseline; теперь дополнительно проверены точные lifecycle/state/MF-loader paths | Нужна ли совместимость с Pilet API; выбранный профиль; достаточность готового shell |
| Native Federation | Уже названо в competition inventory; теперь исследованы отдельные v4 builder/orchestrator | Production adapter; same-name live replacement; совместимость выбранного builder с нашей TS policy |
| OpenComponents | Уже названо в inventory; теперь исследован конкретный browser-client lifecycle | Выбранный server/browser/template профиль; полноценный plugin contract и state continuity |

Формулировка «в системе будет поддержка всех четырёх» сейчас сильнее принятого решения. Корректно: «это известные, непосредственно пересекающиеся с проектом механизмы; возможные роли и ограничения исследованы».

## 2. Это разные слои, а не четыре взаимозаменяемых runtime

| Решение | Основные роли | Что непосредственно пересекается с плагинами |
| --- | --- | --- |
| **Piral Cloud** | Discovery, доставка, выбор активных версий, environments/approval | Откуда брать допустимые версии и какой набор модулей доступен клиенту |
| **Pilet + Piral shell** | Формат авторинга, предоставляемый shell API, UI contributions, setup/teardown, shell data API | Как расширение регистрирует UI и получает host capabilities |
| **Module Federation** | Контейнеры/модули, remote loading, shared modules и reference identity | Как получить исполняемую реализацию; как разделять зависимости |
| **Native Federation v4** | Builder, ESM artifacts/metadata, import maps, shared resolution и runtime loading | Альтернативный механизм упаковки/загрузки JS-модулей |
| **OpenComponents** | Версионированный UI-компонент, registry, optional server logic, template/client rendering | Доставка и отображение UI-компонентов с конкретными lifecycle hooks |
| **single-spa** | UI application/parcel composition, async mount/unmount/unload, framework helpers | Готовая координация UI lifecycle |
| **Zephyr** | Доставка и управление релизами; конкретные клиентские OTA integrations | Выбор версии, уведомление/применение обновления, rollback маршрутизации |

Основания: [P01–P07, S01–S03, F01, Z01–Z02, N01–N04, O01–O05].

Слово state здесь особенно неоднозначно. В Piral есть shell data API; в Native Federation — состояние resolution/cache; в OpenComponents поле oc.state обозначает статус компонента, например experimental/deprecated. Это разные данные с разными владельцами. Наличие любого из этих механизмов не доказывает перенос несохранённого документа, но и утверждать «у конкурентов нет состояния» нельзя. [P06, N04–N07, O05]

Название Native Federation относится к нативным механизмам веб-платформы, прежде всего ES modules/import maps. Это не эквивалент Extism, native binary host или исполнения гостей на произвольных языках. OpenComponents допускает потребление через HTTP/HTML из разных host stacks; это также другое свойство, чем Wasm guest execution. [N01–N02, O01]

### «Адаптер» и «под капотом» совместимы

Возможный адаптер использует существующий механизм под капотом. Например, входной формат может быть pilet, исполняемый артефакт — MF remote, lifecycle — Piral, доставка — Piral Cloud. **Такое сочетание уже существует:** у Piral есть собственный MF pilet loader; pilet и MF не взаимоисключающие альтернативы. [P07]

Пока обоснованы границы ответственности, а не новые обязательные пакеты:

- Источник версий может выдавать артефакты из Cloud/registry без передачи ему права самостоятельно публиковать выбранное состояние приложения.
- Загрузчик предоставляет существующие load/evaluation/share semantics; библиотека учитывает их реальные пределы.
- UI bridge опирается на lifecycle конкретного framework/shell. Поддержка чужого авторского формата может потребовать совместимости с его API, а не только чтения manifest.
- Механизмы исполнения/владения ресурсами сохраняют свою семантику. Library operation согласует их, не подменяя новым универсальным disposer.
- Канонические данные и полномочия остаются у соответствующего продуктового владельца. Общая операция и recovery logic остаются внутри самостоятельной библиотеки. [R03–R04]

Загрузить React-компонент ещё не значит предоставить полноценное расширение с командами, доступом к данным и полномочиями. Обратное тоже возможно: для части задач достаточно готового UI-компонента, и насаждать более широкий plugin protocol невыгодно. Это архитектурный вывод из различия контрактов, не новый выбранный SPI.

## 3. Сильные готовые baseline и реальные границы

### 3.1. Piral + Piral Cloud + готовый loader

Это ближайший серьёзный baseline для расширяемого UI: готовый shell, pilet lifecycle, управляемые UI registrations, shell data API, доставка и управление версиями. Cloud поддерживает несколько форматов, включая MF, Native Federation и OpenComponents. Ограничивать сравнение «самодельным loader против нашей полной системы» было бы нечестно. [P01–P02, P05–P07]

В source cohort **npm piral 1.12.5 / commit 15af4fd…** обнаружены точные completion boundaries:

- addPilet выполняет load → inject → setup. На inject заменяется запись того же имени, удаляются её зарегистрированные contributions и отправляется unload. Поэтому этот путь сам по себе не доказывает модель «старый полностью действует до успешной готовности нового». [P03]
- setupSinglePilet ловит и логирует ошибки setup. Fulfilled Promise внешнего action нельзя автоматически использовать как подтверждение успешного прикладного readiness. [P04]
- Cleanup уже снимает собственные регистрации/часть loader artifacts и вызывает teardown. Но в проверенном пути нет ожидания завершения произвольной асинхронной teardown-работы. [P03, P05]
- getData/setData и disposers для registrations — готовые полезные механизмы. Их следует учитывать до проектирования собственного shell state/registration API. [P06]

Это source observations, а не доказательство невозможности более сильного решения на Piral. Custom hooks, wrappers и приложение могут дополнить контракт. Сколько именно кода и какие гарантии потребуются для нашего сценария — **UNKNOWN до сравнительной реализации**.

### 3.2. single-spa + framework helper + MF + Zephyr

Здесь готовые части закрывают разные уровни: single-spa управляет async lifecycle, React helper делает framework mount/unmount, MF загружает модули, Zephyr управляет версиями и клиентским принятием в конкретных интеграциях. **Это предложенный составной baseline из существующих механизмов, не заявление о едином уже квалифицированном vendor bundle.** [S01–S03, F01, Z01–Z02]

single-spa принимает Promise-based lifecycle и умеет unload/rebootstrap. Очистка приложения, его подписок и глобальных эффектов входит в contract его unmount. React helper уже реализует часть этой работы; не следует объявлять UI cleanup новой функцией нашей библиотеки. unregisterApplication при этом не означает стирание loader registry или всех сохранённых ссылок на код. [S01–S03]

У Zephyr уже описаны prompt и замена feature component на месте, а не только deployment dashboard. Текущая Electron интеграция — **Beta**, ограничена renderer feature с Vite/React; main/preload/native/app-shell изменения требуют обычного релиза. Состояние вне заменяемой feature может оставаться в shell; сохранение произвольного внутреннего редакторского состояния этим не установлено. [Z01]

Rollback у Zephyr переключает релизную маршрутизацию. Уже работающий клиент принимает старый релиз через свой очередной check/load flow. Это хороший готовый механизм, но переключение routing, окончание принятия клиентом и обратимость внешних side effects — разные факты. [Z02]

### 3.3. Native Federation v4: не переносить выводы о v3

Текущее семейство разделяет core builder и orchestrator. Published metadata показывает **core 4.10.1** и **orchestrator 4.10.2**. У прочитанных immutable source commits package.json всё ещё 4.10.0, а в npm metadata нет gitHead. Поэтому ниже указаны **механизмы конкретных pinned sources**, без приравнивания их к проверенным байтам npm tarball. [N01–N08, M02–M03]

Существенные контрпримеры преувеличенной новизне:

- Orchestrator уже делает stages init и rollback подготовленных repository/cache records при ошибке. Rollback сохраняется даже при исключении пользовательского logger. Неверно приписывать ему только fetch/import. [N05–N06]
- Его dynamic init работает относительно committed mappings; это добавление, а не повторный выбор всех уже разрешённых shared versions. Известный remote не заменяется повторным dynamic init с другим URL. Следовательно, данный public path нельзя без проверки объявить обычной операцией v1→v2 того же logical plugin. [N03–N04, N09]
- В source commit-changes результат async setImportMapFn намеренно не ожидается до commit repositories; preload ожидает его отдельно. Promise завершения init и ack конкретного async setter — разные границы. Это предусмотренный upstream design, не общий диагноз ошибки. [N07]

Отдельный adoption gate: **published core 4.10.1 зависит от TypeScript >=5 <7**; upstream объясняет использование JS compiler API при каждой сборке. Это конфликт выбранного build core с нашим требованием TS >=7.0.2. Orchestrator имеет другую зависимостную границу; нельзя превращать build conflict в запрет всего runtime семейства. Здесь нет установки, override или выбора обходного пути. [R01, N08, M02–M03]

Практический вывод: готовый shared resolver, metadata и cache алгоритмы надо изучать и переиспользовать при подходящем профиле. Из них не следует автоматически нужная операция замены; подготовка совместимого artifact/profile остаётся отдельной квалификацией.

### 3.4. OpenComponents: больше, чем HTML loader

Готовые составляющие — версия компонента, registry, серверные данные/логика по профилю, template/client rendering и события lifecycle. Это прямое пересечение с доставкой UI-расширений. [O01–O03]

В **oc-client-browser 2.1.13 / gitHead 806b6a08…** source есть custom-element lifecycle: при disconnect клиент ждёт следующий tick, не делает teardown если элемент уже подключён снова, и при включённом lifecycle вызывает доступный unmount. Это полезное готовое поведение, в том числе против ложного teardown при перемещении DOM. [O04]

При этом ESM path вызывает mount без ожидания возвращаемой Promise; disconnect path также не ожидает произвольный async unmount. Событие rendered/unrendered нельзя переименовать в доказательство готовности приложения/завершения всех ресурсов без конкретного bridge contract. Это узкая source boundary, не отсутствие lifecycle вообще. [O03–O04]

**Версии нельзя смешивать:** oc 0.50.67 ссылается на browser ^2.1.13 и Node client ^4.0.4, но сам oc-client 4.0.4 фиксирует browser **1.5.4**. Новые выводы о browser 2.1.13 не распространяются автоматически на server-rendered страницы, использующие другой клиент. Full installed/template/compiler graph здесь не квалифицирован. [M04–M06]

## 4. Один честный сравнительный сценарий

Следующий сценарий — **предложение для проверки ценности**, не выбранный production default и не уже пройденный E2E. До его выполнения нужно выбрать один конкретный host/UI/profile, одинаковый для baseline и нашей библиотеки. Допустимы лучшие готовые state/resource helpers у обеих сторон.

### Начальное состояние

В работающем редакторе v1 есть несохранённый текст D1 и canonical revision r1. Старый in-flight запрос был принят раньше, для r0. У поколения есть timer, listener и подписка; у каждого видимый владельцу handle/identity. Пользователь продолжает редактирование. Внешний backend и разрешённые state/authority primitives одинаковы для всех сравниваемых реализаций.

Для первого bounded сравнения достаточно явно обещать сохранность текста и отсутствие stale overwrite. Cursor/selection/undo/IME нужно включать только при выбранном concrete framework contract; нельзя молча считать их сохранёнными вместе с документом.

### Последовательность и наблюдаемые результаты

| Шаг | Проверяемое поведение | Что нельзя подменить слабым сигналом |
| --- | --- | --- |
| Найти v2 | Получены точная версия/артефакт и допустимость выбранного профиля | Feed содержит v2 ≠ текущий редактор уже обновлён |
| Подготовить | Установлено, что исполнилось, какие ресурсы заняты и готов ли кандидат в допустимом объёме | load/Promise fulfilled ≠ отсутствие side effects или readiness |
| Применить | Пользователь видит реальную новую возможность, например изменённый результат команды, при сохранённом обещанном D1 | Только смена version label не считается полезным обновлением |
| Завершить старую работу | Результат r0 учитывается по выбранному contract и не затирает более свежий D1; есть итог принятой операции | Timeout или просьба отменить ≠ физическая остановка и отсутствие effects |
| Удержать старое поколение | Есть объяснимая причина, почему v1 ещё живо, и поддерживается конкретное необходимое продолжение | Запись удалена из registry ≠ все старые callbacks/refs исчезли |
| Очистить | Timer/listener/subscription v1 освобождены согласно их реальным owners; очистка v1 не снимает ресурс v2 | Один глобальный reset или одинаковое имя версии не доказывают ownership |
| Плохой кандидат | Ошибка до выбора либо частичная подготовка дают честный результат и соответствующее восстановление | Общая ошибка не означает, что registry, UI, draft и ресурсы вернулись вместе |
| Поздняя деградация | Релизный rollback и восстановление клиентского feature согласованы с текущими canonical data | Включить старый код ≠ отменить уже выполненные записи или внешние effects |

Для compatible-overlap case можно сравнить продолжение старой принятой операции и admission новых вызовов в v2. Для exclusive resource case нужен другой ожидаемый результат — отложенное обновление, ограниченный handover либо restart. **Выбор между ними остаётся вопросом владельца; невозможно объявить overlap универсальной гарантией.**

Полезны два разных плохих кандидата: ошибка во время подготовки, уже успевшей захватить ресурс, и ошибка прикладного readiness после загрузки. Для каждой ветки нужен собственный observed outcome. «Старое осталось работать» проверяется реальным прежним действием; «пользователь увидел обновление» — реальным новым действием.

Repeated-update проверка должна считать реальные handles/receipts в выбранной области. Она не доказывает сборку мусора или отсутствие всех утечек в произвольном пользовательском JS. Сквозные source/native evidence и ограничения остаются отдельными. [R04]

### Что готовые решения дают для этого сценария

| Составной baseline | Уже есть и следует использовать | Что требует конкретного integration contract; достаточность пока UNKNOWN |
| --- | --- | --- |
| Piral + Cloud + готовый loader | Feed/version control, shell API/data, contributions, setup/teardown, MF loader | Проверяемое readiness, связь dirty document с новой feature, продолжение принятой работы, awaited retirement/recovery по точным hooks |
| single-spa + React helper + MF + Zephyr | Async UI lifecycle, renderer helpers, module loading/sharing, release/rollback, конкретный OTA UX | Один согласованный transition между release selection, host selection, state, old work и cleanup; сама комбинация пока не выполнена |
| NF v4 + выбранный UI/state lifecycle | Builder/metadata, shared resolver, dynamic discovery/load и staged cache rollback | Допустимый live replacement profile при additive dynamic init; acknowledged import-map readiness; UI/state/work/resources |
| OC + выбранный registry/template/client + shell | Версия компонента, доставка/рендеринг, custom-element lifecycle, render/unrender events | Точный client cohort, async readiness/cleanup, сохранность dirty state, логика старой операции и server-side effects |

Последняя колонка **не означает «этого у продукта нет»**. Она означает, что полная связка не подтверждена приведёнными доказательствами и должна быть реализована/проверена в конкретном consumer. Тот же стандарт применяется к нашей будущей библиотеке.

Ready stack может использовать существующий Effect/resource scope или worker host для отдельных ресурсов. Эти механизмы не нужно переписывать ради сравнения. Их stop/finalization contracts проверяются в отдельном custody review; закрытие scope, exit worker и завершение внешнего эффекта не должны автоматически сливаться в один receipt. Этот документ не добавляет новые нативные результаты для этих профилей.

## 5. Где может быть сильное практическое отличие

**Гипотеза полезна, но пока не доказана:** одна переносимая библиотечная операция согласует готовые mechanisms и выдаёт пригодный для пользователя результат — применено, отложено, требуется remount/restart, старое ещё завершается, cleanup не закончен, требуется recovery. Она сохраняет ответственность за весь переход внутри библиотеки. У потребителя остаются доменные state/authority contracts, а не собственный orchestration engine. [R03–R04]

Это потенциально сильнее простой обёртки над import/loadRemote. Но сам набор слов «плагины, версии, hot update, rollback, управление состоянием» не уникален: рассматриваемые стеки уже имеют существенные части, а некоторые предлагают и готовые клиентские flows.

Чтобы сравнение могло опровергнуть нашу гипотезу, заранее зафиксировать:

1. **Одинаковое обещание пользователю.** Сравнивать конкретный сохранённый draft и конкретную принятую работу при одинаковом trust/host профиле.
2. **Количество и место оставшегося integration кода.** Считать production consumer glue отдельно от библиотек, fixtures и business logic; не наказывать конкурент за использование готового helper.
3. **Наблюдаемые отказы.** На выбранных failure paths смотреть сохранность работы, понятность исхода, возможность повторной попытки и освобождение ресурсов.
4. **Контроль реальных владельцев.** Не создавать второй graph/selector/resource registry ради одинакового внешнего facade.
5. **Проверяемость ограничений.** Unsupported update либо targeted restart могут быть корректным результатом, если они соответствуют заранее выбранному обещанию.

Если готовый baseline выполняет согласованный сценарий с небольшим устойчивым glue и понятными ограничениями, смысл большого нового framework уменьшается. Тогда ценностью могут оказаться небольшая integration library, conformance suite или улучшения upstream. Если же одно и то же сложное согласование приходится писать заново в нескольких независимых hosts, standalone complete-operation library получает сильное практическое основание. Это вывод о проверке гипотезы, не решение о продукте.

Пока нельзя заявить прямое конкурентное превосходство, отсутствие аналогов, размер рынка или «все другие узкие». Нельзя также превращать желаемые будущие гарантии нашей системы в преимущества над уже поставляемым чужим кодом.

## 6. Что известно надёжно и что осталось открытым

| Уровень уверенности | Вывод |
| --- | --- |
| Высокий: repository/source evidence | Принята TS-first complete-operation boundary; четыре направления записаны с разной глубиной; pilet/MF совместимы; перечисленные pinned lifecycle/cache paths действительно различаются |
| Высокий: package metadata | Опубликованные версии и gitHead/integrity зафиксированы; NF core TS range конфликтует с нашей tooling policy; OC browser/Node dependency cohorts различаются |
| Средний: архитектурное сопоставление | Их можно рассматривать как delivery/source/UI/loading интеграции поверх общих границ, но конкретный минимальный adapter contract пока не выбран |
| UNKNOWN: сравнительный результат | Полный dirty-editor scenario, стоимость consumer glue, надёжность всех recovery/retention веток, пользовательское превосходство |
| OPEN: решения владельца | Семь вопросов trust/update group/state/visibility/old work/recovery/old clients; необходимость конкретных чужих authoring formats |

**Предыдущие нативные результаты не расширены:** MF 4/4 и SystemJS 2/2 относятся к ранее сохранённым профилям. Здесь нет нового Piral/Native Federation/OpenComponents/Zephyr/full-stack E2E. Источники не превращены в исполненные тесты, а dependency metadata — в установленный и квалифицированный toolchain.

## Источники

- **R01** — Repository instructions: /workspace/scratch/95e187720be1/live-update-value-validation/AGENTS.md; HEAD 7611e1a44542204d77e489a166f92a2e31b0020a.
- **R02** — Existing competition research: /workspace/scratch/95e187720be1/live-update-value-validation/docs/research/live-update-value-competition-and-implementation-size-2026-11-22.md; HEAD 7611e1a44542204d77e489a166f92a2e31b0020a.
- **R03** — OD-003 owner decisions: /workspace/scratch/95e187720be1/live-update-value-validation/docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md; HEAD 7611e1a44542204d77e489a166f92a2e31b0020a.
- **R04** — Existing Module Federation qualification: /workspace/scratch/95e187720be1/live-update-value-validation/docs/research/module-federation-update-boundaries-and-architecture-options-2026-11-22.md; HEAD 7611e1a44542204d77e489a166f92a2e31b0020a.
- **R05** — Research reference: /workspace/scratch/95e187720be1/live-update-value-validation/docs/research/plugin-system-research-reference.md; HEAD 7611e1a44542204d77e489a166f92a2e31b0020a.
- **P01** — [Piral Cloud format breadth](https://www.piral.cloud/comparison).
- **P02** — [Piral Cloud feed control](https://docs.piral.cloud/).
- **P03** — [Piral add/remove/inject actions](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-core/src/actions/app.ts).
- **P04** — [Piral setup completion](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-base/src/lifecycle/setup.ts).
- **P05** — [Piral cleanup](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-base/src/lifecycle/cleanup.ts).
- **P06** — [Piral state and registration APIs](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-core/src/modules/core.ts).
- **P07** — [Piral Module Federation pilet loader](https://github.com/smapiot/piral/blob/15af4fd41e049b5880916af81e130cf22e6ac44b/src/framework/piral-base/src/loaders/mf/index.ts).
- **S01** — [single-spa application lifecycle](https://single-spa.js.org/docs/building-applications/).
- **S02** — [single-spa React integration](https://single-spa.js.org/docs/ecosystem-react/).
- **S03** — [single-spa applications API](https://single-spa.js.org/docs/api/).
- **F01** — [Module Federation runtime API](https://module-federation.io/guide/runtime/runtime-api).
- **Z01** — [Zephyr Electron OTA](https://docs.zephyr-cloud.io/features/electron-ota-updates).
- **Z02** — [Zephyr instant rollback](https://docs.zephyr-cloud.io/features/instant-rollbacks).
- **N01** — [Native Federation v4 core](https://github.com/native-federation/native-federation-core/blob/b3822259fb748eec1309f45d2c978134baf46785/README.md).
- **N02** — [Native Federation orchestrator](https://github.com/native-federation/orchestrator/blob/d1502d3b99e1164c79c0946296caad2cd9ee8068/README.md).
- **N03** — [Native Federation configuration](https://github.com/native-federation/orchestrator/blob/d1502d3b99e1164c79c0946296caad2cd9ee8068/docs/config.md).
- **N04** — [Native Federation version resolver](https://github.com/native-federation/orchestrator/blob/d1502d3b99e1164c79c0946296caad2cd9ee8068/docs/version-resolver.md).
- **N05** — [Native Federation dynamic init flow](https://github.com/native-federation/orchestrator/blob/d1502d3b99e1164c79c0946296caad2cd9ee8068/src/lib/core/2.app/flows/init-remote-entry.flow.ts).
- **N06** — [Native Federation rollback implementation](https://github.com/native-federation/orchestrator/blob/d1502d3b99e1164c79c0946296caad2cd9ee8068/src/lib/core/2.app/steps/rollback-changes.ts).
- **N07** — [Native Federation commit acknowledgment](https://github.com/native-federation/orchestrator/blob/d1502d3b99e1164c79c0946296caad2cd9ee8068/src/lib/core/2.app/steps/commit-changes.ts).
- **N08** — [Native Federation TypeScript compiler dependency](https://github.com/native-federation/native-federation-core/blob/b3822259fb748eec1309f45d2c978134baf46785/docs/architecture/typescript-dependency.md).
- **N09** — [Current Native Federation resolver documentation](https://native-federation.com/docs/v4/orchestrator/version-resolver/).
- **O01** — [OpenComponents introduction](https://opencomponents.github.io/docs/intro/).
- **O02** — [OpenComponents client rendering](https://opencomponents.github.io/docs/consumers/client-side-rendering/).
- **O03** — [OpenComponents event hooks](https://opencomponents.github.io/docs/consumers/events-hooks/).
- **O04** — [OpenComponents published browser-client lifecycle source](https://github.com/opencomponents/oc/blob/806b6a08d16d583a75dcdc5adb3266076e615dfd/packages/oc-client-browser/src/oc-client.js).
- **O05** — [OpenComponents component metadata](https://opencomponents.github.io/docs/building/package.json-structure/).
- **M01** — [piral@1.12.5 published metadata](https://registry.npmjs.org/piral/1.12.5).
- **M02** — [@softarc/native-federation@4.10.1 published metadata](https://registry.npmjs.org/@softarc/native-federation/4.10.1).
- **M03** — [@softarc/native-federation-orchestrator@4.10.2 published metadata](https://registry.npmjs.org/@softarc/native-federation-orchestrator/4.10.2).
- **M04** — [oc@0.50.67 published metadata](https://registry.npmjs.org/oc/0.50.67).
- **M05** — [oc-client-browser@2.1.13 published metadata](https://registry.npmjs.org/oc-client-browser/2.1.13).
- **M06** — [oc-client@4.0.4 published metadata](https://registry.npmjs.org/oc-client/4.0.4).
- **M07** — [single-spa@6.0.3 published metadata](https://registry.npmjs.org/single-spa/6.0.3).
- **M08** — [@module-federation/runtime@2.9.3 published metadata](https://registry.npmjs.org/@module-federation/runtime/2.9.3).
