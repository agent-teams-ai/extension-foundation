# Конкуренты runtime/control plane и честная ценность live-update библиотеки

Дата проверки: 2026-11-22. Только первичные источники и анализ; без новых native
запусков, изменений репозитория, коммитов или выбора спорных продуктовых политик.
Реестр URL, версий, webrefs и границ доказательств:
`competition-runtime-sources.json`.

## Вывод

**Называть такую библиотеку единственной системой обновления кода на лету нельзя.**
OSGi и Erlang/OTP уже предоставляют значительную часть соответствующих runtime
контрактов; wasmCloud предоставляет управление развёртыванием Wasm, Extism —
готовую основу встраиваемых разноязычных плагинов. Наличие в нашем плане
планирования, смены версии, управления зависимостями и очистки само по себе ещё
не доказывает уникальность. [S1] [S2] [S6] [S7] [S12] [S16]

Возможное преимущество — **удобная встраиваемая TypeScript-библиотека, которая
даёт потребителю законченную операцию обновления с проверенными границами
состояния, ресурсов и восстановления, используя готовые runtimes**. Это гипотеза
ценности для выбранных потребителей. Её нужно подтвердить интеграцией и
сопоставимыми измерениями; универсальное архитектурное превосходство из неё не
следует. Ни одну архитектурную опцию этим анализом не принимаем.

## Четыре сильных семейства

| Семейство | Что уже существует | С чем честно сравнивать наш проект |
| --- | --- | --- |
| OSGi / Felix / Equinox / Karaf | Жизненный цикл модулей, версии и wiring, динамические сервисы, dependency refresh, управление provisioning | Встраивание в другую экосистему и цена прикладной интеграции; не изобретение lifecycle/dependency management [S1] [S2] [S3] [S6] [S19] |
| Erlang/OTP | Горячая смена кода, атомарная загрузка набора модулей, upgrade/downgrade scripts, синхронизация процессов и миграция их состояния | Удобство и гарантии для TS/Wasm-потребителей вне BEAM; не изобретение управляемого upgrade [S7] [S8] [S9] [S10] |
| wasmCloud | Wasm workload runtime, интерфейсы, артефакты, rollout и наблюдаемое состояние через operator | Встраиваемая application-level операция и UX выбранного хоста; не собственный OCI/deployment/orchestration stack [S11] [S12] [S14] [S15] |
| Extism | Host SDK/PDK, переносимые Wasm-плагины, host functions, память обмена, конфигурация, cancel/reset/free | Дополнительный контракт обновления приложения поверх готового runtime; не новый Wasm loader/ABI [S16] [S17] [S18] |

Эти семейства — сильные контрпримеры широкому заявлению об уникальности, а не
исчерпывающая перепись рынка. Различие runtime, языка и deployment unit важно:
OSGi bundle, OTP process/module, wasmCloud workload и Extism plugin нельзя
считать одинаковыми единицами обновления.

## 1. OSGi: развитая модель динамических модулей и сервисов

Core R8 определяет install/start/stop/update/uninstall, события и доступ к
состоянию framework. При update создаётся новая revision; действующие wiring
могут продолжать использовать старую. `FrameworkWiring.refreshBundles` вычисляет
dependency closure, останавливает затронутые bundles, снимает разрешение
зависимостей и пытается восстановить прежние lifecycle-состояния. Есть уведомление
о завершении асинхронного refresh. Поэтому version retention, scope обновления
и завершённая framework-операция уже имеют готовые контракты. [S1] [S2]

Declarative Services умеет управлять зависимостями и rebinding: static policy
предусматривает deactivate/reactivate, dynamic policy может менять bindings
без деактивации, но компонент обязан корректно переживать конкурентные изменения.
Karaf добавляет provisioning группы bundles/configurations/transitive features,
`feature:install --simulate`, управление auto-start и auto-refresh. Его документация
прямо разбирает cascading refresh. [S3] [S6]

**Граница также документирована.** Framework автоматически снимает свои service
registrations/listeners, но прикладные threads/resources должен освобождать
bundle. OSGi отдельно описывает stale references: framework управляет собственными
структурами, а сохранённые объектные ссылки должны корректно освобождать
потребители. Рекомендуются Service Tracker/DS; описана и indirection с отсечением
старой реализации. Это не доказательство превосходства нашего будущего lease
API: сначала нужно показать, что он надёжнее предотвращает соответствующие
ошибки в целевом consumer. [S1] [S4]

Важная текущая квалификация: Felix Framework 8 удалил стандартный OSGi security
layer, хотя соответствующие permission API остаются. Нельзя приравнивать модульную
изоляцию или наличие permission types к реально работающей sandbox-политике.
Это ограничение конкретной ветки Felix, не утверждение обо всех реализациях OSGi.
Equinox остаётся официально описанной основой Eclipse plug-in runtime. [S5] [S19]

## 2. Erlang/OTP: особенно сильный контрпример

В проверенной документации OTP 29.1.2 `code:atomic_load/1` загружает весь набор
модулей либо ни одного, с ограничениями вроде `on_load` и непогашенного старого кода; существуют разделённые `prepare_loading/1` и
`finish_loading/1`. Runtime различает current/old code, допускает их одновременное
исполнение, но жизненный цикл старого кода ограничен правилами purge. Это
атомарность загрузки модулей, а не автоматически атомарная транзакция всех
прикладных эффектов. [S7]

SASL предоставляет инструменты создания release packages, `.appup` и `relup`,
установку, upgrade/downgrade и выбор permanent release для последующего reboot.
Для изменения состояния behaviour-процессов используется синхронизированная
последовательность suspend → `code_change` → resume с опорой на supervision
contracts. `appup` задаёт зависимости и политику `soft_purge`/`brutal_purge`;
последняя может завершать процессы, оставшиеся на старом коде. [S8] [S9] [S10]

Нельзя представлять OTP как универсально бесшовную миграцию: официальное руководство
разбирает циклические зависимости, процессы, созданные во время upgrade, и
разные версии release на разных узлах. `release_handler` различает recoverable
errors и ошибки с restart, поддерживает timeout-параметры. Даже
`check_install_release` исполняет инструкции до `point_of_no_return`; название
«check» не означает чистый анализ без действий. Обратное преобразование состояния
и согласованность внешних записей остаются частью прикладного upgrade-контракта.
Это вывод о границе этих механизмов, не утверждение, что OTP не может реализовать
такие протоколы. [S8] [S9] [S10]

## 3. wasmCloud: сравнивать текущую v2, сохраняя scope старых источников

Текущая документация — **v2**. `wadm` из v1 заменён `runtime-operator` и
Kubernetes API. Основные ресурсы: Artifact, Host, Workload, WorkloadDeployment,
WorkloadReplicaSet; текущие CRDs добавляют WorkloadDaemonSet. Workload может
содержать компоненты и optional services. Поэтому описание платформы как простого
stateless Wasm runner уже недостаточно. [S11] [S12] [S13]

Artifact отслеживает revisions и может инициировать rollout нового образа.
WorkloadDeployment управляет ReplicaSets и replicas; API задаёт `RollingUpdate`
как default deployment policy. Для нового WorkloadDaemonSet документированы
start-new-before-stop-old на отдельном host, `maxConcurrentHosts` и альтернативный
`Recreate`. Эти гарантии надо сохранять в их точном scope: не переносить правило
DaemonSet на каждый ресурс или считать rolling update одним глобальным commit
всего fleet. [S12] [S14]

V1 control-interface также уже отличает принятие update-команды от завершения:
успешный ACK означает попытку, а результат проверяется по событиям. Это полезный
готовый образец честного control-plane API, **именно v1**. Документация migration
самого проекта сообщает о прежних проблемах resiliency/reconciliation и уменьшении
обязанностей хоста в v2. Это upstream self-report и архитектурная мотивация, а не
новый воспроизведённый нами дефект. Опубликованные там performance numbers не
используем как наш benchmark. [S11] [S15]

Практический вывод: прежде чем писать собственный distributed reconciler,
artifact cache или deployment manager, нужно сравнить требуемый сценарий с этими
готовыми компонентами. Их existence не доказывает готовность конкретного UI/state
handoff нашего приложения; это отдельный consumer-контракт. Из отсутствия такой
демонстрации на найденной странице не следует, что платформа её не поддерживает.

## 4. Extism: реальная готовая основа для расширяемости

Extism прямо позиционируется как инструменты для реализации определяемого
приложением plugin interface с Host SDK и PDK. C API предоставляет
create/call/free, обновление config, reset, host functions и cancel handle.
Переписывать эти runtime-примитивы ради «своей архитектуры» без конкретного
непокрытого требования нет оснований. [S16] [S17]

Существенный контракт памяти: Extism-managed buffers обмена очищаются между
вызовами, а выходной буфер доступен до следующего вызова. Это не утверждение о
сбросе всей Wasm-памяти или миграции бизнес-состояния. Manifest позволяет задавать
источники Wasm, hashes и runtime constraints. Эти готовые механизмы стоит
использовать внутри адаптера, сохраняя их реальные lifetime-правила. [S18] [S20]

Нельзя на основании краткого C API делать вывод «у Extism нет update ecosystem».
Для заявлений о полном опыте обновления нужно отдельно оценивать выбранный SDK,
конкретные host callbacks и интеграцию. Но и `reset/free` нельзя выдавать за
доказанный перенос пользовательского состояния между версиями приложения — это
другой проверяемый результат.

## Какие преимущества ещё надо доказать consumer E2E

Это предложения квалификационных сценариев, **не новые запуски и не выбранные
политики**. Механизм-спайки не заменяют эти доказательства.

| Обещание | Минимальная полноценная проверка |
| --- | --- |
| Потребитель получает готовую операцию | Отдельное приложение использует опубликованный public API; orchestration, fencing и recovery не скопированы в consumer вручную. Сравнить объём прикладного кода с разумным готовым baseline. |
| Изменения видны предсказуемо | Реальный UI/обработчик переходит с A на B в документированной точке. Prepared/evaluated не выдаётся за visible/ready; сохраняется согласованное пользовательское состояние. |
| Старые версии управляемы | Долгий A-вызов, новые B-вызовы, retained reference, timeout и drain. После отзыва старая версия не пишет через защищённый порт; границы cooperative и hard-stop профилей проверяются отдельно. |
| Состояние сохраняется корректно | Версии schema, конкурирующий writer, migration failure и update/recovery после внешней записи. Обратимость доказана для выбранной миграции либо честно показан иной путь восстановления. |
| Ошибки не оставляют ложный успех | Fault injection до/после публикации и в cleanup, crash инициатора, два конкурирующих updater. Результат и журнал соответствуют реальному consumer; повтор операции не создаёт повторных прикладных эффектов в заявленном scope. |
| Ресурсы очищаются | Много последовательных обновлений с реальными subscriptions, sockets, workers и UI-resource owners; нет старых callbacks после завершения соответствующей политики. Измерить накопление ресурсов, не только успешный dispose callback. |
| Адаптеры заменяемы | Один consumer contract проходит хотя бы на двух реально поддержанных профилях. Различия serialization, cancellation, isolation и state ownership явно отражены в capability contract. |
| Fleet/old-version UX надёжен | Старый клиент, отложенный lazy asset, offline/resume, удалённый artifact и rollback. Локальное переключение, rollout когорты и fleet convergence имеют отдельные результаты. |
| Библиотека лучше по выбранным критериям | Одинаковые workload/fault scenarios и критерии: integration effort, latency, resource retention, recovery time, объяснимость статуса. Сравнение с готовым решением плюс разумный glue, а не только с голым import(). |

Честное заявление до этих проверок: **«Мы проектируем более удобный для выбранных
TS-потребителей слой управляемых обновлений, опираясь на готовые механизмы;
преимущества в гарантиях и стоимости интеграции ещё квалифицируем».**

[S1]: https://docs.osgi.org/specification/osgi.core/8.0.0/framework.lifecycle.html
[S2]: https://docs.osgi.org/specification/osgi.core/8.0.0/framework.wiring.html
[S3]: https://docs.osgi.org/specification/osgi.cmpn/8.0.0/service.component.html
[S4]: https://docs.osgi.org/specification/osgi.core/8.0.0/framework.service.html
[S5]: https://felix.apache.org/documentation/subprojects/apache-felix-framework/apache-felix-framework-8-upgrade-guide.html
[S6]: https://karaf.apache.org/manual/latest/provisioning
[S7]: https://www.erlang.org/doc/apps/kernel/code.html
[S8]: https://www.erlang.org/doc/system/release_handling.html
[S9]: https://www.erlang.org/doc/apps/sasl/appup.html
[S10]: https://www.erlang.org/doc/apps/sasl/release_handler.html
[S11]: https://wasmcloud.com/docs/migration/
[S12]: https://wasmcloud.com/docs/kubernetes-operator/crds/
[S13]: https://wasmcloud.com/docs/faq/
[S14]: https://wasmcloud.com/docs/kubernetes-operator/api-reference/
[S15]: https://wasmcloud.com/docs/v1/hosts/lattice-protocols/control-interface/
[S16]: https://extism.org/docs/concepts/plug-in-system/
[S17]: https://extism.org/docs/concepts/runtime-apis/
[S18]: https://extism.org/docs/concepts/memory/
[S19]: https://eclipse.dev/eclipse/
[S20]: https://extism.org/docs/concepts/manifest/
