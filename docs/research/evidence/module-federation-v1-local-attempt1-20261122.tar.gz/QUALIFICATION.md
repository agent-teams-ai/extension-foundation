# Qualification receipt and remaining boundary

## Frozen v1 / local attempt

Input checkpoint committed and pushed by root before execution:
`4a95ba3026ad4721ed6585a38fbd192e5aba133d`.
All 11 executable/configuration/audit inputs matched `frozen-inputs-v1.json`;
aggregate SHA256 `ab08d51b4182b3cfc15e648b4951afbd0209d42f5d21af86acdff9d122df6493`.
Source: 515 maintained TS LOC, zero production LOC.

| Stage | Result | Evidence |
|---|---|---|
| Dependency/compiler static audit | PASS: 70 distinct installed packages, 2,599 JavaScript files scanned; identified compiler and platform package exactly7.0.2; Acorn substring false positive classified | `probe/dependency-audit.json` |
| Actual compiler version | PASS: `Version 7.0.2` | `probe/results/v1/01-version.{json,log}` |
| Strict TypeScript check, skipLibCheck:false | Exit0 | `probe/results/v1/02-check.{json,log}` |
| TS emit + webpack generation | Exit0: five real containers and one host, eleven output files | `probe/results/v1/03-build.{json,log}`; `build-manifest.json` |
| Browser native attempt | BLOCKED in shared before-hook; Chromium process singleton socket denied by operating environment | `probe/results/v1/04-native.{json,log}` |
| Semantic MF cases | **0 executed, 0 passed, 0 semantic failures established** | `native-observations.json`: empty cases and requests |

`node:test` reports four failed tests because the browser setup hook failed.
Those are not four independently executed MF assertion failures. Chromium's
fatal message names `socket() failed: Operation not permitted`; a later crash
diagnostic also reports denied ptrace. No attempt was made to weaken the local
environment restriction, mutate browser guards or use a fake DOM/container.

The actual generated artifacts and hashes remain available in `probe/dist/`
and the build manifest. Necessary upstream MIT licenses for webpack and the
four bundled MF packages are retained in `third-party-licenses/`; no dependency
directory is redistributed.

## Proposed next execution profile, not yet executed

Use an authorized hosted browser runner with the same released dependency lock
and generated-container inputs. Existing previous-phase workflow hardcodes a
different fixture, so rerunning it would not qualify this spike. A portable
browser executable selection and a separately frozen/pushed input checkpoint
are required before that run; root owns any workflow integration. Original v1
attempts must remain in the final evidence packet.

No source finding is promoted to native evidence until its real case executes.
