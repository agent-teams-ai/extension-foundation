Static restart validation — repository handoff evidence
Evidence cut: 2026-10-25

This archive supplements, and does not replace or rewrite:
  docs/research/evidence/static-restart-validation-20261025.tar.gz
  SHA-256 e16e9cdb74bed1e83ec863b19beea8dd7bfe55567d42b36b35ea58ffd1c6de68
  416 regular files, 805541 bytes

The original archive owns the native/static/browser/growth campaign. It
predates the later mechanical integration of Extension Foundation main.
This handoff owns repository gate logs, immutable input manifests, hosted
check snapshots, independent integration review and the separately frozen
browser input crosscheck.

Tested integrated research commit:
  96bf8eef4b9ec26972125c7735044f3740bf05e0
Tested exact Git tree:
  0d289e599ba81a99166e038d759486c9bc0dc595
Integrated main:
  39c72bf3061dd6cf4aa4bd3c92f0c9b3f88a0bde

Local tests ran on the identical staged merge tree before the local branch
was aligned to the connector-published commit. HEAD/MERGE_HEAD in raw logs
therefore identify the parents; the complete file manifests and canonical
tree binding identify the actual tested content.

Read handoff.json first, then the owning gate metadata and logs under
validation/. SHA256SUMS binds all payload files except itself. The archive
contains only regular relative paths, not native binaries, dependency
installations, database roots or a private agent checkpoint.

Required local routes:
  pnpm docs:info
  pnpm docs:protocol:check
  pnpm check:changed
  CI=true pnpm check

The changed route dispatched the actual unchanged check:fast route with
fast-full coverage. That completed invocation satisfies the fast gate;
it was not redundantly repeated. Keep the fast profile's explicit skips
separate from the complete gate and the hosted jobs.

Recorded execution profile:
  Node 26.11.1
  npm 11.20.0
  pnpm 11.18.0
  TypeScript 7.0.2
  Linux x64, local CI=true for the unchanged repository browser profile
  Google Chrome for Testing 156.0.8078.47

CI=true selects the repository's supported Linux CI browser behavior.
It is not a source patch, a hosted-CI claim or a changed child deadline.
The full environment receipt retains actual timeouts and executable hash.
Task-owned temporary directories and process groups isolate the runs.
Installation used frozen dependency inputs.

Hosted validation is separately attributed to exact commit 96bf8eef.
The identity check remains red: the pinned old controller requires the
exact raw owner name "iliya", while the GitHub connector commits as "Илия".
The current central alias policy does not change that older pinned
controller. No identity rule, caller, required check or dependency was
modified to bypass it. The source and job log are retained.

Read every result at its recorded scope. A successful repository gate
does not erase the intentionally red stop-admission research cases,
qualify PostgreSQL restore helpers or prove production Host replacement.

