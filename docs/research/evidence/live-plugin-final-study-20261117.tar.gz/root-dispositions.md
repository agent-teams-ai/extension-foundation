# Root review dispositions

## Reviewed inputs

- Round1: `089c7b60990a6c3fe1d91f2de751bc8bd149a72218d4474600886c323d25d9b4`.
- Round2: `a3f6beeb0b2d9b2944c7c241e1429b75143ae484ea3cbdefc3bf574156bbd2f3`.
- Final governed report after the bounded Effect wording correction:
  `a02bef6a417ed109654c733f5bd7ae67aa141f0c7127f5269cfc515d81a10552`.

Exact first/second root inputs are preserved. The final document is in the
repository; the Effect specialist's second-round record verifies its final hash.
The other reviews remain accurately bound to their own inspected drafts.

## Material corrections

| Finding | Disposition |
| --- | --- |
| Snapshot-assisted Golem source guard generalized to every automatic variant | Scoped source revision/start fields and stale-source guard to assisted selection; preserved full-replay strategy distinction. |
| Felix STARTING rejection generalized | Included supported declared lazy-activation exception; lane report/ledger also made precise. |
| Wasm bind timeout simplified to waiting for a normal return | Included reply drop on store teardown; caller timeout remains distinct from cleanup. |
| Finite RcRef TTL claimed to defer every final release | Included invalidation, which takes awaited cleanup regardless of TTL. |
| No finite TTL phrase conflated omission with infinity | Replaced with explicit omitted-option behavior; specialist verifies final correction. |
| Go limitation had adjacent but insufficient source attribution | Added direct how-to guide citation and corrected root ledger row; kept updating guide's narrower claim. |
| Restate server license lacked direct locator | Added exact release LICENSE link; no blanket permissive OSS claim. |
| MCP local proxy capture could imply remote code affinity | Added server-contract qualification in both current and prior portable reports; no change to original evidence packet. |
| SDK overlap could be read as a reproduced bug | Kept explicit unexecuted falsifier label and added implementation/test locators. |
| Output interpretation might float after invocation | Captured input/output contract and actual executor stated together for the promised boundary. |

No review approves a public API, new package, runtime migration, interruption
policy or merge. New production/integration runtime code remains zero.

## Root verification

Root independently read primary protocol, official current/versioned docs,
release metadata and selected source. In particular, the Effect release branch
confirms omitted TTL or invalidation awaits Scope.close, finite non-invalidated
TTL forks cleanup, and infinity retains until another lifetime boundary.
The root rechecked current Get Modular main and the private kernel marker.
No source inspection was relabeled as runtime execution.
