# Independent review: durable execution and rollout, round 2

Reviewed: 2026-11-17.

The governed draft and frozen input `review-inputs/root-round2.md` both have
SHA-256 `a3f6beeb0b2d9b2944c7c241e1429b75143ae484ea3cbdefc3bf574156bbd2f3`.

Additional inputs inspected:

- `emerging-runtimes/report.md`, SHA-256
  `ae19093f75d66097b982d2fe8fea88276a934bb450fb824db96aad47852f96b7`.
- `emerging-runtimes/source-ledger.json`, SHA-256
  `30eec1b3bef18a78bdafe25e3dc1a5808e72423beb10cafe7bd32d87b82cc16a`.
- Updated preceding portable report, SHA-256
  `2ad43f7c1d1471938ed6ccdc378455df3b94a730bdd51131bc981feb0bf588df`.

## Verdict

**The root synthesis passes this bounded source/ownership review.** No remaining
material semantic issue was found in the reviewed durable-execution and rollout
claims. One small ledger attribution correction remains before packaging; it
does not require changing the root synthesis.

## Round 1 dispositions verified

- **DR1-01 resolved.** The root and emerging-runtime lane now distinguish the
  persisted choice between full and assisted replay from the extra source
  revision/start guard carried by snapshot-assisted automatic selection. Plain
  automatic selection is explicitly described as lacking those assisted fields.
  This matches the independently inspected `strategy()` and
  `stale_assisted_head()` source.
- **DR1-02 resolved in root prose.** The current Go manual-update limitation is
  directly linked to the versioned update-running-agents guide. Restate BSL1.1
  identification now links to the exact server LICENSE. No permission to adopt,
  copy a server, or make a legal conclusion is implied.
- The additional Felix lazy-activation and RcRef invalidation qualifications are
  explicit in the frozen input. Their full source qualification belongs to the
  respective specialist lane; this reviewer did not expand into another runtime
  audit merely because those fixes changed adjacent text.

## Minor evidence attribution correction

**DR2-01, low severity:** the emerging-runtime source ledger still assigns the
phrase `current Go limitation` to
`docs/src/content/v1.6/develop/updating.mdx`. The specific statement is in
`docs/src/content/v1.6/how-to-guides/common/golem-update-running-agents.mdx`.
Move that phrase to the guide's ledger row; leave updating.mdx associated with
its actual replay/snapshot compatibility findings. Both exact blob identities
in the ledger match the independently retrieved files. This is a source-row
attribution fix, not a newly discovered runtime issue.

## Additional confirmations

- Temporal continuation is a named new-run boundary; required business
  deduplication survives only through the owning application contract. The
  preview status is preserved.
- Restate execution selection and object-state schema remain distinct. Its
  removal CLI/server split is not relabeled as an executed race or stronger
  authoritative retirement barrier.
- Envoy per-request capture, per-thread propagation and broader rollout are not
  conflated. Snapshot refresh and post-warming hook failures remain qualified.
- The preceding portable report now directly explains that retaining an MCP
  client closure does not pin the remote tool implementation; the stronger
  promise needs a server-owned binding. This is a current clarification, not
  rewriting the original experiment/archive.
- Root and the new lane preserve source evidence versus inference, runtime
  source versus artifact qualification, and publicly available entrypoints
  versus a private kernel. They claim no new runtime execution.
- No second Host, active-head owner, workflow history store, schema migrator or
  idempotency ledger is introduced. Estimates remain conditional and exclude
  the newly explored state/distributed/runtime profiles.
- The ordinary-update interruption choice remains OPEN; no recommendation is
  promoted to owner acceptance. Pending publication/evidence links remain
  delivery work, not missing architecture decisions.

This review adds no governed-file edits, runtime test, dependency change or
external publication. Full third-party inspection copies are not part of the
owned evidence packet.
