# Durable execution and rollout mechanics: deeper source review

Research date: 2026-11-17. This supplements the earlier Temporal, stateful-upgrade
and production-reload reports. It reuses their established conclusions and adds
implementation-level distinctions. Nothing was installed, benchmarked or
executed. Source inspection, documented behavior and proposed transfers are
separate below. No runtime, public contract, interruption policy or dependency
upgrade is selected.

## Three findings that change the design

1. **The update boundary must preserve business identity, not only code identity.**
   Temporal's explicit Continue-as-New boundary can select a new build, but starts
   a new run; Update ID deduplication does not automatically survive that boundary.
   Restate likewise separates invocation identity from the state shared by
   successive versions. A generic generation number cannot replace the consuming
   application's command identity, state compatibility and effect receipts.
2. **A successful publication acknowledgment needs a named scope.** Envoy's RDS
   source publishes a new shared configuration into thread-local slots through
   dispatcher callbacks. Existing streams have a selected configuration snapshot.
   Returning successfully from the main-thread update is not a simultaneous
   switch of all workers, all resource types, all connections or all processes.
3. **Drain observation and enforced retirement are distinct mechanisms.** Restate's
   released CLI checks drain status, then calls a server API which only implements
   forced removal. Temporal's drainage status is periodically refreshed and closed
   workflow queries may still need an old worker. An adapter cannot silently
   promote these observations to a stronger atomic retirement guarantee.

These are useful successful design patterns with explicit limits. They are not
claims that the inspected projects are defective.

## Evidence identities and comparison with the previous study

| Case | Evidence inspected now | New depth beyond retained work |
| --- | --- | --- |
| Temporal | Documentation commit `8ae62952028e3f473a163f45cf89e9eda4520d89`, committed 2026-11-17T00:06:27Z; current hosted official pages | Boundary state and deduplication, dispatch optimization caveat, exact preview status; existing affinity, replay and drainage findings rechecked |
| Restate | GitHub latest release `v1.8.1`, published 2026-10-21, commit `20efb1b83a39b8227451e531c366e067588ae9ee`; current hosted docs | Actual persisted deployment/protocol selection, state-table boundary, CLI/server retirement split |
| Envoy | GitHub latest release `v1.40.2`, published 2026-10-27, commit `b2d89e0ae53916f28770771fbdd49c5c99c5c5a2` | RDS warming-to-publication path, asynchronous thread-local replacement and per-stream snapshot; previous v1.36.0 operational interpretation not rewritten |

The exact release source was read; downloaded runtime binaries, package archives,
SBOMs and installation compatibility were not qualified. Temporal documentation
HEAD is not an executable server/SDK pin. Restate's old public documentation
repository resolves to a 2025 commit and does not carry the current hosted path;
this report does not mislabel that old tree as the source of current hosted docs.
The source ledger records exact Git blobs and the mutable documentation limitation.

## 1. Temporal: moving at a checkpoint has additional semantics

### Documented execution affinity remains bounded

Pinned workflows use one Worker Deployment Version unless explicitly moved.
Auto-Upgrade workflows may change builds and must retain replay compatibility.
Independent Activities can use another deployment's routing, so a pinned workflow
does not freeze every participant in its call graph. These established facts
remain in the current concepts source. [T1]

Upgrade-on-Continue-as-New still carries **Public Preview / experimental SDK
option** status in the current guide. By default a pinned workflow inherits its
build across continuation. The option changes the new run at the explicit
continuation boundary; it does not modify a suspended stack in the current run.
The documented notification is refreshed as workflow tasks complete, so the
example's polling timer is demonstration code, not a universal zero-latency
change signal. [T2]

### New distinction: continuity of the entity differs from continuity of a run

The entity-workflow guide requires the main workflow to wait for active handlers
before continuation and explicitly carry its state forward. It also warns that
Update IDs are scoped to one workflow execution: a previously used Update ID can
be accepted after Continue-as-New unless the application carries the necessary
deduplication state. [T3]

**Transfer inference:** a safe checkpoint must state which facts cross it. For an
agent conversation those might be the logical conversation identity, pending
user command identity, completed operation receipts, expected state schema and
resume token. Serializing local variables or assigning the new plugin generation
does not establish those facts. Preserve the existing application's durable
command/idempotency owner; do not create a second ledger in the plugin library.
For an ordinary stateless renderer, none of this requires adding a workflow
engine or durable store.

### New distinction: an optimized dispatch path can have a different contract

The current performance guide warns that eager Workflow start can use an
available local worker outside the deployment's Current/Ramping selection.
The general versioning guide describes normal routed starts in Current/Ramping.
Treat the eager path as an explicit qualification concern; do not transfer the
normal-path guarantee to every latency optimization. [T4, T5]

This is a documented caveat, not a reproduced server defect or a claim about
every SDK/release combination. It illustrates why a universal adapter needs
rejecting tests for all actual invocation routes, including shortcuts, recovery,
retry, background callbacks and direct calls.

### Existing limit, freshly checked

Drainage checks periodically count open pinned workflows and expose their
last-check time. Closed pinned workflows can still require workers for queries.
Consequently a generation's inactive status, zero open workflows, zero currently
running tasks and absence of future executable obligations are different facts.
[T6] Existing reports already captured this; the new design implication is to
retain observation scope and freshness in the consuming owner instead of
flattening a provider response into `retired = true`.

## 2. Restate: invocation pin, journal protocol and state have different lifetimes

### Source trace of an invocation's selected implementation

In the released `invocation_task/mod.rs`, the task reads journal metadata before
selecting a deployment. If that metadata already names a deployment, the task
looks up that ID and retains the selected service-protocol version. Missing
deployment metadata and unsupported resume protocol are explicit error paths.
Without a pin it resolves the latest service deployment and negotiates a protocol.
The same path explicitly rejects a journal-v2 to journal-v1 downgrade. [R1]

`OnPinnedDeploymentCommand` persists the chosen deployment and protocol in
invocation metadata; it also updates queue metadata and handles the journal
format transition when needed. These are part of the durable execution owner's
state machine, not transient lookup convenience in a caller. [R2]

**Transfer inference:** a durable invocation binding should outlive its original
process. A replacement mechanism may ask the existing execution owner to resolve
it, but must not reconstruct it from today's active plugin. Protocol/serializer
identity is a compatibility axis distinct from the code digest. An endpoint
label by itself does not prove unchanged executable bytes.

### Pinning does not create one state database per implementation

The hosted versioning guide states that Virtual Object state survives versions
and requires compatible state schemas. Re-registering a mutable endpoint with
force is described as a development convenience that can invalidate ongoing
journal replay. Moving affected invocations to a fixed deployment also requires
the new code to accept their recorded journal. [R3]

At the released storage API boundary, user-state reads and writes take a
`ServiceId` plus state key, rather than a deployment ID. This supports the
documented separation between execution version and state ownership. It does
not by itself establish every storage backend's isolation or transaction
semantics. [R4]

**Transfer inference:** keeping old and new code alive is insufficient when both
operate on shared durable data. The feature owner must choose compatible readers
and writers, an explicit migration/handoff, or exclusive ownership. A neutral
library can coordinate an already defined boundary; it cannot infer the meaning
of a renamed field or whether collapsing two account keys is valid.

### New source-level limit: the CLI's check is not the server's seal

The released removal CLI queries active invocations, reads current service
metadata, computes deployment status, and refuses an unsafe removal unless the
operator selected force. After those checks, however, it calls the removal helper
with `force = true`; the source explicitly notes that server-side graceful
validation is not implemented. [R5]

The corresponding server route rejects non-forced deletion and removes deployment
metadata through the schema registry for forced requests. Its response is an
accepted operation, not an OS process-exit receipt. The bulk API has the same
forced-only condition. [R6]

**Transfer inference:** a client-side snapshot and a later mutation are separate
events. A caller who needs atomic prevention of new bindings must establish that
with the existing authoritative owner; a neutral adapter cannot invent that
stronger guarantee from a CLI's successful output. This review did not reproduce
a race, establish that one occurs under an ordinary operator deployment, or
classify this deliberate API boundary as a bug.

### Repair and deletion are not business rollback

The managing-invocations documentation distinguishes resume on another compatible
deployment from restart-as-new. Restart-as-new creates a different invocation
and repeats its operations without preserving partial progress. Killing does
not run compensation and excludes detached one-way/delayed calls from the
originating call tree. [R7]

**Transfer inference:** one generic `rollback()` result must not hide routing
rollback, journal replay, restart, snapshot restoration and effect compensation.
These transitions can have different command identities and duplicate-effect
risks. Carry already owned business receipts across the selected operation.

### Reuse and licensing boundary

The inspected Restate server license is **Business Source License 1.1**, with a
change to Apache-2.0 four years after release and an additional-use restriction
on the defined public Restate platform service. It calls itself non-open-source
before that transition. [R8] This is license identification, not legal advice or
a deployment approval. It is inaccurate to describe every investigated runtime
as a permissively licensed library that can be copied into a new package.

## 3. Envoy: configuration publication is precise because its scope is narrow

### Implementation trace at the released source

1. The RDS receiver builds and warms a candidate configuration. The subscription
   publishes from `onConfigWarmed`, which may run synchronously when nothing needs
   warming. Failure statuses from its before/provider/after publication hooks
   are logged, not propagated back as xDS rejection; the configuration publishes
   independently of those hook status values. [E1]
2. The base RDS provider captures the parsed configuration and invokes
   `tls_.runOnAllThreads` to replace each thread-local shared pointer. It returns
   success after scheduling that work. [E2]
3. That overload posts to registered worker dispatchers and runs the main-thread
   callback directly. The thread-local facility has a separate completion-callback
   overload, but this RDS publication path does not use it. [E3]
4. HTTP `ActiveStream` selects a route-configuration shared pointer while decoding
   request headers, then resolves routes through the captured value. It also
   exposes an explicit snapshot-refresh method; “existing streams can never
   change configuration” would overstate the implementation. [E4]

The source shows deliberate request-scoped coherence with asynchronous
propagation. It does not claim a fleet-wide instantaneous transaction. The
shared-pointer lifetime covers configuration objects, not arbitrary application
effects performed by upstream services.

### Protocol-level evidence makes the limit visible

The v1.40.2 xDS documentation says ACK establishes validation/intent, not proof of
successful application. A NACK need not mean that every resource in the response
was rejected. Cross-resource consistency is eventual; dependency-before-consumer
sequencing avoids the demonstrated route-to-unknown-cluster gap. ADS controls
sequencing and is not a universal atomic multi-resource commit. [E5]

The same release's hot-restart contract describes a new process initializing,
obtaining listener sockets and accepting new connections while its predecessor
drains. Existing connections remain with the old process and can be closed at
termination; they do not migrate into the new process. Drain and parent shutdown
have separate deadlines. [E6]

**Transfer inference:** define the unit of consistency before selecting an
algorithm. A synchronous local owner can protect one selection/admission/resource
acquisition. A group of interdependent plugin capabilities may need one coherent
composition cohort. Independent processes require their existing distributed
authority/rollout semantics. These scopes should not all be marketed as the same
atomic swap.

## Consequences for a portable library

These are proposed responsibilities, not approved public interfaces or new
packages. They reuse GM composition and the optional existing lifecycle kernel,
native Effect scopes where adopted, and the consuming Host's single authority.

| Concern | Portable mechanism can help with | Existing owner retains |
| --- | --- | --- |
| Ordinary local call | Protected generation selection plus admission and resource retention; completion of that retention | Product permission, operation boundary and invocation contract |
| Stateful continuation | Invoking a supplied handoff/checkpoint operation and reporting its explicit outcome | State meaning, migrations, business command identity, deduplication and durable receipt |
| Durable recovery | Narrow integration that resolves a previously selected generation | Existing durable execution engine and canonical persistence; no duplicate scheduler |
| Multi-worker rollout | Qualified execution adapter and observations with named scope | Existing process custody, deployment control and distributed authorization |
| Retirement | Distinguish no new admission, no remaining work, resource release and observed container exit | Policy for existing work, query/recovery retention and physical enforcement |

The reusable concern is the correctly scoped transition and lifetime handling.
An ordinary external project must be able to use the in-process profile without
Temporal, Restate, Envoy, an organization catalog or a new database. Conversely,
a durable adapter must not advertise stronger guarantees than the provider path
it actually uses. This is the practical Liskov requirement: an implementation
cannot substitute a periodic observation for a contract requiring an enforced
transition.

The same reasoning supports DRY: retain one authoritative operation identity,
one active-selection owner, one lifecycle bookkeeping owner and one durable
progress owner. A second library state machine that independently guesses these
facts would add conflicting knowledge, even if its class structure looked clean.

## Proposed falsifiers, scoped to an actually selected profile

None of the following tests was run in this review. They are useful only when the
corresponding capability belongs to the implementation being qualified.

| Scenario | Observation needed | Claim it challenges |
| --- | --- | --- |
| A completed business command is retried after a continuation that changes code | Same logical command is recognized without a duplicate effect | A preserved conversation/workflow ID automatically preserves all deduplication |
| A pinned invocation resumes after its endpoint is changed in place | Actual executable identity and replay compatibility are verified or rejected | Deployment label implies immutable bytes |
| New code writes state then an old retained invocation resumes | Both schema and business invariants remain valid, or access is explicitly rejected | Keeping both generations alive makes state compatible |
| A deployment is observed drained, then another authorized operation changes its bindings before removal | Existing owner prevents unsafe re-admission or reports non-atomic scope honestly | A status query alone is a retirement barrier |
| An RDS-style update reaches different worker dispatchers at different times | Each request uses a coherent declared configuration; global propagation is separately observed | Success on one owner means all workers changed simultaneously |
| A stream requests an explicit route/configuration refresh | The refresh boundary has a declared consistency contract | An initial snapshot freezes every later action automatically |
| Eager/local/direct dispatch bypasses ordinary routing | The actual selected implementation satisfies the invocation profile, or the shortcut is rejected | One routing test covers every invocation path |
| A failed generation is replaced and old work restarted | Effect receipts and operation identity distinguish retry, replay and compensation | Reverting code automatically reverts the business world |

## What remains deliberately open

Whether an ordinary update may interrupt healthy current work is still the
owner's open product question. None of these mechanisms selects “always wait”,
“cancel after a timeout”, “move every session” or “restart everything”. The
architecture should preserve those explicit choices without promising every
choice on every backend.

## Source references

All retrievals were 2026-11-17. Git links use immutable source identities;
hosted Restate documentation is a moving primary source. The adjacent JSON
ledger records Git blob hashes and evidence limitations.

[T1]: https://github.com/temporalio/documentation/blob/8ae62952028e3f473a163f45cf89e9eda4520d89/docs/encyclopedia/workers/worker-versioning.mdx
[T2]: https://github.com/temporalio/documentation/blob/8ae62952028e3f473a163f45cf89e9eda4520d89/docs/production-deployment/worker-deployments/worker-versioning/upgrade-on-continue-as-new.mdx
[T3]: https://github.com/temporalio/documentation/blob/8ae62952028e3f473a163f45cf89e9eda4520d89/docs/design-patterns/entity-workflow.mdx
[T4]: https://github.com/temporalio/documentation/blob/8ae62952028e3f473a163f45cf89e9eda4520d89/docs/develop/worker-performance/index.mdx
[T5]: https://docs.temporal.io/production-deployment/worker-deployments/worker-versioning
[T6]: https://github.com/temporalio/documentation/blob/8ae62952028e3f473a163f45cf89e9eda4520d89/docs/production-deployment/worker-deployments/worker-versioning/sunset-and-gc.mdx
[R1]: https://github.com/restatedev/restate/blob/20efb1b83a39b8227451e531c366e067588ae9ee/crates/invoker-impl/src/invocation_task/mod.rs
[R2]: https://github.com/restatedev/restate/blob/20efb1b83a39b8227451e531c366e067588ae9ee/crates/worker/src/partition/state_machine/lifecycle/pinned_deployment.rs
[R3]: https://docs.restate.dev/services/versioning
[R4]: https://github.com/restatedev/restate/blob/20efb1b83a39b8227451e531c366e067588ae9ee/crates/storage-api/src/state_table/mod.rs
[R5]: https://github.com/restatedev/restate/blob/20efb1b83a39b8227451e531c366e067588ae9ee/cli/src/commands/deployments/remove.rs
[R6]: https://github.com/restatedev/restate/blob/20efb1b83a39b8227451e531c366e067588ae9ee/crates/admin/src/rest_api/deployments.rs
[R7]: https://docs.restate.dev/services/invocation/managing-invocations
[R8]: https://github.com/restatedev/restate/blob/20efb1b83a39b8227451e531c366e067588ae9ee/LICENSE
[E1]: https://github.com/envoyproxy/envoy/blob/b2d89e0ae53916f28770771fbdd49c5c99c5c5a2/source/common/rds/rds_route_config_subscription.cc
[E2]: https://github.com/envoyproxy/envoy/blob/b2d89e0ae53916f28770771fbdd49c5c99c5c5a2/source/common/rds/rds_route_config_provider_impl.cc
[E3]: https://github.com/envoyproxy/envoy/blob/b2d89e0ae53916f28770771fbdd49c5c99c5c5a2/source/common/thread_local/thread_local_impl.cc
[E4]: https://github.com/envoyproxy/envoy/blob/b2d89e0ae53916f28770771fbdd49c5c99c5c5a2/source/common/http/conn_manager_impl.cc
[E5]: https://www.envoyproxy.io/docs/envoy/v1.40.2/api-docs/xds_protocol
[E6]: https://www.envoyproxy.io/docs/envoy/v1.40.2/intro/arch_overview/operations/hot_restart
