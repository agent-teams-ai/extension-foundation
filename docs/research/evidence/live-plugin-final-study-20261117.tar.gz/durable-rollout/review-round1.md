# Independent review: durable execution and rollout, round 1

Reviewed: 2026-11-17.

Draft: `docs/research/live-plugin-evolution-final-research-and-architecture-2026-11-17.md`

Exact draft SHA-256:
`089c7b60990a6c3fe1d91f2de751bc8bd149a72218d4474600886c323d25d9b4`.

Also cross-read `deeper-live-plugins-20261117/portable-boundary/report.md` and the
durable-rollout source ledger. No governed files were modified, runtime
experiments executed, policy chosen or external comments posted.

## Result

One source-scope correction is needed before the Golem evidence is final.
Temporal, Restate and Envoy assertions in the root synthesis agree with the
inspected contracts/source at their stated scope. The ownership and conditional
planning treatment are sound. The two citation improvements below are narrow
evidence traceability changes, not reasons to expand the architecture.

## Findings

### DR1-01: source revision/start guard applies to snapshot-assisted selection

**Severity:** medium; exact claim correction.

The Golem paragraph currently says the persisted strategy includes source
revision/start identity and rejects a stale source without distinguishing the
two strategies. At commit `b277b3ddfbcf02cf52b921e9c41f5816bbd55de7`,
`snapshot_selection/mod.rs` `strategy()` constructs those source fields only for
`SnapshotAssistedAutomatic`; ordinary `Automatic` contains `target_revision`.
`stale_assisted_head()` returns `None` for all other update kinds. The durable
choice between assisted and full replay is supported, but the source guard must
not be generalized to the full-replay representation.

**Concrete fix:** state that the choice is persisted for the attempt, and that
*for snapshot-assisted automatic updates* the frozen selection additionally
records source revision/start identity and rejects a stale source before
instantiation. Keep the stable-attempt/retry conclusion scoped to that selected
strategy instead of implying a universal source guard.

Independent source read: Git blob
`24474441c8bc27765178b1397c935c7d214f0552`, `strategy()` and
`stale_assisted_head()`, at the immutable [source](https://github.com/golemcloud/golem/blob/b277b3ddfbcf02cf52b921e9c41f5816bbd55de7/golem-worker-executor/src/worker/snapshot_selection/mod.rs).

### DR1-02: place the exact licensing and Go limitation sources at the claims

**Severity:** low; citation precision.

The Go manual-update limitation is present at the end of the versioned
`how-to-guides/common/golem-update-running-agents.mdx`, Git blob
`42b77699b43e0a9cdd9a811c7317b624d4988db1`. The paragraph's adjacent
`golem-updating` / revision-preparation links do not directly contain that Go
sentence. Add the existing `golem-guide` link next to the limitation.

Restate's BSL1.1 identification is correct but the paragraph has no direct license
link. Add an immutable link to
`restatedev/restate@20efb1b83a39b8227451e531c366e067588ae9ee/LICENSE`, Git blob
`82a68338267bbde13cf9b0a04682778284ef3f35`, already in the lane ledger.

## Checks that passed

- Temporal's preview qualification and new-run/application deduplication
  distinction are accurate. No claim of generic stack migration, automatic
  compensation or indefinite old-worker retention is introduced.
- Restate retains deployment/protocol selection in invocation metadata; the
  root correctly separates that from persistent object-state compatibility.
- Restate CLI drain inspection followed by forced server removal is accurately
  described as a layered source observation. The text does not claim a
  reproduced race, vulnerability or universal application failure.
- Envoy source supports asynchronous per-thread publication and per-stream
  captured configuration. The explicit refresh qualification avoids claiming
  the snapshot can never change. xDS and publication-hook limits are not
  confused with whole-fleet transactional cutover.
- Golem's automatic restart versus manual queued snapshot boundary, filesystem
  compatibility and replay/snapshot limitation are otherwise supported by the
  independently fetched release source and versioned guide.
- Root's remote-MCP wording matches the portable-boundary lane: a locally
  retained proxy cannot pin remote implementation bytes; the actual server
  contract must carry the stronger promise.
- Business identity, execution attempt, code generation and state schema are
  distinct; the existing application retains idempotency, effect receipts and
  state meaning. No second workflow engine, schema migrator, Host, graph compiler
  or independent active-head owner appears.
- Estimates explicitly exclude state migration/distributed publication and
  describe new P/I/T LOC, changed-existing uncertainty and judgment scores. They
  are not presented as measured delivery cost or runtime reliability.
- Ordinary-update interruption stays OPEN. The proposed checks are selected by
  profile; they do not silently require cancellation or all-profile support.
- Yet-uncreated evidence/receipt/review links are pending delivery work and are
  not semantic blockers in this review.

## Review limits

This is source/contract criticism. No runtime test or benchmark was executed.
It does not independently qualify the complete OTP/OSGi/Node/Effect/Wasm stacks,
approve a public SPI, or choose the future implementation profile. Golem source
and license were independently fetched for this round; full third-party working
copies remain under `inspection-temp` and are excluded from the owned evidence
archive.
