# Final live plugin evolution research evidence

Observation date: 2026-11-17, Europe/Kiev.

This packet supports the governed report
`docs/research/live-plugin-evolution-final-research-and-architecture-2026-11-17.md`
in agent-teams-ai/extension-foundation Draft PR55. It extends, rather than
replaces, the immutable Nov14 native Effect evidence and first Nov17 portable
mechanism packet.

## Contents

- `mature-runtimes/`: OTP and OSGi/Felix source/contract investigation.
- `durable-rollout/`: Temporal, Restate and Envoy investigation.
- `portable-boundary/`: Node, MCP, native Effect and portable ownership.
- `emerging-runtimes/`: root Golem/wasmCloud investigation and GM recheck.
- Each specialist lane contains two independent review rounds of the root
  synthesis; the root dispositions describe all material corrections.
- `review-inputs/` preserves the exact first and second root drafts reviewed.
  The second-round Effect specialist additionally verifies the final wording
  correction against the published document hash.
- `validation/` retains the original spelling failure and authoring scope.

The source ledgers retain immutable Git commit/blob identities and dated moving
documentation URLs. Third-party working copies in `inspection-temp`, repository
credentials, dependencies, executables, raw downloaded source and symlinks are
excluded. This packet redistributes our analysis, not complete upstream files.

## Evidence boundary

No new competitor/runtime experiment, regression reproduction, scale benchmark,
public package or production integration was executed. Inspected upstream tests
are not reported as locally passing tests. The MCP SDK overlap scenario remains
a proposed falsifier. Document-server and other outside consumers are proposed
acceptance fixtures, not existing adopters.

Ordinary-update interruption remains OPEN. Research does not accept a runtime,
publish a public SPI, merge the Draft PR or replace existing authority.

The adjacent archive manifest binds every regular file's size and SHA256.
The adjacent validation receipt binds final governed files and contains the
completed documentation gate and independent custody audit. That receipt is
created after the local gate and is not its own test input. Hosted CI outcomes
are recorded against the final commit in PR metadata, not asserted in an
earlier source snapshot.
