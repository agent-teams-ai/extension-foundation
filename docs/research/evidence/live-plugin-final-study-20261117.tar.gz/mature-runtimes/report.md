# Mature runtime upgrade semantics: Erlang/OTP and OSGi/Felix

Observation: 2026-11-17, Europe/Kiev. This lane adds implementation-level
counterexamples to the retained 2026-10-21 and 2026-11-14 research. It does not
claim to discover hot replacement for the first time, select a product update
policy, propose a BEAM/JVM migration, or qualify either runtime locally.

Evidence classes: **contract** is published official documentation/specification;
**source** is inspected pinned implementation; **inference** is our proposed
transfer; **proposed check** was not executed. No runtime tests were run.

## What is new relative to the existing report

The retained research already covered OTP's two code versions and explicit state
conversion, OSGi dependency-closure refresh, dynamic rebinding and stale object
references. The deeper findings concern the exact boundaries of those promises:

1. **A successful lifecycle operation need not establish application readiness.**
   OSGi can finish a refresh after reporting component failures; SCR lifecycle
   callbacks have deliberately different failure semantics. Readiness needs
   its own owner-defined condition.
2. **Preparation may execute user code more than once.** OTP's script checker
   evaluates pre-commit instructions, and installation evaluates them again.
   A check phase is not automatically pure or safe to repeat.
3. **A process snapshot is not an admission barrier.** OTP's update interpreter
   operates on discovered processes and records the ones successfully suspended.
   Its source explicitly recognizes processes that appear afterward or fail to
   suspend. VM support does not eliminate application quiescence design.
4. **Rollback can reconstruct service without preserving the instance.** Felix
   stops an active bundle before revising its executable revision. Restoring a
   revision does not preserve the old activator or its resources.
5. **API compatibility does not preserve enforcement.** Felix Framework 8 keeps
   permission API types while deliberately removing Security Manager enforcement.
   A runtime profile has behavioral obligations beyond compatible signatures.

These are supported below; the architectural implications are inferences, not
unreported upstream defects.

## Exact evidence identities

| Surface | Inspected identity | Applicability |
| --- | --- | --- |
| OTP | `OTP-29.1.2`, commit `d199a49a01a2079afb6f2c5c9ae047cd4555e68d` | Official documentation presently identifies OTP 29.1.2 / SASL 4.4. This is an evidence pin, not a deployment recommendation. |
| OSGi contracts | Core Release 8, lifecycle/service 1.10; Declarative Services 1.5 in Compendium 8.1 | Versioned normative descriptions; permissions must be interpreted with the actual runtime implementation. |
| Felix Framework | Released 8.0.0 tag, commit `b1bcadcfefde90bd6ef6f5919dbf626754255f2f` | Apache release guide and distribution listing confirm released identity; binary artifacts were not downloaded or qualified. |
| Felix SCR | Released 2.3.0 tag, commit `615dd9d623fc7659631aec9e2b6962feeccfefa6` | Released Declarative Services implementation; no test suite run here. |
| Felix current source | `c9e909e7da0eb41a1d1f40f5f5f240845f042907` | Framework 8.0.1-SNAPSHOT / SCR 2.3.1-SNAPSHOT. Relevant core, wiring and dependency-manager files match their released blobs exactly. BaseMethod differs, so claims use the released file. |

OTP and Felix source headers identify Apache-2.0. OSGi specifications use their
own specification license; this lane links them and does not redistribute a
specification or a copied implementation.

## 1. OTP: code availability, process conversion and application admission

### Interpreter trace and partial conversion

**Source.** `release_handler_1:eval_script/5` separates instructions around
`point_of_no_return`. `eval({suspend,...})` obtains supervised processes, then
collects successful suspensions. `change_code` visits the retained process IDs
sequentially. A failing conversion throws; the script interpreter represents a
post-boundary failure as an exit. This is not an all-process transactional swap.
[OTP interpreter][otp-engine]

**Source.** `gen_server:system_code_change` substitutes its state only on an
`{ok, NewState}` callback result. `sys:do_change_code` returns the existing
process bookkeeping when the callback fails. This establishes a bounded local
state result. It does not roll back callbacks that already changed another
process or wrote outside the process. [gen_server][otp-server]; [sys][otp-sys]

**Inference.** Suppose process A converts, process B fails, and conversion A
also writes to a database. Neither replacing the code pointer nor retaining B's
old state makes that database compatible again. A portable contract must name
which state is inside its failure boundary. A library should not accept an
arbitrary migration callback and advertise transactional rollback around it.

The existing owner can choose a compatible state protocol, a versioned durable
schema or a qualified restart. These are application-specific choices. Keeping
all of them in a single generic `reload()` method would hide the essential
preconditions and weaken substitutability.

### Preparation, timeout and admission details

**Source.** `check_script` executes the script segment before the boundary;
`eval_script` executes that segment during installation as well. Both reach the
same instruction evaluator, including `apply`. **Inference:** such instructions
must be designed for repetition or carry their own idempotency/custody contract.
Treating a preliminary check as proof that no side effects occurred is invalid.
[OTP interpreter][otp-engine]

**Contract/source.** Current `install_release` supports `code_change_timeout` and
`suspend_timeout`. The current default `sys:change_code/4` timeout is 5,000ms.
An older indexed `appup` manual says code change has no timeout; that historical
wording must not be used for this pin. The separate `sync_nodes` instruction
still documents unbounded waiting. [release_handler][otp-handler]; [sys][otp-sys];
[current appup][otp-appup]

**Source.** The suspension helper omits unresponsive processes and attempts to
resume them if suspension arrives late. Its comments explicitly recognize new
processes appearing between discovery and code loading. **Inference:** an
updater that needs every new operation excluded must establish that property in
the owning admission path; successful suspension of an observed set is weaker.
[OTP interpreter][otp-engine]

This is directly relevant to JavaScript: single-threaded scheduling does not
prevent a new operation from entering between two awaited phases. Admission,
generation selection and lifetime retention must share a protected boundary;
an array of active calls obtained earlier is not that boundary.

### Scope of true hot code loading

**Contract/source.** OTP can retain current and old module code; local calls may
continue in old code while fully qualified calls select current code. Loading
and purge APIs expose refusal or forced removal. These VM facilities do not
move arbitrary JavaScript stacks and closures. [OTP code][otp-code]

**Inference.** The portable equivalent worth designing is explicit compatibility
between operations and a retained generation. In-place migration can be a
separately qualified optional profile. The common library should not pretend to
emulate the VM, own process discovery, or select cancellation to clear old code.

## 2. OSGi/Felix: distinguish registry, wiring, activation and useful service

### Bundle update is a lifecycle sequence

**Source.** Released Felix `updateBundle` rejects an update that reenters a bundle
while it is STOPPING or actively STARTING. STARTING is permitted when the
declared activation policy is in use and the revision declares lazy activation.
For an ACTIVE bundle it first calls stop, then
revises the bundle under the framework lock. A failed revision can roll back
revision data. The method later starts a previously active bundle again; the
original live activator has already stopped. [Felix Framework 8.0.0][felix-core]

**Inference.** An operation returning to old code is not enough to call it
seamless rollback. Distinguish retaining the old instance, reconstructing an
instance from old executable bytes, restoring persisted state and compensating
external effects. These require different acceptance criteria. A universal
mechanism can report them truthfully without implementing them all.

**Contract.** If `BundleActivator.start` fails, its `stop` callback is not called.
The initializer must clean up its partial acquisitions. Successful stop does
not revoke every exported Java code reference: other bundles may still execute
exported packages. [OSGi lifecycle][osgi-lifecycle]

**Inference.** A candidate resource scope must register cleanup as resources are
acquired. A final disposer installed only after setup succeeds misses partial
failure. Native Effect scopes are relevant to this concern; they still do not
decide whether old work may be interrupted.

### Refresh completion is not readiness

**Contract.** `FrameworkWiring.refreshBundles` returns before work completes.
It expands the reverse dependency closure, stops and re-resolves affected
bundles, then attempts restart. Errors are sent as `FrameworkEvent.ERROR`;
some bundles may remain unresolvable. The subsequent `PACKAGES_REFRESHED` event
announces completion of the operation, not universal successful activation.
[OSGi FrameworkWiring][osgi-wiring]

**Source.** Felix queues refresh requests on a dedicated thread. Its refresh
implementation stops all affected bundles before refreshing/removing and
restarting them, and emits the completion event afterward. Certain system or
extension-bundle changes require framework restart. [Felix wiring][felix-wiring];
[Felix core][felix-core]

**Inference.** A future adapter should expose actual observations: revision
installed, initialization completed, consumer readiness accepted, new requests
selected, prior work settled and resources released. Replacing these with one
`updated: true` boolean makes a consumer unable to tell a completed attempt
from a usable replacement. This does not justify a second authoritative ledger:
the existing owner records the facts it needs.

### Dynamic dependency binding has its own contract

**Contract.** DS distinguishes activation from binding/configuration callbacks.
A thrown activation callback prevents activation. Exceptions in bind callbacks
are logged without failing activation; modified callbacks can throw while
processing continues; unbind failures do not stop deactivation. A replacement
bind precedes the outgoing unbind. [DS 1.5][osgi-ds]

**Source.** Felix `SingleDynamicCustomizer` serializes competing binding attempts,
tracks the current and proposed references, queues better candidates, and tests
whether a candidate disappeared during the callback sequence. Its base method
invoker logs callback exceptions and returns a caller-selected failure result.
[SCR dependency manager][felix-dm]; [released invoker][felix-method]

**Inference.** Async JavaScript adapters need the equivalent identity discipline:
old cleanup cannot clear a slot now containing a newer object; a late candidate
cannot overwrite a newer selected revision; and callbacks may trigger more
changes. Use the existing operation/generation owner and native concurrency
primitives instead of reproducing a general dynamic dependency container.

The OSGi service contract also documents synchronous registration notifications:
a listener can obtain and invoke a service before `registerService` returns.
It warns against putting arbitrary objects into service properties because the
framework cannot track the resulting dependencies. [Service layer][osgi-service]

**Inference.** Prepare internal ownership and cleanup before making a capability
discoverable. Descriptors should not smuggle live generation-owned handles into
long-lived metadata. This is a useful rule for model-visible tool catalogs too.

### Current breaking change: permission types outlive enforcement

**Contract.** The Felix Framework 8 upgrade guide explicitly removes the OSGi
security layer following Java's Security Manager removal. The permission types
remain exported; lifecycle, service and class/resource operations no longer run
those checks. A launcher that requests `org.osgi.framework.security` fails at
startup, rather than starting under that requested protection. SCR 2.3.0 removes
the corresponding permission wrappers. [Official upgrade guide][felix-upgrade]

**Inference.** This is a documented intentional transition, not a newly discovered
vulnerability. It demonstrates why a portable runtime profile must state
enforcement as a postcondition. Compatible exported method names and successful
compilation cannot prove the promised boundary. A consumer must reject an
adapter that cannot provide a required guarantee; optional metadata cannot turn
that adapter into a suitable implementation.

## 3. Consequences for a universal library

| Concern | Reusable mechanism or existing primitive | Consumer-owned condition |
| --- | --- | --- |
| Candidate acquisition | Native resource scope and cleanup registration | Which dependencies establish useful readiness |
| Selection | One protected selection/admission/retention operation | Which operation or session may adopt the candidate |
| Replacement closure | Existing composition plan plus explicitly bounded retained dependencies | Which provider, client, renderer and state must change together |
| Reentrancy | Existing generation identity and serialized operation control | Whether an update request is deferred, rejected or scheduled after a boundary |
| State | Optional typed checkpoint/restore adapter only for a demonstrated need | Semantic compatibility, canonical writes and recovery |
| Retirement | Existing resource/custody owner and observed release facts | Timing and permitted interruption remain OPEN |
| Runtime conformance | A profile's testable postconditions and explicit unsupported outcomes | Required isolation, deployment and failure boundary |

This structure applies Clean Architecture concretely: high-level policy names
the condition it needs, and an adapter supplies only the mechanism it can
actually uphold. Interface segregation prevents tools, UI components and stateful
providers being forced into irrelevant methods. Liskov substitution means
matching failure, lifetime and enforcement semantics, not merely method names.
DRY preserves one source of knowledge for each state transition and authority;
it does not require unrelated runtimes to share a fabricated implementation.

These lessons support a library designed for external consumers from its first
real delivery. They do not establish a need for a new package: first subtract
Get Modular composition, its existing private lifecycle candidate, Effect or
ordinary resource owners, and fitting worker/process libraries. Reuse may leave
a small coordinator or only a qualified recipe. No JVM/BEAM code should be
ported merely to reproduce familiar lifecycle names.

## 4. Five proposed falsifiers for the future real slice

None was executed in this research lane. Run only against a disposable consumer
when a selected design makes the outcome decisive.

| Scenario | Distinct observation required | Architectural assumption it challenges |
| --- | --- | --- |
| Repeat preparation | Run check, installation preparation and one retry; observe external writes independently | Preparation is pure merely because it is named check or prepare |
| Work enters during suspension | A new call attempts admission after active work was enumerated but before retirement | An active-call snapshot closes admission |
| Failure after partial acquisition | Candidate acquires one real resource, then initialization fails | The final dispose callback covers resources acquired before successful activation |
| Callback-triggered second update | Binding triggers a newer update; old cleanup completes late | The last promise to settle is necessarily the newest authorized candidate |
| Completion with broken service | Loader/refresh completes while readiness fails or a needed capability is absent | A completed lifecycle event proves useful availability |

A sixth profile check becomes warranted only if a consumer requires isolation:
hold an unchanged public API while substituting an adapter without the required
enforcement. It must reject qualification instead of treating lifecycle success
as security equivalence. This is conditional, not a new mandatory subsystem.

## Scope and remaining uncertainty

New production/integration code: **zero**. No executable qualification, benchmark,
upstream regression reproduction or published artifact provenance audit was
performed. Source findings are bounded to the exact identities above. Existing
product authority and ordinary-update interruption remain unchanged. Callback
side effects and failures in the proposed examples are deliberate falsifiers,
not claims that an upstream default implementation currently loses user data.

The useful next evidence is a real, bounded consumer operation with retained
resources and concurrent replacement. Another broad ecosystem inventory would
not settle whether our particular ownership boundary is correct.

[otp-engine]: https://github.com/erlang/otp/blob/d199a49a01a2079afb6f2c5c9ae047cd4555e68d/lib/sasl/src/release_handler_1.erl
[otp-handler]: https://github.com/erlang/otp/blob/d199a49a01a2079afb6f2c5c9ae047cd4555e68d/lib/sasl/src/release_handler.erl
[otp-server]: https://github.com/erlang/otp/blob/d199a49a01a2079afb6f2c5c9ae047cd4555e68d/lib/stdlib/src/gen_server.erl
[otp-sys]: https://github.com/erlang/otp/blob/d199a49a01a2079afb6f2c5c9ae047cd4555e68d/lib/stdlib/src/sys.erl
[otp-code]: https://github.com/erlang/otp/blob/d199a49a01a2079afb6f2c5c9ae047cd4555e68d/lib/kernel/src/code.erl
[otp-appup]: https://www.erlang.org/doc/apps/sasl/appup.html
[osgi-lifecycle]: https://docs.osgi.org/specification/osgi.core/8.0.0/framework.lifecycle.html
[osgi-service]: https://docs.osgi.org/specification/osgi.core/8.0.0/framework.service.html
[osgi-wiring]: https://docs.osgi.org/javadoc/osgi.core/8.0.0/org/osgi/framework/wiring/FrameworkWiring.html
[osgi-ds]: https://docs.osgi.org/specification/osgi.cmpn/8.1.0/service.component.html
[felix-core]: https://github.com/apache/felix-dev/blob/b1bcadcfefde90bd6ef6f5919dbf626754255f2f/framework/src/main/java/org/apache/felix/framework/Felix.java
[felix-wiring]: https://github.com/apache/felix-dev/blob/b1bcadcfefde90bd6ef6f5919dbf626754255f2f/framework/src/main/java/org/apache/felix/framework/FrameworkWiringImpl.java
[felix-dm]: https://github.com/apache/felix-dev/blob/615dd9d623fc7659631aec9e2b6962feeccfefa6/scr/src/main/java/org/apache/felix/scr/impl/manager/DependencyManager.java
[felix-method]: https://github.com/apache/felix-dev/blob/615dd9d623fc7659631aec9e2b6962feeccfefa6/scr/src/main/java/org/apache/felix/scr/impl/inject/methods/BaseMethod.java
[felix-upgrade]: https://felix.apache.org/documentation/subprojects/apache-felix-framework/apache-felix-framework-8-upgrade-guide.html
