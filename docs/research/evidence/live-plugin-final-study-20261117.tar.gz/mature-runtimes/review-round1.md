# Independent mature-runtime and cross-source review — round 1

Reviewed file:
`docs/research/live-plugin-evolution-final-research-and-architecture-2026-11-17.md`

Reviewed SHA-256:
`089c7b60990a6c3fe1d91f2de751bc8bd149a72218d4474600886c323d25d9b4`.

Date: 2026-11-17, Europe/Kiev. Review scope: mature runtime source support,
release applicability, readiness/rollback claims, Golem and wasmCloud source
cross-checks, portability and ownership. No runtime execution or policy adoption.

## Result

Two narrowly scoped factual corrections are required before final publication.
One additional cleanup-condition clarification is recommended. The architecture
and authority treatment otherwise preserve the intended boundary: no second
composition/resource/authority owner, no implicit ordinary-update interruption
policy, no new public SPI or qualified-runtime claim.

### R1 — Felix STARTING rejection has an explicit exception

The OSGi/Felix section says reentrant update during STARTING or STOPPING is
rejected. Released Framework8.0.0 `Felix.updateBundle` excludes the supported
lazy-activation STARTING state from that rejection. This exception was retained
in the specialist report and should survive synthesis.

Recommended disposition: say that updates are rejected while STOPPING or
actively STARTING, with the explicit supported lazy-activation exception.

Evidence: commit `b1bcadcfefde90bd6ef6f5919dbf626754255f2f`,
`framework/src/main/java/org/apache/felix/framework/Felix.java`,
blob `f2104d2aa58522d9adf90c88ad841c95c3190d01`, `updateBundle`,
condition immediately after acquiring the bundle lock.

### R2 — Golem source identity is specific to snapshot-assisted strategy

The Golem section states that the persisted strategy includes source revision
and its start identity and rejects stale source before instantiation. In the
inspected source, `strategy()` constructs those fields in
`UpdateDescription::SnapshotAssistedAutomatic`; the plain `Automatic` strategy
contains `target_revision`. `stale_assisted_head` deliberately checks the former
variant only. Persisting the chosen strategy applies to both forms, but these
source fields and stale-source check should not be generalized to both.

Recommended disposition: separate the statements: selection is persisted;
the snapshot-assisted form additionally freezes source revision/start identity,
and a stale snapshot-assisted source is rejected before instantiation.

Evidence: commit `b277b3ddfbcf02cf52b921e9c41f5816bbd55de7`,
`golem-worker-executor/src/worker/snapshot_selection/mod.rs`,
blob `24474441c8bc27765178b1397c935c7d214f0552`, `strategy`,
`decide_start`, `stale_assisted_head`, `active_head`.

### R3 — Deferred unbind also proceeds after store teardown drops the reply

The wasmCloud section currently says unbind is deferred until the hook returns.
`spawn_deferred_unbind` waits for its reply channel; the source explicitly
includes the channel being dropped by store teardown, and it then checks the
current incarnation's availability. The principal conclusion remains correct:
timeout alone proves neither cleanup nor physical absence.

Recommended disposition: add “or its store is torn down” to the wait condition.
Do not imply that all cleanup must wait for a normal successful return.

Evidence: commit `8b0e24cb6610642783e3f16f5f1eac45ff2cb5aa`,
`crates/wash-runtime/src/plugin/component_host/lifecycle.rs`,
blob `b08dda8f52b5ff42c1473c0463abd3603eb4d10b`,
`spawn_deferred_unbind` and its reply wait.

## Independently checked positive claims

- OTP conversion is sequential; the successful suspended set is not new-work
  admission closure. Pre-boundary script instructions are evaluated by both
  check and install paths. No all-process or external-effect rollback is claimed.
- OSGi refresh completion is distinct from readiness. Partial activation cleanup
  and callback-specific failure semantics are accurately distinguished.
- Felix8 permission API continuity does not imply Security Manager enforcement;
  this is a documented platform transition, not characterized as a vulnerability.
- Released Felix core, wiring and dependency manager blobs match the inspected
  master; current and released version identities are not conflated.
- Golem automatic/manual lifecycle distinction, queued manual invocation,
  filesystem compatibility and documented Go manual-update limitation are
  supported by the exact release sources and versioned guide.
- wasmCloud held targets check deployment generation, rather than equating a
  retained handle with liveness; bind timeout can outlive the caller; recovery
  retains reservation identity. These are source observations, not executed tests.
- Library-first portability remains explicit. Consumer contracts and selection,
  state and permission authorities keep their owners. Effect/private kernel
  reuse is not turned into an unconditional outside dependency or public API.
- Qualified recipe, residual implementation and stronger platform remain
  alternatives. Conditional cost scores are not represented as measured
  reliability. External fixture and independent SPI conformance remain distinct.

## Cross-source inventory

The Golem files independently read for this review are lifecycle/mod.rs
(`bf732fb97c98a5ef39a344617374034846e98704`), snapshot_selection/mod.rs
(`24474441c8bc27765178b1397c935c7d214f0552`), versioned updating.mdx
(`93693d9666447a3a8455927dd4646c2bac3e028e`), revision_update.rs
(`7841b10100bcffd01f099bea4417c8677b560531`), and the update-running-agents guide
(`42b77699b43e0a9cdd9a811c7317b624d4988db1`).

The wasmCloud files independently read are lifecycle.rs
(`b08dda8f52b5ff42c1473c0463abd3603eb4d10b`), workload_call.rs
(`0a77e557c6f37b0d61191a2acfe2ec36e2c89ad1`) and host/cleanup.rs
(`61d94844ba4b38b729d6316af115a4af7727155c`). Mature-runtime identities are
retained in this lane's source ledger. Temporary evidence/review/validation
links awaiting assembly are not findings against this draft.

This review does not re-run runtime tests, qualify binary releases or select
one proposed architecture. Final acceptance requires the corrected document
and ordinary documentation delivery checks, owned by root.
