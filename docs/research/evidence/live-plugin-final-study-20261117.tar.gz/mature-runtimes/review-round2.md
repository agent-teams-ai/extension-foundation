# Independent mature-runtime and cross-source review — round 2

Date: 2026-11-17, Europe/Kiev.

Reviewed governed synthesis:
`docs/research/live-plugin-evolution-final-research-and-architecture-2026-11-17.md`

SHA-256:
`a3f6beeb0b2d9b2944c7c241e1429b75143ae484ea3cbdefc3bf574156bbd2f3`.
The retained `review-inputs/root-round2.md` has that same hash.

## Verdict

**Pass for the reviewed research scope. No material finding remains open from
this lane.** This is evidence review, not runtime qualification, public API
approval, adoption of an interruption policy or a declaration that repository
delivery checks have already passed.

## Round 1 findings resolved

- **R1:** Felix's supported lazy-activation exception is explicit in the root
  synthesis. The specialist report already retained the exception; its wording
  and matching ledger claim were made more exact during this round: STARTING is
  permitted when the declared activation policy is in use and the revision
  declares lazy activation. No governed file was edited by this reviewer.
- **R2:** Golem now separates persisted choice from the additional source
  revision/start fields and stale-source check of the snapshot-assisted form.
  Plain automatic strategy is no longer assigned those fields. Both the root
  report and emerging-runtime lane retain the distinction.
- **R3:** wasmCloud's deferred cleanup now waits for the hook reply or a reply
  dropped by store teardown. Timeout, hook settlement and actual cleanup remain
  distinct observations.

## Evidence-map correction found and resolved during this round

The initial emerging-runtime source ledger assigned the Go manual-update
limitation to `develop/updating.mdx`. The inspected release places that statement
in `how-to-guides/common/golem-update-running-agents.mdx`. Root moved the clause
to the correct source entry; the final ledger was read back to verify the
disposition. The governed synthesis already cited the correct guide and did
not need another content change.

## Other checked changes and invariants

- The earlier portable report's remote-MCP clarification limits local capture
  claims at the actual remote execution boundary, without weakening locally
  enforced immutable bindings or relabeling historical experiments.
- Source citations were added for the request schema, SDK inspection, Golem Go
  limitation and Restate license. A source-derived SDK falsifier remains clearly
  unexecuted.
- The RcRef paragraph now distinguishes an invalidated resource from the finite
  TTL path and mentions the owning scope. Its configuration-specific cleanup
  statement does not become a general resource-lifetime guarantee. The specialist
  resource lane owns detailed implementation verification.
- Ordinary interruption stays OPEN; candidate coalescing/backpressure cannot
  introduce hidden cancellation. Architecture remains one owner per invariant,
  with existing primitives subtracted before adding shared mechanism code.
- No public package, stable SPI, production E2E, universal atomic cutover,
  arbitrary state migration or successful binary qualification is claimed.
- Proposed external consumer and conformance scenarios remain proposals; no
  invented adopter or additional implementation mandate was introduced.

## Reviewed supporting identities

| Artifact | SHA-256 |
| --- | --- |
| Prior portable report with MCP clarification | `2ad43f7c1d1471938ed6ccdc378455df3b94a730bdd51131bc981feb0bf588df` |
| Emerging runtime report | `ae19093f75d66097b982d2fe8fea88276a934bb450fb824db96aad47852f96b7` |
| Corrected emerging source ledger | `0d03d02c15158ac92d50114dfae1d078f3a8322e46e6eb4eacf66d0637fdd9e2` |
| Mature runtime report after exact exception wording | `448dde9d50f202f0482801d9d9841d8e1e048f227bd7053be4a9f2ca4de5064a` |
| Mature source ledger after matching wording | `35d9c09c5142ff8e8fc0e210f796e3ae76f3b53b627ce28fd0b95126dc4e1831` |

This was a bounded correction/regression review. No new research campaign,
runtime test, source build or repository gate was run by this reviewer.
