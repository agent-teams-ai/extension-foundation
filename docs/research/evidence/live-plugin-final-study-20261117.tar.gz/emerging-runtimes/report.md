# Emerging Wasm runtime mechanisms and reuse boundaries

Observation: 2026-11-17, Europe/Kiev. This root lane supplements the three
specialist investigations with released Golem and wasmCloud implementation
inspection and a fresh Get Modular ownership check. It contains source evidence
and architectural inference, not a runtime experiment or a recommendation to
migrate to either platform. Exact file/blob/release identities are in
`source-ledger.json`.

## Golem 1.6.3: versioned agent identity and explicit reconstruction

Release `v1.6.3` resolves to
`b277b3ddfbcf02cf52b921e9c41f5816bbd55de7`. The official release metadata was
read and the source tag resolved separately. No executable release artifact was
downloaded, installed or qualified.

The versioned update guide and `worker/lifecycle/mod.rs` agree on two different
mechanisms. An automatic update of an idle or running agent queues the target
and requests a restart. A manual update is a special invocation queued behind
existing work. Its fresh application snapshot is converted by the new code at
that named boundary. These choices have different interruption behavior; neither
is selected for the owner's ordinary updates by this study.

The automatic request's admission index is distinct from the later strategy
selection. `snapshot_selection::decide_start` persists either a snapshot-assisted
strategy or full replay, then re-evaluates the resulting status. An assisted
selection binds source component revision, the source revision's start index,
snapshot index and filesystem snapshot identity. `stale_assisted_head` rejects
a changed source or a non-newer target. The plain automatic strategy records
the target and does not carry those assisted-source fields. Do not advertise
the assisted guard as a universal property of every update variant.

The source-to-target state conversion has several independent inputs. The
target loads application bytes, the executor restores a filesystem baseline,
and revision preparation validates target metadata and applies initial-file
rules. A changed initial-file declaration can conflict with a file modified by
the agent. A snapshot round-trip within new code would not prove that it can
load the old code's output. Current versioned documentation also says Go agents
cannot use manual update yet because an early durable host call precedes
snapshot loading. This is a documented implementation limit, not an inference
that all supported languages have identical behavior.

**Transfer inference:** the important reusable principles are explicit update
attempt identity, a frozen recovery choice where required, state compatibility
checked at the correct boundary, and truthful failure. An ordinary library
does not need its own operation log merely because Golem uses one. Use an
existing durable owner when the consumer needs this level of continuity.

The inspected server license is Business Source License 1.1 with an additional
use grant and hosted developer-platform restrictions. Golem is a source-available
reference in this research. No upstream implementation or license text is copied
into the proposed library or redistributed in the evidence archive; no adoption
or legal conclusion is made.

## wasmCloud 2.12.1: captured handles and outstanding cleanup

Release `v2.12.1` resolves to
`8b0e24cb6610642783e3f16f5f1eac45ff2cb5aa`. Its runtime is an embeddable Rust
crate around Wasmtime, with distinct host, engine, workload and plugin concerns.
Current v2 documentation explicitly says host component plugins load once at
host start and have no dynamic reload today. The earlier v1 development-loop
page describes another version/category; its message-boundary updates must not
be transferred to v2 host plugin behavior. The source is Apache-2.0, which is a
different adoption coordinate from Golem's server license, not qualification.

`component_host/workload_call.rs` implements a narrow positive pattern. A
target handle captures an interface route together with a deployment generation.
Each call rechecks whether that generation is still current. Reusing the same
workload ID after a redeploy does not make an old handle current again. This
keeps coherent references separate from permission to start more work.

`component_host/lifecycle.rs` has a more subtle lifetime contract. A bind
deadline can fail deployment while its hook continues. The pending unbind waits
for the hook's reply, or for store teardown to drop that reply, so late
provisioned state is not treated as already cleaned. Following supervised store
restart, binding hooks are replayed before queued capabilities are served;
callbacks must be idempotent. The study inspected these code paths and their
comments, but did not execute an uncancellable hook or a crash-loop scenario.

`host/cleanup.rs` retains interrupted operations' resources and reservation.
Recovery is serialized, compares that reservation with the current owner and
does not clear a newer operation's record. A timeout preserves cleanup failure;
background retry proceeds while the existing runtime/host supports it. The
source also handles the case where no runtime exists to spawn recovery. This is
evidence for honest cleanup debt, not proof that cleanup is always bounded or
that arbitrary external effects disappear.

**Transfer inference:** a common adapter contract should name actual facts
such as request accepted, callback settled, resources released or container
exit. It should use the existing custody owner for outstanding cleanup and
should not silently substitute a timer expiring for physical cleanup. A generic
plugin interface with one `close(): Promise<void>` needs enough behavioral
definition to avoid concealing these differences.

## Current Get Modular and Effect ownership

Get Modular main was freshly resolved to
`33c032f829028967825428bc6b049ed6db1c56b2`, unchanged from the earlier portable
study. `packages/lifecycle-kernel/package.json` still has `private: true`.
The kernel supplies existing phase, call and custody bookkeeping; its source
has no authority to invent product admission or physical cleanup. The Effect
README supplies native construction/resource semantics, not a live dependency
rewiring service.

Reuse those responsibilities under their existing admission and ownership
boundaries. Ordinary outside consumers cannot be told to install the private
candidate as a published npm API. A qualified recipe with supported entrypoints
may be the entire useful result; a residual common mechanism requires evidence
from materially different consumers before publication.

## Proposed checks, not executed

- Crash/restart between update admission and strategy selection: the selected
  recovery facts must follow the existing owner's replay contract.
- Target snapshot loading fails after a previous successful source snapshot:
  distinguish current selection, reconstructed instance, state and external effects.
- A retained handle spans removal and redeploy under the same logical ID:
  a generation check must reject revival where that is the declared contract.
- A bind callback times out, then finishes late: cleanup must affect only its
  own reservation and report the outstanding lifetime truthfully.

The main governed synthesis combines these mechanisms with mature runtime,
durable-routing and Node/MCP findings. This lane adds zero maintained runtime
code, changes no adopted dependency and does not settle interruption policy.
