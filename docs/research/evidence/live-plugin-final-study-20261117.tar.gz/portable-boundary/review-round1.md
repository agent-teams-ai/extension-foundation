# Independent critique, round 1 — portable boundary lane

Reviewed draft: `docs/research/live-plugin-evolution-final-research-and-architecture-2026-11-17.md`

Exact SHA256 before and after reading:
`089c7b60990a6c3fe1d91f2de751bc8bd149a72218d4474600886c323d25d9b4`

Observation date: 2026-11-17. Reviewer: portable boundary specialist.
No governed files were edited. This is a source/contract review, not runtime
qualification. Pending archive, manifest, receipt and review-record links are
expected delivery work and are not counted as findings.

## Result

Two bounded factual qualifications should be fixed before finalizing this
synthesis. No architectural ownership blocker was found. The MCP remote
boundary is now stated accurately; the SDK concern remains an unexecuted
falsifier. Private-kernel availability, one-owner rules, ordinary external
consumers and the still-open interruption choice are preserved.

## Findings

### PB-R1-01 — Qualify finite RcRef TTL with the invalidation exception

Priority: P2, factual precision affecting the adapter postcondition.

Location: `How Effect fits`, paragraph beginning "New source qualification".

The draft says a finite TTL schedules cleanup separately. Effect 4.1.4's
`release` instead takes the awaited immediate path when the retained acquired
state has been invalidated, regardless of its configured TTL. The public
`RcRef.make` option documentation states this distinction too. Omitting the
exception is material because the preceding study specifically uses
invalidation to retain existing borrowers while new acquisitions proceed.

Suggested correction:

"For non-invalidated resources, finite idleTimeToLive, including zero,
schedules cleanup separately from the final borrower's scope. If TTL is omitted
or the retained resource was invalidated, the final borrower awaits resource
finalization. Closing RcRef's owning scope is a separate lifetime boundary and
must not be treated as prevented by borrower retention."

Keep the existing conclusion: a generic release receipt must name what was
actually observed. No extra reference counter or new Effect experiment is needed.

Sources:

- `packages/effect/src/RcRef.ts` at
  `289a53f7b1fc40049219c6e69022db2fb859c356`,
  blob `d2e4c3eaa99a9659e05f4b49c22d6e3b90e47743`, `make` option documentation.
- `packages/effect/src/internal/rcRef.ts` at the same commit,
  blob `e751bb819627183c5e526537d263e468eb8aa818`, `release` and `make`.

### PB-R1-02 — Preserve Felix's lazy-activation exception

Priority: P2, bounded overstatement of a source condition.

Location: `OSGi and Felix`, sentence saying reentrant update during STARTING or
STOPPING is rejected.

The released Felix 8.0.0 source rejects STOPPING and STARTING without the
supported declared lazy-activation policy. The mature-runtime lane retained
that exception, but the summary drops it. The claim should not prohibit every
STARTING-state update.

Suggested correction:

"Reentrant update while STOPPING or actively STARTING is rejected; the supported
declared lazy-activation state is an explicit exception."

I independently fetched `Felix.java` at
`b1bcadcfefde90bd6ef6f5919dbf626754255f2f`,
blob `f2104d2aa58522d9adf90c88ad841c95c3190d01`.
The condition in `updateBundle` checks both STARTING and the declared
activation-policy flags before rejecting. This is a source qualification,
not a new test or request to adopt Felix.

## Optional evidence improvement

PB-R1-03, P3: put an exact SDK source link beside the falsifier paragraph, and
a schema link beside the absence of an expected implementation revision.
The archive already provides these, so this is discoverability, not a missing
basis for the conclusion.

- SDK source:
  https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/packages/server/src/server/mcp.ts
- Standard request schema:
  https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/schema/2026-07-28/schema.ts

It would also be useful to name output validation/interpretation in the
coherent operation record. The current general "capability contract" wording
already encompasses it; no additional abstraction is required.

## Positive checks and cross-lane review

- MCP: discovery, TTL, pagination and current authorization remain separate
  from remote executor affinity. A local proxy is explicitly insufficient.
  The alternative is supported server-side affinity or honest weaker behavior,
  not a custom metadata field presumed to work on any server.
- SDK: the text labels the mutation scenario unexecuted and does not call it
  a reproduced failure, security finding or reason to replace the official SDK.
- Node: root query identity is distinguished from a transitive cohort. The
  report does not falsely deny the existence of internal cache deletion.
  Escaped objects, native resources, worker exit and remote effects stay
  separate.
- Ownership: the kernel is private; no public npm availability is invented.
  No second graph compiler, active-head store, native refcount, recovery engine
  or product authority is proposed.
- Effect: the main outcome is correct after PB-R1-01's configuration qualifier.
  No claim of new execution is made from the retained four-case experiment.
- Mature runtime synthesis was cross-read against its lane report. Completion
  versus readiness, partial conversion, repeated preparation and
  reconstruction versus retained instance remain distinct. PB-R1-02 is the
  only source-condition loss found there.
- Durable synthesis was cross-read against its lane report. Temporal run
  continuity, deduplication, Restate shared state and deployment pinning,
  Envoy stream/thread/fleet scopes, and the CLI-check versus authoritative
  removal distinction are not conflated.
- No immutable experiment archive or accepted ADR is rewritten. The new
  document's implementation costs retain their bounded scope and are not
  claimed as measured results.
- Interruption of healthy work by an ordinary update remains OPEN throughout.
  Backpressure and a cleanup deadline do not silently choose that policy.

## Review process

Read the complete 665-line draft and both neighboring lane reports. Followed
the repository's documentation route; read-only `docs:info` and `docs:find`
completed successfully. Those commands are navigation, not a substitute for
the root's final documentation gate. No runtime tests, experiments or adopted
dependency changes were performed.

