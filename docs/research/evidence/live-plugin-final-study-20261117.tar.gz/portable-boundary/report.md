# Portable live evolution: runtime limits, remote consistency and decisive falsifiers

Research date: **2026-11-17, Europe/Kiev**. Sources retrieved on 2026-11-17 UTC.
This lane extends the existing portable mechanism study; it does not repeat its
ten project traces or the earlier four Effect runtime scenarios. Evidence here
is official specification/documentation, pinned source inspection, inspected
upstream tests, and explicitly labelled architectural inference. **No runtime
experiment, new test execution, package release or product adoption occurred.**

Ordinary-update interruption remains **OPEN**. A recommendation about a coherent
operation or resource receipt does not choose whether ordinary updates may stop
healthy work. The repository's existing owners and public-contract gates remain
in force.

## Findings that change the design

1. **A local snapshot does not pin a remote executor.** An MCP client can retain
   the schema it showed a model and the local function that sends a request.
   The standard request still names the remote tool, without a standard
   expected-implementation revision. Remote revision affinity requires a
   server-supported contract. Otherwise refresh, unavailability or replanning
   must remain possible. [M1], [M2]
2. **A complete tool listing is not necessarily one coherent remote generation.**
   Current MCP caching explicitly permits changes before TTL expiry and provides
   no cross-page consistency guarantee. A client cannot manufacture the absent
   guarantee by freezing the collected array. [M3]
3. **New entry-module identity is weaker than a new executable cohort.**
   Node resolves each dependency and looks up its own module job. Changing only
   the root URL query does not automatically version sibling imports, native
   libraries, host services or externally captured objects. [N1], [N2], [N3]
4. **A cleanup API's exact configuration changes its postcondition.**
   Node Worker termination observes thread exit. Effect RcRef with a finite
   idle TTL, including zero, can return from the last borrower's scope before
   deferred finalization runs. These are useful mechanisms with different
   contracts; neither justifies a universal, stronger close receipt. [N5],
   [N6], [E1], [E2]
5. **A reusable package is conditional on a remaining shared invariant.**
   Existing GM composition, optional private lifecycle accounting, native
   borrowing and a selected execution library already cover much of the
   mechanism. The new evidence strengthens the case for qualification and
   small adapters before another general runtime. It does not require duplicate
   counters or product authority. [G1], [G2], [G3]

## Source identities and scope

| Subject | Identity inspected | Evidence limit |
| --- | --- | --- |
| Node.js | Release v26.13.1, tag resolves to `e9c277643b0249c50f6e6de5413be8a88ea11b6a` | Documentation and implementation inspected; no binary execution or memory benchmark |
| ECMAScript | Published 2026 edition, module namespace and module-loading algorithms | Language semantics, not a host-specific reclamation guarantee |
| MCP | Released protocol 2026-07-28, documentation/schema snapshot `de3550c9fea3c5269e42ac95204eef44a2b2cb92` | Current text of the released revision, not a claim every deployed server implements it |
| MCP TypeScript SDK | Main `919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c`; server source manifest 2.4.0 | Source version observed; exact npm artifact/publication not qualified in this lane |
| Get Modular | Main `33c032f829028967825428bc6b049ed6db1c56b2` | Relevant kernel and Effect README blobs unchanged from prior study |
| Effect | Already qualified 4.1.4 source `289a53f7b1fc40049219c6e69022db2fb859c356` | Existing qualified source revisited; no new runtime test |

The adjacent source ledger records file hashes, symbols, exact URLs, evidence
classes and limitations. No retrieved third-party implementation is copied into
a new maintained implementation.

## 1. JavaScript can change dispatch without changing existing executions

### Module identity and the dependency cohort

**Documented and source-inspected.** Node uses URL identity for ESM, so queries
or fragments can cause multiple loads. The loader separately indexes module
jobs by resolved URL and import type. Relative dependency resolution uses the
dependency specifier with its parent URL; a root's query is not an automatic
generation tag on every dependency. [N1], [N2], [N3], [N4]

For example, `entry.ts?revision=2` importing `./helper.js` can receive the
same helper URL as revision 1. This is an architectural inference from normal
relative URL resolution and the inspected cache path, not a new executed test.
A selected loader can intentionally rewrite its controlled graph; the earlier
OpenCode study shows such a strategy. The loader must still declare which
imports, packages, native dependencies and late-loaded code it controls.

The load cache currently has an internal deletion operation. That is
counterevidence against claiming Node has no deletion mechanism whatsoever.
It is not a supported public transaction that erases escaped references,
releases resource owners or proves module memory was reclaimed. The public ESM
documentation also separates its cache from `require.cache`. [N1], [N2], [N4]

**Design consequence.** Use the existing artifact/loader owner to identify a
closed, admitted cohort where that promise is needed. A neutral coordinator
should receive the result; it should not become a second dependency resolver
or create an approximate graph from filesystem watching.

### Live bindings have a precise scope

**Language contract.** A module namespace refers to a particular Module Record.
Reading an export resolves the binding in that record's environment.
GetModuleNamespace caches the namespace on its Module Record; ordinary namespace
assignment and deletion cannot replace its exported bindings. A mutable export
can change in its original module, but this is different from redirecting every
reference to a separately imported revision. [J1], [J2]

**Inference.** An already copied function, closure, iterator or callback retains
its own references until its owner changes them or they become unreachable.
No portable library can infer a suspended function's state migration merely
from loading another file. A stable application facade can deliberately choose
the implementation for a new operation. It must define whether a multi-step
operation captures one generation or can make independent selections.

The sensible universal target is explicit admission and revision selection at
declared boundaries. Transparent rewriting of arbitrary running stacks,
callbacks or renderer internals is outside that target.

### Worker exit and native resources

**Documented and source-inspected.** Worker.terminate asks the native handle to
stop, then resolves on the exit event; async disposal awaits that method.
Documentation permits execution to stop at any point. Node also documents
positive cleanup behavior: unmanaged file descriptors opened through its
supported filesystem APIs are tracked by default and closed on worker exit.
These concrete protections should be credited. [N5], [N6]

**Limit.** Exit is a useful observable fact, not proof that a main-thread
callback, a delegated remote request or a committed database operation vanished.
A generic adapter must keep application settlement and external-effect
uncertainty with their existing owners. This is a contract boundary, not a claim
that Node's exit event is unreliable.

**Documented native boundary.** Addons loaded in multiple Node environments
must support Node-API or context-aware initialization, and need environment
cleanup for allocated resources. Shared static state requires its own protection.
The CommonJS docs explicitly exclude native addons from the ordinary delete-cache
reload recipe. A plugin's transitive native dependencies therefore affect which
replacement profile can honestly be supported. [N7], [N8]

A worker adapter is useful when a separately disposable JavaScript environment
is required. It is not an automatic hostile-code sandbox, a generic native
library updater, or a substitute for the existing physical-custody owner.

## 2. MCP makes discovery dynamic; execution coherence remains a separate contract

### Four identities that must not be collapsed

The local model-visible descriptor, the local RPC client, the remote selected
implementation and the remote state handle are distinct. Capturing the first two
does not freeze the latter two. This distinction is new precision for the prior
study's descriptor/executor advice.

**Protocol observation.** CallToolRequestParams supplies a tool name and
arguments, together with inherited request metadata and optional multi-round-trip
input/state. The standard shape does not define an expected tool-generation or
implementation-digest precondition. Protocol-version metadata identifies the
wire protocol; it is not an implementation version for the named tool. [M2],
[M5]

**Inference and proposed transfer.** Where the product promises generation
consistency across an RPC boundary, its remote owner must support an explicit
versioned endpoint, operation handle or checked revision contract. A local
wrapper cannot add that authority unilaterally. A normal MCP adapter without
that agreement can expose the tool's current behavior and handle changes
explicitly; it cannot claim snapshot-pinned execution. Even unchanged JSON
schema can conceal a changed business meaning, so revalidation alone does not
prove the stronger promise.

This does not require a new universal RPC protocol. Reuse the actual remote
owner's supported contract. If no such contract exists, keep the limitation
visible in the selected profile and return refresh/unavailable/replan outcomes
according to the consumer's existing policy.

### Caching is not a revision lease

**Released protocol.** Cacheable results carry TTL and public/private scope.
Private results cannot be shared across authorization contexts. TTL is a
freshness hint; data may change sooner. List-change notifications invalidate
cached results, but the protocol's list pagination still has no cross-page
snapshot consistency: duplicates or gaps can occur during changes. Restarting
the enumeration is the documented recovery advice, not a guaranteed transaction
under continuous mutation. [M3]

**Design consequence.** Separate catalog refresh from invocation admission.
Authorization must be applied by the executing owner even if a tool was recently
listed. A model-context snapshot is a host-level consistency choice; it should
not be advertised as a lease granted by MCP.

Modern list-change notifications require an opted-in subscriptions stream, an
acknowledged filter and subscription identity. After stdio reconnection,
subscriptions must be established again. Such notification routing is useful
for eventual refresh; it does not define installation, active-call migration
or a total ordering of deployment revisions. [M4]

### Explicit state is more portable than connection identity

**Documented guidance.** The tools page describes explicit opaque handles for
state spanning calls. For authenticated servers, a handle names state and the
server should check authorization on every use. The handle's lifetime and
expiry behavior belong to the tool contract; a handle is not a protocol-level
session. [M1]

**Related contract.** In multi-round-trip requests, the initial invocation ends
and a retry uses a different JSON-RPC request ID. The server owns the opaque
requestState interpretation and integrity checks. The protocol explicitly says
integrity, principal and expiry checks alone do not guarantee single use;
a server requiring that invariant enforces it. [M6]

**Inference.** A deployment change between those requests is a real compatibility
boundary. The receiving owner must understand the retained state, route to an
appropriate implementation or reject it explicitly. A local generation manager
must not treat the retry as continuation of one still-running JavaScript stack.
This is a useful template for universally reusable plugin designs: explicit
application state can outlive disposable execution, but its schema, authorization,
single-use rules and migration retain one responsible owner.

## 3. A concrete SDK falsifier, without claiming an upstream incident

**Pinned source observation.** The current TypeScript SDK call handler obtains a
RegisteredTool object, awaits its input validation, invokes that object's current
executor, then validates and projects output using that object's current schema.
The public update operation mutates the same object's input schema, executor
and output schema. [S1]

The inspected integration tests for ordinary callback update and schema update
both update the tool before connecting the transport and making the call.
They are positive evidence for sequential mutation, not evidence for
mutation during an active validation or handler. This statement concerns those
located tests; it is not an exhaustive claim that no related upstream test
exists. None of the tests was executed here. [S2]

**Proposed falsifier, not reproduced defect:**

1. Register a tool whose old input validation can pause on a controlled barrier.
2. Start a request and observe that validation entered under revision 1.
3. Update input schema, callback and output schema to revision 2 while it waits.
4. Release validation and record the actual validator, executor and result-schema
   revisions used.
5. Repeat with a barrier inside the old handler before output validation.

The source suggests a possible mixed tuple. A real reproduction must exercise
the SDK's accepted validator and wire-dispatch path, preserve the exact dependency
cohort and establish which update guarantees upstream actually promises.
Do not label this a security vulnerability, confirmed bug or production failure
from source reading alone.

**Architectural consequence independent of that test's outcome:** when our
own boundary promises coherence, capture the full immutable operation record
before the first asynchronous gap. Include output interpretation as well as
input schema and executor. Do not claim a shallow frozen record makes captured
mutable application state immutable. Dynamic registration and coherent
in-flight execution are separately testable promises.

## 4. Effect removes mechanics, but its observable lifetime must stay native

GM's current integration builds verified closed compositions as native Layers.
Its README explicitly distinguishes native operation lifetimes from returning a
service or lazy stream after the providing scope has ended. The existing
private lifecycle kernel separately accounts for phases, admitted calls and
custody; it does not perform I/O or physical cleanup. Those source blobs remain
unchanged from the prior study. [G1], [G2]

**A useful refinement from Effect 4.1.4:** RcRef's default last-borrow release
awaits resource finalization. For a non-invalidated resource, a finite
idleTimeToLive, including zero, schedules cleanup in a separate fiber; the
releasing scope does not await that deferred cleanup. An explicitly infinite
TTL retains the idle non-invalidated resource until invalidation or owner-scope
closure. Invalidated resources follow the immediate awaited path.
The RcRef owning scope still has its own finalizer; borrower retention does not
permit closing that owner early. [E1], [E2]

This makes a small, concrete Liskov question: does an adapter result mean
"this borrower released," "cleanup was scheduled," or "owned finalizers
completed"? Preserve the real meaning rather than normalizing every backend
into a stronger Promise<void> receipt. Native Effect types and causes can remain
on the opted-in native boundary.

A no-new-package recipe remains plausible for a single already-owned Effect
application. Native scopes/RcRef cover physical borrowing; the existing owner
covers protected selection and policy; the admitted optional kernel can cover
its distinct accounting facts. The kernel is still private. Do not deep-import
it into an external example and call that proof of an installable public
library. [G3]

The neutral-library alternative becomes justified only if a remaining
coordination invariant is genuinely reusable and separately qualified.
New counters, a new graph compiler or another independently advancing Host do
not become necessary just because the mechanism is exposed as a library.

## 5. Four architecture counterexamples

| Attractive shortcut | Concrete failure in this study | Better ownership boundary |
| --- | --- | --- |
| One Plugin object mandates tool, UI, state-migration, shutdown and cancellation hooks | Native code, remote tools and pure descriptors cannot satisfy the same lifecycle postconditions | Consumer-owned capability contracts and explicitly qualified execution profiles; interfaces only where alternatives are real |
| A universal manager owns loading, desired revision, auth, routing, resource count and recovery | It duplicates GM, kernel, native scope and consumer Host authority; disagreement becomes another failure mode | One selection owner invokes reusable mechanism; adapters report observations without granting themselves authority |
| Freeze a descriptor array and retain the client function, then advertise pinned remote calls | MCP list pages can span changes and tools/call does not name the expected remote generation | Server-supported affinity or an honest current-remote profile with explicit change handling |
| Every close or released Scope returns the same "fully disposed" receipt | Worker exit, released borrower and deferred RcRef finalization are distinct observations | Narrow postconditions per supported profile; no successful no-op implementation of a stronger contract |

These are practical Clean Architecture, SOLID and DRY checks. They do not demand
classes, an interface per function, a new generic repository or a directory
template. DRY is achieved by one owner for the same invariant, while different
runtime guarantees can legitimately require different adapters.

## 6. Testable ordinary external consumer

Use the already proposed independent document server as a design discriminator.
It replaces a renderer behind its own narrow document contract. Its first
qualification should establish:

- It supplies already selected factories or endpoints without Agent Teams
  credentials, catalog storage or session types. No composition graph is
  required when the application has none.
- A local operation holds one selected contract/executor record and its owned
  resources for the actual work interval. A streaming result extends that
  interval through consumption/finalization, not merely handle return.
- A remote implementation only receives the stronger generation claim when
  its server-side contract proves it. A locally captured request function is
  explicitly insufficient.
- Candidate failure and stale completion do not silently select a new revision.
  Exactly one existing owner makes the selection.
- Current authorization and retirement policy can reject later work even when
  an object or state handle still exists.
- Documentation identifies the exact supported cleanup observation and
  retained-resource bound; overload behavior does not secretly choose forced
  interruption.

This is an acceptance design, not a built example or existing adopter.
Qualification must use ordinary public entrypoints or an explicitly admitted
packed candidate, and independently authored observations. Copying a product
fixture and renaming its identifiers is inadequate evidence of portability.

## 7. Six future falsifiers that can change the choice

| Scenario | Decisive observation | Decision it informs |
| --- | --- | --- |
| Old model schema and same-name remote tool across deployment | Calls either reach an explicitly bound compatible revision or return the declared change outcome; a client snapshot alone never claims pinning | Whether remote generation affinity is a supported profile at all |
| Mutation while SDK validation or output work waits | Record which revision validated input, executed and interpreted output; reject a false coherent-tuple claim | Whether the existing registration API can sit directly on the promised boundary or needs an owner-controlled immutable record |
| Paginated catalog mutates, notification disconnects, authorization changes | No invented snapshot guarantee or cross-authorization private cache reuse; reconnection/re-enumeration handles staleness explicitly | Scope of catalog adapter promises and model-context refresh |
| Entry URL changes while a dependency or native addon remains old | Loader reports the actual controlled cohort; it never certifies full replacement from a root query alone | Loader profile and need for a separately disposable environment |
| Worker exits while a main-thread delegated effect is still pending | Execution exit, call settlement and external effect uncertainty remain separately observable | Executor adapter postconditions and existing custody integration |
| Ordinary document consumer plus materially different resource backend | No product imports or duplicated selection/refcount owner; honest support for unsupported or deferred cleanup | Whether a new neutral package has a real residual contract; otherwise deliver a qualified recipe |

These are proposed discriminators, not an instruction to build a broad new test
platform. Existing successful evidence should be reused for unchanged inputs.
A selected first slice needs only the falsifiers that can change its design.

## 8. Alternatives and scope of the estimate

The existing study's bounded alternatives still hold: qualified recipe,
Effect-native coordination, or a small neutral coordinator with one ordinary
execution implementation. The new evidence does not justify a larger universal
Host. A remote-versioning contract, persistent state migration or native-addon
update profile is outside the earlier in-process LOC estimates; those costs
must not be silently included in a few-hundred-line claim.

The earlier P/I/T ranges and confidence/complexity judgments are retained as
planning judgments for their original scope, not re-estimated or newly validated
by this source review. Portability must be proven in the first delivery of a
demonstrated shared concern; it should not be deferred until product-specific
copies accumulate.

## Proposed precision for the prior report

A narrow current addendum can preserve historical evidence while saying:

> Capturing descriptor and executor together is a qualified local-cohort
> invariant. If the captured executor is an RPC client, it captures the local
> client implementation, not necessarily the remote tool revision. A stronger
> cross-process promise needs a server-supported generation-affine endpoint
> or checked version contract. Ordinary MCP tools/call does not supply that
> guarantee by itself; unsupported profiles keep refresh, unavailable or
> replan behavior explicit.

The all-plugin vision remains useful: every category should have an explicit
update path, declared continuity boundary and observable outcome. It cannot
honestly mean that every arbitrary extension can replace its code, state and
dependencies while every current operation continues unchanged.

## References

[N1]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/lib/internal/modules/esm/loader.js
[N2]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/lib/internal/modules/esm/module_map.js
[N3]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/lib/internal/modules/esm/resolve.js
[N4]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/doc/api/esm.md
[N5]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/doc/api/worker_threads.md
[N6]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/lib/internal/worker.js
[N7]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/doc/api/addons.md
[N8]: https://github.com/nodejs/node/blob/e9c277643b0249c50f6e6de5413be8a88ea11b6a/doc/api/modules.md
[J1]: https://tc39.es/ecma262/2026/multipage/ordinary-and-exotic-objects-behaviours.html#sec-module-namespace-exotic-objects-get-p-receiver
[J2]: https://tc39.es/ecma262/2026/multipage/ecmascript-language-scripts-and-modules.html#sec-getmodulenamespace
[M1]: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/docs/specification/2026-07-28/server/tools.mdx
[M2]: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/schema/2026-07-28/schema.ts
[M3]: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/docs/specification/2026-07-28/server/utilities/caching.mdx
[M4]: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/docs/specification/2026-07-28/basic/patterns/subscriptions.mdx
[M5]: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/docs/specification/2026-07-28/basic/versioning.mdx
[M6]: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/de3550c9fea3c5269e42ac95204eef44a2b2cb92/docs/specification/2026-07-28/basic/patterns/mrtr.mdx
[S1]: https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/packages/server/src/server/mcp.ts
[S2]: https://github.com/modelcontextprotocol/typescript-sdk/blob/919bb8ea88b6e10e72c2f8b6218fad4cfdc40b2c/test/integration/test/server/mcp.test.ts
[E1]: https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/RcRef.ts
[E2]: https://github.com/Effect-TS/effect/blob/289a53f7b1fc40049219c6e69022db2fb859c356/packages/effect/src/internal/rcRef.ts
[G1]: https://github.com/agent-teams-ai/get-modular/blob/33c032f829028967825428bc6b049ed6db1c56b2/packages/effect/README.md
[G2]: https://github.com/agent-teams-ai/get-modular/blob/33c032f829028967825428bc6b049ed6db1c56b2/packages/lifecycle-kernel/src/features/lifecycle/kernel.ts
[G3]: https://github.com/agent-teams-ai/get-modular/blob/33c032f829028967825428bc6b049ed6db1c56b2/packages/lifecycle-kernel/package.json

