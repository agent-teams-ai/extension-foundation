# Independent critique, round 2 — portable boundary lane

Observation date: 2026-11-17. Reviewer: portable boundary specialist.
No governed files were edited. No new broad research or runtime execution was
performed.

## Exact inputs and verdict

Initial frozen input:
`review-inputs/root-round2.md`

Initial root draft SHA256:
`a3f6beeb0b2d9b2944c7c241e1429b75143ae484ea3cbdefc3bf574156bbd2f3`

Final verified root draft:
`docs/research/live-plugin-evolution-final-research-and-architecture-2026-11-17.md`

Final root draft SHA256:
`a02bef6a417ed109654c733f5bd7ae67aa141f0c7127f5269cfc515d81a10552`

Prior-report clarification reviewed at SHA256:
`2ad43f7c1d1471938ed6ccdc378455df3b94a730bdd51131bc981feb0bf588df`

**Verdict: PASS for the reviewed source/contract and ownership scope.**
No material finding remains open after the bounded correction below. This is
not runtime conformance, publication approval, a selected interruption policy
or a replacement for the root's final documentation/CI gates.

## Round-1 dispositions

- **PB-R1-01 closed:** finite TTL is now explicitly limited to non-invalidated
  resources. Invalidation follows the awaited final-release path. The RcRef
  owning scope is also distinguished as another lifetime boundary.
- **PB-R1-02 closed:** Felix's STARTING condition now preserves the supported
  lazy-activation exception; STOPPING remains rejected.
- **PB-R1-03 addressed:** exact SDK implementation, inspected sequential tests
  and standard request schema links were added near their claims. Protected
  acquisition explicitly binds the input/output contract with its executor.

## One narrow round-2 correction, now verified

**PB-R2-01, P2, closed.** The first round-2 wording said "With no finite TTL".
That phrase also describes an explicit infinite TTL. In the already inspected
Effect 4.1.4 `release` branch, an infinite idle TTL retains a non-invalidated idle
resource instead of awaiting cleanup at final borrower release.

Root changed the phrase to:

"When `idleTimeToLive` is omitted, or after invalidation, the final borrower's
release awaits cleanup."

I re-read the resulting paragraph and independently compared the final
document with the frozen round-2 input. This phrase is the sole root-document
difference between the two verified hashes above. The original frozen review
input remains intact. The correction matches the same public RcRef contract
and implementation already pinned in this lane; no new experiment was needed.

## Confirmation of important boundaries

- MCP local schema/client capture does not promise remote executor pinning.
  Stronger behavior needs a server-supported binding; refresh/rejection/
  replanning remain explicit when that contract is unavailable.
- The narrow clarification in the preceding portable-mechanism report makes
  the same boundary explicit. Its diff adds navigation and clarification;
  it does not relabel original experiment results or change the archive.
- The SDK overlap concern remains an **unexecuted falsifier**. Sequential
  upstream test inspection is not presented as a fresh runtime result.
- Node root-import identity, dependency cohort, escaped references, native
  cleanup and worker exit are kept distinct. No universal unload, suspended
  stack migration or hostile isolation promise was introduced.
- GM's lifecycle kernel is still private. Public external usability requires
  qualified entrypoints or a separately admitted packed candidate, not private
  deep imports.
- Selection, policy, composition, physical resource lifetime, durable state and
  custody preserve their named existing owners. The design adds no independent
  Host, second graph resolver, duplicated native refcount or competing state
  authority.
- Golem's stronger source-revision guard is now scoped to snapshot-assisted
  recovery; the text no longer attaches those fields to plain automatic replay.
  This is consistent with the supplied durable/root source disposition; this
  lane did not perform another Golem implementation audit.
- Ordinary-update interruption stays OPEN. A timeout, overload response,
  retained object or compatible method signature does not silently select it.
- Cost bands remain for the named in-process scope and explicitly exclude the
  new remote/state/migration obligations. Documentation quality is not promoted
  into production capacity evidence.

## Own lane synchronization before archive

The lane report and source ledger were tightened consistently:

- The RcRef paragraph now directly qualifies finite TTL with non-invalidated
  resources and states the explicit infinite-TTL retention case.
- The source ledger's E1 claim carries the same distinction.
- The M5 source locator now uses the exact existing heading
  `Protocol Version Negotiation`, with `Terminology`, rather than approximate
  heading names.

Final lane report SHA256:
`b1179376dc23216fdff0a9ec640c9927e19afc0ec148ecace433d53cce93a013`

Final lane source-ledger SHA256:
`9b1451f70ef6dc1209781b51904f016f02a4709cfb038e154aaf986bc43bfd47`

These are bounded documentation precision changes. They add no runtime result,
adoption decision or new source qualification claim.

