import assert from "node:assert/strict";
import { assemblyFor, group } from "@get-modular/assembly";
import type { SemanticCapabilities } from "../upstream/semantic/src/composition/semantic.root.js";
import { runnerAModule } from "../upstream/semantic/src/features/runner/composition/runner-a.module.js";
import { sessionGroup } from "../upstream/semantic/src/features/session/composition/session.group.js";
import { identityInput, journalInput } from "../upstream/semantic/src/features/session/composition/session.inputs.js";
import { sessionModule } from "../upstream/semantic/src/features/session/composition/session.module.js";
import { runnerBModule } from "../upstream/semantic/tests/features/runner/runner-b.module.js";

export async function prepareSelection(tag: "A" | "B") {
  const selected = tag === "A" ? runnerAModule : runnerBModule;
  const preparation = await assemblyFor<SemanticCapabilities>().prepare({
    // Same profile identity: the digest must distinguish actual selected providers.
    profileId: "qualification/static-restart",
    modules: [group("runner", [selected]), sessionGroup],
    roots: { session: sessionModule },
    inputs: { identity: identityInput, journal: journalInput },
  });
  if (preparation.status !== "prepared") throw preparation.error;
  assert.equal(preparation.status, "prepared");
  return preparation;
}
