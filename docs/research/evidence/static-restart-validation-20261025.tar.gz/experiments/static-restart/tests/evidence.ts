import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, readdir, realpath, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../../", import.meta.url));
const sourceRoot = resolve(root, "../../repos/get-modular");
async function inventory(directory: string, relative = ""): Promise<{ path: string; bytes: number; sha256: string }[]> {
  const result: { path: string; bytes: number; sha256: string }[] = [];
  for (const entry of (await readdir(join(directory, relative), { withFileTypes: true })).toSorted((a, b) => a.name.localeCompare(b.name, "en"))) {
    const path = join(relative, entry.name);
    if (entry.isDirectory()) result.push(...await inventory(directory, path));
    else {
      assert.ok(entry.isFile(), `Unexpected file kind: ${path}`);
      const data = await readFile(join(directory, path));
      result.push({ path, bytes: data.byteLength, sha256: createHash("sha256").update(data).digest("hex") });
    }
  }
  return result;
}
const upstream = await inventory(join(root, "upstream"));
for (const item of upstream) {
  const original = await readFile(join(sourceRoot, "tests/qualification/consumer-fixtures", item.path));
  assert.equal(createHash("sha256").update(original).digest("hex"), item.sha256, item.path);
}
const packages: Record<string, unknown> = {};
for (const name of ["core", "assembly", "resources", "conformance"]) {
  const directory = await realpath(join(root, "node_modules/@get-modular", name));
  const manifest: unknown = JSON.parse(await readFile(join(directory, "package.json"), "utf8"));
  const entries = (await inventory(directory)).filter(row => !row.path.startsWith("node_modules/"));
  packages[name] = { manifest, entries, inventorySha256: createHash("sha256").update(JSON.stringify(entries)).digest("hex") };
}
const nodeTypes = JSON.parse(await readFile(join(root, "node_modules/@types/node/package.json"), "utf8")) as { version: string };
const compiler = JSON.parse(await readFile(join(root, "node_modules/typescript/package.json"), "utf8")) as { version: string };
const files = [...await inventory(join(root, "tests"))];
const identity = {
  observedAt: new Date().toISOString(), node: process.version, platform: process.platform, arch: process.arch,
  sourceCommit: execFileSync("git", ["rev-parse", "HEAD"], { cwd: sourceRoot, encoding: "utf8" }).trim(),
  sourceDirty: execFileSync("git", ["status", "--porcelain"], { cwd: sourceRoot, encoding: "utf8" }).trim(),
  upstreamFiles: upstream, upstreamCopiedBytesMatch: true, packages,
  nodeTypes: nodeTypes.version, typescript: compiler.version,
  lockfileSha256: createHash("sha256").update(await readFile(join(root, "pnpm-lock.yaml"))).digest("hex"),
  addedSourceFiles: files,
};
await writeFile(join(root, "results/identities.json"), JSON.stringify(identity, null, 2) + "\n");
console.log(JSON.stringify({ node: identity.node, sourceCommit: identity.sourceCommit, sourceDirty: identity.sourceDirty,
  upstreamFiles: upstream.length, upstreamCopiedBytesMatch: true, typescript: compiler.version, packages: Object.keys(packages) }));
