import assert from "node:assert/strict";
import { randomUUID, createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { createAttempt } from "../upstream/semantic/tests/support/attempt-owner.js";
import { createFileJournal } from "../upstream/semantic/tests/support/journal.js";
import { prepareSelection } from "./selection.js";

const tag = process.argv[2];
assert.ok(tag === "A" || tag === "B", "Select one known, statically imported author provider.");
const identity = randomUUID();
const preparation = await prepareSelection(tag);
await using journal = await createFileJournal();
await using attempt = createAttempt(preparation.prepared, identity, journal);
assert.equal(await attempt.ready, true);
const values: string[] = [];
for (const id of ["first", "second"]) {
  values.push(await attempt.run({ id, payload: " hello ", signal: attempt.signal }));
}
const close = await attempt.stop();
assert.equal(close.complete, true);
await assert.rejects(journal.probe(), { code: "EBADF" });
const source = tag === "A"
  ? new URL("../upstream/semantic/src/features/runner/composition/runner-a.module.js", import.meta.url)
  : new URL("../upstream/semantic/tests/features/runner/runner-b.module.js", import.meta.url);
console.log(JSON.stringify({ pid: process.pid, identity, tag, values, close,
  digest: preparation.composition.digest,
  selected: preparation.composition.plan.selections,
  providerBytesSha256: createHash("sha256").update(await readFile(source)).digest("hex"),
  records: await journal.read(),
}));
