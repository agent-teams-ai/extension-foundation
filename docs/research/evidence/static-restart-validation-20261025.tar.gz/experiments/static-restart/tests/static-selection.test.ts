import assert from "node:assert/strict";
import test from "node:test";
import { assemblyFor, declareModule, defineContract, group, implement } from "@get-modular/assembly";
import { compileComposition } from "@get-modular/core";
import type { SemanticCapabilities } from "../upstream/semantic/src/composition/semantic.root.js";
import { runnerADeclaration } from "../upstream/semantic/src/features/runner/composition/runner-a.declaration.js";
import { runnerAModule } from "../upstream/semantic/src/features/runner/composition/runner-a.module.js";
import { identityDeclaration } from "../upstream/semantic/src/features/session/composition/identity.declaration.js";
import { journalDeclaration } from "../upstream/semantic/src/features/session/composition/journal.declaration.js";
import { sessionDeclaration } from "../upstream/semantic/src/features/session/composition/session.declaration.js";
import { sessionGroup } from "../upstream/semantic/src/features/session/composition/session.group.js";
import { identityInput, journalInput } from "../upstream/semantic/src/features/session/composition/session.inputs.js";
import { sessionModule } from "../upstream/semantic/src/features/session/composition/session.module.js";
import type { RunnerPort } from "../upstream/semantic/src/features/session/contracts/session.js";
import { runnerBModule } from "../upstream/semantic/tests/features/runner/runner-b.module.js";
import { runnerBDeclaration } from "../upstream/semantic/tests/features/runner/runner-b.declaration.js";
import { createAttempt } from "../upstream/semantic/tests/support/attempt-owner.js";
import { createFileJournal } from "../upstream/semantic/tests/support/journal.js";
import { prepareSelection } from "./selection.js";

const watchdog = { timeout: 10000 };

test("S-01 author provider selection changes real effects while a constructed A keeps its references", watchdog, async context => {
  const a = await prepareSelection("A");
  const before = JSON.stringify(a.composition);
  assert.ok(Object.isFrozen(a.composition.plan));
  assert.ok(Object.isFrozen(a.composition.plan.selections));
  await using aJournal = await createFileJournal();
  await using aRun = createAttempt(a.prepared, "old-a", aJournal);
  assert.equal(await aRun.ready, true);
  assert.equal(await aRun.run({ id: "before", payload: "hello", signal: aRun.signal }), "old-a:A:hello");
  const b = await prepareSelection("B");
  assert.notDeepEqual(a.composition.digest, b.composition.digest);
  await using bJournal = await createFileJournal();
  await using bRun = createAttempt(b.prepared, "new-b", bJournal);
  assert.equal(await bRun.ready, true);
  assert.equal(await bRun.run({ id: "new", payload: "hello", signal: bRun.signal }), "new-b:B:hello");
  assert.equal(await aRun.run({ id: "after", payload: "hello", signal: aRun.signal }), "old-a:A:hello");
  assert.equal(JSON.stringify(a.composition), before);
  assert.deepEqual((await aJournal.read()).filter(row => row.kind === "effect").map(row => row.value), ["old-a:A:hello", "old-a:A:hello"]);
  assert.deepEqual((await bJournal.read()).filter(row => row.kind === "effect").map(row => row.value), ["new-b:B:hello"]);
  assert.equal((await aRun.stop()).complete, true);
  assert.equal((await bRun.stop()).complete, true);
  context.diagnostic(JSON.stringify({ aDigest: a.composition.digest, bDigest: b.composition.digest, capturedReferencesStable: true }));
});

test("S-02 missing, ambiguous and duplicate graph entries fail preparation before author acquisition", watchdog, async context => {
  const api = assemblyFor<SemanticCapabilities>();
  let factoryInvocations = 0;
  // These author factory sentinels fail if preparation attempts executable work.
  // Their real declarations are the unchanged current consumer declarations.
  const attemptedEffect = async (): Promise<never> => {
    factoryInvocations += 1;
    throw new Error("Preparation invoked an author factory.");
  };
  const a = implement<SemanticCapabilities>()(runnerADeclaration, attemptedEffect);
  const b = implement<SemanticCapabilities>()(runnerBDeclaration, attemptedEffect);
  const root = implement<SemanticCapabilities>()(sessionDeclaration, attemptedEffect);
  const configurations = [
    { name: "missing", modules: [root] as const, expected: "assembly.prepare.unresolved-binding" },
    { name: "ambiguous", modules: [group("providers", [a, b]), root] as const, expected: "assembly.prepare.unresolved-binding" },
    { name: "duplicate", modules: [a, a, root] as const, expected: "assembly.prepare.duplicate-module" },
  ];
  for (const configuration of configurations) {
    const result = await api.prepare({ profileId: "qualification/rejected", modules: configuration.modules,
      roots: { session: root }, inputs: { identity: identityInput, journal: journalInput } });
    assert.equal(result.status, "failed");
    if (result.status !== "failed") throw new Error("An invalid graph prepared.");
    assert.equal(result.error.code, configuration.expected);
    context.diagnostic(JSON.stringify({ row: configuration.name, code: result.error.code }));
  }
  assert.equal(factoryInvocations, 0, "Every rejected preparation precedes all author factory invocation.");
});

test("S-03 exact revision conflict is rejected by public Core before any Assembly execution", watchdog, async context => {
  const revision2 = defineContract<RunnerPort>()({ id: "fixture/session/runner", revision: 2 });
  const declaration = declareModule({ moduleId: runnerADeclaration.moduleId,
    implementationId: runnerADeclaration.implementationId, owner: runnerADeclaration.owner,
    slots: runnerADeclaration.slots, provides: [revision2.provide()] });
  const declarations = [declaration, sessionDeclaration, identityDeclaration, journalDeclaration];
  const result = await compileComposition({ declarations, profile: {
    kind: "get-modular.composition-profile", schemaVersion: 1, profileId: "qualification/revision-conflict",
    roots: [sessionDeclaration.moduleId],
    selections: declarations.map(({ moduleId, implementationId }) => ({ moduleId, implementationId })),
    bindings: [
      { consumerImplementationId: runnerADeclaration.implementationId, slotId: "journal", providerImplementationIds: [journalDeclaration.implementationId] },
      { consumerImplementationId: sessionDeclaration.implementationId, slotId: "identity", providerImplementationIds: [identityDeclaration.implementationId] },
      { consumerImplementationId: sessionDeclaration.implementationId, slotId: "journal", providerImplementationIds: [journalDeclaration.implementationId] },
      { consumerImplementationId: sessionDeclaration.implementationId, slotId: "runner", providerImplementationIds: [runnerADeclaration.implementationId] },
    ],
  } });
  assert.equal(result.ok, false);
  if (result.ok) throw new Error("Incompatible revision compiled.");
  assert.ok(result.diagnostics.some(row => row.code === "binding.compatibility-mismatch"));
  context.diagnostic(JSON.stringify({ diagnostics: result.diagnostics }));
});
