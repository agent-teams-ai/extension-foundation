import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readdir, writeFile } from "node:fs/promises";
import { setImmediate } from "node:timers/promises";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { Supervisor } from "../upstream/recovery/src/supervisor.js";
import { makeSubmission, SUCCESS } from "../upstream/recovery/src/schema.js";

const watchdog = { timeout: 60000 };
const resultUrl = new URL("../../results/", import.meta.url);
const fdCount = async () => (await readdir("/proc/self/fd")).length;
// The environment does not expose procfs's task children file (failed attempts retained).
// Claims below cover only the exact directly owned PID/exit observations and parent FDs.
const isObject = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null;

test("S-04 sequential A/B/A process restart uses immutable provider bytes with fresh incarnation and no live predecessor", watchdog, async context => {
  assert.equal(process.platform, "linux", "Linux /proc evidence requires actual Linux execution.");
  const receipts: Record<string, unknown>[] = [];
  const fdSamples: number[] = [];
  const before = await fdCount();
  for (const tag of ["A", "B", "A", "B", "A", "B", "A", "B", "A", "B", "A", "B"] as const) {
    const child = spawnSync(process.execPath, [fileURLToPath(new URL("selection-child.js", import.meta.url)), tag], {
      encoding: "utf8", timeout: 10000, killSignal: "SIGKILL", maxBuffer: 1024 * 1024,
      env: { ...process.env, NODE_PATH: "", NODE_OPTIONS: "", NODE_TEST_CONTEXT: undefined },
    });
    assert.equal(child.error, undefined, String(child.error));
    assert.equal(child.signal, null);
    assert.equal(child.status, 0, child.stderr);
    const receipt: unknown = JSON.parse(child.stdout.trim());
    assert.ok(isObject(receipt));
    assert.equal(receipt.pid, child.pid);
    assert.equal(receipt.tag, tag);
    assert.equal(typeof receipt.identity, "string");
    assert.deepEqual(receipt.values, [`${receipt.identity}:${tag}:hello`, `${receipt.identity}:${tag}:hello`]);
    assert.deepEqual(receipt.close, { complete: true, settled: true, debts: [] });
    assert.ok(Array.isArray(receipt.records));
    const effects = receipt.records.filter((row: unknown) => isObject(row) && row.kind === "effect");
    assert.equal(effects.length, 2, "Two independent actual author effects precede child exit.");
    assert.throws(() => process.kill(child.pid, 0), { code: "ESRCH" });
    await setImmediate();
    fdSamples.push(await fdCount());
    receipts.push(receipt);
  }
  assert.equal(new Set(receipts.map(row => row.identity)).size, 12);
  for (const tag of ["A", "B"]) {
    const selected = receipts.filter(row => row.tag === tag);
    assert.equal(new Set(selected.map(row => row.providerBytesSha256)).size, 1, "Restored old provider bytes remain identical.");
    assert.equal(new Set(selected.map(row => JSON.stringify(row.digest))).size, 1, "Content identity is stable across fresh incarnations.");
  }
  assert.notDeepEqual(receipts[0]?.digest, receipts[1]?.digest);
  assert.ok(Math.max(...fdSamples) <= before + 2, JSON.stringify({ before, fdSamples }));
  const result = { scope: "Linux parent-owned sequential one-shot processes", before, fdSamples, receipts };
  await writeFile(new URL("selection-process-cycles.json", resultUrl), JSON.stringify(result, null, 2) + "\n");
  context.diagnostic(JSON.stringify({ cycles: 12, identities: 12, before, fdSamples,
    exactOwnedPidsAbsent: true, completeChildInventory: "unavailable-procfs-children" }));
});

test("S-05 unchanged recovery fixture joins each worker exit before 24 fresh starts; no automatic respawn", watchdog, async context => {
  assert.equal(process.platform, "linux");
  await using supervisor = await Supervisor.create("record-only");
  const before = await fdCount();
  const observations: { cycle: number; pid: number; grant: string; descriptors: number; ownedPidAbsent: boolean }[] = [];
  const grants = new Set<string>();
  const canonical = await supervisor.store.read();
  for (let cycle = 0; cycle < 24; cycle += 1) {
    const worker = await supervisor.start();
    assert.equal(grants.has(worker.grant), false);
    grants.add(worker.grant);
    const restored = (await worker.status()).snapshot;
    assert.equal(restored.generation, canonical.generation, "Durable fixture identity is distinct from execution incarnation.");
    assert.deepEqual(restored.records, []);
    await worker.stop();
    await assert.rejects(worker.submit(makeSubmission()), { code: "fixture.worker.exited" });
    assert.throws(() => process.kill(worker.pid, 0), { code: "ESRCH" });
    await setImmediate();
    assert.equal(supervisor.events.filter(row => row.kind === "worker-ready").length, cycle + 1);
    assert.equal(supervisor.events.filter(row => row.kind === "worker-exit").length, cycle + 1);
    observations.push({ cycle, pid: worker.pid, grant: worker.grant, descriptors: await fdCount(), ownedPidAbsent: true });
  }
  assert.ok(Math.max(...observations.map(row => row.descriptors)) <= before + 2, JSON.stringify({ before, observations }));
  assert.deepEqual(supervisor.counts(), { grants: 24, launches: 0, handshakes: 0, exits: 0, occupied: 0, reserved: false });
  const result = { scope: "Linux public existing test Supervisor, no work dispatched", before, observations,
    liveResourceBound: "each known worker PID absent, parent FD count within baseline+2",
    completeChildInventory: "UNQUALIFIED: environment has no procfs task children file",
    referenceBound: "NOT CLAIMED: unchanged fixture retains historical worker connections/events" };
  await writeFile(new URL("recovery-worker-cycles.json", resultUrl), JSON.stringify(result, null, 2) + "\n");
  context.diagnostic(JSON.stringify({ cycles: 24, uniqueGrants: grants.size, before,
    fdSamples: observations.map(row => row.descriptors), referenceBound: "not-claimed" }));
});

test("S-06 accepted work naturally settles and its effect exits before old writer stop and fresh readback", watchdog, async context => {
  await using supervisor = await Supervisor.create("record-only");
  const first = await supervisor.start();
  const operation = makeSubmission();
  assert.equal((await first.submit(operation)).created, true);
  await supervisor.wait("effect-held");
  assert.equal(supervisor.counts().occupied, 1);
  await assert.rejects(supervisor.start(), { code: "fixture.writer.occupied" });
  await assert.rejects(first.submit(makeSubmission("no-queue")), { code: "fixture.operation.overloaded" });
  await supervisor.complete(operation);
  const terminal = await supervisor.wait("terminal", row => row.workerPid === first.pid);
  assert.equal(terminal.record?.result, SUCCESS);
  const effect = await supervisor.observeEffectExit(operation);
  assert.equal(effect.result, SUCCESS);
  assert.equal(effect.child.exited, true);
  assert.equal(effect.child.code, 0);
  assert.equal(effect.child.signal, null);
  await first.settle();
  await first.stop();
  const firstExit = supervisor.events.findIndex(row => row.kind === "worker-exit" && row.workerPid === first.pid);
  assert.ok(firstExit >= 0);
  const fresh = await supervisor.start();
  assert.notEqual(fresh.grant, first.grant);
  const newReady = supervisor.events.findIndex(row => row.kind === "worker-ready" && row.workerPid === fresh.pid);
  assert.ok(newReady > firstExit);
  assert.deepEqual(await fresh.query(operation), terminal.record);
  assert.equal((await fresh.submit(operation)).created, false);
  await fresh.settle();
  assert.equal(supervisor.counts().launches, 1, "Readback/duplicate after restart must not re-execute accepted work.");
  await fresh.stop();
  context.diagnostic(JSON.stringify({ firstPid: first.pid, freshPid: fresh.pid, terminal: terminal.record,
    oldWriterExitIndex: firstExit, freshReadyIndex: newReady, naturalWorkBeforeExit: true,
    forceStopUsed: false, events: supervisor.events }));
});
