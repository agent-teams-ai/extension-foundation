# Static composition and controlled restart qualification plan

Date: 2026-10-25. This is a disposable qualification fixture, not a production
Host, supervisor, kernel, RPC implementation or reusable lifecycle package.

## Real components

- Get Modular's public Core, Assembly, Resources and Conformance package roots.
- The unchanged current Get Modular semantic consumer and recovery consumer
  fixture sources, copied under `upstream/` and inventoried by relative filename,
  source commit and SHA-256 before execution.
- Real Node child processes, file descriptors, file writes, file synchronization,
  rename, IPC, signals and exit observations in the existing recovery fixture.
- Narrow additional ordinary TypeScript tests/one-shot child composition using
  the existing consumer's author declarations, module factories and resources.

The existing fixture Supervisor is test-only and remains the sole owner of its
real sibling handles. No second supervisor/RPC/Host/kernel is introduced.

## Hypotheses and falsifiers

| Hypothesis | Falsifier / decisive observation |
| --- | --- |
| Author-supplied compatible A/B modules can be selected in a static graph | Wrong provider output, selected declaration or actual effect identity |
| Invalid/conflicting preparation precedes factory effects | Journal acquire/effect entry or factory invocation from rejected prepare |
| A prepared graph and capability objects keep their identity | Existing A graph becomes B after preparation of another graph |
| Sequential full process restart restores an immutable selection with a fresh incarnation | Old process remains, reused incarnation, wrong plan/provider/source hash |
| Stop closes admission and settles accepted work before resource release in the existing semantic policy | New work enters after stop; cleanup precedes accepted terminal recording |
| Durable records do not invent live custody or safe retries after loss | Unknown claimed work re-executes, stale grant launches, or live sibling slot disappears |
| Failed startup and failed cleanup retain truthful ownership | Failed spawn grants capacity incorrectly; close/debt report is treated as physical release |
| Repeated restarts remain bounded in the exercised disposable scope | A live old PID or persistent descriptor growth beyond the stated bound |

## Adversarial matrix and budgets

1. Run existing strict semantic module/lifetime/workload E2E unchanged.
2. Run existing strict recovery E2E unchanged, both `record-only` and
   `restart-pending` profiles: acceptance/claim/terminal crash windows,
   duplicate/conflicting operation identities, capacity-one/no-queue,
   live cancellation/late success, lost acknowledgement, live sibling custody,
   cleanup debt/retry, worker/effect spawn failure and failed canonical writes.
3. Add static A/B selection, ambiguity/missing/revision conflict before effects,
   immutable prepared graph and one-shot process restart identity observations.
4. Add 24 sequential existing recovery worker restart cycles and 12 one-shot
   static provider process cycles. Observe Linux `/proc` descriptors and PID
   absence; use exact process exit as the required retirement boundary.

Each test has a deadline; deadlines are observation bounds, not benchmarks.
No production queue is promised. Existing live policy rejects overload, while
`restart-pending` recovers only unclaimed durable pending work.

## Scope limits

This is local Linux execution under the owner's exact Node/TypeScript pins,
strict typechecking with dependency declarations checked. The fixture has no
PostgreSQL persistence, product authorization, public plugin SPI admission,
Agent Runtime production custody adapter, trusted readiness implementation,
durable routing authority or distributed coordinator. File snapshot tests do
not adopt file persistence. It does not qualify power-loss durability, full
custody-owner crash, descendant process containment, untrusted native plugins,
Windows/macOS, production traffic or thousands of simultaneously live plugins.

Controlled restart may be unavailable between incarnations. These tests do not
promise overlap, transparent session migration or forced successful completion
of accepted work. Cancellation, terminal result, resource close, process exit
and external artifact deletion remain separate observations.
