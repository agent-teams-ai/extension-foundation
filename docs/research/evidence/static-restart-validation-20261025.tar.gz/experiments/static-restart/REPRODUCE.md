# Reproduce the static/restart qualification

This is an isolated external public-package consumer, not a Get Modular source
checkout. It declares pnpm 11.18.0. The current Get Modular repository requires
pnpm 11.20.0; these commands do not install or build that repository.

Use Node **26.11.1**, pnpm **11.18.0**, TypeScript **7.0.2** and the committed
exact lockfile. The original session used
`/tmp/plugin-validation-toolchain-20261025/bin` for Node/pnpm. From this directory:

```sh
export PATH=/tmp/plugin-validation-toolchain-20261025/bin:$PATH
NODE_USE_ENV_PROXY=1 pnpm install --frozen-lockfile --ignore-scripts --store-dir /tmp/plugin-static-pnpm-store-20261025
node --version
pnpm --version
pnpm exec tsc --version
pnpm typecheck
pnpm build
pnpm test:existing
pnpm test:added
pnpm test:stop-admission
```

**Expected current outcome:** strict typecheck/build pass; unchanged inherited
suite reports 60 passed / 0 failed; added positive suite reports 6 passed /
0 failed; `test:stop-admission` reports **2 failed** (one per recovery profile). `pnpm check` includes that
required rejecting row and must remain red until the owning admission boundary
is actually fixed. There is no passing aggregate claim.

The failing row deterministically holds a real child launch acknowledgement,
starts stop, observes physical child exit, then submits new work while stop is
still in flight. The existing fixture incorrectly accepts/persists that work.
The test releases the barrier and joins physical shutdown, starts a fresh worker,
and observes the accepted record's disposition before failing. `record-only`
retains it pending without dispatch even after a duplicate submit;
`restart-pending` resumes it to a successful real child result. Neither trace
shows durable record loss.

The one-shot provider child can also be called directly:

```sh
node out/tests/selection-child.js A
node out/tests/selection-child.js B
node out/tests/selection-child.js A
```

Each receipt reports real module results, effect records, exact content digest,
fresh UUID, provider emitted-byte hash, and cooperative close. Process exit is
observed separately by the calling tests. This is finite one-shot graph
execution, not a persistent Host replacement service.

`node out/tests/evidence.js` verifies the 47 copied `upstream/` files against
`../../repos/get-modular/tests/qualification/consumer-fixtures` at the exact
recorded source revision and inventories installed public package bytes. It
intentionally fails if that source checkout is unavailable or differs. The
frozen inventory in `results/identities.json` is usable independently of that
live source-audit command. Package acquisition is registry-resolved and bound
by the lockfile's distribution integrities; this experiment does not verify
npm signature/attestation trust.

## Execution restrictions and retained failures

The original sandbox denied default pnpm store creation and network requests;
an explicit disposable store and the platform's reviewed network execution
route were used. It also returned `spawnSync git EPERM`; identity capture and
direct process qualification ran through the reviewed execution route.

Linux procfs did not expose `/proc/self/task/<tid>/children`, even after resolving
its native PID instead of the sandbox namespace PID and running outside the
sandbox. Failed attempts and the namespace probe remain in `logs/`. Consequently
complete child/descendant enumeration is **unqualified**. The final positive
tests cover exact owned-child exit, known-PID `ESRCH`, absence of implicit worker
ready events and parent-process FD counts. They do not silently substitute those
observations for descendant containment, memory bounds or complete process-tree
absence.

The final observations are in `logs/existing-expanded.log`,
`logs/added-after-scope-correction.log`, and
`logs/stop-admission-with-recovery.log`. The earlier single-profile failing trace
is in `logs/stop-admission-counterexample.log`; earlier failure logs remain verbatim.
