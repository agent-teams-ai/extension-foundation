# Optional Temporal adapter experiment

Read the complete report at `../../reports/temporal-adapter-e2e.md`. This is disposable component evidence, not a production plugin Host or a rollout implementation.

## Retained inputs and outputs

- `PLAN.md`: scope, real components, falsifiers and budgets stated before execution.
- `authority/pr90-2026-10-25.json`: live primary PR90 state and full contemporaneous PR body.
- `upstream/`: unchanged PR90 source/config and retained historical evidence from exact head `0af892165a023a274302f89b47ba514ab2915e59`.
- `fixture/`: narrow added strict TypeScript receiver/adapter/evidence harness. Native bootstrap, PostgreSQL asset adapter and Temporal initializer are unchanged copies from PR90.
- `results/baseline/`: actual local unchanged native fixture result/logs/config,11 assertion scenarios plus a resource observation.
- `results/adapter/`: actual added real-stack result,7 scenario groups, raw histories, native summary and ordinary-with-no-service probe.
- `results/adapter-attempt-1/`: genuine first added-stack failure, not a pass.
- `logs/`: strict typechecking, independent physical oracle, baseline attempts, dependency correction and attempted-action ledger.
- `source-manifest.json`: exact source/lock/shared static-child hashes and native PostgreSQL executable hash.

All runtime credentials are omitted from retained evidence. Redacted server configs retain every other setting. Local ports are fixture-only loopback endpoints; temporal-server frontend27233 and its existing service/membership ports must be free. The bootstrap chooses an independent PostgreSQL port and creates a new temporary cluster.

## Reproduction

Use Node 26.11.1, pnpm 11.18.0 and the exact checked-in lock. This run used the complete shared toolchain at `/tmp/plugin-validation-toolchain-20261025/bin`. On a normal non-root machine run directly; this container required the existing uid/gid65534 with `setpriv`, task-only ownership changes, and the approved tool network/process boundary. Never create an OS account or touch another cluster.

```bash
export PATH=/tmp/plugin-validation-toolchain-20261025/bin:$PATH
pnpm install --frozen-lockfile
pnpm exec tsc -p tsconfig.json
```

First build the adjacent static-restart experiment with its exact lock/toolchain and `pnpm run build`. Its unchanged `out/tests/selection-child.js` and relative compiled fixtures are required; do not replace the child with a fake function. Copy the built `out` tree to a task execution root as `static-selection`, with this experiment's dependencies available from an ancestor. The exact shared inputs from the measured run are in the source manifest.

Unchanged baseline, from a task execution root containing this directory and dependencies:

```bash
NODE_USE_ENV_PROXY=1 \
SPIKE_OUTPUT_DIR=/tmp/plugin-temporal-e2e-20261025/baseline-results \
setpriv --reuid=65534 --regid=65534 --clear-groups \
node --import tsx upstream/scripts/research/od035/bootstrap/run-native.ts temporal
```

Added adapter matrix, after the baseline has stopped its owned components:

```bash
NODE_USE_ENV_PROXY=1 \
SPIKE_OUTPUT_DIR=/tmp/plugin-temporal-e2e-20261025/adapter-results-2 \
STATIC_SELECTION_CHILD=/tmp/plugin-temporal-e2e-20261025/static-selection/tests/selection-child.js \
setpriv --reuid=65534 --regid=65534 --clear-groups \
node --import tsx fixture/bootstrap/run-native.ts temporal
```

Each native invocation downloads and verifies official Temporal1.32.1 native artifacts and matching source schemas, initializes a disposable native PostgreSQL cluster, runs real service/Workers and stops the cluster. It fails closed if a required native component is missing. Keep outputs in a fresh directory on every attempt. The exact observed commands and environmental failures are in the attempt ledger and report.

Validate captured physical results and the ordinary-call boundary after the native suite has stopped:

```bash
node --import tsx fixture/verify-evidence.ts results/adapter/results.json
STATIC_SELECTION_CHILD=/tmp/plugin-temporal-e2e-20261025/static-selection/tests/selection-child.js \
node --import tsx fixture/offline-ordinary.ts
```

The last probe requires an unavailable service port; a timeout or an unexpected live service fails rather than being treated as absence. Run through the same unprivileged process boundary when using this container.

## Ownership and interpretation

The80-line SQL receiver is test-owned application authority for this disposable scenario. It does not copy a lifecycle kernel or claim production authorization, canonical-generation or physical-custody conformance. The28-line physical bridge invokes an existing finite GM child as repeatable preflight, records its actual values/effects/digest/identity and observed exit, then calls the receiver. A stale command may still perform that harmless preflight; it accepts no canonical application mutation. External side effects and a long-lived active Host require their own owned fencing and reconciliation.

The baseline and added 7-group suite are separate executions. Historical hosted macOS/Windows results in `upstream/docs/...` are retained source evidence and were not locally rerun. No product release, active-plugin scale, installer, upgrade, restore, or lifecycle custody adoption is claimed.
