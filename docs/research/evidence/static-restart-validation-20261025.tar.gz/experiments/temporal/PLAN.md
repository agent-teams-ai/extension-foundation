# Optional Temporal replacement adapter qualification

## Authority and scope

Current primary source: Orchestrator PR90, exact head `0af892165a023a274302f89b47ba514ab2915e59`; owner-approved accepted ADR0116 selects full native Temporal Service + PostgreSQL for Fully Local V1. PR90 is open and unmerged. Main still has historical unresolved OD035 text. This experiment does not reopen product engine selection. A purpose-neutral plugin update/restart mechanism may use an optional Temporal coordinator; ordinary plugin invocations remain ordinary calls.

## Real components and limits

Reuse unchanged native bootstrap and full Temporal/PostgreSQL fixture from PR90. Actual Temporal Server 1.32.1 and matching SQL migration tool, TypeScript SDK 1.24.0, embedded-postgres18.4.0-beta.17 PostgreSQL binaries, pg8.23.1, tsx 4.21.0, TypeScript 7.0.2. No Docker, SQLite dev server, fake Temporal service, fake Worker, or in-memory business database. Task-owned loopback endpoints/processes only. Workflow state owns scheduling progress; PostgreSQL rows/receipts/epochs are the fixture's application authority.

The added adapter experiment uses a narrow test-only update-operation command port and real SDK Activity dispatch, not a new plugin runtime. It does not implement physical resource custody, a generation kernel, real Host admission/drain, Dapr/NATS/AR transports, or production authorization. Exact source/config/artifact identities and every failed attempt are retained.

## Hypotheses and useful falsifiers

1. A real full-service baseline can recover durable scheduling from Worker and service death. Failure to replay, or a second timer/effect, rejects this baseline.
2. One stable operation/command identity retains one application effect after commit-before-ack Worker death and duplicate delivery. More than one effect or changed command payload acceptance rejects receipt semantics.
3. A delayed old Activity after the scheduler epoch changes must be rejected by the receiving application command transaction. Temporal timeout alone is insufficient. A stale accepted mutation rejects integration.
4. Abrupt coordinator Worker loss must recover the same operation from engine history and application state. A new competing operation/authority rejects recovery.
5. Ordinary plugin invocation must remain executable while the workflow Worker is absent. A dependency on a workflow task for ordinary invocation rejects this adapter boundary.

## Budgets

Single Linux x64 task-owned stack; finite Activity retries, bounded four Activity/four Workflow execution slots in reused baseline, database Worker pool max4. Per-scenario observation bounds up to60 seconds; baseline includes80 parked waits but claims no active-plugin scale or throughput. New cases target deterministic commit/epoch boundaries. macOS/Windows new scenarios are not locally executable and will be reported as such. Historical hosted CI remains separate.

## Anticipated evidence

Unchanged full native fixture run, then narrow update/restart operation suite with lost acknowledgement, duplicate command, current/reused operation identity, receiver epoch rejection, Worker/service recovery, and ordinary invocation during coordinator unavailability. Any unavailable real component fails closed. Scores and LOC will distinguish narrow adapter evidence from production integration and release qualification.

## Postexecution budget clarification

The readiness/boundary polls have explicit60-second bounds and Activities have finite retry budgets. Inspection after the successful run identified that every Workflow `result()` await does not have its own enclosing wallclock deadline. The observed invocations finished, but the pre-execution phrase “per-scenario observation bounds up to60 seconds” must not be read as a fully enforced universal timeout. Future CI should put the whole owned process group under a declared job/process timeout and preserve cleanup debt on expiry. This clarification does not relabel a timeout as success or change the executed source.
