import { existsSync, writeFileSync } from 'node:fs';
import { setTimeout as delay } from 'node:timers/promises';
import * as receiver from './receiver.ts';
import { executeUpdate } from './bridge.ts';
import { output } from './paths.ts';
import type { UpdateCommand } from './types.ts';

export async function updateSelection(command: UpdateCommand) {
  if (process.env.PAUSE_OPERATION === command.operationId) {
    writeFileSync(output(`paused-${command.operationId}.json`), JSON.stringify({ pid: process.pid, command, boundary: 'before receiver SQL transaction' }));
    while (!existsSync(output(`release-${command.operationId}`))) { await delay(50); }
  }
  const result = await executeUpdate(command);
  const marker = output(`committed-${command.operationId}.json`);
  if (process.env.CRASH_AFTER_COMMIT_OPERATION === command.operationId && !existsSync(marker)) {
    writeFileSync(marker, JSON.stringify({ pid: process.pid, command, result, boundary: 'after durable application COMMIT before Activity acknowledgement' }));
    process.kill(process.pid, 'SIGKILL');
  }
  return result;
}

export async function readSelection(scope: string) { return receiver.evidence(scope); }
