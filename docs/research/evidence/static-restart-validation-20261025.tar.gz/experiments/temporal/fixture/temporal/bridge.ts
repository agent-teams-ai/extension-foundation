import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import type { Candidate, UpdateCommand } from './types.ts';
import * as receiver from './receiver.ts';

export function constructCandidate(candidate: Candidate): Record<string, unknown> {
  const child = process.env.STATIC_SELECTION_CHILD;
  if (child === undefined) { throw new Error('Real static-selection child is required'); }
  const outcome = spawnSync(process.execPath, [child, candidate], { encoding: 'utf8', timeout: 10_000, env: { ...process.env, NODE_OPTIONS: '' } });
  assert.equal(outcome.status, 0, outcome.stderr);
  assert.equal(outcome.signal, null);
  const value: unknown = JSON.parse(outcome.stdout);
  assert.ok(typeof value === 'object' && value !== null && 'pid' in value && typeof value.pid === 'number');
  assert.ok('tag' in value && value.tag === candidate && 'close' in value && typeof value.close === 'object' && value.close !== null && 'complete' in value.close && value.close.complete === true);
  const pid = value.pid;
  assert.throws(() => process.kill(pid, 0), { code: 'ESRCH' });
  return { ...value, observedExit: { status: outcome.status, signal: outcome.signal, absentAfterReap: true } };
}

// The same narrow test-owned usecase is called directly and by an Activity.
// Construction is a repeatable preflight. It is not a physical switch receipt.
export async function executeUpdate(command: UpdateCommand) {
  await receiver.noteDelivery(command);
  if (!await receiver.hasReceipt(command)) {
    await receiver.noteConstruction(command, constructCandidate(command.candidate));
  }
  return receiver.applySelection(command);
}
