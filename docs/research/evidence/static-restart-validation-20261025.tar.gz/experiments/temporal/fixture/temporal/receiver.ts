import { createHash } from 'node:crypto';
import { Pool } from 'pg';
import type { CommandResult, UpdateCommand } from './types.ts';

// Disposable application receiver, not production ownership or a lifecycle kernel.
export const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 4 });
const schema = 'plugin_update_fixture';
const digest = (command: UpdateCommand) => createHash('sha256').update(JSON.stringify({ operationId: command.operationId, scope: command.scope, candidate: command.candidate })).digest('hex');

export async function migrate(): Promise<void> {
  await pool.query(`CREATE SCHEMA ${schema};
    CREATE TABLE ${schema}.selection(scope text PRIMARY KEY, scheduler_epoch integer NOT NULL, candidate text NOT NULL, effects integer NOT NULL DEFAULT 0);
    CREATE TABLE ${schema}.operations(operation_id text PRIMARY KEY, scope text NOT NULL, payload_digest text NOT NULL, candidate text NOT NULL);
    CREATE TABLE ${schema}.receipts(command_id text PRIMARY KEY, operation_id text NOT NULL, payload_digest text NOT NULL, candidate text NOT NULL, effects integer NOT NULL);
    CREATE TABLE ${schema}.deliveries(id bigserial PRIMARY KEY, operation_id text NOT NULL, scheduler_epoch integer NOT NULL, worker_pid integer NOT NULL);
    CREATE TABLE ${schema}.constructions(id bigserial PRIMARY KEY, operation_id text NOT NULL, evidence jsonb NOT NULL);`);
}

export async function createScope(scope: string): Promise<void> {
  await pool.query(`INSERT INTO ${schema}.selection VALUES($1,1,'A',0)`, [scope]);
}

export async function submitOperation(command: UpdateCommand): Promise<void> {
  await pool.query(`INSERT INTO ${schema}.operations VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`, [command.operationId, command.scope, digest(command), command.candidate]);
  const operation = await pool.query<{ payload_digest: string }>(`SELECT payload_digest FROM ${schema}.operations WHERE operation_id=$1`, [command.operationId]);
  if (operation.rows[0]?.payload_digest !== digest(command)) { throw new Error('operation identity conflict'); }
}

export async function noteDelivery(command: UpdateCommand): Promise<void> {
  await pool.query(`INSERT INTO ${schema}.deliveries(operation_id,scheduler_epoch,worker_pid) VALUES($1,$2,$3)`, [command.operationId, command.schedulerEpoch, process.pid]);
}

export async function hasReceipt(command: UpdateCommand): Promise<boolean> {
  return (await pool.query(`SELECT 1 FROM ${schema}.receipts WHERE command_id=$1`, [`select:${command.operationId}`])).rowCount === 1;
}

export async function noteConstruction(command: UpdateCommand, evidence: unknown): Promise<void> {
  await pool.query(`INSERT INTO ${schema}.constructions(operation_id,evidence) VALUES($1,$2::jsonb)`, [command.operationId, JSON.stringify(evidence)]);
}

export async function applySelection(command: UpdateCommand): Promise<CommandResult> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const operation = await client.query<{ payload_digest: string }>(`SELECT payload_digest FROM ${schema}.operations WHERE operation_id=$1`, [command.operationId]);
    if (operation.rows[0]?.payload_digest !== digest(command)) { throw new Error('operation identity conflict'); }
    const selection = await client.query<{ scheduler_epoch: number; candidate: 'A' | 'B'; effects: number }>(`SELECT * FROM ${schema}.selection WHERE scope=$1 FOR UPDATE`, [command.scope]);
    const current = selection.rows[0];
    if (current === undefined) { throw new Error('unknown scope'); }
    const receipt = await client.query<{ payload_digest: string; candidate: 'A' | 'B'; effects: number }>(`SELECT * FROM ${schema}.receipts WHERE command_id=$1`, [`select:${command.operationId}`]);
    const accepted = receipt.rows[0];
    let result: CommandResult;
    if (accepted !== undefined) {
      if (accepted.payload_digest !== digest(command)) { throw new Error('command identity conflict'); }
      result = { outcome: 'replayed', candidate: accepted.candidate, canonicalEffects: accepted.effects };
    } else if (current.scheduler_epoch !== command.schedulerEpoch) {
      result = { outcome: 'stale', candidate: current.candidate, canonicalEffects: current.effects };
    } else {
      const nextEffects = current.effects + 1;
      await client.query(`INSERT INTO ${schema}.receipts VALUES($1,$2,$3,$4,$5)`, [`select:${command.operationId}`, command.operationId, digest(command), command.candidate, nextEffects]);
      await client.query(`UPDATE ${schema}.selection SET candidate=$2,effects=$3 WHERE scope=$1`, [command.scope, command.candidate, nextEffects]);
      result = { outcome: 'applied', candidate: command.candidate, canonicalEffects: nextEffects };
    }
    await client.query('COMMIT');
    return result;
  } catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}

export async function advanceEpoch(scope: string): Promise<void> {
  await pool.query(`UPDATE ${schema}.selection SET scheduler_epoch=scheduler_epoch+1 WHERE scope=$1`, [scope]);
}

export async function evidence(scope: string) {
  const selection = await pool.query(`SELECT * FROM ${schema}.selection WHERE scope=$1`, [scope]);
  const receipts = await pool.query(`SELECT * FROM ${schema}.receipts WHERE operation_id IN (SELECT operation_id FROM ${schema}.operations WHERE scope=$1) ORDER BY command_id`, [scope]);
  const deliveries = await pool.query(`SELECT * FROM ${schema}.deliveries WHERE operation_id IN (SELECT operation_id FROM ${schema}.operations WHERE scope=$1) ORDER BY id`, [scope]);
  const constructions = await pool.query(`SELECT * FROM ${schema}.constructions WHERE operation_id IN (SELECT operation_id FROM ${schema}.operations WHERE scope=$1) ORDER BY id`, [scope]);
  return { selection: selection.rows, receipts: receipts.rows, deliveries: deliveries.rows, constructions: constructions.rows };
}
