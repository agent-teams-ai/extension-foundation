export type Candidate = 'A' | 'B';
export type UpdateCommand = { operationId: string; scope: string; candidate: Candidate; schedulerEpoch: number };
export type CommandResult = { outcome: 'applied' | 'replayed' | 'stale'; candidate: Candidate; canonicalEffects: number };
