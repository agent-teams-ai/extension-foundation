import { proxyActivities, sleep } from '@temporalio/workflow';
import type * as activities from './activities.ts';
import type { UpdateCommand } from './types.ts';

const activity = proxyActivities<typeof activities>({ startToCloseTimeout: '30s', retry: { initialInterval: '1s', maximumInterval: '2s', maximumAttempts: 3 } });
export async function updateOperation(command: UpdateCommand) { return activity.updateSelection(command); }
export async function delayedUpdate(input: { command: UpdateCommand; waitMs: number }) {
  await sleep(input.waitMs);
  return activity.updateSelection(input.command);
}
