import assert from 'node:assert/strict';
import { spawn, type ChildProcess } from 'node:child_process';
import { closeSync, existsSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { setTimeout as delay } from 'node:timers/promises';
import { Client, Connection, WorkflowExecutionAlreadyStartedError } from '@temporalio/client';
import Long from 'long';
import { initialize, nativeBinary } from './initialize.ts';
import { output, sourceDir } from './paths.ts';
import { constructCandidate, executeUpdate } from './bridge.ts';
import * as receiver from './receiver.ts';
import type { UpdateCommand } from './types.ts';
import type { updateOperation, delayedUpdate } from './workflows-v1.ts';

const namespace = 'plugin-update-fixture';
const queue = 'plugin-update-fixture';
const prefix = `plugin-${Date.now()}`;
const processes = new Set<ChildProcess>();
const scenarios: Record<string, unknown> = {};
const result: Record<string, unknown> = { fixture: 'optional Temporal update-operation adapter', engine: 'full native Temporal service', server: '1.32.1', sdk: '1.24.0', node: process.version, platform: process.platform, arch: process.arch, startedAt: new Date().toISOString(), testOwnedReceiver: true, releaseQualification: false, scenarios };
let connection: Connection | undefined;
let client: Client;
let service: ChildProcess;

function record(name: string, evidence: unknown): void {
  scenarios[name] = evidence;
  writeFileSync(output('results.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ scenario: name, evidence }));
}

async function until(predicate: () => Promise<boolean> | boolean, label: string, timeout = 60_000): Promise<void> {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) { if (await predicate()) { return; } await delay(50); }
  throw new Error(`Timed out: ${label}`);
}

function launch(program: string, args: string[], log: string, env: Record<string, string> = {}): ChildProcess {
  const fd = openSync(output(log), 'w');
  const child = spawn(program, args, { cwd: sourceDir, env: { ...process.env, ...env }, stdio: ['ignore', fd, fd] });
  closeSync(fd);
  processes.add(child);
  child.once('exit', () => processes.delete(child));
  return child;
}

async function kill(child: ChildProcess): Promise<{ pid: number | undefined; code: number | null; signal: NodeJS.Signals | null }> {
  if (child.exitCode === null && child.signalCode === null) {
    const exited = new Promise<void>(resolve => child.once('exit', () => resolve()));
    child.kill('SIGKILL');
    await exited;
  }
  if (child.pid !== undefined) { assert.throws(() => process.kill(child.pid!, 0), { code: 'ESRCH' }); }
  return { pid: child.pid, code: child.exitCode, signal: child.signalCode };
}

async function startServer(): Promise<void> {
  service = launch(nativeBinary('temporal-server'), ['--config-file', output('server-config.private.json'), '--allow-no-auth', 'start'], `server-${Date.now()}.log`);
  await until(async () => {
    try {
      const probe = await Connection.connect({ address: '127.0.0.1:27233', connectTimeout: '500ms' });
      await probe.workflowService.getSystemInfo({}); await probe.close(); return true;
    } catch { return false; }
  }, 'full native service readiness');
}

async function startWorker(env: Record<string, string> = {}, taskQueue = queue): Promise<ChildProcess> {
  const log = `worker-${taskQueue}-${Date.now()}.log`;
  const child = launch(process.execPath, ['--import', 'tsx', 'worker.ts'], log, { ...env, TASK_QUEUE: taskQueue });
  await until(() => existsSync(output(log)) && readFileSync(output(log), 'utf8').includes('"ready":true'), 'real SDK Worker readiness');
  return child;
}

function command(scope: string, name: string, candidate: 'A' | 'B' = 'B', schedulerEpoch = 1): UpdateCommand {
  return { scope, operationId: `${scope}-${name}`, candidate, schedulerEpoch };
}

async function ensureWorkflow(value: UpdateCommand, taskQueue = queue) {
  const workflowId = `${value.operationId}-epoch-${value.schedulerEpoch}`;
  try {
    return await client.workflow.start<typeof updateOperation>('updateOperation', { workflowId, taskQueue, args: [value] });
  } catch (error) {
    if (!(error instanceof WorkflowExecutionAlreadyStartedError)) { throw error; }
    return client.workflow.getHandle<typeof updateOperation>(workflowId);
  }
}

async function normalAndDuplicateScenarios(): Promise<void> {
  const scope = `${prefix}-sequence`;
  await receiver.createScope(scope);
  for (const [index, candidate] of (['A', 'B', 'A'] as const).entries()) {
    const value = command(scope, String(index), candidate);
    await receiver.submitOperation(value);
    assert.equal((await (await ensureWorkflow(value)).result()).outcome, 'applied');
  }
  const sequence = await receiver.evidence(scope);
  assert.equal(sequence.selection[0]?.candidate, 'A');
  assert.equal(sequence.selection[0]?.effects, 3);
  assert.equal(sequence.receipts.length, 3);
  assert.equal(sequence.constructions.length, 3);
  record('workflowActivityToExistingGMChildAtoBtoA', { pass: true, evidence: sequence, physicalMeaning: 'Three finite one-shot compositions with observed natural exit. SQL command acceptance is separate from physical receipts; no long-lived active Host replacement is asserted.' });

  const duplicateScope = `${prefix}-duplicate`;
  await receiver.createScope(duplicateScope);
  const duplicate = command(duplicateScope, 'stable');
  await receiver.submitOperation(duplicate);
  // Real start succeeds; test intentionally discards its response before retry.
  const first = await ensureWorkflow(duplicate);
  const repeated = await ensureWorkflow(duplicate);
  await repeated.result();
  const firstDescription = await first.describe();
  const repeatedDescription = await repeated.describe();
  assert.equal(firstDescription.runId, repeatedDescription.runId);
  assert.equal((await executeUpdate(duplicate)).outcome, 'replayed');
  await assert.rejects(receiver.submitOperation({ ...duplicate, candidate: 'A' }), /identity conflict/);
  await assert.rejects(receiver.applySelection({ ...duplicate, candidate: 'A' }), /identity conflict/);
  const duplicateEvidence = await receiver.evidence(duplicateScope);
  assert.equal(duplicateEvidence.selection[0]?.effects, 1);
  assert.equal(duplicateEvidence.receipts.length, 1);
  assert.equal(duplicateEvidence.constructions.length, 1);
  const history = await repeated.fetchHistory();
  writeFileSync(output('duplicate-history.json'), JSON.stringify(history, null, 2));
  record('lostStartResponseDuplicateCommandAndPayloadConflict', { pass: true, injection: 'Discarded actual successful start response, then retried same workflow ID; no network partition claimed.', runId: firstDescription.runId, evidence: duplicateEvidence });

  const directScope = `${prefix}-direct`;
  await receiver.createScope(directScope);
  const direct = command(directScope, 'shared-port');
  await receiver.submitOperation(direct);
  assert.equal((await executeUpdate(direct)).outcome, 'applied');
  assert.equal((await (await ensureWorkflow(direct)).result()).outcome, 'replayed');
  const directEvidence = await receiver.evidence(directScope);
  assert.equal(directEvidence.selection[0]?.effects, 1);
  assert.equal(directEvidence.receipts.length, 1);
  record('directAndTemporalUseSameApplicationReceiver', { pass: true, evidence: directEvidence, limitation: 'Test-owned narrow receiver and ephemeral GM preflight. This is optional-adapter substitutability, not product admission/authority conformance.' });
}

async function commitGapScenario(worker: ChildProcess): Promise<ChildProcess> {
  await kill(worker);
  const scope = `${prefix}-commit-gap`;
  await receiver.createScope(scope);
  const value = command(scope, 'stable');
  await receiver.submitOperation(value);
  const crashing = await startWorker({ CRASH_AFTER_COMMIT_OPERATION: value.operationId });
  const handle = await ensureWorkflow(value);
  await until(() => existsSync(output(`committed-${value.operationId}.json`)), 'actual application COMMIT marker');
  await until(() => crashing.exitCode !== null || crashing.signalCode !== null, 'Worker SIGKILL');
  const afterCrash = await receiver.evidence(scope);
  assert.equal(afterCrash.receipts.length, 1);
  assert.equal(afterCrash.selection[0]?.effects, 1);
  const replacement = await startWorker();
  assert.equal((await handle.result()).outcome, 'replayed');
  const recovered = await receiver.evidence(scope);
  assert.ok(recovered.deliveries.length >= 2);
  assert.equal(recovered.receipts.length, 1);
  assert.equal(recovered.selection[0]?.effects, 1);
  assert.equal(recovered.constructions.length, 1);
  record('workerDeathAfterReceiverCommitBeforeActivityAck', { pass: true, workerExit: await kill(crashing), afterCrash, recovered, physicalMeaning: 'Preflight child naturally exited before commit; retry read receipt and did not construct it again. Does not prove exactly-once external effects.' });
  return replacement;
}

async function staleEpochScenario(): Promise<void> {
  const scope = `${prefix}-epoch`;
  await receiver.createScope(scope);
  const old = command(scope, 'stable');
  await receiver.submitOperation(old);
  const staleQueue = `${prefix}-stale`;
  const paused = await startWorker({ PAUSE_OPERATION: old.operationId }, staleQueue);
  const handle = await ensureWorkflow(old, staleQueue);
  await until(() => existsSync(output(`paused-${old.operationId}.json`)), 'Activity reached boundary before receiver transaction');
  assert.equal(paused.kill('SIGSTOP'), true);
  await receiver.advanceEpoch(scope);
  const beforeRelease = await receiver.evidence(scope);
  assert.equal(beforeRelease.selection[0]?.scheduler_epoch, 2);
  assert.equal(beforeRelease.receipts.length, 0);
  writeFileSync(output(`release-${old.operationId}`), 'release');
  assert.equal(paused.kill('SIGCONT'), true);
  assert.equal((await handle.result()).outcome, 'stale');
  const afterDelayedActivity = await receiver.evidence(scope);
  assert.equal(afterDelayedActivity.selection[0]?.effects, 0);
  assert.equal(afterDelayedActivity.receipts.length, 0);
  await kill(paused);
  const current = { ...old, schedulerEpoch: 2 };
  assert.equal((await (await ensureWorkflow(current)).result()).outcome, 'applied');
  const recovered = await receiver.evidence(scope);
  assert.equal(recovered.selection[0]?.effects, 1);
  assert.equal(recovered.receipts.length, 1);
  record('delayedActualActivityRejectedAfterSchedulerEpochChange', { pass: true, beforeRelease, afterDelayedActivity, recovered, enforcement: 'Same PostgreSQL receiver transaction locks canonical selection, validates command binding, then compares scheduler epoch before inserting receipt/updating selection.', physicalMeaning: 'Old epoch still may perform repeatable preflight construction; stale authority accepts no canonical application mutation.' });
}

async function serviceRecoveryAndBypass(worker: ChildProcess): Promise<void> {
  const scope = `${prefix}-timer-recovery`;
  await receiver.createScope(scope);
  const value = command(scope, 'durable');
  await receiver.submitOperation(value);
  const handle = await client.workflow.start<typeof delayedUpdate>('delayedUpdate', { workflowId: `${value.operationId}-timer`, taskQueue: queue, args: [{ command: value, waitMs: 3000 }] });
  await until(async () => (await handle.fetchHistory()).events?.some(event => Boolean(event.timerStartedEventAttributes)) === true, 'timer persisted in actual service');
  const workerExit = await kill(worker);
  const before = await connection!.workflowService.listWorkflowExecutions({ namespace, pageSize: 100 });
  const ordinary = constructCandidate('A');
  const after = await connection!.workflowService.listWorkflowExecutions({ namespace, pageSize: 100 });
  assert.equal(after.executions.length, before.executions.length);
  record('ordinaryPublicGMInvocationWhileTemporalWorkerAbsent', { pass: true, workerExit, ordinary, workflowExecutionsBefore: before.executions.length, workflowExecutionsAfter: after.executions.length, sourceBoundary: 'Same existing selection-child public GM composition invokes two ordinary root calls with no Temporal import or scheduling adapter.' });
  const oldService = await kill(service);
  await delay(1000);
  await startServer();
  const replacement = await startWorker();
  assert.equal((await handle.result()).outcome, 'applied');
  const history = await handle.fetchHistory();
  assert.equal(history.events?.filter(event => Boolean(event.timerStartedEventAttributes)).length, 1);
  assert.equal(history.events?.filter(event => Boolean(event.timerFiredEventAttributes)).length, 1);
  const readback = await receiver.evidence(scope);
  assert.equal(readback.receipts.length, 1);
  assert.equal(readback.selection[0]?.effects, 1);
  writeFileSync(output('service-recovery-history.json'), JSON.stringify(history, null, 2));
  record('durableOperationThroughWorkerAndFullServiceDeath', { pass: true, workerExit, oldService, replacementServicePid: service.pid, replacementWorkerPid: replacement.pid, readback, samePostgresCluster: true });
}

try {
  await initialize();
  await receiver.migrate();
  const privateConfig: unknown = JSON.parse(readFileSync(output('server-config.private.json'), 'utf8'));
  writeFileSync(output('server-config.redacted.json'), JSON.stringify(privateConfig, (key, value: unknown) => key === 'password' ? '[redacted]' : value, 2));
  await startServer();
  connection = await Connection.connect({ address: '127.0.0.1:27233' });
  await connection.workflowService.registerNamespace({ namespace, workflowExecutionRetentionPeriod: { seconds: Long.fromNumber(86400) } });
  client = new Client({ connection, namespace });
  let worker = await startWorker();
  await normalAndDuplicateScenarios();
  worker = await commitGapScenario(worker);
  await staleEpochScenario();
  await serviceRecoveryAndBypass(worker);
  result.allExecutedScenariosPassed = true;
  result.completedAt = new Date().toISOString();
} catch (error) {
  result.failure = error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : String(error);
  console.error(error);
  process.exitCode = 1;
} finally {
  for (const child of [...processes]) { child.kill('SIGCONT'); await kill(child); }
  if (connection !== undefined) { await connection.close(); }
  await receiver.pool.end();
  result.ownedServiceAndWorkersReaped = processes.size === 0;
  writeFileSync(output('results.json'), JSON.stringify(result, null, 2));
}
