import { DefaultLogger, NativeConnection, Runtime, Worker } from '@temporalio/worker';
import { resolve } from 'node:path';
import * as activities from './activities.ts';
import { sourceDir } from './paths.ts';

Runtime.install({ logger: new DefaultLogger('WARN') });
const connection = await NativeConnection.connect({ address: '127.0.0.1:27233' });
const worker = await Worker.create({ connection, namespace: 'plugin-update-fixture', taskQueue: process.env.TASK_QUEUE ?? 'plugin-update-fixture', workflowsPath: resolve(sourceDir, 'workflows-v1.ts'), activities, maxConcurrentActivityTaskExecutions: 2, maxConcurrentWorkflowTaskExecutions: 2, shutdownGraceTime: '1s' });
console.log(JSON.stringify({ ready: true, pid: process.pid }));
await worker.run();
