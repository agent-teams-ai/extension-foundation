import assert from 'node:assert/strict';
import { createConnection } from 'node:net';
import { constructCandidate } from './temporal/bridge.ts';

const serviceUnavailable = await new Promise<boolean>((resolve, reject) => {
  const socket = createConnection({ host: '127.0.0.1', port: 27233 });
  socket.setTimeout(2000);
  socket.once('connect', () => { socket.destroy(); reject(new Error('Temporal service unexpectedly available')); });
  socket.once('timeout', () => { socket.destroy(); reject(new Error('Port absence probe timed out; absence unproven')); });
  socket.once('error', error => {
    if ('code' in error && error.code === 'ECONNREFUSED') { resolve(true); }
    else { reject(error); }
  });
});
assert.equal(serviceUnavailable, true);
const physicalReceipt = constructCandidate('A');
assert.ok('identity' in physicalReceipt && typeof physicalReceipt.identity === 'string');
assert.deepEqual(physicalReceipt.values, [`${physicalReceipt.identity}:A:hello`, `${physicalReceipt.identity}:A:hello`]);
console.log(JSON.stringify({ ordinaryPublicGMCallWithNoTemporalService: 'passed', servicePort: 27233, observedPortError: 'ECONNREFUSED', physicalReceipt }, null, 2));
