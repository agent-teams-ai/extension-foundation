import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

// Independent artifact oracle: validate recorded physical outputs, not the bridge's tag alone.
const result: unknown = JSON.parse(readFileSync(process.argv[2] ?? '', 'utf8'));
const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);
assert.ok(isRecord(result) && result.allExecutedScenariosPassed === true);
const hashes = { A: new Set<string>(), B: new Set<string>() };
const digests = { A: new Set<string>(), B: new Set<string>() };
const identities = new Set<string>();
let observedReceipts = 0;
function visit(value: unknown): void {
  if (Array.isArray(value)) { value.forEach(visit); return; }
  if (!isRecord(value)) { return; }
  if ('observedExit' in value && 'values' in value) {
    assert.ok(value.tag === 'A' || value.tag === 'B');
    assert.equal(typeof value.identity, 'string');
    assert.ok(typeof value.providerBytesSha256 === 'string' && /^[0-9a-f]{64}$/.test(value.providerBytesSha256));
    assert.equal(typeof value.digest, 'string');
    assert.deepEqual(value.values, [`${value.identity}:${value.tag}:hello`, `${value.identity}:${value.tag}:hello`]);
    assert.ok(Array.isArray(value.records));
    assert.deepEqual(value.records.filter((row: unknown) => isRecord(row) && row.kind === 'effect').map((row: Record<string, unknown>) => row.value), value.values);
    assert.deepEqual(value.observedExit, { status: 0, signal: null, absentAfterReap: true });
    assert.ok(isRecord(value.close) && value.close.complete === true && value.close.settled === true);
    assert.deepEqual(value.close.debts, []);
    hashes[value.tag].add(value.providerBytesSha256);
    digests[value.tag].add(String(value.digest));
    identities.add(String(value.identity));
    observedReceipts += 1;
  }
  Object.values(value).forEach(visit);
}
visit(result);
assert.ok(identities.size >= 10);
assert.equal(hashes.A.size, 1); assert.equal(hashes.B.size, 1);
assert.equal(digests.A.size, 1); assert.equal(digests.B.size, 1);
assert.notEqual([...hashes.A][0], [...hashes.B][0]);
assert.notEqual([...digests.A][0], [...digests.B][0]);
console.log(JSON.stringify({ independentPhysicalReceiptValidation: 'passed', distinctCompositionIdentities: identities.size, observedReceiptCopies: observedReceipts, providerHashes: { A: [...hashes.A], B: [...hashes.B] }, compositionDigests: { A: [...digests.A], B: [...digests.B] }, interpretation: 'Repeated evidence snapshots are not new physical executions; distinct identities count finite one-shot constructions only.' }, null, 2));
