import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFile, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { runParity } from "./parity.js";

const here = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const roots = Object.fromEntries(["core", "assembly"].map(name =>
  [name, dirname(require.resolve(`@get-modular/${name}`))]));
const importMap = { imports: Object.fromEntries(["core", "assembly"].map(name =>
  [`@get-modular/${name}`, `/vendor/${name}/index.js`])) };
const index = `<!doctype html><title>GM browser parity</title><script type="importmap">${JSON.stringify(importMap)}</script>`;
const serverErrors: string[] = [];
const server = createServer((request, response) => {
  void (async () => {
    const pathname = new URL(request.url ?? "/", "http://127.0.0.1").pathname;
    if (pathname === "/") { response.setHeader("Content-Type", "text/html"); response.end(index); return; }
    if (pathname === "/parity.js") { response.setHeader("Content-Type", "text/javascript"); response.end(await readFile(resolve(here, "parity.js"))); return; }
    const matched = /^\/vendor\/(core|assembly)\/(.+\.js)$/.exec(pathname);
    if (!matched) { response.writeHead(404).end(); return; }
    const root = roots[matched[1]!];
    assert.ok(root);
    const path = resolve(root, matched[2]!);
    assert.ok(path.startsWith(`${root}/`));
    response.setHeader("Content-Type", "text/javascript"); response.end(await readFile(path));
  })().catch(error => { serverErrors.push(String(error)); response.writeHead(500).end(); });
});
await new Promise<void>(resolveListening => server.listen(0, "127.0.0.1", resolveListening));
const address = server.address();
assert.ok(address && typeof address !== "string");
let browser;
try {
  const nodeResult = await runParity();
  browser = await chromium.launch({ executablePath: process.env.QUALIFICATION_CHROME ?? "/tmp/plugin-validation-browsers-20261025/chrome-linux64/chrome",
    headless: true, args: ["--no-sandbox"] });
  const page = await browser.newPage();
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(String(error)));
  await page.goto(`http://127.0.0.1:${address.port}/`);
  const browserResult: unknown = await page.evaluate(async () => {
    // Identical compiled program, no browser-only replacement implementation.
    const loaded = await import("./parity.js");
    return loaded.runParity();
  });
  assert.deepEqual(browserResult, nodeResult);
  assert.deepEqual(errors, []); assert.deepEqual(serverErrors, []);
  const result = { status: "passed", node: process.version, playwright: require("playwright/package.json").version as string,
    chrome: browser.version(), platform: process.platform, arch: process.arch, nodeResult, browserResult,
    note: "Static public package parity only; no browser Host or physical reload/isolation qualification." };
  await writeFile(resolve(here, "../result.json"), `${JSON.stringify(result, null, 2)}\n`);
  console.log(JSON.stringify(result));
} finally {
  await browser?.close();
  await new Promise<void>((resolveClosed, reject) => server.close(error => error ? reject(error) : resolveClosed()));
}
