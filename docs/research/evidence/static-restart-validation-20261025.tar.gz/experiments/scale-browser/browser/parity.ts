import { required } from "@get-modular/core";
import { assemblyFor, declareModule, defineContract, implement, type CapabilitiesOf } from "@get-modular/assembly";

const Message = defineContract<{ read(): string }>()({ id: "qualification/browser/message", revision: 1 });
interface Capabilities extends CapabilitiesOf<typeof Message> {}
function requireCondition(value: unknown, message: string): asserts value {
  if (!value) throw new Error(message);
}

/** One identical public-API program executes in Node and in a real browser. */
export async function runParity() {
  let factoryCalls = 0;
  const declaration = (tag: "a" | "b") => declareModule({
    moduleId: `qualification/browser/${tag}`,
    implementationId: `qualification/browser/${tag}/default`,
    owner: { authority: "qualification", path: ["browser"] },
    provides: [Message.provide()], slots: [],
  });
  const a = implement<Capabilities>()(declaration("a"), async () => {
    factoryCalls += 1;
    const port = { read: () => "A" };
    return { instance: port, capabilities: { "qualification/browser/message": port } };
  });
  const b = implement<Capabilities>()(declaration("b"), async () => {
    factoryCalls += 1;
    const port = { read: () => "B" };
    return { instance: port, capabilities: { "qualification/browser/message": port } };
  });
  const appDeclaration = declareModule({
    moduleId: "qualification/browser/app", implementationId: "qualification/browser/app/default",
    owner: { authority: "qualification", path: ["browser"] },
    provides: [], slots: [Message.slot("message", required())],
  });
  const app = implement<Capabilities>()(appDeclaration, async dependencies => {
    factoryCalls += 1;
    return { instance: { read: () => dependencies.message.read() }, capabilities: {} };
  });
  const api = assemblyFor<Capabilities>();
  const prepare = (provider: typeof a | typeof b) => api.prepare({
    profileId: "qualification/browser-parity", modules: [provider, app], roots: { app },
  });
  const pa = await prepare(a);
  requireCondition(pa.status === "prepared", "A must prepare");
  requireCondition(factoryCalls === 0, "preparation must not invoke factories");
  const immutablePlan = JSON.stringify(pa.composition);
  requireCondition(Object.isFrozen(pa.composition.plan), "plan must be frozen");
  const arun = await pa.prepared.run();
  requireCondition(arun.status === "succeeded", "A must construct");
  requireCondition(arun.roots.app.read() === "A", "A actual invocation");
  const pb = await prepare(b);
  requireCondition(pb.status === "prepared", "B must prepare");
  const brun = await pb.prepared.run();
  requireCondition(brun.status === "succeeded", "B must construct");
  requireCondition(brun.roots.app.read() === "B", "B actual invocation");
  requireCondition(arun.roots.app.read() === "A", "old instance remains A");
  requireCondition(JSON.stringify(pa.composition) === immutablePlan, "old plan is unchanged");
  requireCondition(JSON.stringify(pa.composition.digest) !== JSON.stringify(pb.composition.digest), "provider selection changes digest");
  const again = await prepare(a);
  requireCondition(again.status === "prepared", "A reprepare");
  requireCondition(JSON.stringify(again.composition.digest) === JSON.stringify(pa.composition.digest), "A digest is stable");
  const countBeforeRejections = factoryCalls;
  const diagnostics: string[] = [];
  for (const modules of [[app] as const, [a, b, app] as const, [a, a, app] as const]) {
    const rejected = await api.prepare({ profileId: "qualification/browser-rejected", modules, roots: { app } });
    requireCondition(rejected.status === "failed", "invalid graph must fail preflight");
    diagnostics.push(rejected.error.code);
  }
  requireCondition(factoryCalls === countBeforeRejections, "invalid graphs cause zero factory effects");
  requireCondition(JSON.stringify(diagnostics) === JSON.stringify([
    "assembly.prepare.unresolved-binding", "assembly.prepare.unresolved-binding", "assembly.prepare.duplicate-module",
  ]), "each invalid graph must return its expected public diagnostic");
  requireCondition(Object.is(factoryCalls, 4), "two constructed graphs invoke exactly their provider and root factories");
  const abort = new AbortController();
  abort.abort("already cancelled");
  const cancelled = await pa.prepared.run({ signal: abort.signal });
  requireCondition(cancelled.status === "cancelled", "pre-cancelled construction must stop");
  requireCondition(factoryCalls === countBeforeRejections, "cancelled run invokes zero factories");
  return { status: "passed", groups: 5, aDigest: pa.composition.digest, bDigest: pb.composition.digest,
    values: [arun.roots.app.read(), brun.roots.app.read()], diagnostics, factoryCalls,
    scopes: ["provider substitution and old-reference stability", "immutable plan and stable digest",
      "missing/ambiguous/duplicate fail before effects", "pre-aborted construction", "Node/browser exact result equality"] };
}
