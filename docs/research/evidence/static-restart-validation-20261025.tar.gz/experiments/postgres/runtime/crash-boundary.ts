import assert from 'node:assert/strict';
import {spawn, execFileSync, type ChildProcess} from 'node:child_process';
import {createHash} from 'node:crypto';
import {access, mkdir, mkdtemp, readFile, writeFile} from 'node:fs/promises';
import {dirname, join} from 'node:path';
import {tmpdir} from 'node:os';
import {setTimeout as delay} from 'node:timers/promises';
import {Pool, type PoolClient} from 'pg';
import {createSandboxManifestFeature} from './agent-context/dist/index.js';
import {postgresBinaries} from './postgres-binaries.ts';

const output = process.env.PG_BOUNDARY_OUTPUT ?? '';
assert.ok(output, 'Explicit task-owned evidence output is required');
const root = await mkdtemp(join(tmpdir(), 'crash-'));
const data = join(root, 'data');
const socket = join(root, 'socket');
await mkdir(socket, {mode: 0o700});
const binaries = postgresBinaries();
const bin = dirname(binaries.postgres);
const rows: {name: string; status: string; detail: unknown}[] = [];
const observedErrors: string[] = [];
const events: {pid: number; code: number | null; signal: NodeJS.Signals | null}[] = [];
const summary: Record<string, unknown> = {kind: 'postgres-feature-crash-boundary', releaseQualification: false,
  node: process.version, platform: process.platform, architecture: process.arch, uid: process.getuid?.(),
  source: 'aaabc1e7cd2e2482668530e4412e61c2bca1f515', root, rows, observedErrors, events};
let active: {child: ChildProcess; exited: Promise<void>} | undefined;
let pools: Pool[] = [];
let status = 1;
const errorName = (value: unknown) => value instanceof Error ? value.message : String(value);
const check = (name: string, detail: unknown) => rows.push({name, status: 'passed', detail});
const control = (...args: string[]) => execFileSync(binaries.pgCtl, ['-D', data, ...args],
  {encoding: 'utf8', timeout: 15_000, stdio: 'pipe'});
async function bounded<T>(work: Promise<T>, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try { return await Promise.race([work, new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`Observation bound exceeded: ${label}`)), 10_000);
  })]); } finally { if (timer !== undefined) clearTimeout(timer); }
}
function pool(user: string): Pool {
  const value = new Pool({host: socket, user, database: 'postgres', max: 2, connectionTimeoutMillis: 2000});
  value.on('error', error => observedErrors.push(error.message));
  pools.push(value);
  return value;
}
async function start(): Promise<void> {
  const child = spawn(binaries.postgres, ['-D', data, '-k', socket, '-h', '', '-c', 'fsync=on',
    '-c', 'full_page_writes=on', '-c', 'synchronous_commit=on', '-c', 'max_connections=12'],
  {stdio: ['ignore', 'pipe', 'pipe']});
  assert.ok(child.pid);
  let text = '';
  child.stdout.on('data', (chunk: Buffer) => {text += chunk.toString();});
  child.stderr.on('data', (chunk: Buffer) => {text += chunk.toString();});
  const exited = new Promise<void>((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (code, signal) => {events.push({pid: child.pid ?? -1, code, signal}); resolve();});
  });
  active = {child, exited};
  const deadline = Date.now() + 10_000;
  while (!text.includes('database system is ready to accept connections')) {
    if (child.exitCode !== null || child.signalCode !== null || Date.now() > deadline) {
      throw new Error(`PostgreSQL did not become ready: ${text}`);
    }
    await delay(25);
  }
  summary[`serverLog${events.length}`] = text;
  void exited.then(async () => {await writeFile(join(output, `server-${child.pid}.log`), text);});
}
async function identity(owner: Pool) {
  const result = await owner.query<Record<string, string>>(`SELECT version(),
    system_identifier::text AS system_identifier,current_setting('data_directory') AS data_directory,
    current_setting('fsync') AS fsync,current_setting('full_page_writes') AS full_page_writes,
    current_setting('synchronous_commit') AS synchronous_commit FROM pg_control_system()`);
  assert.ok(result.rows[0]);
  return result.rows[0];
}
const context = {tenantId: 'TEST_crash_tenant', projectId: 'tenants/TEST_crash_tenant/projects/TEST_crash_project', principalId: 'TEST_human'};
const manifest = (id: string) => ({name: `${context.projectId}/contextManifests/${id}`,
  workspace: `${context.projectId}/workspaces/workspace`, agentProfileVersion: `${context.projectId}/agentProfileVersions/profile`,
  runPolicySnapshot: `${context.projectId}/runPolicySnapshots/policy`, instructionRef: 'instructions:version-1', createdAt: '-1'});
const committed = manifest('committed');
const pending = manifest('pending');
const make = (runtime: Pool, owner: Pool, event: string) => createSandboxManifestFeature({pool: runtime,
  migrationPool: owner, authorization: {async assertAuthorized() {}}, nextId: () => event});
async function exactRows(owner: Pool, expected: readonly {value: ReturnType<typeof manifest>; event: string}[]) {
  const stored = await owner.query('SELECT name,facts,to_char(created_at AT TIME ZONE \'UTC\',\'YYYY-MM-DD HH24:MI:SS.US\') AS instant FROM agent_context.manifests ORDER BY name');
  assert.deepEqual(stored.rows, expected.map(item => ({name: item.value.name, facts: item.value, instant: '1969-12-31 23:59:59.999999'})));
  const outbox = await owner.query('SELECT tenant_id,project_id,event_id,resource_name,kind FROM agent_context.outbox ORDER BY resource_name');
  assert.deepEqual(outbox.rows, expected.map(item => ({tenant_id: context.tenantId, project_id: context.projectId,
    event_id: item.event, resource_name: item.value.name, kind: 'SandboxManifestCreated'})));
}
try {
  // Trust authentication is isolated to a private task-owned Unix socket, with no TCP listener.
  summary.initdb = execFileSync(join(bin, 'initdb'), ['-D', data, '-A', 'trust', '-U', 'TEST_owner',
    '--no-locale', '--encoding=UTF8'], {encoding: 'utf8', timeout: 20_000, stdio: 'pipe'});
  await start();
  let owner = pool('TEST_owner');
  await owner.query('CREATE ROLE test_runtime LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT');
  let runtime = pool('test_runtime');
  const before = await identity(owner);
  assert.equal(before.data_directory, data);
  for (const setting of ['fsync', 'full_page_writes', 'synchronous_commit']) assert.equal(before[setting], 'on');
  summary.identityBefore = before;
  summary.binarySha256 = createHash('sha256').update(await readFile(binaries.postgres)).digest('hex');
  check('native-payload-identity-and-durability-settings', before);
  let feature = make(runtime, owner, 'TEST_committed_event');
  await feature.migrate();
  await owner.query('GRANT USAGE ON SCHEMA agent_context TO test_runtime');
  await owner.query('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA agent_context TO test_runtime');
  await feature.seedManifest(context, committed);
  await feature.seedManifest(context, committed);
  assert.deepEqual(await feature.api.getManifest(context, {name: committed.name}), committed);
  await exactRows(owner, [{value: committed, event: 'TEST_committed_event'}]);
  check('committed-public-feature-and-idempotent-outbox', {name: committed.name, event: 'TEST_committed_event'});
  const held = Promise.withResolvers<{client: PoolClient; ended: Promise<void>; stagedNames: string[]}>();
  const release = Promise.withResolvers<void>();
  const heldPool = new Proxy(runtime, {get(target, key) {
    if (key !== 'connect') return Reflect.get(target, key);
    return async () => {
      const client = await target.connect();
      const ended = new Promise<void>(resolve => {client.once('end', resolve);});
      return new Proxy(client, {get(connection, property) {
        if (property === 'query') return async (text: string, values?: unknown[]) => {
          if (text === 'COMMIT') {
            const staged = await connection.query<{name: string}>('SELECT name FROM agent_context.manifests ORDER BY name');
            held.resolve({client, ended, stagedNames: staged.rows.map(row => row.name)});
            await release.promise;
          }
          return connection.query(text, values);
        };
        const value: unknown = Reflect.get(connection, property);
        return typeof value === 'function' ? value.bind(connection) : value;
      }});
    };
  }});
  const rejected = assert.rejects(make(heldPool, owner, 'TEST_pending_event').seedManifest(context, pending), {code: 'UNAVAILABLE'});
  const staged = await bounded(held.promise, 'real feature transaction staged before COMMIT');
  assert.deepEqual(staged.stagedNames, [committed.name, pending.name]);
  await exactRows(owner, [{value: committed, event: 'TEST_committed_event'}]);
  assert.ok(active);
  const killedPid = active.child.pid;
  assert.equal(active.child.kill('SIGKILL'), true);
  await bounded(active.exited, 'owned postmaster SIGKILL exit');
  assert.deepEqual(events.at(-1), {pid: killedPid, code: null, signal: 'SIGKILL'});
  await bounded(staged.ended, 'checked-out backend closes after postmaster death');
  release.resolve();
  await bounded(rejected, 'public command rejects after server loss');
  await bounded(Promise.all(pools.map(value => value.end())), 'old pool shutdown');
  pools = [];
  active = undefined;
  check('actual-postmaster-SIGKILL-during-public-feature-transaction', {killedPid, stagedNames: staged.stagedNames});
  await start();
  owner = pool('TEST_owner'); runtime = pool('test_runtime');
  const after = await identity(owner);
  assert.equal(after.system_identifier, before.system_identifier);
  assert.equal(after.data_directory, data);
  feature = make(runtime, owner, 'TEST_pending_event');
  assert.deepEqual(await feature.api.getManifest(context, {name: committed.name}), committed);
  await assert.rejects(feature.api.getManifest(context, {name: pending.name}), {code: 'NOT_FOUND'});
  await exactRows(owner, [{value: committed, event: 'TEST_committed_event'}]);
  check('same-cluster-crash-recovery-exact-committed-and-no-uncommitted-state', after);
  await feature.seedManifest(context, pending);
  await feature.seedManifest(context, pending);
  await exactRows(owner, [{value: committed, event: 'TEST_committed_event'}, {value: pending, event: 'TEST_pending_event'}]);
  check('same-identity-retry-after-crash-one-owned-outbox', {names: [committed.name, pending.name]});
  const helpers: Record<string, boolean> = {};
  for (const helper of ['pg_dump', 'pg_restore', 'pg_controldata']) {
    helpers[helper] = await access(join(bin, helper)).then(() => true, () => false);
  }
  rows.push({name: 'native-distribution-backup-and-restore', status: 'unavailable', detail: {helpers,
    reason: 'Required backup/restore helpers absent; no external helper substitution or mock restore'}});
  status = 0;
} catch (error) {
  summary.error = errorName(error);
  rows.push({name: 'unexpected-fixture-failure', status: 'failed', detail: errorName(error)});
} finally {
  try {
    await bounded(Promise.all(pools.map(value => value.end())), 'final pool shutdown');
    if (active !== undefined && active.child.exitCode === null && active.child.signalCode === null) {
      summary.finalStop = control('-m', 'fast', '-w', '-t', '10', 'stop');
      await bounded(active.exited, 'final owned postmaster exit');
      assert.equal(events.at(-1)?.code, 0);
    }
    let alive = false;
    try {control('status'); alive = true;} catch (error) {
      assert.ok(typeof error === 'object' && error !== null && 'status' in error && error.status === 3,
        'Only pg_ctl status 3 establishes an absent owned cluster');
    }
    assert.equal(alive, false);
    summary.databaseStopped = true;
  } catch (error) {summary.databaseStopped = false; summary.cleanupError = errorName(error); status = 1;}
  summary.outcome = status === 0 ? 'passed-with-explicit-unavailable-backup' : 'failed';
  await writeFile(join(output, 'crash-results.json'), JSON.stringify(summary, null, 2) + '\n');
}
process.exitCode = status;
