# Native PostgreSQL feature-boundary experiment

Date: 2026-10-25. Disposable Linux x64 component experiment. `releaseQualification: false`.

## Scope and results

This fixture reuses the real Orchestrator Agent Context immutable-manifest feature, migration and original PostgreSQL tests unchanged at `aaabc1e7cd2e2482668530e4412e61c2bca1f515`. The native resolver is copied unchanged from PR90 `0af892165a023a274302f89b47ba514ab2915e59`.

- Original feature and disconnect tests: **2 passed, zero skips/failures**.
- New actual-postmaster-crash fixture: **5 passing rows**, exact same-cluster committed/absent-uncommitted readback, idempotent retry, and observed final stop.
- Backup/restore: **explicitly unavailable**, because the exact native payload lacks `pg_dump`, `pg_restore`, `pg_controldata`. No restore assertion passed.
- Strict source, original-test and new-fixture compilation: passed on TS7.0.2, `skipLibCheck: false`.

Read `../../reports/current-storage-and-postgres.md` for authority, interpretation and remaining conditions. `evidence/crash-results.json` distinguishes every passing/unavailable row. Timeouts are observation bounds, not benchmarks.

The fixture uses `embedded-postgres`18.4.0-beta.17's native PostgreSQL18.4 payload and standard native process control; it does not qualify the wrapper lifecycle/global hook or a product Supervisor. Fixture-only Unix-socket `trust` authentication is confined beneath a private 0700 task root with no TCP listener. Native signed Desktop installation, production credentials, macOS/Windows, schema upgrades, verified backup restore, external-effect recovery and scale remain outside scope.

## Reproduction on an ordinary unprivileged Linux account

Use exact Node26.11.1 and pnpm11.18.0, with this directory in a path traversable by the account. Run from `runtime/`:

```bash
pnpm install --frozen-lockfile --config.engine-strict=true --strict-peer-dependencies
node node_modules/typescript/bin/tsc --project tsconfig.build.json --pretty false
node node_modules/typescript/bin/tsc --project tsconfig.test.json --pretty false
node node_modules/typescript/bin/tsc --project tsconfig.crash.json --pretty false
```

Resolve the package's exact binary directory through its public optional-distribution resolver, then run the unchanged tests:

```bash
TASK_PG_BIN=$(node --input-type=module -e "import {dirname} from 'node:path'; import {postgresBinaries} from './postgres-binaries.ts'; console.log(dirname(postgresBinaries().postgres))")
RUN_CONTEXT_OBSERVATION_PG=1 TEST_POSTGRES_BIN="$TASK_PG_BIN" node --test --test-concurrency=1 --test-isolation=none agent-context/tests/features/sandbox-manifest/manifest-postgres.test.ts agent-context/tests/features/sandbox-manifest/postgres-disconnect.test.ts
```

Create a new private output directory; run the new harness with `PG_BOUNDARY_OUTPUT` pointing to its absolute path. `TMPDIR` may select another fresh private task root. The process must be unprivileged because initdb rejects root. The harness retains its stopped data root for inspection; remove only that explicitly recorded task-owned root after confirming `databaseStopped: true` and preserving evidence.

```bash
mkdir -m 700 ./crash-output
PG_BOUNDARY_OUTPUT="$PWD/crash-output" node crash-boundary.ts
```

An exit0 from the new harness means its five core rows passed and its backup capability row remains unavailable. Inspect the JSON; do not interpret exit0 as a passing restore or release qualification.

## Exact campaign commands and identities

The campaign shell was root, so the same source/dependencies were copied to `/tmp/plugin-validation-pg-run-20261025` without modifying `/workspace/scratch` permissions. Only `/tmp/plugin-validation-pg-runtime-20261025` was assigned to the existing nobody uid/gid65534. The following were executed under the authorized existing-account privilege drop:

```bash
runuser -u nobody -- env TMPDIR=/tmp/plugin-validation-pg-runtime-20261025 RUN_CONTEXT_OBSERVATION_PG=1 TEST_POSTGRES_BIN=/tmp/plugin-validation-pg-run-20261025/node_modules/.pnpm/@embedded-postgres+linux-x64@18.4.0-beta.17/node_modules/@embedded-postgres/linux-x64/native/bin /tmp/plugin-validation-toolchain-20261025/bin/node --test --test-concurrency=1 --test-isolation=none agent-context/tests/features/sandbox-manifest/manifest-postgres.test.ts agent-context/tests/features/sandbox-manifest/postgres-disconnect.test.ts
runuser -u nobody -- env TMPDIR=/tmp/plugin-validation-pg-runtime-20261025 PG_BOUNDARY_OUTPUT=/tmp/plugin-validation-pg-runtime-20261025/evidence /tmp/plugin-validation-toolchain-20261025/bin/node crash-boundary.ts
```

The cwd for both commands was `/tmp/plugin-validation-pg-run-20261025`; root-shell redirects preserved logs into this `evidence/` directory. Shared toolchain PATH selected `/tmp/plugin-validation-toolchain-20261025/bin`. The first exact dependency resolution generated the committed lock; the corrected final `pnpm install --frozen-lockfile --store-dir /tmp/plugin-validation-pg-store-20261025 --config.engine-strict=true --strict-peer-dependencies` passed with engine/peer enforcement. `NODE_USE_ENV_PROXY=1` and authorized network execution were required for package fetches.

`evidence/execution-identities.json` binds actual native binary, tool, wrapper, source/configuration and lockfile hashes. `reused-source-manifest.json` binds all copied original `.ts` bytes. Vendor/native files and installed dependencies are excluded from the evidence archive; reinstall from the frozen lock. Original source copies are retained as frozen experiment inputs, not a new production fork.

## Failure record and critical distinctions

The first package install failed on pnpm's default store, then on restricted network access. The initial package-level build allowlist was ignored by pnpm11; moving it to the current workspace `allowBuilds` location matched PR90. Final frozen installation passed; no dependency code was patched. These failures remain as `install-*-failed.log`.

The first unchanged-test run could not traverse root-only `/workspace/scratch` as nobody. It was not a failing SQL assertion. `existing-feature-tests-path-failed.log` preserves it; the final separate readable runtime succeeded. A first new-fixture strict compile reported `crash-boundary.ts(66,54): error TS2345: Argument of type 'string | undefined' is not assignable to parameter of type 'string'. Type 'undefined' is not assignable to type 'string'.` The output path now has a string default followed by a required nonempty assertion; compiler settings were unchanged. The initial diagnostic is transcribed here from the tool output, since the final clean compile reused its log path.

The original suite's `pg_terminate_backend` cases kill a checked-out connection backend. Its lost-COMMIT response uses a client Proxy after a genuine COMMIT. The new harness actually SIGKILLs the known owned postmaster with a staged public-feature transaction and awaits backend end; fresh pools then reopen the same physical cluster. Those are three distinct failure boundaries. None is a real power-loss test.

Final `pg_ctl status`3, actual postmaster exit0 and the independent process check establish this fixture's stopped cluster. They do not prove a general OS custodian, arbitrary-descendant absence, PID-reuse safety or restarted-Supervisor adoption. The independent peer review is documented in the report; it is not a second execution.
