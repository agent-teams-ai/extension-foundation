# Static composition and controlled restart: executable qualification

Evidence date: 2026-10-25. Status: **static public-package composition demonstrated;
controlled-restart mechanisms partially demonstrated; a required admission-seal
property fails in the reused recovery fixture. No production runtime qualified.**

## Decision-relevant outcome

The owner's static-composition plus controlled-restart baseline is supported by
real current Get Modular author/provider construction and process experiments.
It requires no new Host, kernel, RPC stack or supervisor. Static A/B provider
selection produces different real effects and immutable plans; preparing B does
not rewrite references captured by an existing A. Invalid missing, ambiguous,
duplicate and incompatible graphs are rejected before executable construction.
Old A bytes can be reused in a fresh process incarnation with the same content
digest and a new UUID.

**The existing restart fixture must not be promoted unchanged into a production
restart adapter.** An added rejecting test found a real missing admission seal:
new work is accepted and durably written while `worker.stop()` is in flight once
the old physical effect child has exited. The semantic attempt fixture closes its
own ingress correctly; the recovery command receiver does not enforce the same
rule. This is a defect in that disposable fixture's product-policy coverage,
not evidence that Core or Assembly owns admission or that a new generic runtime
is needed. The correct product admission owner must seal its actual acceptance
boundary before draining. No source fix or alternative runtime was written.

## Exact subjects and adoption boundaries

| Subject | Executed or inspected identity |
| --- | --- |
| Runtime | Linux x64, Node 26.11.1, pnpm 11.18.0 in the isolated experiment |
| Compiler | TypeScript 7.0.2 native compiler; ordinary `.ts`; `strict:true`, `skipLibCheck:false`, NodeNext/ES2024; `@types/node`24.19.1 |
| Public runtime packages | Registry-resolved `@get-modular/core@0.7.0`, `@get-modular/assembly@0.7.0`, `@get-modular/resources@0.2.1` |
| Public development harness | Registry-resolved `@get-modular/conformance@0.5.0` |
| Copied fixture source | Clean Get Modular main `b70ba39304ac71964175c42a77309406a7c30ca2`; 47 files copied byte-for-byte from `tests/qualification/consumer-fixtures/{semantic,recovery}` |
| Prior research restored read-only | EF PR55 head `150c29acc341380ba16d5cc402052a03d201ce4c`, `/tmp/plugin-static-validation-20261025`; research hub, customization/reuse records and original executor findings inspected |
| Current Orchestrator authority inspected | Main `aaabc1e7cd2e2482668530e4412e61c2bca1f515`, ADR0113 |

Orchestrator ADR0113 selects the exact **0.5.0 Core/Assembly pair** as its design
baseline and pins the Consumer Module Standard at
`a3a079baca2c6af48c9d45bc08992825be1c2bbd`. It explicitly does not authorize adding
production dependencies before admission. The external 0.7.0 consumer run here
does **not** migrate that adopted pair or qualify an Orchestrator production
scope. Optional Resources and lifecycle packages are not adopted merely by
family membership. The isolated fixture's pnpm11.18 profile also does not change
the current GM repository's pnpm11.20 requirement.

Primary owning sources are GM's System Boundary, current public package READMEs,
Consumer Module Standard, ADR0023 (Assembly), ADR0030 (Resources), ADR0038 (TS7),
and Orchestrator ADR0113. Immutable URLs:

- [GM source boundary](https://github.com/agent-teams-ai/get-modular/blob/b70ba39304ac71964175c42a77309406a7c30ca2/docs/architecture/system-boundary.md).
- [GM Assembly public contract](https://github.com/agent-teams-ai/get-modular/blob/b70ba39304ac71964175c42a77309406a7c30ca2/packages/assembly/README.md).
- [GM Resources public contract](https://github.com/agent-teams-ai/get-modular/blob/b70ba39304ac71964175c42a77309406a7c30ca2/packages/resources/README.md).
- [Existing controlled-restart qualification route](https://github.com/agent-teams-ai/get-modular/blob/b70ba39304ac71964175c42a77309406a7c30ca2/tests/assembly/consumer-restart.test.mjs).
- [Orchestrator accepted composition selection](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/aaabc1e7cd2e2482668530e4412e61c2bca1f515/docs/decisions/0113-canonical-module-and-composition-adoption.md).

`experiments/static-restart/results/identities.json` records every copied source
file SHA-256, verifies correspondence with the clean source checkout, and hashes
the installed public package trees. The exact lockfile retains distribution
SHA-512 integrities. Separate npm metadata responses for all four public
packages are in `logs/registry-*.json`; their Git-head fields were not supplied.
No tarball-to-Git equivalence or verified npm provenance-signature claim follows.

## Components exercised, and what is fixture policy

Real public boundaries: `defineContract`, `declareModule`, `implement`, static
groups, `assemblyFor().prepare`, public `compileComposition`, public Resources
`scoped/createScope`, and public Conformance checks in the inherited suite.
Actual A/B author modules consume closed typed dependencies and acquire real
file-backed resources. Actual application code emits real file journal effects.

The recovery experiment reuses the **existing test-only Supervisor**, operation
owner, snapshot store, worker and sibling effect child unchanged. It uses real
Node process spawning, IPC, physical exit, exclusive file acquisition,
write/sync/close/rename and cleanup. Faults and named barriers are injected by
the fixture. Its single live test Supervisor retains every actual child handle;
neither a persisted PID nor a status object reconstructs custody.

The snapshot store, command sequencing, one-writer grant, admission policy and
readiness in these sources are **test-owned policy**, not a production
implementation or PostgreSQL durability proof. Supervised worker loss is not
complete loss of the physical-custody owner. `selection-child.ts` adds only a
one-shot CLI around real prepared modules; it introduces no persistent Host,
protocol, generation state machine or supervisor. All new source is test-only.

## Executed matrix

| Case | Actual observation | Result and limits |
| --- | --- | --- |
| Unchanged semantic module/lifetime/workload and recovery suites | 60 passing test observations, 0 failed, 0 skipped, 0 todo | Local execution; inherited suite covers both recovery profiles and four nested file-fault cases |
| S01 real author A/B selection | A emits `old-a:A:hello` before and after B is constructed; B emits `new-b:B:hello`; original A composition bytes unchanged | Passed; existing references do not become B |
| S02 graph preflight | Missing and ambiguous provider rows give `assembly.prepare.unresolved-binding`; duplicate identity gives `assembly.prepare.duplicate-module`; author factory sentinel invocation count remains0 | Passed; this checks construction effects, not import-time code effects |
| S03 revision conflict | Real public Core reports `binding.compatibility-mismatch`, expected runner/r1 versus actual runner/r2 | Passed before any Assembly execution |
| S04 12 sequential A/B process executions | All children return expected two real results and effect records, close resources, exit0; exact known PID is absent (`ESRCH`); all12 UUIDs distinct | Passed within finite one-shot cohort scope |
| S04 immutable old bytes reused | Same provider emitted-byte hash and plan digest across all A restorations; same independently for B; A and B plan digests differ | Passed; content digest is separate from incarnation identity |
| S05 24 existing recovery-worker stop/start cycles | All24 grants distinct; every old worker exit joined before next start; old client rejects commands after exit; exactly one ready/exit pair per explicit start/stop | Passed for directly owned workers; no automatic replacement is invoked by stop |
| S06 real natural completion before restart | Accepted operation completes SUCCESS; effect child exits0 without signal; terminal readback precedes old worker exit; fresh worker ready follows old exit; duplicate after restart adds no launch | Passed; force stop was not used to call work completed |
| S07 admission while stop in flight, both recovery profiles | After revoke and actual old effect exit, a new submit returns `created:true` and persists a pending record while held ACK keeps stop in flight | **FAILED required property twice**; retained red regression; no aggregate pass |
| S07 next-worker disposition | `record-only` retains the admitted-during-stop record pending with no automatic or duplicate-triggered dispatch; `restart-pending` resumes it to SUCCESS with one new real child | Observed after stop; no durable record loss claimed |
| Complete child/descendant inventory | procfs task `children` file unavailable even outside sandbox | **Unqualified**, no substitute passing inventory |
| Reference/RSS retention under arbitrary churn | Existing fixture retains historical worker connections and events; only24 cycles exercised | **Unqualified**; no unbounded-memory or descriptor-count-to-memory inference |
| Windows/macOS/native plugin containment/full custody-owner crash | Not executed | **Unqualified** |

The inherited recovery suite includes committed acceptance before lost response,
unclaimed pending recovery versus record-only behavior, cancellation surviving
restart, unknown claims becoming quarantined without re-execution, stale grants,
lost child acknowledgement retaining live sibling occupancy, physical exit
separate from actual retained-file cleanup debt, late success after cancellation,
duplicate/conflicting command identities, capacity-one rejection without a queue,
failed durable cancellation freezing launches, competing startup, failed worker
and effect spawn, and file replacement faults. These are actual assertions and
local execution, not a proposed crash matrix.

Inherited lifetime tests exercise late factory result ownership, readiness after
stop, publication ordering, accepted callback completion before cleanup,
cancellation of accepted work, partial acquisition cleanup, failed cleanup retry,
abandoned observers that do not release ownership, post-await effect permission,
capacity return and no admission after semantic ingress closes. The aggregate
workload test admits16 of64 observations, rejects48 under its explicitly
test-owned aggregate limit, records15 successes/1 cancellation and physically
releases16 resources with17 cleanup attempts. This is a bounded workload, not
thousand-plugin or tenant-product capacity qualification.

## The failing stop trace

S07 uses existing supported fixture controls, not a timer race:

1. Start the writer and hold its first real effect launch acknowledgement.
2. Submit the first operation and observe `launch-ack-held`.
3. Request `worker.stop()`; observe revocation and actual effect exit.
4. Keep acknowledgement held so stop remains live; submit a different operation.
5. Observe `created:true`, a second canonical pending record and a new capacity
   reservation. Release acknowledgement and join shutdown.
6. Start a fresh worker. Under `record-only`, read back the exact pending record;
   a duplicate submit remains a duplicate and triggers no dispatch. Under
   `restart-pending`, observe a fresh claim/real effect child, complete it and
   read back SUCCESS. Join the fresh worker's stop, then fail the original
   required admission-rejection assertion in both profiles.

Source explanation: `worker.ts` sets `closing=true` in the stop command and
`schedule()` refuses to dispatch when closing, but the submit command still
calls `current().submit(...)`; `OperationOwner.submit()` has no stop admission
state. Physical capacity availability therefore permits a new durable accepted
operation during shutdown. This is precisely why dispatch closure is not an
acceptance seal. The test does not assert that this accepted operation executed;
the canonical pending record is already the violated promise. The follow-through
shows it can be resumed by the explicit restart-pending policy and stays durably
pending under the record-only policy; it does not demonstrate data loss or
indefinite inability to recover through another owning command.

The correction belongs at the actual product acceptance receiver and its one
authoritative operation, preserving idempotent readback of previously accepted
identities. This report does not select a new API or amend the existing fixture.
`pnpm test:stop-admission` remains red. `pnpm check` includes it and must remain
red until that behavior is corrected and requalified.

## Resource observations and honest platform scope

The final12 one-shot children leave the parent FD count at21 after every cycle,
from a21 baseline. The24 recovery worker cycles leave22 after every cycle from
a21 baseline. The fixture's assertion bound is baseline+2, per the actual parent
process, after awaited worker exit and an event-loop turn. These are plateau
observations, not a long-run leak proof, memory benchmark or machine-wide
process census. No unknown descendant identity was inspected or declared gone.

The environment's process namespace differs from mounted procfs (`process.pid`
and `NSpid` observations preserved). Both initial namespace-PID addressing and
native-PID addressing of procfs task children failed because the children file
does not exist in this environment. The final scope explicitly leaves complete
descendant enumeration unqualified while retaining exit and `ESRCH` checks for
exact known child PIDs. FD readings concern the observing parent only.

The one-shot A/B/A sequence allows full unavailability between processes. It
does not overlap old/new admission, migrate accepted work, make an active
capability graph mutable or force unfinished work to succeed. Existing loss and
cancellation cases preserve cancellation/uncertainty instead of calling them
natural completion. Resource callback completion, process exit and file debt
closure remain separate observations.

## Failures, corrections and reproduction custody

All commands and raw outcomes remain under `experiments/static-restart/logs`:

- Install attempt1: default pnpm store could not open its SQLite index. Attempt2:
  required network requests returned sandbox `EPERM`. Attempt3: explicit
  disposable store and reviewed network route installed exact packages without
  scripts, overrides or source patches.
- First typecheck: own test code had unreachable narrowing, a descriptor
  inference conflict from spreading an existing declaration, and a wrong
  diagnostic-code name. These were corrected in the test source; dependency
  declarations and `skipLibCheck:false` remained unchanged.
- First Node default reporter summarized files instead of individual cases.
  The expanded run uses the existing fixture's `--test-isolation=none` route and
  TAP, retaining60 actual passing test observations.
- Process attempts1–4 failed on the unavailable procfs task children file. The
  scope correction is explicit above; those rows do not qualify descendant
  inventory. Identity capture also initially hit sandbox `spawnSync git EPERM`;
  reviewed execution completed the clean source audit.
- The first multi-spec `npm view` invocation emitted no metadata. Four separate
  exact-spec invocations produced the retained distribution records.
- S07 is an actual unresolved behavior failure and remains red. It is not
  reclassified as a passing counterexample test.

`REPRODUCE.md` gives exact commands, expected statuses and execution restrictions.
The final strict build and no-emit typecheck pass. `existing-expanded.log`
records60/60, `added-after-scope-correction.log` records6/6, and
`stop-admission-with-recovery.log` records0/2 (both profiles). The earlier
single-profile0/1 log remains preserved. These are separate observed
outcomes; a green aggregate is not claimed. No entire GM/EF/Orchestrator source
repository gate was run or claimed, because no owning repository source changed.

## Alternatives, scores and code budget

Scores are engineering judgments out of10, not measured availability. Reliability
means achievable within each stated scope **after** remaining product gates;
higher complexity means more burden. LOC estimates carry approximately×2
uncertainty and exclude existing GM/AR code and platform/release packaging.

| Option and promised scope | Confidence | Achievable reliability | Complexity | New production/integration estimate | New tests/fixtures estimate |
| --- | ---: | ---: | ---: | ---: | ---: |
| Static trusted composition, immutable selection, ordinary startup | 9 | 9 | 2 | 50–200 product composition/wiring LOC | 200–600 owner oracle/negative LOC |
| Full controlled restart through the existing physical-custody owner; admission may be unavailable | 7 | 9 | 4 | 150–500 receiver/custody adapter LOC, only after real product seam is inspected | 600–1,400 E2E/fault LOC |
| Trusted request-cohort hot overlap with state/effect recovery | 4 | 7 | 8 | 800–2,000 integration LOC plus existing unreleased-kernel adoption prerequisites | 1,500–3,500 E2E/fault LOC |

The hot-overlap row is an **unexecuted comparison estimate**, not an authorized
replacement for the accepted restart baseline. This campaign does not add a
production kernel or release the optional lifecycle candidate. Optional Temporal
scheduling is assessed by its separate workstream; it cannot supply the missing
receiver admission seal or physical custody by workflow history alone.

**Actual incremental production source:0 LOC. Actual new strict TypeScript
test/fixture/evidence source:373 physical lines. Reused frozen TypeScript source:
3,576 physical lines** including inherited negative fixtures; the root strict
project follows the original runtime scope and excludes those deliberately
negative files. The copied source is not a new production implementation.
Metadata, lockfile, logs, reports and emitted JS are counted separately from
handwritten source. A real product first slice still needs its actual accepted
package pin, immutable selected artifact input, admission/stop semantics,
existing AR custody adapter, failure persistence/readback and deployment gates.
