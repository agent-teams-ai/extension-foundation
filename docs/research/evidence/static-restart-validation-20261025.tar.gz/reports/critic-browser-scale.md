# Independent critique: browser parity and current GM graph growth

Reviewed 2026-10-25. This is a bounded inspection of the retained experiment,
unchanged growth driver and accepted scope. I did not execute another browser,
compiler or growth campaign. Additional execution was limited to read-only input
hash comparisons. Root owns integration and disposition.

## Verdict

The observed browser result supports **one identical static public-API program
on Linux Node 26.11.1 and actual Chrome 156.0.8078.47**, using native browser ESM
and an import map. The growth results available at review support the **current
ADR-0041 generated descriptor-union recipe at N100, N500 and N1000**, with all
eight selected compiler/runtime stages passing under the original caps.
N1000 completed during review; I inspected its terminal full report at
`/tmp/gm-growth-1000-so5mfG/report.json` before finalizing this report; root has
copied it to `experiments/scale-browser/growth-results/1000/report.json`.

These are appropriate evidence for the accepted static composition baseline.
They do not qualify a browser Host, physical replacement, arbitrary third-party
plugin loading, malicious-code containment, a thousand simultaneously active
plugins, product resource budgets or a production latency/reliability promise.

The main actionable gaps were a browser oracle weakness and replay metadata.
Root has strengthened the former; retain the completed final run and the
explicitly labeled earlier attempts. Preserve the metadata listed below before
calling the experiment independently reconstructable.

## Sources and ownership checked

I read the shared [brief](../context.md), GM `AGENTS.md`, the restored central
Engineering Quality Standard, [ADR-0041](../repos/get-modular/docs/decisions/0041-preserve-complete-feature-maps-with-descriptor-unions.md),
the P5 plan/scenarios and the existing 2026-10-23 qualification receipt. The
experiment inputs are [growth-inputs.json](../experiments/scale-browser/growth-inputs.json),
the public input lock, browser `parity.ts`, `run.ts`, `tsconfig.json`, package
manifest, results and execution/typecheck logs. Growth review additionally used
the full temporary `report.json` files and the driver at
`/tmp/plugin-growth-check-20261025/tests/qualification/consumer-fixtures/growth`,
including generator, independent oracle, edits, runtime sources, parent
supervisor and worker, plus `support/materialize.mjs`.

The driver checkout reports HEAD
`b70ba39304ac71964175c42a77309406a7c30ca2`. `git status` reports only the four
tracked package manifest substitutions; the driver sources are unchanged. Its
package manifests and ignored `dist` outputs have deliberately been replaced
with registry inputs. Therefore the HEAD and repository lock identify the
**driver**, not a same-commit build of those registry packages. The explicit
scope sentence in `growth-inputs.json` handles this correctly.

## Browser oracle assessment

The fixture runs `runParity()` in Node and imports its identical compiled module
in a real Playwright-driven Chrome page. Only Core and Assembly public
entrypoints are mapped; relative public distribution modules are served as
JavaScript. There is no bundler, browser replacement implementation or Node
polyfill in the common program. The runner compares complete returned results
with `assert.deepEqual` and rejects observed page/server errors. The retained
result records Playwright 1.62.1, actual Chrome version, Linux/x64 and matching
Node/browser values, digests, rejection codes and factory count. The strict
compiler configuration has `skipLibCheck: false` and `noEmitOnError: true`.

This oracle has useful independent expectations: A reads A; B reads B; the old
A reference still reads A; the two selections change the digest; preparing A
again preserves the digest; invalid graphs and a pre-aborted construction invoke
no factories. This goes beyond checking that both environments return the same
possibly wrong value.

**Finding B1 — diagnostic and construction-count oracle strengthened.** The
initial source merely accumulated diagnostic codes and compared factory counts
before and after rejection. It did not independently assert the three expected
codes or that the two valid constructions invoked exactly four factories. I
reported this to root. The reviewed final source and compiled `out/parity.js`
now include both checks. Missing and ambiguous bindings legitimately share the
public `assembly.prepare.unresolved-binding` code; duplicate declarations return
`assembly.prepare.duplicate-module`. A separate failure log records the initial
TypeScript control-flow narrowing complaint; the corrected count check uses
`Object.is`. An execution from stale compiled output after that failed compile
is separately labeled and must not be used as proof of the strengthened source.
The final empty typecheck log and updated compiled assertions were present at
inspection; root should bind the successful final command exit and result to
those final source hashes in the packaged receipt.

**Finding B2 — state only the actual immutability observation.**
`Object.isFrozen(pa.composition.plan)` checks the plan object itself. Retaining
equal JSON across subsequent work checks the serialized fields exercised in
this sample. Neither proves recursive freezing or rejects every attempted
nested mutation. Root accepted the narrow phrasing: shallow frozen plan object,
stable prior serialized plan and preserved old instance behavior. No extra
immutability campaign is needed for that claim.

The source calls a pre-aborted signal only. It does not exercise abort during a
live factory. Its fresh independent A/B compositions demonstrate provider
substitution; they do not stop or replace an existing execution owner. The small
common program has no resource custody or cleanup workload. These limits are
consistent with the runner's explicit static-package-only note.

## Growth oracle and observed results

The current generator derives complete contract unions and separate
`CapabilitiesOf` bases from one predecessor list. This is the **accepted
2026-10-23 ADR-0041 successor**, not the historical inherited-map recipe that hit
its N500 compiler ceiling. The 2026-10-23 receipt already qualifies this current
recipe through N1000 on its identified inputs. Current local samples should be
described as additional public-registry-byte checks; do not report them as the
first discovery that the old recipe now works or that a compiler defect was
fixed.

The unchanged driver has substantial oracles. A separate expected arithmetic
routine does not import generated implementations, the generator or completed
plan. It checks every constructed value for seeds 17 and 23. Independent naming
rules pin every provider, the input and root through public `checkWiring`.
Inventory checks assert exact source path census, declared/reached node counts,
bindings, occurrences, unique edges and maximum path depth. Ordinary public
smoke injects failure and abort at each constructed entry; test-owned wrappers
independently count total and per-feature factory calls and dependency reads.
The published smoke implementation itself validates success/failure/cancellation
semantics and injected failure identity, rather than returning unexamined steps.

G-03 checks unchanged source/output identities, performs the frozen leaf edit
with the expected +1 result, restores baseline bytes/output, and performs the
fixed six-file contract/revision edit while preserving both checksums and
provider pins. Full smoke is intentionally not repeated for the edit stages;
that boundary is explicit in their result. The compatible wrong-provider
rejecting control is the original small N8 case; it is not rerun at every large
size. Do not claim current execution of the small control from these large
logs alone.

| Current sample | Source files / declarations / distinct edges | Full smoke attempts / factory calls / dependency reads | Cold emit | Complete supervised case | Result |
| --- | --- | --- | --- | --- | --- |
| N100 | 703 / 101 / 197 | 201 / 10,200 / 19,803 | 5.994 s | 31.027 s | All eight stages passed |
| N500 | 3,503 / 501 / 997 | 1,001 / 251,000 / 499,003 | 17.459 s | 70.813 s | All eight stages passed |
| N1000 | 7,003 / 1,001 / 1,997 | 2,001 / 1,002,000 / 1,998,003 | 71.340 s | 277.565 s | All eight stages passed |

The external parent arms each stage deadline before acknowledging child launch
and waits for worker close; the worker waits for each synchronous child to be
reaped before its stage-end handshake. The pass receipts record natural worker
exit, no expiry and eight observed ended stages. Compiler/runtime/aggregate caps
remain 180/120/600 seconds. First failure must stop progression; no cap increase
or timeout repeat is justified by this critique.

One sample is not a distribution or SLO. The current logs explicitly report
source scanner and RSS as not collected. Compiler `Memory used` is not process
RSS. This test constructs a sparse synthetic graph with a chain and useful
checksums; it does not keep N worker processes, connections or user plugins
concurrently alive. Nor is N1000 graph growth a browser growth result.

## Exact inputs and reproducibility disposition

Read-only hash checks found all four worktree manifests and `dist` trees equal
to the frozen static install's inputs, with manifest hashes matching
`growth-inputs.json`. Recomputing the identities of the copied packages in both
N100 and N500 subjects also matched each full report's recorded identity, file
census and byte count. The same four copied-package identities appear in both:

| Copied public package | Version | Manifest-plus-dist SHA-256 |
| --- | --- | --- |
| Core | 0.7.0 | `5d17ed3eb926a51765d46610d375c14e39a8d762dff3233b3efa51e6f6b04544` |
| Assembly | 0.7.0 | `70cf34d650251a27635465f541c4d8ebc9d67f6a9da09791d358fbd676c5daa3` |
| Resources | 0.2.1 | `cbbbeb4c7b22f17aa59f3ae4aa4c353cc1df4227ca53a7d6108eb02be009d2cd` |
| Conformance | 0.5.0 | `d3fa5faf0723b14c363ab93b6f67dda97a9ff174722d1c14860148f36964e1e8` |

The N100/N500/N1000 cold generated-source identities exactly match their respective
2026-10-23 current-recipe source identities: `b6dc1400…dd1de`,
`e32188ee…4d2a5` and `f3534c8c…23194`. Their generator, oracle, edits, config and generated runtime test
identities also match that retained recipe. Registry-package output identities
differ from the original repository-built receipt, so do not merge the two
package-build provenance claims or turn the new log's explicit uncollected
source scan into a newly executed scan.

**Finding R1 — retain the actual native compiler identity.** The growth worker
hashes the TypeScript wrapper package, but TypeScript 7's `lib/tsc.js` selects a
separate `@typescript/typescript-linux-x64` native executable. That executable is
outside the wrapper tree. The public input lock carries its integrity; retain
the actual optional package tree and native executable hashes beside the Node
identity. This is a read-only metadata correction and requires no rerun.

**R1 disposition:** closed by the inspected
`execution-input-identities.json`. It records the native package tree and
`lib/tsc` executable SHA-256
`4f2de678286401759b3fb4475bafe35b8f32b4b3a07d92642bbf37eadc9b34a4`,
matching the retained supported native compiler identity. It also records the
actual Node executable identity.

**Finding R2 — distinguish the browser's shared install from a frozen browser
install.** Browser `node_modules` points to the frozen static GM/types install
and to runtime-owned Playwright. The copied public-input lock has no Playwright
entry. A version string and the browser's `package.json` are insufficient to
reproduce those exact runtime bytes alone. Retain Playwright and playwright-core
tree hashes, their exact install recipe or separate lock/integrity, and Chrome's
official download URL, archive hash, observed version and launch arguments.
This gap does not invalidate the observed real-browser execution.

**R2 disposition at handoff:** actual runtime Playwright and playwright-core
trees are recorded in the inspected `execution-input-identities.json`. Root
reports a completed separate frozen browser installation with its own lockfile.
Its final targeted browser rerun and input binding are in progress, so I do not
claim to have independently inspected that later receipt. Root can close the
installation-replay follow-up when its successful strict compile/run, exact
lock/input identities and Chrome download identity are retained. The prior
real-Chrome parity result remains valid within its stated inputs.

**Finding R3 — summary growth logs are insufficient by themselves.** Preserve
each full report, supervision receipt, raw stage stdout/stderr, runtime and edit
verification JSON, patches, deterministic generator, independent oracle, root
manifest/driver lock and required support imports. `worker.mjs` imports
`support/materialize.mjs` and `upstream-compiler.ts` even when the optional
candidate route is not selected. Retaining only the growth folder's entrypoint
and terminal summary would break replay. Omitting generated thousands of source
files and outputs is reasonable when retained drivers reproduce their recorded
identities; retain before/after edit text and hashes from the reports.

## Closure

No architecture change, alternative runtime, new production code or additional
scale campaign is proposed here. Confidence/reliability/complexity scores and
alternative production/integration LOC are therefore not new decisions in this
routine evidence review. Root should finalize the replay manifest and terminal
browser-install disposition, preserve the original limits and label all observations at
their exact scopes. The current narrow Node/browser claim and completed
N100/N500/N1000 graph claims are supported by the inspected evidence.
