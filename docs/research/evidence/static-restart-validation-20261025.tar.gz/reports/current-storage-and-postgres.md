# Current storage authority and PostgreSQL boundary verification

Observation date: 2026-10-25. Research evidence, not an accepted decision or release qualification.

## Verified authority map

| Authority | Immutable identity | Verified state and implication |
| --- | --- | --- |
| Organization backend reference, PR376 | head `d408d83fcd86840b7dd2e16a4f9024188a7950cd`, merge `38c973858d808aa852ed18b42294a4990a52eeec` | Merged 2026-10-22. Native PostgreSQL, asynchronous node-postgres and adapter-local Drizzle; the consuming product owns exact versions and qualification. `embedded-postgres` is the selected Supervisor adapter approach. |
| Orchestrator PR89, ADR0114/0115 | head `b85cd870edd6c668f906fda7917da93517d1bd30`, merge/current main `aaabc1e7cd2e2482668530e4412e61c2bca1f515` | Merged 2026-10-22. Native PostgreSQL is authoritative for Fully Local and hosted profiles; Fully Local is a mandatory V1 profile. A client attached to a hosted Target starts no unused local database and holds no SQL credentials. |
| Orchestrator PR90, ADR0116 | `0af892165a023a274302f89b47ba514ab2915e59` | Open and unmerged at this observation. The branch contains the owner-approved accepted ADR dated 2026-10-23 selecting full native Temporal Service backed by PostgreSQL for Fully Local V1. Its OD035 is resolved; main's older OD035 remains open because adoption has not merged. Do not reopen the approved engine choice on the strength of stale main alone. |
| PR90 adoption-head native CI | run `40009973655`, exact PR90 head | Live workflow/jobs API confirms all nine candidate/OS jobs succeeded, including the deliberate bootstrap-failure exit control and native engine fixtures. This is hosted component evidence, not local execution here or product qualification. |

Primary links: [PR376](https://github.com/agent-teams-ai/.github/pull/376), [PR89](https://github.com/agent-teams-ai/agent-teams-orchestrator/pull/89), [PR90](https://github.com/agent-teams-ai/agent-teams-orchestrator/pull/90), [ADR0114](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/aaabc1e7cd2e2482668530e4412e61c2bca1f515/docs/decisions/0114-canonical-backend-stack-and-distributed-role-adoption.md), [ADR0116](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/0af892165a023a274302f89b47ba514ab2915e59/docs/decisions/0116-native-temporal-for-fully-local-durable-workflows.md), [native CI](https://github.com/agent-teams-ai/agent-teams-orchestrator/actions/runs/40009973655).

Raw observed metadata is retained in `../experiments/postgres/evidence/current-pr-metadata.json`, `pr90-workflows.json`, and `pr90-native-jobs.json`. ADR0114's exact adopted central reference is [revision `4dcf4ffe29279e479e089bc06f745dd1a62f12d1`](https://github.com/agent-teams-ai/.github/blob/4dcf4ffe29279e479e089bc06f745dd1a62f12d1/docs/backend-stack.md), independently fetched and retained in `adopted-central-backend-reference.json` (Git blob `5efaae4b013124f9bd80326988f86f7d32c122a0`). The PR376 merge is current integration evidence; it does not replace the consumer's exact content pin.

## Exact selection versus evidence pins

The selected Node package is **`embedded-postgres` behind a narrow Local Supervisor component adapter**. ADR0114 explicitly says that this does **not** select the historical research wrapper `18.4.0-beta.17` or an exact production engine/helper/artifact matrix. OD003 and OD021 retain those qualifications. The Supervisor owns native binary/process/protected-root/endpoint/activation custody; Host/context adapters own SQL connections, migration, transactions and business recovery. A dedicated launcher child may contain global wrapper hooks but must not become a second Supervisor.

Current main's materialized Agent Context dependency catalog pins `pg` and `@types/pg` to **8.23.1**, with TypeScript **7.0.2**. The accepted stack selects adapter-local Drizzle, while OD003 retains a pre-production readiness/exact-version decision; historical `drizzle-orm` **1.0.0-rc.4** parity evidence is not a fresh production pin. The existing bounded Agent Context adapter uses node-postgres directly; it is an available real-product boundary to reuse rather than a reason to invent a generic persistence framework.

ADR0116's **Temporal Server 1.32.1 / TypeScript SDK 1.24.0 / PostgreSQL 18.4** are exercised research pins, explicitly not a perpetual production version policy or upstream PostgreSQL support certification. Full native service means neither Temporal's SQLite development server nor an in-memory production scheduler. The optional Temporal adapter for the plugin replacement mechanism does not reopen the product's accepted workflow choice.

## Historical ADR reconciliation

ADR0048 and ADR0049 remain accepted historical records whose bodies mention SQLite. ADR0114 explicitly replaces ADR0048's local SQLite authority and SQLite-specific recovery artifacts, while retaining its other requirements. It also replaces the relevant SQLite requirements in ADR0025/0052 and supersedes ADR0011's topology. ADR0049's exact-value and microsecond-instant profile remains applicable to PostgreSQL. One authority, logical transfer, post-commit effects, context ownership and adapter-local Drizzle remain binding. No accepted ADR body is rewritten in this research.

Main OD035 currently says the local engine is unresolved and preferred OpenWorkflow is only a spike candidate. PR90's owner-approved ADR0116 resolves that choice and retains the comparison as historical evidence. PR90 is not merged: report both the accepted branch decision and the integration state. Its stated remaining blocker is the required commit-author-identity policy, not a reopened engine comparison. This research does not bypass the protected check or merge PR90.

## Reused executable evidence and bounded new scope

The repository already contains real Agent Context tests `manifest-postgres.test.ts`, `postgres-disconnect.test.ts`, their `pg-fixture.ts`, and the existing production feature/migration. They cover concurrent duplicate immutable manifests, authorization/RLS isolation, exact negative microseconds, persistent restart, same-identity retry after a synthetic lost COMMIT response, atomic rollback when outbox append fails, and actual checked-out-backend termination during commands/migration. The lost response uses a Proxy after a real COMMIT; it is injected client observation loss, not a network partition.

OD003 also preserves historical helper/restore, transactional migration, pooling and PITR evidence with exact archive fingerprints. Those ZIP sources are not present in this restored Git checkout, so their historical assertions are not relabeled as locally rerun. It reports that the raw npm Linux payload contains `postgres`, `initdb`, `pg_ctl` but lacks `pg_dump`, `pg_restore`, `pg_controldata`. That can falsify a backup-capable distribution claim even while ordinary startup works.

### Planned falsifiable matrix

| Boundary | Hypothesis and falsifier | Real components / limitations |
| --- | --- | --- |
| Existing feature contracts | Existing manifest/disconnect tests pass with real native PostgreSQL and strict pinned TypeScript. Any contract assertion failure falsifies that row. | Unchanged feature, migration and tests; bounded synthetic tenant/project, no real user resources. |
| Actual payload/readiness | Selected approach resolves to the measured native engine; fsync, full_page_writes and synchronous_commit are on. Wrong engine/configuration, inaccessible native payload or root-only init failure fails closed. | Exact research package/payload, SQL identity; no installer/signing claim. |
| Crash during accepted work | A previously committed sentinel survives unclean server termination; an open uncommitted transaction does not become committed; fresh reopen works. Any contrary state falsifies. | Real native PostgreSQL process and node-postgres. Does not prove power-loss/filesystem durability. |
| Backup capability | Required helper payloads exist and a real backup restores into a different clean isolated root with exact readback. Missing helpers are an unavailable row, never a mock success. | Reuse historical source if restored; otherwise bounded fixture only when justified. No product-wide NATS/AR/blob recovery claim. |
| Resource/cleanup bounds | Owned clusters stop and no owned backend remains; fixtures stay within declared pool and time budgets. Timeout is failed/unresolved cleanup, not proof of absence. | Task-owned temporary roots/processes only. |

Plan estimate: **0 production LOC**, approximately **150–300 new fixture LOC**, excluding unchanged reused tests and generated/vendor files; x2 uncertainty. Confidence **8/10**, expected reliability of the bounded approach **8/10**, complexity **4/10** are engineering judgments, not uptime or achieved release results. No alternative production engine/launcher is proposed.

## Executed Linux evidence

The bounded experiment completed on Linux x64 with official Node **26.11.1**, pnpm **11.18.0**, TypeScript **7.0.2**, `pg`/`@types/pg` **8.23.1**, `@types/node` **26.6.5**, wrapper/distribution **18.4.0-beta.17**, and actual native PostgreSQL **18.4**. These are experiment inputs, not new production pins. The final frozen install, strict source build, strict original-test typecheck and strict new-fixture typecheck passed. `skipLibCheck` is **false** for all three fixture projects. Full owning-repository CI/lint/gates were not rerun by this fixture.

The existing Agent Context source and tests were copied byte-for-byte from main `aaabc1e7cd2e2482668530e4412e61c2bca1f515` into a disposable runtime. Their source SHA-256 map is `evidence/reused-source-manifest.json`. The public native-binary resolver is copied unchanged from PR90 `0af892165a023a274302f89b47ba514ab2915e59`. No shared source or accepted ADR was mutated.

| Executed surface | Result | Evidence and precise implication |
| --- | --- | --- |
| Existing `manifest-postgres.test.ts` | Passed | Real PostgreSQL restart, concurrent duplicate seeds, immutable-name conflict, input rejection, current authorization, forced RLS, exact `-1` microsecond, post-restart retry, synthetic lost-COMMIT response and atomic outbox failure rollback. |
| Existing `postgres-disconnect.test.ts` | Passed | Actual `pg_terminate_backend` while the checked-out command/migration transaction is held, typed unavailable result, no partial state/outbox, fresh usable connection, and ended-pool rejection. |
| Original suite total | **2/2 passed, 0 skips/failures** | `evidence/existing-feature-tests.log`; this is a small real-product feature boundary, not a complete Host/Dapr/NATS/AR deployment. |
| Native identity/durability configuration | Passed | Actual PostgreSQL18.4, data root and system identifier observed; `fsync`, `full_page_writes`, `synchronous_commit` all `on`. |
| Actual postmaster loss during public feature seed | Passed | The real feature stages both the new manifest and outbox before COMMIT. An independent connection sees only the previous committed row. Owned postmaster PID92678 exits with actual SIGKILL; its checked-out backend closes and the command rejects `UNAVAILABLE`. |
| Same-cluster crash recovery/readback | Passed | Fresh process PID92691 reopens the same physical data root and system identifier `7700546930572265959`; PostgreSQL logs automatic recovery. Fresh pools read exact committed manifest facts, negative microsecond and outbox identity; the uncommitted pair is absent. |
| Same-identity retry after crash | Passed | Retrying the pending public feature seed twice yields the independently expected two manifests and two corresponding outbox rows, exactly once per immutable manifest. This feature has immutable-manifest idempotency, not a separate generic command-receipt table. |
| Distribution backup/restore | **Unavailable; not passed** | `pg_dump`, `pg_restore`, `pg_controldata` are absent from the exact selected research payload. No external helper or fake restore was substituted. Historical helper qualification remains historical evidence. |
| Cleanup | Passed in this fixture | Final fast stop, actual postmaster exit0, and `pg_ctl status`3 observed. An external scan finds both known PIDs absent and no live PostgreSQL/initdb/pg_ctl command matching the task-owned roots. |

The new harness has **5 passing rows and 1 explicit unavailable row**. Its result is deliberately `passed-with-explicit-unavailable-backup` and `releaseQualification: false`. Sources are `runtime/crash-boundary.ts` and `runtime/postgres-binaries.ts`; raw results/logs are `evidence/crash-results.json`, `server-92678.log`, and `server-92691.log`. `execution-identities.json` binds native/tool/source/configuration hashes; `post-execution-process-check.json` preserves the independent process check.

### Isolation, failures and practical limits

The shell initially ran as uid0; PostgreSQL ran as the existing nobody uid/gid65534 in distinct private task-owned roots under `/tmp/plugin-validation-pg-runtime-20261025`. Databases use private Unix sockets with no TCP listener. Fixture `trust` authentication beneath a 0700 ancestor is a deliberately test-only profile and does not satisfy the production SCRAM/credential/ACL requirement. The data-root/socket profile is separate from the Temporal investigator's cluster and ports.

Initial attempts failed because pnpm's default store was unwritable, network access was restricted inside the sandbox, pnpm11 ignored the old package-level build allowlist, and nobody could not traverse the root-only `/workspace/scratch` parent. The final attempt uses a task-specific store, authorized package/network access, repository-matched workspace `allowBuilds`, and a task-owned readable runtime copy in `/tmp`. Failed logs remain in `evidence/`; no dependency source or gate was patched. One strict compile found a possibly undefined output directory; it was corrected before execution, without an assertion cast or weaker compiler options.

The new boundary harness launches the exact package's native payload with standard PostgreSQL process control and reuses PR90's resolver. It does **not** exercise or qualify the wrapper's global exit hook or complete Supervisor adapter. Actual postmaster loss differs from the original suite's client-backend loss and its synthetic lost-reply injection. SIGKILL is process-crash evidence, not power-loss/filesystem durability. The two observed postmaster exits and status check prove this fixture's stopped cluster, not generic custody across arbitrary descendants, a restarted Supervisor, or PID reuse. Pool maximums are two each (four normal connections across owner/runtime) and server `max_connections` is12; original tests retain their own declared pool caps. Observation bounds are timeouts, not performance claims.

An independent peer reviewed the new harness and found no blocking concern, while requiring these exact process-crash/custody and unavailable-restore limits. That review was not a second execution. Actual incremental code is **0 production LOC**, **194 new TypeScript fixture LOC**, plus **22 unchanged resolver LOC** and small project configuration. The selected experiment resolved its scoped question; no larger optional campaign is inferred.

## Release conditions that remain independently binding

Every released OS/architecture requires exact installed-package, executable/helper/native-library digest enforcement, signature/notarization, offline launch, credential/ACL cleanup, authenticated readiness and cluster identity, collision/foreign-process rejection, truthful wrapper-hook outcomes, concurrent ensure and generation-safe custody, Supervisor-death reconciliation, supported application/schema/engine transitions, and actual verified restore before dispatch. Windows and macOS do not inherit Linux results or generic Local Host Control CI.

Temporal additionally requires supported sequential server/schema upgrades when Desktop versions are skipped, representative N/N-1 histories and old Workers, interrupted upgrade recovery, history/retention bounds, long timers/clock changes, installed local resource budgets and concurrent-agent scale qualification, and engine/dependency exit evidence preserving business authority. OD005/021/040 and deployment qualification remain separate gates. A selected library and successful component experiment satisfy neither production implementation readiness nor release qualification.
