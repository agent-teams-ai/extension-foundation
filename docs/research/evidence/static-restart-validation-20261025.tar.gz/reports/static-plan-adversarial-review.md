# Adversarial review of the static-restart spike plan

Review date: 2026-10-25. Reviewer: current-storage-authority investigator. Scope: source inspection of current Get Modular recovery/semantic fixtures and the root-provided plan to reuse them unchanged, then exercise public graph preflight/selection and bounded repeated restarts. This is not an execution result.

## Disposition

Proceed with the bounded experiment. Reusing the existing public assembly/resource seams and unchanged recovery fixtures is preferable to a new Host, kernel, RPC stack or workflow coordinator. No blocking ownership defect is identified in that plan. The result must retain the following limitations and rejecting controls.

## Required claim boundaries

1. `tests/assembly/consumer-restart.test.mjs` explicitly emits `source: incomplete`, `custody: live-supervisor`, and `powerLossDurability: not-selected`. Its recovery Worker is restarted while its fixture Supervisor remains alive. It proves that scenario, not restarted-Supervisor discovery, OS-level orphan custody, durable leadership or PostgreSQL recovery. Fresh Worker PID/grant observations do not imply durable host incarnation fencing.
2. `SnapshotStore.replace` syncs a temporary file, closes it, and renames it. It does not sync the containing directory. This fixture is file-backed crash-boundary evidence, not a production WAL, complete persistence adapter, or power-loss guarantee. Do not import its store/Supervisor into production or interpret it as an alternative to selected PostgreSQL.
3. The existing fixture Supervisor has its own narrow IPC, synchronous incumbent allocation, one-shot launch permission, and actual sibling child handles. Those remain test scaffolding. Passing its own guards cannot establish conformance of an unimplemented product Supervisor, Agent Runtime, dispatch path or replacement coordinator. Preserve the emitted fixture labels and distinguish existing GM public implementation from these fixture policies.
4. An unchanged recovery suite is useful counterevidence because it checks late success after cancellation, actual child exit, live capacity retention, acknowledged versus unacknowledged effect state, and cleanup file debt. Report exact executed scenario identities and zero skips. Do not turn its total count into an achieved universal reliability score.
5. `semantic/tests/module/workload.test.ts` provides 64 observations across 16 retained instances, but its aggregate admission bound is test scheduling (`active >= 16`), and `createAttempt` has infinite local capacity for that test. Those results cannot qualify a production aggregate tenant budget or thousands of active plugins/agents. Count prepared descriptors, live resources, accepted work, parallel workers and churn separately.
6. Resource `CloseReport.complete/settled` alone is insufficient for claims about physical release. Existing semantic fixtures strengthen that with independent file-handle `EBADF` probes and journal ordering; recovery fixtures observe actual child exit and separate file cleanup debt. Keep those oracles. A watchdog kill is failed-test cleanup, never successful graceful drain.

## New repeated-restart falsifiers

The proposed extension should reject a bad public graph/candidate before changing canonical selection or starting candidate effects; prove the incumbent remains usable; and then demonstrate that the selected fresh graph actually handles post-activation work. In-flight work must remain pinned to its accepted generation and be drained or explicitly canceled before owned resource release. Probe released physical resources independently, inspect cumulative resource/process counts and cleanup debt, and retain a failed/timed-out candidate's capacity while startup/cleanup is still live.

Do not claim old-byte rollback from reselecting an old label. If that behavior is tested, bind immutable artifact/source identity and restore the old implementation as a fresh generation. A bounded sequence on one Linux Node runtime is component E2E evidence only; it is not Desktop/Windows/macOS, untrusted-plugin isolation, distribution/signing, universal replacement, or scale qualification.

## Cost and evidence judgment

Reusing these fixtures introduces **0 production LOC** and **0 modified historical fixture LOC**. The bounded new public-boundary test should remain roughly **100–250 test LOC**, x2 uncertainty, plus minimal run configuration. Confidence **8/10**, expected bounded-contract reliability **8/10**, complexity **4/10** are review judgments, not measured uptime. A fresh generic Host/Supervisor would materially worsen ownership and test independence and is outside the approved scope.

Sources inspected: `tests/assembly/consumer-restart.test.mjs`; recovery `src/{schema,store,supervisor,consumer}.ts` and `tests/recovery.test.ts`; semantic `tests/module/workload.test.ts`, at the task's restored Get Modular checkout `b70ba39304ac71964175c42a77309406a7c30ca2`. Root should bind the exact tested checkout commit/hash alongside execution evidence.
