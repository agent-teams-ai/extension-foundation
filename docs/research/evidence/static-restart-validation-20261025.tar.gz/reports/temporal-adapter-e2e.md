# Optional Temporal replacement-coordinator qualification

Observation date: **2026-10-25**. Research/component evidence; no production source, accepted ADR, release gate, or kernel was changed.

## Finding

**A real optional Temporal adapter can durably schedule a narrow update-operation receiver without putting ordinary GM module calls through workflows.** The unchanged full native Orchestrator fixture passed all 11 assertion scenarios on this Linux x64 environment. The added adapter passed7 scenario groups with actual Temporal service/Workers, native PostgreSQL, and the existing public-GM A/B child composition. Independent readback protected one canonical command commit across duplicate delivery and Worker death after COMMIT; a genuinely delayed Activity from an older scheduler epoch accepted no canonical mutation. A separate actual public-GM call succeeded with the Temporal frontend returning `ECONNREFUSED`.

This is sufficient evidence to keep Temporal **optional for the purpose-neutral plugin replacement coordinator**. It is not evidence that complete long-lived plugin replacement is implemented or qualified. The physical bridge deliberately reuses a finite one-shot composition as preflight; production admission, active-work drain, authoritative selection handoff, actual resource custody, external-effect ambiguity and recovery retain their existing owners.

Orchestrator's application-workflow choice is a different question and is already owner approved: ADR0116 selects **full native Temporal Service backed by PostgreSQL for Fully Local V1**. Its PR remains open because integration is blocked; stale main text does not reopen that decision. [Current PR90](https://github.com/agent-teams-ai/agent-teams-orchestrator/pull/90), [exact accepted ADR0116](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/0af892165a023a274302f89b47ba514ab2915e59/docs/decisions/0116-native-temporal-for-fully-local-durable-workflows.md).

## Current primary authority

The live GitHub API was read during this investigation, rather than relying on personal-context recollection. Its compact metadata and complete contemporary PR body are retained at `../experiments/temporal/authority/pr90-2026-10-25.json`.

| Source | Exact identity | Verified interpretation |
| --- | --- | --- |
| Orchestrator current main | `aaabc1e7cd2e2482668530e4412e61c2bca1f515` | Contains the older unresolved OD035/local-candidate text. |
| Orchestrator PR90 | `0af892165a023a274302f89b47ba514ab2915e59` | Open, non-draft, unmerged, `mergeable_state=blocked`; base is the main identity above. |
| ADR0116 in PR90 | Accepted, `approved_by: product-owner`, accepted2026-10-23 | Full native Temporal Service + PostgreSQL for Fully Local; resolves OD035's engine selection. |
| ADR0027 | Accepted owning contract | Application persistence owns business state; history owns engine execution progress; Activities call idempotent application usecases. Temporal remains an adapter. |
| OD005 | Still open | Owns first actual workflow/Worker placement, contracts, versioning, deployment and reconciliation; selection is not implementation permission for everything. |
| PR90 native CI evidence | Retained matrix run39988635688; PR body reports exact adoption-head run40009973655 | Earlier hosted component evidence, distinct from the local execution below. Linux11/macOS11/Windows10 assertions with one explicit Windows POSIX suspension skip. Assertion counts are not reliability scores. |

The live PR body identifies commit-author-identity policy activation as its remaining merge blocker. This task neither changed that policy nor bypassed a protected check. Main and accepted branch state are both reported. The selected native production engine is not the SQLite development server or an in-memory scheduler. ADR0116 explicitly retains separate implementation/release gates and treats its exercised versions as evidence pins. [ADR0027](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/0af892165a023a274302f89b47ba514ab2915e59/docs/decisions/0027-temporal-as-run-orchestration-adapter.md), [OD005](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/0af892165a023a274302f89b47ba514ab2915e59/docs/open-decisions/OD-005-temporal-workflow-boundary.md), [adoption-head native CI](https://github.com/agent-teams-ai/agent-teams-orchestrator/actions/runs/40009973655).

## Exact execution profile

| Component | Measured pin or identity |
| --- | --- |
| Operating system | Linux x64; this container only |
| Runtime/package manager | Node 26.11.1, pnpm 11.18.0; complete official shared toolchain |
| Own compiler | TypeScript 7.0.2; ordinary `.ts`, strict, noUncheckedIndexedAccess, exactOptionalPropertyTypes, noImplicitOverride |
| Temporal service and SQL migration tool | Official full native Server 1.32.1 distribution |
| TypeScript SDK | `@temporalio/client`, `worker`, `workflow`1.24.0 |
| Native SQL launcher/distribution | `embedded-postgres`18.4.0-beta.17; native PostgreSQL 18.4 |
| SQL client | `pg`8.23.1, `@types/pg`8.23.1 |
| Other execution dependencies | tsx 4.21.0, long 5.3.2, @types/node 26.6.5 |
| Existing physical bridge | Public `@get-modular/core`/`assembly`0.7.0, resources0.2.1; existing fixture test dependency conformance0.5.0 |
| Upstream GM source | `b70ba39304ac71964175c42a77309406a7c30ca2`; adjacent static-restart experiment's preserved TS/compiled child hashes |

Orchestrator's accepted composition profile still pins Core/Assembly0.5.0. The public0.7.0 child is an **external current-package component qualification**, not a silent product dependency migration or proof that the accepted0.5.0 pair was exercised here.

The task uses a frozen lock, engine strictness, exact dependency pins and retained integrity fields. Strict own-source typechecking passed. `skipLibCheck: true` is explicit, matching the owning PR90 research profile; this is not a dependency-declaration qualification. All maintained added JavaScript-runtime source is ordinary TypeScript.

Verified native artifact identities:

- Temporal archive `temporal_1.32.1_linux_amd64.tar.gz`: SHA256 `4260448d650c1ba7ee7683ff0c93d5c6a1709260e3a7ef543bfa34e06cff6051`.
- Matching source/schema archive: SHA256 `9a1766efcdc2acf03165e0304549d00930e18ff4fbf2c5abe27732fe7c04f7ee`.
- Measured native PostgreSQL executable: SHA256 `de0a4a7646c51f032e0088ae6fe9d0833fa280b78d4455681574a32937b32838`.

The unchanged bootstrap verified the first two digests on the actual downloads in each native invocation. It identified the PostgreSQL executable as x86-64 ELF and queried actual `version()`, `fsync=on`, `full_page_writes=on`, `synchronous_commit=on`. These observations do not certify upstream PostgreSQL 18.4 support for every Temporal release. Source/lock/native/shared-child hashes are in `../experiments/temporal/source-manifest.json`; full native summaries are retained beside both executed results.

## Real boundaries and deliberate fixture scope

| Boundary | Actual component | What was simulated or omitted |
| --- | --- | --- |
| Durable scheduling | Full native temporal-server frontend/history/matching/Worker services with PostgreSQL engine and visibility schemas | No fake service, SDK test server, Cloud account, Docker or SQLite development server. |
| Workflow execution | Real SDK Worker processes, deterministic workflows, durable timers and actual Activity dispatch/retries | Disposable operation types, namespace and task queues. No product workflow placement decision. |
| Application command acceptance | Real PostgreSQL transactions, row lock on selection, immutable operation-payload binding, stable command receipts and receiver-enforced epoch comparison | Receiver is80 lines of **test-owned** SQL authority. It is not the lifecycle kernel, production admission, product authorization or a second production canonical state. |
| Physical bridge | Existing finite `selection-child` with public GM composition, root calls, actual effect journal, resource scope, actual OS child exit and post-reap `ESRCH` observation | Repeatable preflight construction only. No long-lived Host active-work switch, production drain or AR custody. |
| Loss/retry injection | Actual Worker SIGKILL after durable COMMIT; actual service SIGKILL; actual Activity Worker SIGSTOP/SIGCONT before receiver SQL | Lost workflow-start acknowledgement is a deliberately discarded **actual successful response**, not a claimed network partition. |
| Ordinary invocation | Same existing public-GM child/root executes ordinary calls with Worker absent, then separately with service unavailable | No product public transport/authorization test. Workflow-list counts are supporting observations, not a globally fresh absence proof. |

No new Supervisor, RPC protocol, general scheduler, generation runtime, lifecycle kernel, or production package was introduced. The Local Supervisor/AR physical-custody boundary was not reassigned. The two-slot Activity/two-slot Workflow configuration in the new adapter and four-slot configurations in the unchanged baseline are bounded fixture settings, not active-plugin capacity measurements.

## Unchanged full-native baseline:11 assertion scenarios passed

The PR90 fixture source and bootstrap were reused unchanged. Actual result: `../experiments/temporal/results/baseline/results.json`; native summary and all Worker/service logs accompany it. One separate resource snapshot is excluded from the assertion count.

| Scenario | Actual result and meaning |
| --- | --- |
| Separate migration/runtime authority | Runtime DDL was denied after matching SQL-tool migrations; not a complete production secret/ACL audit. |
| Early and duplicate approval | Actual application state/receipts produced one activation effect. |
| Approval committed without workflow signal | A durable Temporal timer reread authoritative application state and recovered the lost wake; production outbox remains required. |
|80 durable parked waits | Control and cancellation progressed within fixture bounds; parked waits release Workflow slots. This is not80 active Agents/plugins. |
| Worker death after business COMMIT | Real SIGKILL before engine acknowledgement, then a replacement Worker retried; two observed attempts, one canonical activation effect. |
| Worker and full-service death through a durable timer | Both real processes were killed/restarted; one persisted timer-start event and one timer-fired event led to application readback. |
| Compatible patched Worker update | A pending execution resumed with patched code. |
| Fresh workflow on patched Worker | Patch marker was present in actual history. |
| Incompatible replay negative control | Actual nondeterminism failure was observed; no application effect occurred while blocked; patched Worker recovered it. |
| Cancellation | Application cancellation and engine cancellation agreed, with no activation effect in this fixture; this does not establish physical termination of arbitrary external work. |
| Paused predecessor resumed | Actual POSIX suspension/replacement/resume retained one application effect by receipt protection; timeout did not terminate the predecessor or fence external effects. |

The resource snapshot, for context only, reported a cold gRPC-ready launch after schema setup/PostgreSQL startup and sampled Linux `/proc` RSS. It is a single observation, not a benchmark, memory budget or supported-hardware qualification. Raw values are retained without promoting them to product targets.

## Added optional-adapter matrix:7 scenario groups passed

Primary actual result: `../experiments/temporal/results/adapter/results.json`. Physical records are separate from SQL canonical acceptance; an Activity delivery, a preflight construction, a Workflow timer and a committed application command are different facts.

| Group | Independent observed state/evidence | Scope of conclusion |
| --- | --- | --- |
| Workflow→Activity→existing GM child, A→B→A | Three selection receipts, three accepted canonical commands and three finite GM children. Same compiled A provider bytes/digest were restored as a fresh composition identity. Actual child values/journals and natural exits retained. | Durable adapter reaches a real public composition boundary. First A acceptance starts from fixture-default A; the count is accepted commands, not three physical Host switches. |
| Lost start response, duplicate command and conflicting payload | Retrying after discarding a successful start returned the same runID `01a17293-5bb0-73f1-ba0d-8e7d7cf745f5`; duplicate command delivery produced one receipt/effect and one preflight construction. Changed payload under the same operation identity was rejected. | Stable operation identity plus application receipts close this tested ambiguity. No exactly-once external execution claim. |
| Direct/Temporal substitutability | The same `executeUpdate`/receiver accepted the direct call and returned a replayed receipt through the Workflow; two deliveries, one canonical commit, one construction. | Optional scheduling adapter does not own a second business implementation. Receiver remains test-owned. |
| Worker killed after receiver COMMIT, before Activity acknowledgement | Worker98687 actually exited by SIGKILL. Before replacement: one receipt/effect/delivery. After replay: two deliveries, still one receipt/effect and one construction. | Real at-least-once Activity retry needs the receiver's durable receipt; engine acknowledgement is not the business receipt. |
| Delayed actual Activity after scheduler epoch change | Actual first Activity reached the pre-SQL boundary; its Worker was SIGSTOPed, SQL epoch advanced 1→2, then SIGCONT/release. Old Activity returned stale: **zero receipts/effects**. Current epoch then produced one receipt/effect. | Receiver transaction enforces scheduler authority at acceptance after awaits. It does not make an already dispatched task or external effect disappear. |
| Ordinary public GM calls with coordinator Worker absent | Worker98809 was killed/reaped. Same public-GM child executed two ordinary root calls and naturally exited. Observed namespace execution count stayed9→9. | This concrete ordinary invocation does not require a Workflow Worker. Source and real calls support the boundary; list visibility alone is not the proof. |
| Durable operation after Worker and full native service death | Worker98809 and actual temporal-server97408 were killed, not just a Workflow client. Replacement service99587/Worker99622 resumed the same persisted timer; exactly one timer-start and timer-fired event, one canonical receipt/effect in PostgreSQL readback. | Durable engine recovery is exercised separately from physical plugin lifecycle recovery. PostgreSQL stayed running throughout these engine-process crashes. |

The new suite's `ownedServiceAndWorkersReaped=true` is backed by awaited child exits and `kill(pid,0)` returning `ESRCH` for those exact children. The native bootstrap also reports `databaseStopped=true` with actual PostgreSQL shutdown logs. This is bounded task cleanup evidence; it is not a complete Supervisor descendant-custody or arbitrary PID-reuse proof.

### Stronger ordinary-call and physical-output checks

After the suite had stopped the service and Workers, the additional probe required **actual `ECONNREFUSED` from 127.0.0.1:27233** before invoking the same public-GM root. It then observed the expected A results, journal and natural child exit. A timeout or an unexpected live service fails this probe. Output: `../experiments/temporal/results/adapter/offline-ordinary.json`.

An independent artifact oracle read the actual raw child receipts, rather than trusting their A/B tag. It validated each returned value and journal effect against the requested provider/identity, complete/debt-free scope closure, actual recorded process exit, stable provider bytes and stable composition digest per A/B. It observed **10 distinct finite composition identities** in the native adapter run. Twelve copies of physical receipts occur across before/after snapshots; these are not 12 physical constructions. The separate offline ordinary probe adds another independent child invocation and is not folded into that 10. Source and successful output: `fixture/verify-evidence.ts`, `logs/independent-physical-receipts.log`.

### The stale-epoch case exposes an important limit

The resumed old Activity accepted **no canonical application mutation**, but it still performed **one repeatable preflight child construction** before the receiver's final SQL check. The current-epoch attempt then performed another preflight and accepted one canonical command. This is intentional and visible in separate `constructions` and `receipts` tables.

Therefore the experiment directly rejects the stronger claim that Temporal timeout, scheduler ownership, or a SQL receipt automatically provides exactly-once physical lifecycle/external effects. A real mutating physical command must cross the existing custody owner's own idempotent/fenced receiver with stable operation and execution-incarnation identity, or preserve unknown-outcome debt and reconcile. The test's harmless one-shot preflight cannot substitute for that production boundary.

## Failed attempts and corrections retained

The initial environment had no Docker/native PostgreSQL/Temporal binary and default Node 24.22.1. The exact Node 26.11.1/pnpm 11.18.0 toolchain was supplied by root before execution. Default-sandbox network access failed at an unavailable browser proxy; the approved network/process boundary with `NODE_USE_ENV_PROXY=1` downloaded the verified official artifacts.

The first unchanged baseline attempt initialized PostgreSQL but could not write precreated outputs under uid 65534. It failed with EACCES and shut down the database. Task-only ownership correction through the approved process boundary fixed the environment; the second unchanged invocation passed. A default-sandbox chown and later copy also failed because of uid/file ownership mapping; no source/dependency patch or weakened test was used.

The first added adapter attempt failed because the reused GM child required `@get-modular/resources`, omitted from the initial task manifest. Real Activity retries exhausted, the Workflow failed, and all owned components stopped. Its actual failure JSON/console/service/Worker logs and redacted configuration are retained under `results/adapter-attempt-1`. Exact public fixture dependencies were added; the same adapter source then passed. The before-correction manifest there is explicitly reconstructed, not labeled original file bytes.

The first strict typecheck found that a narrowed unknown property was not retained inside a closure; capturing the numeric PID in a const fixed it without suppression. One final offline-probe staging command used the wrong working directory and failed before executing any test; the corrected absolute source path passed. `logs/attempt-ledger.json` records all of these, including source/evidence paths. None is discarded from the record or counted as an engine pass.

## Code cost, alternatives and recommendation scope

**Actual new production/integration source:0 lines.** All additions are disposable fixture/evidence code. There are **453 new TS fixture lines**:153 adapter-shaped/test-receiver/bridge lines and300 driver/oracle/ordinary-probe lines. The physical bridge itself is28 lines. An additional 300 TS lines are unchanged reused bootstrap/asset/initializer/path helpers, excluding the separately retained unchanged baseline and the adjacent reused GM fixture. These counts exclude lockfiles, generated JS and dependencies. They are not a production implementation estimate.

The following comparable estimates concern incremental work above an already owned Host/custody/persistence contract, which this task did not implement. Scores are engineering judgments for this bounded mechanism, **not uptime**. Estimates have approximately×2 uncertainty and exclude native installer/signing, full product migrations, observability and ongoing vendor operations unless stated.

| Optional replacement-coordinator choice | Confidence/10 | Expected reliability/10 | Complexity/10 | Estimated new production/integration LOC | Estimated additional tests/fixtures LOC |
| --- | ---: | ---: | ---: | ---: | ---: |
| Accepted static composition/controlled restart using existing owner's durable operation ledger and recovery |8|8|4|150–400|300–700|
| Optional Temporal adapter when the consuming product already operates the selected service/Worker family |8|8|6|120–300 adapter lines, above the shared owned command/lifecycle baseline|250–600 focused adapter/real-stack lines, above shared conformance|
| Introduce and maintain full native Temporal solely for a neutral plugin mechanism that otherwise needs no workflow engine |5|8|9|1,500–4,000 lifecycle/distribution/integration lines plus the owned baseline; platform maintenance dominates|800–2,000 plus OS/release matrix|

The second choice is plausible for Orchestrator because its application workflows already select the engine family; it does not make Temporal mandatory in EF, GM, a neutral plugin library or an ordinary invocation. The third choice has substantially more operational scope and is not justified by this narrow scheduling need alone. No alternative application workflow engine is proposed or adopted here. The baseline choice remains static composition with controlled restart; use an optional adapter where its durable operations add value.

## Unqualified boundaries and next concrete integration gate

1. **Long-lived active replacement is unqualified.** The next meaningful product gate is to drive the same command contract through the actual product admission/dispatch and existing custody owner: accepted-work affinity, drain/seal, startup/cleanup debt, exact old/new generation selection, execution-incarnation binding and receiver epoch, cancellation versus settlement/physical absence, and unknown external effects. The adjacent recovery fixture's stop-admission counterexample reinforces why a finite one-shot child cannot stand in for that gate. Do not fix it by adding a second Supervisor or copied kernel.
2. **No product transport/trust proof.** This matrix omits Host public APIs, Dapr, NATS/outbox transport, AR and real authorization. Application receipts and epoch enforcement here are fixture-owned SQL transactions. Accepted existing owners/contracts still govern production integration.
3. **New adapter OS matrix is Linux x64 only.** macOS arm64 and Windows x64 hosted results belong to the unchanged earlier engine fixture. The added adapter and offline probe were not run there. Linux arm64, macOS x64 and Windows arm64 were not executed in this task. POSIX SIGSTOP/SIGCONT requires an explicit Windows equivalent.
4. **Release lifecycle remains open.** Signed/offline installation, native notices, protected endpoints and restricted users, port conflicts, suspend/resume and clock changes, skipped-Desktop sequential Temporal server/schema upgrades, N/N-1 histories, interruption/rollback/restore, history/receipt retention and dependency exit remain binding ADR0116 conditions.
5. **Restore and active scale are not proven.** The separate storage investigation found the exercised npm payload missing backup/restore helper binaries; no substitute is silently counted. Parked workflows and sampled RSS establish no active-plugin/agent capacity, churn, compiler scale or installed hardware budget.
6. **The harness has no universal per-scenario wallclock deadline.** Readiness/boundary polls are bounded and Activity retries are finite, but each Workflow `result()` await lacks a separate enclosing wallclock deadline. Both observed native commands completed and cleaned up. Before CI reuse, add a declared whole-process-group/job timeout with cleanup-debt reporting; do not treat the original plan's60-second poll bound as enforced for every possible failure path.

The complete reproducible source, exact pins, raw actual histories/configs/results, source manifests, failed attempts and commands are retained under `../experiments/temporal`. Current decision selection, optional mechanism evidence and remaining product/release gates remain separate.
