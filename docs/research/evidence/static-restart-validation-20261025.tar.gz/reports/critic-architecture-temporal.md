# Independent architecture and Temporal critic

Review date: 2026-10-25. Scope: the owner-confirmed static composition and controlled restart direction, current accepted responsibility boundaries, and the optional Temporal adapter's actual evidence. This review inspected source, exact checkout identities, retained execution logs/results, and evidence hashes. It did **not** independently rerun the native engines, repeat the static fault campaign, inspect a production deployment, or perform another live PR-status check. No production source or accepted ADR was changed.

## Decision

**Keep the selected baseline and proceed only to a bounded actual-product integration slice.** The reviewed sources support immutable composition selected at startup and a controlled restart that may include downtime. The optional Temporal experiment demonstrates real durable scheduling around the same narrow test-owned command receiver. Neither experiment qualifies a complete long-lived product replacement mechanism.

There is one present behavior blocker to promoting the reused recovery fixture unchanged: its required seal-before-stop property fails in both profiles. Two further claim boundaries are material: stale Temporal scheduling is fenced at the SQL mutation boundary after repeatable construction preflight, and the Temporal fixture skips dependency declaration checking. Neither finding requires a new Host, a replacement kernel, a different database, or reopening the selected application workflow engine.

## Authority and exact pins

The inspected checkouts have these HEADs: GM `b70ba39304ac71964175c42a77309406a7c30ca2`; Orchestrator main `aaabc1e7cd2e2482668530e4412e61c2bca1f515`; PR90 `0af892165a023a274302f89b47ba514ab2915e59`. The live-state observations are retained by the owning storage investigator in [current-storage-and-postgres.md](current-storage-and-postgres.md) and its metadata artifacts. This review confirms their content against those exact local sources, rather than claiming a second live status observation.

| Decision | Reviewed responsibility and limit |
| --- | --- |
| [Orchestrator ADR-0114](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/aaabc1e7cd2e2482668530e4412e61c2bca1f515/docs/decisions/0114-canonical-backend-stack-and-distributed-role-adoption.md) | Native PostgreSQL for local and hosted authority; context-owned schemas/transactions; Supervisor component adapter uses the selected `embedded-postgres` approach. Its adopted central backend reference remains exact `4dcf4ffe29279e479e089bc06f745dd1a62f12d1`. The research wrapper version is not a production distribution pin. |
| [ADR-0115](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/aaabc1e7cd2e2482668530e4412e61c2bca1f515/docs/decisions/0115-canonical-fully-local-v1-adoption.md) | Fully Local is mandatory V1 scope, with shared business implementations and independent native release evidence. Supervisor availability custody does not absorb Orchestrator business policy or AR provider custody. |
| [ADR-0116](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/0af892165a023a274302f89b47ba514ab2915e59/docs/decisions/0116-native-temporal-for-fully-local-durable-workflows.md) | Owner-approved accepted branch decision selecting full native Temporal Service with PostgreSQL. PR90 remains unmerged in the retained status observation. Engine selection and release qualification are separate. Its engine-history authority cannot replace feature-owned operations, receipts, cancellation cutoffs, fences, outbox or recovery. |
| Orchestrator ADR-0113, inspected by the static investigator | The adopted Core/Assembly baseline remains 0.5.0 and Consumer Module Standard revision `a3a079baca2c6af48c9d45bc08992825be1c2bbd`. Registry 0.7.0 evidence does not update those pins or admit production dependencies. |
| [GM ADR-0029](https://github.com/agent-teams-ai/get-modular/blob/b70ba39304ac71964175c42a77309406a7c30ca2/docs/decisions/0029-admit-an-optional-lifecycle-kernel-candidate.md) | One optional local synchronous lifecycle-kernel candidate. It has no I/O, callbacks, promises, clocks or product authority; the inspected manifest still has `private: true`. Source/candidate tests do not authorize publication or product adoption. Static setup does not require the candidate. |

Earlier SQLite and unresolved-local-engine descriptions must retain their historical identities while current guidance follows these bounded supersessions. Optional plugin rollout scheduling remains distinct from ADR-0116's application workflow choice. The current synthesis gets this distinction right.

## Findings and dispositions

### A1 — Missing stop admission seal: actual blocker to fixture promotion

**Severity:** high for an implementation claiming rejection during stop; bounded fixture defect, not an established GM Core/Assembly defect. **Disposition:** confirmed by independent source/log inspection; unresolved behavior remains red.

The unchanged recovery Worker sets `closing = true` in its `stop` branch, but its `submit` branch still calls `OperationOwner.submit`. That owner checks storage freezing, duplicate identity and capacity; neither path rejects a new identity because shutdown has begun. The physical Supervisor's reservation becomes available after effect exit, allowing the new record to persist while a held launch acknowledgement keeps `stop()` unresolved. Sources: `experiments/static-restart/upstream/recovery/src/worker.ts:142–150,185–191`, `operation-owner.ts:34–40,56–70`, and `tests/stop-admission-counterexample.test.ts:7–49`.

The retained TAP log `experiments/static-restart/logs/stop-admission-with-recovery.log` reports **0/2 passing required rejection assertions**, with `admittedDuringStop:true` in each profile. It also documents what happened to the unexpected acceptance: `record-only` preserves a pending record without automatic dispatch; `restart-pending` resumes it to a successful real child result. **The evidence does not show durable data loss.** The defect is the promised ingress contract and ownership handoff, with a resulting possibility of unexpected queued work.

A product can deliberately accept durable work into a separate stable ingress during executor unavailability, but that must be its explicit product contract and owner. These tests instead require this old receiver to reject new identities while stopping. Relabeling their failure as intentional queueing would change the tested contract.

**Falsifier/closure:** the actual product receiver atomically seals new acceptance before drain proceeds, accounts for submissions already crossing the acceptance boundary, preserves duplicate lookup/original outcomes according to its contract, and passes the held-ack/effect-exit scenario against its real persistence and custody adapter. A `closing` flag tested only at dispatch cannot close this finding.

### A2 — Temporal stale epoch protects canonical SQL mutation, not all candidate execution

**Severity:** material claim qualification; high if promoted to effect-authority fencing. **Disposition:** acceptable within the fixture's explicitly repeatable preflight scope; retain the limitation prominently.

`fixture/temporal/bridge.ts:22–27` records delivery, checks for a receipt, performs real finite GM construction, records construction evidence, and only then calls `applySelection`. `receiver.ts:41–65` locks the canonical selection row and compares scheduler epoch before inserting a new receipt and updating selection. Therefore an old Activity can still construct and invoke the candidate before its stale SQL mutation is refused.

The raw result confirms this: in `results/adapter/results.json`, `delayedActualActivityRejectedAfterSchedulerEpochChange.afterDelayedActivity` has **one construction, one delivery, zero receipts and zero canonical effects**, with scheduler epoch 2 and candidate A unchanged. The fresh epoch then produces construction 2 and one receipt/effect. `run.ts:185` already states the exact physical limitation correctly.

Safe claim: **a delayed real Activity is refused by the same transactional receiver after an epoch change, without a new canonical selection mutation.** Unsafe claim: a stale scheduler cannot execute candidate code, acquire resources, or cause external effects. The tested child naturally exits before SQL selection acceptance; it is not an activated replacement.

**Falsifier/closure for stronger authority claims:** real effect receivers enforce current authority, with an exact execution/custody contract around preflight and acquisition; adversarially resume old attempts after transfer and independently observe no unauthorized effect. An early epoch read alone would leave a check/use race. Repeatable preflight must remain effect-safe or retain explicit cleanup/unknown-outcome obligations.

### A3 — Real native Temporal E2E, intentionally narrow application seam

**Severity:** evidence interpretation. **Disposition:** useful positive evidence; reject a production replacement claim.

The seven new groups are present and passing in the retained result: A/B/A finite construction; discarded actual start response plus same-ID retry/conflict; direct/Temporal use of the same receiver; actual Worker SIGKILL after application COMMIT and before acknowledgement; paused actual Activity across epoch change; ordinary GM execution with no Worker; and persisted timer progress through Worker and full native Service death. The experiment uses actual native Service 1.32.1, SDK 1.24.0 and PostgreSQL 18.4 on Linux x64. The unchanged baseline separately reports eleven assertions.

This is substantially stronger than a mocked scheduler or hand-coded successful transition model. The SQL receiver, scope/operation identity, candidate labels, effect counter, process setup and authorization model are still test-owned. `receiver.ts` itself says it is not production ownership or a lifecycle kernel. `bridge.ts` labels construction as repeatable preflight rather than a physical switch receipt. There is no actual product authorization, artifact/trust admission, AR process contract, long-lived active graph, admission seal, accepted-work transfer, schema migration, or Desktop updater in this adapter.

The independent artifact oracle retained at `logs/independent-physical-receipts.log` checks actual values/effect records, distinct A/B byte hashes and plan digests, close reports and observed child exit. It counts **10 distinct finite composition identities**, rather than counting twelve repeated receipt snapshots as twelve executions. `results/adapter/offline-ordinary.json` additionally records an ordinary call with the service port returning `ECONNREFUSED`. These strengthen the narrow physical/output and scheduler-independence claims, while leaving production custody unqualified.

**Falsifier/closure:** an actual product slice uses its existing owned command/operation, public package pin, authorization, persistence and physical custodian through unchanged direct/Temporal behavior scenarios. Success-only reconstruction of this receiver in another fixture would not close that integration gap.

### A4 — Strict own-source checks are not dependency declaration qualification

**Severity:** reporting precision. **Disposition:** retain the exact toolchain exception.

`experiments/temporal/tsconfig.json` has `strict:true`, `noUncheckedIndexedAccess:true`, `exactOptionalPropertyTypes:true` and `skipLibCheck:true`. Static and PostgreSQL reports describe `skipLibCheck:false`. Aggregate statements that all tracks passed strict dependency declaration checking would be false. The Temporal fixture may accurately report strict own-source typechecking with dependency declaration checking skipped. This review did not diagnose the motivating dependency error or authorize relaxing any owning production gate.

**Closure:** preserve the exception in the report/reproduction profile, or pass an actually stricter configuration and retain its result. Do not infer the stricter result from runtime execution.

## Clean Architecture, DRY and ownership assessment

The selected direction respects the existing split: GM owns inert declarations, graph construction and its admitted resource semantics; EF owns neutral artifact/trust/lifecycle requirements and conformance; product features own extension contracts, actual grants, canonical selection, operations and recovery; AR owns provider execution custody; Local Supervisor owns its admitted native service availability. Multiple scoped component owners are legitimate. The forbidden duplication is two independently advancing owners of the **same** process, operation or authoritative fact.

One semantic mutation owner need not be one global daemon, one process, or one queue for every plugin. ADR-0114 permits qualified concurrent writer replicas under owner constraints and transactions. Scaling should preserve per-scope ordering/fencing and aggregate resource budgets, rather than introduce a universal plugin manager or serialize unrelated products through one coordinator.

The fixture's direct/Temporal paths genuinely call the same function, but that does not by itself establish production Clean Architecture conformance. Its `bridge` directly imports a concrete SQL receiver and is intentionally test scaffolding. In production, Workflows/Activities and database details remain outside domain/application; an adapter invokes the existing consumer-owned application port. No extra domain layers are needed around this disposable script merely to make it look like production.

**Reusable mechanism** means shared driver code and contracts where semantics are actually common, under one product-authorized operation and receiver. It does not mean sharing product state, canonical selection, grants, business schema, physical resource handles, or a universal plugin interface. Reuse GM composition and resources; use the existing lifecycle candidate only if its exact dynamic contract is required and separately admitted; use the existing execution owner; reuse existing receipts/outbox/operation primitives. A simple full restart need not wait for public lifecycle-kernel release. Conversely, a shared driver must not privately reimplement the candidate's lease/generation state machine to evade its gates.

No residual package is yet established by the direct/Temporal fixture alone. The same product use case can have both adapters without a separate repository. Before extraction, identify a second real consumer or concrete repeated need, subtract existing responsibilities, and demonstrate the stable residual contract and its admission/conformance requirements. This follows the reviewed Engineering Quality Standard's explicit distinction between shared semantics and similar-looking code.

Static composition can support an evolving installed plugin set: selection is frozen for one execution owner and the next accepted installation/profile produces a new graph at restart. Product-owned extension families provide narrow contracts and approved loader/admission seams; authors need not fork product invariants. This campaign does not yet prove that full installation/loader author experience. Nor does N1000 graph or compiler evidence imply a thousand concurrent active plugins, process trees, pooled connections, histories or safe restart cohorts. The current Node/browser result is useful exact static-package parity; it does not supply browser physical custody semantics.

## What Temporal adds and what remains with the operation

The demonstrated benefit is durable timer/execution progress through Worker and Service death, retry delivery after the commit/ack gap, and a common mature engine family where the product already selects Temporal. Ordinary composition/capability calls remain possible without scheduling availability. For one short controlled restart that can be retried/read back at its existing owner, a direct adapter can be enough. Temporal becomes useful when the actual operation needs durable multi-step waits, retries, approvals or long recovery across coordinator restarts.

The application still owns command identity/fingerprint, receipts, canonical state, cancellation cutoffs, scheduler epochs, external-effect debt, authority and reconciliation. Temporal history records engine progress; it is not a second copy of authoritative product state. The fixture's operations are inserted before the engine start, but it does not implement a feature-owned outbox/reconciliation dispatcher that closes every lost wake. ADR-0116 keeps that production requirement. The native engine choice does not make another general custom scheduler or workflow DSL necessary.

## Planning alternatives and bounded code costs

Scores are engineering judgments out of 10, not observed uptime. Reliability denotes achievable behavior **within the named scope after its prerequisites are met**. LOC estimates carry approximately x2 uncertainty; production/runtime and product integration columns are disjoint handwritten new-code scopes, excluding existing GM/AR/native service code, generated bindings, domain changes and signed release/installer work. They are alternatives/increments, not a complete project budget.

| Option | Confidence | Reliability | Complexity | New shared/runtime LOC | New product integration LOC | New tests/fixtures LOC | Prerequisites |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Direct full controlled restart, downtime allowed | 8 | 9 | 4 | 0 | 150–500 | 600–1,400 | Existing real operation/persistence/custody seams; actual seal-before-stop and accepted-work contract. This excludes implementing those absent subsystems from scratch. |
| Optional Temporal adapter to that same qualified operation | 8 | 9 | 5 | 80–220 | 70–230 | 500–1,100 | Existing admitted engine/Worker lifecycle and operation; owned notification/reconciliation path; receipts and receiver fences. Incremental to the direct operation, not a replacement for it. |
| Extract an additional neutral driver package now | 4 | 7 | 6 | 100–300 | 100–250 per consumer | 500–1,000 | Stable residual semantics demonstrated in real consumers, package owner and exact admission evidence. Defer extraction until those facts exist. |
| Transparent overlapping generations/stateful hot replacement | 3 | 7 | 8 | Not estimated here | 800–2,000 | 1,500–3,500 | Separate accepted scope, dynamic-kernel admission if used, accepted-work affinity, exact effect fences and state/schema compatibility. Unexecuted comparison; outside this baseline. |

Actual incremental production implementation in this campaign remains **0 LOC**. Do not use a small optional-adapter estimate as the cost of producing the full native release, upgrading arbitrary histories, implementing custody, or supporting hostile third-party extensions.

## Safe next implementation boundary

Choose one real product extension family and explicitly permit restart unavailability. Keep its current accepted package/adoption pins. Its product-owned operation should accept an admitted immutable candidate/profile, seal the actual ingress, record the disposition of accepted work, ask the existing custodian to stop/reconcile the exact old execution, construct and verify the next graph, and reopen only when the owned readiness and recovery contract permits. Old bytes restored as a fallback receive a fresh execution identity. Unknown exit, ambiguous effect or cleanup debt remains visible and consumes the appropriate budget.

Use one canonical operation/selection owner. Let a direct driver or optional Temporal adapter request the same idempotent transitions, with current receiver-enforced authority. Keep library release, production package admission, stable SPI independence and full deployment qualification as their distinct existing gates. The next useful evidence is that real slice's boundary behavior, not a larger substitute Host fixture.

## Review evidence custody

The inspected Temporal `source-manifest.json` contains 62 source/configuration entries and 50 shared static bridge entries. A local SHA-256 comparison found no mismatches among the currently present listed files. This is byte-consistency checking, not a second source-build, native execution or full provenance/signature audit. Important reviewed identities:

| File | SHA-256 |
| --- | --- |
| ADR-0114 at inspected main | `810d93cc4e531064c8c2397069d7356d0ff71e61433cde2355db6bdb1e4582fb` |
| ADR-0115 at inspected main | `5d59e63db6dea5ff6a60d04cd0c9b634abb371f25d57f88f0df87130b0cc8805` |
| ADR-0116 at PR90 head | `8c170317a54f6352a256b8e11ddda519f529cd5e7948fbac0b3af62156b707e9` |
| Temporal `fixture/temporal/bridge.ts` | `52f22ceea3341a904b1c8c7b6b5c8665ad1076ccb26ae9514549415a8b428cd3` |
| Temporal `fixture/temporal/receiver.ts` | `8b38ddd684b0dd7d26c4192c71dba829e32d7efeaa8d58e71680c664d711786b` |
| Temporal `results/adapter/results.json` | `a9b650f333ef4c3e6ca17ac600242a50132a379aba6f0c7e0ecc1f9acfaf1e92` |
| Static admission log | `4574fab6ebb52bd2d633e21a83d9d0a76ba6a78805041e760fb644f43e1cffaa` |

Additional inspected sources: the full shared `context.md`; current static/PG reports; static source/logs cited above; GM system boundary and lifecycle candidate decision/manifest; the saved organization Engineering Quality Standard; Temporal baseline/native summary, Activity/Workflow/receiver/bridge/harness, strict project configuration, original failed adapter attempt, physical-output oracle and offline ordinary-call artifacts. Root owns final documentation integration and live-status freshness at publication.
