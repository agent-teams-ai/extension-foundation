# Independent critic: static restart and PostgreSQL executable evidence

Date: 2026-10-25. Review target: the complete shared `context.md`,
`static-restart-e2e.md`, `current-storage-and-postgres.md`, and
`static-plan-adversarial-review.md`, together with their retained sources and
raw evidence. This is an adversarial review and one independent Linux
counterexample execution. It introduces **0 production LOC**, no Host, no
supervisor, no RPC stack, no kernel and no shared source edits.

## Disposition

**Publish the bounded research with its failing admission property and
unavailable restore row intact. Keep static composition plus controlled restart
as the owner-approved baseline. Do not promote the recovery fixture unchanged
into a product restart adapter, or label the combined campaign production E2E.**

The principal failure is independently reproduced: after stop has begun,
revocation has been observed and the old physical effect has exited, the still
connected worker accepts a distinct new operation and durably records it. Its
dispatch gate is closed, but its acceptance boundary is open. This is a real
fixture-policy counterexample; it neither indicts Get Modular's graph
construction nor transfers product admission ownership into that library.

The PostgreSQL evidence is materially stronger than an in-memory model: it
uses the actual product feature, real SQL and a real native postmaster crash.
It still does not integrate the restart receiver with PostgreSQL and existing
Agent Runtime custody. Restore, full custody-owner loss, release packaging and
scale remain unqualified. The reviewed reports state these limits accurately.

## Findings and required dispositions

### F1 — High for product promotion: stop does not seal acceptance

**Evidence:** `experiments/static-restart/upstream/recovery/src/worker.ts`
lines 135–142 and 185–191; `operation-owner.ts` lines 56–70;
`logs/stop-admission-with-recovery.log`; independently,
`experiments/critic-restart/counterexample-sandbox.log` and its command JSON.

The causal chain is visible in source and executable evidence. Stop sets
`closing=true`, asks existing operations to stop and awaits outstanding
dispatches. `schedule()` and dispatch checks use that flag. The submit command
still calls `OperationOwner.submit()`. That owner checks identity/conflict,
record cap and a physical-capacity reservation, then persists the pending
record; it has no closing state. Once the first effect physically exits, the
capacity reservation can succeed while a held launch acknowledgement keeps
the old worker's stop in flight. Capacity availability is therefore mistaken
for permission to accept new work.

The independent run uses the existing named barriers and unchanged test, not
a sleep or speculative interleaving. It reports `admittedDuringStop:true`,
two canonical records, `occupied:0` and `reserved:true`. After acknowledgement
release and joined stop, a fresh `record-only` worker reads the exact new
pending record; its duplicate does not create another record or launch. The
desired assertion fails with actual `true` versus expected `false`, exit 1,
0 passed/1 failed/0 skipped. The producer's two-profile log separately shows
the `restart-pending` disposition reaching SUCCESS with one fresh real child.
No data loss is demonstrated.

**Disposition:** retain the red test and original source. The first product
slice must enforce its permanent acceptance seal at its actual authoritative
receiver before draining. Preserve identity/conflict readback for earlier
accepted commands, actual accepted-work affinity, failure persistence and
existing physical custody. Do not add another independently advancing
coordinator or duplicate kernel to repair a fixture policy gap.

**Falsifier for the eventual correction:** under the same held-ACK/revocation/
physical-exit ordering, a distinct new identity receives the specified stopped
rejection, creates no canonical record and consumes no new reservation. Existing
accepted identities remain readable/idempotent as the product contract defines.
Both profiles and the real product receiver must satisfy that oracle.

### F2 — Medium for future requalification: current red witness also assumes the defect occurred

**Evidence:** `experiments/static-restart/tests/stop-admission-counterexample.test.ts`
lines 31–49. After recording `admittedDuringStop`, the test unconditionally expects
the candidate to exist on the next worker, and `restart-pending` first waits for
it to be claimed. A correctly rejected candidate would fail the later readback
assertion, or wait for a claim that should never occur, before reaching the final
seal assertion.

This does not undermine the present counterexample: the observed acceptance,
durable record and incorrect final boolean are explicit. It means the present
combined witness is **not a sufficient future green regression oracle**.

**Disposition:** preserve it unchanged in this research snapshot, as instructed.
When an owner separately authorizes the real correction, keep the rejection
assertion and give the rejection branch an absent-record/no-reservation oracle.
Keep the current accepted-candidate follow-through as separate historical
evidence or a branch reached only when the defect occurs. Do not merely weaken
the final assertion or turn expected failure into a passing test.

### F3 — High release gate, accurately disclosed: restore is unavailable for the measured payload

**Evidence:** PostgreSQL `runtime/crash-boundary.ts` lines 165–171,
`evidence/execution-identities.json`, `evidence/crash-results.json`.
The measured `embedded-postgres@18.4.0-beta.17` native payload lacks `pg_dump`,
`pg_restore` and `pg_controldata`. The new harness records five passing core
rows and one unavailable backup/restore row, then exits 0 with
`passed-with-explicit-unavailable-backup` and `releaseQualification:false`.

**Disposition:** read the structured result, not just process exit 0. No backup,
restore or release pass follows. Native PostgreSQL/`embedded-postgres` selection
remains adopted; this research package version is explicitly not the selected
production distribution. Qualify actual production helpers/artifacts within the
existing Supervisor adapter. A restore into a distinct clean owned root with
exact application readback is the missing falsifiable proof. Do not substitute
historical archive claims or an externally installed helper and call this exact
payload qualified.

### F4 — High integration gate, not a discovered product defect: component successes do not compose automatically

The static experiment uses public Core/Assembly 0.7.0, Resources 0.2.1 and
Conformance 0.5.0, plus a file-snapshot recovery fixture with a live test
Supervisor. Orchestrator ADR0113 adopts the exact Core/Assembly 0.5.0 pair as its
design baseline; it does not admit production dependencies automatically.
The PostgreSQL experiment separately exercises one Agent Context feature and
its outbox. No executed trace combines actual product admission, selected
immutable artifact, the product's adopted package pair, existing AR custody,
PostgreSQL recovery and restart into one product-authorized operation.

**Disposition:** preserve the reports' explicit separation. The next bounded
product slice should bind these existing seams and qualify its own receiver,
without treating either copied fixture as a production Host. A specific joint
trace through that actual slice, including the F1 rejection and recovery
readback, is the missing evidence. This requirement does not reopen the accepted
static/restart direction or authorize hot overlap.

## Independent identity and count audit

`experiments/critic-restart/audit-results.json` records the detailed result:

| Audit | Result |
| --- | --- |
| Static copied inputs | All 47 files match their stored hashes and current clean GM source bytes at `b70ba39304ac71964175c42a77309406a7c30ca2` |
| Static added source identity | All 6 TypeScript files match the final identity inventory |
| Installed public package bytes | Core 52, Assembly 32, Resources 16 and Conformance 40 inventoried file entries match; 140 entries total |
| Static evidence checksum manifest | All 98 entries match |
| PostgreSQL copied product inputs | All 17 TypeScript files match their hashes and source bytes at Orchestrator `aaabc1e7cd2e2482668530e4412e61c2bca1f515` |
| PostgreSQL evidence/identity manifests | All 52 source/evidence entries and 14 execution-identity entries match, including actual native executables |
| Independent strict static rebuild | Exit 0 with the unchanged `strict:true`, `skipLibCheck:false` project; all 48 emitted JavaScript files match the executed tree byte-for-byte |

The independent build writes solely under `experiments/critic-restart/rebuilt`.
Its command, 48 per-file hashes and equality observations are in
`independent-strict-build.json`; its empty diagnostic log is retained separately.
The generated rebuild can be omitted from an archive because the frozen inputs
and comparison manifest reproduce it. Package-byte equality is not a verified
registry signature, provenance attestation or tarball-to-Git equivalence.

| Raw execution record | Audited result | Independent status |
| --- | --- | --- |
| Static `logs/existing-expanded.log` |60 pass/0 fail/0 skipped/0 todo | Audited original execution; not rerun |
| Static `logs/added-after-scope-correction.log` |6 pass/0 fail/0 skipped/0 todo | Audited original execution; not rerun |
| Static `logs/stop-admission-with-recovery.log` |0 pass/2 fail/0 skipped/0 todo | Audited both profiles |
| Critic `counterexample-sandbox.log` |0 pass/1 fail/0 skipped/0 todo | Independently rerun, filtered `record-only` |
| PG `evidence/existing-feature-tests.log` |2 pass/0 fail/0 skipped/0 todo | Audited original execution; not rerun |
| PG `evidence/crash-results.json` |5 passed rows,1 unavailable row | Source/raw-log audit; no second PG execution |

Counts remain separate. There is no green aggregate and no inference of
thousands-of-plugin qualification from 66 positive static observations.

## What the real PostgreSQL crash does establish

The copied product feature and migration perform genuine native PostgreSQL
transactions and outbox writes. The new harness's client Proxy holds COMMIT
before sending it; it does not replace the database or persistence adapter.
The held transaction reads its staged manifest while an independent connection
sees only the previously committed manifest/outbox. The owned postmaster 92678
then actually exits with SIGKILL, the checked-out backend ends, and the public
command rejects with `UNAVAILABLE`. Fresh pools attach to postmaster 92691 at
the same data root and system identifier `7700546930572265959`.
`server-92691.log` independently records interrupted shutdown, automatic recovery,
WAL redo and readiness. Exact committed facts/outbox survive; the uncommitted
pair is absent. Two retries yield one pending-manifest insertion and its one
owned outbox event. This is immutable-resource idempotency, not a general
command-receipt or cross-system exactly-once guarantee.

Real versus injected boundaries must remain explicit. Authorization in the new
harness is a permissive stub; the inherited suite checks its own current-
authorization and forced-RLS contracts. The older lost-COMMIT-response case
injects client observation loss after a real COMMIT. The disconnect case calls
real `pg_terminate_backend`. The new case kills the real postmaster. None is
power loss, arbitrary filesystem failure or proof of event delivery to external
systems. Native startup bypasses the wrapper's global lifecycle hooks, so it
does not qualify those hooks or a complete product Supervisor.

The final native exit 0, `pg_ctl status`3 and retained external process check
support cleanup of the known task cluster. They do not establish generic PID
reuse safety or recovery after loss of the custody owner.

## Resource, restart and authority boundaries retained

The raw cycle receipts contain 12 alternating A/B one-shot executions, 12 unique
UUIDs and stable same-provider emitted-byte/content-plan hashes. Parent FD
samples stay 21 from a 21 baseline. These permit complete unavailability between
incarnations. They do not demonstrate traffic routing or accepted-work transfer
across an overlapping cutover.

The 24 recovery-worker cycles have 24 unique grants, explicitly joined worker
exit before the next start and known-PID absence observations. They dispatch
**zero work**; parent FD samples plateau at 22 from a 21 baseline. The separate
S06 case establishes natural successful work completion before stop/restart.
It must not be read as 24 work-bearing drain/recovery cycles.

Complete descendant inventory is unqualified because procfs task `children`
is unavailable. FD readings are the observing parent's descriptors only.
The unchanged Supervisor retains historical worker connections and events;
no retained-reference or RSS bound was measured. The finite FD plateau neither
conceals that retention nor proves a long-run leak-free runtime. Full
Supervisor death, hostile/native plugin containment and macOS/Windows do not
inherit these Linux observations.

Accepted authority remains consistent with the reports. ADR0113 owns the
product's exact composition adoption; ADR0114 already selects native PostgreSQL,
node-postgres, adapter-local Drizzle and the `embedded-postgres` Supervisor
approach, while explicitly withholding a production version matrix. PR90's
ADR0116 is accepted on its owner-approved branch and chooses full native Temporal
with PostgreSQL; PR90 remains unmerged in the retained current metadata. This
does not make the plugin-replacement adapter mandatory, or reopen the product's
workflow-engine decision. Optional lifecycle-kernel adoption/release is not
implied by the experiment.

The original workflow/job summaries omitted the run's head SHA. I resolved
that evidence-custody gap with one independent read-only run-details GET.
`experiments/critic-restart/pr90-run-exact-head.json` preserves its query and
raw response: run 40009973655, head
`0af892165a023a274302f89b47ba514ab2915e59`, PR90, `pull_request`, attempt 1,
`success`. Combined with the original nine-job response, exact-head attribution
is now self-contained. This is hosted component evidence, not a local rerun or
product release qualification.

## Alternatives and code cost judgment

Scores below are engineering judgments out of 10 after the named missing owner
gates are satisfied; they are not measured uptime. Higher complexity means more
burden. Estimated LOC carry approximately×2 uncertainty and exclude existing
GM/AR implementation, full Desktop packaging and application workflow design.

| Approach and scope | Confidence | Achievable reliability | Complexity | New production/integration LOC | New E2E/test LOC |
| --- | ---: | ---: | ---: | --- | --- |
| Trusted static composition and ordinary immutable startup |9 |9 |2 |50–200 composition/wiring |200–600 |
| Accepted full controlled restart through existing custody, downtime allowed |7 |9 |4 |150–500 receiver/custody integration, subject to actual seam inspection |600–1,400 |
| Request-cohort hot overlap and state/effect recovery |4 |7 |8 |800–2,000 plus explicit optional-kernel/admission prerequisites |1,500–3,500 |

The first two judgments agree with the reviewed report. The hot-overlap row is
unexecuted and outside the accepted next slice. An optional Temporal rollout
adapter cannot substitute for the receiver seal or physical custody; its
additional cost/replay qualification belongs to the separate Temporal workstream.
The PG work validates the selected persistence approach at a bounded feature
seam; no alternate database is proposed or scored as an adoption decision here.

Audited actual counts are **0 new production LOC**, **373 static test/evidence
TypeScript lines**, **3,576 unchanged static fixture TypeScript lines**,
**194 new PG crash-harness TypeScript lines** and **22 unchanged resolver
TypeScript lines**. These are physical source lines; configurations, reports,
logs and generated JS are separate. This critic adds no maintained fixture code.

## Independent reproduction

From `experiments/static-restart`, the exact filtered command is:

```sh
/tmp/plugin-validation-toolchain-20261025/bin/node --test --test-isolation=none --test-reporter=tap '--test-name-pattern=S-07 record-only' out/tests/stop-admission-counterexample.test.js
```

Expected status in this snapshot is exit 1 with the admission assertion failing.
The recorded start is 2026-10-25T10:22:51.195015+00:00. It completed within the
existing 20-second test observation bound, released the held acknowledgement,
joined the original stop and the fresh worker stop, and used normal fixture
disposal. No fixture was edited and no active peer process was touched.
Sandbox execution succeeded; no escalation or failed retry was needed.

Review inputs and their SHA-256 identities are recorded in `audit-results.json`.
This review closes its bounded remit; the remaining actions are the concrete
owner dispositions above, not an invitation to keep enlarging this fixture.
