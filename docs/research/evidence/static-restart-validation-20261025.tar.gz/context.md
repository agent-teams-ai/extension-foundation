# Plugin direction validation — shared brief (2026-10-25)

## Owner goal and current authorization

The owner is building a TypeScript-first, deeply modular ecosystem with hundreds or thousands of modules and user plugins. Users should customize behavior without forking the product. Clean Architecture, SOLID, DRY, Pluggable, clear ownership, ordinary author UX, reliable lifecycle and real scale matter more than elegant small demos. Prefer mature libraries and existing responsible components to bespoke pools, RPC, workflow engines or supervisors. Native Rust/Go may be justified by a concrete system/CPU/reuse benefit; no blanket TypeScript or Rust mandate.

Current owner message explicitly accepts **static composition with controlled restart** as the baseline. A **Temporal adapter is optional for the replacement mechanism**, to be used where useful. This does not reopen an existing product's choice of Temporal for its own application workflows. The owner believes PostgreSQL is now selected everywhere, with a particular bundled native PostgreSQL solution for Desktop; previous SQLite findings may be stale. Verify fresh decisions and update the record accordingly.

The owner authorizes recording/pushing confirmed direction, marking remaining hypotheses, and a substantial **parallel executable spike/E2E campaign before large implementation**. Use GPT-6.1 Sol xhigh researchers and independent critics, give everyone this full context, save all findings/source identities/reproduction/failed attempts. Do not introduce a production runtime, publish packages, silently rewrite accepted ADRs, or merge unrelated work. Commit and push meaningful documentation/evidence checkpoints promptly. A test result is not an adoption decision.

## Freshness leads that MUST be verified

Previous local files are gone; restore from GitHub. On the first live check:
- EF PR55 is open draft, branch docs/plugin-research-hot-reload-20261021, head 150c29acc341380ba16d5cc402052a03d201ce4c.
- GM PR210 is open draft, head 8249c674ad53458b31d6ad06803ceb76e29ff4c7.
- Orchestrator PR88 is open draft on docs/mandatory-modules-and-collaboration, head 477b3445c4c66416121559894cf6f393c9450c72.
- Organization .github PR379 is now MERGED, final head 94ec1454f2626b90a375ff19c255c57e59e3f847.

Personal-context retrieval supplies useful but partially conflicting leads. Primary current repository evidence must resolve them:
- .github PR376 and Orchestrator PR89 reportedly merged PostgreSQL + node-postgres + Drizzle, Fully Local native PostgreSQL via a Supervisor adapter using `embedded-postgres`.
- Earlier research candidates included Rust `postgresql_embedded` 0.21.0 and Node `embedded-postgres` 18.4.0-beta.17; these are historical candidates, not assumed current approved pins.
- A later owner-approved ADR0116 reportedly chooses FULL native Temporal Service + PostgreSQL for Fully Local V1, closes OD035, with PR90 showing Linux/macOS/Windows E2E. Its last recalled merge blocker was commit identity, not architecture. Verify current PR90/main instead of repeating the old SQLite/OpenWorkflow direction.
- Earlier files repeating SQLite/open OD035 may simply be our stale Oct22 report. Do not treat a copied old report as fresh authority.

## Existing architecture to preserve unless current accepted source supersedes it

GM owns inert module declarations, graph composition/construction and its resource semantics. Accepted optional `@get-modular/lifecycle-kernel` candidate owns synchronous local generation/call/custody facts, without I/O, timers, callbacks, promises or product policy; it was private/unreleased at the earlier snapshot. Verify current status; do not duplicate, move or silently release it.

EF owns purpose-neutral artifact/trust/lifecycle requirements, conformance and package admission. Products own extension points, actual authority, effective grants, canonical active selection, admission/dispatch, business persistence/effects and recovery. Existing Agent Runtime custody owns physical process/resource control. One product-authorized operation may use reusable driver CODE; exclude a second independently advancing coordinator or a second independently mutable copy of authoritative state.

Library independence does not require a new repository. Subtract existing kernel/executor/RPC before proposing a shared residual package. Ordinary-library admission, stable public SPI independence and Orchestrator's real-product-integration gates are distinct. Keep them exact rather than inventing extra approval loops or weakening them.

## Previous research and executable evidence

EF PR55 contains 13 governed research documents with 18 pattern/failure entries. Read the research hub and relevant owning docs at the restored branch. Two archives contain the common brief, 12 raw reports/critic dispositions and exact executor experiments. Keep historical evidence frozen; current synthesis must mark supersession clearly.

Original Linux Node26.11.1/TS7.0.2 executor experiment: eight scenarios plus unchanged repeat for Piscina5.3.2, workerpool10.0.3 and direct Worker. A separate critic's two-worker Piscina case showed fulfilled graceful close with no pool error while a still-running accepted task was terminated, finally absent. workerpool termination could fulfill and fire a hook while a task remained live, and admit new work during termination. Do not treat close/hook/stats as physical exit or successful natural drain. Raw tarball identities and source hashes were verified; final own sources were strict TS with explicit skipLibCheck for Piscina's incompatible published declaration. Do not relabel that as dependency-declaration qualification.

Other prior corrections: final validity check and owned exact-generation handoff after the last await/user conversion; host and execution incarnation binding; receiver-enforced scheduler epochs; actual accepted-work affinity; immutable old bytes restored as a fresh generation; distinct cancellation, settlement, process exit, physical absence and external-effect debt; a failed/timed-out candidate retains capacity while startup/cleanup remains live. Per-cohort caps require aggregate tenant/product budgets. Descriptor count is not active workers or runtime/compiler/churn qualification.

## Experiment rules

1. Read current AGENTS.md, relevant skills and accepted decisions before code. Apply local exact toolchain/dependency profiles. New maintained JS-runtime source must be ordinary `.ts`, strict and supported TS7.0.2+ according to the owning profile. Do not patch dependency sources or relax repo gates.
2. State scope, hypothesis, falsifier, real components versus fakes, exact versions/commits and bounded budgets before execution. Report the plan to root early so overlapping critics can challenge it.
3. Reuse existing runnable spikes/fixtures before creating another framework. Use disposable task-owned directories and processes; do not touch user databases/services. No independent production Host, custom RPC stack or duplicate kernel in a fixture.
4. Exercise real public boundaries end-to-end. Include failures that can change the decision: bad candidate/preflight, active work during restart, start/stop failure, process loss, late completion, recovery/readback, duplicate/retried commands and resource bounds, as applicable. Do not invent production proof from a hand-coded success-only model.
5. Distinguish source inspection, existing unrun assertions, local execution, hosted CI execution, estimates and untested targets. Timeouts are observation bounds, not benchmarks. No claims of thousands-of-plugin qualification from a small test or a static source check.
6. Prefer E2E/contract evidence and a few critical unit/property checks over implementation-mirroring tests. Do not keep adding optional cases after the actual uncertainty is resolved.
7. Preserve logs, exact commands, configurations, source hashes, failures and corrections. Tests should fail closed when a required real component is unavailable. An explicit nonexecuted platform row is better than a passing mock substitute.
8. For significant alternatives record confidence/reliability/complexity /10 and new production/integration versus test/fixture LOC, scope/prerequisites and approximately x2 uncertainty. Scores are not uptime measurements.

## Coordination and deliverables

Shared base: `/workspace/scratch/f863b9d38368/research/plugin-validation-2026-10-25`.
Root controls shared repo branches, docs integration, commits/pushes and remote PR metadata. Agents own distinct experiment/report subdirectories; do not edit shared accepted ADRs or source concurrently. Report early missing tools/permissions so root can provide one shared toolchain. No credentials in logs.

Expected result: verified current PostgreSQL/Temporal authority; confirmed direction versus open qualification matrix; runnable static-restart, persistence and optional durable-coordinator spikes; independent overlapping review with dispositions; durable source-backed reports and evidence in EF/owning repositories, with exact links and candid remaining production/OS gaps. No blanket promise of bug-free or universal hot replacement.
