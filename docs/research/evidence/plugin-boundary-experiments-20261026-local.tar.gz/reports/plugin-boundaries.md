# Plugin loading and execution boundaries — executed observations

Date: 2026-10-26 UTC. Track: plugin-boundaries. **Research fixture, not production
admission.** The accepted static-composition plus controlled-restart baseline is
unchanged. No production Host, SPI, supervisor, package or security sandbox was
introduced.

## Findings and resulting decision

The smallest approved experiments resolved their selected questions:

1. **Inert data plus explicit selected loading can reject before module
   evaluation.** The actual released GM Core rejected a selected incompatible
   graph with `binding.compatibility-mismatch`; the child exited normally and
   parent-read executable markers were absent. Separate fixture gates rejected
   missing selected-loader correspondence and changed selected bytes before
   evaluating the entries. Selected A worked while installed/unselected B stayed
   unevaluated. GM supplied graph validation; the TEST target seam supplied
   pre-import sequencing and illustrative byte admission.
2. **Entry-only identity is insufficient, and a complete content hash still
   does not establish byte custody.** Changing only a helper left the entry hash
   unchanged but changed actual invocation. Re-importing only the entry under a
   query URL retained its old helper in the same process. A fresh process saw the
   changed helper. More decisively, both entry and helper digests were verified
   and ACKed, the parent independently confirmed that full receipt, then an
   atomic entry replacement at the same path changed the subsequently imported
   code. Complete hashing plus fresh process lifetime cannot by itself close
   that verify/load gap.
3. **Execution placement changes the tested availability/termination boundary.**
   A synchronous allocation-free loop blocked the disposable in-process host's
   post-start ping; the independent parent then force-terminated it. The same
   loop in a Worker or child process left its host responsive. The Worker exit
   and fulfilled terminate promise were accompanied by disappearance of its
   independently identified OS task. The child-process trial separately recorded
   signal send, disconnect, exit, stdio close and known-process absence. Startup
   marker files persisted after retirement, so physical termination did not
   reverse those earlier file effects.

**Recommendation/inference:** keep inert artifact/declaration inspection,
selected whole-graph validation and target-local literal loading separate.
For the accepted baseline, prefer a coherent closed build artifact and fresh
process execution where process-owned code lifetime is needed, **conditional on
the existing artifact/execution owner holding the complete selected closure fixed
through evaluation**. The experiment deliberately did not implement or qualify
that custody enforcement. Retain trusted in-process execution when its blocking
risk is acceptable. Use fitting existing Worker/process custody when the selected
capability needs independent interruption; do not add one Worker per ordinary
static module or a new universal runtime.

## Scope, authority and exact environment

Plans were independently reviewed before execution:

- `plans/critique-plugin-boundaries-by-restart.md`, R1–R6 accepted.
- `plans/critique-restart-and-boundaries-by-state.md`, relevant M3–M6 accepted.
- Root explicitly approved execution after those corrections and serialized this
  track's strict compile/run phase with restart work.

Runtime was **Node26.11.1 on Linux kernel6.18.55, UID0**. TypeScript was7.0.2;
public `@get-modular/core`0.7.0 and `@types/node`24.19.1 came from the root-managed
frozen dependency installation. All new maintained code is ordinary `.ts`, with
`strict:true`, `skipLibCheck:false` and `noEmitOnError:true`. Emitted `.js` is
reproducible generated fixture output. No independent install or dependency
modification occurred; the experiment owns only its symlink to shared
`node_modules`.

Reproduction command and exact paths are in
`experiments/plugin-boundaries/REPRODUCE.md`. Important identity anchors:

| Input | Identity |
| --- | --- |
| Node binary | SHA256 `5a7b8a3cf5ccb57d297519754fd73238f64cf560afd0ef19a2f9bf7384cbb657` |
| Frozen shared lock | SHA256 `8fad72c06cabce75e6ca4f16c641456979c744e2e1de913b12e604f7a21fb535` |
| Public Core entry | SHA256 `957b0b510435788f66a2112805aedc194f5e4619a10cac0e5bf2bd06ea1b95ef`; this single file is not the complete package receipt |
| Complete shared input inventory | Root-owned `validation/shared-toolchain-identities.json`; frozen manifest/lock unchanged |
| Current GM standard read for planning | Restored GM `b1866ac5328231b7fe1d63ed136e7a905a2facc1`, complete-document SHA256 `3c5814ebf1ab1bd17688e49955aa0baa2ee91dd3a369adcea4d38aaccd53ba86` |
| Earlier executed public consumer | Frozen `historical/20261025`; unchanged and not re-executed as a broad suite |

The environment exposed nested PID namespaces with host-mounted procfs. A Node
PID such as157 was not a native procfs path. Before this track's first run, the
observer was corrected using the restart track's finding: map the explicit local
PID by matching the observer PID-namespace inode and the final `NSpid` field,
then retain native proc PID plus start time. Worker code synchronously reads its
own `/proc/thread-self`, and the independent observer checks that raw task under
the mapped native process. Neither a missing arbitrary PID path nor Node's
Worker `threadId` is used as physical-absence evidence.

At successful-run start, `statfs` recorded4,096-byte blocks,281,465 free blocks
(about1.07GiB physical free) and **zero unprivileged available blocks**. UID0
execution used root's explicit ≤6MiB authorization. `/proc/meminfo` reported
3,474,040KiB available; this is an environment observation, not a memory-bound
qualification. The retained experiment footprint was about380KiB before this
report/manifests. It did not use `/dev/shm` or touch another track's data.

## Actual results

The corrected `attempt-2` ended with exit0. Counts below describe different
scenarios and controls; they are not a reliability percentage.

### PB-01: six selected-loading observations

The pre-admission child runtime import closure contains Node built-ins and the
released public Core only. Inert JSON supplies declarations/profile; no candidate
barrel or A/B/root executable is imported before admission. Source review is
small and explicit, with no new import scanner.

| Row | Actual observation | Evidence |
| --- | --- | --- |
| Selected A | Public plan selections exactly match selected loaders A and consumer root. Actual call returns literal `A`; parent sees exactly A/root markers, no B. | `results/attempt-2/PB01-1.json` |
| Metadata only | Public compilation succeeds; no loader invocation; no executable markers; normal exit0. | `PB01-2.json` |
| Incompatible graph | Actual public diagnostic is `binding.compatibility-mismatch`, expected token `fixture/session/runner/r1`, actual `.../r2`; no markers; normal exit0. | `PB01-3.json` |
| Changed selected entry | Frozen expected A receipt differs after the owned edit. Actual `fixture.byte-mismatch` rejection; no A/root markers; normal exit0. | `PB01-4.json` |
| Missing selected loader | Actual selected IDs A/root differ from selected mapping root-only. `fixture.selected-loader-mismatch`; no markers; normal exit0. Installed unused B is legal. | `PB01-5.json` |
| Executable-first control | Direct import writes synchronous `bad-evaluated-before-throw` marker then throws. The child catches the actual import rejection and exits0. | `PB01-6.json` |

The positive selected call and executable-first control prove marker visibility;
normally exited named rejections prevent timeout/no-progress from masquerading
as zero evaluation. The byte check is a tiny TEST-owned SHA comparison, not EF
artifact admission. It verifies one selected emitted file in this row, not an
arbitrary package dependency graph or malicious writer.

### PB-02: four artifact/code-lifetime groups

| Group | Actual output and independent observation |
| --- | --- |
| Helper-only edit | Entry hash remained `fd90050b…df433`; helper hash changed. Fresh invocation returned `old-entry/new-helper`; marker bytes independently confirmed both components. |
| Root-only query re-import | First call returned `old-entry/old-helper`. After helper edit, query re-import returned the same old helper. Entry marker appeared twice, helper marker once. Fresh process at the unchanged path returned `old-entry/new-helper`. |
| Full receipt then replacement | Child ACKed entry `fd90050b…df433` and helper `e68c7451…72d61`; parent separately rehashed both unchanged. Parent atomically replaced entry at that path, producing `d1a7e480…3a61e`; unchanged literal import returned `new-entry/old-helper`. |
| Coherent static A/B | Separate unchanged artifact directories in separate fresh processes returned exactly `old-entry/old-helper` and `new-entry/new-helper`. Parent hashes before/after each were equal; both children exited normally and were independently absent. |

Full digests, ACK order, before/after parent digests, output/marker bytes and
process facts are in `PB02-1.json` through `PB02-4.json`. Expected receipts were
frozen from designated prebuilt baseline bytes before mutation; the tested child
did not choose its own expected artifact identity from current candidate bytes.

These observations reject both entry-only coherence and the stronger mistaken
claim that complete hashing closes mutable-path loading. The coherent positive
depends on fixture directories intentionally remaining unchanged. No extractor,
signature verifier, loader hook, file-descriptor loader, re-verification loop or
new custody owner was added to make the race disappear.

### PB-03: five real placement trials and reused import control

Each fault had a successful nonce ping before go. A new nonce was sent only
after the explicit startup marker; buffered earlier pongs could not qualify
responsiveness. The500ms observation is a test cap, not an application SLO.

| Trial | Readiness/response fact | Physical retirement fact | External effect fact |
| --- | --- | --- | --- |
| Cooperative in-process control | Ready message and post-start pong | Host exit0, close, mapped PID absent | Startup marker retained |
| Asynchronous non-settlement | No ready message within500ms; host pongs before, during and after observation | Explicit normal shutdown; exit0/close/PID absent | Marker retained; harness IPC, rather than unresolved Promise alone, kept host observable |
| In-process synchronous loop | Post-start ping deadline expired while exact host remained live | Planned SIGKILL; actual signal exit, close and mapped PID absence | Marker retained |
| Worker synchronous loop | Host answered post-start and post-termination pings | Worker exit1; terminate fulfillment1; exact independently live native task1156201 absent afterward; host remained same incarnation, then exit0/close/absence | Marker retained |
| Child-process synchronous loop | Host answered post-start and post-termination pings | Recorded SIGTERM send; separate disconnect, actual SIGTERM exit, close and mapped native PID1156209 absence; host later exited0 | Marker retained |
| Partial import failure | Reuses actual PB01-6 import throw | Normally exited control child | Marker preceded throw and survived; no second duplicate trial |

Worker's namespace PID157 mapped to native process1156194; its synchronous
thread-self value was `1156194/task/1156201`. The observer independently recorded
that task's start time while live, then absence after exit/terminate. Full task,
process, nonce, signal and ordered event receipts are in `PB03-1.json` through
`PB03-5.json`; `PB03-6.json` explicitly labels reused evidence.

The accepted run created **17 direct owned child processes**, one explicitly
registered nested plugin child and one Worker. All direct child exits and
absences are in summary cleanup evidence; nested process exit/close/absence and
Worker task absence are in their individual rows. The in-process loop used its
planned force-stop, not an emergency watchdog. No unresolved cleanup debt was
observed. Full descendant inventory remains unqualified.

## Failures, corrections and verification

The first no-emit strict typecheck and build passed. `attempt-1` then failed
before any successful observation because the TEST inert wire token
`revision-1` violated public Core identity grammar. Core returned actual
`identity.invalid` diagnostics; the child exited1 and parent later reported its
bounded missing-done deadline. **Absent markers were not counted as success.**
The parent retained child stderr, process incarnation and confirmed absence.

The incorrect declarations and pre-correction PB01 source are retained in
`results/attempt-1/`; logs and summary are separate from the corrected run.
After inspecting the existing public descriptor/wire grammar, the fixture used
`fixture/session/runner/r1` and `.../r2`. No production source, package dependency,
compiler gate or expected public diagnostic was weakened. The corrected strict
build passed, and the one corrected bounded run completed. No optional repeat,
stress/churn, native fault or third-party plugin run followed.

Actual commands and outcomes:

| Command | Outcome |
| --- | --- |
| TS7 no-emit strict check | Exit0; `logs/typecheck-attempt-1.log` |
| Initial strict emitted build | Exit0; `logs/build-attempt-1.log` |
| First bounded run | Exit1, TEST input defect; `logs/run-attempt-1.log`, `results/attempt-1/summary.json` |
| Corrected strict emitted build | Exit0; `logs/build-attempt-2.log` |
| Corrected bounded run | Exit0; `logs/run-attempt-2.log`, `results/attempt-2/summary.json` |

All groups/trials have explicit caps, and exact owned handles/namespace/native
identities are registered before go. A surviving outer observer retains nested
plugin PID/start-time cleanup authority if its inner host dies. This is bounded
fixture cleanup, not production process-tree containment. The successful marker
root was removed after its bytes were retained; emitted mutable files were
restored to the baseline. The failed first run's marker root contained only an
empty `p1-0` directory; its inventory was retained, then both exact empty owned
directories were removed with `rmdir` after logs/source/cleanup evidence was saved.

## Comparison, code cost and remaining qualification

Scores are engineering judgments for stated trusted scope, not measured uptime.
Higher complexity is more burden. Future LOC estimates are incremental and
approximately×2 uncertain; actual campaign production/integration LOC are both0.

| Choice | Confidence/10 | Reliability/10 within stated conditions | Complexity/10 | Future production mechanism LOC | Future product integration LOC |
| --- | ---: | ---: | ---: | ---: | ---: |
| Inert data + public graph compile + selected literal imports |9|9 for instrumented rejected-entry sequencing|2|0–50|60–140|
| Entry-only hash/root-query reload as whole-code coherence |10 that insufficient|2|2|0–20|20–60|
| Complete fixed build closure + fresh process |9|9 **conditional on real custody keeping that closure fixed**|3|0–50|80–180|
| In-process initializer with same-loop observation timeout |10|3 for a bounded host-block/physical-stop promise|1|0|15–40|
| Worker with independent observation and explicit retirement |9|8 for tested pure-JS loop, shared process fate retained|4|0 if existing adapter fits|60–140|
| Existing process custody for independent process lifetime |9|9 for this owned process/Linux profile, OS authority untested|5|0 if existing custody fits|100–220|

Actual new TEST code is571 TypeScript lines, plus6 inert JSON lines and small
configuration/documentation files; generated output and retained evidence are
separate. This stays within the plan's fixture estimate. No maintained shared
runtime mechanism, production integration or native rewrite was created.

Remaining unqualified boundaries are: real product executable admission and
readiness/custody integration; complete arbitrary Node/package/import closure;
signature/provenance enforcement; immutable artifact custody against concurrent
writers; native-addon code lifetime; process/global OOM/native faults; hostile
code isolation/OS permissions; arbitrary descendants; cross-OS behavior;
long-lived work, external-effect reconciliation and state migration; repeated
churn/RSS/reference bounds and large active-plugin counts. None is silently
promoted by these small successful fixtures.

## Source grounding versus executed evidence

Official sources were retrieved2026-10-26; accessible Node pages rendered
v26.12.1, while executed Node was26.11.1. Versioned26.11.1 URLs were unavailable
through the search tool and that limitation is retained in the plan.

- [Node ESM](https://nodejs.org/api/esm.html#file-urls) documents query/fragment
  module identity and separate ESM cache; PB02 supplies the actual local helper
  observation rather than assuming it from the root-URL rule.
- [Node Worker](https://nodejs.org/api/worker_threads.html#workerterminate)
  documents termination fulfillment at exit. Its engine limits exclude external
  data and global OOM can still abort the process. PB03 tests only the selected
  pure-JS loop and independent native-task retirement.
- [Node child_process](https://nodejs.org/api/child_process.html#subprocesskilled)
  distinguishes signal send from termination and does not promise Linux
  descendant termination. PB03 keeps those observations separate.
- [Node permissions](https://nodejs.org/api/permissions.html) explicitly excludes
  protection against malicious code. No permission enforcement or sandbox test
  was run here.
- [VS Code manifest](https://code.visualstudio.com/api/references/extension-manifest),
  [host](https://code.visualstudio.com/api/advanced-topics/extension-host) and
  [runtime security](https://code.visualstudio.com/docs/configure/extensions/extension-runtime-security)
  ground separate metadata, runtime placement and process authority. These were
  documentation inspections, not a VS Code experiment.
- [Vault plugin architecture](https://developer.hashicorp.com/vault/docs/plugins/plugin-architecture)
  separates catalog/checksum validation from starting execution. It is precedent
  for that distinction, not qualification of this TEST Node artifact seam.
- EF's retained OpenClaw audit at
  `33ccaae2f522c3ae299aaf8b195fa166ab536bd8` identifies inert metadata strengths,
  runtime-export compatibility side effects, source custody and ESM lifetime
  limits. This track executed no OpenClaw code and makes no current-product
  comparative reliability claim.

All selected uncertainties are resolved within this scope. Further fixture
expansion is not justified before a real product slice supplies another named
decision and boundary.
