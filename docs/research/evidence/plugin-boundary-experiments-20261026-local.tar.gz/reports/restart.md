# Restart boundary results — 2026-10-26

## Outcome and decision

**The small receiver-local seal closes the measured S07 acceptance hole in the
copied fixture, without a new Host, kernel or supervisor.** Seven selected
positive cases passed. The original two S07 cases and the independent new
absence negative control remain **three deliberate red witnesses**, retained
separately. There is no green aggregate that hides those red cases and no
production restart-adapter qualification.

The new observations support three concrete integration requirements:

1. Put permanent acceptance sealing in the same authoritative ordering as
   acceptance, and wait for its actual completion before draining. Dispatch
   closure alone is insufficient. A submission already ahead of the seal is
   accepted work with an explicit recovery disposition.
2. Keep the original construction/resource attempt through readiness rejection
   and failed cleanup. The existing attempt owner handled the tested join
   unchanged; another candidate lifecycle state machine was unnecessary.
3. Preserve semantic outcome, actual external effect, child result message,
   IPC status, physical exit and cleanup as different facts. Canonical
   cancellation did not undo an already synced file effect; a success message
   and IPC disconnect did not establish child exit.

The owner-confirmed static composition plus controlled restart baseline remains
appropriate. Downtime is allowed. These experiments do not select overlap,
publish a package, change production APIs, adopt the optional lifecycle kernel,
replace execution custody or reopen Temporal's owning product decision.

## Exact subjects and retained inputs

Actual runtime: Linux x64, kernel6.18.55, Node26.11.1. Actual compiler:
TypeScript7.0.2, ordinary `.ts`, NodeNext/ES2024, `strict:true`,
`skipLibCheck:false`. The experiment symlinked root-managed dependencies
read-only; no install, dependency patch or download was performed. Exact public
runtime packages were Core/Assembly0.7.0 and Resources0.2.1; the shared frozen
harness also supplies Conformance0.5.0 and `@types/node`24.19.1.

The Node binary SHA-256 is
`5a7b8a3cf5ccb57d297519754fd73238f64cf560afd0ef19a2f9bf7384cbb657`.
`experiments/restart/results/execution-identities.json` binds the package
manifests, strict flags, actual platform, binary and root's complete shared
identity manifest. Frozen dependency manifest/lock copies are under `inputs/`.

Reused source is the prior GM `b70ba393` recovery/semantic fixture preserved in
the immutable20261025 archive, not a build of fresh GM main. Current EF/GM
authority was inspected before planning; neither current main nor an
Orchestrator/AR production scope was changed. `source-copy-inventory.json`
records every original/current hash; `source-diff.patch` shows the copied-fixture
changes. The original S07 test file remains byte-identical:
`a9d52bcc430927080fc8a51292cf202793a6bb241ed5916cebfaa17498c0f6cc`.

The **baseline** copy has only observational additions to its existing test
Supervisor: per-operation acquisition audit, raw result/disconnect/close
observations, exact-child identity registration and unused narrow test methods.
Its admission owner, worker and effect behavior remain unchanged. The
**corrected** copy adds the small permanent seal/stop ordering and two explicitly
test-owned effect scheduling modes. The semantic attempt owner is unchanged in
both copies. Instrumentation and scheduling faults are fixture code, not product
contracts or a substitute for the actual product receiver/custodian.

## Selected execution results

| Group | Actual result | Decisive evidence |
| --- | --- | --- |
| Original S07, record-only/restart-pending | **0 pass / 2 fail** | Both accept a distinct identity during stop, persist it and recover it; record-only pending, restart-pending SUCCESS. Unchanged required assertion fails. |
| New absence-control on unsealed baseline | **0 pass / 1 fail** | Parent directly reads candidate canonical presence, monotonic reserve-attempt audit and occupied reservation; fresh worker again reads its pending record. The desired absence assertion fails. |
| RST01 corrected seal and recovery | **4 pass / 0 fail** | Both profiles reject new identities after actual queued seal completion, including after reconcile; no acquisition audit for rejected candidates; independent canonical/fresh-worker absence. Earlier queued acceptance survives with the declared profile disposition. |
| RST02 readiness rejection + cleanup debt | **1 pass / 0 fail** | Real construction succeeded; readiness rejects; first cleanup report has one named failed debt; native resource/journal remain open; same retained attempt retry closes both without publication/business effects. |
| RST03 actual late success + live disconnected child | **2 pass / 0 fail** | Actual synced file and late success preserve canonical CANCELLED; separate success/disconnect trace retains live PID/capacity and pending stop until planned exact-handle force retirement, native exit/close and absence. |

All selected positive groups have zero skipped/todo/cancelled cases. The red
controls exit1 as actual failed assertions, not an expected-failure wrapper that
relabels them passed. Their cleanup receipts are still qualified. Raw TAP and
stderr are under `logs/`; structured events/snapshots/identities are under
`results/`. No broad unchanged inherited suite was rerun.

### RST01: sealing, reconciliation and accepted-before-seal work

The original trace remains reproducible after named revocation and actual old
effect exit, while the launch ACK is held. The new distinct candidate is pending
in the canonical file and consumes a reservation. The new audit records its
actual reserve RPC. This is the expected negative control for the independent
absence/no-acquisition oracle. Neither trace establishes data loss.

The corrected owner has a separate monotonic `admissionSealed` boolean and queues
its seal on the existing transition queue, independently of the recoverable
storage `frozen` flag. Existing identity/conflict lookup precedes sealed-new-work
rejection. Stop enqueues the seal before its first await, synchronously closes
dispatch scheduling, releases owned test holds, awaits actual seal completion,
then enumerates the accepted cohort and invokes existing stop/revocation. The
observed `admission-sealed` event comes after that actual awaited transition.

Each corrected profile performs the held-ACK trace, receives the exact sealed
rejection, independently reads unchanged canonical bytes while unrelated
transitions are held, and verifies candidate absence. The existing custodian's
monotonic audit is qualified by operation identity and worker grant; rejected
identities have **zero reserve attempts, permission attempts/issuance, launch
attempts or physical-spawn audit events**. Final `reserved:false` alone is not
the oracle. Duplicate/conflicting accepted identity commands add no acquisition.

The stopped-but-connected worker then reconciles using the unchanged API and
rejects another new identity with the same absence/no-acquisition proof.
Reconciliation clearing storage freeze cannot reopen the permanent seal. After
joining stop, a fresh worker reads both rejected identities as absent.

The separate acceptance-race case holds real temporary-file sync/close before
canonical rename, then requests stop. Stop-request observation precedes
acceptance-committed, which precedes seal-completed. The earlier queued operation
is legitimately accepted before the seal. No child is launched by that old
worker after closing; its reservation is revoked/released after joined stop.
Fresh `record-only` retains it pending with no new reservation or launch. Fresh
`restart-pending` makes exactly one new reserve attempt, starts one actual effect
and reaches SUCCESS; duplicate readback does not relaunch it.

This ordering does **not** promise retroactive rejection of every command whose
acknowledgment arrives after wall-clock stop request. It demonstrates one
receiver's queue-linearized accepted cohort and seal. File replacement/readback
is qualified for this process-restart profile. The store does not fsync the
parent directory; no power-loss or filesystem commit guarantee follows.

Evidence: `rst01-*-sealed.json`, `rst01-*-fresh.json`,
`rst01-*-before-seal.json`, `rst01-baseline-absence-control.json` and
`rst01-baseline-fresh-control.json`.

### RST02: readiness rejection did not discard cleanup authority

The actual GM run reports `succeeded` after real resource/journal acquisition.
The test attaches its rejection observer before rejecting the held readiness
promise with `fixture.readiness.rejected`; `run()` then rejects at closed
ingress. There are zero publications and zero module-run/business-effect
entries. Initialization itself did acquire a real external resource.

The first same-owner stop reports `complete:false`, `settled:true` with exactly
one failed debt at the actual runner resource path, cause
`fixture.cleanup.failed`. Native probes show both resource and prerequisite
journal still open. The retry is made on the same retained attempt; while its
real release is held, both probes remain usable. Releasing that barrier yields
one real release after two cleanup attempts and `EBADF` from both closed handles.
The final report is complete, settled and debt-free, with no publication/effect.

`rst02-readiness-debt.json` retains the first named report, journal records,
observations and final report. The unchanged L07 early-journal counterexample
was source-audited and not replayed. No extra candidate/control matrix was added.

### RST03: cancellation, late success and physical exit are separate

| Observation | A: actual late success after cancel | B: result/disconnect while child remains live |
| --- | --- | --- |
| Physical effect | Parent reads exactly one literal synced file line before cancellation and before custodian cleanup. | Parent reads exactly one literal file line after actual result/disconnect. |
| Canonical semantic outcome | Explicit cancel records CANCELLED; actual later SUCCESS message does not overwrite it. | Stop remains pending, then dispatch records CANCELLED after planned child retirement. |
| Raw child message | Actual SUCCESS after held-result release. | Actual SUCCESS before IPC disconnect, while PID is still live. |
| Custody before exit | Retained until actual natural exit. | Same operation reservation occupied, one live child, zero exits and no additional launch. |
| Stop observation | Normal cooperative protocol completes after child exit. | 200ms observation window ends with stop still pending; fresh writer refused because incumbent is live. This refusal is separate from effect occupancy proof. |
| Physical retirement | Actual exit0/no signal, native close, exact incarnation absent. | Planned exact retained-handle SIGKILL; actual null code/SIGKILL, native close and exact incarnation absent. No emergency watchdog. |
| Restart/readback | Fresh duplicate remains CANCELLED, one launch total. | Fresh duplicate remains CANCELLED, one launch total. |

The existing custodian still resolves `finished` and `wait-result` only after
physical exit and artifact handling. Raw-result/disconnect observations do not
change that promise, release capacity or promote canonical success. The child
in B deliberately retains a live timer after sending result/disconnecting; the
fault mode is synthetic, but its process survival, file effect, native exit and
close are real.

The parent stores A's actual pre-cancel file bytes/hash before the custodian
deletes its file after exit, and later compares the custodian's cached artifact
to those independent bytes. A demonstrates that semantic cancellation does not
undo the already completed file effect. B demonstrates an intentionally wrong
release predicate—result OR disconnect OR stop-request is true while the owned
child is independently live. Its final planned SIGKILL qualifies only force
retirement of that exact owned process, not graceful plugin cleanup.

Evidence: `rst03a-before-cancel.json`, `rst03a-final.json`,
`rst03b-live-after-deadline.json` and `rst03b-final.json`.

## Observation/custody failures retained and corrected

Three harness/evidence failures are separate from the selected test results:

1. Initial outer runner assumed Node's PID was directly usable under `/proc`.
   This exec environment has nested PID namespaces with host procfs. For example
   Node reported PID2 while `/proc/self` identified a host PID and `NSpid`
   contained both. The runner stopped before claiming any result. Its failure
   note and empty registry were retained.
2. Two initial baseline executions had qualified exit/child-absence receipts and
   structured evidence, but stdout/stderr pipe capture yielded empty TAP files.
   Their empty files/receipts remain under `empty-capture-attempt-1`. No exact
   reason for that transport observation is asserted. Switching the child to
   explicit native log file descriptors supplied complete bounded TAP on the
   reruns; test/admission policy was unchanged.
3. Two targeted evidence refinements were authorized by root: retain/assert
   RST02's exact first failed report and retain the baseline negative's fresh
   readback before its intended failing assertion. Previous complete logs and
   receipts remain under `before-evidence-refinement`. Only those two rows
   reran; the other six positives were not repeated.

The corrected namespace-aware native oracle matches the observer's PID-namespace
inode and innermost `NSpid`, retains namespace PID, host-proc PID and start time,
and reads that exact process incarnation. Both PID identities are in the raw
append-only custody registries. The surviving outer runner receives every
explicit worker/effect identity before a named fault barrier can release, with
bounded rescue authority over only matching live owned processes. No outer
rescue was used in any completed execution.

Independent source/receipt review found that `registerProcess` silently omits a
child if its native mapping is unavailable. The actual registries match every
expected finite create in these runs (RST01 eight workers/three effects; RST03
four workers/two effects; absence negative two workers/one effect). Their
cleanup evidence is supported. A generic fail-closed complete registrar, or
cleanup under an unavailable mapping, is **not qualified**. RST02's refined
test retains its first report for evidence; discarded-report behavior belongs
to the unchanged historical L07 evidence and is not claimed newly rerun here.

These are direct owned-process observations, not arbitrary descendant inventory,
general PID-reuse safety, a new custody service or complete custodian-loss
recovery. RST03B makes exit uncertain to a stop observer while the actual child
is known live; it does not simulate inaccessible/dead custody authority.

## Resources, checks and code cost

All final execution groups completed under their unchanged caps: 120s outer
bound for S07/RST01 groups, 60s for RST02/RST03, 20s inner test bound and inherited
5s emergency cleanup watchdog. Actual retained final outer durations are about
0.8s original S07, 0.44s absence negative, 1.62s corrected RST01, 0.12s corrected
RST02 and 0.92s corrected RST03. These are individual observations, not timing
SLOs or benchmarks. Every completed custody receipt records no outer deadline,
output overflow, rescue retirement or unresolved process.

Final selected groups cover 17 positive-fixture worker/effect incarnations and
10 red-control incarnations, all absent afterward; targeted/empty-capture
attempts have their own separate receipts. There is no descendant/RSS/long-run
reference bound. Peak RSS was not measured. All task temp roots from completed
runs were disposed; the initial empty diagnostic root is inert evidence. No
peer/shared data was removed. Final task files occupied about1.8MiB on disk at
the measurement checkpoint, well below root's10MB permission; emitted output is
reproducible. `f_bavail` was0 while UID0 physical free was about1.15GB. This
source-only permission did not satisfy or relax the state track's native guard.

Strict TS7 runner/baseline/corrected builds all passed. The subsequent targeted
test-evidence-only edits were strictly rebuilt; no flags, assertions or imported
package bytes were weakened. `source-counts.json` records **608 incremental
physical TypeScript lines**, counting both copies' observational additions,
new tests, two namespace probes and the114-line outer runner. Reused unique
fixture source is3,576 TypeScript lines, plus the unchanged historical S07.
Counts exclude config, reports, logs and emitted JS. **New production/shared
runtime LOC:0. New product integration LOC:0.**

Engineering judgments, not uptime; higher complexity means more burden. LOC
estimates carry approximately x2 uncertainty and exclude existing GM/AR code,
domain schema, packaging/signing and OS qualification:

| Next option within its stated scope | Confidence/10 | Achievable reliability/10 | Complexity/10 | New production/shared LOC | New product integration LOC | New tests/fixture LOC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Reuse one actual product receiver/persistence/custodian for direct controlled restart, downtime allowed |8|9 after actual product gates|4|0 assumed|150–500 provisional until actual seam inspection|600–1,400|
| Add optional Temporal scheduling above that same qualified operation |8|9 after receiver/custody qualification|5|80–220 adapter mechanics|70–230 incremental|500–1,100 incremental|
| Add a new generic Host/second supervisor to solve these measured fixture questions |3|6|8|800–2,000 speculative|200–600 per consumer|1,500–3,500|

The third option remains unjustified and outside authorization. The second is
not required by these results and belongs to the scheduling track. A native
rewrite offers no demonstrated benefit for this missing receiver policy.

## Remaining real integration gates

Choose the first actual product extension family and its availability/trust
contract. Apply the acceptance order and accepted-work policy at its real
authoritative receiver, canonical store and already admitted execution custodian.
Prove actual immutable-artifact selection, product package pin, startup failure,
late-result reconciliation, physical-absence uncertainty/debt and deployment
cleanup at those joins. This file-backed fixture is not a PostgreSQL/product
transaction integration. Full custodian death, arbitrary descendants, hostile
code, exclusive resources, private-state migration, sudden power loss, cross-OS
delivery and aggregate plugin capacity remain unqualified.

Peer plan criticism and each disposition are retained in the plan/review files.
The experiment stops here: no optional churn or broad suite follows the resolved
three uncertainties. Root owns evidence integration, governed docs, commits and
publication.

## Sources versus executed evidence

Current authority and frozen executable evidence are linked by the campaign
`context.md`, `plans/restart.md` and the source-copy inventory. Official docs
checked on2026-10-26 grounded only the design, not these execution claims:
[Node child process](https://nodejs.org/api/child_process.html), rendered26.12.1
moving documentation; [NGINX control](https://nginx.org/en/docs/control.html),
unversioned; and [Envoy1.37.7 draining](https://www.envoyproxy.io/docs/envoy/v1.37.7/intro/arch_overview/operations/draining).
They distinguish admission/drain, signal-send, transport status and physical
exit. None was installed or executed. The actual local run was Node26.11.1 and
its exact own inputs, commands, failures and receipts remain reproducible below
`experiments/restart/`.
