# Independent restart-result review by plugin-boundaries track

Date: 2026-10-26 UTC. Status: **source, raw-result and custody-receipt review;
no tests repeated by this reviewer**. The restart narrative report was not yet
present at initial review; it subsequently became available and was read in
full, including the finite registrar and inherited L07 qualifications.

## Verdict

The selected corrected fixture observations are supported. I found no material
false-pass in the executed RST01, refined RST02 or RST03 rows. The newly applied
candidate-absence oracle also fails against the unsealed baseline, and its
fresh-worker readback retains the bad pending candidate. This is stronger
evidence than the historical S07 follow-through alone.

The recommendation can remain narrow: reuse a receiver-local monotonic seal in
the existing acceptance queue, retain the existing attempt for readiness failure
and cleanup retry, and preserve semantic outcome versus physical effect/result/
exit distinctions in the existing custody owner. These observations do not
qualify a product Host, fully durable filesystem commit, universal process-tree
custody, recovery after Supervisor loss or production library publication.

## Reviewed evidence identities

I read the entire corrected tests, actual owner/worker/custodian/effect/probe
changes, baseline absence control, outer runner, latest raw TAP/stderr, actual
canonical/event/physical-file result JSON, live namespace identities, registry
and cleanup receipts. I compared changed recovery code against the frozen
20261025 sources. Exact anchors at review time:

| Input under `experiments/restart/` | SHA-256 |
| --- | --- |
| `corrected/tests/restart.test.ts` | `3eb8f53555bd2b41d3697078cc66e79b52a5cb6de972a8512666f5b5fb0907b7` |
| `corrected/upstream/recovery/src/operation-owner.ts` | `dd72fd83dfe9b8ad3692dbbdab367330c724e40fa22ea2f1fc5c38301f2fed41` |
| `corrected/upstream/recovery/src/worker.ts` | `05a56e3c0a6b64aba475da0bb2d97fd0b97ce0e4e5261853158585505a4d25a5` |
| `corrected/upstream/recovery/src/supervisor.ts` | `295a16430f52fa4f7dd807da49a380360b8f2de70cc54089cb10f7d025e12888` |
| `results/corrected-rst01-custody.json` | `91c29bacd89785700f376e9a5ace61112f45346186ca31c9af0f866236a62a9f` |
| `results/corrected-rst02-custody.json` | `1ec1c7ffafb074f814de26861b63c9479b5dad1d5a72632b83dcda715ca8cfbd` |
| `results/corrected-rst03-custody.json` | `d64d4523b49a65ecc82e734e281d21fb4d384fa7e9d03ca8481effd2a07a0cc5` |
| `results/baseline-absence-custody.json` | `51ebf277c1259a08ae58f403cb2d6b91475610ab542a915125d5f84544d5e232` |

The actual runtime in these receipts is Node26.11.1. Public dependency/toolchain
identity and strict compile records remain the owning track's responsibility;
this review does not imply a separate frozen install or independent reexecution.

## RST01: corrected acceptance ordering and rejecting sensitivity

The production-like behavior under test is in the copied fixture, not a deployed
product. The correction is appropriately small:

- A separate `admissionSealed` fact lives in `OperationOwner`, with its
  `sealAdmission()` transition queued in the same sole serialized chain as submit.
- Submit still performs existing identity/conflict lookup before rejecting a new
  identity at the sealed gate, and the rejection precedes reserve/snapshot work.
- Worker stop synchronously enqueues seal and closes scheduling, releases held
  barriers, awaits actual seal completion, emits its ACK, then enumerates accepted
  records for stop/revocation. Reconciliation clears the storage freeze without
  clearing this independent seal.

The four actual corrected rows cover both existing profiles. The post-seal
submission is issued only after the actual `admission-sealed` event, old revocation
and real old-effect exit. The test reads canonical bytes independently before/
after rejection, checks absence, requires the exact sealed error, and examines
identity-qualified monotonically sequenced receiver reserve/permission/launch
audit events. It then reconciles, rejects another distinct identity and checks
the same properties. A fresh worker confirms both rejected candidates remain
absent; the old accepted operation's duplicate and conflicting fingerprint
retain their proper readback/conflict behavior without another acquisition.

The other two rows hold an existing submit at the actual synced/closed-temp-file
boundary before rename. They prove `stop-requested` precedes canonical acceptance,
which precedes seal completion. That accepted pending record survives joined
stop with zero old launches and a released reservation. Fresh `record-only`
keeps it pending with zero fresh reserves; `restart-pending` makes exactly one
new reservation and one actual child/effect. Duplicate readback does not relaunch.
This is the correct distinction between a pre-seal accepted cohort and a new
post-seal identity; no retroactive stop-request rejection is claimed.

**Negative sensitivity:** `baseline-absence.tap` intentionally reports failure
for independent canonical absence. Its retained JSON shows `created:true`, the
candidate's reserve-attempt at receiver sequence7, durable pending presence, and
`rst01-baseline-fresh-control.json` preserves that pending candidate after restart.
The first failing assertion means its later fresh-absence assertion is not
executed, but the fresh readback was performed/saved before that failure and I
read the actual retained row. Do not imply two independent assertion failures;
the evidence is one red assertion plus an independently inspected fresh readback.

No further test is needed for this selected uncertainty. Actual product receiver
integration and other stop/accept races remain outside this finite fixture.

## RST02: the refined rerun adds the intended join only

The latest one-row TAP is green. Source and `rst02-readiness-debt.json` jointly
show successful real construction, named readiness rejection, ingress refusal,
zero publications and no module-run/business-effect entries. First stop records
one settled failed cleanup debt whose exact cause is `fixture.cleanup.failed`.
The real resource and prerequisite journal remain probeable before/during retry;
the same owner releases after its inherited barrier; both handles then return
EBADF, with exactly two cleanup attempts and one resource release.

The small rerun was useful evidence refinement: unlike the earlier JSON, the
latest JSON serializes the debt state/path/cause instead of dropping the Error's
non-enumerable details. It does not introduce a different lifecycle state machine
or claim a GM compiler defect.

Two reporting limits are necessary:

1. The test retains `const firstReport` for serialization. **Discarded-report
   authority is inherited L-07 evidence**, not a new observation of this rerun.
2. Initialization deliberately acquired a real resource and wrote a journal.
   "No effect" means no business-effect/module-run entry after failed readiness,
   not zero arbitrary initialization effects.

Do not rerun the historical L-07 matrix solely to repeat the already retained
mechanism. This one readiness-rejection × cleanup-debt join is sufficient.

## RST03: actual effect, message, canonical outcome and exit are separate

The copied custodian's original `finished` semantics are preserved: it does not
resolve at child result/disconnect, and `wait-result` still waits for exit plus
artifact handling. New methods/events expose observation and planned retirement
without changing that release condition.

**A — real effect before cancellation.** The child appends and syncs its actual
file, then holds before success send. The independent test parent reads the
known live file and checks its literal operation/value line before canceling.
The retained hash/bytes in `rst03a-before-cancel.json` are independent of the
custodian's later artifact cache. Actual cancel chooses canonical CANCELLED;
actual released child success is observed; the child naturally exits0 with no
signal; close and mapped process absence follow. The canonical result remains
CANCELLED after actual work settles and fresh-worker duplicate readback. Exactly
one launch/file effect remains. No message or in-memory synthetic late-success
substitute is used.

**B — result/disconnect while physically live.** The child sends actual success
and disconnects, but its explicit live timer keeps the same native process
incarnation present. The test independently reads the effect file. After named
result/disconnect/revocation observations, the200ms observer deadline leaves
worker stop unsettled, the exact operation reservation retained, occupied count1,
and launches1. Writer refusal alone would be inadequate, but the receipt also
contains those separate live-process/reservation facts. Planned exact-handle
SIGKILL then yields actual exit/close and native absence before stop completes
and a fresh worker starts. Final canonical cancellation and duplicate readback
do not add another effect.

The200ms wait is an explicit pending-observation window after named barriers;
it is not evidence of general scheduling bounds or the cause of earlier events.
Planned forced retirement is not graceful drain and does not establish plugin
cleanup callbacks. No emergency watchdog was used in the selected runs.

## Cleanup evidence and the remaining harness limitation

The latest outer receipts reconcile with the tests' finite known process creates:

| Group | Actual tests/outcome | Registered workers/effects | Final observations |
| --- | --- | ---: | --- |
| Corrected RST01 |4/4; child exit0|8 /3|All registered incarnations absent; no rescue/debt|
| Refined RST02 |1/1; child exit0|0 /0|Real FD assertions inside test; no process cleanup claim|
| Corrected RST03 |2/2; child exit0|4 /2|All registered incarnations absent; no rescue/debt|
| Baseline absence control |Required assertion red; child exit1|2 /1|All registered incarnations absent; no rescue/debt|
| Original S07 controls |Required assertions red; child exit1|4 /3|All registered incarnations absent; no rescue/debt|

Every reviewed receipt has `deadline:false`, `outputExceeded:false`, no
unplanned `retirements`, empty `unresolved` and `cleanupQualified:true`. Native
proc observations retain namespace ID, host PID and start time; they do not
mistake a missing namespace-number path for physical absence. Earlier failed
identity and empty-pipe-capture attempts are retained separately and do not
contribute green test claims. Direct file descriptors preserve the latest TAP.

**Harness limitation, not a contradiction of these finite results:**
`registerProcess()` silently omits a child if process mapping is unavailable.
The outer runner can then only assess the supplied registry; `cleanupQualified`
is not a generic fail-closed proof of complete child registration. For the
reviewed executions, registry counts match every expected worker/effect create,
and relevant live identities are present, so the finite cleanup observations
are supported. Do not generalize them to arbitrary new scenarios, inaccessible
procfs or arbitrary descendants. A future harness delivery should fail closed
on registration failure before releasing a fault. That source-hardening choice
does not require repeating the current tests absent another material uncertainty.

The same caution applies to process-tree inventory and Supervisor death: neither
was qualified. In addition, file sync plus rename without a demonstrated parent
directory fsync/recovery model is not a power-loss commit contract. Preserve the
process-restart scope in every "durable acceptance" sentence.

## Final disposition

Accept the bounded fixture evidence with the above claim limits. No new runtime
or test matrix is justified. Final synthesis should explicitly separate:
corrected receiver policy; observed canonical bytes; actual effect bytes; child
message; semantic result; real process exit/close/absence; and cleanup debt.
The raw rejected baseline remains red and should never be blended into a
success percentage. Product integration, physical-custody-owner recovery and
filesystem/power-loss guarantees remain separate gates.

## Narrative report follow-through

The subsequently reviewed `reports/restart.md` carries the required distinctions:
reviewed SHA256 `13fa318df4db92dd05a5e9d8fa6ae5ba2db55fb01b5d60dc2db1f3f1a070b3f7`.
It preserves
seven positive fixture cases and three separate deliberate red witnesses;
receiver-local correction rather than product qualification; earlier queued
acceptance allowed; actual fresh-worker absence; named readiness debt and real
FD probes; real synced effect versus semantic cancellation; planned force
retirement versus emergency watchdog; process-restart rather than power-loss
persistence; finite registrar cardinality rather than generic fail-closed
custody; and historical discarded-report evidence rather than an invented new
rerun claim. Its reported17 positive-fixture worker/effect incarnations and10
red-control incarnations reconcile with the latest retained registries.

No additional execution is requested by this review. Source hardening for a
future reusable harness and real product integration remain future work, with
their own owner and rejecting evidence.
