# Independent review: actual awaited initializer refinement

Date: 2026-10-26 UTC. Reviewer: plugin-boundaries track. **Read-only source,
receipt and report review; no test or build repeated.**

## Verdict

Accept the single refinement observation within its stated TEST scope. It closes
the specific gap in original PB03-2: the new initializer really is awaited by a
retained startup Promise. The source/receipt does not merely create an unused
Promise and choose to suppress readiness. The same-process release-to-ready
positive supplies a meaningful control against a broken readiness path.

The original plugin-boundary evidence remains frozen and should retain its
weaker claim. This supplementary result must not retroactively turn PB03-2 into
an actual awaited-initializer experiment or qualify a production Host.

## Exact reviewed subjects

| Input under `experiments/plugin-boundaries-async-refinement/` | SHA256 |
| --- | --- |
| `src/initializer.ts` | `44aea4905a1ba96cd7d6196caaf973ff49cc6b9b2257f536beaefe551a0f978d` |
| `src/run.ts` | `67195f120a4ab8d55df10dc6529de945af2ab349f75d1c89f15fa1bd3960d196` |
| `results/observation.json` | `4993dd95f10eefefc94781930fcb8987bc2328d1a98e308a104491ec1cb257ca` |
| `REPORT.md` | `bdec11a122d36979a4dd45fd5fc7c73b34ea8c128e8c3c213b285b49c50392a7` |

I also read the pre-code plan, source-origin receipt, retained ENOSPC failure
receipt and the copied observer's original source. Its stated origin hash,
`5275ff31a8f2b0d8d0dd0aa9b0043776bfc4b16ab4756af3d21b8af17f6af06b`,
matches the frozen original PB observer. The plan was reviewed before execution;
the requested observed ordering, parent-read markers and exactly-one-ready
through normal exit were incorporated.

## Why the observation resolves the gap

Source shows these actual relationships:

1. `async initialize()` writes `entered`, emits its entry message and **awaits**
   the deferred gate before appending `returned` and returning `initialized`.
2. The retained `startup` Promise **awaits initialize()**, then emits ready using
   its returned value. It cannot emit ready through that path before the gate.
3. Shutdown **awaits that same startup**, emits `startup-joined` and disconnects.
   It does not drop the awaited operation merely because the parent observed a
   deadline.

The independent parent supplied distinct literal expectations, fresh nonces and
native identity observations. The retained result contains:

- Successful pre-go, post-entered and post-deadline pings with three distinct
  nonces; an earlier buffered pong cannot qualify later responsiveness.
- A503.37ms no-ready observation, parent-read file exactly `entered\n`, and the
  same mapped live native process incarnation. This is pending observation, not
  cancellation or physical cleanup evidence.
- An explicit release sent at642.335ms, then actual ordered messages:
  release-received642.671ms, initializer-returned642.699ms, ready642.751ms and
  startup-joined643.231ms on the parent clock.
- Actual ready literal `initialized` and independently read file exactly
  `entered\nreturned\n`. Exactly one ready remained observed through actual
  normal process exit, rather than being counted only before shutdown began.
- Actual exit0/no signal, stdio close and exact mapped native process absence;
  `rescueUsed:false`, `failed:null` and `finalAbsent:true`. Namespace PID16 mapped
  to native proc PID1185329/start time5036502, preserving the procfs distinction.

That reachable positive is the useful negative-control complement: a permanently
broken readiness emitter could have passed a no-ready-only test, but could not
produce this actual awaited return/ready/join/normal-exit sequence.

## Failure handling and claim limits

The first attempt's strict build returned2 with no diagnostic bytes; later
inspection found ENOSPC at sandbox startup and a4096-byte partial observer emit.
No observation result or pass is claimed for that attempt. The retained receipt
correctly labels this an ENOSPC-era incomplete attempt and does not infer a
TypeScript semantic defect from an empty diagnostic file. It is separate from
the later successful strict build and single selected execution.

The result remains deliberately narrow. Harness IPC supplies physical liveness;
an unresolved Promise or its awaiting caller is not itself a native-resource
oracle. The gate is test-owned scheduling injection. The10s `bounded()` race is
in the observing process, not an independently preempting watchdog. The report
states that distinction, and current success required normal exit without rescue.
No generic hard-deadline or cleanup-under-observer-death claim follows.

This row does not qualify automatic cancellation, plugin-owned resource cleanup,
arbitrary initialization effects, long-lived accepted-work drain, hostile code,
physical process-tree containment or production lifecycle policy. No additional
placement, fault, original PB rerun or framework is necessary for this resolved
uncertainty. Production/shared-runtime/integration LOC remain0.

The final report accurately carries those limits. **No further execution or
source change is requested by this review.**
