# Independent result critique: plugin boundaries

Reviewer: restart track. Date: 2026-10-26. Scope: source/retained-result audit of
`reports/plugin-boundaries.md` and `experiments/plugin-boundaries/`. **No plugin
experiment, compiler, dependency install or broad repeat was run by this critic.**
The small receipt-consistency audit and both checksum validations are read-only.

## Disposition

**Retain and integrate PB-01, PB-02 and the actual loop-placement/retirement
observations.** Their important negative controls, byte-race ordering and native
process/task evidence are supported. No hostile isolation, arbitrary closure,
production artifact admission or generic custody qualification follows, and the
report mostly preserves those limits correctly.

**Narrow PB03-2 to what actually ran.** Its source creates an unused pending
Promise and deliberately withholds `ready`; it does not invoke and await an
actual asynchronous initializer. Its pings/native exit are real, but it cannot
qualify actual awaited initializer ownership. Root has separately authorized one
small new correction artifact after this frozen review. Do not edit or replace
the original PB source, results or manifests, and do not rerun the PB campaign.

Also describe the existing `bounded()` timers as observation limits, not a
qualification of a universal hard outer deadline/cleanup mechanism. They race
Promises without cancelling the losing continuation. Actual finite exits and
absence in this run remain supported; failure cleanup under every timeout does
not inherit that qualification.

## Audited identity and count anchors

Both commands completed successfully without changing files:

```sh
sha256sum --check --quiet SHA256SUMS
sha256sum --check --quiet INPUTS-AND-REPORT-SHA256SUMS
```

The payload manifest has68 entries, SHA-256
`2daee9e2fb89a2be62c03e6f5b9d2f759057f0ce9913fc397c6beb3f2741f536`.
The input/report manifest SHA-256 is
`33c9d4dd3c6d307183e2d4231a2079953ef3496a5db41ff7e0d243120fa5733d`.
Reviewed report SHA-256:
`ead69a03535232a2748c6c79be4fabe729f21ad730c1fa37d16c3246c464c845`.
The strict config includes every fixture `.ts`, `strict:true`,
`skipLibCheck:false` and `noEmitOnError:true`; source totals571 TypeScript lines.
This is an audit of reported build evidence, not my independent rebuild.

`attempt-1` has zero successful rows, one direct child, actual public
`identity.invalid` stderr and a later parent missing-done deadline. The recorded
child exited and was absent. The malformed source/data and cleanup inventory
remain retained. This failure was not converted into zero-evaluation success.

`attempt-2` has16 recorded rows: six PB01, four PB02, five new PB03 trials and
one explicitly reused import-failure row. It is **not16 independently executed
new tests**. Its17 direct owned children all have `exited:true` and
`absent:true`; the explicitly nested plugin process and Worker task have
additional individual-row evidence. No repeated churn or physical resource
bound is established by those finite observations.

## PB-01: actual public validation precedes candidate evaluation

Source inspection confirms `pb1.ts` imports only Node built-ins and actual
public `compileCompositionJson` before admission. Its inert declaration/profile
JSON is read as bytes. No candidate module or barrel is in that pre-admission
runtime import closure. Public Core supplies graph validation; the TEST seam
supplies deferred loading and its illustrative byte/loader policy.

The selected result has actual public selection IDs A/root, matching selected
loader IDs, literal invocation output `A` and independent parent-read markers
exactly A/root. Installed B remains unmarked. Source and emitted fixture identity
show B's marker-writing module exists; no generic discovery/import scan occurs.

The incompatible row retains actual public
`binding.compatibility-mismatch`, provider coordinate and exact expected r1 /
actual r2 compatibility tokens. It exits normally0 with stdio close and mapped
process absence before the parent asserts empty markers. Byte mismatch and
selected-loader mismatch similarly retain their precise TEST gate results,
normal exit and empty markers. These are stronger than a no-progress/timeout
absence assertion.

The same selected-A positive proves its marker/path/callable works. The
executable-first control performs actual import, writes synchronous
`bad-evaluated-before-throw`, catches the import throw and exits normally. It
independently demonstrates that a rejected executable-first compatibility path
can already have side effects. No assertion merely substitutes zero factory
calls for zero evaluation.

**Limits:** the post-check imports are the fixed A/root literal loaders; this
qualifies that tiny selected graph/sequencing, not arbitrary graph execution.
The byte row checks only A's emitted file. It is not package closure, artifact
authentication, a public extension admission implementation or protection
against modified JS intrinsics/hostile code. The report states these limits; no
new runtime or broader test is needed.

## PB-02: full receipt really precedes the controlled replacement

The expected two-file receipt is frozen by the parent from designated emitted
baseline bytes before mutation, separately from the child verifier's expected
environment input. Actual hard-coded callable outputs and marker literals are
not generated from that metadata or the verifier's decision.

I independently checked the retained JSON consistency:

- Helper-only edit leaves entry hash unchanged and changes helper hash; actual
  fresh output/markers are `old-entry/new-helper`.
- Root query re-import produces two entry evaluations but only one old-helper
  evaluation in the same process; a fresh process sees the changed helper.
- PB02-3's actual child `verified-full` hashes equal the parent expected receipt
  and parent's independent pre-mutation hashes. The parent then atomically
  replaces the **same entry path** before releasing the literal import. Entry
  hash changes, helper remains equal, and actual output/markers become
  `new-entry/old-helper`. Child post-load hashes equal the replacement hashes.
- The two separate coherent directories retain equal before/after hashes,
  independently expected old/old versus new/new outputs, normal exits and
  native process absence.

The sequential awaited source ordering closes the measurement ambiguity:
verification ACK, independent parent verification, actual rename replacement,
then release/import. No sleep is used to infer the verify/load race.

This is a decisive counterexample to the claim that a full content hash plus
fresh process lifetime closes mutable-path loading. The report correctly makes
its coherent-artifact recommendation conditional on another existing owner
holding the full selected closure fixed. It does not claim to enforce that
custody. No extra signature loader or archive mechanism is requested.

## PB-03: physical task/process evidence is real and narrowly scoped

The Worker synchronously reads `/proc/thread-self` from its own JavaScript
thread. In the actual receipt it reports `1156194/task/1156201`; the outer
observer independently maps known namespace PID157 to native process1156194,
reads native task1156201's live start time and later observes that exact task
absent. The host remains the same native incarnation and answers a new
post-termination nonce. Worker exit1 and terminate fulfillment1 corroborate,
rather than replace, the native task observation. Node's JS Worker `threadId`
is not substituted for a native TID.

The child-process trial independently maps plugin PID172 to native1156209;
the host is a different retained process1156202. It records successful SIGTERM
send, IPC disconnect, actual null-code/SIGTERM exit, stdio close and mapped
process absence separately. The host answers new pings after plugin retirement,
then itself exits0/closes/is absent. Signal send alone was not used as success.

For each loop placement, a before-go ping succeeded and the decisive new nonce
was sent after the explicit started marker. In-process loop times out while
its exact host remains live, then planned SIGKILL has actual exit/close/absence.
Worker/process placements answer during their loop and after its retirement.
Persisting startup marker bytes independently demonstrate that physical
termination did not reverse earlier file effects.

### Required qualification correction: PB03-2

`host.ts`'s async branch is `void new Promise<void>(() => {}); return;`. The
pending Promise is neither returned nor retained by an actual initializer
startup path, and no caller awaits it. The parent correctly observes no ready
message for500ms, continuing pings, then normal IPC-driven shutdown and exact
process absence. Those observations are valid. They establish a responsive
host deliberately withholding readiness, not ownership or cancellation of an
actually awaited asynchronous initialization.

The report already excludes a plugin-owned native-resource leak and correctly
says harness IPC keeps the host alive. Preserve those limits, and do not promote
the row into async initializer lifetime/drain qualification. Root's separately
authorized one-row refinement should explicitly await an initializer, retain
its startup Promise, gate readiness on actual awaited return and independently
observe no-ready/pings before releasing that gate. This is a new narrow artifact,
not a reason to erase or broadly repeat the frozen campaign.

### Required reporting limit: timers and generic cleanup

`bounded()` uses Promise.race and clears only its timer. A group timeout does not
cancel an already running coroutine or provide a separate watchdog that can
terminate the observing process itself. Output overflow throws in a data event;
generic cleanup after arbitrary observer failure is not exercised. The native
PID cache also has no general reuse-invalidation proof. No such event occurred
in the selected successful run, and its exact finite cleanup evidence is sound.

Publish actual per-row deadlines, planned forced retirements and final absence
as observed facts. Do not call this a qualified hard outer wallclock envelope,
fail-closed universal process registrar or arbitrary descendant supervisor.
No additional watchdog test or infrastructure is justified for these resolved
finite questions; a real product custodian must qualify its own mechanism.

## Sandbox and production claims

The fixtures run as UID0 trusted code and can write their marker paths. Worker
engine limits are not whole-process memory/OS limits; child separation is not
hostile-code isolation. Native addons, global OOM, permissions, arbitrary
descendants, native code unload, long-lived work, external effects and
production admission are all excluded in the reviewed report. I found no
unsupported sandbox claim in its findings/recommendation.

Complete immutable artifact custody remains a named prerequisite rather than
an inferred success. No production Host, second supervisor or public SPI is
introduced. The comparison scores are engineering judgments, explicitly scoped
and not measured reliability. Preserve those distinctions in root's synthesis.

## Remaining action

No broad repeat or missing native fact is requested. Integrate the supported
findings with the two reporting limits above. Keep the async correction as its
separate explicitly authorized one-row follow-up after peer plan criticism.
This critic adds0 production/integration/test implementation LOC and does not
modify the frozen PB report, sources or manifests.
