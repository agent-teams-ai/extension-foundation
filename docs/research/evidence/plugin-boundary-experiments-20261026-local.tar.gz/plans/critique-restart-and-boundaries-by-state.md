# Independent state/recovery critique of restart and plugin-boundary plans

Review date: 2026-10-26. Reviewer: state-recovery track. **Plan/source review only; no experiment, installation or execution performed.** Reviewed `plans/restart.md`, `plans/plugin-boundaries.md`, the full owner brief, retained current engineering standard, and the relevant frozen actual `OperationOwner`, `SnapshotStore`, worker, Supervisor, effect, attempt-owner, lifetime tests and S07 counterexample sources. Historical evidence and other tracks' files remain unmodified.

## Disposition

**Proceed after the mandatory clarifications below.** These are useful small experiments, with suitable independent OS/file observations and honest ownership boundaries. They do not need a new Host, generic schema/lifecycle manager, workflow engine, supervisor or hash-verification library. The strongest new results would be the corrected ingress absence/no-reservation oracle, the real late-result/live-process traces, and a whole-fixture-artifact verification/load counterexample. RST-02 is a reasonable small join, but its inherited cleanup mechanisms should not become another lifetime matrix.

The plans correctly distinguish the old S07 failure from data loss; use actual module-evaluation markers rather than factory counts; retain unknown cleanup instead of calling a timeout success; and limit fresh-process loading to its declared trusted profile. Keep those distinctions in the final reports. Resource prerequisites are unchanged: root handles the environment; this review does not authorize downloads, use of read-only `/dev/shm`, unrelated cleanup or weakening the state-recovery disk gate.

## Mandatory plan fixes before implementation

### M1 — Make permanent admission seal survive reconciliation, and narrow the linearization claim

Target: RST-01's corrected owner/stop sequence and oracle. Severity: material correctness/evidence gap; small change.

The proposed ordering is sound for the stated fixture if `seal()` **synchronously enters the same sole transition queue** before the first stop await, dispatch scheduling closes immediately, and stop enumerates accepted records only after the seal flight settles. An already queued submit can reserve and replace the canonical file before the queued seal; it is legitimately in the accepted cohort. A later command must reject before reserve or file mutation. The proposed pre-rename barrier is a useful actual boundary for proving this ordering.

However, the existing owner has a separate storage `frozen` Boolean that `reconcile()` deliberately clears, and the Supervisor's `reconciled` RPC clears its freeze projection. The new admission seal must be a distinct monotonic live admission fact, never an alias for that recovery flag. The plan names reopening after reconciliation as a falsifier but has no explicit scenario causing reconciliation in the stopped-but-connected window.

**Minimum fix:** add one existing `reconcile()` call in the held-ACK post-seal window, then retry a new distinct identity. Require the same sealed rejection, zero reserve RPC attempts and durable absence before/after a fresh-worker readback. Duplicate/conflict lookup for an already accepted identity remains separate from new admission. This is a few assertions in the selected scenario, not another test matrix.

Also define “no dispatch starts after closing” precisely. A dispatch function already suspended before stop can resume, and a queued claim can complete after seal for previously accepted work. The intended decisive property is no **new physical launch/unauthorized handoff** after its allowed boundary, together with the declared pending disposition; do not fail a legitimate queue continuation merely because its function or bookkeeping event ran later.

The file store synchronizes the temporary file and renames it; it does not establish a general power-loss commit protocol. Call the observed point canonical file replacement/fixture acceptance, and bind any “durable” wording to this process-restart profile. Neither successful rename nor this experiment qualifies sudden power loss or a filesystem flush contract.

### M2 — Preserve independent physical-effect evidence and identify planned forced retirement

Target: RST-03, with a wording correction in RST-02. Severity: material claim/false-positive risk; no new subsystem needed.

The actual source supports the intended semantic/physical separation: `cancel()` invokes live stop/revocation before its queued canonical replacement; `recordResult()` retains an existing terminal result; `wait-result` waits for the effect's finished flight; that flight resolves only after native exit and artifact processing. A late success message, cancellation receipt, canonical CANCELLED record, file append, effect exit and worker exit are therefore six different facts.

The custodian currently deletes the effect file after exit and caches its contents. Reading only the custodian's later `artifact` field would partly reuse the implementation's own interpretation as the physical-effect oracle.

**Minimum fix:** in Scenario A, after the named sync/held-result boundary but before cancellation, have the independent test parent read the actual known effect path and retain those bytes/hash. Observe exactly the literal operation/value line independently. After late message/exit, compare this evidence with canonical cancellation and the custodian's retained artifact. No extra effect sink or receipt ledger is required. Describe the result as a completed file effect in this process profile, not power-loss durability or arbitrary external-effect reconciliation.

For Scenario B, name the intentional final termination as **planned force retirement**, record the requested signal separately from actual native exit/close and PID identity/absence, and report it as force retirement rather than graceful drain. This is different from the emergency watchdog: an expected explicit force-retirement step can pass its narrow physical-stop assertion, whereas a watchdog needed to recover a stuck test fails qualification. An intact semantic result does not certify any cleanup that forced termination bypassed.

The existing single-writer `start()` refusal is based on a live incumbent worker; refusal alone therefore does not prove the effect's reservation remains occupied. Require the actual effect PID to stay alive, the exact operation reservation to remain present and launch count unchanged, as the plan already proposes in aggregate. Keep those three observations individually visible.

RST-02's “no effect” wording must mean **no module-run/business-effect journal entry**. The candidate deliberately created a real resource and journal before readiness failed. That is already external initialization activity. A zero business-effect count is useful; it cannot support zero arbitrary initialization effects. PB-03 C6 supplies the complementary counterexample without expanding RST-02.

### M3 — Keep cleanup authority alive when the outer deadline fires

Target: all enclosing process caps, especially RST-03 and PB-03 C5. Severity: execution safety/measurement validity prerequisite.

Each plan correctly requires an outer wallclock bound and exact owned handles. Make the enforcement location explicit before coding. If the outer watchdog kills the test process that holds the Supervisor/host handles first, that process cannot run its finally block; its child effects can remain alive. Killing a host is not a generic descendant-stop operation. The Node child-process documentation makes signal receipt, termination and descendant behavior separate facts.[N1]

**Minimum fix:** the surviving outer observer must retain the bounded task child identities before barriers release and retain authority to terminate/join every explicitly created child if the inner owner stalls. A task-owned process group with verified membership or an explicit known-PID/start-time inventory is sufficient for these fixtures. There is no arbitrary descendant spawning, so no general containment framework is justified. The outer cleanup must have its own finite exit/absence bound and emit unresolved debt instead of waiting forever. Do not count timeout status, `killed`, IPC disconnect or a terminated shell/host PID as successful child cleanup.

This may already be the intended implementation of “retains owned handle cleanup”; the mandatory change is to make it concrete and reviewable, not add another experiment.

### M4 — Demonstrate that a complete fixture hash still has the verify/load gap

Target: PB-02 group3 and recommendation/score wording. Severity: material inference gap; strengthen the existing row rather than add a row.

Group1 correctly falsifies entry-only identity by changing a helper. Group3 currently says “receipt/hash ACK” without fixing whether the accepted receipt covers the entry alone or both files. If it covers only the entry, the reader can mistakenly conclude that hashing the full artifact solves the independently demonstrated race.

**Minimum fix:** make group3's child verify the **entire declared two-file fixture artifact** and ACK the exact accepted entry/helper digests. The independent parent must verify that both actual files match those accepted digests before mutating the selected entry, then atomically replace that entry at the same path and release the unchanged literal loader. Record the old accepted complete receipt, new actual full-file digests and replacement literal output/marker. That one row then demonstrates that whole-artifact identity plus mutable path loading still lacks byte custody.

The coherent A/B positive is a valid trusted static-build demonstration because both directories are deliberately left unchanged. It is not an enforcement test that they are immutable. Say explicitly that **fresh process lifetime and complete content identity do not close verify/load race**. The positive recommendation/9-of-10 reliability judgment is conditional on the actual artifact/execution owner keeping the entire selected closure fixed through evaluation. Protection against a writable artifact, signature admission, archive extraction and hostile writers remain unqualified. No new loader hook, temp-copy deployment scheme or file-descriptor loader needs to be invented to resolve this plan.

### M5 — Keep byte receipts and expected policy outside the verifier under test

Target: PB-01 P4 and PB-02 digests/positive controls. Severity: oracle-definition requirement, largely consistent with the existing plan.

The independent literal outputs and parent-read marker files are strong. Preserve them. Before mutation, freeze the expected receipt from the designated prebuilt A bytes, and have the parent independently read/hash those exact inputs. The tested admission helper must not generate the expected receipt from whichever candidate files happen to exist at test time, nor generate the expected output from metadata or its own admit/reject result. A checksum routine compared with itself can be correct mechanically while admitting the wrong policy/input.

**Minimum fix:** make that custody/expectation origin explicit in the plan and keep raw fixture bytes/source hashes in retained evidence. P4 must show one known pre-receipt byte identity, a deliberate post-receipt mismatch, no selected-entry marker and the actual mismatch diagnostic. P1/direct import proves marker visibility and the path are working. An absent marker after a killed/timed-out child is inconclusive; a negative zero-evaluation row requires the expected rejection and a normal observed exit. A named compiler diagnostic must come from the actual released public compiler, not a hand-authored JSON imitation.

This qualifies the experiment's sequencing and the selected instrumented files, not complete artifact admission. The plans already state the latter limit; keep it prominent when reporting a green result.

### M6 — Do not infer a live resource from an unresolved Promise

Target: PB-03 C2. Severity: small but concrete fixture/claim ambiguity.

C2 specifies a marker and an initialization Promise that never settles, then infers that an observer timeout does not remove listener/resource ownership. A pending Promise by itself need not keep a Node process alive. Node documents normal exit when no work remains; an unresolved top-level await can instead produce exit13.[N2,N3] The host's IPC listener may keep the host alive, but that is not evidence of a plugin-owned resource.

**Minimum fix:** either narrow C2 to “startup remains unresolved while the independently responsive host stays alive,” with no plugin-resource-cleanup assertion, or use one real already justified fixture-owned listener/file handle and probe its continued ownership after the observation timeout. Record what keeps the host alive. Do not multiply this by every placement or build a resource abstraction. C3/C4/C5 already answer interruption/physical-stop differences.

## Optional simplifications and additions — not execution blockers

- **RST-02:** retain only the readiness-rejection + first-cleanup-failure join and the actual open/closed native handle observations. Reuse the unchanged early-journal-close counterexample through source/hash evidence when its inputs are unchanged, as the plan already allows. No full L01–L07 rerun is needed.
- **PB-01 child budget:** P1–P6 already consume six fresh children. Clarify that P1 is also the direct selected-import/marker positive, or adjust the count for an additional control. No extra run is needed if P1 establishes the same fact. There is no reason to spend a repeat unless a concrete failure/critic question requires it.
- **PB-02 surprising cache result:** preserve it as an actual observation and report exact resolved URLs. A surprise is not necessarily a failed artifact-safety claim; the cache row is exploratory. Do not add custom eviction or mutate the hypothesis into the expected answer.
- **RST-01 record bytes:** the existing byte-equality/identity-absence plus zero-reserve oracle is sufficient. Do not add a second database/command ledger to this file-backed fixture. Recovery from a process crash and full Supervisor death remain separate, explicitly unqualified boundaries.
- **Cross-track effect claims:** use a compact evidence table in reports with command receipt, canonical semantic state, actual file bytes, local result message, exact process exit and cleanup debt. This is presentation of existing evidence, not new runtime state.

## Unchanged boundaries and go criteria

The review does not reopen static restart, require overlap availability, adopt GM's optional lifecycle candidate, or reopen the accepted native Temporal choice. A native process boundary does not demonstrate hostile plugin security or rollback of arbitrary external effects. A zero evaluation marker is an instrumented-file result; a coherent A/B restart is not a public SPI/Host implementation. These limitations are already appropriate in both plans.

Execution can start after the owners dispose M1–M6 in their plans, root approves the bounded rows and the shared runtime/disk prerequisites are met. Root may trim already answered rows. Do not turn this critique into extra approval rituals or a request for a new architecture. This review approves no production code or installation.

## Primary-source check for this critique

Retrieved2026-10-26. The current rendered Node documentation identifies v26.12.1; it is source grounding, not a claim about the executed/toolchain version. No Node process experiment was run by this reviewer.

- **N1:** [Node child_process](https://nodejs.org/api/child_process.html), sections subprocess.killed, kill, exit/close and detached processes: signal delivery does not establish termination; terminating a parent on Linux need not terminate its child processes. The spawned process/known descendant must have independent exit/absence evidence.
- **N2:** [Node process beforeExit](https://nodejs.org/api/process.html#event-beforeexit): Node can exit when its event loop has no more work. This supports requiring an actual live handle rather than equating unresolved application state with physical liveness.
- **N3:** [Node ESM top-level await](https://nodejs.org/api/esm.html#top-level-await): the documented never-resolving top-level-await example exits13. The fixture must distinguish this case from a deliberately live host with unresolved initialization.
