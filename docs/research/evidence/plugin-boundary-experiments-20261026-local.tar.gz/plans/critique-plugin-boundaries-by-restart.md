# Independent plan critique: plugin boundaries, by restart track

Date: 2026-10-26. Reviewed: `plans/plugin-boundaries.md` before implementation.
Disposition: **approve the three bounded questions after the required changes
below; no additional framework or broad matrix is needed.** No implementation,
experiment or dependency installation was performed for this critique.

## What the plan already gets right

PB-01 addresses a real gap: historical S02 checked author factory invocation but
the test statically imported both A and B. Source inspection confirms the
historical `static-selection.test.ts` and `selection.ts` import executable
providers before the test body. Their green result cannot establish zero
top-level module evaluation. The external marker/actual-callable oracle is an
appropriate way to test that separate promise.

PB-02 uses Node's real filesystem and ESM behavior rather than a new loader
model. Separate artifact roots and fresh child processes are appropriate for
the accepted controlled-restart baseline. Entry-only identity and cache-busting
counterexamples are useful, provided the full-receipt race is also kept visible.

PB-03 deliberately runs in-process hangs inside an expendable host child. It
distinguishes an observing parent from the blocked execution agent, explicitly
separates Node `threadId` from Linux TID, and allows an unavailable physical
thread-absence row. It does not equate terminated JavaScript with rolled-back
external effects or a hostile-code security boundary.

All groups have concrete stop rules, no downloaded plugin payloads, no global
OOM injection and no proposed new production supervisor. Those boundaries should
remain. The resource plan is compatible with the current roughly 30MB free only
if all dependency/toolchain access is root-managed and read-only; do not perform
an independent install.

## Required changes before execution

### R1 — Bind the actual public compiler diagnostic to inert-only inputs

**Applies to PB-01 P2/P3.** Public GM does not itself guarantee that a consumer
has not already imported its candidate executables. The current Consumer Module
Standard says the product owns inert declarations/literal imports and must
reject the selected graph before candidate import. The historical public Core
call can reject revision mismatch before Assembly execution, but its test file
has already imported executable modules. Reusing that test wholesale would
reproduce the same evidence gap.

Require the PB child entry and every runtime import it follows before admission
to exclude A/B executable modules and barrels that re-export them. Compile the
selected graph using actual released public Core from inert parsed JSON or
declaration-only modules whose entire runtime import closure is inert. Keep the
package pin/bytes, actual public result and exact stable diagnostic in the
receipt. P3 must fail with the expected public
`binding.compatibility-mismatch`, not a fixture's substitute code or a broad
"some error occurred" check. If the exact released package cannot express the
chosen inert input, retain that limitation rather than casting through an
incompatible source API or substituting a mock.

This needs only a small source/import review and the existing external markers;
no new import graph scanner is requested. State that **the target-local
sequencing** supplied pre-import behavior, while GM supplied graph validation.

### R2 — Prevent absent-marker false positives and ambiguous loader equality

**Applies to PB-01 P2–P6.** Every expected rejection must also show that the child
reached the intended admission check, returned its specified result and exited
normally. A deadline-killed child with no marker cannot pass a zero-evaluation
row: it may simply have failed before reaching the gate. The direct selected
import control must demonstrably evaluate the same marker-writing file at the
same resolved path under the same writable parent directory. Use a bounded
synchronous marker write at the beginning of module evaluation so marker
absence does not depend on an unflushed async operation.

Clarify P5's equality boundary. The full literal table can contain installed B
while only A is selected; that is necessary for P1. Compare the exact **selected
implementation set and selected loader mapping**, not all installed table keys.
An unused installed entry is different from an unexpected entry supplied as
part of the selected execution set. Pick one mismatch direction first and keep
fallback absent. No schema framework or both-direction matrix is required.

P4 may use a tiny test-owned hash check, but its result proves that one proposed
gate's ordering works. It does not qualify EF artifact admission or a general
verifier. Keep expected marker/callable literals outside the metadata and the
verifier under test, as the plan proposes.

### R3 — Demonstrate that a complete hash still leaves the verify/load race

**Applies to PB-02 scenario 3 and its decision text.** The present text permits
an entry-only receipt at the ACK barrier. That would show a real race, but leave
the most consequential inference insufficiently challenged: the comparison
table recommends a complete immutable artifact with fresh process execution.
A complete hash alone does not establish immutable custody or bind the later
path-based open performed by Node.

Use the same scenario, with no new group: let the child or independent parent
verify the **complete known two-file entry+helper receipt**, ACK that exact
receipt, then atomically replace one verified file at the same owned path before
the unchanged literal import. Require actual replacement output/marker despite
the previously matching full receipt. Preserve the before/after hashes and
barrier sequence. This independently demonstrates both facts: closure hashing
catches pre-verification helper edits, and closure hashing does not close a
subsequent path-based verify/load gap.

Keep a coherent A/B positive, but describe immutable custody as an explicit
precondition that this experiment does not enforce against a concurrent writer.
A fresh process supplies a fresh ESM cache/code lifetime; it does not itself
make files immutable, qualify package closure, authenticate a receipt or defeat
a hostile writer. Do not respond to a red race by adding re-verification loops,
cache eviction, custom loader hooks, extraction code or a second custody owner.

### R4 — Make the Worker TID oracle a real worker-thread syscall and bracket it

**Applies to PB-03 C4.** The current wording correctly requires synchronous
`/proc/thread-self` identification, and this must survive implementation. Execute
that synchronous operation inside the Worker JavaScript thread before its loop;
do not ask the host for its own thread-self, use async filesystem work that can
run on a libuv helper thread, or treat Node `worker.threadId` as the OS TID.

The independent observer should record host PID/start-time identity and actual
`/proc/<host-pid>/task/<tid>/stat` identity **while the Worker is live**, then
observe that same task absent after the terminate/exit sequence. Record the
Worker-reported mapping and the observer's direct task observation separately.
Parse `/proc/*/stat` without assuming the parenthesized comm field is a
space-free token. This is a few-line parsing concern, not a new library.

If the mapping or live-before observation is inaccessible, retain Node's
terminate/exit result with OS physical absence unqualified. Do not mark a
missing post-termination path as meaningful absence when that path was never
proved to represent the owned live Worker.

### R5 — Separate responsiveness, non-settling promises and actual resources

**Applies to PB-03 C1–C5.** Require one nonce ping success before starting the
loop and another new nonce sent after the explicit plugin start/loop marker.
The latter is the decisive responsive-sibling observation. A buffered response
from before the loop cannot establish host responsiveness during it. Record
deadline expiration in the independent outer parent for the blocked in-process
host; do not rely on the loop's own timeout callback.

C2 currently combines "promise held forever" with claims about listener/resource
ownership. A pending Promise by itself is not a native resource-leak oracle and
does not by itself require Node to remain alive. Either narrow C2 to its actual
promise/response/liveness observations, with the test host's IPC listener
explicitly keeping the host observable, or use one existing real owned resource
and probe it independently. Prefer narrowing the claim to avoid unnecessary
new fixture code. Do not attribute the harness's ping transport to a leaking
plugin resource.

The proposed 500ms response window is a test observation cap under this host,
not an application SLO or guaranteed OS scheduling delay. An unresponsive
Worker/process host must remain a retained failure, not be relabeled successful
because a later ping eventually arrives.

### R6 — Resolve cleanup debt before success and keep descendant scope honest

**Applies to all groups, especially PB-03.** Final row status must distinguish
normal completed observation, expected forced termination of the loop owner,
deadline failure, and unresolved cleanup. Expected loop termination is part of
PB-03's defined mechanism; watchdog rescue after its explicit termination bound
is a failed row, never another path to a green result. No marker directory may
be removed and no next loop trial may begin while the prior exact execution
owner remains unresolved.

Register every directly spawned child handle and its pre-fault identity before
releasing the action that can hang. Observe `exit`, and `close` where claiming
stdio/native-handle closure, separately from signal send or promise settlement.
Before any PID-based escalation, confirm it is still the same known owned live
incarnation; if already absent, do not signal the numeric PID. Retain both
runtime exit observations and independent procfs identity/absence observations
without claiming a generic PID-reuse or process-tree custody guarantee.

The historical campaign could not read procfs `children`. Therefore "owned child
enumeration" must mean the explicit direct handles created by this harness
unless actual descendant inspection works and is recorded. Since the fixture
does not intentionally spawn descendants, direct-child evidence is sufficient
for its selected scope. Mark complete descendant inventory unqualified rather
than inventing a passing empty tree or adding a process supervisor.

## Optional additions: useful only if a concrete remaining risk appears

These are **not pre-execution requirements**:

- A second loader-mismatch direction if the implementation has a materially
  different path for extra versus missing selected entries.
- A second sync-loop location (import versus initializer) only if the first
  observation leaves a real choice unresolved.
- An independent repeat requested by root/critic after observing a surprising
  cache or procfs result. No default churn/stress loop is justified.
- A package-closure/symlink/import-map test only after a real product artifact
  slice admits those mechanisms. Two owned files cannot qualify a whole Node
  dependency/distribution closure.

Do not add an archive extractor, signature verifier, permission sandbox,
native crash, OOM test, process-tree controller, registry or new Host to this
campaign. The plan's own source-backed limits are sufficient to defer those.

## Recommended execution disposition

| Group | Disposition after required changes | Result that changes the decision |
| --- | --- | --- |
| PB-01 | Execute first once exact public package bytes/toolchain are available. | Demonstrates whether the proposed inert-data/literal-load sequencing truly rejects before evaluation, and exposes any compatibility information that requires executable import. |
| PB-02 | Execute its existing four groups, strengthen the third to use the full known receipt. | Rejects entry-only identity and the stronger mistaken claim that complete hashing plus a fresh process closes writable-path TOCTOU. Supports coherent fresh-process loading only under explicit custody assumptions. |
| PB-03 | Execute the chosen single loop location, direct process/Worker boundaries and bounded controls. | Records which observation owner remains responsive, which owned execution agent can be terminated, and where only runtime exit rather than independent physical absence is available. |

These changes refine existing scenarios; they should not materially increase
source size or the stated child count. Estimated additional handwritten fixture
cost is approximately 20–60 LOC within the existing plan, with x2 uncertainty;
production/shared-runtime/integration LOC remain zero. No industry daemon,
third-party plugin or download is needed. Stop when the approved uncertainty is
resolved or a real inaccessible boundary makes its row unavailable.

## Review source references

- `plans/plugin-boundaries.md` (review target, 2026-10-26).
- Frozen `historical/20261025/experiments/static-restart/tests/static-selection.test.ts`,
  S02/S03 and eager provider imports.
- Frozen `historical/20261025/experiments/static-restart/tests/selection.ts`,
  eager A/B provider imports.
- Current GM `docs/architecture/common-assembly.md`, Consumer Module Standard /
  optional dynamic Host lifecycle candidate: target owner supplies inert
  declarations/literal imports; observers do not release held ownership.
- Frozen `historical/20261025/reports/static-restart-e2e.md` and
  `critic-restart-evidence.md`: procfs descendant inventory unavailable; process
  observations are finite and do not establish full custody-owner recovery.
- Official Node child-process API, current rendered v26.12.1, checked by this
  track on 2026-10-26: <https://nodejs.org/api/child_process.html>. Signal-send,
  IPC disconnect, exit and stdio-close observations are distinct. The executed
  runtime must retain its own exact identity.

This critique does not claim the proposed PB tests have run, that any current
product violates these properties, or that documentation qualifies a production
security/custody boundary.
