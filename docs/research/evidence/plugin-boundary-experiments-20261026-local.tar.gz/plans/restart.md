# Restart boundary experiments — proposed, awaiting execution approval

Date: 2026-10-26. Owner: restart track. Status: plan/research only. No experiment
has been implemented or executed in this campaign. Shared repositories and the
20261025 archive are read-only. The owner-confirmed static-composition plus
controlled-restart baseline remains fixed; downtime is permitted.

## Decision and scope

The useful next decision is the minimum evidence and receiver integration needed
before promoting a controlled-restart slice, not selection of a new Host,
supervisor, lifecycle kernel, RPC framework or workflow engine. Three experiments
cover a currently failing boundary and two untested joins of existing mechanisms.
They reuse the real worker/effect processes, actual file snapshots, GM public
composition and native file-resource fixtures retained on 20261025. They do not
claim an Orchestrator/Agent Runtime/PostgreSQL production integration.

Each result can change one concrete disposition:

1. Whether a small receiver-local serialized admission seal suffices for this
   fixture, and exactly which pre-seal accepted work must survive stop.
2. Whether candidate readiness failure can reuse the retained attempt/resource
   cleanup owner, including a failed first cleanup, without extra lifecycle code.
3. Whether the existing custodian's result/exit separation remains sufficient
   when a real effect commits before cancellation or reports a result while
   staying alive, and what uncertainty must remain visible to a stop observer.

No experiment adopts a production API. A green copied fixture establishes only
its stated seam. Actual product receiver/custody/persistence joins remain gates.

## Authority and inspected evidence

Read before this plan: full campaign `context.md`; current EF/GM `AGENTS.md`;
retained current organization Engineering Quality Standard; EF docs-authoring
route; EF ADR-0011 applicability, admission and effect-proof sections; current
OD-003; research reference and static/restart validation; historical README,
static-restart and independent critic reports; actual recovery owner, store,
worker, Supervisor, effect and recovery tests; actual semantic attempt-owner,
lifetime controls, held startup controller and lifetime tests.

The plan is an external campaign file, not a governed EF document. Root owns any
later governed document creation/checks. No repository docs command, release
gate, product adoption or independent conformance pass is claimed here.

Current source authority is the shared brief's exact EF head `84f43b9`, current
GM main `b1866ac` and Orchestrator main `94a480d`. The optional lifecycle-kernel
README still states candidate status and no release/product-adoption claim. This
track does not require that package. The frozen recovery fixture came from GM
`b70ba393`; executed package identities were Core/Assembly 0.7.0, Resources 0.2.1
and Conformance 0.5.0. Reusing those bytes is historical fixture qualification,
not silent migration to current GM source or a product package pin.

Known evidence is deliberately not rerun as a broad suite merely for volume:

- S07 is red in both profiles and independently reproduced for `record-only`.
  After stop/revocation/actual effect exit, held launch ACK keeps the worker
  connected; a new distinct operation gets `created:true` and a durable pending
  record. This is missing ingress sealing, not proven data loss or GM failure.
- The historical S07 follow-through assumes the bad record exists. It is not a
  future rejection regression oracle. Preserve its source and red expectation.
- Existing recovery tests already cover missing worker/effect executables,
  pre-handshake child exit, stale/consumed/revoked launch permissions, malformed
  child results, file-cleanup debt, recovery quarantine and synthetic late
  success after cancellation. Existing lifetime tests cover failed partial
  setup, late factory/readiness completion, retained cleanup retry and abandoned
  close observation. Do not recreate these as purported new discoveries.
- Earlier twelve A/B and twenty-four work-free worker cycles are finite process
  observations, not resource bounds or work-bearing drain repetition.

Exact frozen file hashes inspected on 2026-10-26:

| File under historical static-restart | SHA-256 |
| --- | --- |
| `tests/stop-admission-counterexample.test.ts` | `a9d52bcc430927080fc8a51292cf202793a6bb241ed5916cebfaa17498c0f6cc` |
| `upstream/recovery/src/operation-owner.ts` | `1acfdf9f39fa3df13e07e0e466e05f6d1c9ba236dae4690a9c4721e277ff174e` |
| `upstream/recovery/src/supervisor.ts` | `b4e94a911195885805851d9fb462b90f3cf3a8f2651069b9493036b32fe54b05` |
| `upstream/recovery/src/worker.ts` | `14b7cca785a33bcfa320bb3f2fe712576240fef69e767749adcccaa7b0b40a35` |
| `upstream/recovery/src/effect.ts` | `638fe1145c304afc65e4651346fc713802696f3ccaa28bff61bfcb940b092a90` |

## Small primary-source check: facts and inference

Retrieval date for all sources below: 2026-10-26. These checks answer only the
named boundary questions, not a general survey or component-adoption exercise.

| Primary source, identity and status | Source fact | Inference for this plan |
| --- | --- | --- |
| [Node child_process API](https://nodejs.org/api/child_process.html), retrieved page identifies v26.12.1; moving documentation. The exact v26.11.1 archive URL could not be retrieved through search and is explicitly not claimed checked. | Sending a kill signal and `killed` do not establish termination. `exit` follows process end; `close` additionally follows stdio closure. IPC disconnect is a separate transport observation. Failed spawn can emit error without exit. | Keep independent native exit/close/absence observations. A deadline or lost IPC must not release the occupied slot. Execute with the actual qualified toolchain and record it; this page is not evidence that our runtime is v26.12.1. |
| [NGINX control](https://nginx.org/en/docs/control.html), unversioned current documentation. | A failed reconfiguration can retain old configuration; successful reconfiguration starts new workers and asks old workers to close listening sockets while servicing old clients. | Separate candidate failure, new admission and accepted-work disposition. NGINX's overlap/old-active availability promise does not transfer to the owner's downtime-permitted restart baseline. Do not test or build an NGINX analogue. |
| [Envoy draining v1.37.7](https://www.envoyproxy.io/docs/envoy/v1.37.7/intro/arch_overview/operations/draining), versioned documentation. | Draining behavior depends on listener/filter support. Immediate listener stop and graceful drain differ; graceful draining can continue accepting until the drain timeout. | A method named drain/stop does not define the product admission contract. Name the seal linearization and independently observe it. This is a semantics lesson, not evidence that Envoy is defective or that we should adopt it. |

Source facts are documentation, not locally executed industry tests. The proposed
queue shape and scoring below are engineering inference. We do not need to
install NGINX/Envoy, another native runtime or a process supervisor to answer the
three fixture questions.

## RST-01 — serialized acceptance seal and accepted-work disposition

**Uncertain question and changed decision.** Does placing a permanent live
admission seal in the existing owner transition queue close the S07 hole without
breaking duplicate/conflict readback or losing an acceptance already preceding
the seal? If yes, recommend this narrow receiver requirement for the first
product slice. If no, retain the counterexample and name the specific additional
seam needed; do not grow a runtime.

**Real boundary.** Forked worker, same live test custodian, actual effect child,
real canonical file replace and fresh-worker readback, both existing recovery
profiles. The custodian stays live. Exact public GM package bytes remain frozen.

**Test-owned change.** Copy only needed historical fixture source to this
track. Keep one unmodified baseline copy for the original S07 witness. In a
separate corrected copy, add one owner admission boolean and an idempotent seal
operation to the existing serialized transition queue. Existing identity/conflict
lookup precedes the seal rejection. The stop command enqueues the seal before
its first await, synchronously closes dispatch scheduling, releases test holds,
then awaits the seal before enumerating accepted records for revocation/drain.
This is a disposable policy correction, not an approved general contract.

**Linearization being tested.** Durable acceptance completes before the queued
seal step; the seal step makes admission permanently closed for that worker.
Older submissions already ahead in the sole queue can complete before sealing,
even if stop has been requested. Submissions behind the seal cannot acquire a
new reservation or canonical record. This deliberately does not promise that
wall-clock stop-request arrival retroactively rejects earlier in-flight commands.
Record stop-requested, acceptance-committed and seal-completed observations so
the distinction cannot be hidden by a final boolean.

**Smallest scenarios.**

1. Run the unmodified original S07 witness in isolation, both profiles. Preserve
   expected red exit and its accepted-candidate follow-through unchanged. Never
   include that expected failure in a green aggregate.
2. Corrected seam: reproduce held real launch ACK -> stop -> named seal and
   revocation -> real effect exit -> distinct new submission. Require the
   specific sealed rejection while stop is still pending. Release ACK, join stop,
   start a fresh worker and prove the rejected identity remains absent. Do not
   wait for a claim/event for an operation that must not exist.
3. In that stopped-but-connected window, duplicate the original accepted
   operation and submit its conflicting fingerprint. Require readback/no new
   launch for the duplicate and conflict rejection for the changed input.
4. Hold a submit at the real synced/closed temporary-file-before-rename barrier,
   enqueue stop/seal, then release the hold. Prove its acceptance precedes seal,
   no dispatch starts after closing, and the pending record is present after
   joined stop. On fresh worker, `record-only` retains it pending with zero
   launches; `restart-pending` resumes once to the existing exact success/file
   oracle. Duplicate readback creates no second child/effect. This qualifies one
   accepted-work disposition per profile without a churn matrix.

**Independent observable oracle.** Parse actual canonical bytes from an
independent file read before/after rejection and from a fresh worker; assert the
candidate identity is absent and bytes do not change for its rejection. Add one
audit event at the existing custodian reserve RPC boundary containing operation
identity: the rejected candidate has zero reserve attempts, zero launches and no
reservation. Count actual child acquisition/exit and exact effect-file lines for
the accepted-before-seal scenario. Do not derive expectations from the owner
implementation or only inspect its `closing` flag.

**Meaningful negative control/falsifier.** The same absence oracle run against
the uncorrected copy must fail because the candidate is present and reserved.
The original red witness additionally proves the defect's recovery disposition.
Any wrong rejection code, candidate durable presence/reserve attempt, duplicate
launch, reopened admission after reconciliation, or disappearance of the earlier
accepted record falsifies the corrected seam. If failure appears, retain it;
one bounded correction/review iteration is enough before returning to root.

**Bounds/cleanup/stop rule.** At most two worker incarnations and one effect per
scenario, record cap unchanged at 32, original 20-second scenario cap and
5-second cleanup watchdog, plus an enclosing 120-second process bound per
profile group. No ports/database/download. Always release owned ACK/barriers,
join owned child exits, dispose only the scenario root. Watchdog use is failure
cleanup and must be reported, never successful drain. Stop when original red,
new rejection/absence and one earlier-acceptance disposition per profile are
resolved; no optional repetition.

## RST-02 — readiness rejection joined with failed candidate cleanup

**Uncertain question and changed decision.** Can the existing retained attempt
close a successfully constructed but never-ready candidate after the first
cleanup fails, with no publication or effect, by reusing its current resource
owner? A pass supports reuse rather than a new candidate state machine. A fail
identifies a gap in the test owner, not a GM graph defect or product incident.

**Real versus synthetic.** Use exact existing semantic public-GM composition,
`createAttempt`, `lifetimeControls`, actual native file resource and actual file
journal. Readiness rejection and the one cleanup failure are named test-owned
injections. This is trusted in-process candidate construction; it does not claim
worker startup, exclusive socket handover or product Host activation.

**Scenarios/oracle.** After real construction reports succeeded and the real
resource probe works, reject the held readiness promise with a named error.
Observe `ready` rejecting, zero publications, closed ingress and zero effect or
module-run entries. Call the existing attempt stop; configure the inherited
`cleanupFailures:1` and require an incomplete settled debt report, a still-open
native resource and still-live journal. Discard the first returned report while
retaining the attempt. Retry stop on that same owner; hold actual release with
the inherited barrier and prove both FDs still operate, then release and require
complete report, exactly two cleanup attempts/one real release, EBADF on both
closed handles, no publication/effect. A fresh independent candidate must still
construct, become ready and close, showing failure has not poisoned shared state.

**Negative control/falsifier.** Reuse the inherited early-journal-close
counterexample only as a targeted control: closing that actual prerequisite
before retry must produce EBADF debt, not a false complete report. Restore only
the test-owned journal prerequisite in finally and release the real resource.
If control evidence remains byte-identical and already adequate, retain/source-
audit it instead of re-executing; state this distinction. Any publication,
effect, closed journal needed for retry, forgotten open handle, or false complete
report falsifies the intended reuse claim.

**Bounds/cleanup/retention/stop rule.** One failed candidate and one fresh
positive control, no child/port/DB, original 10-second test cap and 60-second
outer process cap. Finally releases only owned holds and retries actual cleanup;
unresolved cleanup is retained as debt/failure. Retain actual diagnostics,
resource/journal probe receipts and exact journal lines. Stop after this join;
do not rerun the already-qualified lifetime matrix.

## RST-03 — real late result and result-without-exit custody

**Uncertain question and changed decision.** Does the existing custodian keep
semantic outcome, physical effect and physical absence separate in two credible
late-completion traces? A pass supports preserving its narrow effect-specific
observations in the real adapter. A fail blocks that fixture's promotion; it does
not justify replacing the physical custody owner.

**Real versus synthetic.** Reuse the exact worker, file owner and actual forked
effect. Add only named child fault modes and narrow test methods on the existing
custodian. The modes are synthetic scheduling/behavior; the file sync, IPC,
native process survival and eventual exit are real. No killed-parent recovery,
descendant containment or hostile plugin isolation is claimed.

**Scenario A: committed effect, delayed success message.** Child performs its
existing real append/sync, emits a named held-result observation, then holds
before sending success. Cancel the accepted operation and require canonical
CANCELLED while the child is still retained. Release the held real success;
observe its actual message and actual exit. Require canonical cancellation to
remain unchanged, exactly one effect-file line, no second launch on duplicate
or fresh-worker reconciliation. The existing R07 synthetic `lateSuccess` path
is not substituted for the real message. Interpretation must state that a
semantic cancellation did not reverse the already committed file effect.

**Scenario B: result/disconnect without physical exit.** A child sends its real
terminal result and disconnects IPC while a bounded test-owned live handle keeps
it alive. Wait for named result/disconnect observations and independently prove
the known child remains alive. Request worker stop; observing an explicit short
deadline must leave stop pending/uncertain rather than return released. A new
start remains refused by the existing single-writer rule; the effect reservation
remains occupied and no extra launch occurs. Then terminate only this exact
owned live effect through the same custodian and join actual exit/close. Only
that observation may settle the worker and permit a fresh start. The short
deadline demonstrates observer abandonment, never establishes ordering or
physical absence. This does not simulate loss of the custodian itself.

**Oracle and controls.** Use actual synced file content, actual child messages,
native exit/close events, known-PID survival/absence observations with identity
limitations stated, canonical fresh-worker readback and launch/reservation counts.
Native FD/resource cleanup and process exit are separate assertions. An ordinary
unheld child is the positive exit control. The tempting premature predicate
`result received || IPC disconnected || stop requested` must evaluate true while
the child is independently live: that is the negative control demonstrating why
it cannot qualify release. Do not turn it into the implementation under test.

**Falsifier.** Canonical result overwritten by late success, duplicate physical
effect, release/start allowed before real absence, or a false successful stop at
the observation deadline. If the process fixture cannot support meaningful
independent survival/exit observations in this environment, report unavailable
and stop; do not replace it with an in-memory model.

**Bounds/cleanup/retention/stop rule.** One worker/effect plus one fresh worker
per scenario; capacity one and record cap unchanged. 20-second scenario limit,
5-second cleanup watchdog, 60-second outer process cap per scenario. A 100–500ms
observation deadline may demonstrate pending observation only after named
barriers; no sleep creates a causal assertion. Retain known owned process handles
before any fault. Finally release result holds and kill/join only exact owned
still-live handles if necessary; watchdog cleanup fails qualification. No process
name pattern kills, detached unknown descendants or shared filesystem cleanup.
Stop after these two traces, without a churn or OS matrix.

## Cost, alternatives and prerequisites

Engineering judgments out of 10, not measured availability. Reliability refers
to achievable behavior within each stated scope after its actual product gates.
Higher complexity means more burden. LOC are disjoint handwritten estimates with
approximately x2 uncertainty; existing fixtures, GM/AR code, packaging/signing,
production schema work and deployment operations are excluded.

| Option and promised scope | Confidence | Reliability | Complexity | New production/shared runtime LOC | New product integration LOC | New tests/fixture LOC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Run these disposable fixture experiments only | 9 | 8 | 3 | 0 | 0 | 350–650; includes minimal copied-fixture changes, not unchanged source |
| First direct product controlled-restart slice reusing actual receiver, persistence and custody, downtime permitted | 8 | 9 | 4 | 0 | 150–500, provisional until actual seam inspected | 600–1,400 |
| Add a generic restart Host/second supervisor now | 3 | 6 | 8 | 800–2,000 | 200–600 per consumer | 1,500–3,500 |

The third option is rejected as speculative and outside authorization. No native
rewrite is selected: the named uncertainty is product acceptance policy and
honest evidence, for which a language change supplies no demonstrated benefit.
Optional Temporal is a separate scheduling track and cannot repair receiver
admission or physical-exit proof. Actual new production/integration source for
this campaign remains zero.

Prerequisites: root approval after independent plan criticism; root-managed
Node26/TS7.0.2+ toolchain, exact frozen package bytes/cache and Node types. Prefer
read-only shared dependencies or one root-approved bounded install. No download
is planned or authorized by this plan. Use short owned `/tmp` roots. Estimate
under 10MB handwritten/emitted/log evidence excluding shared toolchain; no DB,
browser, persistent service or port. If dependencies are missing or disk budget
cannot accommodate the small copy/build, ask root and retain an unavailable row.

## Retained delivery and execution gates

After approval, only `experiments/restart/` and `reports/restart.md` are writable
by this track, alongside this plan. Preserve original S07 source and raw red
logs; separate corrected source/patch, new absence-oracle source and results.
Retain reproduction commands, exact runtime/compiler/package identities and
hashes, source-copy inventory and per-file diff, strict compiler flags
(`strict:true`, `skipLibCheck:false`), raw TAP/stderr for every attempt, structured
scenario facts and ordered event receipts, canonical snapshots, exact file
artifacts, exit/cleanup receipts and final SHA-256 manifest. Retain failed
attempts and critic dispositions. Generated JS is reproducible and may be
excluded from the final archive when hashes and strict build inputs are kept.

Enclose every scenario group in a wall-clock process bound that retains owned
handle cleanup; never silently use timeout/kill as a successful stop oracle.
Report historical test assertions, local executions, source inference and
unavailable observations separately. No broad existing suite is needed unless a
copy modification changes an inherited contract and leaves a concrete risk.
Root alone integrates governed docs, commits or pushes the meaningful evidence.

**Pre-execution criticism requested:** challenge the serialized acceptance/seal
ordering; the independent no-reserve/absent-record oracle; whether RST-02 adds
meaningful coverage beyond L06/L07; whether RST-03 tests honest uncertainty rather
than a synthetic state machine; and the ability to clean every real owned handle
within the stated caps. No implementation begins until root sends execution go.

## Execution-go peer dispositions, 2026-10-26

Root authorized execution after both reviews: `critique-restart-and-state-by-boundaries.md`
and `critique-restart-and-boundaries-by-state.md`. All restart refinements are
accepted. The actual queued seal completion emits the incarnation-qualified ACK;
reserve/permission/launch attempts are monotonic, operation/grant-qualified audit
events. Direct canonical absence and fresh-worker readback are independent.
The held-ACK scenario explicitly reconciles after seal, then rejects another new
identity without acquisition. Earlier acceptance is canonical file replacement
in this process-restart profile, not a parent-directory-fsync/power-loss claim;
no new dispatch means no new unauthorized physical launch/handoff.

RST-02 is only the readiness-rejection/cleanup-debt join. Attach its rejection
observer before rejecting; preserve the attempt owner unchanged. No early-journal
counterexample replay or unrelated fresh candidate is needed. Zero effects means
zero business/module-run entries; actual initialization acquisition is present.

RST-03 preserves `finished`/`wait-result` after physical exit and artifact handling.
Add raw result/disconnect and native close observations, independently read synced
artifact bytes before cleanup, and label the intentional exact-handle SIGKILL in
scenario B as planned force retirement. Emergency watchdog use fails qualification.
The outer bounded runner retains explicit child PID/start-time identities via a
test-only append-only registry written before fault barriers release; if the
inner owner stalls, the surviving runner terminates only matching owned live
incarnations, reports unresolved debt, and never counts that rescue as a pass.
All source changes are confined to disposable copies and recorded as such.
