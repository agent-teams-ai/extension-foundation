# Cross-critique of restart and state-recovery plans

Reviewer: plugin loading/execution-boundaries track. Date: 2026-10-26 UTC.
Status: read-only source/plan review; **no implementation or experiment executed**.

## Recommendation

Proceed with **RST-01** after making its admission/observation assertions explicit.
Retain **RST-02** only as one small readiness-rejection × cleanup-debt join; most
of its cleanup mechanics are already qualified by L-07. **RST-03** is useful if
it observes the actual child/custodian boundary without changing the existing
meaning of `finished` or `wait-result`. **SR1** addresses a real unavailable
capability, conditional on disk and matching client binaries. **SR2** should
prioritize real SQL contention and transaction rollback; keep compatibility
examples small and explicitly test-owned.

Both plans preserve the accepted static-composition/controlled-restart baseline,
product authority and existing physical custody. They do not need a Host,
supervisor, SPI, schema framework or new package. The mandatory changes below
are clarifications or small rejecting probes at existing boundaries, not a
request to enlarge the architecture or failure matrix.

## Reviewed identities and evidence

Plan bytes reviewed:

| Input | SHA-256 |
| --- | --- |
| `plans/restart.md` | `92237fe471fe88e48b919409be920fed68928146ce7f3f6f15a3f8ad6c420b5c` |
| `plans/state-recovery.md` | `691d6f2d6a9e8fd239fb76bc84c09b4b9f39f9072695eed33641a138de742932` |

Read the frozen recovery `operation-owner.ts`, `worker.ts`, `supervisor.ts`,
`effect.ts`, `store.ts`, original S07 counterexample, semantic `attempt-owner.ts`
and `tests/module/lifetime.test.ts`, plus the preserved Agent Context migration,
PostgreSQL store, native fixture and feature test. Relevant frozen hashes:

- Lifetime tests:
  `392387c04c03d6b41059ea471ea678d24d896cf7f75291a50a8704e76db0131d`.
- Agent Context migration:
  `31b99b8bac8176c6a5728dee958c0c3a07f7c421b0168c3215d37ccb0a3b718a`.

Also read the campaign brief, EF/GM agent routes, retained organization standard
and plugin track authority/research inputs during the parent assignment. Shared
source and historical evidence remain unmodified.

Primary SQL documentation checked online on 2026-10-26:

- [PostgreSQL18 row security](https://www.postgresql.org/docs/18/ddl-rowsecurity.html):
  superusers/BYPASSRLS bypass RLS; owners normally bypass unless forced; visibility
  and modification checks differ.
- [PostgreSQL18 pg_restore](https://www.postgresql.org/docs/18/app-pgrestore.html):
  ordinary restore retains ownership commands, and transactional restore is
  distinct from merely continuing after errors.
- [PostgreSQL18 SQLSTATE appendix](https://www.postgresql.org/docs/18/errcodes-appendix.html):
  record server error codes rather than relying only on localized text. This
  moving major-version documentation currently identifies its error table as18.6;
  executed binary/version must remain the actual recorded18.4 pairing.

## Mandatory dispositions before execution

### RST-01: seal ordering and the no-acquisition oracle

**The linearization model is appropriate.** `OperationOwner.submit()` serializes
the identity lookup, reserve RPC and snapshot replacement. Putting the permanent
seal in that same queue permits a submission already ahead of it to finish.
Closing dispatch synchronously before awaiting the seal prevents that accepted
pending record from starting new dispatch during stop. A post-seal distinct
identity must reject before `controls.reserve`, record creation, permission or
launch. A stop-request timestamp alone does not establish that ordering.

Required details:

1. **Emit seal-completed only from completion of the actual queued transition.**
   Send the rejecting submission only after the observer receives that exact
   worker-incarnation/seal acknowledgment. Retain the earlier submit's
   acceptance-replacement completion and seal order. A flag read at request
   receipt, or an event emitted when the seal is merely enqueued, is insufficient.
2. **Make the acquisition audit candidate-specific and monotonic.** At the
   custodian's actual RPC receiver, record identity and worker grant for reserve
   attempts, permission issuance and launches. Require zero candidate reserve
   attempts and zero candidate permission/launch events, plus no live reservation
   attributable to it. A global final `reserved:false` can hide acquisition then
   revocation. The original source does reserve in `submit` before canonical
   replacement; the baseline's candidate presence/reservation is a valid control.
3. **Keep canonical absence and acquisition absence independent.** Parent reads
   canonical file bytes directly before/after rejected submission, then checks
   absence again through a fresh worker. Use identity-qualified comparisons;
   exact whole-file equality is valid only while unrelated legitimate transitions
   are held. No wait for a rejected operation's claim/result may be introduced.
4. **Check the permanent seal survives reconciliation.** Existing reconciliation
   explicitly clears `frozen`; the new seal must be a distinct admission fact.
   While the held-ACK window still permits commands, reconcile and retry a new
   identity, requiring the same rejection and no acquisition. This is a small
   credible reopen path, already named among the plan's falsifiers.
5. **Check the earlier accepted record's reservation is released honestly.**
   It may reserve before seal, persist after stop was requested, and remain
   pending. After joined stop its reservation must be released/revoked under the
   existing custodian. Fresh `record-only` does not manufacture a new reservation;
   `restart-pending` makes one new live admission and one actual effect. Do not
   count the historical pre-seal reserve as a forbidden post-seal acquisition.

Duplicate readback and fingerprint conflict before seal rejection are correct.
They must produce no new reserve/permission/child. The new seal should not become
a blanket rejection that prevents reading an already accepted result.

**Claims correction:** the file store syncs/closes its temporary file and renames
it, but the inspected source does not fsync the parent directory. These tests can
show process-visible canonical acceptance/readback and the stated process-crash
profile. They cannot establish filesystem/power-loss persistence of the renamed
directory entry. Use that scope when calling acceptance "durable".

### RST-02: retain only the new join

Existing L-06 covers partial setup release. L-07 already proves a first failed
cleanup leaves the real resource and prerequisite journal usable, a discarded
report does not discard owner authority, retry uses the same owner, and actual
release yields EBADF. L-07's early-journal-close counterexample already detects
a prerequisite being destroyed before retry. L-02 covers construction success
followed by stop while readiness is held.

The distinct uncertainty is **readiness rejects after successful construction,
then cleanup fails once, and the same retained attempt retries without ever
publishing**. One row is justified; implementing a second cleanup owner or
repeating all L-07 controls is not.

Required assertions beyond L-07 are: startup is actually `succeeded`; the named
readiness rejection is the observed rejection; `run()` rejects at ingress; no
publication and no actual module entry/effect occurred; the first stop retains
debt; the same attempt's second stop actually releases. Attach rejection
observation before triggering the held promise, so an ambient unhandled rejection
does not contaminate the result. Retain exact original owner bytes or identify
any required changes rather than patching semantics merely to pass the join.

The fresh candidate positive is acceptable if it shares a potentially poisoned
real prerequisite. Otherwise it is optional; per-attempt state isolation is
already apparent in the inspected source. Source-audit the byte-identical
early-journal counterexample rather than rerunning it.

### RST-03: child result is not canonical success or physical exit

This plan has a valuable real boundary: the current custodian receives child
`result` messages but resolves `finished` only **after `exit` and artifact
read/cleanup**. `wait-result` awaits `finished`. Preserve that meaning.

Required details:

1. Add observation events at actual child message/disconnect receipt. Do not
   resolve `finished`, release the reservation or return `wait-result` early to
   make the new test easier. "Terminal child result" must not be reported as
   a canonical terminal operation until the actual owner records it.
2. In scenario A, hold **after actual append/sync and before success send**.
   Parent reads the live artifact before cancellation and confirms exactly one
   literal line. Since the original child's `chosen` state ignores later stop,
   the fault mode needs a narrow separate release command/control after that
   point. The real successful message must be delivered, not synthesized by
   `lateSuccess`. Then require canonical CANCELLED and that same one real effect.
3. In scenario B, observe child result and IPC disconnect while independent
   PID/start-time evidence proves the exact child live. Require reservation
   occupied and an explicit fresh-start rejection while worker stop remains
   pending. Current start refusal can also be caused by the incumbent worker;
   report both facts rather than treating writer refusal alone as proof that
   effect capacity was retained.
4. Once IPC is disconnected, the original `stopEffect` cannot deliver a
   cooperative stop. Specify the narrow test-only custodian operation that
   terminates its retained exact child handle. Distinguish this **planned forced
   trial termination** from the five-second emergency watchdog. The former may
   complete the intended result-without-exit scenario; the latter fails cleanup
   qualification. State expected code/signal and the canonical cancellation
   disposition instead of assuming a natural SUCCESS exit.
5. Observe `exit`, stdio `close`, artifact cleanup outcome and PID absence
   separately. Current source joins exit and artifact handling but does not
   expose a separate successful-child `close` promise. If close is claimed, add
   only its observer before releasing the fault. Process absence does not prove
   no descendant exists; that remains explicitly excluded.

These observations can remain within the existing custodian and exact child
handles. No new supervisor, RPC implementation or generic lifecycle contract is
needed.

### SR1: prove restored privileges at the SQL receiver

SR1 is strongly motivated: actual prior distribution lacked logical restore
helpers. Different cluster IDs, stopped source, unfiltered custom archive,
globals, transactional missing-role failure and actual post-restore writes form
a useful minimal recovery gate. The following probes prevent false positives:

1. **Assert the actual target connection role.** On the runtime connection,
   record `session_user`, `current_user`, `rolsuper`, `rolbypassrls`, and relevant
   role membership/ownership. Require the intended nonsuperuser/NOBYPASSRLS
   runtime role, with no owner/bootstrap substitution. Parent bootstrap queries
   may independently inspect all rows but cannot serve as the RLS oracle.
2. **Exercise visibility and `WITH CHECK` directly.** In a runtime transaction
   set tenant B and query the restored tables without an application tenant
   predicate. Verify own rows present, tenant A rows absent. Attempt an INSERT
   with tenant A under that B setting and an UPDATE of a visible B row to tenant A;
   require actual server RLS rejection/unchanged rows. Use ROLLBACK and independent
   owner readback. Probe `manifests` and its transactional `outbox`, at least one
   direct write rejection per policy-covered table. A foreign-name API rejection
   can occur before SQL and cannot qualify restored RLS.
3. Assert `relrowsecurity`, `relforcerowsecurity`, policy expressions and schema/
   table grants against source values. Keep the positive same-tenant SQL/API read
   and actual new manifest/outbox transaction so absent grants cannot masquerade
   as effective tenant isolation. Runtime DDL denial is an additional privilege
   check, not a replacement for RLS tests.
4. The mandatory missing-role restore must run in a clean target DB with owner
   restoration enabled. Retain actual nonzero output; independently query absent
   feature schema/tables/data afterward. Apply globals and retry the same archive
   without running `feature.migrate()` or issuing GRANT/policy repairs on target.
   Otherwise a missing restored object can be silently reconstructed by setup.
5. Reorder the optional PG17 helper check **before source shutdown**. As written,
   SR1 step2 stops source while step3 requires it running. This check may simply
   be omitted if its old helper dependencies are unavailable; missing-role
   failure remains mandatory.

The feature's `app.tenant_id` is a trusted adapter-set transaction context. These
probes establish restoration/enforcement of that scoped RLS policy, not security
against arbitrary SQL code that can choose another tenant setting. No broader
identity/sandbox claim should appear.

Logical restore from an archive into a distinct cluster proves reconstruction
at the declared snapshot. It does not simulate torn filesystem writes, corrupt
WAL, sudden power loss, disk loss during dump, or a coherent multi-store product
recovery point. Existing explicit exclusions are correct and should remain in
the result headings, not only a final caveat.

### SR2: make migration outcomes observable and avoid a no-op contention test

Real PostgreSQL catalog/lock/data observations give SR2 value beyond a toy
conversion function. Required refinements:

1. **Make V1 overwrite an existing row after V2 wrote it.** Merely adding a new
   V1 row tests NULL backfill; it does not expose a stale, previously populated
   `retry_delay_us`. Use fixed differing literals, independently observe stale
   derived state, then restart/reconcile V2 and require exact corrected values.
   Do not modify the V1 adapter to update a column it never knew.
2. Explicitly reset the tiny owned schema to V1 before the parallel-expand group,
   or use a distinct unapplied migration identity. Likewise identify an unapplied
   ALTER for the lock-timeout group. Otherwise a successful prior expand can make
   both later runners no-op without exercising DDL, locks or rollback.
3. Record both backend PIDs, actual granted/waiting advisory locks, matching lock
   key and blocking relation. B must reread the committed version *after* acquiring
   the lock and return a truthful already-applied outcome. Verify one actual
   schema transformation and journal transition with an independent connection.
4. For timeout, show real table-lock blocking on the intended ALTER and record
   actual SQLSTATE. Roll back explicitly after SQL error. Include a version-journal
   write before the blocked DDL, within that same transaction, then prove it also
   rolled back. Without an earlier mutation, an unchanged journal is a weak
   all-or-nothing oracle. After releasing the blocker, retry the same intended
   migration once and inspect committed catalog/data/journal.
5. During precision rejection and after contract, inspect rows/journal directly.
   A V1 read's missing-column SQL error alone proves no attempted write. Execute
   the V1 write as a separate statement/transaction too, observe its actual
   failure, and prove unchanged data. There is no SR2 outbox in the described
   fixture; do not create one merely to assert it unchanged. Check actual owned
   tables instead.

Keep the result explicitly directional: expand plus declared restricted writes
permits the tested rollback window; dropping V1 representation and accepting1250us
ends it. The arithmetic fact that1250us cannot be represented as whole
milliseconds is already known. Do not claim that discovering this fact qualifies
a product migration contract. The actual SQL concurrency/rollback observations
are the uncertain part worth executing.

## Optional scope and stopping decisions

| Item | Disposition |
| --- | --- |
| Original S07 full follow-through on both profiles | Existing retained evidence already proves the defect. One baseline run with the **new absence/acquisition oracle** is enough as its sensitivity control unless copy/profile changes create a concrete difference. |
| Additional RST-02 early-journal failure or broad lifetime rerun | Retain/source-audit L-07; do not rerun by default. |
| RST-03 process trees, custodian death or repeated churn | Deferred; materially different custody questions and disk/time cost. |
| SR1 PG17 mismatch helper | Optional existing-binary control, ordered before source stop; no install. |
| SR1 backup during live concurrent app writes | Deferred; quiescent source is adequate for this initial logical restore capability. |
| SR2 migrator process kill | Deferred; real lock timeout and rollback already target the selected uncertainty. Add only if a remaining concrete effect cannot be resolved. |
| Full snapshot downgrade after contract | Deferred; SR1 tests logical reconstruction and SR2 identifies the compatibility boundary. It would not recover post-snapshot writes or reverse effects. |
| Native rewrite, schema manager, universal Host | Out of scope and unnecessary for these questions. |

## Resource and execution gate

Root reports approximately30MiB unprivileged free and read-only `/dev/shm`.
SR1's declared1GiB free-space guard/350MiB reservation cannot currently be met.
It must remain unexecuted until root allocates sufficient writable task space;
do not quietly lower the guard, use another agent's data root, or substitute
logical success without a distinct native target. RST and small source work may
proceed independently once root supplies the shared toolchain/go.

Apply caps to real child/native work and cleanup; a Promise.race does not cancel
SQL, a native command or an owned child. All cleanup targets exact owned handles,
PIDs/incarnations and paths. Retain raw failed controls as separate rows, with
no blended pass percentage or expected-failure suppression hiding a real gap.

Reviewer recommendation after these dispositions: **RST-01 yes; RST-02 one
small join; RST-03 yes with receiver/exit observations preserved; SR1 yes when
resource prerequisites hold; SR2 SQL contention/rollback first, minimal
compatibility example only.** None is production admission.
