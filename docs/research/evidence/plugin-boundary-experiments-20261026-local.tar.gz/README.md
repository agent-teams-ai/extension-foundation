# Plugin boundary and restart local execution checkpoint

Date: 2026-10-26. Research only; zero production and product-integration lines.
Read `context.md` for the complete owner brief and accepted baseline. This
archive extends the unchanged 416-file 20261025 evidence; that historical archive
is separately preserved in EF PR55 and is not silently rebuilt here.

## Start here

- `reports/restart.md`: seven positive cases, three deliberately red witnesses,
  actual native custody observations, readiness/cleanup join and limits.
- `reports/plugin-boundaries.md`: six selection rows, four artifact groups and
  five execution-placement trials, with one reused import-failure control.
- `reports/critic-restart-by-boundaries.md` and
  `reports/critic-boundaries-by-restart.md`: independent source/result reviews.
- `experiments/plugin-boundaries-async-refinement/REPORT.md`: one separately
  reviewed actual awaited-initializer correction. Original PB source, report and
  manifests remain frozen; the old asynchronous row was insufficient for this
  stronger claim.
- Track plans and pre-execution cross-critiques are under `plans/`.
- `validation/` preserves exact shared inputs and local/hosted gate observations.

These counts have different scopes and cannot be summed into a reliability
percentage. The red assertions remain raw failed tests. No broad prior suite
was repeated just to raise counts. Native PostgreSQL restore and the blocked
Drizzle migration experiment have separate input/result checkpoints.

## Verify and restore the exact lightweight dependencies

From this extracted archive root, `sha256sum -c SHA256SUMS` verifies every payload.
Nested track manifests bind their original scopes too. All members are regular
files with relative paths; no installed dependencies, symlinks or native binary
payloads are embedded. Original runtime was Node26.11.1 and pnpm11.18.0; actual
binary/package hashes are retained under `validation/` and track results.

The historical dependency manifest and lock are retained at
`experiments/restart/inputs/frozen-dependencies-package.json` and
`experiments/restart/inputs/frozen-pnpm-lock.yaml`. On a suitable Linux environment,
copy them as `package.json`/`pnpm-lock.yaml` into a fresh task-owned dependency
directory and run the exact pnpm version with `install --frozen-lockfile
--ignore-scripts`. No repinning or skipLibCheck change is part of reproduction.
Create task-owned node_modules symlinks to that installation for each experiment
and both restart fixture copies. Use the retained strict configs and replace
only the recorded absolute toolchain paths with the exact restored equivalents.

The per-track REPRODUCE/REPORT files retain actual commands and expected exit
codes. Use a NEW result destination or preserve existing evidence before running
because some fixtures write their named results. The first two restart commands
must fail their rejection/absence assertions; three corrected groups must pass.
Read structured custody/effect/native evidence in addition to process exit.

Restart and async generated output is reproducible and excluded. Original PB's
small emitted output is retained because its frozen manifest includes
those bytes; PB's deliberate mutable output is restored to baseline afterward.
The partial ENOSPC emission is identified by its retained receipt/hash and empty
logs, not relabeled as a TypeScript source error or successful observation.

## Validation and environmental limits

Strict TS7.0.2 passes use skipLibCheck:false and noEmitOnError:true. Lightweight
cases used UID0 within their tiny authorized owned fixtures; native unprivileged
PostgreSQL's 1GiB available-space guard is separate and remains unsatisfied
locally. Only root's own completed bootstrap npm cache was reclaimed during the
disk-full observation; peer data, shared dependencies and evidence were untouched.

Local docs catalog/prose checks passed at the planning checkpoint after canonical
authoring recovery. One authoring contract file still fails opaquely locally;
its original logs and reporter-only diagnostic reproduction remain failed.
No transaction journal/lock, dependency or policy was hand-edited to pass.

Hosted checks on exact commit a19cb286b70bf21eeb3ce11789e5fd70caa88b09 passed:
check, node-26-check, architecture-windows, architecture-macos, product-sources,
CodeQL and the actual trusted DocsProtocol route. Their fetched GitHub receipts
are retained under validation/github-a19-*. These observations do not claim that
later documentation/evidence commits already passed. The identity controller
remains failed on the existing author-alias mismatch; no policy was weakened.

The earlier authoring recovery's first success receipt was followed by active
state; that unexplained intermediate observation is retained. A further unchanged
canonical recovery produced a JSON receipt and independently observed journal
absence before prose editing resumed. It is not silently erased from history.

## Interpretation boundary

These fixtures do not qualify production admission, hostile-code isolation,
complete arbitrary import/descendant closure, power-loss durability, generic
hard cancellation, native-addon/OOM behavior, complete Desktop delivery or
thousands of simultaneously active plugins. The full-hash mutation example
specifically leaves real byte custody unresolved. A successful observation cap
is not a cancellation mechanism. Read each critic before reusing a claim.
