# Reproduce the bounded plugin-boundary observations

This is an owned TEST fixture, not a production loader, Host, supervisor,
artifact verifier or sandbox. Read `../../plans/plugin-boundaries.md` and its
peer critiques before executing. Every active fixture is local, benign source;
looping code runs only inside disposable children/Workers.

## Exact shared profile

The campaign uses Node26.11.1, TypeScript7.0.2, released public
`@get-modular/core`0.7.0 and `@types/node`24.19.1, through the root-managed frozen
installation. `node_modules` is an experiment-owned symlink to
`/tmp/ps26-deps-u35mfk4v/node_modules`. Never install into that directory.

The locked dependency installation is described by
`/tmp/ps26-deps-u35mfk4v/package.json` and `pnpm-lock.yaml`; its lock SHA256 is
`8fad72c06cabce75e6ca4f16c641456979c744e2e1de913b12e604f7a21fb535`.
Node binary SHA256 is
`5a7b8a3cf5ccb57d297519754fd73238f64cf560afd0ef19a2f9bf7384cbb657`.
The dependency closure/package integrity evidence is root-owned; one public
entry-file hash alone is not the complete package receipt.

From this experiment directory, with root's serialized compile/run slot:

```bash
export PATH=/tmp/ps26-tools-vr2ly24w/bin:/usr/local/bin:/usr/bin:/bin
GOMAXPROCS=2 GOMEMLIMIT=512MiB node node_modules/typescript/bin/tsc --project tsconfig.json --noEmit --pretty false
GOMAXPROCS=2 GOMEMLIMIT=512MiB node node_modules/typescript/bin/tsc --project tsconfig.json --pretty false
TEST_ATTEMPT=attempt-1 node --max-old-space-size=128 out/run.js
```

Use a new attempt identifier after a failure so prior raw evidence remains.
No dependency install, browser, network listener or database is needed. Strict
typechecking includes every `.ts` fixture with `skipLibCheck:false`.

## Evidence and limits

`results/<attempt>/` keeps each row, the independent pre-mutation receipt and
the final summary, with actual PID/TID identities, nonce pings, expected versus
actual markers, diagnostics, exit/close observations and cleanup. CLI logs and
source/binary identity manifests are retained adjacent to those results. Success
removes only the unique `/tmp/pb26-*` marker root made by this run; failure initially
keeps it for inspection. The first failed run's empty marker directory was
inspected and removed after its inventory, failure inputs and logs were retained.
Cleanup targets exact direct child handles and explicitly
registered nested plugin PID/start-time identities. Full descendant inventory
is unqualified.

PB01 uses inert parsed JSON and public Core before selected literal imports.
The installed table contains B, while only A and the consumer root are selected.
Normally exited rejection with the expected diagnostic plus no marker is the
zero-evaluation oracle. A timeout is inconclusive and fails the row.

PB02 intentionally edits only its own emitted `out/fixtures/mutable` files and
restores the baseline in finally. It does not edit source, dependencies or other
tracks. The verify/load counterexample ACKs both entry and helper hashes before
the parent independently verifies and atomically replaces the entry. Full hash
identity and fresh process execution do not establish immutable byte custody.

PB03 brackets faults with nonce-bearing pings, identifies Worker TID through a
synchronous Worker-local `/proc/thread-self` read and proves that exact task live
before observing absence. Pure-JS loops allocate no data. Their planned forced
termination is distinct from emergency deadline cleanup. The asynchronous
unsettled promise is kept observable by the harness's IPC listener; it does not
demonstrate a plugin-owned native-resource leak. Startup marker files remain
after physical retirement, illustrating the external-effect limit.

This fixture does not qualify hostile-code isolation, OS permissions, OOM/native
crash containment, arbitrary package closure, signature verification, native
addon unload, a production restore or a public SPI.
