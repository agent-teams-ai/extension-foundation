import { writeFileSync } from "node:fs";
import { join } from "node:path";
writeFileSync(join(process.env.TEST_MARKERS!, "root"), "root-evaluated\n", { flag: "wx" });
export function consume(provider: { readonly value: () => string }): string { return provider.value(); }
