import { appendFileSync } from "node:fs";
import { join } from "node:path";
appendFileSync(join(process.env.TEST_MARKERS!, "helper"), "new-helper\n");
export const helper = "new-helper";
