import { appendFileSync } from "node:fs";
import { join } from "node:path";
appendFileSync(join(process.env.TEST_MARKERS!, "helper"), "old-helper\n");
export const helper = "old-helper";
