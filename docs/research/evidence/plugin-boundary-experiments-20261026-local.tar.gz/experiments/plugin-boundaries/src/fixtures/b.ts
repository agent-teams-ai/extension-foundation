import { writeFileSync } from "node:fs";
import { join } from "node:path";
writeFileSync(join(process.env.TEST_MARKERS!, "b"), "b-evaluated\n", { flag: "wx" });
export function value(): string { return "B"; }
