import { appendFileSync } from "node:fs";
import { join } from "node:path";
import { helper } from "./helper.js";
appendFileSync(join(process.env.TEST_MARKERS!, "entry"), "new-entry\n");
export function value(): string { return `new-entry/${helper}`; }
