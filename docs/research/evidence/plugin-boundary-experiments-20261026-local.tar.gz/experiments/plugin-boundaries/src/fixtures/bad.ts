import { writeFileSync } from "node:fs";
import { join } from "node:path";
writeFileSync(join(process.env.TEST_MARKERS!, "bad"), "bad-evaluated-before-throw\n", { flag: "wx" });
throw new Error("fixture.import.partial-failure");
