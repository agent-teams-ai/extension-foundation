import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { mkdir, mkdtemp, readFile, readdir, rename, rm, statfs, writeFile } from "node:fs/promises";
import { tmpdir, platform, release } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { OwnedChild, bounded, procIdentity, type Identity } from "./process-support.js";

const root = fileURLToPath(new URL("../", import.meta.url));
const work = await mkdtemp(join(tmpdir(), "pb26-"));
const attempt = process.env.TEST_ATTEMPT ?? `attempt-${Date.now()}`;
const retained = join(root, "results", attempt);
await mkdir(retained, { recursive: true });
const fsFacts = await statfs(root, { bigint: true });
await writeFile(join(retained, "environment.json"), JSON.stringify({
  node: process.version, execPath: process.execPath, uid: process.getuid?.(), platform: platform(), kernel: release(),
  filesystem: Object.fromEntries(Object.entries(fsFacts).map(([key, value]) => [key, String(value)])),
  memory: await readFile("/proc/meminfo", "utf8"),
  processStatus: await readFile("/proc/self/status", "utf8"),
}, null, 2));
const children: OwnedChild[] = [];
const nested = new Map<number, Identity>();
const observations: object[] = [];
const sha = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex");
const aPath = fileURLToPath(new URL("./fixtures/a.js", import.meta.url));
const mutable = fileURLToPath(new URL("./fixtures/mutable/", import.meta.url));
const aBaseline = await readFile(aPath);
const entryBaseline = await readFile(join(mutable, "entry.js"));
const helperBaseline = await readFile(join(mutable, "helper.js"));
const expectedReceipt = [sha(entryBaseline), sha(helperBaseline)];
await writeFile(join(retained, "expected-baseline.json"), JSON.stringify({
  a: sha(aBaseline), expectedReceipt, expectedLiterals: ["A", "old-entry/old-helper", "old-entry/new-helper", "new-entry/new-helper"],
}, null, 2));

async function markers(name: string): Promise<string> { const path = join(work, name); await mkdir(path); return path; }
async function markerRead(path: string): Promise<Record<string, string>> {
  const found: Record<string, string> = {};
  for (const name of (await readdir(path)).sort()) found[name] = await readFile(join(path, name), "utf8");
  return found;
}
function spawn(script: string, args: readonly string[], markerRoot: string, env: NodeJS.ProcessEnv = {}): OwnedChild {
  const child = new OwnedChild(script, args, { TEST_MARKERS: markerRoot, ...env }); children.push(child); return child;
}
async function record(id: string, data: object): Promise<void> {
  const row = { id, status: "observed", ...data }; observations.push(row);
  await writeFile(join(retained, `${id}.json`), JSON.stringify(row, null, 2));
  process.stdout.write(`${id}: observed\n`);
}
async function mutated(path: string, bytes: Uint8Array): Promise<void> {
  const next = `${path}.owned-next`; await writeFile(next, bytes); await rename(next, path);
}
async function resetMutable(): Promise<void> { await writeFile(join(mutable, "entry.js"), entryBaseline); await writeFile(join(mutable, "helper.js"), helperBaseline); }
async function hashes(): Promise<string[]> { return [sha(await readFile(join(mutable, "entry.js"))), sha(await readFile(join(mutable, "helper.js")))]; }

async function pb1(): Promise<void> {
  const modes = ["selected", "metadata", "incompatible", "byte-mismatch", "loader-mismatch", "unsafe"] as const;
  for (let i = 0; i < modes.length; i++) {
    const mode = modes[i]!;
    const path = await markers(`p1-${i}`);
    try { await bounded((async () => {
      if (mode === "byte-mismatch") await writeFile(aPath, Buffer.concat([aBaseline, Buffer.from("\n// owned post-receipt edit\n")]));
      const child = spawn("./pb1.js", [mode], path, { TEST_EXPECTED_SHA: sha(aBaseline) });
      const message = await child.wait("done");
      const exit = await child.normalExit();
      const actual = await markerRead(path);
      if (mode === "selected") {
        assert.equal(message.value, "A"); assert.deepEqual(actual, { a: "a-evaluated\n", root: "root-evaluated\n" });
      } else if (mode === "unsafe") {
        assert.equal(message.gate, "executable-first"); assert.deepEqual(actual, { bad: "bad-evaluated-before-throw\n" });
      } else {
        assert.deepEqual(actual, {});
        if (mode === "metadata") assert.equal(message.gate, "metadata-only");
        if (mode === "incompatible") { assert.equal(message.gate, "public-core"); assert.match(JSON.stringify(message.diagnostics), /binding.compatibility-mismatch/); }
        if (mode === "byte-mismatch") assert.equal(message.code, "fixture.byte-mismatch");
        if (mode === "loader-mismatch") assert.equal(message.code, "fixture.selected-loader-mismatch");
      }
      await record(`PB01-${i + 1}`, { mode, message, markers: actual, exit, logs: child.logs });
    })(), 8000, `PB01-${i + 1}`); } finally { await writeFile(aPath, aBaseline); }
  }
}

async function pb2(): Promise<void> {
  await resetMutable();
  const changedHelper = Buffer.from(helperBaseline.toString().replaceAll("old-helper", "new-helper"));
  assert.notEqual(sha(changedHelper), expectedReceipt[1]);
  // Parent expectations were frozen before any mutation and are not made by the child verifier.
  await mutated(join(mutable, "helper.js"), changedHelper);
  const helperPath = await markers("p2-helper");
  const helperChild = spawn("./pb2.js", ["fresh"], helperPath);
  const helperMessage = await helperChild.wait("done");
  const helperExit = await helperChild.normalExit();
  assert.equal(helperMessage.value, "old-entry/new-helper");
  const helperHashes = await hashes();
  assert.equal(helperHashes[0], expectedReceipt[0]); assert.notEqual(helperHashes[1], expectedReceipt[1]);
  assert.deepEqual(await markerRead(helperPath), { entry: "old-entry\n", helper: "new-helper\n" });
  await record("PB02-1", { acceptedEntryHash: expectedReceipt[0], fullBefore: expectedReceipt, fullAfter: helperHashes,
    message: helperMessage, markers: await markerRead(helperPath), exit: helperExit });

  await resetMutable();
  const cachePath = await markers("p2-cache");
  const cacheChild = spawn("./pb2.js", ["cache"], cachePath);
  const first = await cacheChild.wait("first"); assert.equal(first.value, "old-entry/old-helper");
  await mutated(join(mutable, "helper.js"), changedHelper);
  cacheChild.send({ type: "helper-edited" });
  const again = await cacheChild.wait("done"); const cacheExit = await cacheChild.normalExit();
  assert.equal(again.value, "old-entry/old-helper");
  assert.deepEqual(await markerRead(cachePath), { entry: "old-entry\nold-entry\n", helper: "old-helper\n" });
  const freshPath = await markers("p2-fresh"); const freshChild = spawn("./pb2.js", ["fresh"], freshPath);
  const fresh = await freshChild.wait("done"); const freshExit = await freshChild.normalExit();
  assert.equal(fresh.value, "old-entry/new-helper");
  await record("PB02-2", { first, again, fresh, cacheMarkers: await markerRead(cachePath), freshMarkers: await markerRead(freshPath),
    cacheExit, freshExit, fullAfter: await hashes() });

  await resetMutable();
  assert.deepEqual(await hashes(), expectedReceipt);
  const racePath = await markers("p2-race");
  const raceChild = spawn("./pb2.js", ["race"], racePath, { TEST_FULL_RECEIPT: JSON.stringify(expectedReceipt) });
  const accepted = await raceChild.wait("verified-full");
  assert.deepEqual(accepted.hashes, expectedReceipt);
  const parentVerified = await hashes(); assert.deepEqual(parentVerified, expectedReceipt);
  await mutated(join(mutable, "entry.js"), Buffer.from(entryBaseline.toString().replaceAll("old-entry", "new-entry")));
  const replacedHashes = await hashes(); assert.notEqual(replacedHashes[0], expectedReceipt[0]); assert.equal(replacedHashes[1], expectedReceipt[1]);
  raceChild.send({ type: "verified-path-replaced" });
  const loaded = await raceChild.wait("done"); const raceExit = await raceChild.normalExit();
  assert.equal(loaded.value, "new-entry/old-helper");
  assert.deepEqual(await markerRead(racePath), { entry: "new-entry\n", helper: "old-helper\n" });
  await record("PB02-3", { accepted, parentVerified, replacedHashes, loaded, markers: await markerRead(racePath), exit: raceExit });

  await resetMutable();
  const coherent: object[] = [];
  for (const tag of ["a", "b"] as const) {
    const path = await markers(`p2-coherent-${tag}`);
    const artifact = fileURLToPath(new URL(`./fixtures/coherent-${tag}/`, import.meta.url));
    const before = [sha(await readFile(join(artifact, "entry.js"))), sha(await readFile(join(artifact, "helper.js")))];
    const child = spawn("./pb2.js", [`coherent-${tag}`], path);
    const message = await child.wait("done"); const exit = await child.normalExit();
    assert.equal(message.value, tag === "a" ? "old-entry/old-helper" : "new-entry/new-helper");
    const after = [sha(await readFile(join(artifact, "entry.js"))), sha(await readFile(join(artifact, "helper.js")))];
    assert.deepEqual(after, before);
    coherent.push({ tag, before, after, message, markers: await markerRead(path), exit });
  }
  await record("PB02-4", { coherent, custody: "Fixture directories intentionally unchanged; hostile writer enforcement untested" });
}

async function ping(child: OwnedChild, ms = 500): Promise<object> {
  const nonce = randomUUID(); const sentAt = performance.now(); child.send({ type: "ping", nonce });
  const pong = await child.wait("pong", value => value.nonce === nonce, ms);
  return { nonce, sentAt, receivedAt: performance.now(), pong };
}
async function pb3(): Promise<void> {
  for (const [placement, mode, id] of [
    ["in-process", "cooperative", "PB03-1"], ["in-process", "async", "PB03-2"],
    ["in-process", "loop", "PB03-3"], ["worker", "loop", "PB03-4"], ["process", "loop", "PB03-5"],
  ] as const) {
    await bounded((async () => {
    const path = await markers(id); const child = spawn("./host.js", [placement, mode], path);
    const prepared = await child.wait("prepared");
    assert.equal(typeof prepared.pid, "number"); assert.equal(typeof prepared.threadSelf, "string");
    const parts = String(prepared.threadSelf).split("/"); const tid = Number(parts.at(-1));
    assert.ok(Number.isSafeInteger(tid));
    const pid = Number(prepared.pid); const live = procIdentity(pid); assert.ok(live);
    const taskLive = procIdentity(pid, tid); assert.ok(taskLive, "Independent actual OS task live-before observation");
    if (placement === "process") nested.set(pid, live);
    const beforePing = await ping(child);
    child.send({ type: "go" });
    await child.wait("started");
    assert.equal((await markerRead(path)).startup, `${mode}-entered\n`);
    let afterPing: object; let retirement: object;
    if (placement === "in-process" && mode === "loop") {
      try { await ping(child); throw new Error("fixture.blocked-host-unexpectedly-responsive"); }
      catch (cause) {
        assert.match(String(cause), /fixture.deadline:message:pong:500/);
        afterPing = { deadlineExpired: true, error: String(cause), stillLive: procIdentity(pid) };
      }
      retirement = await child.terminate("SIGKILL");
    } else {
      afterPing = await ping(child);
      if (mode === "cooperative") { await child.wait("ready"); child.send({ type: "shutdown" }); retirement = await child.normalExit(); }
      else if (mode === "async") {
        try { await child.wait("ready", () => true, 500); throw new Error("fixture.unresolved-readiness-settled"); }
        catch (cause) { assert.match(String(cause), /fixture.deadline:message:ready:500/); }
        const finalPing = await ping(child); child.send({ type: "shutdown" });
        retirement = { observedUnsettledMs: 500, harnessIpcKeepsHostLive: true, finalPing, exit: await child.normalExit() };
      } else {
        child.send({ type: "terminate" });
        if (placement === "worker") {
          const workerExit = await child.wait("worker-exit", () => true, 2000);
          const termination = await child.wait("terminate-fulfilled", () => true, 2000);
          assert.equal(procIdentity(pid, tid), undefined);
          assert.deepEqual(procIdentity(pid), live);
          retirement = { workerExit, termination, taskAbsent: true, hostStillLive: procIdentity(pid), postTerminationPing: await ping(child) };
        } else {
          const signal = await child.wait("signal-sent", () => true, 2000);
          const processExit = await child.wait("plugin-exit", () => true, 2000);
          const processClose = await child.wait("plugin-close", () => true, 2000);
          assert.equal(procIdentity(pid), undefined); nested.delete(pid);
          retirement = { signal, processExit, processClose, absent: true, postTerminationPing: await ping(child) };
        }
        child.send({ type: "shutdown" }); retirement = { ...retirement, hostExit: await child.normalExit() };
      }
    }
    assert.equal(procIdentity(pid, tid), undefined);
    assert.equal((await markerRead(path)).startup, `${mode}-entered\n`, "Actual initialization marker survives physical exit");
    await record(id, { placement, mode, prepared, liveBefore: live, taskLiveBefore: taskLive, beforePing, afterPing,
      retirement, messages: child.messages, markers: await markerRead(path), logs: child.logs });
    })(), 5000, `${id}-trial`);
  }
  await record("PB03-6", { reuse: "PB01-6", observation: "Actual import rejects after synchronous external marker; zero factory/readiness is not zero import effects" });
}

async function cleanup(): Promise<void> {
  // Surviving outer observer knows each explicit plugin PID before go; inner-host loss cannot discard custody.
  for (const [pid, expected] of nested) {
    const current = procIdentity(pid);
    if (current) { assert.deepEqual(current, expected); process.kill(pid, "SIGKILL"); }
  }
  for (const child of children) if (!child.exited) await child.terminate();
  for (const [pid] of nested) {
    const end = performance.now() + 2000;
    while (procIdentity(pid) && performance.now() < end) await new Promise(resolve => setTimeout(resolve, 10));
    assert.equal(procIdentity(pid), undefined, "Emergency nested-child cleanup debt must resolve");
  }
}
let failed: string | undefined;
try {
  await bounded((async () => {
    await bounded(pb1(), 60000, "PB01-group");
    await bounded(pb2(), 90000, "PB02-group");
    await bounded(pb3(), 60000, "PB03-group");
  })(), 180000, "complete-campaign");
} catch (cause) { failed = cause instanceof Error ? cause.stack : String(cause); process.stderr.write(`${failed}\n`); process.exitCode = 1; }
finally {
  try { await cleanup(); } catch (cause) { failed = `${failed ?? ""}\ncleanup:${String(cause)}`; process.exitCode = 1; }
  await writeFile(aPath, aBaseline); await resetMutable();
  const cleanupEvidence = children.map(child => ({ identity: child.identity, exited: child.exited,
    absent: procIdentity(child.identity.pid) === undefined, logs: child.logs }));
  await writeFile(join(retained, "summary.json"), JSON.stringify({
    node: process.version, platform: platform(), kernel: release(), uid: process.getuid?.(), attempt,
    work, status: failed ? "failed" : "observed", failed, rows: observations, cleanupEvidence,
    limits: { directChildrenSequential: true, loopTrials: 3, candidateResourceClaim: false, hostileIsolationClaim: false, descendantInventory: "unqualified" },
  }, null, 2));
  if (!failed) await rm(work, { recursive: true });
}
