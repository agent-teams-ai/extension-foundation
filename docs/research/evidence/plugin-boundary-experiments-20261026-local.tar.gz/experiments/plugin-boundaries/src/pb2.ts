import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

const mode = process.argv[2];
function send(value: object): void { process.send?.(value); }
function waitGo(): Promise<void> { return new Promise(resolve => process.once("message", () => resolve())); }
async function receipt(): Promise<readonly string[]> {
  return Promise.all(["entry.js", "helper.js"].map(async file => createHash("sha256").update(
    await readFile(new URL(`./fixtures/mutable/${file}`, import.meta.url))).digest("hex")));
}
function output(module: unknown): string {
  assert.ok(module !== null && typeof module === "object" && "value" in module && typeof module.value === "function");
  const result: unknown = module.value();
  assert.equal(typeof result, "string");
  return String(result);
}
if (mode === "race") {
  const hashes = await receipt();
  assert.deepEqual(hashes, JSON.parse(process.env.TEST_FULL_RECEIPT!));
  send({ type: "verified-full", hashes });
  await waitGo();
  send({ type: "done", value: output(await import("./fixtures/mutable/entry.js")), hashesAfter: await receipt() });
} else if (mode === "cache") {
  send({ type: "first", value: output(await import("./fixtures/mutable/entry.js")) });
  await waitGo();
  // Intentionally bad root-only cache-busting scheme; not a proposed loader.
  const query = "./fixtures/mutable/entry.js?generation=2";
  send({ type: "done", value: output(await import(query)), query, hashesAfter: await receipt() });
} else if (mode === "coherent-a") {
  send({ type: "done", value: output(await import("./fixtures/coherent-a/entry.js")) });
} else if (mode === "coherent-b") {
  send({ type: "done", value: output(await import("./fixtures/coherent-b/entry.js")) });
} else {
  send({ type: "done", value: output(await import("./fixtures/mutable/entry.js")), hashes: await receipt() });
}
process.disconnect();
