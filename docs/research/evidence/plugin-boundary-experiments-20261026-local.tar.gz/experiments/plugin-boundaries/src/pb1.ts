import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { compileCompositionJson } from "@get-modular/core";

const mode = process.argv[2];
const finish = (value: object): void => { process.send?.(value); process.disconnect(); };
if (mode === "unsafe") {
  let rejection = "";
  try { await import("./fixtures/bad.js"); } catch (cause) { rejection = String(cause); }
  assert.match(rejection, /fixture.import.partial-failure/);
  finish({ type: "done", gate: "executable-first", rejection });
} else {
  // This entire pre-admission runtime import closure contains no candidate imports.
  const raw = await readFile(new URL("../src/data/declarations.json", import.meta.url), "utf8");
  const documents: unknown = JSON.parse(raw);
  assert.ok(Array.isArray(documents));
  const bytes = documents.map(value => Buffer.from(JSON.stringify(value)));
  if (mode === "incompatible") {
    bytes[0] = Buffer.from(bytes[0]!.toString().replace("fixture/session/runner/r1", "fixture/session/runner/r2"));
  }
  const profile = await readFile(new URL("../src/data/profile.json", import.meta.url));
  const result = await compileCompositionJson({ declarations: bytes, profile });
  if (mode === "incompatible") {
    assert.equal(result.ok, false);
    if (result.ok) throw new Error("fixture.expected-public-rejection");
    assert.ok(result.diagnostics.some(value => value.code === "binding.compatibility-mismatch"));
    finish({ type: "done", gate: "public-core", diagnostics: result.diagnostics });
  } else {
    assert.equal(result.ok, true, JSON.stringify(result));
    if (!result.ok) throw new Error("fixture.expected-plan");
    const installed = {
      "fixture/provider/a/default": () => import("./fixtures/a.js"),
      "fixture/provider/b/default": () => import("./fixtures/b.js"),
      "fixture/session/root/default": () => import("./fixtures/root.js"),
    };
    // Installed unselected B is deliberately legal; compare selected executable mapping.
    const selected: Record<string, () => Promise<unknown>> = { "fixture/session/root/default": installed["fixture/session/root/default"] };
    if (mode !== "loader-mismatch") selected["fixture/provider/a/default"] = installed["fixture/provider/a/default"];
    const expectedIds = result.plan.selections.map(value => value.implementationId).sort();
    const loaderIds = Object.keys(selected).sort();
    if (JSON.stringify(expectedIds) !== JSON.stringify(loaderIds)) {
      finish({ type: "done", gate: "selected-loader", code: "fixture.selected-loader-mismatch", expectedIds, loaderIds });
    } else if (mode === "metadata") {
      finish({ type: "done", gate: "metadata-only", digest: result.digest });
    } else {
      const actual = createHash("sha256").update(await readFile(new URL("./fixtures/a.js", import.meta.url))).digest("hex");
      if (actual !== process.env.TEST_EXPECTED_SHA) {
        finish({ type: "done", gate: "bytes", code: "fixture.byte-mismatch", actual });
      } else {
        const entry = await installed["fixture/provider/a/default"]();
        const consumer = await installed["fixture/session/root/default"]();
        finish({ type: "done", gate: "selected", value: consumer.consume(entry), digest: result.digest, expectedIds, loaderIds });
      }
    }
  }
}
