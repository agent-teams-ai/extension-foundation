import { readlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { parentPort, workerData } from "node:worker_threads";

const mode: unknown = parentPort ? workerData : process.argv[2];
const markerRoot = process.env.TEST_MARKERS!;
function send(value: object): void { if (parentPort) parentPort.postMessage(value); else process.send?.(value); }
send({ type: "prepared", pid: process.pid, threadSelf: readlinkSync("/proc/thread-self") });
function message(value: unknown): void {
  if (value === null || typeof value !== "object" || !("type" in value)) return;
  if (value.type === "ping" && "nonce" in value) { send({ type: "pong", nonce: value.nonce }); return; }
  if (value.type === "shutdown") { if (parentPort) parentPort.close(); else process.disconnect(); return; }
  if (value.type !== "go") return;
  writeFileSync(join(markerRoot, "startup"), `${String(mode)}-entered\n`, { flag: "wx" });
  send({ type: "started", mode });
  if (mode === "loop") { for (;;) { /* allocation-free owned CPU loop */ } }
  if (mode === "async") { void new Promise<void>(() => {}); return; }
  send({ type: "ready", value: "cooperative-ready" });
}
if (parentPort) parentPort.on("message", message);
else process.on("message", message);
