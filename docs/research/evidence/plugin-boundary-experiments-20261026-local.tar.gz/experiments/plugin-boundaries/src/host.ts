import { fork, type ChildProcess } from "node:child_process";
import { readlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { Worker } from "node:worker_threads";

const placement = process.argv[2];
const mode = process.argv[3];
let worker: Worker | undefined;
let plugin: ChildProcess | undefined;
const send = (value: object): void => { process.send?.(value); };
function received(value: unknown): void {
  if (value !== null && typeof value === "object") send(value);
}
if (placement === "worker") {
  worker = new Worker(new URL("./executor.js", import.meta.url), {
    workerData: mode, resourceLimits: { maxOldGenerationSizeMb: 32 }, stdout: true, stderr: true,
  });
  worker.stdout.resume(); worker.stderr.resume();
  worker.on("message", received);
  worker.on("error", cause => send({ type: "worker-error", error: String(cause) }));
  worker.on("exit", code => send({ type: "worker-exit", code }));
} else if (placement === "process") {
  plugin = fork(new URL("./executor.js", import.meta.url), [String(mode)], {
    execPath: process.execPath, execArgv: ["--max-old-space-size=64"],
    stdio: ["ignore", "pipe", "pipe", "ipc"],
  });
  plugin.stdout?.resume(); plugin.stderr?.resume();
  plugin.on("message", received);
  plugin.on("error", cause => send({ type: "plugin-error", error: String(cause) }));
  plugin.on("disconnect", () => send({ type: "plugin-disconnect" }));
  plugin.on("exit", (code, signal) => send({ type: "plugin-exit", code, signal }));
  plugin.on("close", (code, signal) => send({ type: "plugin-close", code, signal }));
} else {
  send({ type: "prepared", pid: process.pid, threadSelf: readlinkSync("/proc/thread-self") });
}
process.on("message", (value: unknown) => {
  if (value === null || typeof value !== "object" || !("type" in value)) return;
  if (value.type === "ping" && "nonce" in value) { send({ type: "pong", nonce: value.nonce }); return; }
  if (value.type === "shutdown") { process.disconnect(); return; }
  if (value.type === "terminate") {
    if (worker) {
      void worker.terminate().then(code => send({ type: "terminate-fulfilled", code }));
    } else if (plugin) {
      const sent = plugin.kill("SIGTERM");
      send({ type: "signal-sent", signal: "SIGTERM", sent });
    }
    return;
  }
  if (value.type !== "go") return;
  if (worker) { worker.postMessage(value); return; }
  if (plugin) { plugin.send(value); return; }
  writeFileSync(join(process.env.TEST_MARKERS!, "startup"), `${String(mode)}-entered\n`, { flag: "wx" });
  send({ type: "started", mode });
  if (mode === "loop") { for (;;) { /* allocation-free owned loop blocks only this disposable host */ } }
  if (mode === "async") { void new Promise<void>(() => {}); return; }
  send({ type: "ready", value: "cooperative-ready" });
});
