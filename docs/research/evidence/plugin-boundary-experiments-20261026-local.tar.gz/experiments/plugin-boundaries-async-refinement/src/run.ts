import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { OwnedChild, bounded, procIdentity } from "./process-support.js";

const markerRoot = await mkdtemp("/tmp/pba-");
const child = new OwnedChild("./initializer.js", [], { TEST_MARKERS: markerRoot });
const record: Record<string, unknown> = { node: process.version, childIdentity: child.identity, markerRoot };
let failed: string | undefined;
let rescueUsed = false;
async function ping(): Promise<object> {
  const nonce = randomUUID(); const sentAt = performance.now();
  child.send({ type: "ping", nonce });
  return { nonce, sentAt, pong: await child.wait("pong", value => value.nonce === nonce, 2000) };
}
try {
  await bounded((async () => {
    await child.wait("prepared", () => true, 2000);
    record.beforeGoPing = await ping();
    child.send({ type: "go" });
    await child.wait("initializer-entered", () => true, 2000);
    record.afterEnteredPing = await ping();
    const started = performance.now();
    try { await child.wait("ready", () => true, 500); throw new Error("fixture.ready-before-release"); }
    catch (cause) { assert.match(String(cause), /fixture.deadline:message:ready:500/); }
    record.noReadyObservation = { elapsedMs: performance.now() - started, messages: [...child.messages],
      actualMarker: await readFile(join(markerRoot, "initializer"), "utf8"), live: procIdentity(child.identity.pid) };
    assert.equal(await readFile(join(markerRoot, "initializer"), "utf8"), "entered\n");
    assert.equal(child.messages.some(value => value.type === "ready"), false);
    assert.deepEqual(procIdentity(child.identity.pid), child.identity);
    record.afterDeadlinePing = await ping();
    record.releaseSentAt = performance.now(); child.send({ type: "release" });
    await child.wait("release-received", () => true, 2000);
    await child.wait("initializer-returned", () => true, 2000);
    const ready = await child.wait("ready", () => true, 2000);
    assert.equal(ready.value, "initialized");
    record.completedMarker = await readFile(join(markerRoot, "initializer"), "utf8");
    assert.equal(record.completedMarker, "entered\nreturned\n");
    child.send({ type: "shutdown" });
    await child.wait("startup-joined", () => true, 2000);
    record.normalExit = await child.normalExit();
    const order = child.messages.map(value => value.type);
    for (const [before, after] of [["initializer-entered", "release-received"], ["release-received", "initializer-returned"], ["initializer-returned", "ready"], ["ready", "startup-joined"]]) {
      assert.ok(order.indexOf(before) < order.indexOf(after));
    }
    assert.equal(child.messages.filter(value => value.type === "ready").length, 1, "No second ready through actual normal exit");
    assert.equal(child.messages.some(value => value.type === "startup-error"), false);
  })(), 10000, "awaited-initializer-row");
} catch (cause) { failed = cause instanceof Error ? cause.stack : String(cause); process.exitCode = 1; }
finally {
  if (!child.exited) {
    rescueUsed = true;
    try {
      if (child.process.connected) { child.send({ type: "release" }); child.send({ type: "shutdown" }); }
      await bounded(child.exit, 2000, "failed-row-release-shutdown");
      await bounded(child.close, 2000, "failed-row-close");
    } catch { try { await child.terminate(); } catch (cause) { failed = `${failed ?? ""}\ncleanup:${String(cause)}`; } }
    process.exitCode = 1;
  }
  record.status = failed || rescueUsed ? "failed" : "observed";
  record.failed = failed ?? null; record.rescueUsed = rescueUsed; record.messages = child.messages; record.logs = child.logs;
  record.finalAbsent = procIdentity(child.identity.pid) === undefined;
  await writeFile(new URL("../results/observation.json", import.meta.url), JSON.stringify(record, null, 2) + "\n");
  if (record.finalAbsent) await rm(markerRoot, { recursive: true });
  else process.exitCode = 1;
  console.log(JSON.stringify(record));
}
