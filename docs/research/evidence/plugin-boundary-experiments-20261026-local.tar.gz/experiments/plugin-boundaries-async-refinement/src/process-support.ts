import assert from "node:assert/strict";
import { fork, type ChildProcess } from "node:child_process";
import { readFileSync, readlinkSync, readdirSync } from "node:fs";

export type Message = Record<string, unknown>;
export interface Identity {
  readonly pid: number; readonly procPid: number; readonly startTime: string;
  readonly pidNamespace: string; readonly taskTid?: number;
}
const pidNamespace = readlinkSync("/proc/self/ns/pid");
const procPids = new Map<number, number>();
function procPidFor(localPid: number): number | undefined {
  const known = procPids.get(localPid); if (known !== undefined) return known;
  const matches: number[] = [];
  for (const entry of readdirSync("/proc")) {
    if (!/^\d+$/.test(entry)) continue;
    try {
      if (readlinkSync(`/proc/${entry}/ns/pid`) !== pidNamespace) continue;
      const status = readFileSync(`/proc/${entry}/status`, "utf8");
      const ids = status.match(/^NSpid:\s+(.+)$/m)?.[1]?.trim().split(/\s+/).map(Number);
      if (ids?.at(-1) === localPid) matches.push(Number(entry));
    } catch (cause) {
      if (cause !== null && typeof cause === "object" && "code" in cause && ["ENOENT", "EACCES", "EPERM"].includes(String(cause.code))) continue;
      throw cause;
    }
  }
  assert.ok(matches.length <= 1, "Namespace-qualified local PID maps unambiguously to procfs");
  const mapped = matches[0]; if (mapped !== undefined) procPids.set(localPid, mapped);
  return mapped;
}
export function procIdentity(pid: number, tid?: number): Identity | undefined {
  const procPid = procPidFor(pid); if (procPid === undefined) return undefined;
  try {
    const raw = readFileSync(tid === undefined ? `/proc/${procPid}/stat` : `/proc/${procPid}/task/${tid}/stat`, "utf8");
    const suffix = raw.slice(raw.lastIndexOf(")") + 2).trim().split(/\s+/);
    assert.ok(suffix[19], "Linux stat start time exists");
    return { pid, procPid, startTime: suffix[19], pidNamespace, ...(tid === undefined ? {} : { taskTid: tid }) };
  } catch (cause) {
    if (cause !== null && typeof cause === "object" && "code" in cause && cause.code === "ENOENT") return undefined;
    throw cause;
  }
}
export async function bounded<T>(promise: Promise<T>, ms: number, name: string): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  try {
    return await Promise.race([promise, new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`fixture.deadline:${name}:${ms}`)), ms);
    })]);
  } finally { if (timer) clearTimeout(timer); }
}
export class OwnedChild {
  readonly process: ChildProcess;
  readonly identity: Identity;
  readonly messages: Message[] = [];
  readonly logs: { stdout: string; stderr: string } = { stdout: "", stderr: "" };
  readonly exit: Promise<{ code: number | null; signal: NodeJS.Signals | null }>;
  readonly close: Promise<void>;
  private readonly observers = new Set<() => void>();
  exited = false;
  constructor(script: string, args: readonly string[], env: NodeJS.ProcessEnv) {
    this.process = fork(new URL(script, import.meta.url), [...args], {
      execPath: process.execPath, execArgv: ["--max-old-space-size=64"],
      env: { ...process.env, NODE_OPTIONS: "", NODE_PATH: "", ...env },
      stdio: ["ignore", "pipe", "pipe", "ipc"],
    });
    assert.ok(this.process.pid);
    const identity = procIdentity(this.process.pid);
    assert.ok(identity, "Prove direct child live before releasing fault");
    this.identity = identity;
    this.process.on("message", (value: unknown) => {
      if (value !== null && typeof value === "object") {
        this.messages.push({ ...value, observedAt: performance.now() });
        for (const observe of this.observers) observe();
      }
    });
    for (const key of ["stdout", "stderr"] as const) this.process[key]?.on("data", (chunk: Buffer) => {
      this.logs[key] += chunk.toString();
      if (this.logs[key].length > 131072) throw new Error(`fixture.output-cap:${key}`);
    });
    this.exit = new Promise(resolve => this.process.once("exit", (code, signal) => { this.exited = true; resolve({ code, signal }); }));
    this.close = new Promise(resolve => this.process.once("close", () => resolve()));
    this.process.on("error", cause => { this.logs.stderr += `process-error:${String(cause)}\n`; });
  }
  send(message: object): void { assert.ok(this.process.connected); this.process.send(message); }
  async wait(type: string, predicate: (value: Message) => boolean = () => true, ms = 5000): Promise<Message> {
    let notify: (() => void) | undefined;
    const found = (): Message | undefined => this.messages.find(value => value.type === type && predicate(value));
    try {
      return await bounded(new Promise<Message>(resolve => {
        notify = () => { const value = found(); if (value) resolve(value); };
        this.observers.add(notify); notify();
      }), ms, `message:${type}`);
    } finally { if (notify) this.observers.delete(notify); }
  }
  async normalExit(): Promise<object> {
    const exit = await bounded(this.exit, 2000, "normal-exit");
    await bounded(this.close, 2000, "stdio-close");
    assert.deepEqual(exit, { code: 0, signal: null }, this.logs.stderr);
    assert.equal(procIdentity(this.identity.pid), undefined, "Known direct PID absent after reaped exit");
    return { ...exit, closeObserved: true, absent: true, identity: this.identity };
  }
  async terminate(signal: NodeJS.Signals = "SIGKILL"): Promise<object> {
    const current = procIdentity(this.identity.pid);
    if (current) {
      assert.deepEqual(current, this.identity, "Never signal a reused PID");
      this.process.kill(signal);
    }
    const exit = await bounded(this.exit, 2000, "planned-termination");
    await bounded(this.close, 2000, "planned-stdio-close");
    assert.equal(procIdentity(this.identity.pid), undefined);
    return { requestedSignal: signal, ...exit, closeObserved: true, absent: true, identity: this.identity };
  }
}
