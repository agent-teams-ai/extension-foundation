import { appendFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const marker = join(process.env.TEST_MARKERS!, "initializer");
const gate = Promise.withResolvers<void>();
let startup: Promise<void> | undefined;
const send = (value: object): void => { process.send?.(value); };

async function initialize(): Promise<string> {
  writeFileSync(marker, "entered\n", { flag: "wx" });
  send({ type: "initializer-entered" });
  await gate.promise;
  appendFileSync(marker, "returned\n");
  send({ type: "initializer-returned" });
  return "initialized";
}

process.on("message", (message: unknown) => {
  if (message === null || typeof message !== "object" || !("type" in message)) return;
  if (message.type === "ping" && "nonce" in message) { send({ type: "pong", nonce: message.nonce }); return; }
  if (message.type === "release") { send({ type: "release-received" }); gate.resolve(); return; }
  if (message.type === "go") {
    if (startup !== undefined) throw new Error("fixture.duplicate-startup");
    startup = (async () => {
      const result = await initialize();
      send({ type: "ready", value: result });
    })();
    void startup.catch(cause => { send({ type: "startup-error", cause: String(cause) }); process.exitCode = 1; process.disconnect(); });
    return;
  }
  if (message.type === "shutdown") {
    void (async () => {
      await startup;
      send({ type: "startup-joined" });
      process.disconnect();
    })();
  }
});
send({ type: "prepared" });
