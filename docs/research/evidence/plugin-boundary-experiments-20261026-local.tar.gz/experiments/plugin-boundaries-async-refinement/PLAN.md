# One awaited-initializer refinement — plan before execution

Date: 2026-10-26. Root authorized this isolated correction after the independent
PB result critique. **Plan only; peer criticism precedes implementation/run.**
Do not edit the frozen `plugin-boundaries` source/results/manifests or rerun its
other groups. Writable scope is only this new directory and its later report.
Maximum task payload1MiB; no install/download/service/port/native dependency.

## Question and decision

Can a real async initializer remain awaited by a retained startup Promise while
the host answers independent pings, with readiness emitted only after actual
initializer return? The earlier PB03-2 merely created an unused pending Promise
and withheld ready; its current pings/process-exit facts remain, but it cannot
supply this async-await join evidence.

A pass closes only that fixture observation gap. It does not prove automatic
cancellation, plugin-resource cleanup, hard deadlines, arbitrary initialization
effects, security isolation or a production Host. No architecture change follows.

## Small realistic boundary and test ownership

One actual Node26.11.1 child, real parent/child IPC, one tiny external marker
file and namespace-aware native PID/start-time observation. Copy only the frozen
PB `process-support.ts` observer, recording its origin/hash and unchanged bytes.
New maintained code is ordinary strict TS7.0.2 with `skipLibCheck:false` and the
same read-only shared dependency link. No new supervisor or generic fixture API.

The child has an actual `async initialize()` that writes/sends entered evidence
and **awaits** a test-owned deferred gate. Its retained startup Promise awaits
`initialize()` and emits `ready` only on fulfilled return. The IPC listener is
explicitly what keeps the host physically observable. The gate is scheduling
injection, not a resource or product operation.

## One scenario, including its reachable-path positive control

1. Parent creates unique marker root and child. Observer retains exact mapped
   native PID/start-time before go. Require a fresh nonce ping before go.
2. Child starts retained awaited startup, writes literal `entered` marker and
   emits initializer-entered from inside the async function before its await.
3. Parent sends a new nonce after that event and requires its response. Wait
   for ready with an explicit500ms observation cap; require the named timeout,
   no recorded ready event, exact same child live and marker bytes only entered.
   This deadline is observation, never cancellation or physical absence proof.
4. Parent sends another fresh ping after the deadline. Then explicitly release
   the same deferred gate. Require actual initializer-returned followed by ready,
   parent marker bytes exactly entered/returned and no second ready. This
   same-process positive proves readiness was reachable and gated by the real
   awaited return, rather than a broken event path.
5. Request shutdown only after ready. Child awaits its retained startup Promise
   before disconnecting. Require actual normal exit0/no signal, stdio close and
   exact mapped native incarnation absence. Retain all messages/nonces/marker
   bytes and native identity/exit receipt before removing the unique owned root.

## Oracle, falsifiers and controls

Independent parent IPC/marker/native observations supply the expected answer.
Literal marker/output expectations are not generated from child's state fields.
No child Boolean alone qualifies pending or completed startup. Source inspection
must show actual `await initialize()` and readiness after that await.

Falsifiers: ready before release, failed post-enter/post-deadline ping, no actual
initializer-returned/ready after release, duplicate ready, wrong marker bytes,
abnormal exit or unproved native absence. A deadline/no-ready without the later
reachable ready control is insufficient and fails qualification. No second
placement or broad PB repeat is needed.

## Bounds and cleanup

One child, no loops, ≤16KiB marker/results plus bounded128KiB streams; whole row
10s observation bound, each positive message2s, expected no-ready500ms, native
exit/close2s each. Execute inside root's bounded command slot; no generic hard
watchdog claim. In finally, release any held gate and request shutdown; if normal
completion fails, retire only the stored exact child handle/incarnation, retain
cleanup debt and fail the row. Never equate rescue with the required normal exit.

Retain plan/peer disposition, strict config, copied observer origin/hash, all
new sources and any diff, commands/build logs, actual structured receipt,
source/binary/package hashes, failures and final checksum manifest. No optional
rerun after this join is resolved.

## Cost and comparison

Target new tests/fixture code70–130TS lines plus the unchanged copied observer;
production/shared/runtime and integration LOC0. No new significant technology
choice: reuse Node/IPC/actual async-await. Confidence9/10, achievable reliability8/10
for this bounded trusted fixture, complexity2/10; judgments, not uptime. Root's
≤1MiB cap and strict unchanged toolchain apply. Notify state/root before the
small build/run; do not collide with its compiler slot.

## Peer disposition before implementation

PB peer approved this one row on2026-10-26, requiring actual observed ordering
`initializer-entered < release-received < initializer-returned < ready`, exact
parent-read marker lines, and exactly one ready through normal exit. Source
must retain actual startup/initializer awaits; copied observer origin/hash stays
visible. The500ms result remains observation-only; finally releases the gate and
joins startup/shutdown, and any rescue fails normal-exit qualification. No extra
placement or PB repeat is requested. All refinements are accepted below.
