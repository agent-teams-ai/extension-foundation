# Actual awaited initializer — isolated refinement result

Date: 2026-10-26. **One selected row observed successfully after one environmental
ENOSPC attempt.** This is a separate TEST artifact. Original PB sources, reports,
results and manifests remain unchanged; its weaker PB03-2 observation is not
retroactively relabeled as an actual awaited initializer.

## What changed and why

The independent result critique found that PB03-2 created an unused pending
Promise and deliberately withheld ready. Its responsive-host/no-ready/native-exit
observations were valid, but no caller actually awaited an initializer. Root
authorized this one targeted correction rather than a full PB repeat. The PB
peer reviewed `PLAN.md` before implementation and required observed
entered/release/return/ready ordering, exact parent-read markers and exactly one
ready through normal exit. Those refinements were applied.

`src/initializer.ts` now contains an actual `async initialize()` that writes
entered evidence and awaits a deferred gate. The retained `startup` Promise
awaits `initialize()` and emits ready only after its return. Shutdown awaits
that same startup Promise before disconnecting. This is a small test-owned
join, not a new Host/runtime abstraction.

## Actual observations

The single successful run used Node26.11.1, strict TypeScript7.0.2,
`skipLibCheck:false` and `noEmitOnError:true`. It reused read-only root-managed
dependencies with no install or version change. Native namespace PID16 mapped
to procfs PID1185329, start time5036502, namespace `pid:[4026532348]`.

| Boundary | Independent observed fact |
| --- | --- |
| Before starting initialization | Fresh nonce ping succeeded. |
| Inside actual initializer, before deferred await | Initializer-entered message; parent-read file exactly `entered` plus newline. |
| While startup actually awaited initializer | New post-entered nonce ping succeeded; no ready message during the500ms observation window. Actual elapsed observation was503.37ms. Exact native incarnation remained live. |
| After observation deadline | A third independent nonce ping succeeded; no cancellation/termination was inferred from the deadline. |
| Explicit gate release | Ordered actual messages: release-received642.671ms, initializer-returned642.699ms, ready642.751ms, startup-joined643.231ms on the parent's monotonic clock. |
| Reachable positive | Ready's actual literal was `initialized`; parent-read marker became exactly `entered\nreturned\n`. Exactly one ready was observed through actual normal exit. |
| Physical retirement | Actual exit0/no signal, stdio close, exact mapped process absent. `rescueUsed:false`; no cleanup debt. |

Full nonces, message ordering, parent-read file bytes, native identity and actual
exit receipt are in `results/observation.json`; complete parent CLI JSON is in
`logs/run-attempt-2.log`. Source inspection supplies the actual await relation;
the expected markers/results are independently stated in the parent rather than
generated from a child status Boolean.

The same-process release/ready positive matters: no-ready alone might result
from a broken message path. Here releasing the retained gate actually allowed
the awaited initializer and startup to finish, produce the expected file/ready
facts and join shutdown.

## Environment failure retained separately

The first strict build returned2 with an empty diagnostic file during host disk
exhaustion; partially emitted `process-support.js` was exactly4096 bytes. An
attempted run returned1 and subsequent inspection failed at sandbox startup:
the synthetic mount target could not be registered due to ENOSPC. There was no
observation JSON and no pass. `results/enospc-attempt-1.json` preserves the exact
distinction, partial-emission hashes and startup error. The empty raw first
build/run files are retained.

Root reclaimed only its own reproducible bootstrap npm cache. With ordinary
exec restored, strict build attempt2 exited0 with no diagnostics. Only then did
the single row execute and exit0. This does not establish a TypeScript source
defect or qualify behavior under disk-full conditions. No sandbox escalation,
namespace bypass, dependency change or peer-data cleanup was used.

## Scope and remaining limits

This closes the specific actual async-await observation gap: an initializer
can remain awaited while its ordinary event loop handles IPC, readiness can be
gated on its actual return, and its retained startup can join normal shutdown.
The deferred gate is a named synthetic scheduling injection; the async-await,
IPC, marker writes and process exit are real.

Harness IPC keeps the child physically observable. Neither an unresolved
Promise nor its awaiting caller alone is claimed to keep Node alive. No
automatic cancellation, plugin-owned native-resource cleanup, arbitrary
initializer side effects, graceful drain of long-lived work, hard outer timeout,
hostile isolation or production lifecycle is qualified. The10s whole-row race
and per-message limits are observation bounds, not generic cancellation or
independent watchdog guarantees. Any rescue would have failed the required
normal-exit row; none was used.

No Worker/process placement matrix, original PB repeat or additional fault was
run. Further tests are unnecessary for this selected gap. Production/shared
runtime and product integration LOC remain0. `results/source-origin.json` binds
the unchanged copied observer to original PB `process-support.ts`, SHA-256
`5275ff31a8f2b0d8d0dd0aa9b0043776bfc4b16ab4756af3d21b8af17f6af06b`.

## Reproduction

Coordinate the root compiler/run slot and retain a new attempt destination
before another authorized run. From this directory with the same read-only
dependency symlink:

```sh
/tmp/ps26-tools-vr2ly24w/bin/node /tmp/ps26-deps-u35mfk4v/node_modules/typescript/bin/tsc -p tsconfig.json --pretty false
/tmp/ps26-tools-vr2ly24w/bin/node out/run.js
```

Expected: strict build exit0; run exit0; `status:observed`, one ready after
initializer-returned, normal exit0/close/absence, no rescue. The code owns only
its short `/tmp/pba-*` marker root and exact child handle. Exclude `node_modules`
symlink and reproducible `out/` from the final archival payload; retain all
source/config, origin, plan/peer disposition, logs, results and checksums.
