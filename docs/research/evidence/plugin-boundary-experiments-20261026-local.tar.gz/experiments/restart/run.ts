import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, readdirSync, readlinkSync, openSync, closeSync, statSync } from "node:fs";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { join, resolve } from "node:path";

interface Owned { readonly pid: number; readonly start: string; readonly kind: string }
function identity(pid: number): { pid: number; hostPid: number; start: string; namespace: string } | undefined {
  const namespace = readlinkSync("/proc/self/ns/pid");
  for (const name of readdirSync("/proc")) {
    if (!/^\d+$/.test(name)) continue;
    try {
      if (readlinkSync(`/proc/${name}/ns/pid`) !== namespace) continue;
      const status = readFileSync(`/proc/${name}/status`, "utf8");
      const match = /^NSpid:\s+(.+)$/m.exec(status);
      if (match === null || Number(match[1]?.trim().split(/\s+/).at(-1)) !== pid) continue;
      const raw = readFileSync(`/proc/${name}/stat`, "utf8");
      const start = raw.slice(raw.lastIndexOf(")") + 2).split(" ")[19];
      if (start === undefined) throw new Error("fixture.proc.invalid");
      return { pid, hostPid: Number(name), start, namespace };
    } catch (cause) {
      if (typeof cause === "object" && cause !== null && "code" in cause && (cause.code === "ENOENT" || cause.code === "EACCES" || cause.code === "ESRCH")) continue;
      throw cause;
    }
  }
  return undefined;
}
const name = process.argv[2];
const profile = process.argv[3];
const pattern = process.argv[4];
if (name === undefined || (profile !== "baseline" && profile !== "corrected")) throw new Error("runner.arguments");
const root = resolve(import.meta.dirname, "..");
const ownedRoot = await mkdtemp("/tmp/rs-");
const registry = join(ownedRoot, "custody.jsonl");
writeFileSync(registry, "");
const args = ["--test", "--test-isolation=none", "--test-reporter=tap", "--test-concurrency=1"];
if (pattern !== undefined) args.push(`--test-name-pattern=${pattern}`);
args.push(profile === "baseline" ? (name === "original-s07" ? "out/tests/stop-admission-counterexample.test.js" : "out/tests/absence-control.test.js") : "out/tests/restart.test.js");
const start = performance.now();
const outputPath = join(root, "logs", `${name}.tap`);
const errorPath = join(root, "logs", `${name}.stderr`);
const outputHandle = openSync(outputPath, "w");
const errorHandle = openSync(errorPath, "w");
const spawned = spawn(process.execPath, args, { cwd: join(root, profile), env: { ...process.env,
  NODE_OPTIONS: "", NODE_PATH: "", TMPDIR: ownedRoot, RESTART_CUSTODY_REGISTRY: registry,
  RESTART_RESULTS: join(root, "results") }, stdio: ["ignore", outputHandle, errorHandle] });
if (spawned.pid === undefined) throw new Error("runner.spawn.no-pid");
const testIdentity = identity(spawned.pid);
if (testIdentity === undefined) throw new Error("runner.spawn.identity-missing");
let output = "";
let errors = "";
let deadline = false;
let outputExceeded = false;
let testExited = false;
const retirements: unknown[] = [];
function known(): Owned[] {
  return readFileSync(registry, "utf8").split("\n").filter(Boolean).map(line => {
    const value: unknown = JSON.parse(line);
    if (typeof value !== "object" || value === null || !("pid" in value) || !("start" in value) || !("kind" in value) ||
      typeof value.pid !== "number" || typeof value.start !== "string" || typeof value.kind !== "string") throw new Error("runner.registry.invalid");
    return { pid: value.pid, start: value.start, kind: value.kind };
  });
}
function retire(value: Owned): void {
  const actual = identity(value.pid);
  if (actual?.start !== value.start) { retirements.push({ owned: value, actual, sent: false }); return; }
  const sent = process.kill(value.pid, "SIGKILL");
  retirements.push({ owned: value, actual, sent });
}
function rescue(): void {
  for (const value of known().sort((a, b) => Number(a.kind === "worker") - Number(b.kind === "worker"))) retire(value);
  setTimeout(() => { if (!testExited) retire({ ...testIdentity!, kind: "test-parent" }); }, 500).unref();
}
const outputMonitor = setInterval(() => {
  if ((statSync(outputPath).size > 1024 * 1024 || statSync(errorPath).size > 1024 * 1024) && !outputExceeded) {
    outputExceeded = true; rescue();
  }
}, 100);
const outerDeadlineMs = pattern?.includes("RST02") || pattern?.includes("RST03") ? 60000 : 120000;
const timer = setTimeout(() => { deadline = true; rescue(); }, outerDeadlineMs);
const outcome = await new Promise<{ code: number | null; signal: NodeJS.Signals | null }>((resolveExit, reject) => {
  spawned.once("error", reject);
  spawned.once("exit", () => { testExited = true; });
  spawned.once("close", (code, signal) => resolveExit({ code, signal }));
});
clearTimeout(timer);
clearInterval(outputMonitor);
closeSync(outputHandle);
closeSync(errorHandle);
output = readFileSync(outputPath, "utf8");
errors = readFileSync(errorPath, "utf8");
const owned = known();
const cleanupStart = performance.now();
let live = owned.filter(value => identity(value.pid)?.start === value.start);
if (live.length > 0) {
  for (const value of live) retire(value);
  while (live.length > 0 && performance.now() - cleanupStart < 3000) {
    await new Promise<void>(done => setTimeout(done, 20));
    live = owned.filter(value => identity(value.pid)?.start === value.start);
  }
}
const registryBytes = await readFile(registry, "utf8");
writeFileSync(join(root, "logs", `${name}.tap`), output);
writeFileSync(join(root, "logs", `${name}.stderr`), errors);
const receipt = { name, command: [process.execPath, ...args], cwd: join(root, profile), runtime: process.version,
  testIdentity, outcome, deadline, outerDeadlineMs, outputExceeded, elapsedMs: performance.now() - start,
  owned, finalObservations: owned.map(value => ({ owned: value, actual: identity(value.pid) ?? null })),
  retirements, unresolved: live, registrySha256: createHash("sha256").update(registryBytes).digest("hex"),
  cleanupQualified: live.length === 0 && retirements.length === 0 && !deadline && !outputExceeded };
writeFileSync(join(root, "results", `${name}-custody.json`), JSON.stringify(receipt, null, 2) + "\n");
writeFileSync(join(root, "results", `${name}-registry.jsonl`), registryBytes);
if (live.length === 0) await rm(ownedRoot, { recursive: true, force: true });
console.log(JSON.stringify(receipt));
process.exitCode = outcome.code === 0 && receipt.cleanupQualified ? 0 : 1;
