import assert from "node:assert/strict";
import test from "node:test";
import { makeSubmission, SUCCESS } from "../upstream/recovery/src/schema.js";
import { Supervisor } from "../upstream/recovery/src/supervisor.js";

for (const profile of ["record-only", "restart-pending"] as const) {
test(`S-07 ${profile} required admission seal: no new accepted durable record while stop is in flight`, { timeout: 20000 }, async context => {
  await using supervisor = await Supervisor.create(profile);
  supervisor.holdNextAcknowledgement();
  const worker = await supervisor.start();
  const operation = makeSubmission();
  const candidate = makeSubmission("arrives-during-stop");
  await worker.submit(operation);
  const firstHeld = await supervisor.wait("launch-ack-held", row => row.workerPid === worker.pid);
  const stopping = worker.stop();
  let admittedDuringStop = false;
  let rejectedCode: unknown;
  try {
    await supervisor.wait("revoked", row => row.workerPid === worker.pid);
    // Named observation, not a delay: the capacity slot has now been released,
    // while held launch acknowledgement keeps the writer's stop in flight.
    await supervisor.observeEffectExit(operation);
    try { admittedDuringStop = (await worker.submit(candidate)).created; }
    catch (cause) { rejectedCode = typeof cause === "object" && cause !== null && "code" in cause ? cause.code : "uncoded"; }
    context.diagnostic(JSON.stringify({ profile, phase: "stopping", admittedDuringStop, rejectedCode,
      canonicalRecords: (await supervisor.store.read()).records, counts: supervisor.counts() }));
  } finally {
    supervisor.releaseAcknowledgement();
    await stopping;
  }
  const fresh = await supervisor.start();
  if (profile === "restart-pending") {
    await supervisor.wait("claimed", row => row.workerPid === fresh.pid && row.record?.id === candidate.id);
    await supervisor.wait("effect-held", row => row.child?.pid !== firstHeld.child?.pid);
    await supervisor.complete(candidate);
    await supervisor.wait("terminal", row => row.workerPid === fresh.pid && row.record?.id === candidate.id);
  }
  await fresh.settle();
  const restored = await fresh.query(candidate);
  assert.equal(restored?.state, profile === "restart-pending" ? "terminal" : "pending");
  assert.equal(restored?.result, profile === "restart-pending" ? SUCCESS : null);
  assert.equal((await fresh.submit(candidate)).created, false);
  await fresh.settle();
  assert.deepEqual(await fresh.query(candidate), restored);
  context.diagnostic(JSON.stringify({ profile, phase: "fresh-worker", restored,
    disposition: profile === "restart-pending" ? "resumed-to-success" : "durably-pending-no-automatic-dispatch",
    counts: supervisor.counts() }));
  await fresh.stop();
  assert.equal(admittedDuringStop, false, "The existing recovery fixture lacks a permanent admission seal during stop.");
});
}
