import assert from "node:assert/strict";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import test from "node:test";
import { makeSubmission } from "../upstream/recovery/src/schema.js";
import { Supervisor } from "../upstream/recovery/src/supervisor.js";

test("RST01 negative control: independent candidate absence and acquisition oracle rejects the unsealed fixture", { timeout: 20000 }, async () => {
  await using supervisor = await Supervisor.create("record-only");
  supervisor.holdNextAcknowledgement();
  const worker = await supervisor.start();
  const operation = makeSubmission();
  const candidate = makeSubmission("absence-control");
  await worker.submit(operation);
  await supervisor.wait("launch-ack-held");
  const stopping = worker.stop();
  let absent = true;
  try {
    await supervisor.wait("revoked", row => row.workerPid === worker.pid);
    await supervisor.observeEffectExit(operation);
    const accepted = await worker.submit(candidate);
    const actual = await supervisor.store.read();
    absent = !actual.records.some(row => row.id === candidate.id);
    const path = process.env.RESTART_RESULTS;
    assert.ok(path);
    await writeFile(join(path, "rst01-baseline-absence-control.json"), JSON.stringify({ accepted, actual, absent, events: supervisor.events, counts: supervisor.counts() }, null, 2));
  } finally {
    supervisor.releaseAcknowledgement();
    await stopping;
  }
  const fresh = await supervisor.start();
  const restored = await fresh.query(candidate);
  await fresh.stop();
  const path = process.env.RESTART_RESULTS;
  assert.ok(path);
  await writeFile(join(path, "rst01-baseline-fresh-control.json"), JSON.stringify({ restored, events: supervisor.events, counts: supervisor.counts() }, null, 2));
  assert.equal(absent, true, "independent canonical absence oracle must fail for original missing seal");
  assert.equal(restored, undefined, "fresh-worker absence oracle");
});
