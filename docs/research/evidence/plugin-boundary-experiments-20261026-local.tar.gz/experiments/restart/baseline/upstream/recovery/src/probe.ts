import { appendFileSync, readFileSync, readdirSync, readlinkSync } from "node:fs";
export function processIdentity(pid: number): { pid: number; hostPid: number; start: string; namespace: string } | undefined {
  const namespace = readlinkSync("/proc/self/ns/pid");
  for (const name of readdirSync("/proc")) {
    if (!/^\d+$/.test(name)) continue;
    try {
      if (readlinkSync(`/proc/${name}/ns/pid`) !== namespace) continue;
      const status = readFileSync(`/proc/${name}/status`, "utf8");
      const match = /^NSpid:\s+(.+)$/m.exec(status);
      if (match === null || Number(match[1]?.trim().split(/\s+/).at(-1)) !== pid) continue;
      const raw = readFileSync(`/proc/${name}/stat`, "utf8");
      const start = raw.slice(raw.lastIndexOf(")") + 2).split(" ")[19];
      if (start === undefined) throw new Error("fixture.proc.invalid");
      return { pid, hostPid: Number(name), start, namespace };
    } catch (cause) {
      if (typeof cause === "object" && cause !== null && "code" in cause && (cause.code === "ENOENT" || cause.code === "EACCES" || cause.code === "ESRCH")) continue;
      throw cause;
    }
  }
  return undefined;
}
export function registerProcess(pid: number, kind: string): void {
  const path = process.env.RESTART_CUSTODY_REGISTRY;
  const identity = processIdentity(pid);
  if (path !== undefined && identity !== undefined) appendFileSync(path, JSON.stringify({ ...identity, kind }) + "\n");
}
