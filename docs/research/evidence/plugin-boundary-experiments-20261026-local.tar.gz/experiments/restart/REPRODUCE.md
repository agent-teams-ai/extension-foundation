# Reproduce restart research

Read `../../reports/restart.md` and `../../plans/restart.md` first. This is a
disposable research fixture, not a production runtime. The historical tree is
read-only. Do not install there or modify shared dependencies.

The executed root-managed profile is recorded in
`../../validation/toolchain-bootstrap.json` and
`results/execution-identities.json`: Node26.11.1, TypeScript7.0.2,
Core/Assembly0.7.0, Resources0.2.1, Conformance0.5.0 and Node types24.19.1.
`inputs/` retains the exact historical dependency manifest/lock. Installed
dependencies/native binaries are not part of the retained source artifact.

When the same shared profile is available, these existing symlinks point only
to its read-only `node_modules`. Coordinate the compiler/run slot with root.
Run each build sequentially from the stated directory:

```sh
# experiments/restart
/tmp/ps26-tools-vr2ly24w/bin/node /tmp/ps26-deps-u35mfk4v/node_modules/typescript/bin/tsc -p tsconfig.json --pretty false
# experiments/restart/baseline
/tmp/ps26-tools-vr2ly24w/bin/node /tmp/ps26-deps-u35mfk4v/node_modules/typescript/bin/tsc -p tsconfig.json --pretty false
# experiments/restart/corrected
/tmp/ps26-tools-vr2ly24w/bin/node /tmp/ps26-deps-u35mfk4v/node_modules/typescript/bin/tsc -p tsconfig.json --pretty false
```

From `experiments/restart`, execute groups sequentially:

```sh
/tmp/ps26-tools-vr2ly24w/bin/node runner-out/run.js original-s07 baseline
/tmp/ps26-tools-vr2ly24w/bin/node runner-out/run.js baseline-absence baseline
/tmp/ps26-tools-vr2ly24w/bin/node runner-out/run.js corrected-rst01 corrected RST01
/tmp/ps26-tools-vr2ly24w/bin/node runner-out/run.js corrected-rst02 corrected RST02
/tmp/ps26-tools-vr2ly24w/bin/node runner-out/run.js corrected-rst03 corrected RST03
```

**The first two commands must exit1**, with two original S07 assertion failures
and one new absence assertion failure respectively. Do not convert them to
passing tests or suppress their raw red logs. The last three commands exit0
with4/1/2 positive cases. Inspect custody JSON as well as exit status: completed
groups require `cleanupQualified:true`, no deadline/output overflow, no outer
rescue and no unresolved processes. The intentional exact-handle SIGKILL in
RST03B appears in actual custodian events, not outer rescue retirements.

The runner uses a short owned `/tmp/rs-*` root, retains all explicitly created
child identities before barriers release, writes bounded native stdout/stderr
files and checks native process absence. Its PID observation is namespace-aware:
known Node PID + PID-namespace inode is mapped through NSpid to host-proc PID and
start time. This environment's `/proc/<Node PID>` alone is not a valid oracle.
No pattern kills or arbitrary descendant/process-tree claim is made. If the
same mapping is unavailable on another environment, retain unavailable evidence
rather than substitute passing in-memory status.

Current tests overwrite their named result files. Preserve existing evidence
before a separately authorized rerun. `logs/*empty-capture-attempt-1*`,
`logs/*before-evidence-refinement*`, associated custody receipts and the initial
identity failure note intentionally retain earlier attempts. They are not
additional distinct qualification cases.

For archival delivery, exclude all `node_modules` symlinks, `out/` and
`runner-out/`; their inputs/configuration/source are retained, and the emitted
files are reproducible. Keep the original S07, new test files, copied fixture
source, strict configs, diffs/inventories, locks, raw logs and all result JSON.
