import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import test from "node:test";
import { assemblyFor, group } from "@get-modular/assembly";
import type { SemanticCapabilities } from "../upstream/semantic/src/composition/semantic.root.js";
import { sessionGroup } from "../upstream/semantic/src/features/session/composition/session.group.js";
import { sessionModule } from "../upstream/semantic/src/features/session/composition/session.module.js";
import { identityInput, journalInput } from "../upstream/semantic/src/features/session/composition/session.inputs.js";
import { lifetimeControls, lifetimeRunner } from "../upstream/semantic/tests/features/runner/lifetime.js";
import { createAttempt } from "../upstream/semantic/tests/support/attempt-owner.js";
import { barrier } from "../upstream/semantic/tests/support/barriers.js";
import { createFileJournal } from "../upstream/semantic/tests/support/journal.js";
import { CANCELLED, SUCCESS, makeSubmission, type Identity } from "../upstream/recovery/src/schema.js";
import { processIdentity } from "../upstream/recovery/src/probe.js";
import { Supervisor, type Observation } from "../upstream/recovery/src/supervisor.js";

const bounded = { timeout: 20000 };
const directory = process.env.RESTART_RESULTS;
if (directory === undefined) throw new Error("fixture.results.missing");
async function save(name: string, value: unknown): Promise<void> {
  await writeFile(join(directory!, `${name}.json`), JSON.stringify(value, null, 2) + "\n");
}
function audit(events: readonly Observation[], value: Identity) {
  return events.flatMap(event => event.audit?.operation.scope === value.scope && event.audit.operation.id === value.id ? [event.audit] : []);
}
function ordered(events: readonly Observation[]): void {
  const sequences = events.flatMap(event => event.audit === undefined ? [] : [event.audit.sequence]);
  assert.deepEqual(sequences, Array.from({ length: sequences.length }, (_, index) => index + 1));
}
function noAcquisition(supervisor: Supervisor, value: Identity): void {
  assert.deepEqual(audit(supervisor.events, value), []);
  assert.notDeepEqual(supervisor.reservationIdentity(), { scope: value.scope, id: value.id });
}
function noUnexpected(supervisor: Supervisor): void {
  assert.deepEqual(supervisor.events.filter(row => row.kind === "worker-fatal" || row.kind === "protocol-error" || row.kind === "dispatch-error"), []);
}
function expectEffect(bytes: string, value: Identity): void {
  assert.deepEqual(bytes.trim().split("\n").map(line => JSON.parse(line)), [{ scope: value.scope, id: value.id, value: SUCCESS }]);
}
async function liveFile(supervisor: Supervisor, value: Identity): Promise<string> {
  const snapshot = await supervisor.store.read();
  const record = snapshot.records.find(row => row.scope === value.scope && row.id === value.id);
  assert.ok(record?.claim);
  return readFile(join(supervisor.directory, `effect-${record.claim}.jsonl`), "utf8");
}

for (const profile of ["record-only", "restart-pending"] as const) {
  test(`RST01 ${profile}: actual seal ACK rejects absent candidates before acquisition, including after reconcile`, bounded, async () => {
    await using supervisor = await Supervisor.create(profile);
    const operation = makeSubmission();
    const candidate = makeSubmission("during-sealed-stop");
    const afterReconcile = makeSubmission("after-reconcile");
    supervisor.holdNextAcknowledgement();
    const worker = await supervisor.start();
    await worker.submit(operation);
    await supervisor.wait("launch-ack-held", row => row.workerPid === worker.pid);
    const stopping = worker.stop();
    try {
      await supervisor.wait("admission-sealed", row => row.workerPid === worker.pid);
      await supervisor.wait("revoked", row => row.workerPid === worker.pid);
      await supervisor.observeEffectExit(operation);
      const before = await readFile(supervisor.store.canonical);
      await assert.rejects(worker.submit(candidate), { code: "fixture.admission.sealed" });
      assert.deepEqual(await readFile(supervisor.store.canonical), before);
      assert.equal((await supervisor.store.read()).records.some(row => row.id === candidate.id), false);
      noAcquisition(supervisor, candidate);
      const accepted = await worker.query(operation);
      const beforeDuplicate = audit(supervisor.events, operation).length;
      assert.equal((await worker.submit(operation)).created, false);
      await assert.rejects(worker.submit(makeSubmission(operation.id, " conflicting ")), { code: "fixture.operation.conflict" });
      assert.deepEqual(await worker.query(operation), accepted);
      assert.equal(audit(supervisor.events, operation).length, beforeDuplicate);
      await worker.reconcile();
      const reconciledBytes = await readFile(supervisor.store.canonical);
      await assert.rejects(worker.submit(afterReconcile), { code: "fixture.admission.sealed" });
      assert.deepEqual(await readFile(supervisor.store.canonical), reconciledBytes);
      noAcquisition(supervisor, afterReconcile);
      assert.equal(supervisor.counts().reserved, false);
      await save(`rst01-${profile}-sealed`, { events: supervisor.events, canonical: await supervisor.store.read(), counts: supervisor.counts(), rejected: [candidate, afterReconcile] });
    } finally {
      supervisor.releaseAcknowledgement();
      await stopping;
    }
    const fresh = await supervisor.start();
    await fresh.settle();
    assert.equal(await fresh.query(candidate), undefined);
    assert.equal(await fresh.query(afterReconcile), undefined);
    noAcquisition(supervisor, candidate);
    noAcquisition(supervisor, afterReconcile);
    assert.equal(supervisor.counts().launches, 1);
    await fresh.stop();
    ordered(supervisor.events);
    noUnexpected(supervisor);
    await save(`rst01-${profile}-fresh`, { events: supervisor.events, canonical: await supervisor.store.read(), counts: supervisor.counts() });
  });

  test(`RST01 ${profile}: earlier queued canonical acceptance precedes seal and survives joined stop`, bounded, async () => {
    await using supervisor = await Supervisor.create(profile);
    const operation = makeSubmission("before-seal");
    const first = await supervisor.start("acceptance-temp-closed");
    const accepted = first.submit(operation);
    await supervisor.wait("barrier", row => row.workerPid === first.pid && row.barrier === "acceptance-temp-closed");
    assert.deepEqual((await supervisor.store.read()).records, []);
    const stopping = first.stop();
    assert.equal((await accepted).created, true);
    await stopping;
    const kinds = supervisor.events.filter(row => row.workerPid === first.pid).map(row => row.kind);
    assert.ok(kinds.indexOf("stop-requested") < kinds.indexOf("acceptance-committed"));
    assert.ok(kinds.indexOf("acceptance-committed") < kinds.indexOf("admission-sealed"));
    assert.equal((await supervisor.store.read()).records[0]?.state, "pending");
    assert.equal(supervisor.counts().reserved, false);
    assert.equal(supervisor.counts().launches, 0);
    const originalAudits = audit(supervisor.events, operation);
    assert.deepEqual(originalAudits.map(row => row.action), ["reserve-attempt"]);
    const fresh = await supervisor.start();
    if (profile === "restart-pending") {
      await supervisor.wait("effect-held");
      await supervisor.complete(operation);
      await supervisor.wait("terminal", row => row.workerPid === fresh.pid && row.record?.id === operation.id);
    }
    await fresh.settle();
    const restored = await fresh.query(operation);
    assert.equal(restored?.state, profile === "restart-pending" ? "terminal" : "pending");
    assert.equal(restored?.result, profile === "restart-pending" ? SUCCESS : null);
    const beforeDuplicate = audit(supervisor.events, operation).length;
    assert.equal((await fresh.submit(operation)).created, false);
    await fresh.settle();
    assert.deepEqual(await fresh.query(operation), restored);
    assert.equal(audit(supervisor.events, operation).length, beforeDuplicate);
    const freshReserves = audit(supervisor.events, operation).filter(row => row.grant === fresh.grant && row.action === "reserve-attempt");
    assert.equal(freshReserves.length, profile === "restart-pending" ? 1 : 0);
    assert.equal(supervisor.counts().launches, profile === "restart-pending" ? 1 : 0);
    if (profile === "restart-pending") expectEffect(await supervisor.effectArtifact(operation), operation);
    await fresh.stop();
    ordered(supervisor.events);
    noUnexpected(supervisor);
    await save(`rst01-${profile}-before-seal`, { events: supervisor.events, canonical: await supervisor.store.read(), counts: supervisor.counts() });
  });
}

test("RST02: readiness rejects after real construction, one cleanup debt retained and retried without publication", bounded, async () => {
  const readiness = Promise.withResolvers<void>();
  const holdRelease = barrier();
  const controls = lifetimeControls({ cleanupFailures: 1, holdRelease });
  const preparation = await assemblyFor<SemanticCapabilities>().prepare({
    profileId: "fixture/restart/readiness-failure",
    modules: [group("runner", [lifetimeRunner(controls)]), sessionGroup],
    roots: { session: sessionModule }, inputs: { identity: identityInput, journal: journalInput },
  });
  assert.equal(preparation.status, "prepared");
  if (preparation.status !== "prepared") throw new Error("fixture.preparation.failed");
  await using journal = await createFileJournal();
  const attempt = createAttempt(preparation.prepared, "readiness-rejection", journal, { readiness: readiness.promise });
  const rejection = assert.rejects(attempt.ready, { code: "fixture.readiness.rejected" });
  try {
    assert.equal((await attempt.startup).status, "succeeded");
    assert.ok(controls.resource);
    await controls.resource.probe();
    readiness.reject(Object.assign(new Error("Named readiness rejection."), { code: "fixture.readiness.rejected" }));
    await rejection;
    await assert.rejects(attempt.run({ id: "never-entered", payload: "hello", signal: new AbortController().signal }), { code: "fixture.ingress.closed" });
    assert.equal(attempt.snapshot().publications, 0);
    const firstReport = await attempt.stop();
    assert.equal(firstReport.complete, false);
    assert.equal(firstReport.settled, true);
    assert.equal(firstReport.debts.length, 1);
    const debt = firstReport.debts[0];
    assert.ok(debt?.state === "failed");
    assert.ok(typeof debt.cause === "object" && debt.cause !== null && "code" in debt.cause);
    assert.equal(debt.cause.code, "fixture.cleanup.failed");
    assert.equal(attempt.snapshot().phase, "debt");
    await controls.resource.probe();
    await journal.probe();
    const retry = attempt.stop();
    await controls.releaseEntered.reached;
    await controls.resource.probe();
    await journal.probe();
    holdRelease.release();
    assert.deepEqual(await retry, { complete: true, settled: true, debts: [] });
    await assert.rejects(controls.resource.probe(), { code: "EBADF" });
    await assert.rejects(journal.probe(), { code: "EBADF" });
    assert.deepEqual(controls.enteredIds, []);
    const records = await journal.read();
    assert.deepEqual(records.filter(row => row.kind === "effect" || row.kind === "terminal"), []);
    assert.equal(records.filter(row => row.kind === "resource-released").length, 1);
    assert.equal(controls.cleanupAttempts, 2);
    assert.equal(attempt.snapshot().publications, 0);
    await save("rst02-readiness-debt", { firstReport: { complete: firstReport.complete, settled: firstReport.settled, debts: firstReport.debts.map(debt => ({ state: debt.state, path: debt.path, cause: debt.state === "failed" && typeof debt.cause === "object" && debt.cause !== null && "code" in debt.cause ? debt.cause.code : null })) }, records, events: controls.events, snapshot: attempt.snapshot(), probes: { beforeRetry: "open", afterRetry: "EBADF", journalAfterRetry: "EBADF" } });
  } finally {
    holdRelease.release();
    readiness.reject(new Error("fixture.finally.release"));
    await attempt[Symbol.asyncDispose]();
  }
});

test("RST03A: real synced file effect and actual late success cannot overwrite canonical cancellation", bounded, async () => {
  await using supervisor = await Supervisor.create("record-only");
  supervisor.setNextEffectMode("held-result");
  const operation = makeSubmission();
  const worker = await supervisor.start();
  await worker.submit(operation);
  const held = await supervisor.wait("effect-held");
  assert.ok(held.child);
  const initialIdentity = processIdentity(held.child.pid);
  await supervisor.wait("child-recorded", row => row.workerPid === worker.pid);
  await supervisor.complete(operation);
  await supervisor.wait("effect-result-held", row => row.child?.pid === held.child?.pid);
  const actualBeforeCancel = await liveFile(supervisor, operation);
  expectEffect(actualBeforeCancel, operation);
  await save("rst03a-before-cancel", { actualBeforeCancel, sha256: createHash("sha256").update(actualBeforeCancel).digest("hex"), initialIdentity, events: supervisor.events });
  try {
    const chosen = await worker.cancel(operation);
    assert.equal(chosen.result, CANCELLED);
    assert.deepEqual(processIdentity(held.child.pid), initialIdentity);
    await supervisor.releaseEffectResult(operation);
    const actualResult = await supervisor.wait("effect-result", row => row.child?.pid === held.child?.pid);
    assert.equal(actualResult.result, SUCCESS);
    const exited = await supervisor.observeEffectExit(operation);
    await supervisor.observeEffectClose(operation);
    assert.equal(exited.child.code, 0);
    assert.equal(exited.child.signal, null);
    assert.equal(processIdentity(held.child.pid), undefined);
    await worker.settle();
    assert.equal((await worker.query(operation))?.result, CANCELLED);
    assert.equal(await supervisor.effectArtifact(operation), actualBeforeCancel);
    await worker.stop();
    const fresh = await supervisor.start();
    await fresh.settle();
    assert.equal((await fresh.query(operation))?.result, CANCELLED);
    assert.equal((await fresh.submit(operation)).created, false);
    assert.equal(supervisor.counts().launches, 1);
    await fresh.stop();
    noUnexpected(supervisor);
    await save("rst03a-final", { events: supervisor.events, canonical: await supervisor.store.read(), counts: supervisor.counts(), effectBytes: actualBeforeCancel, exit: exited });
  } finally { await supervisor.releaseEffectResult(operation); }
});

test("RST03B: raw success and disconnected IPC retain real live custody until planned exact-handle force retirement", bounded, async () => {
  await using supervisor = await Supervisor.create("record-only");
  supervisor.setNextEffectMode("result-without-exit");
  const operation = makeSubmission();
  const worker = await supervisor.start();
  await worker.submit(operation);
  const held = await supervisor.wait("effect-held");
  assert.ok(held.child);
  const initialIdentity = processIdentity(held.child.pid);
  assert.ok(initialIdentity);
  await supervisor.wait("child-recorded", row => row.workerPid === worker.pid);
  await supervisor.complete(operation);
  const result = await supervisor.wait("effect-result", row => row.child?.pid === held.child?.pid);
  await supervisor.wait("effect-disconnect", row => row.child?.pid === held.child?.pid);
  assert.equal(result.result, SUCCESS);
  assert.deepEqual(processIdentity(held.child.pid), initialIdentity);
  const actualFile = await liveFile(supervisor, operation);
  expectEffect(actualFile, operation);
  let stopSettled = false;
  const stopping = worker.stop().then(() => { stopSettled = true; });
  await supervisor.wait("revoked", row => row.workerPid === worker.pid);
  await new Promise<void>(resolve => setTimeout(resolve, 200));
  assert.equal(stopSettled, false, "observation deadline is pending, not successful stop");
  assert.deepEqual(processIdentity(held.child.pid), initialIdentity);
  assert.deepEqual(supervisor.reservationIdentity(), { scope: operation.scope, id: operation.id });
  assert.equal(supervisor.counts().occupied, 1);
  await assert.rejects(supervisor.start(), { code: "fixture.writer.occupied" });
  assert.equal(supervisor.counts().launches, 1);
  await save("rst03b-live-after-deadline", { events: supervisor.events, counts: supervisor.counts(), reservation: supervisor.reservationIdentity(), initialIdentity, actualFile, stopSettled, deadlineMs: 200, invalidPrematureReleasePredicate: true });
  assert.equal(await supervisor.forceRetireEffect(operation), true);
  await stopping;
  const exited = await supervisor.observeEffectExit(operation);
  assert.equal(exited.child.code, null);
  assert.equal(exited.child.signal, "SIGKILL");
  assert.equal(processIdentity(held.child.pid), undefined);
  assert.equal(supervisor.counts().reserved, false);
  assert.equal(await supervisor.effectArtifact(operation), actualFile);
  const fresh = await supervisor.start();
  await fresh.settle();
  assert.equal((await fresh.query(operation))?.result, CANCELLED);
  assert.equal((await fresh.submit(operation)).created, false);
  assert.equal(supervisor.counts().launches, 1);
  await fresh.stop();
  noUnexpected(supervisor);
  await save("rst03b-final", { events: supervisor.events, counts: supervisor.counts(), canonical: await supervisor.store.read(), exit: exited, retirement: "planned exact-handle SIGKILL; no watchdog" });
});
