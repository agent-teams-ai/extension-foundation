# Plugin uncertainty campaign — owner brief, 2026-10-26

## Current request and authority

The owner explicitly authorizes a large, autonomous, multi-stage investigation of the plugin system BEFORE substantial implementation. Use many GPT-6.1 Sol xhigh researchers and independent critics, work in parallel when useful, plan unclear experiments first, have critics challenge their value/oracles before execution, and then execute realistic minimal examples. Avoid unnecessary tests and architectural scaffolding. Choose experiments that can change a concrete decision. Retain findings, failures, sources and reproducibility; commit/push meaningful checkpoints to existing Extension Foundation draft PR55 as work progresses. No production runtime/package release or unrelated PR merge is requested.

Full vision: a TypeScript-first modular platform with hundreds/thousands of modules and extensive user plugins; users customize through plugins without forking. Clean Architecture, SOLID, DRY, DDD where appropriate, Pluggable, clear ownership, author usability, reliability and maintainability. Prefer mature libraries and existing components. Another language/native component is considered for a named reliability/system/performance benefit, not automatically. New maintained code targeting JS runtimes must be ordinary strict .ts using the owning TS7.0.2+ baseline. No .mjs/.mts additions as a shortcut.

Owner has confirmed STATIC COMPOSITION + CONTROLLED RESTART. Downtime may be part of this baseline. Optional Temporal adapter can drive the SAME product-owned operation where qualified infrastructure/usefulness justify it. This does not make ordinary module calls workflows or reopen Orchestrator's application workflow engine choice. Do not silently replace accepted ADRs. For genuine unresolved decision conflict, retain clear alternatives with confidence/reliability/complexity /10 and separate new production/integration/test LOC, approximately x2 uncertainty. Ask root before any conflicting adoption, not for routine reversible research.

## Responsibility boundaries

GM owns inert declarations, dependency selection, graph compilation/construction and current resource semantics. EF owns neutral extension/artifact/trust/protocol requirements, conformance and package admission. Products own concrete extension points, effective grants, actual admission, canonical state, operation/recovery and lifecycle; existing execution custody owns physical processes. EF must not import/duplicate GM composition core. Do not build a new universal PluginManager, host, RPC framework, scheduler, second mutable authority or supervisor. Shared library design remains deliberate; a disposable experiment is not an approved package/contract. A local generation kernel candidate exists but was private; verify current public status if relevant.

## Current restored sources (read-only shared repositories)

Base: /workspace/scratch/f863b9d38368/plugin-spikes-2026-10-26
EF: repos/extension-foundation on docs/plugin-research-hot-reload-20261021, head84f43b9db68781474257f8dc0277b4d73de49ebf; main39c72bf3061dd6cf4aa4bd3c92f0c9b3f88a0bde.
GM main fresh b1866ac5328231b7fe1d63ed136e7a905a2facc1; progressed since previousb70ba393. Inspect current AGENTS/pins/contracts rather than assuming tooling unchanged.
Orchestrator main fresh94a480d004e8e6eaf79507feeae30428d372a3d3. ADR0114/0115 already select native PostgreSQL local+hosted and Fully Local V1 with embedded-postgres launcher via Local Supervisor adapter. Historical SQLite premise is superseded within stated scope; other authority/exact-value invariants remain.
PR90 still OPEN/UNMERGED, head0af892165a023a274302f89b47ba514ab2915e59. Owner-approved ADR0116 selects full native Temporal+PG for Fully Local. Do not say this is merged main. Its old native fixtures are also in retained evidence.

Primary research hub: repos/extension-foundation/docs/research/plugin-system-research-reference.md.
Current synthesis: docs/research/static-composition-and-controlled-restart-validation.md.
Open choices: docs/open-decisions/OD-003-module-runtime-and-public-spi-choices.md.
Read relevant AGENTS.md, docs-authoring skill and central engineering-quality-standard before changed files. Root already read central current policy; copy in evidence/ will be available. Root alone edits shared EF docs/branch and publishes.

## Frozen earlier evidence — NEVER modify

historical/20261025 contains the verified 416-file archive. Archive SHA256 e16e9cdb74bed1e83ec863b19beea8dd7bfe55567d42b36b35ea58ffd1c6de68. Start README.md and reports/. It has sources, locks, identities, primary links, native fixtures and failed attempts. Copy selected fixtures into YOUR experiment directory if needed; keep the original frozen. Do not install dependencies in historical/.

Known executed facts, not assumptions:
- Public GM0.7/0.7, resources0.2.1, conformance0.5 consumer:60 unchanged assertions pass,6 added positives.
- S07: 2 required admission-during-stop rejection assertions RED; critic independently reproduced one. Hold real launch ACK, initiate stop, observe revoke+effect-child exit, submit new distinct operation: created=true and durable pending. record-only retains pending; restart-pending resumes toSUCCESS. This is missing ingress sealing in recovery fixture, NOT proven loss or GM composition defect. A future corrected fixture needs rejected candidate ABSENCE/no-reservation oracle, not merely the old followthrough that assumes the bad record exists.
- 12 finite fresh-processA/B cycles and24 work-free recovery-worker cycles (Supervisor remainedlive). Known old PIDs absent, parentFD plateau21→22. No full descendant/RSS/reference bound.
- One real accepted-work natural-completion scenario: effect child exit precedes old worker exit/new readiness, duplicate readback no secondlaunch.
- PG18.4 via embedded-postgres18.4.0-beta.17 researchpayload:2 original feature tests+5 added crash/authority checks pass; actual postmasterSIGKILL during uncommitted tx, samecluster/systemID recovery, committedfacts/outbox survive, uncommitted absent,idempotentretry. Payload lacks pg_dump/pg_restore/pg_controldata: BACKUP/RESTORE UNQUALIFIED. Synthetic lost-COMMIT proxy distinctfromactualcrash. Process crash is not powerloss. Wrapper version not production-approvedpin.
- Full native Temporal1.32.1 SDK1.24 PG18.4:11 original scenarios+7 adaptergroups pass;10 finite GMcomposition identities independentlychecked. Real WorkerSIGKILL after receiverCOMMIT beforeACK ->2deliveries,1canonicalreceipt/effect. Real ActivitySIGSTOP,epoch1→2,resume ->0staleSQLreceipts/effects BUT1finite repeatable preflight construction BEFORE fence. SQL fencing does not fence arbitrary earlier plugin effects. Finite child construction is not long-lived Host cutover. FullService+Workerkill timer/historyrecovered. OrdinaryGMcalls worked withWorkers/serviceabsent. Temporal own source strict but skipLibCheck:true; othertracksfalse. Not every Workflow.result had an outerwallclockcap; improve research harness where relevant rather thanclaimuniversalbound.
- Root actualChrome156/Node26 same strict program:5groupspass exactdiagnostics,digests/factories,independentfrozeninstall. No hostileisolation/deepfreeze/browser-growthproof.
- Currentdescriptor-union growthrecipe N100/500/1000 each8stagespass underunchangedcaps. N1000=7003files/2001attempts/1002000factories,277.57s aggregate. Already upstream-qualifiedOct23; not compilerbugfix or1000activeworkers.
- Prior pool experiments (older archive in EF evidence): fulfilled close/terminate can disagree with real accepted-task completion/process exit. Do not equate promise,hook,stats,abort,settlement andphysicalabsence.
- Prior repo gates sourcesunchanged190files. Monolithic check failed from too-longChromeTMPDIR, corrected fullqualification229/229+packageartifactpass. Use SHORT task-owned/tmp paths. Docs checks have original120s perCLIchild. Do not weaken gates.
- OldEF pinnedidentitycontroller fails rawnameИлия despitecurrentcentralaliaspolicy. Root may use authenticatedGit ifavailable,otherwiseconnectorpushes; do not changeCIidentitypolicy togreen thisresearch.

## Experiment contract

For each proposed experiment write: ID; concrete uncertain question; decision that changes with result; existing evidence/source identities; realistic boundary/components; what is synthetic/test-owned; smallest scenarios including meaningful negative control; independent observable oracle; expected falsifier; bounded deadline/resources; cleanup; exact artifact retention; stop rule. Reuse existing fixtures/official examples before newcode. No vague "testallfailures", sleeps as evidence, synthetic state machine provingitself, or greenmock replacing unavailablecomponent.

Plan criticism happens BEFORE implementation. Phase1 assignment is plans/research only until root sends execution go. Cite primary official docs/source/papers, verify current facts online; preserve retrieval date/exactversion and distinguish inferredrecommendation fromsourcefact, reportedtestfromexecutedtest. Research industry only to resolve the named choice, not endlesstechnologylists.

No production implementation, acceptedADR modifications, workflow-policy changes, package releases, or edits to others' directories. Task-owned childprocesses,ports,tempdirs,databases only. Neverkill processesbybroadpattern ordelete otheragents' files.

Resource note: sharedhost disknearlyfull andotheragentsuse/tmp. Coordinate download/install plans withroot. Do not delete unrelateddata. Reuse one root-managedtoolchain andread-onlynativebinaries whenqualified; keepDBs/outputbounded andclean task-owneddata afterevidence. Node24.22.1 system isavailable; EF supports24.21+ butearlierexperimentsused26.11.1. Followexactowningprofileandreportactualversions. Rootwillarrangecommon Node26/TS7 toolchain ifneeded.

## Working ownership

Each agent owns only plans/<track>.md, reports/<track>.md and experiments/<track>/ after execution approval. Sharedbrief and frozen evidence read-only. Root owns repository mutations, sourcefreshness snapshots, checkpoints/pushes and final integration. Give root an early concise plan and missingtool/resources signal. Preserve failedattempts and criticdispositions in owningreport. Do not continue optional tests after the selected uncertainty is resolved.

