# Independent hosted artifact review

Observed 2026-11-05. Read-only review of retained hosted metadata, original ZIPs, collection receipts, execution archives, decoded files, command logs, package archives and child outputs. No tests, compilers or package commands were executed. This review follows the earlier plan/execution reviews and retains their scope.

## Disposition

**PASS for the four executed public-package integration lanes on exact EF commit `11fa2e2450a8aba62823544fc3129318918e9696`, run `42099097668`, attempt 1.** All four retained jobs report success, all reviewed inputs match the exact 29-member EF ledger, and all four executions contain the actual ten named checks plus their enclosing Node test: **11 passed, zero failed, cancelled, skipped or todo** in each lane.

No required fix was identified within this scope. Preserve each original ZIP, its GitHub digest metadata, inner archive/collection pair, decoded source/output/logs and this review. Independent review is not a fifth execution.

## Exact executed environments

| Lane | Job ID | Runner image / architecture | Actual Node | Compiler / manager | Actual checks |
| --- | --- | --- | --- | --- | --- |
| linux-node24 | `127496867862` | Ubuntu24.04, x64 | `24.21.0` | TS`7.0.2`, pnpm`11.25.0` | 10 named + parent; 11/11 |
| linux-node26 | `127496868199` | Ubuntu24.04, x64 | `26.11.1` | TS`7.0.2`, pnpm`11.25.0` | 10 named + parent; 11/11 |
| macos-node26 | `127496868405` | macOS15 ARM64 | `26.11.1` | TS`7.0.2`, pnpm`11.25.0` | 10 named + parent; 11/11 |
| windows-node26 | `127496868163` | Windows2022, x64 | `26.11.1` | TS`7.0.2`, pnpm`11.25.0` | 10 named + parent; 11/11 |

OS/architecture is supported by the collection's runner facts and actual setup-node acquisition in each job log, not inferred solely from a matrix label. macOS's actual image is `macos-15-arm64`, and its Node archive is darwin-arm64. Other Node archives are linux-x64 or win32-x64. The test receipts separately report `linux`, `darwin` or `win32` and the actual Node version. Architecture is a runner/setup observation; the test receipt itself does not contain `process.arch`.

The retained output is Node's spec-style reporter, not a raw TAP serialization. Its actual summary counts and each named check are visible; use “11 passed” rather than claiming an additional TAP artifact.

## Input and artifact custody checks performed by this reviewer

The current EF input ledger is `docs/research/evidence/packed-consumer-e2e-20261105-inputs.json`. Its source archive is 105,046 bytes, SHA-256 `61fc7aa6b921ce9e68ea8c52165aa08ca6f0f06efdae114e3a23bf779cbbd500`, with exactly 29 members.

For **each** lane I checked all 29 decoded input files against both ledger byte lengths and SHA-256: **29/29 match**. This includes the reviewed runner (SHA-256 `91f4e5dd2fe94a88231105ee40ae125c8cc5220a0c8eb1d0807c095a8bab8e82`), unchanged A source/package inputs, consumer, independent B/H fixtures, strict configs/lock and exact GM0.5 archives. No OS-specific source substitution is hidden behind the shared input claim.

For **each** lane, I also independently checked:

- SHA-256 of `original.zip` equals that artifact's digest in retained GitHub metadata.
- The ZIP contains exactly `collection.json` and `execution.tar.gz`; both members equal the retained standalone files.
- Inner execution archive SHA-256 equals `collection.json`.
- All **130 regular execution archive members** equal their decoded retained files. No `node_modules` member is present, as intended.
- Collection facts bind the exact commit, run ID and attempt; their pre-collection status is success. The retained jobs independently report successful completion on that same head.

| Lane | GitHub artifact ID | Original ZIP SHA-256 | Inner execution archive SHA-256 |
| --- | --- | --- | --- |
| linux-node24 | `13448014335` | `084db7764983e5f34e0ff161cb1ad01f9138cbf9b5980173a51ce03b1cd8a2ea` | `0b35d1b5dbf9fa700549c115e480fff4903eb7beac8219855bfb2035b8057ab5` |
| linux-node26 | `13447999196` | `3e3e614a22abefd7072cd1efc63a6ecd82f936db14ed78b05ae53c63a316e81f` | `110e2dd626984ba2ee8817055921177e2e9c973c5235b5c725d60c35af6acb41` |
| macos-node26 | `13447764426` | `f7c53e244beb36fc5265ed584ed0750cb9324936e4269e371438ff91cccc0f06` | `4000d03c4a56240c89c650030627553111abe1d1f20a37b8635771739f7f91a6` |
| windows-node26 | `13448992127` | `4ab059a176bf1091ffe054b4b092e6c659bd0e0fc202fdd91df46876e13ba30f` | `7414262d2b582c3ec6e22b18eb3e6ed20b788e8b7d732e3796de1e8312217ceb` |

These establish correspondence to the supplied authenticated download metadata and retained files. I did not independently reconnect to GitHub or inspect a still-running remote filesystem.

## Actual execution and package observations

Every lane contains exactly **27 recorded subprocess commands**, with status0, null signal and corresponding retained log. There are ten child invocations in the expected mode order. All three pack commands contain explicit `--config.ignore-scripts=true`; logs004/006/010 contain only pack JSON. The executed runner checks complete dist inventories before/after packing, so the earlier local prepack mistake is not repeated here. It uses the corrected full-body completion flag and verifies both copied consumer/composition JavaScript files.

For each lane's A/B/H package archive, I checked its actual hash against the runtime receipt. A has **20** regular package members; B and H have **4** each. Their emitted dist bytes equal the corresponding retained compiled output. Packed package JSON is reformatted relative to the build-directory input; semantic JSON equality holds. This is expected packing serialization, not exact manifest-byte identity to the prepack input.

For A, the complete packed member-path/hash map equals the runner's retained `aInstalledFiles` observation. The runner also executed equality assertions across baseline/extended/restored installed A and checked exact GM0.5 physical resolution, without changing the source. These are **remote execution assertions retained in the receipt and source**, not a new physical read of remote node_modules by this reviewer. The CI archive intentionally excludes node_modules. B/H have no independent retained installed-file inventory; their archive/compiled-output comparisons, lock/installation logs, actual imports and literal results are the available evidence. Do not describe them as a remotely re-read installed-byte proof.

A/H archives have different compressed hashes on some operating systems, but their entire unpacked regular-file content is byte-identical across all four lanes. B's packed manifest contains its run-specific A devDependency path, so its tarball identity differs per run. Do not collapse the four artifact identities into one claimed reproducible archive.

## Literal behavior and independent oracle

I compared the decoded child receipts with independently restated expected tagged values, without executing or importing fixture code. All four lanes agree on the complete checked results:

1. Baseline primary is `not-found`; delegated target is the exact baseline candidate.
2. Independently packed B/H changes the primary to the exact B candidate: host `fixture-host-b`, component version `2.0.0-b`, protocol3, boot generation7, expected freshness/evidence and `authenticatedHandshakeRequired: true`. Delegated behavior is unchanged.
3. Reversing enumeration preserves the actual plan/digest and results.
4. Both ambiguous permutations report the expected unresolved-binding refusal, with no factories, reads or B/H evaluation and no runtime result.
5. Source failure becomes exact `unavailable/source-failure`; foreign target becomes `rejected/target-mismatch`; fixed now equal to `validUntil` becomes `expired`.
6. In the genuinely held async source row, fresh B returns while old remains pending; old and oldAgain retain baseline. B call count remains1 across oldAgain, and baseline read count is2.
7. A fresh consumer without B restores the exact baseline/delegated values.

The parent literal oracle is separate from B/H identity constants and actual GM output. The selected candidate comes from the unchanged A use case using the constructed B provider, not a parallel direct B call. The marker's positive selected run supports its negative no-evaluation interpretation. No false-green missing/no-op runner, cancelled scenario or skipped check was found.

## Limits to preserve in durable reporting

This qualifies the bounded **public-package integration** on the four observed Node/OS/architecture combinations. It does not turn fixture-owned fallback/GM composition into a deployed product consumer or external plugin Host. Removing B and starting a clean consumer is fresh-process removal/recomposition, not production admission sealing, drain or controlled-restart qualification.

Archive hashes, installed A observations and successful child exits do not establish executable byte custody, signing/OCI admission, hostile isolation or cleanup of arbitrary descendants. No mutation-between-verify-and-load enforcement, overload/fairness, repeated failed setup/cleanup, observer-resurrection or upgrade migration is newly exercised here. No such extra claim is needed for this result to be useful. The prior local failure and prepack correction remain separate historical evidence; this four-lane review does not rewrite them.

The reviewed cross-platform result is complete within that boundary. Stop optional reruns and preserve the exact evidence chain.
