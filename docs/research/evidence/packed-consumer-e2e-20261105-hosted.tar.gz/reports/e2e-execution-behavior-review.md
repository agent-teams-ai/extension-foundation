# Independent execution and behavior review

Date: 2026-11-05. Decision: **behavioral design approved for the stated public-package integration scope; revised driver execution pending**. One receipt-truthfulness defect was found in the executed driver and corrected by root during review. This reviewer inspected that correction but did not execute it. No root source was edited and no build, install or test was rerun by this reviewer.

## Inputs and executed evidence

Read the task brief and retained Engineering Quality Standard, the approved plan/second critique, `experiment/src/e2e.test.ts`, both `consumer/*.ts` files, B/H source and manifests, fixture implementation note, compiler configuration/provenance, `validation/experiment-run-{1,2}.log`, and `.runs/run-Wto5ej/receipt.json`. References below are relative to the task root. Current driver line references include root's review fix; the exact previously executed driver is retained as `validation/pre-review-inputs/e2e.test.ts`.

`experiment-run-2.log` reports **11 tests passed, zero failures/cancellations/skips/todos**: one outer test plus ten named subtests. The receipt contains ten scenario entries and ten fresh child invocations, 27 command records with exit status 0 and no terminating signal, Linux, Node **24.22.1**, TypeScript **7.0.2**, pnpm **11.25.0**. These are observed identities, not Node26 or cross-OS qualification. The earlier run's unpublished-helper registry 404 is retained as an actual failure and is not counted as a pass.

## Findings requiring action

### B1 — Receipt could say passed after a final outer-body failure

**Blocking for the maintained driver's receipt reliability; statically corrected, revised execution pending.**

The executed driver assigned receipt status solely from `passed.length === 10` in its `finally` block (`validation/pre-review-inputs/e2e.test.ts:219–225`). After the tenth scenario succeeds, the final package inventory can still throw. That would fail the outer TAP test but write a receipt labeled `passed`. This is a narrow real false-green path; it does not invalidate `run-Wto5ej`, whose outer TAP result also passed and whose package evidence is present.

Root preserved the original driver and introduced `completed = false`, setting it true only after evidence collection and the final scenario-count assertion. Current `experiment/src/e2e.test.ts:221–228` uses that flag. The diff is the appropriate small correction; no scenario or assertion was weakened. It needs execution under the revised input before the revised harness is called passed. The existing successful receipt remains evidence for its original exact input.

No further blocking behavior defect was found in the selected scope.

## Behavior findings and evidence limits

| Concern | Source and observed evidence | Review conclusion |
| --- | --- | --- |
| Actual GM resolver | `consumer/composition.ts:8–22,37–66` declares one public contract and three entries, calls public `assemblyFor().prepare`, and explicitly binds discovery to B. `consumer/consumer.ts:43–48` runs only a prepared result. | This is real retained GM0.5 composition, not a hand-written provider selector. B's dependency is the fixture baseline; discovery consumes B. The retained successful plan records both bindings and baseline→B→discovery construction order. |
| Conflict before factories/evaluation | B is dynamically imported only inside the extension factory (`composition.ts:42–45`). B/H top-level evaluation flags are written in their own packed source. Driver `e2e.test.ts:186–196` asserts exact GM unresolved-binding cause, zero factories/reads, no results and both flags false for both ambiguous orders. | The two fresh refused children did not run any authored factory or evaluate B/H. This does not mean no JavaScript executed: A, GM, declarations and consumer code necessarily ran. It is not product admission or hostile-code isolation. |
| Module enumeration | `composition.ts:63–65` uses the normal tuple and its full reversal. Driver `e2e.test.ts:181–184` compares complete preparation, plan/digest, results, factories and reads. Both ambiguous tuples are also checked. | A real reversal is exercised; outcome is not secretly selected from tuple position. This is **one reversed enumeration control**, not exhaustive arbitrary permutations or a new proof of all GM semantics. |
| Actual unchanged A invocation | `composition.ts:50–57` constructs imported A with the GM-injected source. `consumer.ts:78–80` invokes the returned actual `discover`; it does not serialize a parallel direct B result. Driver literals `e2e.test.ts:34–51,167–179` are independent of B/H. | The useful candidate and delegated result go through A. H's identity/version reaches the candidate; full result equality includes protocol, freshness, target and authenticated-handshake requirement. A's policy was not reimplemented in the fixture. |
| Error and validation controls | `consumer.ts:31–40` awaits selected B then injects an exception or a well-formed foreign target; expiry changes only the injected clock. Driver `e2e.test.ts:198–207` compares exact terminal objects and checks absence of the exception sentinel. | Source-failure normalization/redaction, target rejection and exact exclusive expiry are enforced by actual A after selected B is used. These are runtime-negative wrappers owned by the TEST consumer, not new switches in B. Other observation fields remain valid. |
| Pending old/new instances | `consumer.ts:54–74` waits for old source entry, holds its promise, obtains fresh B's result, checks old is still pending, releases old, then invokes old again. Driver `e2e.test.ts:209–214` expects B candidate, two original-baseline results and unchanged B read count across old-again. | This decisively tests per-instance dependencies and finite concurrent independence without timing sleeps. It does not retire old, cancel it, drain a Host, mutate shared source state or prove immutable source objects. |
| Removal/restoration | Driver creates three separate consumer installations (`e2e.test.ts:125–149`), requires B absent from baseline/restored roots (`162–163`), compares A inventories, then starts a fresh restored child (`215–220`). Receipt PIDs are distinct and every child command completes successfully. | Fresh A-only reconstruction restores independent literal baseline outcomes. This is package absence plus a fresh test-process lifetime, stronger than deselection in an old import cache. It is not uninstalling a plugin from a running application or qualifying a product-managed restart protocol. |

The existing source tests already owned the three negative invariants. The new value is their preservation across installed public A/B/H boundaries and actual selected construction. The optional compatibility matrix and helper mutation race were deliberately omitted, consistent with the bounded plan. No C package, competing composition owner, lifecycle kernel, loader, supervisor, product API or A source edit was introduced.

## Nonblocking improvements and qualification limits

1. **Both compiled consumer files should be asserted identical.** The executed driver copied `consumer.js` and `composition.js` into every consumer but asserted only `consumer.js` equality. I independently read and hashed the retained files: both files were identical across all three roots; composition hash was `b559caeaa06378c31b8c8c2c614f4ff9b340ca522eb0b0632bfa0153b6365008`. Root added the symmetric assertion at current `e2e.test.ts:159–160`. This strengthens the gate without changing the observed original behavior; its new execution is pending.
2. **The environment is inherited, not allowlisted.** `e2e.test.ts:62–63` spreads `process.env` and overrides a few entries. The preimplementation plan proposed an allowlist. For this controlled trusted fixture it is not a blocker, but do not call the experiment hermetic or claim isolation from inherited Node/package-manager configuration. There are no hostile-plugin or credential-safety claims supported here. No generic sandbox layer should be added for this report.
3. **Portability was inspected, not executed.** The driver uses Node path/file APIs, `process.execPath`, a JavaScript pnpm entrypoint, and slash normalization for local package specifications; it does not rely on shell command quoting or POSIX executable shims. I found no concrete Windows/macOS source blocker in these selected paths. Only Linux/Node24 ran. Windows, macOS, Node26, package-manager-path variations and package-store-layout variants remain unqualified. The explicit pnpm11.25 version and pnpm physical-layout assertion are intentionally narrow supported fixture inputs, not a general installer API.
4. **Child completion scope stays narrow.** `spawnSync` returns a completed command and the driver rejects errors/nonzero exit; the actual receipts show normal termination. This suffices for these trusted children with no authored descendants. It does not establish arbitrary descendant cleanup, custody, forced-timeout cleanup, readiness, admission sealing or any physical execution guarantee of the real product.

## Final scoped assessment

The executed original input supplies credible **public-package integration E2E** evidence: real A operation, independently compiled/packed B and helper, a real GM ambiguity/refusal/explicit binding, preserved A validation, one order reversal, old/new instance independence and fresh A-only restoration. The two small driver revisions address receipt truthfulness and symmetric file identity; their input is **pending execution** at this review's completion.

This advances the user's no-fork extensibility investigation without manufacturing a plugin Host. The accepted direction of static composition plus managed restart remains intact; the experiment supplies only a fresh test-process reconstruction example. A real application consumer, supported public plugin Host/SPI, product admission/grants, artifact-to-executor handoff, managed readiness/drain/restart, migration and UI workflow remain absent from this slice and must not be labeled qualified by it.

## Final disposition after corrected execution

**APPROVED for the bounded public-package integration behavior scope.** This disposition supersedes the earlier pending-execution statements while preserving their input history.

Read the corrected current driver, `validation/experiment-run-3.log` and `.runs/run-3Tudbb/receipt.json` after root completed execution. The corrected run reports **11/11 TAP tests passed**, with zero failures, cancellations, skips or todos; its receipt contains all ten named scenarios, ten fresh children and 27 commands with status 0 and no terminating signal. Runtime remains Linux, Node24.22.1, TS7.0.2 and pnpm11.25.0. Read-only comparison found the children's preparation, factories, evaluation flags, results and behavioral observations identical to the previously reviewed successful run.

The executed current driver now sets receipt success only after final evidence collection and count checks (`experiment/src/e2e.test.ts:223–230`) and asserts both compiled consumer files equal across roots (`161–162`). B1 is closed for this reviewed input; no behavioral blocker remains.

Root separately discovered that the older environment/config approach had not suppressed A's pnpm11 prepack hook. The current pack command explicitly passes `--config.ignore-scripts=true` and compares `dist` inventories before and after packing (`92–95`); the new receipt records that actual flag for A/H/B, and A's pack log begins with package JSON rather than prepack output. The earlier run must not be described as proving suppressed prepack or a single isolated compiler invocation. Exact package/toolchain qualification remains with the artifact review; this final disposition concerns the corrected behavioral execution and does not silently promote old packaging evidence.

No tests were rerun by this reviewer. Hosted Windows/macOS/Node26 lanes remain **pending/unqualified**, as do the product Host/SPI, custody, UI and managed-restart responsibilities already excluded above. The inherited-environment and single-reversal limits remain unchanged.

## Reporter terminology clarification — 2026-11-05

The retained local logs contain Node's **spec-style reporter output and Node test totals**, not raw TAP serialization. Historical references to “TAP” in this dated review mean those Node test totals; no raw TAP artifact is claimed. Counts and behavioral conclusions are unchanged. Subsequent hosted qualification is recorded separately in `e2e-hosted-behavior-review.md`.
