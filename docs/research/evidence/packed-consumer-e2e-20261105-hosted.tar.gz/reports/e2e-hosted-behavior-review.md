# Independent hosted behavior and cross-platform receipt review

Date: 2026-11-05. **Final disposition: PASS for the bounded public-package integration E2E on the four executed lanes below.** No blocking discrepancy was found. This is a read-only review of actual hosted outputs, not another execution or additional test pass. No code was edited and no install, compiler or test was rerun by this reviewer.

## Exact hosted identity

Read `hosted/run.json`, `jobs.json`, `artifacts.json`, every lane's `collection.json`, relevant actual `job.log` setup/execution output, every extracted `e2e.log`, and the one `.runs/*/receipt.json` retained in each extracted archive. Compared with the corrected local `.runs/run-3Tudbb/receipt.json` and the local maintained TypeScript sources previously reviewed.

- Repository: `agent-teams-ai/extension-foundation`.
- Workflow: `Packed consumer E2E research`, `.github/workflows/packed-consumer-e2e-research.yml`.
- Run: **42099097668**, attempt **1**, push event, completed/success.
- Exact input commit: **`11fa2e2450a8aba62823544fc3129318918e9696`**.
- Run URL: <https://github.com/agent-teams-ai/extension-foundation/actions/runs/42099097668>.

Run metadata, all four job records, all four artifact workflow-run identities and each collection record agree on that commit/run/attempt. All jobs and their execution/collection steps completed successfully. Each downloaded execution archive's SHA-256 matches its collection record. This review does not treat workflow green alone as behavior evidence; the actual Node test totals in the spec-style reporter output and child receipts below were inspected independently.

## Actual platform and count observations

Architecture comes from each collection record **and** setup logs showing the downloaded Node architecture. It is not inferred merely from a generic job name or runner label. All four lanes report TypeScript **7.0.2** and pnpm **11.25.0**.

| Lane | Job ID | Actual image / architecture | Actual Node / receipt platform | Receipt directory | Node test totals: passed / failed / cancelled / skipped / todo | Named checks / children / successful commands |
| --- | ---: | --- | --- | --- | --- | --- |
| linux-node24 | 127496867862 | ubuntu-24.04 / x64 | v24.21.0 / linux | `.runs/run-rmK1NN` | 11 / 0 / 0 / 0 / 0 | 10 / 10 / 27 |
| linux-node26 | 127496868199 | ubuntu-24.04 / x64 | v26.11.1 / linux | `.runs/run-ijk7I1` | 11 / 0 / 0 / 0 / 0 | 10 / 10 / 27 |
| macos-node26 | 127496868405 | macos-15-arm64 / ARM64 | v26.11.1 / darwin | `.runs/run-m6Wj2v` | 11 / 0 / 0 / 0 / 0 | 10 / 10 / 27 |
| windows-node26 | 127496868163 | windows-2022 / x64 | v26.11.1 / win32 | `.runs/run-qmFT27` | 11 / 0 / 0 / 0 / 0 | 10 / 10 / 27 |

Receipt directories in this table are relative to `hosted/<lane>/extracted/`. Each lane contains exactly one run receipt, labels its status `passed`, lists the same ten unique check identities as the corrected local run, and records 27 command exits with status **0**, signal **null**. Child PIDs are distinct within each lane. No missing, duplicated, skipped or cancelled named check was found.

**Count interpretation:** each set of Node test totals counts one outer test plus its ten named subtests. Across the four hosted lanes there are **44 Node-reported passing tests representing 40 executions of the same ten named checks**. There are **40 fresh child invocations** and **108 successful recorded commands**. These are repetitions across platform profiles, not 44 different behavioral guarantees, 40 different scenario types or 108 tests. The child sequence has nine distinct mode labels because `baseline` runs twice in different installations: initial and restored.

The executed named checks are:

1. Isolated strict builds and exact installed package identities.
2. Baseline invokes discovery and preserves delegated outcome.
3. Independently packed B and H change A result and preserve delegation.
4. Enumeration reversal preserves actual selected plan digest and result.
5. Real GM ambiguity rejects before all factories and executable B or H.
6. Installed A preserves source-failure through selected B.
7. Installed A preserves target-mismatch through selected B.
8. Installed A preserves expiry through selected B.
9. Old pending source and fresh B instance retain independent bindings.
10. Fresh consumer without B restores literal baseline with unchanged A.

## Cross-lane semantic comparison

Compared every child receipt in sequence with corrected local run `run-3Tudbb`, removing **only** `pid` and `consumerRoot`. The remaining entire payloads match exactly for all four hosted lanes: `mode`, `preparation` including plan/digest or rejection cause, `factories`, `evaluations`, `results`, and `observations`. No target, result, clock, capability, exception, read count, factory order, candidate list or protocol field was normalized away. All four hosted lanes are therefore also pairwise equal on these fields.

This confirms the same observed behavior on all selected profiles:

- Explicit discovery-to-B binding produces the actual A candidate whose host/version values originate in independently packed H; fallback delegation preserves the independent baseline result.
- Normal and reversed module tuples have identical actual preparation, plan digest and outcomes. Both ambiguous tuples return the exact real GM unresolved-binding record, with the same two sorted candidates and **zero** factory calls, source reads or B/H evaluation flags.
- Source exception becomes the exact redacted `unavailable/source-failure`; a well-formed foreign target becomes exact `rejected/target-mismatch`; fixed `now == validUntil` becomes exact `expired`.
- The new B-bound instance returns its candidate while the old source remains pending. Releasing old returns baseline; invoking old again retains baseline, and B reads stay at one.
- Fresh A-only installation returns the original literal missing/delegated outcomes with no B/H evaluation. This is a separate child lifetime, not reuse of an old module cache.

The five maintained TypeScript inputs—driver, composition, child consumer, B and H—are byte-equal across every hosted extraction and the reviewed current local sources. The corrected completion-flag receipt logic, symmetric consumer/composition file checks, explicit pnpm pack script-suppression flag and before/after `dist` check are therefore present in the actual hosted input. The behavioral review's earlier pending-hosted-lane status is closed **for these exact profiles and this exact input**. Artifact identity and compiler-closure details remain separately scoped to the artifact review; matching behavior does not itself establish artifact custody or provenance.

## Remaining limits and final judgment

No behavior blocker or platform-specific result difference was found. The matrix now provides actual Windows x64, macOS ARM64 and Linux x64 evidence for this static public-package integration; it is no longer merely a portable-looking source plan. It does not cover macOS Intel, Windows ARM, Linux ARM, other OS releases, all supported Node/package-manager versions, arbitrary installations, or performance/scale guarantees.

The experiment still exercises **one complete enumeration reversal**, not all possible orderings or an exhaustive proof of GM semantics. The environment remains inherited and trusted; equality across these runners does not establish hermetic execution or hostile-plugin isolation. Successful normal completion of the authored child processes does not prove arbitrary descendant cleanup or timeout recovery.

The final qualified statement is: **the unchanged real Host Discovery package accepts the independently packed B/H adapter through its public contract; real retained GM selects or rejects that composition predictably in the tested order control; A preserves the selected validation and instance-binding behaviors; and fresh A-only test-process reconstruction restores the baseline, identically across the four hosted profiles.**

This does not qualify a production plugin Host/SPI, UI customization, artifact verification-to-execution custody, admission sealing, product readiness/drain, state migration or a real managed restart implementation. Static composition plus managed restart remains the accepted product direction; these tests provide a bounded package integration and reconstruction observation without manufacturing a new runtime, loader or supervisor.

## Reporter terminology clarification — 2026-11-05

The retained `e2e.log` files contain Node's **spec-style reporter output**, including its test totals; they are not raw TAP serialization. Earlier review wording that called these summaries or records “TAP” was imprecise. The table and count interpretation above now use **Node test totals**. All counts, child-receipt comparisons and the scoped PASS disposition are unchanged. No raw TAP artifact is claimed, and no execution was rerun for this clarification.
