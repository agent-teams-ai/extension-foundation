# Packed consumer E2E — completed hosted evidence

Run [42099097668](https://github.com/agent-teams-ai/extension-foundation/actions/runs/42099097668)
completed successfully on 2026-11-05 at exact commit
`11fa2e2450a8aba62823544fc3129318918e9696`. The four jobs execute one fixed,
reviewed public-package integration experiment. They do not qualify a product
plugin Host, physical custody, hostile isolation or controlled restart.

## Actual matrix

| Lane | Test Node | Runtime / architecture | Named checks | Tests including parent | Fail / cancel / skip |
| --- | --- | --- | --- | --- | --- |
| linux-node24 | 24.21.0 | linux / x64 | 10 | 11 passed | 0 / 0 / 0 |
| linux-node26 | 26.11.1 | linux / x64 | 10 | 11 passed | 0 / 0 / 0 |
| macos-node26 | 26.11.1 | darwin / arm64 | 10 | 11 passed | 0 / 0 / 0 |
| windows-node26 | 26.11.1 | win32 / x64 | 10 | 11 passed | 0 / 0 / 0 |

Every lane records the same ten scenario definitions, ten scenario children and
27 subprocess commands with exit zero and no terminating signal. These are
forty executions of ten scenarios, not forty independent behavior designs or a
statistical production reliability measurement. Strict TypeScript7.0.2 and
pnpm11.25.0 were checked and used in every lane.

The original output uses Node's spec reporter. Its counts include the outer
test, but no separate raw TAP serialization was collected or claimed.

Linux image: ubuntu-24.04 20261101.360.1; macOS image: macos-15-arm64
20261028.0489.1; Windows image: windows-2022 20261101.353.1. Full setup logs
retain the exact image release and selected runtime acquisition. Action-host
Node and the selected test Node have distinct owners and identities.

## Contents and verification

- `hosted/run.json`, `jobs.json`, `artifacts.json`: original decoded GitHub
  metadata for the completed execution and original artifact identities.
- `hosted/verified-summary.json`: root's read-only cross-platform reconciliation.
- Each lane directory retains `original.zip` exactly as downloaded. It contains
  `collection.json` and `execution.tar.gz`; the latter contains all130regular
  retained experiment/build/run files, excluding dependency stores. Unpack it
  for full source/configuration, locks, generated output and command logs.
- Each lane also retains its decoded `collection.json`, full `job.log`, and
  selected extracted `install.log`, `e2e.log` and `.runs/.../receipt.json` for
  immediate review without unpacking nested archives.
- `hosted/workflow.yml`: exact executed temporary workflow. It is removed from
  active workflow discovery after this finite experiment; its input archive and
  source history remain. No continuous gate is implied.
- `reports/e2e-hosted-artifact-review.md` and
  `reports/e2e-hosted-behavior-review.md`: independent read-only result reviews.
- `reports/e2e-execution-behavior-review.md`: the local review with a later
  reporter-terminology clarification appended. Its earlier archived version
  remains unchanged in the separate local bundle.

Root verified each original ZIP against the SHA-256 returned by GitHub, each
inner tar against its collection receipt, and all29input files against the
committed input ledger. The actual test summaries, ten scenario results and all
27 command statuses were inspected independently of successful artifact upload.
No missing test receipt, skipped lane or expected-failure conversion counts as
success. See the independent reports for their additional exact comparisons.

| Original artifact | GitHub artifact ID | ZIP SHA-256 |
| --- | --- | --- |
| linux-node24 | 13448014335 | 084db7764983e5f34e0ff161cb1ad01f9138cbf9b5980173a51ce03b1cd8a2ea |
| linux-node26 | 13447999196 | 3e3e614a22abefd7072cd1efc63a6ecd82f936db14ed78b05ae53c63a316e81f |
| macos-node26 | 13447764426 | f7c53e244beb36fc5265ed584ed0750cb9324936e4269e371438ff91cccc0f06 |
| windows-node26 | 13448992127 | 4ab059a176bf1091ffe054b4b092e6c659bd0e0fc202fdd91df46876e13ba30f |

The input archive is separately committed as
`packed-consumer-e2e-20261105-inputs.tar.gz`, SHA-256
`61fc7aa6b921ce9e68ea8c52165aa08ca6f0f06efdae114e3a23bf779cbbd500`,
with29regular files and exact reproduction instructions. The separate local
bundle preserves the initial pnpm override failure, unintended prepack route,
critic-found receipt defect and corrected local run. None is rewritten by the
hosted success.

The test uses unchanged copied Orchestrator A source, separately authored B/H,
existing public GM0.5.0 composition and a TEST consumer. Baseline and restored
processes omit B; selected B changes an actual discovery result. The pending
old/new case proves independent instance binding, not process retirement or
production traffic handoff. Hash matching proves selected retained bytes and
observations, not future immutable artifact-to-executor custody.
