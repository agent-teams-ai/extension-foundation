# Plugin industry and scale review — 2026-11-05

## User objective and authorization

The user asks, in Russian, for the state of our industrial research and scaling readiness, especially increasingly modular agent products. Their ambition is an industry-leading ecosystem with hundreds/thousands of modules, many third-party plugins, very deep customization without product forks, maintainability and reliability. They explicitly request many researchers and independent critics, GPT-6.1 Sol xhigh, full-context sharing, primary-source evidence, preservation of useful and failed patterns for agents, and continuous commits/pushes to existing draft PRs. This is a research/status follow-up, not authorization to merge or build a speculative production runtime. Do not mistake aspiration for demonstrated superiority. Prefer critical mechanism comparisons to rankings or popularity.

## Binding decisions

- Clean Architecture, SOLID, DRY, Pluggable; Get Modular is the sole composition/module system. No parallel framework.
- Static composition and controlled restart accepted; downtime allowed. No blanket in-process hot reload promise.
- GM owns inert declarations, selection, graph validation/construction and resource semantics. Extension Foundation owns neutral contracts, trust/artifact/protocol/conformance research. Products own actual extension points, grants, admission, readiness, state/recovery and application semantics. Existing execution owner keeps physical process/resource custody.
- Optional Temporal adapter above the same product-owned replacement operation where qualified durable coordination pays off. Ordinary module calls stay ordinary. Separate application workflow choice must not be reopened by inference.
- Native PostgreSQL local and hosted; embedded-postgres approach behind existing supervisor adapter. Old SQLite interpretations were superseded. Do not change accepted ADRs, approved pins or public contracts implicitly.
- Preserve prior Rust keeper/init physical custody direction. Consider other languages only for demonstrated boundary benefits, not blanket Rust rewrite. No generic second PluginManager/Host/supervisor/migrator.
- Strict TS7.0.2+ .ts for maintained JS-runtime code; no .mts workaround. Source research is not implementation approval.
- Significant alternatives: confidence/reliability/complexity /10 plus separately scoped incremental production/integration/test LOC with approximately x2 uncertainty. Scores are judgments, not measured uptime. No invented precision.
- Current installation guidance may use @latest then exact save/lock; frozen historical evidence and approved pins stay fixed.

## Prior published evidence and its limits

EF draft PR55 is open/unmerged at 70f03d3d9e134780f27268339a6729a7305a2363 on docs/plugin-research-hot-reload-20261021, verified this turn. Its 20-case industrial research, OpenClaw pinned audit, 18 stable pattern/failure IDs, reusable-mechanism comparisons and multi-stage executed evidence are under docs/research. Existing draft GM PR210 holds latest recipe corrections. No merges requested.

- Previous current descriptor-union N100/N500/N1000 each passed eight capped stages. Historical N1000 includes 7003 files /2001 smoke attempts /1002000 factory calls, approximately71.34s cold compile and34.22s runtime. Verify raw published record before citing numbers. Not 1000 active agents, simultaneous workers, long-run load, hostile isolation or IDE SLO proof. Old Oct22 compiler blocker belongs to an older recipe; dated supersession preserves it.
- Admission during stop counterexample persists as raw red evidence. Small copied receiver fix uses monotonic admission seal in same ordering as acceptance; accepted earlier work preserves explicit recovery disposition. Actual product integration remains unqualified.
- Complete hashing does not hold mutable file paths fixed. Verify-then-replace and ESM helper-cache counterexamples demonstrated. Next useful seam is real product fixed-artifact custody using the existing substitution falsifier.
- Cancellation does not undo external effects; result/disconnect is not physical exit; retained failed attempt/cleanup debt matters. Worker/process availability observations do not establish hostile security or arbitrary-descendant custody.
- Native SR1 real PostgreSQL18.4 single-feature logical restore succeeded in CI40407349905 at b3c51fc. Exact role restore, runtime RLS, old-facts/outbox preservation, duplicate retry, new transaction, normal2cluster cleanup established only bounded feature flow. No full product backup/PITR/powerloss/installer qualification.
- Drizzle exactRC4 strictTS profile remains blocked by47vendor declaration diagnostics. Runtime migration contention/rollback not executed. No inference that newer versions fail or silent repin.
- All frozen archives durable in EFPR55. Final Oct26 code/docs CI passed, identity oldrawauthor alias check failed separately; do not bypass policies.

## This round

Independently review (1) current agent plugin products, (2) mature plugin ecosystems/runtime scaling, (3) our actual published research and current evidence. Root will synthesize and cross-criticize before documentation update. Use official docs/source/first-party issues/advisories only for technical facts. Pin exact source revision when feasible; mark inspected source vs documented claim vs executed evidence vs inference vs untested proposal. A resolved issue is historical, not current defect. Do not presume OpenClaw is bad because user said it has antipatterns. Recognize improvements and fit-dependent tradeoffs.

Do not run competitor code, install dependencies, new scale tests, or alter repository implementation for this research follow-up. Save concise detailed reports in the sibling reports directory; root owns repository edits/publication. State precise coverage gaps rather than broad claims. Research date is 2026-11-05 (Europe/Kiev); verify changing facts now.
