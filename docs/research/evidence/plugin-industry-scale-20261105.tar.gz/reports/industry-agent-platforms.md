# Current agent extension products: mechanism review

Research date: 2026-11-05 UTC. Shared brief read in full before research. Scope: OpenClaw, OpenCode V2, Claude Code, Dify Plugin Daemon. No competitor code was installed or executed. No repository implementation was changed. This is an intermediate research report for the parent synthesis.

## Conclusions

1. There is useful convergence around explicit public extension surfaces, separate installation/activation/runtime states, attributed contributions, and versioned identities. The systems provide different kinds of extension, so a single “plugin architecture” score would obscure essential distinctions.
2. Our useful differentiator would be demonstrable composition, permissions, custody, recovery, and developer experience across a declared scale envelope. Counting manifests or catalogue entries alone cannot establish this.
3. Current OpenClaw deserves reassessment against its new documented design. The current docs describe immutable source generations and bounded recovery. The older pinned audit must remain dated evidence, not become a blanket statement about current OpenClaw.
4. OpenCode V2 documents a substantially different API from V1. Any earlier review of `@opencode-ai/plugin`, returned hook objects, or startup-only V1 behavior needs its version attached. V2 emphasizes domain transforms, registration ownership/disposal, and stable request snapshots.
5. Claude Code now documents in-process “mods” in addition to skills, external hooks, and MCP servers. The extension story is deeper than a directory of prompts. Its documentation also states the associated trust and permission effects explicitly.
6. Dify supplies a useful contrast: an invocation service spanning subprocess, debug, and serverless runtimes, rather than only code imported into an agent process. Recent fixed dispatch and environment bugs expose precise lessons, not grounds for a general security ranking.

These conclusions are judgments drawn from the sources below. No thousand-plugin performance or hostile-isolation claim was independently established for any product.

## Evidence labels and version discipline

- **D**: current official documented contract/design; implementation not independently verified here.
- **H**: official merged change/release describes a historical defect and its repair. This is not a current defect allegation.
- **S**: publicly inspected patch or commit metadata; not an independent executed result.
- **I**: our inference, design implication, or proposed experiment.
- **E**: independently executed evidence. There is no competitor E evidence in this report.

Latest stable release anchors observed by opening official release pages, rather than trusting search snippets:

| Product | Observed release | Release date shown | Exact repository anchor | Limitation |
|---|---|---|---|---|
| OpenClaw | `v2026.11.1` | Nov 5, 09:48 | `4ffdd2047d192dd65554de3c8c46c0e0197c6e2a` | Current web docs can be ahead of this tag. [R1] |
| OpenCode | `v2.2.5` | Oct 30, 23:17 | `9bbb8ce18c80f099e0e448775f59d965ead40a21` | V2 docs used; V1 remains separately published. [R2] |
| Claude Code | `v2.1.318` | Nov 4, 00:01 | `646b74189c735abbccf78ef5cb7ddd38a07a36eb` | Public repo anchor is changelog/release material, not an audit of the product implementation. [R3] |
| Dify Plugin Daemon | `0.6.15` | Nov 5, 09:21 | `14d714820d475075e15bd8dae605d61298382213` | A search result still called 0.6.12 latest; opening releases corrected it. [R4] |

## The extension types must stay distinct

| Type | What changes | Authority question | Composition question |
|---|---|---|---|
| Agent skill / command instructions | Model-visible procedures and task context | Which existing tools may the resulting agent use? Can the skill preapprove anything? | Selection, relevance, names, prompt budget, conflicts between instructions |
| MCP integration | Protocol access to remote services or local server processes | Server admission, credentials, individual tool grants, child process custody | Tool namespaces, catalogue refresh, connection sharing, result limits |
| Event / policy hook | Observe, modify, claim, or gate a product operation | Does this hook see conversations? Can it weaken approvals? Does failure block? | Ordered effects, merge semantics, deadlines, attribution |
| Native runtime module / mod | Direct product capabilities and sometimes UI replacement | What code runs with host/user authority? Which public boundaries exist? | Registration ownership, exclusive slots, disposal, stable call generations |
| Invocation package | Runtime reachable through a daemon's routing protocol | Tenant installation authority, package identity, reverse-call permissions | Prepared dispatch identity, runtime readiness, version transitions |

The table is our analytical taxonomy. Concrete product support is documented in the following sections.

## OpenClaw: native capabilities with declared activation and source generations

**D, architecture [O1].** Discovery/config validation reads manifests before executing native plugin code. Native runtime plugins execute in process; compatible bundles are normalized without importing native runtime code. The docs describe one immutable metadata snapshot and inventory reused by startup and runtime readers, with narrowed in-memory views. Managed installs bind captured source to revision, dependency-closure/content digests, platform/ABI and resolution options. Replacement retains unchanged instances and publishes the candidate registry as a generation. New work waits while affected admitted work drains; failed bounded draining can restore admission to the old generation. Cleanup failure does not authorize a replacement to acquire its resources. Bundled/host/SDK code updates can report `restartRequired`, while external captures can be refreshed. These are substantial documented mechanisms; this review did not prove their implementation or release coverage.

**D, activation [O2].** `activation` is planner metadata, separate from registration/lifecycle. Narrow provider, channel, command, route, harness, capability and config-path triggers reduce candidate loading; existing ownership metadata remains fallback. Explicit `onStartup` is recommended, and omission no longer implicitly startup-loads a manifested plugin. Manifestless configured files retain eager startup behavior. This makes metadata completeness an operational contract rather than an ornamental manifest.

**D, hook composition [O3, O4].** Typed hooks distinguish sequential modification, first-claim wins, gates that stop on block, concurrent observation, synchronous persistence, and attributed evaluators. Priorities order handlers but do not serialize observation effects. A rewrite generally does not mutate the event later handlers see. Registration grants for conversation/prompt access are specific gates, explicitly not a universal sandbox. Hook timeouts bound awaiting, not physical work or synchronous JavaScript; gate failures and observation failures have different policies. Some hooks are not emitted on every runtime path. These documented limits are valuable, not hidden defects.

**D, compatibility and instructions [O5, O6].** Plugin APIs are currently described as experimental with host pinning and compatibility testing advised. Plugin skills merge below bundled, managed, agent, and workspace skills. Thus native capability identity, instruction precedence, and API stability are separate concerns.

**I, lessons for GM/EF/products.** Borrow the ability to explain *why* a module was selected and which inventory/source generation it belongs to. Preserve our existing ownership boundaries: GM can describe selection/graph facts; EF can specify neutral artifact and conformance facts; the product must decide admission, capability priority, grants, readiness and recovery. Current OpenClaw provides a concrete research checklist for the already identified artifact-substitution seam, but copying its large reload system would conflict with our accepted static-composition/restart scope. Its documented mechanism should motivate a falsifier, not substitute for one.

## OpenCode V2: ordered domain transforms with owned registrations

**D, shape and migration [P1, P2].** One package can export server, TUI, GUI and RPC parts. V2 uses `Plugin.define({ id, setup(ctx) })`; V1 implementations do not run unchanged. A stable ID scopes storage and diagnostics. The migration guide explicitly distinguishes prompt admission from just-before-model context transformation, and warns that not every experimental V1 hook has an exact equivalent. This is an example of making migration costs visible rather than implying configuration normalization also ports behavior.

**D, current server contract [P3].** Setup can return cleanup. Hooks execute in plugin order. Domain transforms add/update/remove contributions; later valid tool definitions override the same effective name. Disposal is idempotent, removes the owned transform and replays remaining transforms, revealing previous definitions. Tool reload replays transforms without rerunning setup. Each model request captures executable tool definitions; later reload/disposal affects future snapshots. Closures over mutable plugin data remain mutable. Custom action permissions are asserted by plugin code. An explicit configured deny is final before permission evaluation hooks; hooks can modify allow/ask decisions. These are useful distinctions between a request snapshot, its closure state, and policy enforcement.

**D, discovery and reload [P4].** Applicable plugin arrays are applied in precedence order rather than replacing each other; ordered disables and re-enables are supported. Policy-related built-ins cannot be removed by repository configuration. Watched config changes reload, but unwatched local dependencies can still require restart. Exact npm versions and full Git hashes stay pinned. The desktop toggle disables only a plugin's UI part, while disabling its ID disables the whole plugin. A product must expose that distinction clearly.

**D, dispatch and connections [P5, P6].** MCP tools default to Code Mode, with a native-tool-list opt-out. `execute` can combine tool calls and reduce intermediate context; its runtime has no direct filesystem/import/timer access and supplies HTTP fetch. Nested built-in/MCP permissions remain in force; plugin tools apply the permissions they assert. MCP connection pooling is opt-in and matches account/connection facts, not just a display name. Current pooling requires the newer protocol; sharing removes roots, and the last directory release closes the connection. This is a resource-sharing choice with semantic consequences.

**H, bounded historical failures [P7, P8].** PR60668, merged Oct30 and listed in v2.2.5, fixed shutdown notifications causing clients to immediately reload an evicted location and reconnect its MCP servers. The final design stops callback fibers before connection shutdown; the author replaced an initial boolean because it missed already running callbacks. PR60694, also in v2.2.5, fixed a lower SDK framing cap disconnecting 10–16 MiB messages before the intended host cap, plus repeated whole-buffer concatenation. Reported timings belong to the upstream PR, not our benchmark. Both are resolved historical examples.

**I, lessons.** Owned transformations and replay are a strong no-fork customization pattern when a product can define an explicit merge algebra. They do not make arbitrary independent edits commutative. A contribution debugger should show effective owner, overridden contribution, order and reason. Our product conformance suite should exercise teardown callbacks which trigger observers that can recreate resources. Large-catalog tests also need transport-size and allocation-shape cases, separately from module-count tests.

## Claude Code: bundles, account/org policy, deferred dispatch, and in-process mods

**D, manifest and dependencies [C1, C2].** Plugins bundle several component types, with an optional manifest for default-layout discovery. Manifest validation warns and strips unknown top-level fields while rejecting unknown keys in several strict nested objects. Plugin dependencies support semantic version constraints and marketplace-qualified identity. Unconstrained dependencies follow marketplace releases; cross-marketplace installation requires a root-marketplace allowlist unless already installed/enabled at the same scope. A dependency-only plugin can distribute a curated team set. This is package/deployment composition, not proof that all participating capabilities compose semantically.

**D, runtime identity and conflicts [C3].** The docs separate declared settings, fetched files, and the session's loaded set. `/reload-plugins` applies many component changes; monitors require a session restart. Same-name conflicts have explicit precedence, including managed and session-only sources. Two installed marketplace copies can both appear enabled while only one copy's hooks run; current diagnostics identify the excluded copy. Therefore “installed,” “enabled,” and “active contribution” are distinct states, and manifest name can matter separately from install identity.

**D, trust and policy [C4, C5].** Skills enter model context; hooks and servers execute code. Permission/sandbox rules for model tool calls do not sandbox plugin-owned code: shell hooks, monitors, MCP and LSP processes run outside the tool sandbox. Managed settings can require/block plugins and constrain sources. Current docs explicitly list unsupported policy requests and clarify that source allowlists do not cover `--plugin-dir`; a separate sideload control does. This precision is preferable to a single generic “plugin allowed” flag.

**D, deeper customization [C6].** Mods are JS/TS handlers running inside Claude Code, capable of changing UI, request and tool behavior, beyond external hooks or MCP integration. They run with the user's authority and are not sandboxed. Organization/credential modes affect whether their approvals may bypass ask rules/settings hooks; the permission prompt itself is excluded from restyling. Terminal mods are documented from v2.1.287 onward. Static validation can list declared handler events and calls without running the mod; this is inspection support, not a completeness proof for arbitrary code behavior.

**D, large-catalog dispatch [C7, C8].** MCP tool search defers definitions until needed; its available mode, server instructions, description truncation and provider compatibility matter. The docs do not promise an unlimited context budget. Skills use a separate listing budget: all names remain, while less-used descriptions can be dropped, reducing relevance keywords. Current defaults are 1% of model context for this listing and a per-description character cap, with operator controls and diagnostics. Thus reduced token cost can trade against discovery recall even when runtime module loading is healthy.

**I, lessons.** Expose an explanation spanning source → installed version → declared enablement → effective grants → loaded contribution → dispatch eligibility. Deep customization without forks needs public UI/interaction surfaces as well as backend modules, but it also needs an explicit definition of which surfaces may alter authority. Our product should test that customization cannot restyle or substitute the authoritative approval display. Catalogue SLOs should include discovery recall after budget truncation, not only prompt size.

## Dify Plugin Daemon: runtime routing and tenant/package identity

**D, architecture [D1].** The daemon manages local subprocess/stdin-stdout, TCP debug, and serverless/HTTP runtimes. The API asks the daemon about workspace installations and invokes plugins through it. This is a concrete boundary between product/API routing and execution custody. Process separation is a meaningful mechanism but does not, by itself, establish hostile-code isolation or a unique OS identity per tenant.

**D, declarations and state [D2, D3].** The YAML manifest declares runtime, resources, reverse-call permissions and provided capabilities. Current docs restrict some capability combinations and one provider per extension type. Memory declarations mainly relate to Cloud/Lambda allocation, so they must not be generalized into a proven local enforcement bound. Persistent KV state is workspace-scoped and requires an explicit storage permission/quota. This makes state ownership a product-level dimension, separate from package installation.

**H, identity plus cache [D4, D5].** PR839, merged Oct21 and released in 0.6.12, binds dispatch to exact requested version/checksum while authorizing against the tenant's installed plugin ID; unavailable requested runtimes do not silently select another package. Its initial pinned-dispatch path bypassed the installation cache. PR840, merged the same day and included in 0.6.12, restored cache reuse while keeping the requested package identifier separate and invalidating installation cache in the shared uninstall post-commit path. This pair documents a useful correctness/performance interaction.

**H, environment [D6].** PR799, merged Aug24 and listed in 0.6.11, replaced inherited daemon/shell environments for local plugin subprocesses with an explicit allowlist, covering both daemon and slim CLI spawn sites. Its author reported tests at the real command-construction boundary. This is resolved evidence that process separation alone did not remove ambient credentials; it is not an allegation against the current fixed version.

**I, lessons.** Separate package identity from current tenant authorization, and specify what upgrade, uninstall and revocation mean for previously prepared calls. Cache only the facts whose invalidation authority is defined. Keep the existing physical execution owner responsible for process/environment custody; do not create another generic manager in GM/EF. The Dify contrast gives a protocol and conformance topic, not a reason to adopt Python or a daemon wholesale.

## What our industry-leading goal would need to prove

The following are proposed product experiments, **not executed evidence** and not approval to implement a speculative runtime. They extend the shared brief's already accepted seams.

| Experiment | Concrete falsifier | Owner / reason |
|---|---|---|
| Fixed artifact custody | Verify candidate, substitute an entry/helper/asset before evaluation, and prove the executed bytes stay bound or admission rejects | Existing execution owner integrates; EF describes neutral artifact receipts; GM carries selected identity |
| Customization conflict | Two add/update/remove contributors, deterministic order, invalid rewrite, disposal of winner, and a retained call using its original view | Product defines merge/override rules; GM should not invent universal application semantics |
| Permission transformation | Deny plus observer/modification hook, per-turn grant change, name normalization collision, and an approval after source replacement | Product defines monotonic policy and captures authoritative context |
| Invalidation closure | Upgrade or uninstall while prepared requests, cached installation checks, lazy tools and UI readers exist | Product defines admission/revocation; existing owner settles physical work |
| Shutdown resurrection | Disposal emits events whose subscribers refetch inventory; no callback can restart a retiring resource | Product/custody test; retain failed cleanup evidence |
| Large catalog usability | 1,000 declarations but several active subsets; record discovery I/O, active imports, dispatch latency, tool selection recall and diagnostic size separately | GM scale evidence plus product dispatch/evals; no claim of 1,000 active workers |
| Catalogue/transport shape | Giant tool schema/result, duplicate normalized names, pagination, many reconnecting servers, and event bursts | Product/protocol conformance; declaration count does not cover these |
| Supported no-fork customization | Replace a real UI surface, provider policy and one workflow through documented contracts; upgrade host without source edits | Product acceptance journey; measures public seam completeness and upgrade burden |

No competitor comparison here establishes our superiority. A useful readiness statement is bounded: which public surface, which selected workload, which authority model, which artifact identity, which failure/recovery conditions, and which observed limits.

## Coverage gaps

- Direct pinned source-file opens for OpenClaw/OpenCode returned tool fetch failures. Native loader implementation was not audited in this pass. Current docs may describe changes newer than observed releases.
- Claude Code implementation is not independently inspected; public release/changelog hashes are not equivalent to implementation source revisions.
- No broad issue search was used as a proxy for defect rate. Selected merged fixes show specific failure mechanisms only.
- No thousands-plugin catalogue, multi-user isolation, descendant process custody, cold-start SLO, long-run soak, or provider-selection recall was executed or independently verified.
- Marketplace review quality, install counts, “best” rankings and popularity were not evaluated.
- Suggested experiments have no LOC estimates because no alternative production implementation is proposed in this lane. Parent synthesis should estimate only approved, concretely scoped integration work.

## Source ledger

All sources were retrieved 2026-11-05. Current docs are mutable and have no verified exact revision unless stated. Web reference IDs below are supplied so the parent can independently open before citing. Summaries above deliberately separate documented design from inspected patch metadata and upstream execution reports.

| ID | Class | Official source and web reference | Version/date note |
|---|---|---|---|
| R1 | S/release | https://github.com/openclaw/openclaw/releases/tag/v2026.11.1 — `turn239view3`; commit `turn240view1` | Full SHA above |
| R2 | S/release | https://github.com/anomalyco/opencode/releases — `turn239view4`; commit `turn240view2` | v2.2.5/full SHA above |
| R3 | S/release | https://github.com/anthropics/claude-code/releases — `turn251view0`; commit `turn252view0` | v2.1.318/full SHA above |
| R4 | S/release | https://github.com/langgenius/dify-plugin-daemon/releases — `turn240view0`; commit `turn242view2` | 0.6.15/full SHA above |
| O1 | D | https://docs.openclaw.ai/plugins/architecture — `turn226view0`, `turn231view0` | Current design; not release-qualified here |
| O2 | D | https://docs.openclaw.ai/plugins/manifest/capabilities — `turn249view4` | Activation metadata |
| O3 | D | https://docs.openclaw.ai/plugins/hooks/reference — `turn249view5`, `turn250view2`, `turn250view3` | Hook execution contracts/budgets |
| O4 | D | https://docs.openclaw.ai/plugins/hooks — `turn225search1` | Permission gates/runtime emission limits |
| O5 | D | https://docs.openclaw.ai/plugins/building-plugins — `turn225search3` | Experimental API compatibility guidance |
| O6 | D | https://docs.openclaw.ai/tools/skills — `turn225search2` | Skill precedence |
| P1 | D | https://opencode.ai/v2/docs/build/plugins/ — `turn228view0` | Parts/exports |
| P2 | D | https://opencode.ai/v2/docs/build/plugins/migrate-v1/ — `turn236view1` | Explicit V1/V2 implementation incompatibility |
| P3 | D | https://opencode.ai/v2/docs/build/plugins/server/ — `turn231view7`, `turn251view3` | Domain contracts; not independently executed |
| P4 | D | https://opencode.ai/v2/docs/plugins — `turn225search6`, `turn246view6` | Current V2 discovery/reload |
| P5 | D | https://opencode.ai/v2/docs/mcp-servers — `turn249view3`, `turn251view4` | Pooling/protocol/namespace semantics |
| P6 | D | https://opencode.ai/v2/docs/tools — `turn249view2`, `turn250view4` | Code Mode and tool/skill distinctions |
| P7 | H/S | https://github.com/anomalyco/opencode/pull/60668 — `turn240view6`, `turn242view8` | Merged Oct30; commit `2e29481d5c5b92b75b6a29eeca8a8ff8ed166af7` (`turn252view4`); released v2.2.5 |
| P8 | H/S | https://github.com/anomalyco/opencode/pull/60694 — `turn240view5`, `turn242view7` | Merged Oct30; commit `1a443ae42ac8bf8cb46bb3bafe2d876115815679` (`turn252view5`); released v2.2.5 |
| C1 | D | https://code.claude.com/docs/en/plugins-reference — `turn226view2` | Manifest validation and components |
| C2 | D | https://code.claude.com/docs/en/plugins/dependencies — `turn236view0` | Version constraints/cross-marketplace trust |
| C3 | D | https://code.claude.com/docs/en/plugins/loading — `turn231view5`, `turn251view1` | Declared/fetched/loaded; same-name hook diagnostics require v2.1.296+ |
| C4 | D | https://code.claude.com/docs/en/plugins/security — `turn231view4`, `turn234view2` | Explicit trust boundary |
| C5 | D | https://code.claude.com/docs/en/plugins/org — `turn244view5`, `turn246view3` | Managed policy reach and limitations |
| C6 | D | https://code.claude.com/docs/en/plugins/mods/overview — `turn244view3`, `turn246view1` | Terminal v2.1.287+; in-process authority |
| C7 | D | https://code.claude.com/docs/en/mcp — `turn249view0`, `turn251view2` | Deferred tool definitions/provider limits |
| C8 | D | https://code.claude.com/docs/en/skills — `turn249view1`, `turn250view1` | Current listing budget and visibility tradeoffs |
| D1 | D | https://github.com/langgenius/dify-plugin-daemon — `turn226view4` | Main README; not pinned implementation |
| D2 | D | https://docs.dify.ai/en/develop-plugin/features-and-specs/plugin-types/plugin-info-by-manifest — `turn239view1` | Manifest/resource constraints |
| D3 | D | https://docs.dify.ai/en/develop-plugin/features-and-specs/plugin-types/persistent-storage-kv — `turn240view4` | Workspace KV |
| D4 | H/S | https://github.com/langgenius/dify-plugin-daemon/pull/839 — `turn244view0` | Merged Oct21; `1369a6c8e507f16cff5ee0e224dee168e51af32f` (`turn252view1`); released0.6.12 |
| D5 | H/S | https://github.com/langgenius/dify-plugin-daemon/pull/840 — `turn244view1` | Merged Oct21; `c94dd223a24363e2618364e2ef0ecaf5b7196382` (`turn252view2`); released0.6.12 |
| D6 | H/S | https://github.com/langgenius/dify-plugin-daemon/pull/799 — `turn244view2` | Merged Aug24; `a00091320c08878fa20cd5805ead5314f63bbef0` (`turn252view3`); released0.6.11 |

