# Root review disposition — 2026-11-05

## Task and status

The owner wants a deeply customizable agent platform with hundreds or thousands
of modules and independently supplied plugins, useful extension without forks,
explicit responsibility boundaries, and evidence rather than feature-count or
marketing comparisons. This follow-up answers the industrial-research and scale
status question while preserving the earlier authorized research work in EF
draft PR55. It is not a new runtime implementation or an adoption decision.

The existing accepted direction remains static composition and controlled
restart, GM as the composition owner, EF as the neutral extension/artifact/trust/
protocol/conformance owner, and products as owners of concrete extension points,
grants, admission, readiness and state. Existing execution owners retain physical
custody. Temporal remains an optional adapter at a qualified product seam.
No generic host, second container, second supervisor or blanket language rewrite
is introduced.

## Review participants and independence

All six delegated investigators/critics used the owner's requested
GPT-6.1 Sol xhigh. They received the same retained context.md owner brief;
assignments separated three investigator topics and three independent critical
perspectives. Only three child agents ran concurrently. The root verified
important source claims, current repository identities and actual hosted test
receipts, integrated the reports, and reviewed the final prose.

Investigators:

- industry-agent-platforms.md: current agent products, release anchors,
  customization mechanisms and historical fixes.
- industry-mature-ecosystems.md: mature extension contracts, lifetimes, placement,
  trust and compatibility.
- internal-industry-and-scale-status.md: current GM/EF/Orchestrator authority,
  retained scale artifacts, hosted execution and gaps.

Independent critics:

- critic-industry-claims.md: source fidelity, fixed versus current defects,
  source/docs/release differences and fair comparison. Its second review is
  retained in the same report.
- critic-scale-and-design.md: exact denominators, aggregate capacity,
  classification of dense-test evidence and decision-changing experiments.
- critic-plugin-author-experience.md: useful no-fork customization, actual
  provider substitution, predictable conflicts and ordinary author burden.
  Its final narrow review found no remaining publication blocker in this scope.

The root's model-facing-scale.md adds tool discovery and model-context cost as a
separate axis. Research notes retain their original qualifications and are not
silently rewritten to make all investigators agree. The synthesis and this
disposition are the current reconciliation.

## Accepted material corrections

1. OpenClaw: credit current inventory, activation and generation/snapshot
   mechanisms. Ordinary captured files are independent copies, but late-demand
   dependencies need separate qualification. Initial source digest, managed
   install snapshot, release tag and current-main publication code are different
   evidence subjects. The old audit remains dated source evidence.
2. Claude Code: native mods are trusted in-process code. Tool-mediated permission
   behavior is credential/mode/managed-policy dependent; a protected approval UI
   is not a native-code sandbox. The synthesis retains this qualification.
3. OpenCode: current review concerns V2 documented contracts. The shutdown
   callback/resurrection incident is a fixed historical example, not a claim of
   a current defect. Captured executable definitions can close over mutable state.
4. Dify: exact artifacts, current tenant installation authority and cache
   invalidation are separate obligations. PR799/839/840 are explicitly historical
   merged repairs. Shared non-root process identity does not prove per-tenant
   isolation.
5. MCP: the pinned tools specification recommends deterministic ordering
   (SHOULD); the synthesis no longer makes a universal guarantee. Deferred model
   context loading does not automatically reduce request transport.
6. N1000: identify frozen Core/Assembly 0.7.0 and the b70ba393 driver/dist
   replacement recipe. The 2,000 count is entries and groups COMBINED, not each.
   Current main, latest public 0.7.1 and this historical run are distinct.
7. Dense graphs: source-inspected P500 tests DEFINE their private semantic/output
   checks. This round has no new dense execution and no independently inspected
   named dense-test CI receipt. Primary-vector counts and the historical private
   traversal record are linked separately.
8. Live instances: credit the actual 1,024 simultaneously live scoped receiver
   instances. The subject is one receiver template, two synchronous source
   objects and precise delivery/cleanup, not 1,024 unrelated plugins, processes,
   real tenants, async jobs, measured RSS or production throughput.
9. No-fork usefulness: make one visible A + independently packaged B + conflict
   fixture journey Priority 1 alongside real artifact handoff qualification.
   Existing consumers must actually use the substituted provider, while B changes
   a supported user workflow or UI and preserves A's other behavior.
10. Conflict determinism: identical declared inputs must survive discovery
    permutations. Explicit configured pipeline order may intentionally change
    behavior. Avoid accidental registration-order singleton selection.
11. Compatibility: allow deliberate MVP contract breaks, explicit lock/version
    changes and understandable rejection/migration. No new permanent backward
    compatibility obligation is inferred from a peer.
12. Customization: narrow typed workflow hooks and UI contributions are valid
    candidates under static composition/restart. They are not bundled with
    arbitrary global mutation or universal in-process unload.
13. Estimates: the historical 0 shared / 150–500 integration / 600–1,400 test LOC
    estimate concerns one backend restart/custody slice, with approximately
    twofold uncertainty. It excludes the additional public UI/workflow/author
    journey, hostile execution, marketplace and distributed rollout. Those costs
    remain unestimated until their real surface is chosen.
14. Evidence counts and scores: 20 prior cases, report counts and judgments out
    of 10 are inventory/planning aids, not proof of leadership, market coverage,
    competitor defect rates or measured reliability.

## Retained execution and current authority

validation/gm-hosted-ci-receipt.json contains the inspected run metadata, all
64 job conclusions, and exact named-test/workspace-integrity excerpts from
Ubuntu, macOS and Windows logs. Run 41971404753 executed source
3aae8a2e6695ba1fca96beea68e674a3c27ef0e9 and completed successfully.
The nine Assembly jobs succeeded; three cross-OS raw logs were inspected.
This is existing upstream execution, not a locally rerun test.

The October tarballs, negative counterexamples and accepted ADRs remain
unchanged. Orchestrator ADR-0117 is the current accepted 0.5.0 composition
baseline. Native PostgreSQL remains accepted through ADR-0114/0115.
A current GM main commit or npm release does not update that consumer.

The pending EF merge carries only the exact identity-verifier workflow update
already accepted in main 29ae5b0269d9d83f071344e3e18761ded04ff53d. It does not
weaken identity checks, add exceptions or claim approval for this draft PR.

## Local documentation validation and a separate tooling blocker

See validation/validation-summary.json and retained logs for final command
outcomes. DocsProtocol creation used identical reviewed preview/apply inputs and
plan digest sha256:ed87214fdd2472dd1ffdc4eb19240017710971d2130ae103775360abce5f10f1.
Navigation and current notes route readers without changing historical pins.
The initial CSpell failure on the proper name Dify is retained; the correction
is a focused word declaration in the new document.

The current organization Engineering Quality Standard forbids initializing
TypeScript below 7.0.2, including embedded compiler APIs. The workspace compiler
is 7.0.2, but pinned Engineering Foundation 1.7.2 resolves API Extractor 7.58.12,
which initializes TypeScript 5.9.3. Package metadata was read without importing
the compiler. The installed CLI static import chain is:

cli.js -> composition/command-host.js -> rule-registry.js /
foundation-check.js -> capability-modules.js ->
capabilities/public-api-compatibility/module.js ->
microsoft-public-api-extractor.js -> @microsoft/api-extractor
lib-commonjs/index.js -> api/CompilerState.js -> require("typescript").

Thus check:changed, check:fast and the complete Foundation-based gate are
blocked locally by an existing owning-toolchain conflict. They are not marked
passed, bypassed or replaced with a pretend full gate. No dependency pin, policy,
scope or workflow is changed to suppress it. The unaffected DocsProtocol gate
runs separately as the documentation skill requires. Resolving the compiler
dependency belongs to Engineering Foundation's upgrade and qualification route.

## Next action and stopping rule

Research supports the accepted composition/restart direction, but not an
industry-leading production capacity claim. The next useful implementation
evidence is the actual public author journey and custody seam, followed by
bounded async load and lifecycle churn at the same owner. Use existing adapters
and conformance routes. Do not build a new framework or repeat unchanged toy
matrices merely to increase the test count.

No accepted-ADR conflict requires an owner decision in this follow-up. The PR
remains draft; publication of the research is not merge approval, runtime
adoption, product readiness or a new compatibility promise.
