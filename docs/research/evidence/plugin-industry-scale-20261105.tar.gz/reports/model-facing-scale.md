# Model-facing catalog scale and protocol boundaries

Observation: 2026-11-05. Root research lane. No external product was executed;
these are current primary-source observations and explicitly marked inferences.

## Evidence

1. Anthropic's current Tool Search documentation describes deferred definitions
   and on-demand expansion. It explicitly distinguishes model-context loading
   from transport: the complete definitions still travel in the API tools array.
   The search request adds work/latency. Its claimed context/accuracy improvements
   are vendor observations, not our measurements or a guarantee for our catalog.
   Source: <https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool>.
   Current moving documentation, read on the observation date; no implementation
   revision or run was independently qualified.
2. The MCP 2026-07-28 Tools specification describes deterministic catalogs,
   pagination, caching and authorization-sensitive tool lists; annotations from
   untrusted servers remain untrusted. Read current source and verify a pinned
   excerpt through the GitHub connector at
   `3c4d91b7e832d9b74338d56eed03403ccc662123`, file
   `docs/specification/2026-07-28/server/tools.mdx`, blob
   `7813b8c37b83198289fd816063b1e6d3bc727315`.
   Source: <https://github.com/modelcontextprotocol/modelcontextprotocol/blob/3c4d91b7e832d9b74338d56eed03403ccc662123/docs/specification/2026-07-28/server/tools.mdx>.
   Web retrieval of this pinned URL failed; connector retrieval succeeded. The
   moving main page was also read through web retrieval. Neither is execution.
3. The official release explanation identifies the July specification's
   stateless request model, explicit application-state handles, header routing,
   cache hints, protocol-extension lifecycle and migration from previous
   sessionful behavior. Source:
   <https://blog.modelcontextprotocol.io/posts/2026-07-28/>.
   This is a published protocol revision, not proof every installed MCP server,
   client or SDK already implements it. Product adapter adoption stays explicit.

## Interpretation for our system

The module catalog, executable activation and model-facing tool shortlist are
three different sets. One plugin may contribute many tools; a declared module
may contribute none. Inert metadata can support discovery without evaluating
all implementations. A product-owned projection can expose only eligible
capabilities for a request, then select a smaller relevant tool set. Invocation
must use the actual authorization/effect owner; descriptions, cached search
results and a permission request are not grants.

Progressive disclosure is a recommendation for the product's agent/tool adapter,
not a new GM resolver or an EF runtime. Reuse the selected model provider or MCP
adapter where suitable. Verify exact revision interoperability rather than
building a second tool protocol. A protocol's lack of transport sessions does
not eliminate application operation identity, state, idempotency or recovery.

Useful measurements are schema bytes/tokens in transport and model context,
discovery latency, relevant-tool recall, wrong-tool/argument errors, call-time
authorization rejection, stale catalog behavior and trace attribution. A schema
budget or shortlist cardinality is not a safety control. Repeated results with
small model samples do not establish a universal success rate.

## Decision-changing future experiment (not executed)

Use the first real product tool projection and existing deterministic catalog.
Keep actual callable capabilities fixed and add inert irrelevant descriptors to
separate search/context growth from code activation. Compare eager exposure with
the existing provider's deferred loading or an already owned search adapter.
Include similar names, same-name tools from different authorities, permissions
removed after discovery, stale revisions and a plugin adding multiple tools.
Use a small fixed task corpus with independent expected eligible tools. Prove
no unauthorized effect at the receiver; measure token/transport/latency/selection
tradeoffs separately. Do not assert thousand-plugin throughput from this test.

This test is warranted when the product's tool projection exists. A new synthetic
framework that only tests its own generated lookup would not resolve that seam.
No package selection, public contract, performance SLO or production threshold
is adopted by this note.
