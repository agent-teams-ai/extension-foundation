# Independent critic: industry claims, version binding and scale transfer

Observation date: 2026-11-05 UTC. Full shared brief read first. Reviewed `industry-agent-platforms.md`, `model-facing-scale.md`, `industry-mature-ecosystems.md`, and the completed `internal-industry-and-scale-status.md`. Primary-source verification below is independent of their source summaries. No competitor code was installed or executed, no new capacity tests were run, and no implementation or repository refs were changed. This report is research criticism, not adoption or implementation approval.

## Disposition

**Accept the mechanism-oriented synthesis after the OpenClaw custody/version clarification and the Claude permission qualification below.** The reports are materially more careful than a product ranking: they distinguish documentation from execution, recognize competitor improvements, preserve historical fixes, and keep GM/EF/product/execution responsibilities separate. No evidence reviewed establishes our superiority, a thousand independent product plugins, a hostile plugin security envelope, or a production capacity SLO.

The strongest correction is symmetrical. Current OpenClaw has real source-capture machinery, so a blanket accusation that it merely reloads mutable package paths would be wrong. Its ordinary capture path also explicitly permits first-demand inputs to observe later edits, so a blanket claim that every executed input belongs to one fully immutable initial digest would be wrong. Managed installation snapshots, ordinary captures, native references, and arbitrary user-authority plugin code need separate scopes.

## 1. Required corrections before publication

### C1 — OpenClaw: do not turn captured source into a complete immutable execution closure

The agent report's broad phrases about immutable source generations need a nearby limitation. Both the current architecture page and the release-pinned architecture document state that a first-demand import/require can see later source edits. The initial digest covers the initial capture; additional inputs do not change that digest. This is an explicit supported boundary, not an independently discovered exploit. Current page: <https://docs.openclaw.ai/plugins/architecture>, web ref `turn264view0`. Release document: <https://github.com/openclaw/openclaw/blob/4ffdd2047d192dd65554de3c8c46c0e0197c6e2a/docs/plugins/architecture.md>, blob `47ccaf229ed3f364119e3addeed7012b44bb9611`, inspected source lines 377–393.

The release implementation independently supports the narrower interpretation. `plugin-generation-artifact.ts` publishes `initialReceipt.sourceDigest` and has demand-driven acquisition paths; it does not label the digest as an attestation of every future input. <https://github.com/openclaw/openclaw/blob/4ffdd2047d192dd65554de3c8c46c0e0197c6e2a/src/plugins/plugin-generation-artifact.ts>, blob `769f60f371052877da342c7e91bcc6abb64b11a4`, especially lines 683–694. This is **source inspection**, with no reproduced competitor run.

**Required wording:** “Already captured ordinary inputs retain independent bytes. Some first-demand inputs can be acquired later and are outside the initial digest. Current managed-install snapshot machinery is a separately scoped mechanism; this review does not establish a complete immutable closure for all plugin execution paths.”

**Disposition:** adopt the distinction and test vocabulary; do not adopt an unqualified custody guarantee or a new reload runtime.

### C2 — Separate the observed stable OpenClaw release from current-main snapshot implementation

The observed release `v2026.11.1` resolves to `4ffdd2047d192dd65554de3c8c46c0e0197c6e2a`; the release page independently confirms the tag and short commit (`turn263view1`). Its architecture document already includes ordinary source copies, generation publication and recovery descriptions. The current website's managed immutable-install snapshot/journal description must not automatically be attached to that release.

I fetched those mechanisms at the exact current-main revision returned by code search, `8eb01599c83a05509c5f1f52407b218e7660623b`. The snapshot artifact source validates captured content/closure against the installation binding, validates the staged payload against retained file/directory/link facts, and publishes a completed directory. The publication wrapper records the staged candidate before publication under an existing lifecycle lease. These are meaningful **source observations**, not execution or full control-flow qualification:

- <https://github.com/openclaw/openclaw/blob/8eb01599c83a05509c5f1f52407b218e7660623b/src/plugins/plugin-source-snapshot-artifact.ts> — blob `8cda9882170a8f02eebb8ae3cc93af0c60fffebe`, 688 lines; inspected binding/payload/publication branches.
- <https://github.com/openclaw/openclaw/blob/8eb01599c83a05509c5f1f52407b218e7660623b/src/plugins/plugin-source-snapshot-publication.ts> — blob `2e91e30a05b81385df21549200f6e8f00e88ea86`, 42 lines, read in full.
- <https://github.com/openclaw/openclaw/blob/8eb01599c83a05509c5f1f52407b218e7660623b/src/plugins/plugin-source-snapshot.types.ts> — blob `0c912661c6f6a684bb3820dea1ac8733ee1e4c2f`, 89 lines; identity includes content/closure/build-resolution facts.
- The corresponding `plugin-source-snapshot-publication.ts` fetch at stable `4ffdd204…` returned GitHub 404. This proves that exact path is absent at that revision; it is not by itself proof that no equivalent older mechanism exists elsewhere.

**Required change:** supplement the report's “pinned source unavailable” coverage note with this targeted source inspection. Keep the broad architecture implementation audit unqualified. Do not relabel all current website claims as release-qualified because a subset of loader source was inspected.

### C3 — Claude mods: include credential-dependent deny bypass and the trusted-code boundary

The report correctly identifies in-process JS/TS mods, user authority and lack of sandboxing. The permission consequence is stronger than bypassing only ask rules or settings hooks: the current permission reference says that, without managed settings or the qualifying Team/Enterprise login credential, a mod may approve a call rejected by a deny rule. API-key or long-lived-token sessions do not inherit the stored login's qualification. Managed policy, credential mode, plan mode, and required-interaction exceptions need their documented qualifications. <https://code.claude.com/docs/en/permissions#extend-permissions-with-hooks> — independently opened, `turn268view0`, `turn268view1`.

The official mod overview also excludes permission-prompt restyling while explicitly granting the mod broad user-level code authority. <https://code.claude.com/docs/en/plugins/mods/overview> — `turn259view1`. An unmodified authoritative approval display is a useful UI contract, but it does not constrain code that directly reads files or starts processes outside mediated model calls.

**Required wording:** “Permission precedence describes mediated tool calls under the documented policy/credential/mode. Native mods remain trusted user-authority code; permission UI and static declaration validation do not provide hostile-plugin isolation.” A proposed monotonic deny policy for our product is a **design choice to test**, not a universal invariant proved by all competitors.

## 2. Counterevidence that should prevent stale or unfair criticism

### OpenClaw already contains concrete custody protections

At stable `4ffdd204…`, ordinary capture uses descriptor-bound copying, including independent small-file destinations and the fs-safe copy path for larger/native-shaped inputs. File-capture aliases reuse the first captured bytes rather than merely pointing a new alias at the original mutable source. The instance loader checks an expected source digest before proceeding and disposes a rejected newly acquired artifact. Relevant exact source:

| File | Blob SHA | Inspected mechanism |
|---|---|---|
| <https://github.com/openclaw/openclaw/blob/4ffdd2047d192dd65554de3c8c46c0e0197c6e2a/src/plugins/plugin-source-file.ts> | `a28b0c913f91d3c7cd2ccf3c89a8f7925e3fee9e` | Admitted input descriptor, independently created output, identity checks, hashing copied descriptor; copy comment explicitly limits concurrent input-edit treatment. |
| <https://github.com/openclaw/openclaw/blob/4ffdd2047d192dd65554de3c8c46c0e0197c6e2a/src/plugins/plugin-generation-file-capture.ts> | `39e490fff73088ed04087a0e495c7f2a441c7ea4` | Captured-path alias map, independent ordinary copies, native-specific branch, per-file receipt. |
| <https://github.com/openclaw/openclaw/blob/4ffdd2047d192dd65554de3c8c46c0e0197c6e2a/src/plugins/plugin-instance-module-loader.ts> | `0605b8f0c998bb4a247ce05f017aa5d8af493df0` | Artifact acquisition, expected-digest mismatch rejection, retention and disposal ownership. |
| <https://github.com/openclaw/openclaw/blob/4ffdd2047d192dd65554de3c8c46c0e0197c6e2a/src/plugins/plugin-native-module-loader.ts> | `5be79a31224be7c198aaca0d8cea0e7ef7bc77f0` | Managed module resolution uses the instance artifact and captured paths. |

These mechanisms refute a blanket “hash then always execute original mutable path” characterization of this release. They do not establish hostile safety, a frozen universe of all future inputs, arbitrary external asset capture or unloading of Node's resident ESM modules. The existing October audit remains useful as a pinned historical audit; this finding neither erases its observed limits nor licenses applying them to every newer release.

### OpenCode V2 cannot be represented by the V1 API

The current migration guide explicitly requires implementation porting and distinguishes V1 returned hook objects from V2 stable IDs and setup registrations. Current server docs support ordered replayable domain transforms, registration disposal and per-model-request executable tool snapshots, with a specific warning that closures may retain mutable plugin state. Independently verified: <https://opencode.ai/v2/docs/build/plugins/migrate-v1/> (`turn265view0`), <https://opencode.ai/v2/docs/build/plugins/server/> (`turn257view1`, `turn266view1`). These remain **current documented contracts**, not an independently executed V2 suite or a source audit bound to `v2.2.5`.

Disposition: retain as a useful product-owned contribution model. Do not call replay commutative, safe against arbitrary plugin code, or evidence of thousand-module throughput. The distinction between registered definitions and running-resource readiness is particularly useful.

### Claude supports deeper no-fork customization than prompt bundles

The mod overview independently confirms UI contributions, tool/request interception and direct command functions, with terminal availability from `v2.1.287` and separate Desktop version guidance. This is counterevidence to describing Claude's extensibility as merely skills/hooks/MCP text bundles. It is a documented trusted customization surface; it supplies no comparative maintainability, ecosystem capacity or hostile isolation proof.

### Dify improvements are current source, not current defects

The report treats the selected bugs as fixed history, correctly. PR839 and PR840 are merged and explicitly included in release0.6.12: <https://github.com/langgenius/dify-plugin-daemon/pull/839> (`turn257view3`), <https://github.com/langgenius/dify-plugin-daemon/pull/840> (`turn259view2`), <https://github.com/langgenius/dify-plugin-daemon/releases/tag/0.6.12> (`turn262view2`). They distinguish requested package identity from tenant installation authority and make cache invalidation participate in uninstall. Do not transform these examples into current-version exploit claims or an inferred defect rate.

I also inspected current0.6.15 source at `14d714820d475075e15bd8dae605d61298382213`. Both spawn sites use the explicit environment builder:

- <https://github.com/langgenius/dify-plugin-daemon/blob/14d714820d475075e15bd8dae605d61298382213/internal/core/local_runtime/subprocess.go> — blob `09586df1b2f63dca52da0e43433df0d078beeb24`.
- <https://github.com/langgenius/dify-plugin-daemon/blob/14d714820d475075e15bd8dae605d61298382213/pkg/slim/local.go> — blob `313ee670dbdb80fd746f4b709402257a6043aeb0`.

PR799's patch and author-run tests are historical evidence, not my executed result: <https://github.com/langgenius/dify-plugin-daemon/pull/799> (`turn259view3`). Environment filtering removes direct ambient inheritance along these paths; it is not proof that the subprocess cannot obtain other same-user resources.

One additional improvement deserves recognition: merged PR833 and release0.6.12 introduce a dedicated runtime user in the local image. Current0.6.15 `docker/local.dockerfile` still sets `USER dify`, blob `ca1b5e658f24fa66f125906fee024ac0eebcb22b`: <https://github.com/langgenius/dify-plugin-daemon/blob/14d714820d475075e15bd8dae605d61298382213/docker/local.dockerfile>. Source inspection shows a shared image user, not one OS principal per plugin or tenant. <https://github.com/langgenius/dify-plugin-daemon/pull/833> (`turn263view0`). This closes any stale blanket claim that the shipped local image necessarily runs Go/Python as root.

## 3. Model-facing scale: independently verified, with transfer limits

The model-facing report's central separation is correct: declarations, running implementations, model-visible tools and actual authorized invocations are different sets. A plugin can contribute zero, one or many tools; a deferred tool definition does not prove an unloaded implementation or an absent server process.

Anthropic's current Tool Search page explicitly keeps every full definition in the request `tools` array even when deferred from model context. The page lists a 10,000-deferred-tool request limit, but that is an API limit, not independently measured recall, throughput, latency, security or plugin-fleet capacity. It also recommends non-deferred frequent tools and requires matching definitions for returned references. <https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool> (`turn264view1`, `turn264view2`). The report's added search-latency implication is sensible inference; retain that label instead of attributing a measured latency delta to the docs.

The MCP pinned Tools file was independently fetched through GitHub at `3c4d91b7e832d9b74338d56eed03403ccc662123`; blob independently matches `7813b8c37b83198289fd816063b1e6d3bc727315`. It supports authorization-sensitive lists, deterministic ordering as a SHOULD, pagination/caching, and treating untrusted-server annotations as untrusted. <https://github.com/modelcontextprotocol/modelcontextprotocol/blob/3c4d91b7e832d9b74338d56eed03403ccc662123/docs/specification/2026-07-28/server/tools.mdx>. Do not upgrade SHOULD ordering into a universal observed property of all MCP servers.

The official July release explanation confirms a stateless protocol core and explicit application-state handles: <https://blog.modelcontextprotocol.io/posts/2026-07-28/> (`turn262view1`). This is a real protocol revision; it neither proves installed-client adoption nor removes product operation identity, durable effects, retries, revocation or recovery. Keep adapter interoperability version-bound. No second resolver or tool protocol is justified.

## 4. Internal scale/status criticism

The completed internal report properly corrects two potentially misleading old summaries: GM has actual executed live-object lifetime evidence, and EF still has no public runtime. The two facts cannot be merged into either “we only have descriptors” or “we have a qualified thousand-plugin runtime.”

Retain the exact denominators:

| Existing result | Legitimate inference | Prohibited transfer |
|---|---|---|
| N1000 complete-map compilation/construction/smoke | That exact type surface and finite graph workload passes its recorded stages/toolchain. | A thousand persistently live heterogeneous plugins, agents, workers, or production capacity. |
| 1,024 simultaneously live scoped receivers from one prepared template, two borrowed synchronous sources | Meaningful reference/lifetime correctness for distinct live receiver roots, partial close and complete cleanup. | 1,024 independent declarations/installations, asynchronous workload, hostile tenants, resource envelope or throughput. |
| Current GM source and its CI | Main includes demonstrated fixes beyond frozen October inputs. | Released package-byte equivalence or automatic product adoption. |
| Orchestrator ADR-0117 canonical Core/Assembly0.5.0 authority | Current accepted product composition baseline supersedes older adoption interpretation. | Repinning to GM latest, rebuilding a generic Host or marking pending product readiness gates passed. |
| EF research draft and frozen archives | Reusable contracts/failure vocabulary and bounded executed experiments. | A shipped EF runtime, automatic execution custody or a product grant boundary. |

The internal report preserves these distinctions and does not add heterogeneous test denominators into a reliability percentage. No blocking correction found in those scope statements. This critic did not re-download all internal archives or independently inspect every CI lane; the internal research lane's explicit cross-OS log sample coverage remains the evidence claim.

The mature-ecosystem report's scored alternatives are engineering judgments under explicit trust assumptions, not benchmark results. Retain that qualification and “production/integration LOC not estimated” where the actual seam is unknown. Do not convert narrow fixture-only LOC ranges into a runtime integration budget. The accepted static/restart path is justified by fit and reduced replacement machinery, not measured superiority to dynamic competitors.

## 5. Adoption register for the synthesis

| Mechanism/claim | Disposition | Existing owner and decision boundary |
|---|---|---|
| Inert inventory, explicit selected/active/ready state, provenance | Adopt as vocabulary and product acceptance criterion; implementation still seam-specific. | GM selection/graph facts; product readiness/grants and diagnostics. |
| Narrow extension points, cardinality/conflict rules, contributing-module attribution | Strong candidate for the next real customization seam. | Product API and policy; GM remains sole composition. |
| Stable request view plus explicitly mutable closures | Adopt distinction; no implicit snapshot of arbitrary state. | Product request/executor owner. |
| Fixed managed artifact plus verified closure/custody | Keep highest-value product integration falsifier; source comparison supplies ideas, not proof. | Existing execution owner; EF receipts/contracts; GM selected identity. |
| Large catalog progressive disclosure | Reuse provider/MCP facilities after actual tool projection exists. | Product agent/tool adapter; no EF runtime/new resolver. |
| User-authority native customization | Valid trusted-code option; do not market as capability isolation. | Product admission/trust; execution owner placement. |
| Process separation/shared non-root account/environment allowlist | Useful cumulative controls; no per-tenant hostile guarantee. | Existing physical execution owner and deployment boundary. |
| Arbitrary in-process hot reload or full competitor loader transplant | Do not adopt within current accepted static/restart scope. | Would require a separate justified decision, not this research update. |
| “Industry-leading,” “best,” “antipattern architecture” rankings | Unsupported as technical findings here. | Present aspiration and specific mechanisms/limits instead. |

**Publication outcome:** usable research with the three corrections above. **Runtime adoption outcome:** no new package pin, public contract, production envelope, generic manager or implementation approval. The next decision-changing evidence remains the first real product seam with independent contributors, exact admitted artifact custody, product policy/readiness, and retained cleanup/recovery outcomes.

## 6. Second review of the root synthesis and navigation

Read the complete `plugin-industry-and-scale-review-2026-11-05.md` and exact navigation diffs in `docs/README.md`, `customization-without-forks-and-scale.md`, `openclaw-plugin-and-reload-audit.md`, and `plugin-system-research-reference.md`. No new research or execution was necessary for this round.

The synthesis now incorporates C1/C2 correctly: ordinary captured files, later-demand inputs and current-main managed snapshots have separate claims; absence of the inspected publication path at the release is stated narrowly. Current OpenCode is identified as V2 documented behavior, and Dify repairs remain historical fixed examples. No unsupported superiority, current-defect-rate, released-runtime or thousand-plugin claim was found. Navigation preserves historical pins and source evidence while routing readers to the dated correction; GM main, npm artifacts and consumer adoption remain separate.

**Second-round disposition:** publication is sound once the root's already planned Claude credential-dependent mediated-deny clarification is added. One minor normative precision edit was requested: describe MCP deterministic ordering as recommended (SHOULD), rather than implying all catalogs are observed deterministic. This is a wording correction, not a new experiment or architecture requirement. The higher-level user-facing explanation may simply describe trusted native customization and its boundary without reproducing detailed permission configuration. No repository changes were made by this critic.

