# Independent scale and architecture critique — 2026-11-05

## Judgment

The accepted architecture is a credible foundation for a large ecosystem, and the current evidence is stronger than “a thousand descriptors compiled.” The N1000 complete-map campaign executes substantial finite construction and adversarial smoke. Current GM additionally has **1,024 simultaneously live, independently scoped receiver instances**, with real subscriptions, exact channel routing, partial retirement, complete cleanup and fresh-template reuse. Those achievements deserve explicit credit. They qualify different axes and cannot be multiplied into a thousand heterogeneous active product plugins or an authenticated multi-tenant capacity envelope.

The most decision-changing gap is now **one actual product extension family using the approved artifacts and existing execution owner**. Another generalized host, registry, scheduler, resource manager, replacement controller or plugin framework would hide the ownership gap behind more machinery. Nor should every missing dimension become a prerequisite for a useful first slice. The next work should falsify the real product's invariants, expose the smallest useful initial envelope and stop when that envelope is established.

This review read the full shared context and the three research reports, plus the current internal status. It independently inspected local source at GM `5fb83478dd7b95216be92c4d3077eddf2774eef8`, EF `70f03d3d9e134780f27268339a6729a7305a2363`, and Orchestrator's accepted ADR-0117. It executed no tests, installed nothing and edited no repository. Existing CI execution is established by the internal researcher's read-only API/log evidence, not a fresh execution by this critic. The parent synthesis was still a scaffold at initial review; final wording review remains separate.

## 1. Corrections and claim severity

Severity here concerns the consequence of publishing the claim, not a discovered production defect.

| Severity | Claim to reject or correct | Supported replacement |
|---|---|---|
| High | “Our scale evidence is descriptor-only / no actual thousand-instance runtime exists.” | N1000 has finite construction/smoke; #223/current CI has 1,024 simultaneously live same-template scoped receivers. Give both results and their distinct limits. [C1–C3] |
| High | “We support a thousand active independent plugins/agents/tenants” or “industry-leading reliability is demonstrated.” | No corresponding product workload, comparison or SLO is qualified. The evidence supports bounded composition and instance-lifetime correctness. The ambition is a design objective. |
| High | “The latest public packages include the current main fixes / Orchestrator uses them.” | Current GM source, exact npm archives and actual consumer adoption are three separate identities. Internal status records Core/Assembly latest 0.7.1 predating Nov2–5 fixes; Orchestrator ADR-0117 preserves adopted 0.5.0. [C4, C8] |
| Medium | “Dense graphs are untested” or “only a sparse N1000 graph has ever been exercised.” | Current source includes a P500 dense admission→semantics→canonical-output proof, independent complete plan/digest expectations and mutations; historical kernel evidence also includes a dense 4,096-node fixture. Neither is a current product capacity result. [C5–C7] |
| Medium | “4,096 entries / a 262,144-provider-occurrence cap means the runtime can serve that fleet.” | These are structural allocation/semantic admission ceilings, not measured service capacity. Assembly's entries/groups/input census ambiguity is explicitly excluded from the recent correction. Do not infer a new combined capacity. [C9] |
| Medium | “All remaining axes need their own framework or mandatory gate before a product slice.” | Attach only applicable scenarios to the same actual seam. Controlled restart is accepted. A smaller qualified envelope is expressly permitted by ADR-0117. [C8] |
| Low–medium | Scores such as reliability 8/10, old LOC ranges or a single timing become evidence of delivery cost/availability. | Scores are judgments within a stated trust profile; timings are single observations; older LOC ranges are scoped planning hypotheses. No current product integration estimate is defensible without its source/ownership inventory. |

The three research reports and internal status mostly avoid these errors. The notable positive addition is dense-graph qualification: the final synthesis should not erase existing algorithmic/semantic evidence while correctly identifying missing product evidence.

## 2. What is actually demonstrated

### Historical complete-map N1000

The EF raw archive was independently re-inspected by the internal lane. It records 1,000 named generated features plus an input declaration: **1,001 declarations, 2,000 entries/groups, 1,997 edges, 7,003 source files**. Full smoke includes **2,001 finite attempts, 1,002,000 factory calls and 1,998,003 dependency-port reads**, with fail/abort injected at each module. Eight compiler/runtime/incremental stages passed. This is substantive construction, cleanup and source-growth evidence. It is not a count of concurrent agent workers or independently released plugin packages. [C3]

The retained EF repetition's 71.34 s cold compile and 34.22 s supervised runtime are different from the faster upstream Oct23 observations. Different subject bytes/environment/driver receipt preclude labeling the difference a measured speedup. The inner full-smoke timer is narrower than the full runtime-stage timer. There is no RSS series or editor SLO in that receipt. These distinctions are already correctly recorded by the internal lane.

### Current live-instance proof

The source prepares a graph once: one source input declaration and one receiver module declaration. It creates all 1,024 scopes before awaiting factories, checks 1,024 distinct root objects and exactly 512 live subscriptions on each of two independent borrowed emitters. Repeated identical values are kept as separate event occurrences. Closing half leaves siblings receiving correctly; closing the rest removes every subscription; repeat close avoids double disposal; a fresh scope reuses the template without reviving the old receiver. [C1]

That result closes an actual lifetime/reference-custody question. “One template” does not make the 1,024 instances imaginary. Equally, synchronous `Set` iteration over tiny callbacks does not exercise asynchronous queues, rate control, hung host calls, slow consumers, external effects, grants, process faults or independently authored dependency closures. It is model channel separation, not authenticated product Tenant isolation.

The internal lane retrieved successful exact-SHA CI and 64/64 job success for #229, with all nine Assembly OS/runtime lanes successful. It independently inspected three cross-OS logs containing the named live test; all-nine named-test execution is additionally reported by the upstream inspected-log record. Preserve that distinction rather than stating this critic independently inspected every log. [C2]

### Dense graph and depth: important evidence, narrower subject

The current private-component integration test covers **500 declarations, 1,496 bindings, 23,821 provider occurrences, 22,824 unique adjacency edges and depth 500**, with an ordered-many window of 48. It runs real admission, semantic analysis and canonical plan output, compares the complete independently expected plan/digest under permutations, rejects a removed binding, and verifies that reversing significant many order changes the expected plan/digest. Literal chain companions exercise depth 2,048 and rejection at 2,049. [C5, C6]

The same fixture's N1000 sizing observation is explicitly `static-fixture-oracle-no-production-subject`; its 48,821 occurrences and 46,824 adjacency edges must not be promoted to an executed current compiler/product run. The older reviewed record reports a private traversal fixture with 4,096 nodes/258,048 edges and bounded diagnostic storm. Its milliseconds are historical fixture observations, not a public compiler or application SLO. [C6, C7]

Current graph source has iterative traversal, indexed vertices, deduplicated adjacency, a ready queue and explicit traversal counters. That is relevant algorithmic discipline. It does not make all compilation O(N+E): admission, normalization, sorting, canonical bytes, output size and product construction also consume resources. There is no measured bottleneck here requiring a new resolver, native rewrite or distributed graph engine. [C10]

## 3. The axes cannot be collapsed into one module count

| Axis | Why it changes the product decision |
|---|---|
| Installed metadata versus selected closures | Lazy selection can keep 1,000 installed packages cheap only if discovery is actually inert and indexed. Installed count does not determine imports, factories or execution realms. |
| Graph nodes, occurrences, distinct edges and fan-out | Multiple slots can repeat a provider-to-consumer pair. A graph can have modest nodes but large declaration/schema/output bytes. High invocation fan-out is a separate runtime multiplication. |
| Distinct implementations and release trains | Repeating one correct template establishes scope behavior; independent authors add version skew, package-copy identity, incompatible DTOs, side effects and incompatible assumptions. |
| Live instances, tenants, generations and replicas | A shared immutable plan can be reused while every instance still owns state, subscriptions and grants. Per-cohort caps do not cap a deployment. |
| In-flight/queued work and external latency | A finite construction campaign can pass while slow dependencies cause unbounded waiting work under ordinary offered traffic. Admission/rejection/backpressure belongs to the actual product owner. |
| Retained failures, caches and artifact revisions | A clean successful close says little about failed setup, cleanup debt, late settlement or stale artifact/cache retention. Unresolved custody cannot be safely “fixed” by silently forgetting its references. |
| Model-visible tools and editor/author experience | One plugin may add many tools or none. Compiler success is distinct from navigation/completion responsiveness; smaller model context can reduce discovery recall. |

**Pure capacity reasoning, not a measurement:** if independently instantiated units U run for tenants T with retained generations G and replicas R, the potential instance count is U×T×G×R before in-flight work and queues. A per-cohort cap only bounds one factor. Memory is more usefully decomposed into catalog/plan metadata, live instance state and handles, buffers/queues, retained attempts/debt, and retained artifact/cache bytes. The test's 1,024 scopes do not establish costs for any other component. Sharing a physical realm can reduce overhead but also changes the failure and authority boundary; do not choose it from instance-count arithmetic alone.

The first product envelope should name these quantities at the actual supported workload. It does not need to promise every axis at 1,000, every plugin combination, universal hot unload or hostile isolation.

## 4. Ownership critique: preserve the architecture, make it concrete

The industry mechanisms support the accepted split, particularly Backstage's small owned points and attributed startup, VS Code's activation/host distinctions and IntelliJ's lifetime discipline. The research does not establish that these products meet our desired fleet target, nor that we already surpass them. Their transferable value is explicit contracts and operational mechanisms.

Keep GM authoritative for declaration selection, graph validation/construction and existing resource semantics. EF may define neutral artifact/protocol/conformance vocabulary. The product owns the actual tool/provider/UI point, conflict algebra, grants, readiness, admission, accepted-work recovery and state. The existing execution owner retains process/resource/artifact custody. A proposed field or adapter should identify which existing owner consumes it; a new “manager” with its own registry, lifecycle state and retries is a sign of duplicate ownership, even if called neutral infrastructure.

Two guardrails are particularly useful:

1. A conformance example should test an invariant at the owning boundary. It must not require an ordinary provider author to implement Host retirement or durable publication just to add a tool/provider. A resource scope is necessary where resources are acquired, not ceremony for pure mappings or contract packages.
2. The optional Temporal adapter should invoke the same product-owned operation. It must not become a second admission/replacement state machine; ordinary module calls remain ordinary. No source evidence in this review warrants reopening the separate application workflow choice or replacing the prior Rust keeper direction.

Deep customization without forks is conditional on a useful public seam and its compatibility policy. It cannot guarantee that every future request fits a pre-existing hook. An absent invariant or extension point can require an upstream API change without representing architectural failure.

## 5. Five decision-changing experiments, with stopping conditions

These are proposals, not executed results or implementation authorization. **Start with experiment A.** Reuse that seam for B–D when applicable. E waits for an actual model-facing catalog. None requires a second framework.

### A. One product point, two separately supplied packed contributors

Choose an existing useful provider/contribution family and its current approved artifact baseline. Supply two independently packed implementations, including one older supported producer. Exercise explicit selection, required/optional absence, duplicate singleton/key conflict, order reversal, and failure during product-owned connection after registration. Capture the provider/point/artifact/version in diagnostics. If there is a real authoring slowdown, use this source graph for a bounded cold/incremental and one representative editor action; do not extrapolate command-line compiler time into IDE performance.

**Decision:** does the accepted narrow point support actual customization and compatibility without deep imports or a competing container? **Stop:** the ordinary external author can contribute and replace through the point; valid combinations work and invalid ones fail before readiness with actionable provenance. Only widen the seam when a real unsupported customization asks for it. Do not demand every N100/500/1000 row before this smaller initial envelope. [C8]

### B. Fixed artifact plus current authority on the actual handoff

Use the retained substitution falsifier at the real execution handoff: entry, transitive helper and an admitted prepared call. Change source/installation revision or remove a grant after discovery/preparation. Include a second tenant/project identity using the same visible tool/provider name. The product decides the semantics for already accepted work; verification metadata does not grant current authority.

**Decision:** can an admitted identity execute different bytes or borrow another authority's cached eligibility? **Stop:** the actual execution is bound to the admitted artifact/generation or rejects before useful capabilities/effects; call-time authority and accepted-work disposition remain explicit. Do not add another verifier/loader ledger if the existing execution owner can close custody.

### C. Stop, late settlement and retained failure at that same receiver

Begin stop with one accepted operation; attempt new ingress; let an old callback/factory settle late; inject one asynchronous cleanup failure and a teardown callback that would normally trigger rediscovery/reconnection. Reuse the original rejection-plus-absence oracle and preserve recovery disposition for previously accepted work. Resource reports, execution disconnection and physical exit remain separate observations.

**Decision:** does the real product seal admission and retire one generation without resurrection, lost accepted work or forgotten custody? **Stop:** no post-seal admission, old callbacks cannot attach to a new generation, retained effects are reconciled, and failed cleanup remains visible/retriable debt at its existing owner. A timeout must not be reported as physical release.

### D. Aggregate capacity and noisy/slow sibling under a bounded product workload

Only after the real path exists, declare a small actual envelope spanning at least the necessary tenant/cohort distinctions and a bounded overlap/debt case. Ramp offered work to the chosen limit while one provider is slow or noisy. Observe aggregate queue/admission, memory/handle/process counts, failure attribution and the unaffected operation's declared response budget. A synchronous emitter benchmark cannot answer this question.

**Decision:** can the current owner enforce aggregate budgets and preserve the useful operation under the selected profile, or must the execution placement/pool boundary change? **Stop:** overload rejects/slows according to the product policy; retained attempts/debt remain inside the declared aggregate envelope; unaffected behavior meets the declared workload target. Change realm placement or add caching only if the observed failure identifies it as the relevant seam. A small repeat/churn sequence can resolve retention slope; no indefinite soak/research project is implied.

### E. Actual catalog discovery and model selection with callable capabilities held fixed

At the first real product tool projection, add inert irrelevant descriptors while holding callable capabilities fixed. Compare the selected provider's existing eager/deferred mechanism using a fixed task corpus. Include near-duplicate names, same visible name from different authorities, stale catalog revisions and removed grants. Count transport bytes, model-context bytes/tokens, search/call latency, relevant-tool recall, wrong tool/argument selection and receiver authorization rejection separately.

**Decision:** does progressive disclosure improve the actual product's context/latency tradeoff without hiding useful tools or weakening invocation authority? **Stop:** the representative catalog remains usable within its explicit budget and stale/unauthorized selections cannot cause effects. Do not build a synthetic search framework whose own lookup oracle is the only consumer. Vendor improvement percentages or small model samples are not our success rate.

## 6. Reliability, cost and superiority claims

The comparisons justify **fit judgments**, not a scoreboard. A trusted static module and a hostile Wasm/process plugin have different guarantees and costs. Reliability 8/10 can communicate an engineering preference only when its failure/trust assumptions are alongside it; it cannot be converted into uptime, probability of success or a weighted “best ecosystem” rank.

Current product production/integration LOC is **not estimable from this review**, because the actual first seam and deletable/replaced code were not inventoried here. Older 400–1,000 production / 800–1,800 test ranges are explicitly narrow historical planning ranges, not new source-based estimates. Significant alternatives should separately account for production, integration and tests, state at least ×2 uncertainty where a scoped estimate is possible, and subtract responsibilities already owned elsewhere. Test-only snippet ranges are not the cost of a mature third-party ecosystem. No new sizing numbers are invented by this critic.

The right evidence of an industry-leading objective would be independently reproducible performance and failure behavior within a published envelope, actual external authors completing supported customizations, compatibility across declared releases, and diagnostics that make supplier/authority/resource ownership clear. Current results are valuable building blocks toward that objective. There is no empirical basis for a superiority or fleet-availability claim yet.

## Source ledger

Primary local sources were inspected; CI/registry/archive facts attributed to the internal lane were not independently re-fetched by this critic. External industry facts are contextual use of the already sourced research reports, not new primary-source verification in this lane.

| ID | Source and evidence kind |
|---|---|
| C1 | Source inspected: [live-instance-custody.test.ts at GM 5fb83478](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/tests/assembly/live-instance-custody.test.ts). |
| C2 | Existing CI retrieved by internal lane: [#223 CI41452952298 attempt2](https://github.com/agent-teams-ai/get-modular/actions/runs/41452952298), [#229 CI41971404753](https://github.com/agent-teams-ai/get-modular/actions/runs/41971404753). Exact source/three cross-OS log links are in `internal-industry-and-scale-status.md` §4. |
| C3 | Source/document inspected: [EF static/restart validation at 70f03d3](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/static-composition-and-controlled-restart-validation.md). Internal lane independently inspected its [frozen archive](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/evidence/static-restart-validation-20261025.tar.gz). Upstream [Oct23 receipt](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/tests/qualification/consumer-fixtures/growth/descriptor-aggregate-evidence/2026-10-23/observations.json) separately inspected; do not mix its timings into the EF repetition. |
| C4 | Current source/release distinction: `internal-industry-and-scale-status.md` §§1,4, primary [Core registry](https://registry.npmjs.org/@get-modular%2fcore), [Assembly registry](https://registry.npmjs.org/@get-modular%2fassembly), [PR229](https://github.com/agent-teams-ai/get-modular/pull/229). Registry values were retrieved by that lane on 2026-11-05. |
| C5 | Source inspected: [current private scale integration test](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/packages/core/tests/features/composition-semantics/scale-integration.test.mjs). Source defines actual pipeline/oracles; no fresh execution in this lane. |
| C6 | Source inspected: [resource-boundary-vectors.json](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/architecture/qualification/v1/resource-boundary-vectors.json), [resource-profile-v2 helper](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/packages/core/tests/qualification-support/support/resource-profile-v2.mjs). P500 expected counts and explicit sizing-only qualification labels. |
| C7 | Historical documented executed fixtures inspected: [V1 contract council/resource profile](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/qualification/v1-contract-council-and-resource-profile.md). Its older review explicitly predates production-compiler conformance; timings remain historical. |
| C8 | Accepted authority inspected: [Orchestrator ADR-0117 at current main](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/docs/decisions/0117-reconcile-mandatory-module-composition.md). |
| C9 | Current contract/source inspected: [common Assembly](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/architecture/common-assembly.md), [typed-build custody correction/exclusions](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/qualification/typed-build-custody-2026-11.md), [Resources public types](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/packages/resources/src/features/scope/types.ts). |
| C10 | Current algorithm source inspected: [selected-graph.ts](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/packages/core/src/features/composition-semantics/selected-graph.ts). |

## Final review stop conditions

Approve the research synthesis when it (1) credits finite N1000 and simultaneous 1024 separately, (2) distinguishes current source/release/adoption, (3) does not erase dense/depth semantic evidence, (4) states the product envelope remains unqualified, (5) recommends a bounded real seam under existing owners rather than a second runtime, and (6) labels proposals, scores, timings and LOC honestly. A current research document does not need every proposed future test completed before it can be published.

### Final synthesis wording review

The completed parent synthesis was read after the initial report. It satisfies the architectural and claim-scope stop conditions: credit for actual 1024 live instances is visible; product capacity and external-author qualification remain separate; source/release/adoption are distinguished; dense/depth evidence is retained with narrower scope; the proposed work uses existing owners and concrete product boundaries; scores and the 150–500 integration / 600–1,400 fixture LOC range are explicitly conditional historical planning, not a new ecosystem estimate.

Two evidence-fidelity wording corrections were sent to the parent before publication:

1. Name the historical EF N1000 repetition's exact frozen public Core/Assembly 0.7.0 subject (and, where useful, Resources 0.2.1 / Conformance 0.5.0), with `b70ba393` driver and registry-dist replacement. “Current descriptor-union recipe” alone beside a current latest-version table could be misread as current-main or latest-0.7.1 qualification.
2. Describe dense P500/depth work as **source-inspected test definitions** unless a named executed receipt is independently inspected. This critic did not rerun or inspect a named dense-test log; the source's complete oracles and exact vectors are inspected evidence. Link the primary vectors and historical resource-profile record for the counts.

No additional architecture blocker was found. Incorporating those clarifications is sufficient for this critic's publication disposition; no new tests or scale campaign is requested.
