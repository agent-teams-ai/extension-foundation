# Mature extensibility ecosystems: mechanisms that survive scale

Research date: 2026-11-05. Independent lane based on the full shared context. Primary documentation and source inspected; no competitor installed or executed; no production changes. This is a mechanism comparison, not a benchmark or ecosystem ranking.

## Decision-relevant result

The mature systems strengthen our accepted ownership model. Keep Get Modular as the sole composition system. Extension Foundation should specify neutral contracts, artifact/protocol trust and conformance; products should own narrow extension points, conflict policy, admission, readiness and recovery; the existing execution owner should retain physical custody. A new generic plugin host would duplicate responsibility without supplying the missing evidence.

The largest remaining gap is **a real product seam with independently supplied contributions**, not another module-count demonstration. The next proof should combine deterministic conflict rejection, contributing-module attribution, product readiness, fixed-artifact custody and explicit cleanup debt. Existing descriptor-union results establish only their recorded construction/compile/runtime workload; this lane adds no executed capacity evidence.

Five distinctions matter:

1. Installed/discovered, selected, imported, registered, initialized, ready and serving are different states. Lazy activation reduces work; it does not prove admission or safe replacement.
2. Typed extension points reduce API coupling; TypeScript types alone do not constrain hostile code or establish compatible behavior.
3. A process, worker, class loader and dependency scope offer different boundaries. Placement is not a grant model.
4. Owning a registration is insufficient unless its callbacks, tasks, handles and retained references share the intended lifetime.
5. Compatibility is a maintained pipeline with provenance and diagnostics, not a version string checked once.

## 1. VS Code: declarative reach, selective activation, bounded host isolation

### Documented mechanism

The manifest separates contribution metadata from activation declarations and code entry points. Activation can be tied to a command, language, view or tool invocation; `*` starts extensions eagerly, while `onStartupFinished` schedules after initial startup activation. Since VS Code 1.74, several contributed items imply their activation events. `activate()` is invoked once when an applicable event occurs. The author is explicitly advised to activate only when needed [S1]. This gives us a concrete model for keeping N installed descriptors distinct from K activated providers.

VS Code can place extensions in local Node.js, remote Node.js or browser WebWorker hosts. Runtime capability, installation location and `extensionKind` influence placement [S2]. Its official high-CPU guide explicitly says extensions in one host are not isolated from each other: one extension can occupy the JavaScript thread and stall the others. VS Code detects unresponsiveness and collects a short CPU profile [S3]. Thus a responsive editor UI does not establish a responsive extension fleet.

The security documentation is unusually explicit: the extension host has the editor's permissions, including filesystem access, network requests and spawning processes. Publisher trust, signatures, scanning and blocklisting improve distribution trust but are not per-extension runtime capabilities [S4]. Do not borrow the phrase “extension host” as evidence of hostile isolation.

The official API guidelines favor a data model and provider interfaces so the product controls invocation and multiple-provider handling. They also call for cancellation tokens, validation of returned data and translation into protocol-specific objects instead of forwarding arbitrary extension objects [S5]. These are useful product seam rules, not an argument for putting domain dispatch into GM.

### Lifetime and compatibility traps

`ExtensionContext.subscriptions` disposes registered items at deactivation, but asynchronous `dispose()` functions are **not awaited** [S6]. The separate activation documentation tells authors to return a promise from asynchronous `deactivate()` [S1]. A registry accepting a `dispose` shape therefore must not be mistaken for proof that cleanup completed. Our real product operation needs an explicit asynchronous completion/timeout/debt result at its existing owner.

The manifest's `engines.vscode` expresses host API compatibility. `extensionDependencies` is a list of extension IDs; it is not a general versioned contract negotiation graph [S7]. Proposed APIs are separately gated as unstable and unsuitable for Marketplace publication [S8]. This is a useful stable/experimental distinction for EF contracts, but our own producer compatibility matrix still needs execution.

At ecosystem scale, debugging is a product feature. VS Code supplies Running Extensions, CPU profiling and an Extension Bisect workflow that disables subsets and reloads the window to isolate a culprit [S9]. Bisect is useful for reproducible isolated failures; as an inference, dependency-sensitive or multi-plugin interactions require preserving the selected dependency closure and recording the whole failing set. A “single culprit” tool is not a proof that every failure has one culprit.

### Transfer to our ownership

- **GM:** inert descriptor inventory, graph selection and graph errors. Preserve stronger inertness than merely importing a JavaScript package and delaying its `init()`.
- **Product:** select/activate only needed providers; own deadlines, fan-out limits, merge/precedence rules and validated DTOs.
- **Execution owner:** isolate a noisy or failed extension where justified and expose actual process/resource status.
- **EF:** versioned boundary contracts and reproducible diagnostic envelopes; no replacement dispatch/runtime framework.

## 2. Backstage backend: the closest match to product-owned customization

### Documented mechanism

Backend modules target one plugin in the same backend instance. They consume extension points from a separate plugin library package, avoiding a direct dependency on the plugin implementation and duplicate plugin installation. All contributing modules complete initialization before the target plugin's initialization. Extension points are not to be used after the module's `init()` resolves [S10]. This is a registration barrier with controlled startup, well aligned with our acceptance of controlled restart.

Current extension-point guidance recommends several small interfaces instead of a few large ones. The product exposes the points and owns their implementation. It may offer additive registration, or a single override setter that rejects a second supplier. For an incompatible change, the guidance recommends deprecating the old point and creating another name/version. A particularly useful current feature is a **factory per consuming module**, whose context can report startup failure against that module when plugin-owned connection work fails later [S11].

This attribution is valuable: “plugin failed” loses the supplier that registered the bad provider. It does **not** decide whether a failed provider is optional, whether product readiness is allowed, or whether partially initialized resources need cleanup. Those remain application semantics.

### Source inspection, pinned

Backstage source was fetched through the GitHub connector at `c6395a54e68e1b4590e3db1f0a5d29f9ec0b0aa1` (commit timestamp 2026-11-05T17:13:15Z). In `BackendInitializer.ts`, the inspected paths reject use of another plugin's extension point and use outside a module; associate the factory callback with plugin/module result amendment; reject feature addition after startup has begun; detect module cycles; and initialize modules by parallel topological traversal [S12]. These are source observations, not executed tests.

The feature-loader docs describe programmatic selection and loading, including “runtime” loading, with only root-scoped service dependencies [S13]. The inspected `add()` guard is a useful corrective: startup-time dynamic selection/import must not be presented as live topology mutation after start. Also, importing arbitrary JS already executes top-level module code. A delayed `register`/`init` convention alone does not meet our stronger inert-discovery requirement.

### Isolation and compatibility limits

Backstage's backend-plugin architecture describes independent plugins communicating over network interfaces and permitting deployment split across backend instances [S14]. Its threat model explicitly says builders/plugins are trusted code, that Backstage does not sandbox them, and that plugins sharing host or database access do not acquire a security boundary [S15]. The latter is the correct security interpretation. Architectural microservice-style separation in a single backend is not hostile isolation.

Lifecycle hooks explicitly support shutdown cleanup, including clearing a timer [S16]. This is a useful ownership convention, but the cited guide does not establish rollback of failed initialization, cancellation of already accepted external effects or arbitrary-child process cleanup.

Backstage's release policy deals with hundreds of packages through verified umbrella releases plus explicit package-skew rules. Individual packages use semver, while the umbrella release does not make the same promise. A subtle policy exception: stable built-in service/utility interfaces protect **consumers**, while producer implementations can break with `BREAKING PRODUCERS`; alpha/beta exports may change without deprecation [S17]. Our conformance must test third-party implementations of a point as producers, not only product calls as consumers.

### Transfer to our ownership

Borrow narrow point design, one explicit owner, registration barriers, duplicate rejection, provider provenance and separate versioned points. Do not transplant Backstage's composition layer or assume its packages are inert. Model each product point's cardinality explicitly: additive set, keyed unique set, exactly-one selected implementation, or an explicitly ordered pipeline. “Last module wins” and a universal mutable hook bus hide conflicts until deployment order changes.

## 3. IntelliJ: unload is a resource-and-reference discipline

### Documented mechanism

IntelliJ registers specific interface or bean extension points in descriptors. Its authoring guidance tells extension implementations to be stateless, keep runtime state in services, avoid constructor initialization and avoid static initialization [S18]. This shows why a declaration/construction distinction is useful even in a mature, deeply customizable in-process system.

Dynamic support is conditional. It requires dynamic extension points, no legacy components and no service overrides, among other restrictions. Native-library requirements can require restart; unload failure falls back to asking for restart. Loading/unloading occurs on the event-dispatch thread under write action. The platform supplies a dedicated unload log category and class-loader heap-reference diagnosis [S19]. This is evidence against promising universal in-process hot reload. Our controlled restart policy is a legitimate reliability choice, not a missing feature to disguise.

A dynamic point must either re-enumerate extensions each use without storing instances, or use an extension-point listener to update retained structures. Error handling should attribute causes to plugins via `PluginException` [S20]. Dynamic unload therefore reaches every consuming cache and callback, not just the loader's registry.

### Resource ownership lesson

IntelliJ's Disposer manages parent-child lifetime trees and disposes children first. Services are disposed on plugin unload, but descriptor extensions are not automatically disposed. Crucially, plugin code must not use the longer-lived `Application` or `Project` directly as parent disposable, because its resources then survive plugin unload. Debug registration can capture allocation stacks and shutdown checks report undisposed resources [S21].

This is the most direct lifetime lesson for our agent modules: a task, subscription, callback or capability should attach to the **attempt/generation that owns it**, not an application singleton merely because the application can eventually close it. Generation-scoped resource accounting belongs to existing GM/resource semantics and the execution owner; the product decides when admission is sealed and how accepted work is recovered. Do not add a second disposal manager.

### Dependency and compatibility lesson

Dedicated plugin class loaders allow different library versions, but declared plugin dependencies also connect class-loader lookup. Libraries using `ServiceLoader` require correct context-class-loader setup and restoration [S22]. This is dependency isolation, not proof of a security sandbox.

Current dependency docs explicitly state that a non-bundled plugin dependency cannot specify a minimum/maximum dependent-plugin version, and warn that an omitted runtime descriptor dependency can produce `NoClassDefFoundError` despite a successful build [S23]. Compilation and resolution against one SDK are therefore weaker than qualified runtime combinations.

Plugin Verifier checks binary compatibility against IDE builds and integrates into CI/Marketplace [S24]. It does not claim to prove semantic correctness, startup/teardown behavior, resource bounds or multi-plugin interference. Our equivalent should distinguish structural checks, protocol conformance, product behavior and lifecycle evidence instead of labeling all four “compatible.”

## 4. Process RPC and Wasm: selective boundary tools

HashiCorp `go-plugin` supplies subprocess RPC, version negotiation, logging and optional checksum/TLS, plus reattachment for cooperating host/plugin upgrades [S25]. Its handshake tutorial explicitly describes the magic-cookie handshake as a UX check, not a security feature [S26]. This is a good model for separating wire compatibility, process availability and trust.

Pinned `go-plugin` source at `415e29b9562b51ba63782ecbd719927b022c43eb` (2026-11-02T07:24:08Z) documents that checksum trust comes from an authoritative source **and** that installation must prevent binary modification between verification and execution. `SecureConfig` cannot be combined with reattachment; `SkipHostEnv` can omit inherited environment; client cleanup remains an explicit responsibility [S27]. This directly corroborates our existing artifact-substitution counterexample. Checksums do not fix mutable-path custody. Reattachment adds physical-identity/custody questions rather than removing them.

Wasmtime is directly useful as a bounded optional research lane for compute or transformation plugins. WASI filesystem access is capability based [S28]. However, fuel/epoch interruption does not interrupt code blocked in a host call; the embedder must handle that, commonly with asynchronous host functions and timeout. The inspected API docs are the moving `52.0.0-dev` build, not an approved dependency pin [S29]. `ResourceLimiter` bounds instance resources in a Store but explicitly excludes some runtime and embedder memory; CPU uses different mechanisms [S30].

Consequently, “Wasm sandbox + timeout + memory limit” is not a complete product guarantee. EF can research a narrow protocol and grant description; the product must bound host operations and external effects; the existing Rust keeper/execution owner retains physical resources. No evidence here justifies moving all modules to Wasm or all code to Rust.

## 5. Consequential alternatives — judgment, not measured uptime

Scores are ordinal engineering judgments: confidence = strength/fit of this recommendation; reliability = expected fault containment under its stated trust model; complexity = implementation/operational burden (10 is harder). They are not cross-vendor uptime comparisons. Production code was not inspected in this lane, so honest production/integration LOC is **not estimable**; copying third-party library size would be misleading. Approximate test-only fixture ranges below have at least ×2 uncertainty and are not authorization to implement.

| Alternative and scope | Confidence /10 | Reliability /10 | Complexity /10 | Incremental production LOC | Integration LOC | Test-only LOC, narrow proposed fixture |
|---|---:|---:|---:|---|---|---|
| Product-owned typed points, pre-start barrier, controlled restart using existing GM | 9 | 8 for trusted modules | 4 | Not estimated: product seam not inspected | Not estimated | 150–350: duplicate/singleton conflict, order reversal, required/optional provider failure and late registration cases |
| Generic mutable hook bus with global priorities and arbitrary object mutation | 3 | 3 for large independently authored fleets | 7 over lifecycle | Not estimated | Not estimated | 100–250: two order permutations and one reentrant mutation counterexample only; does not qualify a whole bus |
| Existing execution-owner process boundary for selected untrusted/noisy extensions; narrow RPC | 8 | 8 for process faults; hostile security requires OS qualification | 7 | Not estimated: platform/custody adapters unknown | Not estimated | 200–500: crash, hang, protocol mismatch, environment omission and process-exit observation; excludes arbitrary descendants/security certification |
| Wasmtime for one pure transformer with narrow imports | 6 | 8 within enforced sandbox/import assumptions | 7 | Not estimated: host ABI and embedding unknown | Not estimated | 200–500: loop, guest growth, host-call hang, denied file access and oversized output; excludes full security audit |
| Universal in-process unload across arbitrary module state | 2 | 3 without pervasive reference/lifetime discipline | 10 | Not defensibly estimable | Not estimated | Not meaningfully bounded: every retaining product seam participates |

No score compares our measured implementation favorably to an incumbent. The proposed static path is recommended because it fits accepted constraints and exposes less replacement machinery, not because a fleet SLO has been demonstrated.

## 6. Highest-leverage missing product experiments

These are **unexecuted proposals**, to be selected against existing product code, not another generic framework backlog.

1. **One real point, two independent providers.** Select an existing agent product point with actual value: tool provider, model-routing policy, context source or storage feature. Supply conflicting keyed entries and singleton overrides; reverse discovery order; inject failure during product-owned connection after registration. Pass condition: stable diagnostic identifies both suppliers/point/version, no accidental last-writer behavior, and product-required vs optional readiness policy is explicit. GM validates composition; product owns semantics; EF defines reusable conformance vocabulary. Backstage provenance is the strongest mechanism to borrow.

2. **Real product fixed-artifact admission.** Reuse the existing mutable-path substitution falsifier against the actual product handoff, including transitive imports/helpers. Pass condition: executed bytes belong to the admitted artifact/generation, or activation is rejected with no useful capability granted. Complete hashing alone is not the pass condition. Artifact custody remains at the existing execution owner; EF records artifact/protocol evidence.

3. **Generation-scoped resource and late-effect test.** At the same real seam, register a callback, long-running task and async disposer; begin controlled stop while one request is accepted, then resolve it late. Pass condition: no post-seal admission; accepted work retains explicit recovery disposition; old callbacks cannot silently attach to the new generation; failed cleanup remains visible debt; physical exit is observed separately. An external effect committed before cancellation must remain accounted for, not reported as undone.

4. **Compatibility in both directions.** Use one older valid contributor against the current product and a current contributor against the oldest supported contract. Include missing capability, duplicate package/reference identity, incompatible protocol and invalid DTO. Pass condition: supported combinations run; unsupported combinations fail before readiness with actionable provenance; producer changes are detected. Avoid an impossible promise to test every subset of thousands of modules. Build a representative seam matrix plus exact deployment lock/artifact records.

5. **Noisy-extension diagnosis within the accepted execution boundary.** Make one extension consume CPU, hang in a host call or produce excessive output. Pass condition: record selected/activated/ready sets, host placement, dependency closure, invocation latency/timeout, resource owner and cleanup result. Assess unaffected product operations under declared load. This is where module-count evidence could become product availability evidence; a descriptor-only N1000 result cannot substitute for it.

## 7. Failure patterns to preserve for agents

Keep reusable negative examples alongside successful recipes: eager wildcard activation; startup work hidden in constructors/imports; provider instances retained in long-lived caches; resources attached to an application lifetime instead of plugin generation; unawaited asynchronous disposal treated as completed cleanup; last-writer override disguised as dependency order; host placement labeled security; binary compatibility labeled semantic compatibility; checksum verification labeled fixed artifact execution; RPC disconnect labeled process exit. Each should identify the owner, violated invariant, falsifier, remaining uncertainty and safe bounded alternative.

## Source ledger

All web sources were freshly opened/searched 2026-11-05. `D` = official documented behavior; `S` = source inspected. Web reference IDs are supplied so the root researcher can independently reopen the exact URL before using final citations. Some pinned GitHub URLs are unavailable to the web fetcher but were successfully fetched through the GitHub connector; do not cite a failed web fetch as evidence. No empirical competitor benchmark is claimed.

| ID | Kind | Exact URL and reference / revision |
|---|---|---|
| S1 | D | https://code.visualstudio.com/api/references/activation-events — `turn227search1` |
| S2 | D | https://code.visualstudio.com/api/advanced-topics/extension-host — `turn227search2` |
| S3 | D | https://github.com/microsoft/vscode/wiki/Explain-extension-causes-high-cpu-load — `turn243view1`, `turn245view4`; page edited 2026-06-26 |
| S4 | D | https://code.visualstudio.com/docs/configure/extensions/extension-runtime-security — `turn227search0`, `turn255view3`; page date 2026-11-04 |
| S5 | D | https://github.com/microsoft/vscode/wiki/Extension-API-guidelines — `turn235view4`, `turn238view5`; page edited 2025-12-02 |
| S6 | D | https://code.visualstudio.com/api/references/vscode-api — `turn238view6`, ExtensionContext.subscriptions |
| S7 | D | https://code.visualstudio.com/api/references/extension-manifest — `turn232view5`, `turn233view6`, `turn256view1` |
| S8 | D | https://code.visualstudio.com/api/advanced-topics/using-proposed-api — `turn254view3` |
| S9 | D | https://github.com/microsoft/vscode/wiki/Performance-Issues — `turn232view6`, `turn233view7` |
| S10 | D | https://backstage.io/docs/backend-system/architecture/modules/ — `turn227search4`, `turn229search0` |
| S11 | D/S docs | https://backstage.io/docs/backend-system/architecture/extension-points/ — `turn232view0`, `turn233view3`, `turn235view2`; source fetched at https://github.com/backstage/backstage/blob/c6395a54e68e1b4590e3db1f0a5d29f9ec0b0aa1/docs/backend-system/architecture/05-extension-points.md |
| S12 | S | https://github.com/backstage/backstage/blob/c6395a54e68e1b4590e3db1f0a5d29f9ec0b0aa1/packages/backend-app-api/src/wiring/BackendInitializer.ts — GitHub connector `fetch_file`; source lines 293/302/355/504/509. Moving branch web reference https://github.com/backstage/backstage/blob/master/packages/backend-app-api/src/wiring/BackendInitializer.ts — `turn238view0`, `turn241view0`, `turn241view1`, `turn243view6` |
| S13 | D | https://backstage.io/docs/backend-system/architecture/feature-loaders/ — `turn232view1` |
| S14 | D | https://backstage.io/docs/backend-system/architecture/plugins/ — `turn235view0` |
| S15 | D | https://backstage.io/docs/overview/threat-model/ — `turn255view0` |
| S16 | D | https://backstage.io/docs/backend-system/core-services/lifecycle/ — `turn232view2` |
| S17 | D | https://backstage.io/docs/overview/versioning-policy/ — `turn254view4`, `turn256view2` |
| S18 | D | https://plugins.jetbrains.com/docs/intellij/plugin-extensions.html — `turn254view1` |
| S19 | D/S docs | https://plugins.jetbrains.com/docs/intellij/dynamic-plugins.html — `turn233view0`, `turn255view2`; pinned docs fetched at https://github.com/JetBrains/intellij-sdk-docs/blob/2407264b3c341a0558344c8a9ff17a5ce1b47f99/topics/basics/plugin_structure/dynamic_plugins.md (repo commit 2026-11-05T15:25:17Z) |
| S20 | D | https://plugins.jetbrains.com/docs/intellij/plugin-extension-points.html — `turn232view3`, `turn233view4` |
| S21 | D | https://plugins.jetbrains.com/docs/intellij/disposers.html — `turn232view4`, `turn233view5`; page date 2025-08-21 |
| S22 | D | https://plugins.jetbrains.com/docs/intellij/plugin-class-loaders.html — `turn254view0` |
| S23 | D | https://plugins.jetbrains.com/docs/intellij/plugin-dependencies.html — `turn254view2` |
| S24 | D | https://plugins.jetbrains.com/docs/intellij/verifying-plugin-compatibility.html — `turn233view1` |
| S25 | D | https://github.com/hashicorp/go-plugin — `turn232view7`, `turn233view8` |
| S26 | D | https://github.com/hashicorp/go-plugin/blob/main/docs/extensive-go-plugin-tutorial.md — `turn233view2`, `turn238view7` |
| S27 | S | https://github.com/hashicorp/go-plugin/blob/415e29b9562b51ba63782ecbd719927b022c43eb/client.go — GitHub connector `fetch_file`; source lines 174/249/270/324/388. Moving branch web reference https://github.com/hashicorp/go-plugin/blob/main/client.go — `turn238view1`, `turn241view2`, `turn241view3`. Commit metadata from connector https://api.github.com/repos/hashicorp/go-plugin/commits/main |
| S28 | D | https://docs.wasmtime.dev/security.html — `turn243view2`, `turn245view6` |
| S29 | D | https://docs.wasmtime.dev/api/wasmtime/struct.Config.html — `turn243view3`, `turn245view5`; observed `52.0.0-dev`, moving development docs |
| S30 | D | https://docs.wasmtime.dev/api/wasmtime/trait.ResourceLimiter.html — `turn243view4`; observed `52.0.0-dev`, moving development docs |

### Explicit limits of this lane

No current product source integration was audited; no fresh fleet throughput, memory, startup, soak, hostile isolation or unload benchmark was run. No claim is made about thousands of simultaneously active agents or superiority over incumbents. A resolved issue was not used as a current defect. Extism was not separately inspected because direct Wasmtime limits were sufficient to identify the relevant embedding seam. Package pins, accepted ADRs and contracts are unchanged.
