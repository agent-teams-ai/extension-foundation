# Internal industry research and scale status — 2026-11-05

## Finding

The industrial research is substantial and reusable: the EF draft contains 20 primary comparison cases, 18 stable pattern/failure IDs, explicit ownership, independent criticism and several executed campaigns with preserved failures. Get Modular has progressed beyond descriptor-only qualification: its supported complete-map recipe passes bounded N1000 compilation/construction/smoke, and current main additionally executes a 1,024-simultaneously-live scoped-consumer correctness test on the existing runtime. These are different achievements. Neither establishes a thousand independently authored, installed, isolated or active product plugins, a thousand agent executions, or a product capacity envelope.

The latest GM production fixes and scale-path optimization are merged on main but are newer than current npm release bytes. Orchestrator's accepted module authority also changed after the EF October checkpoint: ADR-0117 reconciles the mandatory scope against ADR-0113's exact older package/CMS baseline. Updating the research must preserve these advances and the distinction between upstream capability, published artifacts and actual product adoption.

This lane performed read-only source/history/API/registry/archive inspection, plus the read-only `pnpm docs:info` after root made frozen dependencies available. No dependencies were installed, new tests executed, implementation edited or remote refs changed by this lane. Existing CI results below were retrieved, not rerun.

## 1. Exact current source and release identities

| Subject | Verified current identity | State and implication |
|---|---|---|
| EF research PR55 | [`70f03d3d9e134780f27268339a6729a7305a2363`](https://github.com/agent-teams-ai/extension-foundation/commit/70f03d3d9e134780f27268339a6729a7305a2363), branch `docs/plugin-research-hot-reload-20261021` | [PR55](https://github.com/agent-teams-ai/extension-foundation/pull/55) open, draft, unmerged. Normal git clone restored the complete clean checkout at the requested local path. Root owns later edits. |
| EF main | [`29ae5b0269d9d83f071344e3e18761ded04ff53d`](https://github.com/agent-teams-ai/extension-foundation/commit/29ae5b0269d9d83f071344e3e18761ded04ff53d) | Only change after PR55's base `39c72bf` is the alias-aware identity-workflow pin in #60. [README at this head](https://github.com/agent-teams-ai/extension-foundation/blob/29ae5b0269d9d83f071344e3e18761ded04ff53d/README.md) still explicitly says architecture foundation; no public runtime SPI or production package materialized. No new catalog implementation was found. |
| GM main | [`5fb83478dd7b95216be92c4d3077eddf2774eef8`](https://github.com/agent-teams-ai/get-modular/commit/5fb83478dd7b95216be92c4d3077eddf2774eef8) | Nov5 merged #229, after #223/#224/#227/#228. Public pre-1.0 composition packages exist; do not extend EF's architecture-only status to GM. |
| GM recipe/navigation PR210 | [`8249c674ad53458b31d6ad06803ceb76e29ff4c7`](https://github.com/agent-teams-ai/get-modular/commit/8249c674ad53458b31d6ad06803ceb76e29ff4c7) | [PR210](https://github.com/agent-teams-ai/get-modular/pull/210) remains open draft, unmerged and currently conflicting. Its source-check-only wording is historical. It is not the latest implementation head. |
| Orchestrator main | [`5a8496ce711909e381c5bc817fff5500be9a1761`](https://github.com/agent-teams-ai/agent-teams-orchestrator/commit/5a8496ce711909e381c5bc817fff5500be9a1761) | Nov5 #97 synthetic contract fixture. Earlier main includes ADR-0117 reconciliation and the real Agent Context PostgreSQL feature. Architecture-only cannot describe the entire repository without this scoped exception. |
| Orchestrator native Temporal PR90 | [`0af892165a023a274302f89b47ba514ab2915e59`](https://github.com/agent-teams-ai/agent-teams-orchestrator/commit/0af892165a023a274302f89b47ba514ab2915e59) | [PR90](https://github.com/agent-teams-ai/agent-teams-orchestrator/pull/90) still open, non-draft, unmerged; accepted decision and merge/publication are separate facts. |

Direct read-only npm registry queries on 2026-11-05 returned:

| Package | `latest` | Published UTC | Current-source distinction |
|---|---:|---|---|
| [Core registry](https://registry.npmjs.org/@get-modular%2fcore) | 0.7.1 | 2026-11-01 11:16:13.467 | Existing public version; current main fixes are later. |
| [Assembly registry](https://registry.npmjs.org/@get-modular%2fassembly) | 0.7.1 | 2026-11-01 11:19:03.534 | Same exact version pair as Core. |
| [Resources registry](https://registry.npmjs.org/@get-modular%2fresources) | 0.2.1 | 2026-10-21 14:06:52.379 | Nov4 deep-tree/ancestry fixes are newer. |
| [Observation registry](https://registry.npmjs.org/@get-modular%2fobservation) | 0.2.0 | 2026-10-21 14:12:21.435 | Nov4 iterative-data fixes are newer. |
| [Conformance registry](https://registry.npmjs.org/@get-modular%2fconformance) | 0.5.1 | 2026-11-01 11:20:17.381 | Nov5 layout/pin optimizations are newer. |
| [Lifecycle kernel registry](https://registry.npmjs.org/@get-modular%2flifecycle-kernel) | HTTP 404 | — | Source [manifest](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/packages/lifecycle-kernel/package.json) has `private: true`; still an unreleased candidate. |

All registry version objects above lacked `gitHead`; source equivalence must not be inferred from the manifest version alone. Current main retains pending [ownership changeset](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/.changeset/preparation-and-resource-ownership.md) and [root-alias changeset](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/.changeset/capture-preparation-root-aliases.md). The #229 PR explicitly excludes publication. The GitHub Releases API returning an empty list does not mean npm packages are absent.

## 2. What the retained 20 industrial cases cover

These are the 20 main comparison cases/sections already in EF, not 20 newly executed competitor evaluations or a census of all distinct technologies mentioned in supporting references. The primary source ledgers include immutable commits/tags, dated moving documentation and explicitly historical issues. Supporting GitLab/Chubby evidence and the later reuse/language/customization supplements are additional material, not a reason to inflate the original count.

| Record at EF `70f03d3` | Main cases | What agents can reuse |
|---|---|---|
| [OpenClaw audit](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/openclaw-plugin-and-reload-audit.md) | 1: OpenClaw, pinned `33ccaae2f522c3ae299aaf8b195fa166ab536bd8` | Inert discovery, instance/call authority, captured recovery bytes, retained work/physical cleanup, exclusive-resource availability tradeoff, import/cache limitations. Positive protections and fixed historical incidents retained. |
| [Plugin platforms](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/plugin-platform-reload-evidence.md) | 5: IntelliJ, OSGi, VS Code, Theia, Vault/go-plugin | Cooperative unload; refresh closure versus stale service references; activation versus install; compile-time customization versus runtime API; process execution versus product routing. |
| [Production reload systems](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/production-reload-system-evidence.md) | 7: Erlang/OTP, NGINX, Envoy, Node/browser workers, Vite, Wasmtime/Extism, Kubernetes/controllers | VM-specific code/state guarantees; process rotation; ACK/publication/drain distinctions; ESM retention; development HMR limits; instance custody; eventual convergence. |
| [Ecosystem scale](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/plugin-ecosystem-scale-and-composition.md) | 5: Backstage, JupyterLab/Lumino, Gradle, Jenkins, Chrome MV3 | Owned narrow points, trust model, nominal token/packaging identity, constrained cache validity, curated compatibility matrices, lifecycle/permissions/state separation. |
| [Stateful upgrade/recovery](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/stateful-upgrade-and-recovery-evidence.md) | 2: Temporal, Flink | Execution routing and Activity caveats, state identity/serialization, drain/cancel/termination, forward compatibility and uncertain external effects. |

The [maintained hub](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/plugin-system-research-reference.md) routes to those records and holds 18 stable navigation IDs:

| IDs | Preserved concern |
|---|---|
| PR-01–04 | Inert selection, immutable composition, small owned points, identity-bearing package discipline. |
| PR-05–08 | Overlap/readiness restrictions, one closed operation generation, exact resource owner, publication/admission/drain/retirement distinction. |
| PR-09–12 | Original-identity effect reconciliation, forward fresh-generation rollback, bounded retention/debt, trusted rotation versus hostile enforcement. |
| PR-13–16 | Packed independent compatibility/oracles, upgrade versus revocation/state transfer, subtract existing responsibilities, receiver-enforced durable scheduling epochs. |
| PR-17–18 | Demonstrated native boundary advantage, supported customization seams and aggregate capacity scope. |

The research corpus contains 15 maintained research Markdown files at this checkpoint, plus immutable evidence archives. Initial source inspection is not execution evidence. The later archives deliberately preserve successful runs, failed assumptions and critic corrections rather than turning all observations into one green pass count.

## 3. Evidence matrix: completed, failed and still unqualified

| Track | Published executed evidence | Precise limit |
|---|---|---|
| Static/recovery semantics | 60 existing passes plus 6 added positives; 12 fresh A/B one-shot processes and 24 recovery-worker cycles. [Validation](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/static-composition-and-controlled-restart-validation.md). | External frozen public Core/Assembly 0.7.0, Resources 0.2.1, Conformance 0.5.0; neither current GM source nor Orchestrator repin. FD plateau/known PID exit do not establish RSS/descendant closure. |
| Stop/admission | Two original failed rejection assertions, one independent failed absence control; corrected copied receiver 4 passes, readiness/failed cleanup 1, late-result/physical-exit 2. [Follow-up](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/plugin-boundary-and-failure-experiments.md). | Three raw red witnesses remain. The durable improperly accepted operation survives; not demonstrated data loss or a GM compiler defect. Product admission integration unqualified. |
| Loading/artifact boundary | 6 selected-loading observations; 4 dependency/cache/path-replacement groups; 5 placement trials plus reused failure control; separately corrected actual awaited-init case passes. Same follow-up. | Full hashing does not hold mutable file paths fixed. Root-only refresh does not refresh helper cache. Worker/process availability under selected pure JS loop does not prove hostile isolation. |
| PostgreSQL | Earlier 2 feature tests and 5 crash/authority checks; native SR1 one end-to-end logical restore, 4 named checkpoints. [Native run40407349905](https://github.com/agent-teams-ai/extension-foundation/actions/runs/40407349905). | Real PG18.4, different target cluster after source shutdown; roles/RLS/facts/outbox/retries/new transaction/normal cleanup. Not full product backup/PITR/power loss, installer or all-OS distribution qualification. |
| Drizzle SR2 | Exact accepted RC4 profile stops on 47 vendor-only declaration diagnostics, after separately corrected owned errors. Follow-up retains source/diagnostics. | Runtime contention/rollback not executed. No conclusion about other versions, no implicit repin or custom migrator. |
| Temporal | Native baseline 11 assertion scenarios; optional adapter 7 groups; independent oracle10 finite GM constructions. Validation above. | Explicit Temporal `skipLibCheck:true` research profile; stale canonical SQL mutation rejected after candidate preflight, not arbitrary physical/effect fencing. Finite one-shot construction, not long-lived Host replacement. |
| Node/browser | 5 grouped checks Node26.11.1 / real Chrome156.0.8078.47, plus independent frozen installation. | Static API outputs/digests/diagnostics only, not browser plugin isolation/reload parity. |
| Executor mechanisms | 8 single-worker scenarios plus unchanged repeat; one additional two-worker rejecting Piscina5.3.2 case. [Experiment](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/worker-adapter-replacement-experiment.md). | Close/termination fulfillment not universal drain or physical exit proof. Exact package/profile findings; declaration mismatch retained, final experiment uses explicit `skipLibCheck:true`. |
| Complete-map growth | Supported TS7.0.2 N100/500/1000, eight original capped compiler/runtime stages per size; new descriptor-union recipe. | Real finite construction/smoke, no persistent worker population; no RSS, churn, arbitrary type-level surface or IDE SLO. |
| Current live instances | #223 1,024 simultaneously live independently scoped receivers; current #229 CI executes it again. Details next section. | One small prepared graph, synchronous callbacks/two borrowed sources; no async admission, durable event delivery, isolation realms or product tenants. |

These denominators cannot be added to produce a reliability percentage.

### Raw N1000 reinspection

The EF [416-file archive](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/docs/research/evidence/static-restart-validation-20261025.tar.gz) was read directly. Its SHA256 reverified as `e16e9cdb74bed1e83ec863b19beea8dd7bfe55567d42b36b35ea58ffd1c6de68`.

Members `experiments/scale-browser/growth-results/{100,500,1000}/report.json` each record all eight stages passed. `runtime.json` confirms:

| Named features | Actual declarations | Entries + groups | Edges | Source files | Full-smoke attempts | Factory calls | Dependency-port reads |
|---:|---:|---:|---:|---:|---:|---:|---:|
|100|101|200|197|703|201|10,200|19,803|
|500|501|1,000|997|3,503|1,001|251,000|499,003|
|1,000|1,001|2,000|1,997|7,003|2,001|1,002,000|1,998,003|

The additional declaration is the input. N1000 raw cold stage is 71,339.69171 ms and runtime stage 34,219.375273 ms. The runtime's internal `fullSmoke` timer is 26,209.271142 ms; it is narrower than the supervised whole runtime stage and must not replace that denominator. The eight stages are cold, runtime, unchanged incremental, leaf edit, leaf verify, baseline rewarm, shared-contract edit and shared-contract verify. Caps remain compiler180s/runtime120s/aggregate600s. Failure/abort are injected at every module in full smoke.

Driver/source provenance is GM `b70ba39304ac71964175c42a77309406a7c30ca2`; manifests/dist were replaced with exact frozen registry inputs. This does not qualify a source build of that commit. Source scanner is explicitly incomplete/not selected; RSS was not collected. Upstream [Oct23 complete-map receipt](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/tests/qualification/consumer-fixtures/growth/README.md) separately binds code `8ad16885da6ffac88f65118071255842c4624732` and includes fresh matching source qualification. Its faster single observations are a different input/environment receipt, not a comparative speedup against the EF repetition.

## 4. Newer GM runtime progress must be retained

### #223: actual 1,024 simultaneously live instances

[PR223](https://github.com/agent-teams-ai/get-modular/pull/223) merged Nov2 as `20c3ce8c5bb839a16fbe8dc258d6d96fd5206787`. Exact reviewed source `438bacc94d66828436bffa0e05e02b396fdfd801` has successful [CI41452952298, attempt2](https://github.com/agent-teams-ai/get-modular/actions/runs/41452952298). The API directly confirms SHA, attempt and completed/success; the PR retains all64-job result and the historical cancelled first macOS attempt.

The current [strict TS test](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/tests/assembly/live-instance-custody.test.ts) and [precommitted plan](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/research/module-communication-2026-10/live-instance-custody-plan-2026-11-01.md) show one source input declaration and one receiver declaration. It prepares once, creates all1,024 scopes before awaiting factories, then checks1,024 distinct receiver roots. Two independent borrowed emitters have512 subscribers each. Duplicate identical values stay distinct occurrences. Closing half removes exactly their subscriptions while other receivers still work. Full close leaves zero subscriptions; repeat close does not dispose twice; one fresh reused-template run starts clean. This is meaningful lifetime and reference-custody correctness evidence.

The word “tenant” in the plan/test is model channel isolation. It does not establish authenticated product Tenant grants, database isolation, adversarial confidentiality, process separation, throughput, memory bounds or async callback work. Only synchronous event callbacks are used. The plan explicitly says “not1024 distinct declarations.” Its three critic perspectives are stated to be analytical passes, not independently spawned agents.

### #224: foundational runtime defects repaired, packed false-success closed

[PR224](https://github.com/agent-teams-ai/get-modular/pull/224) merged Nov4; current [qualification record](https://github.com/agent-teams-ai/get-modular/blob/5fb83478dd7b95216be92c4d3077eddf2774eef8/docs/qualification/foundational-runtime-refactor-2026-11.md) preserves six reproduced defects and corrections:

- Assembly returns the verified Core-owned composition it executes; completed explicit+inferred bindings are admitted before Core; repeated unresolved slots share frozen indexed candidates.
- Resources uses iterative deep traversal/start queuing and releases successful detached-child ancestry while retaining pending/failed custody.
- Observation validates deep plain graphs iteratively while preserving order, identity, aliases, cycles and validate-before-freeze semantics.
- Packed Assembly/Resources/Lifecycle nested runners clear inherited `NODE_TEST_CONTEXT` and require actual nonempty passing receipts; an earlier false success was independently controlled rather than overlooked.

These are production-source fixes in existing owners with13 focused regressions and unchanged public contracts, not a new Host. Exact reviewed source `c4046e18246ad7cb45f058d4a15ba5ee9c300d1a` has successful [CI41763804763](https://github.com/agent-teams-ai/get-modular/actions/runs/41763804763); direct API confirms completed/success on that SHA. Existing platform skips and interrupted changed-wrapper result remain explicit. New packaged fixes are pending publication.

### #229: preparation boundary and specific algorithm costs

[PR229](https://github.com/agent-teams-ai/get-modular/pull/229) merged Nov5 into current main. It extracts the private handle census/program mapper, keeps Core semantic ownership, replaces allocated Unicode comparisons and serialized pair lookups, appends adjacency without repeated copies, and indexes dense pin membership locally. Current tests include1,024-provider/2,048-unresolved-slot sharing,512-provider membership/missing pins,2,048-edge layout, Unicode order/explicit-row precedence and duplicate/no-factory checks. No general speedup, new API, version or release is implied.

Exact source `3aae8a2e6695ba1fca96beea68e674a3c27ef0e9` has [CI41971404753](https://github.com/agent-teams-ai/get-modular/actions/runs/41971404753). Direct jobs API returned64 jobs/64success, including all9 Assembly lanes with successful integrity steps. This lane downloaded three actual job logs: [Ubuntu default127060282337](https://github.com/agent-teams-ai/get-modular/actions/runs/41971404753/job/127060282337), [macOS Node24 127060282299](https://github.com/agent-teams-ai/get-modular/actions/runs/41971404753/job/127060282299), [Windows Node26 rollback127060282667](https://github.com/agent-teams-ai/get-modular/actions/runs/41971404753/job/127060282667). Each explicitly contains the passing1,024-live-scoped-consumer test and tracked-workspace-integrity success. The all9 named-test claim is also recorded in the PR's inspected-log report; this lane independently inspected these three cross-OS samples, not all9 logs. Supplementary differential checks are self-checks; the final full-diff review is expressly owner-authorized self-review, not independent external approval.

## 5. Current Orchestrator adoption and scale ownership

[ADR0117 at current main](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/docs/decisions/0117-reconcile-mandatory-module-composition.md), accepted Oct28, supersedes ADR0110. ADR0113 remains exact adopted Core/Assembly0.5.0, CMS `a3a079baca2c6af48c9d45bc08992825be1c2bbd`, FMSv1.1. The old `ddf1e0b` current-adoption account in EF's Oct26 record is now historical. No research update silently installs latest0.7.1 or imports newer main fixes.

Mandatory composition applies to actual independently assembled/replaceable/configurable TypeScript production capabilities across package families. Pure contracts/helpers need no artificial entry. Each process owns its graph; remote roles are not reconstructed locally. Resource/Observation/conformance artifacts need exact first-use qualification. The [readiness matrix](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/docs/architecture/implementation-readiness-gates.md) still marks scope activation, existing seam migration, nested source conformance, representative consumer, lifecycle and initial envelope pending. Separate100/500/1000 growth rows are pending for this consumer. A useful smaller qualified envelope may proceed without waiting for every large research row.

Native PostgreSQL ADR0114/0115 remains accepted for server/local. The [package catalog](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/architecture/package-catalog.yaml) owns topology, not evidence every reserved package is implemented. Scoped Agent Context persistence is real; global profile capacity is not established by it. Latest #97 adds one [synthetic Desktop contract negative](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/scripts/orchestration-specs/desktop-first-slice-v1.test.ts) for authenticated Project-local receipts, wrong-Project rejection and invalid Task payloads. It does not qualify new-core Stage2 operations, real product tenants or packed Electron E2E.

[OD041](https://github.com/agent-teams-ai/agent-teams-orchestrator/blob/5a8496ce711909e381c5bc817fff5500be9a1761/docs/open-decisions/OD-041-shared-extension-foundation-and-artifact-distribution.md) remains resolved architecture direction under ADR0096 with explicit production qualification obligations: same fixture through GHCR/Harbor, auth/credential rotation/unavailability, digest/signature/revocation threat fixtures, fail-closed compatibility, product CLI/API, catalog/authorization separation and at least two independent product integrations. Those obligations are not evidence already passed.

## 6. Scale dimensions and prioritized gaps

| Axis | Actual strongest relevant evidence | Remaining product-level question |
|---|---|---|
| Source/type/graph growth | Supported complete-map N1000 compiler/runtime/source series; finite full-smoke and incremental edit cases. | Actual consumer's accepted artifact/toolchain, nesting/ownership/source classifier, editor/navigation and compatibility costs. |
| Simultaneously live object instances |1,024 distinct same-factory scoped receivers with2 borrowed sources, exact subscription cleanup, cross-OS current CI. | Real selected extension mix, async work, peak/steady memory, long duration, failure/overload resource envelope. |
| Installed catalog size | Inert metadata/selected-loading mechanisms researched and bounded fixtures. | Product-owned registry/catalog query/index/invalidation budgets and actual large inventory. |
| Active third-party plugins | No1,000-plugin product workload established. | Distinct plugin closures, trust/grants, independent release trains and extension-point conformance. |
| Tenants and isolation cohorts | Synthetic channel/project separation negatives; ownership contracts. | Authenticated multi-tenant grants/state isolation, realm/process count, adversarial boundaries. |
| Queue/admission | Stop-admission red witness and measured copied seal; original work recovery retained. | Actual receiver uses one monotonic seal/order, bounded admission/queue saturation and reconcilable uncertainty. |
| Retained generations and upgrades | Individual drain/custody/readiness/failure/cache counterexamples. | Aggregate live candidates/predecessors, failed setup/cleanup debt, varied long churn, memory retention slope, rollback compatibility. |
| Physical custody | Selected real child/Worker exit observations, static restart, PostgreSQL normal cleanup. | Existing keeper/supervisor integration, exact descendants, crash/recovery and deployment-specific controls. |
| Compatibility | GM packed package/peer/public API qualification and nominal-identity lessons. | Independently released product plugin/consumer N/N+1 matrices, duplicate copies, packed contracts, roll-forward/back state compatibility. |

Priority1: qualify one real product contribution/provider family through its existing GM owner and exact adopted artifacts, including actual ingress sealing and fixed-artifact custody. Reuse the preserved path-substitution falsifier and original reservation/absence oracle. This directly closes demonstrated gaps without a second manager/supervisor.

Priority2: state the initial workload as a tuple: installed/selected declarations, distinct factories, live instances, tenants, cohorts, processes/workers, dependency closure, in-flight/queued work, retained active/candidate/predecessor/failed owners and artifact/cache bytes. The existing product capacity owner sets aggregate caps; per-cohort caps do not constrain tenant×cohort×generation×replica multiplication. The1024-live test is a good existing seam to extend only when the real product demands that shape.

Priority3: independent third-party authoring and upgrade compatibility, using packed external consumers and the first actual product point. Demonstrate contribution, explicit provider replacement, conflict diagnostics, optional/required dependencies and restart-needed classification. No promise every possible future customization avoids an upstream core contract change.

Priority4: product-shaped lifetime/churn/overload and release qualification after the first seam exists, including retained failed attempts and cleanup debt. Keep native restore and Drizzle runtime gaps bounded to their actual profile. Broader hostile-code/automatic migration claims require a separate selected profile; ordinary static contributions do not inherit a universal runtime project.

## 7. Existing documentation authoring and metadata procedure

Applicable repository [AGENTS](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/AGENTS.md) routes every documentation task to [.agents/skills/docs-authoring/SKILL.md](https://github.com/agent-teams-ai/extension-foundation/blob/70f03d3d9e134780f27268339a6729a7305a2363/.agents/skills/docs-authoring/SKILL.md), plus the [organization Engineering Quality Standard](https://github.com/agent-teams-ai/.github/blob/main/docs/engineering-quality-standard.md). The latter was fetched this lane; strict TS7.0.2 `.ts`, semantic ownership, evidence fidelity and no gate weakening apply. Root has sole edit/publication ownership.

The read-only `pnpm docs:info` succeeded after root prepared dependencies and confirms:

- Protocol `agent-teams.docs-protocol/v1`; consumer `.`; profile `architecture/foundation/docs-protocol.yaml`; Foundation profile `architecture/foundation/document-authoring.yaml` schema3. Metadata sidecar: none.
- Owners `architecture`, `architecture/security`, `architecture/tooling` only. Research initial status `active`, ID grammar `research.<one-suffix>`, path `docs/research/<slug>.md`. Required canonical metadata is `id,type,status,owner,summary`; schema forbids arbitrary fields. Research status only `active|archived`.
- Search first with `pnpm docs:find -- --text <query>`; reuse/relate existing authority. New records use identical `docs:new` intent inputs for reviewed `--dry-run` then `--apply`, with reviewed plan digest where current CLI requests it. Do not hand-create governed metadata to bypass create-only workflow.
- Manual reachability index is `docs/README.md`; the writer never edits it. Hub links can route additional detailed research while the governed index remains current.
- For edits preserve canonical metadata/ownership and use governed review flow. Accepted ADR bodies are immutable; explicit supersession is required. Keep frozen pins/archive bytes/dates intact and append current supersession/status where appropriate.
- Refresh bounded context with installed `docs-protocol context --consumer . --profile architecture/foundation/docs-protocol.yaml --max-documents 8 --max-bytes 32768`, copied from the owning script rather than an invented profile.
- Run `pnpm docs:check`, then `pnpm docs:protocol:check` after index updates; repository changed/fast/full gates remain their separate actual contracts. This lane did not run those gates or tests. No docs protocol transaction was modified.

The maintained hub's undated-looking claim that no thousand-module authoring/runtime profile passed predates its own dated corrections. Root should make current status unequivocal near the top while retaining the historical source-only/compiler-blocker observations and exact inputs. Include current main/source versus released artifacts versus Orchestrator adopted baseline as separate rows. The correct status recognizes both bounded N1000 construction and1024 live receivers while keeping missing product scale evidence explicit.
