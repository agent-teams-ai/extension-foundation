# Independent critic: plugin author experience and useful no-fork customization

2026-11-05. Read the complete shared brief, all three investigator reports and the root synthesis. This review evaluates the supplied evidence and proposed acceptance criteria; it adds no competitor facts, executed tests or implementation. Sources are those supplied records. Dense/live scale and industrial freshness belong to the other critics.

## Verdict

**Accept the ownership direction; revise the qualification priorities before publication.** GM composition, plugin/product-owned contracts and controlled restart can support powerful customization. However, the proposed first seam tests provider composition, attribution and readiness. It does **not** yet test extending another plugin or changing an actual UI/workflow. The synthesis correctly names these outcomes under “industry-leading” criterion 1, then postpones the actual no-fork journey to Priority 3. Custody is necessary, but it cannot substitute for evidence that useful behavior is externally customizable.

The accepted design is a credible direction, not demonstrated deep customization. Do not let “hundreds/thousands of modules” turn into either thousands of arbitrary extension points or a generic second PluginManager. A few public seams completing valuable user jobs establish more than another abstract registry.

## Material corrections and dispositions

| Finding | Required disposition |
| --- | --- |
| Priority-1 providers do not establish plugin-to-plugin extension or visible customization. | **Revise:** make one useful external-author journey a Priority-1 co-gate with artifact/admission qualification. Keep broad UI coverage and full upgrade matrices later. |
| A contribution can be “independently packaged” while still importing host/private plugin internals. | **Clarify:** independently compile and pack against public contracts; install without workspace aliases, source patches, private imports or host implementation dependencies. Ordinary dependency/config/lock changes are legitimate. |
| Two providers can exist without genuine substitution. | **Add:** exercise an existing consumer through the selected replacement and prove baseline consumers no longer bypass it by importing the original implementation. |
| Determinism can accidentally mean sorted registration wins. | **Clarify:** a point has explicit cardinality and selection/merge rules. Permuting discovery must preserve the outcome for identical declared inputs. An explicitly configured pipeline order is itself an input and may intentionally change behavior. |
| The negative alternative combines a generic mutable hook registry with universal unload. | **Split:** reject universal arbitrary mutation/unload; retain narrow typed transforms, middleware or UI contributions when a real product operation needs them. Rich hooks do not inherently require hot reload. |
| “A supported upgrade preserves the journey” can imply an unapproved universal backward-compatibility obligation. | **Scope:** compatibility follows the declared support policy. MVP may deliberately break an experimental contract, with explicit version/lock change, rejection and migration guidance. |
| “Ordinary authors learn only the point” is currently an intention. | **Label unqualified:** demonstrate it using an author-facing recipe and independently packaged consumer. The research does not yet establish low author burden. |

## Smallest useful no-fork acceptance journey

Use the first existing feature that has a real user operation and a public customization opportunity. Do not invent a universal framework or a dummy UI to satisfy the checklist. If no actual UI/workflow surface exists, record that gap instead of treating a backend provider test as its completion.

1. **Baseline:** install feature plugin A into the product through existing GM composition. Complete one observable user task using A's default provider. A exposes its narrow contract from a public contract package; extension B does not depend on A's implementation.
2. **Extend and replace:** independently build/pack B against that contract. By supported installation/configuration and controlled restart, B supplies an alternative provider **and** one useful additive/decorating change to that task's workflow or UI. Demonstrate a changed outcome, not merely a successful registration. Product and A source identities remain unchanged.
3. **Compose:** retain A's other behavior while B's contribution operates. This distinguishes extending A from replacing/forking the entire feature. Existing collaborators must actually use the selected provider. If the first journey covers workflow only, UI customization remains explicitly unqualified, and conversely.
4. **Conflict:** introduce a tiny independently identified conflicting contribution. Exercise both discovery permutations. For a singleton/key, reject ambiguity or use an explicit configured selector; for a pipeline, demonstrate its documented ordering/merge rule. Show both suppliers and the exact corrective action. A declaration-order accident is a failure even if reproducible once.
5. **Failure and recovery:** fail the selected provider after registration, show the responsible supplier and the required/optional readiness consequence, then remove/disable B and restart. The original task works again. Reuse existing artifact/admission falsifiers at this same boundary; authors must not implement those mechanisms themselves.

This can use A, B and a small conflict fixture, with only the contracts required by their user task. It is an **unexecuted proposal**, not authorization to implement new public surfaces. Passing supports “this task is customizable without forks.” It does not prove all workflows/UI, arbitrary plugin combinations or industry leadership.

## Author burden and actionable diagnosis

The first recipe should expose: the point to use, contract maturity/version, a short implementation, contribution identity, supported dependency/configuration declarations and the existing resource-lifetime convention. An author with a timer/subscription still owns its behavior and must register cleanup correctly. They should not copy artifact verification, rollout coordination, global grant arbitration, ingress sealing or physical process custody into every plugin.

Record actual author effort: public concepts and files required, boilerplate versus task logic, product/private source edits required, missing documentation, and whether a failure can be resolved from the supplied diagnostic. Do not invent a numerical time-to-first-plugin target without observation. One researcher writing both sides is useful integration evidence, but is not independent author-usability evidence.

A diagnostic must do more than dump point/version/artifact fields. For a conflict it should identify the contribution IDs, expected cardinality, effective selector/order and the available repair: select one supplier, rename the keyed contribution or remove the conflicting package. For a connection failure, identify the supplying module, public point and required/optional consequence. Offer the small causal explanation first; retain full graph/provenance for inspection. A thousand-candidate dump alone is technically attributable but operationally weak.

## Compatibility appropriate to an MVP

The supplied brief allows deliberate breaks. Do not silently import Backstage's deprecation/new-point strategy as a mandatory long-term support promise. Mark a seam experimental, exact-pin its supported host/contract/package profile, and state which producer/consumer combinations are supported. An incompatible candidate must be rejected before readiness with the expected contract and migration path. A deliberately breaking release can require an author update; that is different from an accidental break or an unannounced private dependency.

Later, test a real supported upgrade in both producer and consumer roles. Where backward compatibility is deliberately unsupported, test understandable rejection and a working documented migration instead. Neither semver alone nor testing every subset of thousands of modules supplies that policy.

## Scores, LOC and coverage claims

The synthesis responsibly distinguishes source, documentation and execution, avoids a superiority ranking and scopes the N1000/live-instance evidence. Preserve those qualifications. Twenty comparison cases and 18/19 pattern IDs are navigation coverage, not completeness or a readiness percentage. Public-contract availability, plugin-to-plugin extensibility, UI/workflow depth and independently observed author effort remain unproven by those counts.

Keep the required /10 judgments, but label **9/8/4** as confidence in architectural fit, expected reliability under assumptions and expected complexity—not product readiness. The unqualified joins and missing author journey materially constrain the interpretation of “8 reliability.” The table should not make the preferred narrow path appear proven by comparing it only with the broadest undesirable alternative.

The **0 shared production / 150–500 integration / 600–1,400 fixture LOC** estimate is honestly scoped to an existing backend restart/custody slice, with approximately ×2 uncertainty. It does not price a new public contract, author documentation, UI/workflow extensibility or compatibility maintenance. Retain it only under that explicit heading; state the useful no-fork journey's additional work is **not yet estimated** until the actual surface is chosen. Zero new shared code is a design constraint/assumption to validate, not a claim that deep customization costs zero.

**Publication disposition:** accepted direction; accept bounded evidence; revise author journey priority and compatibility wording; reject any statement that deep no-fork customization or minimal author burden is already demonstrated. No new manager, production implementation, installs or tests are needed for these research corrections.

## Final narrow verification

Re-read the updated synthesis on 2026-11-05. The requested corrections are applied: Priority 1 now includes the visible A+B+conflict journey; substitution must reach existing consumers; public-contract packaging excludes private imports/workspace aliases; discovery permutations are distinguished from declared pipeline order; removal restores baseline behavior. MVP breaks explicitly remain allowed with rejection/migration guidance. Narrow typed workflow/UI contributions are separated from global mutation and universal unload. The historical backend LOC estimate explicitly excludes additional author-journey work, and minimal author burden remains unqualified until independently observed. Workflow-only evidence does not qualify UI, or conversely.

**Final disposition: no remaining publication blocker in this critic's assigned scope.** Earlier correction requests above are now resolved for this research document. The journey remains proposed and unexecuted; this disposition approves evidence wording and qualification priorities, not production readiness, implementation adoption or a merge. Only this report was appended; no repository file, install or test was changed or run.
